module.exports = {
  presets: [
    '@vue/cli-plugin-babel/preset'
  ],
  plugins: [
    ["import", { "libraryName": "we-vue", "style": "style.css" }, "we-vue"]
  ]
}
