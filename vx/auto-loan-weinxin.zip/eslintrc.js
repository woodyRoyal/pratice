module.exports = {
  // ...
  extends: [
    '@ued2345',
  ],
  // ...
}
