let isDev = process.env.NODE_ENV === 'development'
const CopyWebpackPlugin = require('copy-webpack-plugin')
module.exports = {
  publicPath: isDev ? '/' : '',
  outputDir: 'auto-wx-web',
  runtimeCompiler: true, // 运行时是否需要编译
  productionSourceMap: process.env.NODE_ENV !== 'production',
  devServer: {
    open: true, // 自动打开浏览器
    port: 8085, // 避免多个项目使用相同的端口
    proxy: {
      '/autoloan-wx': {
        target: 'http://cycyh.wang/auto-wx-web', // T1环境
        // target: 'http://d1-managerdaikuan.2345.com', // 目标网址，开发域名D2
        // target: 'http://172.16.0.141:10102', // 目标网址，开发域名D2
        // target: 'http://172.17.16.103:8080', // 目标网址，王浩机器
        // target: 'http://172.17.16.194:8080', // 目标网址，姜绵岳机器
        ws: false, // 是否启用websockets,此项目不存在ws连接
        changOrigin: true, // 是否将请求header中的origin修改为目标地址
        pathRewrite: {
          // '^/auto-loan-api': ''
        }
      },
    }, // 转发代理配置
    overlay: {
      warnings: true,
      errors: true
    }
  },

  configureWebpack: (config) => {
    let src = process.env.NODE_ENV === 'uat' ? __dirname + '/src/assets/uat/MP_verify_wTm9vf8n3PDrC73w.txt' : __dirname + '/src/assets/pro/MP_verify_O76MHcrRv4JRdd7C.txt'
    config.plugins.push(
      new CopyWebpackPlugin(
        [
          {
            from: src,
            to: __dirname + '/auto-wx-web',
            ignore: ['.*']
          }
        ]
      )
    )
  },
  lintOnSave: isDev, // 当 lintOnSave 是一个 truthy 的值时，eslint-loader 在开发和生产构建下都会被启用 (True|false|error)

}
