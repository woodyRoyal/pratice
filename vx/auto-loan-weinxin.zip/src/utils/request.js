import axios from 'axios'
import hostApi from '../config/apiHost'
import { Toast } from 'we-vue'
axios.defaults.headers.common['Content-Type'] = 'application/json;charset=UTF-8'
axios.defaults.baseURL = hostApi.basePath // 发送请求的基础url
axios.defaults.timeout = 30000 // 请求的超时时间
axios.defaults.withCredentials = true // 需要跨域携带认证

// 添加请求拦截器
axios.interceptors.response.use(config => {
  // console.log('begin request')
  return config
})

// 添加一个响应拦截器
axios.interceptors.response.use(res => {
  // 在这里对返回的数据进行处理/
  if (res.data.code !== '1000') {
    Toast.fail('服务错误');
    return Promise.reject(res.data || '服务器错误')
  }
  return res.data
}, (err) => {
  Toast.fail('服务错误');
  return Promise.reject(err)
})

let request = options => {
  options.headers = options.header || {}
  options.method = options.method || 'post'
  if (options.method.toUpperCase() === 'GET') {
    options.params = options.data
  }
  return axios(options)
}

export default request