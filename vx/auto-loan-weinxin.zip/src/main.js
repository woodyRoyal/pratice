import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import './assets/reset.css'
import { Input, Button, Group, actionsheet } from 'we-vue'
import 'we-vue/lib/style.css'
import wx from 'weixin-js-sdk'
window.console.log(wx)
Vue.config.productionTip = false
Vue.use(Input).use(Button).use(Group).use(actionsheet)
// 手机端调试工具
import VCconsole from 'vconsole'
let vConsole = new VCconsole();
window.console.log(vConsole)
new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
