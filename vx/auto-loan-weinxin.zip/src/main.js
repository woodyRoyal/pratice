import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import { Input, Button, Group, actionsheet } from 'we-vue'
import 'we-vue/lib/style.css'
import './assets/reset.css'
import { setCookie, getCookie, deleteCookie } from '../src/utils/cookie'
// import wx from 'weixin-js-sdk'
// import wechatAuth from './plugins/wechatAuth' // 微信登录插件
// window.console.log(wx)
Vue.config.productionTip = false
Vue.use(Input).use(Button).use(Group).use(actionsheet)
// import './permission'
// 手机端调试工具微信页面
import VCconsole from 'vconsole'
let vConsole = new VCconsole();

// 设置appid
// Vue.use(wechatAuth, {
//   appid: 'wx9959e0ecb39da84d'
// })
router.beforeEach((to, from, next) => {
  if (!/micromessenger/i.test(navigator.userAgent) && process.env.NODE_ENV === 'development') {
    if (!getCookie('wxUserInfo')) {
      setCookie('wxUserInfo', '3d089fe3-be94-4e22-8c71-3d5605e72108')
    }
    setCookie('wxRedirectUrl', '/home/applyList')
    next()
    return
  }
  //不要对 WxAuth 路由进行拦截，不进入 WxAuth 路由就拿不到微信返回的授权 code
  if (to.name === 'WxAuth' || to.name === '常见问题' || to.name === '公司介绍' || to.name === '联系我们') {
    next()
    return
  }
  // window.alert('获取wxUserInfo')
  let wxUserInfo = getCookie('wxUserInfo')
  if (!wxUserInfo) {
    // window.alert('wxUserInfo不存在')
    //保存当前路由地址，授权后还会跳到此地址
    // window.alert('存储fullPath')
    if (getCookie('wxRedirectUrl')) {
      deleteCookie('wxRedirectUrl')
    }
    setCookie('wxRedirectUrl', to.fullPath)
    //请求微信授权,并跳转到 /WxAuth 路由
    let appId = process.env.VUE_APP_WECHAT_APPID
    let redirectUrl = encodeURIComponent(process.env.VUE_APP_BASE_URL)
    window.location.href = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${appId}&redirect_uri=${redirectUrl}&response_type=code&scope=snsapi_userinfo&state=STATE&connect_redirect=1#wechat_redirect`
  } else {
    // window.alert('已经有wxUserInfo')
    next()
  }
})
window.console.log(vConsole, new Date())
new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
