<template>
  <div>
    <div class="logo-box">
      <img src="../../assets/logo.png"
           alt="">
    </div>
    <h5 class="">请输入您的身份信息进行用户绑定</h5>
    <div class="form">
      <wv-group title="">
        <wv-input label="手机号码"
                  placeholder="请输入申请手机号"
                  v-model.trim="form.mobilephone"
                  pattern="^[1]([2-9])[0-9]{9}$"
                  required
                  :validate-mode="{onFocus: false,onBlur: true,}"></wv-input>
        <wv-input label="姓名"
                  placeholder="请输入姓名"
                  v-model.trim="form.name"
                  required></wv-input>
        <wv-input label="身份证号"
                  placeholder="身份证号"
                  v-model.trim="form.idno"
                  required
                  pattern="^[a-zA-Z0-9]$"
                  :validate-mode="{onFocus: false, onBlur: true, onChange: false}"></wv-input>
        <wv-input label=""
                  class="weui-cell_vcode"
                  required
                  placeholder="请输入图片验证码"
                  v-model.trim="form.captchaText">
          <img src="../../assets/logo.png"
               @click="changeCaptcha"
               style="width:100px;height:40px;"
               slot="ft" />
        </wv-input>
        <wv-input label=""
                  placeholder="请输入手机验证码"
                  v-model.trim="form.sms">
          <button class="weui-vcode-btn"
                  slot="ft"
                  @click="hadleGetCode()">{{GetCodeBTN}}</button>
        </wv-input>

      </wv-group>
      <div class="btn-main">
        <wv-button type="primary"
                   :disable="true"
                   @click="bind()">绑定</wv-button>
      </div>
      <div class="bottom">
        若手机号已更换，请致电客服电话：021-61046012/61046050
      </div>
    </div>

  </div>
</template>
<script>
import api from '../../api/login.js'
import { setInterval, clearInterval } from 'timers';
export default {
  data () {
    return {
      timer: null,
      GetCodeBTN: '获取验证码',
      form: {
        mobilephone: '',
        name: '',
        idno: '',
        sms: '',
        captchaText: '',
      },
      image: {

      },
      smsCode: {

      }
    }
  },
  created () {
    window.console.log(api)
  },
  methods: {
    bind () {

    },
    async autoGetImage () {
      let data = {
        mobilephone: this.form.mobilephone,
        token: ''
      }
      let res = await api.getImage(data)
      this.image = res.body
    },
    async getCode () {
      let data = {
        mobilephone: this.form.mobilephone,
        token: ''
      }
      let res = await api.getCode(data)
      this.smsCode = res.body
    },
    changeCaptcha () {
      this.autoGetImage()
    },
    hadleGetCode () {
      this.getCode()
      this.GetCodeBTN = 60
      this.timer = setInterval(() => {
        if (this.GetCodeBTN !== '获取验证码' && this.GetCodeBTN > 0) {
          this.GetCodeBTN = this.GetCodeBTN - 1
        } else {
          this.GetCodeBTN = '获取验证码'
          clearInterval(this.timer)
        }
      }, 1000)
    }
  }
}
</script>
<style lang="scss" scoped>
h5 {
  text-align: center;
  margin-top: 30px;
}
.logo-box {
  background: #fff;
  text-align: center;
  img {
    margin-top: 20px;
    // width: 600px;
    height: 280px;
  }
}
.form {
  background: #fff;
  margin-top: 20px;
}
.btn-main {
  padding: 10px 40px;
  margin-top: 40px;
}
.bottom {
  position: fixed;
  bottom: 0px;
  width: 100%;
  text-align: center;
  color: #666;
}
</style>
