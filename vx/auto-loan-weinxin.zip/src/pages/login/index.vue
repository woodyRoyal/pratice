<template>
  <div>
    <div class="logo-box">
      <img src="../../assets/logo.png"
           alt="">
    </div>
    <h5 class="">请输入您的身份信息进行用户绑定</h5>
    <div class="form">
      <wv-group title="">
        <wv-input label="手机号码"
                  class="inputsp"
                  placeholder="请输入申请手机号"
                  required
                  @blur="autoGetImage()"
                  v-model.trim="form.mobilephone"></wv-input>
        <wv-input label="姓名"
                  class="inputsp"
                  placeholder="请输入姓名"
                  @blur="checkName()"
                  v-model.trim="form.name"
                  required></wv-input>
        <wv-input label="身份证号"
                  class="inputsp"
                  placeholder="身份证号"
                  required
                  @blur="checkId()"
                  v-model.trim="form.idno"></wv-input>
        <wv-input label=""
                  class="weui-cell_vcode special "
                  required
                  @blur="checkCaptchaText()"
                  placeholder="请输入图片验证码"
                  v-model.trim="form.captchaText">
          <img :src="`data:image/jpeg;base64,${image.captchaImage}`"
               @click="autoGetImage()"
               style="width:123px;height:40px;"
               slot="ft" />
        </wv-input>
        <wv-input label=""
                  class="vcodeInput"
                  placeholder="请输入手机验证码"
                  required
                  v-model.trim="form.sms">
          <button class="weui-vcode-btn"
                  slot="ft"
                  @blur="checkSms()"
                  :disabled="GetCodeBTN !== '获取验证码'"
                  @click="getCode()">{{GetCodeBTN}}</button>
        </wv-input>
      </wv-group>
      <div class="btn-main">
        <wv-button type="primary"
                   :disable="true"
                   @click="bind()">绑定</wv-button>
      </div>
      <div class="bottom">
        若手机号已更换，请致电客服电话：4008013610
      </div>
    </div>
  </div>
</template>
<script>
import api from '../../api/login.js'
import { setInterval, clearInterval } from 'timers';
import { getCookie } from '../../utils/cookie.js'
import { Toast } from 'we-vue'
export default {
  data () {
    return {
      timer: null,
      GetCodeBTN: '获取验证码',
      form: {
        mobilephone: '',
        name: '',
        idno: '',
        sms: '',
        captchaText: '',
      },
      image: {

      },
      smsCode: {

      },
      token: null,
    }
  },
  created () {
    this.token = getCookie('wxUserInfo') || localStorage.getItem('token') || null
  },
  methods: {
    async bind () {
      if (!/^1[0-9]{10}$/.test(this.form.mobilephone)) {
        return Toast.fail('请填写正确手机号码')
      }
      if (!this.form.name) {
        return Toast.fail('请填写姓名')
      }
      if (!/[0-9a-zA-Z]/.test(this.form.idno)) {
        return Toast.fail('请填写正确的身份证号')
      }
      if (!/[0-9a-zA-Z]/.test(this.form.captchaText) || this.form.captchaText.length !== 4) {
        return Toast.fail('请填写正确的图片验证码')
      }
      if (!/[0-9]/.test(this.form.sms) || this.form.sms.length !== 6) {
        return Toast.fail('请填写正确的手机验证码')
      }
      let data = {
        ...this.form,
        token: this.token
      }
      let res = await api.bind(data)
      window.console.log(res)
      Toast.success('绑定成功')
      setTimeout(() => {
        this.$router.push({ name: '申请单' })
      }, 1000)
    },
    checkName () {
      if (!this.form.name) {
        return Toast.fail('请填写姓名')
      }
    },
    checkId () {
      if (!/[0-9a-zA-Z]/.test(this.form.idno)) {
        return Toast.fail('请填写正确的身份证号')
      }
    },
    checkCaptchaText () {
      if (!this.form.captchaText) {
        return Toast.fail('请填写图片验证码')
      }
    },
    checkSms () {
      if (!this.form.sms) {
        return Toast.fail('请填写手机验证码')
      }
    },
    async autoGetImage (val) {
      if (!val) {
        if (!/^1[0-9]{10}$/.test(this.form.mobilephone)) {
          return Toast.fail('请填写正确手机号码')
        }
      }
      let data = {
        mobilephone: this.form.mobilephone,
        token: this.token
      }
      let res = await api.getImage(data)
      this.image = res.body
    },
    async getCode () {
      if (!/^1[0-9]{10}$/.test(this.form.mobilephone)) {
        return Toast.fail('请填写正确手机号码')
      }
      if (!this.image.captchaKey) {
        return Toast.fail('请先填写图片验证码')
      }
      if (this.GetCodeBTN !== '获取验证码') return Toast.fail('重复点击无效');
      this.GetCodeBTN = 60
      this.timer = setInterval(() => {
        if (this.GetCodeBTN !== '获取验证码' && this.GetCodeBTN > 0) {
          this.GetCodeBTN = this.GetCodeBTN - 1
        } else {
          this.GetCodeBTN = '获取验证码'
          clearInterval(this.timer)
        }
      }, 1000)
      try {
        let data = {
          mobilephone: this.form.mobilephone,
          token: this.token,
          captchaKey: this.image.captchaKey,
          captchaText: this.form.captchaText
        }
        let res = await api.getCode(data)
        this.smsCode = res.body
      } catch (error) {
        this.GetCodeBTN = '获取验证码'
        clearInterval(this.timer)
      }
    },
  },
}
</script>
<style lang="scss" scoped>
h5 {
  text-align: center;
  margin-top: 20px;
}
.logo-box {
  background: #fff;
  text-align: center;
  img {
    margin-top: 10px;
    // width: 600px;
    height: 250px;
  }
}
.form {
  background: #fff;
  margin-top: 0px;
}
.btn-main {
  padding: 10px 40px;
  margin-top: 10px;
}
.bottom {
  position: fixed;
  bottom: 0px;
  width: 100%;
  text-align: center;
  color: #666;
}
.special .weui-cell__ft {
  font-size: 0;
}
</style>
