<template>
  <div>
    <div class="title">
      对公还款(单期还款)
    </div>
    <div class="content">
      <p>1.对公打款步骤如下：</p>
      <p class="mt-30"> 对公户名： {{obj.name}}</p>
      <p>开户行：{{obj.bank}} </p>
      <p>账 号：{{obj.account}} </p>

      <p class="mt-30">2.对公打款时请备注：{{obj.comment}}</p>
      <p class="mt-30">3. 对公还款到账后，我司会有专员处理，请耐心等待。如因打款账户信息有误或未备注打款信息原因导致的罚息，需由客户自行承担。</p>
    </div>
    <div class="bottom">
      如有任何问题，请致电2345车贷王客服：4008013610
    </div>
  </div>
</template>
<script>
import api from '../../api/repay.js'
import { getCookie } from '../../utils/cookie.js'
export default {
  data () {
    return {
      obj: {
        name: '',
        bank: '',
        account: '',
        comment: '',
      }
    }
  },
  created () {
    this.fetchData()
  },
  methods: {
    async fetchData () {
      let data = {
        token: getCookie('wxUserInfo') || localStorage.getItem('token') || null,
        applyId: this.$route.query.applyId
      }
      let res = await api.getPublicInfoByApplyId(data)
      this.obj = res.body
    }
  }
}
</script>
<style lang="scss" scoped>
.title {
  padding: 30px;
  font-size: 26px;
  font-weight: 600;
}
.mt-30 {
  margin-top: 30px;
}
.bottom {
  position: fixed;
  bottom: 30px;
  width: 100%;
  text-align: center;
  color: #666;
}
.content {
  padding: 30px;

  p {
    line-height: 40px;
  }
}
</style>
