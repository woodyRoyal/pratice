<template>
  <div>
    <div class="title">
      对公还款(提前结清)
    </div>
    <div class="content">
      <p>提前结清步骤如下：</p>

      <p class="mt-30"> 1.对公账户信息如下：</p>
      <p>对公户名：{{obj.name}}</p>
      <p>开户行：{{obj.bank}}</p>
      <p>账号：{{obj.account}}</p>
      <p class="mt-30">2. 对公打款时请备注：{{obj.comment}}</p>
      <div class="mt-30">3.请下载并打印【
        <span class="linkClass"
              @click="downLoad()">融资租赁提前结清申请书</span>
        】（请使用微信电脑版打开本页面并点击文件名进行下载）后由本人签名按手印，并手持身份证正面+已签署的确认书拍照邮件至客服邮箱：cdw_service@2345.com。
      </div>
      <p class="mt-30">4.对公还款到账后，我司会尽快处理，请耐心等待。如因打款账户信息有误或未备注打款信息原因导致的罚息，需由客户自行承担</p>
      <p class="mt-30">5.结清解押材料会在符合结清要求（我司收到全部结清款项+符合要求的结清面签照片）后的30个工作日内安排邮寄至合作经销商，请耐心等待。</p>
    </div>
    <div class="bottom">
      如有任何问题，请致电2345车贷王客服：4008013610
    </div>
  </div>
</template>
<script>
import api from '../../api/repay.js'
import { getCookie } from '../../utils/cookie.js'
export default {
  data () {
    return {
      obj: {
        name: '',
        bank: '',
        account: '',
        comment: '',
      }
    }
  },
  created () {
    this.fetchData()
  },
  methods: {
    downLoad () {
      // /apply/downloadAdvanceRepayApplyFile?token=aa&applyId=886
      window.location.href = process.env.VUE_APP_BASE_API + '/apply/downloadAdvanceRepayApplyFile?' + `token=${getCookie('wxUserInfo') || localStorage.getItem('token') || ''}&applyId=${this.$route.query.applyId}`
    },
    async fetchData () {
      let data = {
        token: getCookie('wxUserInfo') || localStorage.getItem('token') || null,
        applyId: this.$route.query.applyId
      }
      let res = await api.getPublicInfoByApplyId(data)
      this.obj = res.body
    }
  }
}
</script>
<style lang="scss" scoped>
.linkClass {
  color: blue;
  cursor: pointer;
}
.title {
  padding: 30px;
  font-size: 26px;
  font-weight: 600;
}
.mt-30 {
  margin-top: 30px;
}
.bottom {
  position: fixed;
  bottom: 30px;
  width: 100%;
  text-align: center;
  color: #666;
}
.content {
  padding: 30px;

  p {
    line-height: 40px;
  }
}
</style>
