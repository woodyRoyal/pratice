<template>
  <div>
    微信网页授权中，如有失败，请退至微信号重新点击菜单进入
  </div>
</template>

<script>
/**
 * 微信网页授权
 */
import { loginByCode } from '../../api/login.js'
import { setCookie, getCookie } from '../../utils/cookie.js'
// import 
export default {
  name: 'WxAuth',
  async created () {
    if (window.location.href.includes("auto-wx-web/?code")) {  //url包括 /?code 证明为从微信跳转回来的
      var url = window.location.href.substring(0, window.location.href.length - 13); //vue自动在末尾加了 #/ 符号，截取去掉
      var jingPosit = url.indexOf("auto-wx-web/") + 12; //获取域名结束的位置
      var urlLeft = url.substring(0, jingPosit);//url左侧部分
      var urlRight = url.substring(jingPosit, url.length); //url右侧部分
      let res = urlLeft + "#/home/WxAuth" + urlRight;
      window.location.href = res//拼接跳转
    }
    // window.alert(this.$route.query.code)

    let code = this.getQueryString('code')

    // window.alert(window.location.href)
    // window.alert(code)
    let redirectUrl = getCookie('wxRedirectUrl')
    // 如果连接中有微信返回的 code，则用此 code 调用后端接口，向微信服务器请求用户信息
    // 如果不是从微信重定向过来的，没有带着微信的 code，则直接进入首页
    if (code) {
      // window.alert('地址带code')
      let res = await loginByCode({
        code: code
      })
      // setCookie('token', res.body.token)
      setCookie('wxUserInfo', res.body.token)
      window.location.href = process.env.VUE_APP_LEFT_URL + redirectUrl
    } else {
      window.alert('地址不带code')
      window.location.href = process.env.VUE_APP_LEFT_URL + redirectUrl
    }

  },
  methods: {
    getQueryString (name) {
      let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)')
      // let r = window.location.search.substr(1).match(reg)
      let num = window.location.href.indexOf('?')
      let r = window.location.href.substr(num + 1).match(reg)
      if (r != null) return decodeURI(r[2])
      return null
    }
  }
}
</script>