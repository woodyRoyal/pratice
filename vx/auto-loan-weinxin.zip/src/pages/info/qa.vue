<template>
  <div class="ignore">
    <div class="title">
      常见问题
    </div>
    <div class="qa-list">
      <p>Q: 提前还款金额查询及操作咨询</p>
      <p>A：如你需提前结清，可通过公众号查询结清金额并通过微信还款，或通过对公打款，详见常用服务-提前结清。</p>
      <div class="line"></div>
    </div>
    <div class="qa-list">
      <p>Q: 结清材料邮寄时效</p>
      <p>A：结清解押材料会在符合结清要求（我司收到全部结清款项+符合要求的结清面签照片）后的30个工作日内安排邮寄至合作经销商。</p>
      <div class="line"></div>
    </div>
    <div class="qa-list">
      <p>Q: 变更还款卡</p>
      <p>A：请拨打客户热线进行还款卡的变更</p>
      <div class="line"></div>
    </div>
    <div class="qa-list">
      <p>Q: 借阅登记证书或营业执照</p>
      <p>A：请将借阅需求发送至客服邮箱，后续我司会有专员进行回复处理。</p>
      <div class="line"></div>
    </div>
    <div class="qa-list">
      <p>Q: 借阅登记证书原件或营业执照原件</p>
      <p>A：您好，借阅登记证书原件或营业执照原件请直接联系当地工作人员。</p>
      <div class="line"></div>
    </div>
    <div class="qa-list">
      <p>Q: 我车子出险了，需要你们开具委托书/理赔函。</p>
      <p>A：请备妥已加盖鲜章的交通事故认定书、车辆定损单（或物损/人伤清单）、对应理赔金额的发票。发送至客服邮箱：cdw_service@2345.com，邮件主题：【保险理赔】+申请编号+客户姓名， 我司工作人员会进行处理。</p>
      <div class="line"></div>
    </div>
    <div class="qa-list">
      <p>Q: 我车不想要了，还给你们。</p>
      <p>请将自愿弃车的需求发送至以下邮箱cdw_dh@2345.com，会有相关工作人员联系处理。
      </p>
      <div class="line"></div>
    </div>

    <div class="bottom">
      如有任何问题，请致电2345车贷王客服：021-61046012/61046050
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {

    }
  },
  created () {
  },
  methods: {

  }
}
</script>
<style lang="scss" scoped>
.title {
  padding: 30px;
  font-size: 30px;
  font-weight: 800;
}
.ignore {
  // height: calc(100% - 80px);
  // padding-bottom: 140px;
  // margin-bottom: 140px;
  // overflow-y: scroll;
  // position: fixed;
  // top: 40px;
  // bottom: 40px;
  // left: 0;
  // right: 0;
}
.bottom {
  position: fixed;
  bottom: 0px;
  width: 100%;
  text-align: center;
  color: #666;
}
.qa-list {
  padding: 0 30px;
  p {
    padding: 10px 0;
  }
  .line {
    border: 1px solid rgb(207, 207, 207);
  }
}
</style>
