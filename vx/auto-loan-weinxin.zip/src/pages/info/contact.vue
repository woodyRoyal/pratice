<template>
  <div>
    <div class="title">
      联系我们
    </div>
    <div class="qa-list">
      <p>公司地址： 上海市浦东新区张江高科技园区环科路555号</p>
      <p>（工作时间，周一至周五 9：00-18：00）</p>
      <div class="line"></div>
    </div>
    <div class="qa-list">
      <p>车贷王客服电话： 021-61046012/61046050</p>
      <p>车贷王客服邮箱：cdw_service@2345.com</p>
      <div class="line"></div>
    </div>
    <div class="qa-list">
      <p>经销商服务专线：021-61046008</p>
      <p>经销商对接邮箱：cdw_dh@2345.com</p>
      <div class="line"></div>
    </div>
    <div class="bottom">
      如有任何问题，请致电2345车贷王客服：021-61046012/61046050
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {

    }
  },
  created () {
  },
  methods: {

  }
}
</script>
<style lang="scss" scoped>
.title {
  padding: 30px;
  font-size: 30px;
  font-weight: 800;
}
.bottom {
  position: fixed;
  bottom: 0px;
  width: 100%;
  text-align: center;
  color: #666;
}
.qa-list {
  margin-top: 30px;
  padding: 0 30px;
  p {
    padding: 10px 0;
  }
  .line {
    border: 1px solid rgb(207, 207, 207);
  }
}
</style>
