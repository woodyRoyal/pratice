<template>
  <div>
    <div class="title">
      公司介绍
    </div>
    <div class="content">
      上海二三四五融资租赁有限公司成立于2016年1月，是一家从事租赁和商业服务的公司，主要营业范围为融资租赁业务、租赁业务、向国内外购买租赁财产、租赁财产的残值处理及维修、租赁交易咨询及担保等，除此之外，还从事与主营业务有关的商业保理业务
    </div>
    <div class="bottom">
      如有任何问题，请致电2345车贷王客服：021-61046012/61046050
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {

    }
  },
  created () {
  },
  methods: {

  }
}
</script>
<style lang="scss" scoped>
.title {
  padding: 30px;
  font-size: 30px;
  font-weight: 800;
}
.bottom {
  position: fixed;
  bottom: 0px;
  width: 100%;
  text-align: center;
  color: #666;
}
.content {
  padding: 30px;
  line-height: 66px;
  text-indent: 2em;
}
</style>
