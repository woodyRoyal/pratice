<template>
  <div>
    <div class="title">
      还款计划
    </div>
    <div class="qa-list">
      <p>剩余{{count}}期未还</p>
    </div>
    <div class="line"></div>
    <div v-for="(item,index) in list"
         :key="index">
      <div :class="{'qa-list':true,'bg-red':item.status === 3}">
        <div class="first-list">
          {{item.repayDate}}

          <span class="dateClass"> ￥{{item.amount}}</span>
        </div>
        <!-- <span>
        ￥2099
      </span> -->
        <span class="text-info">第{{item.period}}期：
          <span :class="{textRed:item.status === 3}">
            {{planMap[`${item.status}`]}}
          </span>
        </span>
      </div>
      <div class="line"></div>
    </div>
    <div class="bottom">
      如有任何问题，请致电2345车贷王客服：4008013610
    </div>
  </div>
</template>
<script>
import api from '../../api/plan.js'
import { planMap } from './config.js'
// import { Toast } from 'we-vue'
import { getCookie } from '../../utils/cookie.js'
export default {
  data () {
    return {
      planMap: planMap,
      // 返回的原始数据保存一份
      obj: {

      },
      applyId: null,
      // 剩余多少起未还
      count: 0,
      list: [
        // {
        //   period: '123123',
        //   repayDate: '123123',
        //   amount: '4354365',
        //   status: 3
        // },
        // {
        //   period: '123123',
        //   repayDate: '123123',
        //   amount: '4354365',
        //   status: 3
        // },
        // {
        //   period: '123123',
        //   repayDate: '123123',
        //   amount: '4354365',
        //   status: 2
        // },
        // {
        //   period: '123123',
        //   repayDate: '123123',
        //   amount: '4354365',
        //   status: 3
        // },

        // {
        //   period: '123123',
        //   repayDate: '123123',
        //   amount: '4354365',
        //   status: 3
        // },
        // {
        //   period: '123123',
        //   repayDate: '123123',
        //   amount: '4354365',
        //   status: 1
        // },
        // {
        //   period: '123123',
        //   repayDate: '123123',
        //   amount: '4354365',
        //   status: 1
        // },
        // {
        //   period: '123123',
        //   repayDate: '123123',
        //   amount: '4354365',
        //   status: 1
        // },
      ]
    }
  },
  created () {
    this.applyId = this.$route.query.applyId || null
    if (!this.applyId) {
      this.$router.push({ name: '计划列表' })
    }
    this.fetchData()
  },
  methods: {
    async fetchData () {
      let data = {
        token: getCookie('wxUserInfo') || localStorage.getItem('token') || null,
        applyId: this.applyId
      }
      const res = await api.getRepayPlanByApplyId(data)
      this.obj = res.body
      let overdueLength = 0, unclearLength = 0;
      if (res.body.overdue) overdueLength = res.body.overdue.length
      if (res.body.unclear) unclearLength = res.body.unclear.length
      this.count = overdueLength + unclearLength
      let obj = {
        clear: res.body.clear || [],
        overdue: res.body.overdue || [],
        unclear: res.body.unclear || [],
      }
      obj.overdue.forEach(element => {
        element.status = 3
      })
      obj.clear.forEach(element => {
        element.status = 1
      })
      obj.unclear.forEach(element => {
        element.status = 2
      })
      this.list = [...obj.overdue, ...obj.unclear, ...obj.clear]
    }
  }
}
</script>
<style lang="scss" scoped>
.textRed {
  color: red;
}
.bg-red {
  background-color: rgb(255, 225, 225);
}
.title {
  padding: 30px;
  font-size: 26px;
  font-weight: 600;
}
.bottom {
  position: fixed;
  bottom: 30px;
  width: 100%;
  text-align: center;
  color: #666;
}
.text-info {
  color: #a2b6cb;
}
.qa-list {
  padding: 0px 20px;
  .dateClass {
    float: right;
  }
  .first-list {
    padding: 10px 0;
  }
}
.line {
  border: 1px solid rgb(207, 207, 207);
}
</style>
