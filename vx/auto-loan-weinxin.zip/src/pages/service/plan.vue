<template>
  <div>
    <div class="title">
      还款计划
    </div>
    <div class="qa-list">
      <p>剩余12期未还</p>
      <div class="line"></div>
    </div>
    <div class="qa-list"
         v-for="(item,index) in list"
         :key="index">
      <p>2019年2月18日</p>
      <p class="text-info">第一期：已还清</p>
      <div class="line"></div>
    </div>
    <div class="bottom">
      如有任何问题，请致电2345车贷王客服：021-61046012/61046050
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      list: [
        {

        },
        {},
        {},
        {},
      ]
    }
  },
  created () {
  },
  methods: {

  }
}
</script>
<style lang="scss" scoped>
.title {
  padding: 30px;
  font-size: 30px;
  font-weight: 800;
}
.bottom {
  position: fixed;
  bottom: 0px;
  width: 100%;
  text-align: center;
  color: #666;
}
.text-info {
  color: rgb(207, 207, 207);
}
.qa-list {
  padding: 0 30px;
  p {
    padding: 10px 0;
  }
  .line {
    border: 1px solid rgb(207, 207, 207);
  }
}
</style>
