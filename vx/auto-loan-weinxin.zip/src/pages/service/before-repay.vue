<template>
  <div>
    <div class="header-box">
      <span>申请编号：{{header}}</span>
    </div>
    <div v-if="type !==3">
      <div class="title-box"
           v-if="type !== 3">
        <p>{{title}}</p>
      </div>
      <div class="money">
        <span>￥</span>3136.23
      </div>
      <!-- <div class="info-text">
      <span>到期还款日： 2019年1月28日（
        <span :class="{active:type === 3}">还剩20天</span>）</span>
    </div> -->
      <div class="info-text"
           v-if="type === 2">
        您已经逾期（
        <span style="color:red">4</span>）天
      </div>
      <div class="btn-main">
        <wv-button type="primary"
                   @click="payClick">立即还款</wv-button>
      </div>
    </div>
    <div v-else
         class="simple-box">
      <span>您的本申请单已全部结清，感谢您的关注</span>
    </div>
    <wv-actionsheet type="ios"
                    :actions="actions"
                    cancel-text="取消"
                    v-model="sheetVisible" />
  </div>
</template>
<script>
const actions = [
  {
    name: '微信支付',
    method: () => {
      // console.log('menu1 clicked')
    }
  },
  {
    name: '对公还款',
    method: () => {
      // console.log('menu2 clicked')
    }
  }
]
export default {

  data () {
    return {
      type: 3,
      actions: actions,
      header: 10005432,
      title: '全部应还',
      // 当期已还清，2月18日应还金额
      // 贷款已经逾期，请及时还款
      sheetVisible: false
    }
  },
  created () {
  },
  methods: {
    payClick () {
      this.sheetVisible = true
    }
  }
}
</script>
<style lang="scss" scoped>
.active {
  color: red;
}
.header-box {
  padding: 30px;
}
.title-box {
  padding: 50px;
  text-align: center;
  font-size: 25px;
  font-weight: 600;
}
.money {
  text-align: center;
  font-size: 60px;
  font-weight: 900;
}
.info-text {
  text-align: center;
  padding: 30px;
}
.btn-main {
  margin-top: 30px;
  padding: 20px 100px;
}
.simple-box {
  text-align: center;
  padding-top: 150px;
  color: #666;
}
</style>
