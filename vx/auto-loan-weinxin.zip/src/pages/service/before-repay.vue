<template>
  <div>
    <div class="header-box">
      <span>申请编号：{{ '100' + applyId}}</span>
    </div>
    <div v-if="detailObj.applyId">
      <div class="title-box">
        <p>{{title}}</p>
      </div>
      <div class="money">
        <span>￥</span>{{detailObj.amount}}
      </div>
      <div class="info-text"
           v-if="detailObj.status === 3">
        您已经逾期
        <span style="color:red">（{{detailObj.overdueDays}}）</span>天
      </div>
      <div class="btn-main">
        <wv-button type="primary"
                   :disabled="this.detailObj.status === 6"
                   @click="payClick">{{btnText}}</wv-button>
      </div>
      <div class="info-text"
           style="color:#ccc">
        该款项由广州二三四五互联网小额贷款有限公司代为收取
      </div>
    </div>
    <div v-else
         class="simple-box">
      <span>您有入账中的还款，暂不能申请结清</span>
    </div>
    <wv-actionsheet type="ios"
                    :actions="actions"
                    cancel-text="取消"
                    v-model="sheetVisible" />
  </div>
</template>
<script>
import api from '../../api/before.js'
import { statusMap } from './config.js'
import { getCookie } from '../../utils/cookie.js'
import WXapi from '../../api/wxPay.js'
import wx from 'weixin-js-sdk'
import { Toast } from 'we-vue'
export default {

  data () {
    return {
      type: 1,
      applyId: null,
      statusMap: statusMap,
      actions: [
        {
          name: '微信支付',
          method: () => {
            this.wxPayStart()
          }
        },
        {
          name: '对公还款',
          method: () => {
            this.toRepay()
          }
        }
      ],
      detailObj: {
        //申请编号
        applyId: null,
        //显示用申请编号
        displayApplyId: '',
        //
        status: null,
        //期数，多期以逗号分隔
        periods: null,
        //应还总金额，精确到分，不带货币符号
        amount: null,
        //到期还款日，格式yyyy年yy月dd日
        repayDate: ``,
        //逾期天数，状态为3时才返回
        overdueDays: null,
        //剩余天数，状态为1时才返回
        remainDays: null,
      },
      title: '全部应还',
      // 当期已还清，2月18日应还金额
      // 贷款已经逾期，请及时还款
      sheetVisible: false
    }
  },
  created () {
    this.applyId = this.$route.query.applyId || null
    if (!this.applyId) {
      this.$router.push({ name: '提前结清列表' })
    }
    let url = window.location.href;
    if (!url.match(/\?#/)) {
      window.location.href = `http://cycyh.wang/auto-wx-web/?#/home/beforeRepay?applyId=${this.applyId}`
    }
    this.fetchData()
  },
  mounted () {
    this.config()
  },
  computed: {
    btnText () {
      if ([5].includes(this.detailObj.status)) {
        return '还款中，点击刷新结果'
      } else if ([6].includes(this.detailObj.status)) {
        return '还款入账中'
      } else {
        return '立即还款'
      }
    }
  },
  methods: {
    async config () {
      // window.alert('调用getConfig 注入jssdk')
      let data = {
        token: getCookie('wxUserInfo') || localStorage.getItem('token') || null,
        url: window.location.href
      }
      let res = await WXapi.fetchConfig(data)
      this.wxConfig = res.body
      window.console.log('真正传给微信的config',
        {
          debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
          appId: process.env.VUE_APP_WECHAT_APPID, // 必填，公众号的唯一标识
          timestamp: res.body.timestamp, // 必填，生成签名的时间戳
          nonceStr: res.body.nonceStr, // 必填，生成签名的随机串
          signature: res.body.signature,// 必填，签名
          jsApiList: ['chooseWXPay',] // 必填，需要使用的JS接口列表
        }
      )
      wx.config({
        debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
        appId: process.env.VUE_APP_WECHAT_APPID, // 必填，公众号的唯一标识
        timestamp: res.body.timestamp, // 必填，生成签名的时间戳
        nonceStr: res.body.nonceStr, // 必填，生成签名的随机串
        signature: res.body.signature,// 必填，签名
        jsApiList: ['chooseWXPay'] // 必填，需要使用的JS接口列表
      });
    },
    async wxPayStart () {
      try {
        let data = {
          token: getCookie('wxUserInfo') || localStorage.getItem('token') || null,
          applyId: this.applyId,
          periods: this.detailObj.periods,
          amount: this.detailObj.amount
        }
        let res = await WXapi.repayByApplyIdadvance(data)
        this.wxParam = res.body.wxParam
      } catch (error) {
        this.fetchData()
      }

      // window.alert('调用接口下单成功，开始唤起微信支付，参数打印在vconsole')
      window.console.log('传给微信', {
        timestamp: this.wxParam.timeStamp, // 支付签名时间戳，注意微信jssdk中的所有使用timestamp字段均为小写。但最新版的支付后台生成签名使用的timeStamp字段名需大写其中的S字符
        nonceStr: this.wxParam.nonceStr, // 支付签名随机串，不长于 32 位
        package: this.wxParam.pkg, // 统一支付接口返回的prepay_id参数值，提交格式如：prepay_id=\*\*\*）
        signType: this.wxParam.signType, // 签名方式，默认为'SHA1'，使用新版支付需传入'MD5'
        paySign: this.wxParam.paySign,// 支付签名
      })
      wx.chooseWXPay({
        timestamp: this.wxParam.timeStamp, // 支付签名时间戳，注意微信jssdk中的所有使用timestamp字段均为小写。但最新版的支付后台生成签名使用的timeStamp字段名需大写其中的S字符
        nonceStr: this.wxParam.nonceStr, // 支付签名随机串，不长于 32 位
        package: this.wxParam.pkg, // 统一支付接口返回的prepay_id参数值，提交格式如：prepay_id=\*\*\*）
        signType: this.wxParam.signType, // 签名方式，默认为'SHA1'，使用新版支付需传入'MD5'
        paySign: this.wxParam.paySign,// 支付签名
        success: function (res) {
          window.console.log(res)
          Toast.success('支付成功')
          this.fetchData()
          this.$router.push({ name: '提前结清成功', query: { applyId: this.applyId, amount: this.detailObj.amount } })
        },
        cancel: function (res) {
          window.console.log(res)
          Toast.success('取消支付')
          this.fetchData()
        },
        error: function (res) {
          window.console.log(res)
          Toast.fail('支付失败，请重新支付')
          this.fetchData()
        },
      });
    },
    toRepay () {
      this.$router.push({ name: '对公还款-提前结清', query: { applyId: this.applyId } })
    },
    payClick () {
      if ([5, 6].includes(this.detailObj.status)) {
        return this.fetchData('updata')
      }
      this.sheetVisible = true
    },
    async fetchData (val) {
      let data = {
        token: getCookie('wxUserInfo') || localStorage.getItem('token') || null,
        applyId: this.$route.query.applyId
      }
      const res = await api.getByApplyId(data)
      if (val && [5, 6].includes(this.detailObj.status)) {
        Toast.text('暂未获取到结果，请稍后再试')
      }
      this.detailObj = res.body
    }
  }
}
</script>
<style lang="scss" scoped>
.active {
  color: red;
}
.header-box {
  padding: 30px;
}
.title-box {
  padding: 50px;
  text-align: center;
  font-size: 25px;
  font-weight: 500;
}
.money {
  text-align: center;
  font-size: 50px;
  font-weight: 600;
}
.info-text {
  text-align: center;
  padding: 30px;
}
.btn-main {
  margin-top: 30px;
  padding: 20px 100px;
}
.simple-box {
  text-align: center;
  padding-top: 150px;
  color: #666;
}
</style>
