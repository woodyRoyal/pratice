<template>

  <div style="background-color:white">
    <div class="header-box">
      <span>申请编号：{{'100' + applyId}}</span>
    </div>
    <div class="title-box">
      <span>还款成功 <img src="../../../assets/success.png"
             class="back-icon imgSuccess"
             alt=""></span>
    </div>
    <div class="money">
      <span>￥</span>{{amount}}
    </div>
    <div class="btn-main">
      <wv-button type="primary"
                 :disabled="detailObj.status === 1"
                 @click="payClick">我知道了</wv-button>
    </div>
    <div class="bottom">
      如有任何问题，请致电2345车贷王客服：4008013610
    </div>
  </div>
</template>
<script>

export default {
  data () {
    return {
      applyId: '0000',
      amount: '0000',
      detailObj: {
        //申请编号
        applyId: null,
        //显示用申请编号
        displayApplyId: '65464',
        //
        status: '',
        //期数，多期以逗号分隔
        periods: null,
        //应还总金额，精确到分，不带货币符号
        amount: '1200',
        //到期还款日，格式yyyy年yy月dd日
        repayDate: ``,
        //逾期天数，状态为3时才返回
        overdueDays: '',
        //剩余天数，状态为1时才返回
        remainDays: '',
      }
    }
  },
  created () {
    this.applyId = this.$route.query.applyId || null
    this.amount = this.$route.query.amount || null
  },
  mounted () {
  },
  computed: {

  },
  methods: {
    payClick () {
      window.location.href = process.env.VUE_APP_PAY_URL + `/home/beforeRepay?applyId=${this.applyId}`
    }
  }
}
</script>
<style lang="scss" scoped>
.active {
  color: red;
}
.header-box {
  padding: 30px;
}
.title-box {
  padding: 50px;
  text-align: center;
  font-size: 0px;

  span {
    position: relative;
    font-size: 18px;
    .back-icon {
      width: 30px;
    }
    .imgSuccess {
      position: absolute;
      left: -100px;
    }
  }
}
.money {
  text-align: center;
  font-size: 20px;
  font-weight: 600;
}
.info-text {
  text-align: center;
  color: rgb(204, 204, 204);
  padding: 30px;
}
.btn-main {
  padding: 20px 100px;
  margin-top: 150px;
}
.bottom {
  position: fixed;
  bottom: 30px;
  width: 100%;
  text-align: center;
  color: #666;
}
</style>
