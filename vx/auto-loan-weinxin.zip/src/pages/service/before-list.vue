<template>
  <div>
    <div class="header-box">
      <span>请选择需要提前结清的申请单</span>
    </div>
    <div class="table-box">
      <div class="table-header">
        <span class="header-col"
              v-for="item in table"
              :key="item">
          {{item}}
        </span>
      </div>
      <div class="table-body">
        <div class="body-row"
             v-for="(item,index) in tableData"
             :key="index">
          <span class="body-col applyBox"
                @click="pushSelfHelp(item)">
            {{item.displayApplyId}}
          </span>
          <span class="body-col">
            {{item.displayApplyId}}
          </span>
          <span class="body-col">
            {{item.dueDate}}
          </span>
          <span class="body-col">
            {{item.status}}
          </span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      table: ['申请编号', '客户姓名', '放款日期', '状态'],
      tableData: [{
        applyId: '123213',
        displayApplyId: '687687687',
        status: 3,
        dueDate: '2017-1-1',
        overdueDays: 12,
        amount: 3125,
      },
      {
        applyId: '123213',
        displayApplyId: '687687687',
        status: 3,
        dueDate: '2017-1-1',
        overdueDays: 12,
        amount: 3125,
      }
      ],
    }
  },
  created () {
  },
  methods: {
    pushSelfHelp (item) {
      this.$router.push({ name: '自助还款', query: { displayApplyId: item.displayApplyId } })
    }
  }
}
</script>
<style lang="scss" scoped>
.header-box {
  padding: 30px;
}
.table-box {
  padding: 30px;
}
.header-col {
  display: inline-block;
  width: 25%;
  color: #666;
  padding: 10px;
}
.body-col {
  display: inline-block;
  padding: 10px;
  width: 25%;
}
.applyBox {
  color: #409eff;
}
</style>
