<template>
  <div>
    <div class="header-box">
      <span>请选择需要提前結清的申请单</span>
    </div>
    <div class="table-box">
      <div class="table-header">
        <span class="header-col-type1">
          申请编号
        </span>
        <span class="header-col-type1">
          客户姓名
        </span>
        <span class="header-col-type2">
          放款日期
        </span>
        <span class="header-col-type1">
          状态
        </span>
      </div>
      <div class="table-body">
        <div class="body-row"
             v-for="(item,index) in tableData"
             :key="index">
          <span class="body-col-type1 applyBox"
                @click="pushSelfHelp(item)">
            {{item.displayApplyId}}
          </span>
          <span class="body-col-type1">
            {{item.name}}
          </span>
          <span class="body-col-type2">
            {{item.loanDate}}
          </span>
          <span class="body-col-type1"
                :class="{textRed:item.status === 3}">
            {{statusMap[`${item.status}`]}}
          </span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import api from '../../api/before.js'
import { statusMap } from './config.js'
import { getCookie } from '../../utils/cookie.js'
export default {
  data () {
    return {
      statusMap: statusMap,
      table: ['申请编号', '客户姓名', '放款日期', '状态'],
      tableData: [
      ],
    }
  },
  created () {
    this.fetchData()
  },
  methods: {
    pushSelfHelp (item) {
      window.location.href = process.env.VUE_APP_PAY_URL + `/home/beforeRepay?applyId=${item.applyId}`
      // this.$router.push({ name: '提前结清', query: { applyId: item.applyId } })
    },
    async fetchData () {
      let data = {
        token: getCookie('wxUserInfo') || localStorage.getItem('token') || null
      }
      const res = await api.advance(data)
      if (res.body && res.body.length === 1) {
        this.$router.push({ name: '提前结清', query: { applyId: res.body[0].applyId } })
        // this.tableData = res.body
      } else {
        this.tableData = res.body
      }
    },
  }
}
</script>
<style lang="scss" scoped>
.header-box {
  padding: 30px;
}
.table-box {
  padding: 30px;
}
.header-col-type1 {
  display: inline-block;
  width: 24%;
  color: #666;
  padding: 10px;
}
.header-col-type2 {
  display: inline-block;
  width: 28%;
  color: #666;
  padding: 10px;
}
.body-col-type1 {
  display: inline-block;
  padding: 10px;
  width: 24%;
}
.body-col-type2 {
  display: inline-block;
  padding: 10px;
  width: 28%;
}
.applyBox {
  color: #409eff;
}
.textRed {
  color: red;
}
</style>
