<template>
  <div>
    <div class="header-box">
      <span>请选择需要还款的申请单</span>
    </div>
    <div class="table-box">
      <div class="table-header">
        <span class="header-col"
              v-for="item in table"
              :key="item">
          {{item}}
        </span>
      </div>
      <div class="table-body">
        <div class="body-row"
             v-for="(item,index) in tableData"
             :key="index">
          <span class="body-col applyBox"
                @click="pushSelfHelp(item)">
            {{item.displayApplyId}}
          </span>
          <span class="body-col">
            {{item.name}}
          </span>
          <span class="body-col">
            {{item.loanDate}}
          </span>
          <span class="body-col"
                :class="{textRed:item.status === 3}">
            {{statusMap[`${item.status}`]}}
          </span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import api from '../../api/index.js'
import { statusMap } from './config.js'
export default {
  data () {
    return {
      statusMap: statusMap,
      table: ['申请编号', '客户姓名', '放款日期', '状态'],
      tableData: [{
        applyId: '123213',
        displayApplyId: '687687687',
        name: '阙文琦',
        status: 1,
        loanDate: '2017-1-1',
      },
      {
        applyId: '123213',
        displayApplyId: '687687687',
        name: '刁灰',
        status: 3,
        loanDate: '2017-1-1',
      },
      ],
    }
  },
  created () {
    window.console.log(api)
  },
  methods: {
    pushSelfHelp (item) {
      this.$router.push({ name: '自助还款', query: { applyId: item.applyId } })
    },
    async fetchData () {
      let data = {
        token: '54644'
      }
      const res = await api.getRepayApplyIds(data)
      if (res.body && res.body.length === 1) {
        this.$router.push({ name: '自助还款', query: { applyId: res.body[0].applyId } })
      } else {
        this.tableData = res.body
      }
    },
  }
}
</script>
<style lang="scss" scoped>
.header-box {
  padding: 30px;
}
.table-box {
  padding: 30px;
}
.header-col {
  display: inline-block;
  width: 25%;
  color: #666;
  padding: 10px;
}
.body-col {
  display: inline-block;
  padding: 10px;
  width: 25%;
}
.applyBox {
  color: #409eff;
}
.textRed {
  color: red;
}
</style>
