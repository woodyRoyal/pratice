export const statusMap = {
  1: '正常',
  3: '已逾期',
  4: '已到期',
  5: '还款中',
  6: '还款入账中',
}