<template>
  <div>
    <div class="header-box">
      <span>申请编号：{{detailObj.displayApplyId}}</span>
    </div>
    <div class="title-box"
         v-if="detailObj.status === 1">
      <p> {{`当期已还清，${detailObj.repayDate}应还金额`}}</p>
    </div>

    <div class="title-box"
         v-else-if="detailObj.status === 3">
      <p style="color:red">贷款已经逾期，请及时还款</p>
    </div>
    <div class="title-box"
         v-else>
      <p>当期应还金额</p>
    </div>
    <div class="money">
      <span>￥</span>{{detailObj.amount}}
    </div>
    <div class="info-text">
      <span>到期还款日： {{detailObj.repayDate}}
        <span :class="{active:detailObj.status === 1}"
              v-if="detailObj.status === 1">{{`（还剩${detailObj.remainDays}天）`}}</span>
        <span :class="{active:detailObj.status === 3}"
              v-if="detailObj.status === 3">{{`（已逾期${detailObj.overdueDays}天）`}}</span>
      </span>
    </div>
    <div class="info-text"
         style="color:#ccc"
         v-if="detailObj.status !== 1">
      逾期将上报征信，请珍惜信用，按时还款
    </div>
    <div class="btn-main">
      <wv-button type="primary"
                 :disabled="detailObj.status === 1 || detailObj.status === 6"
                 @click="payClick">{{btnText}}</wv-button>
    </div>

    <div class="info-text"
         style="color:#ccc">
      该款项由广州二三四五互联网小额贷款有限公司代为收取
    </div>
    <wv-actionsheet type="ios"
                    :actions="actions"
                    cancel-text="取消"
                    v-model="sheetVisible" />
  </div>
</template>
<script>
import api from '../../api/index.js'
import WXapi from '../../api/wxPay.js'
import wx from 'weixin-js-sdk'
import { statusMap } from './config.js'
import { getCookie } from '../../utils/cookie.js'
import { Toast } from 'we-vue'
// const actions = [
//   {
//     name: '微信支付',
//     method: () => {
//     }
//   },
//   {
//     name: '对公还款',
//     method: () => {
//     }
//   }
// ]
export default {
  data () {
    return {
      // 状态
      statusMap: statusMap,
      applyId: null,
      type: 3,
      actions: [
        {
          name: '微信支付',
          method: () => {
            this.wxPayStart()
          }
        },
        {
          name: '对公还款',
          method: () => {
            this.toRepay()
          }
        }
      ],
      header: 10005432,
      title: '当期应还金额',
      wxParam: {},
      wxConfig: {},
      detailObj: {
        //申请编号
        applyId: null,
        //显示用申请编号
        displayApplyId: '',
        //
        status: '',
        //期数，多期以逗号分隔
        periods: null,
        //应还总金额，精确到分，不带货币符号
        amount: '',
        //到期还款日，格式yyyy年yy月dd日
        repayDate: ``,
        //逾期天数，状态为3时才返回
        overdueDays: '',
        //剩余天数，状态为1时才返回
        remainDays: '',
      },
      // 当期已还清，2月18日应还金额
      // 贷款已经逾期，请及时还款
      sheetVisible: false
    }
  },
  created () {
    this.applyId = this.$route.query.applyId || null
    if (!this.applyId) {
      this.$router.push({ name: '申请单' })
    }
    // let url = window.location.href;
    // if (!url.match(/\?#/)) {
    //   window.location.href = `http://cycyh.wang/auto-wx-web/?#/home/selfHelp?applyId=${this.applyId}`
    // }
    this.fetchData()
  },
  mounted () {
    this.config()
  },
  computed: {
    btnText () {
      if ([5].includes(this.detailObj.status)) {
        return '还款中，点击刷新结果'
      } else if ([6].includes(this.detailObj.status)) {
        return '还款入账中'
      } else {
        return '立即还款'
      }
    }
  },
  methods: {
    async config () {
      // window.alert('调用getConfig 注入jssdk')
      let data = {
        token: getCookie('wxUserInfo') || localStorage.getItem('token') || null,
        url: window.location.href
      }
      let res = await WXapi.fetchConfig(data)
      this.wxConfig = res.body
      wx.config({
        debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
        appId: process.env.VUE_APP_WECHAT_APPID, // 必填，公众号的唯一标识
        timestamp: res.body.timestamp, // 必填，生成签名的时间戳
        nonceStr: res.body.nonceStr, // 必填，生成签名的随机串
        signature: res.body.signature,// 必填，签名
        jsApiList: ['chooseWXPay'] // 必填，需要使用的JS接口列表
      });
    },
    async wxPayStart () {
      let data = {
        token: getCookie('wxUserInfo') || localStorage.getItem('token') || null,
        applyId: this.applyId,
        periods: this.detailObj.periods,
        amount: this.detailObj.amount
      }
      try {
        let res = await WXapi.repayByApplyId(data)
        this.wxParam = res.body.wxParam
      } catch (error) {
        this.fetchData()
      }

      // window.alert('调用接口下单成功，开始唤起微信支付，参数打印在vconsole')
      wx.chooseWXPay({
        timestamp: this.wxParam.timeStamp, // 支付签名时间戳，注意微信jssdk中的所有使用timestamp字段均为小写。但最新版的支付后台生成签名使用的timeStamp字段名需大写其中的S字符
        nonceStr: this.wxParam.nonceStr, // 支付签名随机串，不长于 32 位
        package: this.wxParam.pkg, // 统一支付接口返回的prepay_id参数值，提交格式如：prepay_id=\*\*\*）
        signType: this.wxParam.signType, // 签名方式，默认为'SHA1'，使用新版支付需传入'MD5'
        paySign: this.wxParam.paySign,// 支付签名
        success: function (res) {
          window.console.log(res)
          Toast.success('支付成功')
          this.fetchData()
          this.$router.push({ name: '自助还款成功', query: { applyId: this.applyId, amount: this.detailObj.amount } })
        },
        cancel: function (res) {
          window.console.log(res)
          Toast.success('取消支付')
          this.fetchData()
        },
        error: function (res) {
          window.console.log(res)
          Toast.fail('支付失败，请重新支付')
          this.fetchData()
        },
      });
    },
    toRepay () {
      this.$router.push({ name: '对公还款', query: { applyId: this.applyId } })
    },
    payClick () {
      if ([5, 6].includes(this.detailObj.status)) {
        return this.fetchData('1')
      }
      this.sheetVisible = true
    },
    async fetchData (val) {
      let data = {
        token: getCookie('wxUserInfo') || localStorage.getItem('token') || null,
        applyId: this.applyId
      }
      const res = await api.getByApplyId(data)
      window.console.log(res)
      this.detailObj = res.body
      if (val && [5, 6].includes(this.detailObj.status)) {
        Toast.text('暂未获取到结果，请稍后再试')
      }
      if (res.respCode === 'INVALID_USER') {
        this.$router.push({ name: '绑定账号' })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.active {
  color: red;
}
.header-box {
  padding: 30px;
}
.title-box {
  padding: 50px;
  text-align: center;
  font-size: 25px;
  font-weight: 500;
}
.money {
  text-align: center;
  font-size: 50px;
  font-weight: 600;
}
.info-text {
  text-align: center;
  color: rgb(204, 204, 204);
  padding: 30px;
}
.btn-main {
  padding: 20px 100px;
}
</style>
