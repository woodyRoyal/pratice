<template>
  <div>
    <div class="header-box">
      <span>申请编号：{{detailObj.displayApplyId}}</span>
    </div>
    <div class="title-box"
         v-if="detailObj.status === 1">
      <p> {{`当期已还清，${detailObj.repayDate}应还金额`}}</p>
    </div>

    <div class="title-box"
         v-else-if="detailObj.status === 3">
      <p style="color:red">贷款已经逾期，请及时还款</p>
    </div>
    <div class="title-box"
         v-else>
      <p>当期应还金额</p>
    </div>
    <div class="money">
      <span>￥</span>{{detailObj.amount}}
    </div>
    <div class="info-text">
      <span>到期还款日： {{detailObj.repayDate}}
        <span :class="{active:detailObj.status === 1}"
              v-if="detailObj.status === 1">{{`（还剩${detailObj.remainDays}天）`}}</span>
        <span :class="{active:detailObj.status === 3}"
              v-if="detailObj.status === 3">{{`（已逾期${detailObj.overdueDays}天）`}}</span>
      </span>

    </div>
    <div class="btn-main">
      <wv-button type="primary"
                 :disabled="detailObj.status === 1"
                 @click="payClick">{{btnText}}</wv-button>
    </div>
    <div class="info-text"
         style="color:#ccc"
         v-if="detailObj.status !== 1">
      逾期将上报征信，请珍惜信用，按时还款
    </div>
    <wv-actionsheet type="ios"
                    :actions="actions"
                    cancel-text="取消"
                    v-model="sheetVisible" />
  </div>
</template>
<script>
import api from '../../api/index.js'
import { statusMap } from './config.js'
const actions = [
  {
    name: '微信支付',
    method: () => {
      // console.log('menu1 clicked')
    }
  },
  {
    name: '对公还款',
    method: () => {
      // console.log('menu2 clicked')
    }
  }
]
export default {
  data () {
    return {
      // 状态
      statusMap: statusMap,
      applyId: null,
      type: 3,
      actions: actions,
      header: 10005432,
      title: '当期应还金额',
      detailObj: {
        //申请编号
        applyId: null,
        //显示用申请编号
        displayApplyId: '5465464',
        //
        status: 1,
        //期数，多期以逗号分隔
        periods: null,
        //应还总金额，精确到分，不带货币符号
        amount: 3344,
        //到期还款日，格式yyyy年yy月dd日
        repayDate: `2019-10-10`,
        //逾期天数，状态为3时才返回
        overdueDays: 3,
        //剩余天数，状态为1时才返回
        remainDays: 20,
      },
      // 当期已还清，2月18日应还金额
      // 贷款已经逾期，请及时还款
      sheetVisible: false
    }
  },
  created () {
    this.applyId = this.$route.applyId || null
    window.console.log(api)

  },
  computed: {
    btnText () {
      if ([5, 6].includes(this.detailObj.status)) {
        return '还款中，点击刷新结果'
      } else {
        return '立即还款'
      }
    }
  },
  methods: {
    payClick () {
      this.sheetVisible = true
    },
    async fetchData () {
      const res = await api.getByApplyId()
      this.detailObj = res.body
    }
  }
}
</script>
<style lang="scss" scoped>
.active {
  color: red;
}
.header-box {
  padding: 30px;
}
.title-box {
  padding: 50px;
  text-align: center;
  font-size: 25px;
  font-weight: 600;
}
.money {
  text-align: center;
  font-size: 60px;
  font-weight: 900;
}
.info-text {
  text-align: center;
  color: rgb(204, 204, 204);
  padding: 30px;
}
.btn-main {
  padding: 20px 100px;
}
</style>
