<template>
  <div class="ignore">
    <!-- <wv-header title="2345车贷王"
               style="height:40px;font-size:18px">
      <div class="btn-back"
           slot="left">
        <i class="iconfont icon-back"></i>
      </div>
    </wv-header> -->
    <!-- <img src="../assets/back.png"
           @click="goBack()"
           class="back-icon"
           alt="返回"> -->
    <div class="header_ignore">
      2345车贷王
    </div>
    <div style="margin-top:40px;">
      <router-view/>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {

    }
  },
  created () {
  },
  methods: {
    goBack () {
      this.$router.back(-1)
    }
  }
}
</script>
<style lang="scss" scoped>
.ignore {
  height: calc(100% - 60px);
  overflow-y: scroll;
}
.header_ignore {
  position: fixed;
  z-index: 500;
  left: 0;
  top: 0;
  box-sizing: border-box;
  width: 100%;
  height: 40px;
  line-height: 1;
  padding: 0 10px;
  margin: 0;
  color: #fff;
  white-space: nowrap;
  background-color: rgb(33, 41, 44);
  text-align: center;
  line-height: 40px;
  font-size: 16px;
}
.back-icon {
  position: fixed;
  width: 30px;
  height: 30px;
  left: 5px;
  top: 5px;
}
</style>
