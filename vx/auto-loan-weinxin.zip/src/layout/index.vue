<template>
  <div class="ignore">
    <!-- <wv-header title="2345车贷王"
               style="height:40px;font-size:18px">
      <div class="btn-back"
           slot="left">
        <i class="iconfont icon-back"></i>
      </div>
    </wv-header> -->
    <div class="header_ignore">
      2345车贷王
    </div>
    <div style="margin-top:40px;">
      <router-view/>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {

    }
  },
  created () {
  },
  methods: {

  }
}
</script>
<style lang="scss" scoped>
.ignore {
  height: calc(100% - 44px);
  overflow-y: scroll;
}
.header_ignore {
  position: fixed;
  z-index: 500;
  left: 0;
  top: 0;
  box-sizing: border-box;
  width: 100%;
  height: 40px;
  line-height: 1;
  padding: 0 10px;
  margin: 0;
  color: #fff;
  white-space: nowrap;
  background-color: rgb(33, 41, 44);
  text-align: center;
  line-height: 40px;
  font-size: 16px;
}
</style>
