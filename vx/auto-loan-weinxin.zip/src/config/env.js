
const ENV = process.env.NODE_ENV
/** 导出环境变量
 * 开发：development
 * 测试：uat
 * 线上：production
*/
export default ENV
