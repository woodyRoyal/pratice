import env from './env'

/** 引入环境变量
 * 开发：development
 * 测试：uat
 * 线上：production
 */

// 服务目录的路径 TODO 根据实际修改
let servicePath = 'autoloan-wx'
let origin = 'http://t1-managerdaikuan.2345.com'

const ApiHost = {
  development: {
    basePath: `${origin}/${servicePath}` // 服务所在路径，开发环境拼接了/auto-loan-api，此设置在vue.config.js里的proxy中，仅仅为识别用，会替换为''
    // basePath: servicePath // 服务所在路径，开发环境拼接了/auto-loan-api，此设置在vue.config.js里的proxy中，仅仅为识别用，会替换为''
  },
  uat: {
    basePath: servicePath // 服务所在路径
  },
  production: {
    basePath: servicePath // 服务所在路径
  }
}

export default ApiHost[env]
