import env from './env'

/** 引入环境变量
 * 开发：development
 * 测试：uat
 * 线上：production
 */

// 服务目录的路径 TODO 根据实际修改
// let servicePath = 'autoloan-wx'
const ApiHost = {
  development: {
    basePath: window.location.origin + '/autoloan-wx' // 服务所在路径，开发环境拼接了/auto-loan-api，此设置在vue.config.js里的proxy中，仅仅为识别用，会替换为''
    // basePath: servicePath // 服务所在路径，开发环境拼接了/auto-loan-api，此设置在vue.config.js里的proxy中，仅仅为识别用，会替换为''
  },
  production: {
    basePath: 'http://cycyh.wang/autoloan-wx' // 服务所在路径
  },
  uat: {
    basePath: 'http://cztxyh.cn/autoloan-wx' // 服务所在路径
  }
}

export default ApiHost[env]
