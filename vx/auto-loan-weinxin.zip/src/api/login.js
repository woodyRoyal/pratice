import request from '../utils/request'
export function loginByCode (data) {
  return request({
    data,
    url: '/user/getToken',
    method: 'get'
  })
}
// 微信用户获取token，即使未绑定情况下也会返回token信息，以替代后续操作过程中的code参数
export default {
  // 获取发送短信验证码所需的图形验证码
  getImage: data => {
    return request({
      data,
      url: '/user/getImage',
      method: 'get'
    })
  },
  // 发送短信验证码
  getCode: data => {
    return request({
      data,
      url: '/user/getCode',
      method: 'get'
    })
  },
  // 微信账号绑定车贷用户
  bind: data => {
    return request({
      data,
      url: '/user/bind',
      method: 'get'
    })
  },
}
