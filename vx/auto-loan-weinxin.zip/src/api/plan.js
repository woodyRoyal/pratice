import request from '../utils/request'

export default {
  // 获取用户未结清的申请编号
  getRepayApplyIds: data => {
    return request({
      data,
      url: '/apply/getRepayApplyIds',
      method: 'get'
    })
  },
  // 获取还款计划
  getRepayPlanByApplyId: data => {
    return request({
      data,
      url: '/apply/getRepayPlanByApplyId',
      method: 'get'
    })
  },
  // 根据申请编号获取详细信息
  getByApplyId: data => {
    return request({
      data,
      url: '/apply/getByApplyId',
      method: 'get'
    })
  },
  // 根据申请编号进行还款
  repayByApplyId: data => {
    return request({
      data,
      url: '/apply/getByApplyId',
      method: 'get'
    })
  },
  // 根据申请编号进行还款
  updateRepayByApplyId: data => {
    return request({
      data,
      url: '/apply/updateRepayByApplyId',
      method: 'get'
    })
  },
}
