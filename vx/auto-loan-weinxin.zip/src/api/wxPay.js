import request from '../utils/request'

export default {
  // 根据申请编号进行还款
  repayByApplyId: data => {
    return request({
      data,
      url: '/apply/repayByApplyId',
      method: 'get'
    })
  },
  // 
  repayByApplyIdadvance: data => {
    return request({
      data,
      url: '/apply/advance/repayByApplyId',
      method: 'get'
    })
  },
  fetchConfig: data => {
    return request({
      data,
      url: '/wx/getConfig',
      method: 'post'
    })
  },
}
