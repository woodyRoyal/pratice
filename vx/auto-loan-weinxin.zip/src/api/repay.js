import request from '../utils/request'

export default {
  // 获取账户信息
  getPublicInfoByApplyId: data => {
    return request({
      data,
      url: '/apply/getPublicInfoByApplyId',
      method: 'get'
    })
  },
  // 获取账户信息
  repayByApplyId: data => {
    return request({
      data,
      url: '/apply/advance/repayByApplyId',
      method: 'get'
    })
  },
}
