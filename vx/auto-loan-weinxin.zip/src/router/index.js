import Vue from 'vue'
import Router from 'vue-router'
import Home from '../layout'
Vue.use(Router)

let router = new Router({
  routes: [
    {
      path: '/',
      redirect: '/home/login'
    },
    {
      path: '/home',
      name: '2345车贷王',
      component: Home,
      children: [
        {
          path: 'login',
          name: '绑定账号',
          component: () => import('../pages/login/index.vue')
        },
        {
          path: 'selfHelp',
          name: '自助还款',
          component: () => import('../pages/Self-help/index.vue')
        },
        {
          path: 'applyList',
          name: '申请单',
          component: () => import('../pages/Self-help/list.vue')
        },
        {
          path: 'beforeList',
          name: '提前结清列表',
          component: () => import('../pages/service/before-list.vue')
        },
        {
          path: 'beforeRepay',
          name: '提前结清',
          component: () => import('../pages/service/before-repay.vue')
        },
        {
          path: 'planList',
          name: '计划列表',
          component: () => import('../pages/service/plan-list.vue')
        },
        {
          path: 'plan',
          name: '还款计划',
          component: () => import('../pages/service/plan.vue')
        },
        {
          path: 'qa',
          name: '常见问题',
          component: () => import('../pages/info/qa.vue')
        },
        {
          path: 'Introduction',
          name: '公司介绍',
          component: () => import('../pages/info/Introduction.vue')
        },
        {
          path: 'contact',
          name: '联系我们',
          component: () => import('../pages/info/contact.vue')
        },
      ]
    },

  ]
})

export default router