<template>
  <div class="pic-view-dialog" ref="picViewDialog">
    <div class="toolbar" ref="toolbar">
      <i class="el-icon-close" @click="closePicView"></i>
    </div>
    <div class="img-list-wrap" ref="imgListWrap">
      <ul ref="imgWrapDom" style="visibility: hidden; display: flex; flex-wrap: wrap">
        <li v-for="(item, index) in imgItemList" :key="index"><img :src="item.filePathname" alt="" :type="item.fileType"></li>
      </ul>
    </div>
  </div>
</template>

<script>
  import PictureView from 'viewerjs'
  import 'viewerjs/dist/viewer.css'
  export default {
    props: ['imgItemList', 'clickItem'],
    data () {
      return {
        viewer: null
      }
    },
    mounted () {
      this.autoResize()
      let checkArr = ['jpg', 'jpeg', 'bmp', 'png', 'JPG', 'PNG', 'JPEG', 'BMP']
      let viewDom = this.$refs['imgWrapDom']
      let initialIndex = null
      this.imgItemList.forEach((item, index) => {
        if (item.filePathname === this.clickItem.filePathname) {
          initialIndex = index
        }
      })
      this.viewer = new PictureView(viewDom, {
        filter (img) {
          return (img.complete && (checkArr.indexOf(img.getAttribute('type')) > -1))
        },
        initialViewIndex: initialIndex,
        transition: false,
        inline: true, // 不全屏
        keyboard: true, // 非全屏不管用
        ready () {
          this.viewer.update()
        }
      })
      this.viewer.show()
    },
    destroyed () {
      this.viewer.destroy()
    },
    methods: {
      autoResize () {
        let imgListWrap = this.$refs['imgListWrap']
        let toolbar = this.$refs['picViewDialog']
        let clientW = document.documentElement.clientWidth
        let clientH = document.documentElement.clientHeight
        imgListWrap.style.width = toolbar.style.width = (clientW * 0.5) + 'px'
        imgListWrap.style.height = (clientH * 0.65) + 'px'
      },
      closePicView () {
        this.$emit('closePicView')
      }
    }
  }
</script>

<style scoped lang="scss">
  .toolbar{
    cursor: move;
    height: 25px;
  }
  .el-icon-close{
    float: right;
    cursor: pointer;
    font-size: 23px;
    position: relative;
    top: 2px;
    right: 5px;
  }
  ul{
    display: flex;
    flex-direction: row;
  }
  li{
    width: 50px;
    height: 50px;
    float: left;
    img{
      width: 100%;
      height: 100%;
    }
  }
</style>
