<template>
  <div>
    <div class="outerWrap fileUpload-wrap">
      <div class="download-btns-wrap" v-if="showSaveButton">
        <div class="wrap-left">
          <!--<el-button :type="isDownload ? 'primary' : ''" size="mini" @click="downloadFile">下载</el-button>-->
          <!--<el-button size="mini" v-if="isDownload" @click="selectAllFile">全选</el-button>-->
          <!--<el-button size="mini" v-if="isDownload" @click="cancelDownloadFile">取消</el-button>-->
        </div>
        <div class="wrap-right">
          <el-button type="primary" size="mini" @click="saveUploadFiles" :loading="isSaveLoading">保存本页面</el-button>
        </div>
      </div>
      <!--必传文件-->
      <div v-if="necessaryUploadData.length">
        <div class="must-upload-title">
          <h2 v-if="applyNode !== 'internal_audit_file'">{{applyNodeDict[applyNode]}}必传文件</h2>
          <h2 v-else>内部文件</h2>
          <div>{{hideSideTitle ? '' : '以下文件为必传文件，可批量上传'}}</div>
        </div>
        <div class="must-upload-img-outer-wrap">
          <div class="must-upload-img-content" v-for="(item, index) in necessaryUploadData" :key="index">
            <h3 class="img-module-total-title">{{item.categoryDesc}}</h3>
            <div class="img-module-outer-wrap">
              <ul class="img-module-wrap" :ref="item.dictCategory + 'requiredImgList'">
                <li v-for="(k, i) in item.pictureListVOList" :key="i">
                  <div class="img-module-title">{{k.name}}</div>
                  <ul class="img-list">
                    <li v-for="(o, j) in k.fileRecordVOList" :key="j" @click="fileView(o, item.pictureListVOList)">
                      <div class="img-item-wrap">
                        <!--删除-->
                        <span class="img-delete-btn-wrap" @click="deleteImgItem($event, o, j, 1, applyNode)" v-if="!hideDeleteBtn"><i class="el-icon-delete"></i></span>
                        <!--<span class="img-item-checkbox" v-if="isDownload" @click="deleteImgItem"><el-checkbox @change="selectFileItem"></el-checkbox></span>-->
                        <!--<span :class="[{'img-item-cover-show': isDownload}, 'img-item-cover']" v-if="isDownload"></span>-->
                        <!--文件-->
                        <img :src="o.filePathname" :alt="o.name" :type="o.fileType" v-if="fileTypeList.indexOf(o.fileType) > -1">
                        <img src="../../assets/fileImg2.png" :alt="o.name" :type="o.fileType" v-else>
                      </div>
                      <p class="img-item-title">{{o.name}}</p>
                    </li>
                    <li v-if="!hideAllUploadSwitch" @click="uploadHandle(k.dictKey)" @drop="dropHandle($event, k.dictKey, item.dictCategory, true)" @dragover="dragOverHandle($event)" @dragenter="dragEnterHandle($event)">
                      <div class="img-item-wrap">
                        <div class="img-item-upload-icon">
                          <i class="iconfont icon-huaban"></i>
                          <p class="img-item-upload-icon-word">将文件拖到此处或点击上传</p>
                        </div>
                        <input type="file" name="upload" multiple='multiple' class="file-upload-input" :ref="k.dictKey" @change="dropHandle($event, k.dictKey, item.dictCategory, true)"/>
                      </div>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <!--选传文件-->
      <div class="optional-upload-title" v-if="applyNode !== 'internal_audit_file'">
        <h2>{{applyNodeDict[applyNode]}}选传文件</h2>
        <div>{{hideTree ? '' : '以下文件为选传文件，可批量上传'}}</div>
      </div>
      <div class="optional-upload-img-outer-wrap" v-if="applyNode !== 'internal_audit_file'">
        <div class="optional-upload-content-left" v-if="!hideTree">
          <h3 class="optional-img-module-total-title optional-img-file-tree-title">添加其他附件</h3>
          <div class="optional-img-file-tree-wrap">
            <el-tree :data="optionalTreeData" :props="defaultProps" :indent="0" @node-click="handleNodeClick" class="post-loan-up-tree"></el-tree>
          </div>
        </div>
        <div class="optional-upload-content-right">
          <div class="optional-upload-content-right-content" v-for="(item, index) in unNecessaryUploadData" :key="index">
            <h3 class="optional-img-module-total-title">{{item.categoryDesc}}</h3>
            <div class="optional-img-module-outer-wrap">
              <ul class="img-module-wrap" :ref="item.dictCategory + 'notRequiredImgList'">
                <li v-for="(k, i) in item.pictureListVOList" :key="i">
                  <div class="img-module-title">{{k.name}}</div>
                  <ul class="img-list">
                    <li v-for="(o, j) in k.fileRecordVOList" :key="j" @click="fileView(o, item.pictureListVOList)">
                      <div class="img-item-wrap">
                        <!--删除-->
                        <span class="img-delete-btn-wrap" @click="deleteImgItem($event, o, j, 0, applyNode)" v-if="k.dictKey !=='fault_file' && k.dictKey !=='fault_file_request_loan'&& k.dictKey !=='fault_file_post_loan' && !hideDeleteBtn"><i class="el-icon-delete"></i></span>
                        <!--<span class="img-item-checkbox" v-if="isDownload"><el-checkbox @change="selectFileItem"></el-checkbox></span>-->
                        <!--<span :class="[{'img-item-cover-show': isDownload}, 'img-item-cover']"></span>-->
                        <!--文件-->
                        <img :src="o.filePathname" :alt="o.name" :type="o.fileType" v-if="fileTypeList.indexOf(o.fileType) > -1">
                        <img src="../../assets/fileImg2.png" :alt="o.name" :type="o.fileType" v-else>
                      </div>
                      <p class="img-item-title">{{o.name}}</p>
                    </li>
                    <li v-if="k.dictKey !=='fault_file' && k.dictKey !=='fault_file_request_loan'&& k.dictKey !=='fault_file_post_loan' && !hideAllUploadSwitch" @click="uploadHandle(k.dictKey)" @drop="dropHandle($event, k.dictKey, item.dictCategory, false)" @dragover="dragOverHandle($event)" @dragenter="dragEnterHandle($event)">
                      <div class="img-item-wrap">
                        <div class="img-item-upload-icon">
                          <i class="iconfont icon-huaban"></i>
                          <p class="img-item-upload-icon-word">将文件拖到此处或点击上传</p>
                        </div>
                        <input type="file" name="upload" multiple='multiple' class="file-upload-input" :ref="k.dictKey" @change="dropHandle($event, k.dictKey, item.dictCategory, false)"/>
                      </div>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { UPLOAD_URL } from '../../api/commonApi.js'
  import PicView from '../../components/PicView/index'
  import {changePicFileType} from '../../utils/constant'
  const qs = require('qs')
  export default {
    /*
    showSaveButton: 是否显示保存按钮，
    hideTree：隐藏选传文件树['这个决定着是否已纯展示图片']，
    applyNode：提报文件，贷后文件，请款文件
    necessaryUploadData：每个applyNode对应的必传文件
    unNecessaryUploadData：每个applyNode对应的非必传文件
    optionalTreeData：选传文件树
    */
    props: [
      'applyNode',
      'showSaveButton',
      'isSaveLoading',
      'hideSideTitle',
      'hideTree',
      'hideAllUploadSwitch',
      'hideDeleteBtn',
      'necessaryUploadData',
      'unNecessaryUploadData',
      'optionalTreeData'
    ],
    data () {
      return {
        defaultProps: {
          children: 'list',
          label: 'dictName'
        },
        fileTypeList: ['jpg', 'jpeg', 'bmp', 'png', 'JPG', 'PNG', 'JPEG', 'BMP'],
        isPicViewShow: false,
        applyNodeDict: {
          'identity_file': '申请提报',
          'post_loan_upload': '贷后',
          'request_loan_attachment': '请款',
          'dealer_file': '经销商上线'
        }
      }
    },
    components: { PicView },
    methods: {
      // 鼠标移入
      dragEnterHandle (e) { e.preventDefault() },
      // 鼠标悬浮
      dragOverHandle (e) { e.preventDefault() },
      // 拖拽上传
      dropHandle (e, parentCategory, grandCategory, isRequired) {
        e.preventDefault()
        this.fileUpload(e, parentCategory, grandCategory, isRequired)
      },
      // 点击对应的input触发对应input的change事件
      uploadHandle (parentCategory) {
        // 触发选择文件前，清空上次上传的文件，将具体的阻止相同上传的逻辑代码单独处理
        this.$refs[parentCategory][0].value = ''
        this.$refs[parentCategory][0].click()
      },
      // 将对应的选传文件种类添加到要上传的文件中
      pushOptionalKindToFileList (situation, treeNode) {
        let val = treeNode
        let notRequiredFilesList = JSON.parse(JSON.stringify(this.unNecessaryUploadData))
        if (situation === 'pushSame') {
          notRequiredFilesList.push(
            {
              categoryDesc: val.dictCategoryName,
              dictCategory: val.dictCategory,
              pictureListVOList: [{
                dictKey: val.dictKey,
                name: val.dictName,
                fileRecordVOList: []
              }]
            }
          )
        } else if (situation === 'pushChild') {
          notRequiredFilesList.forEach(item => {
            if (item.dictCategory === val.dictCategory) {
              item.pictureListVOList.push({
                dictKey: val.dictKey,
                name: val.dictName,
                fileRecordVOList: []
              })
            }
          })
        } else if (situation === 'deleteEmpty') {
          // 删除对应的文件种类
          notRequiredFilesList.forEach((item, index) => {
            if (item.dictCategory === val.dictCategory) {
              if (item.pictureListVOList.length) {
                item.pictureListVOList.forEach((k, i) => {
                  if (!k.fileRecordVOList.length && val.dictKey === k.dictKey) item.pictureListVOList.splice(i, 1)
                  if (!item.pictureListVOList.length) notRequiredFilesList.splice(index, 1)
                })
              }
            }
          })
        }
        this.$emit('changeUnNecessaryUploadData', {applyNode: this.applyNode, notRequiredFilesList})
      },
      // 选取需要上传的文件种类
      handleNodeClick (val) {
        let parentFlag = 0
        let childFlag = 0
        if (val.list) {
          return false
        } else {
          if (this.unNecessaryUploadData.length === 0) {
            this.pushOptionalKindToFileList('pushSame', val)
          } else {
            this.unNecessaryUploadData.forEach(item => {
              if (item.dictCategory === val.dictCategory) {
                parentFlag = 1
                item.pictureListVOList.forEach(k => {
                  if (k.dictKey === val.dictKey) childFlag = 1
                })
              }
            })
            if (!parentFlag) {
              this.pushOptionalKindToFileList('pushSame', val)
            } else if (parentFlag && !childFlag) {
              this.pushOptionalKindToFileList('pushChild', val)
            } else if (parentFlag && childFlag) {
              this.pushOptionalKindToFileList('deleteEmpty', val)
            }
          }
        }
      },
      // 文件上传主要代码
      fileUpload (e, parentCategory, grandCategory, isRequired) {
        // let that = this
        let fileList = e.target.files || e.dataTransfer.files // 点击上传和拖拽上传获取文件的方式不一样
        // FileList 数据类型
        Array.prototype.forEach.call(fileList, file => {
          const checkSameFileParam = {file, fileListLength: fileList.length, parentCategory, grandCategory, isRequired}
          let fileType = file.type.slice(file.type.indexOf('/') + 1)
          if (this.fileTypeList.indexOf(fileType) > -1) {
            /* if (parentCategory === 'operate_upload_file') {
              if (!that.checkIsUploadSameFile(checkSameFileParam)) that.fileUploadAjax(file, parentCategory, grandCategory, isRequired)
            } else {
              console.log(new Date().getTime(), 'compressStart')
              // 压缩
              this.photoCompress(file, {quality: 0.7}, function (base64Codes) {
                const fileNameChanged = changePicFileType(file.name);
                let fileStream = that.convertBase64UrlToFile(base64Codes, fileNameChanged)
                console.log(new Date().getTime(), 'compressEnd')
                // 上传
                if (!that.checkIsUploadSameFile(checkSameFileParam)) that.fileUploadAjax(fileStream, parentCategory, grandCategory, isRequired)
              })
            } */
            if (!this.checkIsUploadSameFile(checkSameFileParam)) this.fileUploadAjax(file, parentCategory, grandCategory, isRequired)
          } else {
            this.fileUploadAjax(file, parentCategory, grandCategory, isRequired)
          }
        })
      },
      // 文件ajax
      fileUploadAjax (fileStream, parentCategory, grandCategory, isRequired) {
        let fd = new FormData()
        fd.append('inputStream', fileStream)
        fd.append('fileCategory', parentCategory)
        let xhr = new XMLHttpRequest()
        xhr.onreadystatechange = () => {
          if(xhr.status === 200 && xhr.readyState === 4) {
            let res = JSON.parse(xhr.response)
            if (res.respCode === '1000') this.pushFileToFileList(isRequired, grandCategory, parentCategory, res.body)
          } else if (xhr.status !== 200 && xhr.readyState === 4){
            this.$message.warning('上传失败')
          }
        }
        xhr.open('post', UPLOAD_URL, true)
        xhr.send(fd)
      },
      // 将对应的文件添加至对应的数组中
      pushFileToFileList (isRequired, grandCategory, parentCategory, data) {
        let arr = isRequired ? JSON.parse(JSON.stringify(this.necessaryUploadData)) : JSON.parse(JSON.stringify(this.unNecessaryUploadData))
        arr.forEach(item => {
          if (item.dictCategory === grandCategory) {
            item.pictureListVOList.forEach(k => {
              if (k.dictKey === parentCategory) {
                data.relatedGroup = grandCategory
                k.fileRecordVOList.push(data)
              }
            })
          }
        })
        isRequired ? this.$emit('changeNecessaryUploadData', {applyNode: this.applyNode, requiredFilesList: arr}) : this.$emit('changeUnNecessaryUploadData', {applyNode: this.applyNode, notRequiredFilesList: arr})
      },
      /* // 图片压缩
      photoCompress (file, compressOption, callback) {
        let that = this
        let ready = new FileReader()
        ready.readAsDataURL(file)
        ready.onload = function() {
          let re = this.result
          that.canvasDataURL(re, compressOption, callback)
        }
      },
      // 图片压缩具体代码
      canvasDataURL (path, compressOption, callback) {
        let img = new Image()
        img.src = path
        img.onload = function() {
          let that = this
          let quality = 0.7 // 默认图片质量为0.7
          //生成canvas
          let canvas = document.createElement('canvas')
          let ctx = canvas.getContext('2d')
          canvas.width = that.width / 2.5
          canvas.height = that.height / 2.5
          ctx.drawImage(that, 0, 0, canvas.width, canvas.height)
          // 图像质量
          if(compressOption.quality && compressOption.quality <= 1 && compressOption.quality > 0) quality = compressOption.quality
          // quality值越小，所绘制出的图像越模糊
          let base64 = canvas.toDataURL('image/jpeg', quality)
          // 回调函数返回base64的值
          callback(base64)
        }
      },
      // Base64Url转为File对象
      convertBase64UrlToFile (urlData, fileName) {
        let arr = urlData.split(',')
        let mime = arr[0].match(/:(.*?);/)[1]
        let bstr = atob(arr[1])
        let n = bstr.length
        let u8arr = new Uint8Array(n)
        while(n--) {
          u8arr[n] = bstr.charCodeAt(n)
        }
        return new File([u8arr], fileName, {type:mime});
      }, */
      // 文件名check是否相同，上传单个会提示
      checkIsUploadSameFile (checkSameFileParam) {
        const {file, fileListLength, parentCategory, grandCategory, isRequired} = checkSameFileParam
        let nameList = []
        const fileList = isRequired ? this.necessaryUploadData : this.unNecessaryUploadData
        fileList.forEach(item => {
          if (item.dictCategory === grandCategory) {
            item.pictureListVOList.forEach(k => {
              if (k.dictKey === parentCategory) {
                k.fileRecordVOList.forEach(item => {
                  nameList.push(item.name)
                })
              }
            })
          }
        })
        if (nameList.indexOf(file.name) > -1) {
          if (fileListLength === 1) this.$message.warning('请勿上传相同的文件')
          return 1
        }
        return 0
      },
      // 文件预览
      fileView (clickItem) {
        let totalFilesList = [...this.necessaryUploadData, ...this.unNecessaryUploadData].reduce(((newVal, item) => {
          newVal.push(...item.pictureListVOList)
          return newVal
        }), [])
        let totalFilesListConcat = totalFilesList.reduce(((newVal, item) => {
          newVal.push(...item.fileRecordVOList)
          return newVal
        }), [])
        let imgItemList = totalFilesListConcat.filter(item => {
          return this.fileTypeList.indexOf(item.fileType) > -1
        })
        if (this.fileTypeList.indexOf(clickItem.fileType) > -1) {
          this.$emit('showPicView', {clickItem, imgItemList})
        } else {
          // 非图片文件，文件下载
          window.location.href = process.env.BASE_API + '/fileStoreClient/downloadFile?' + qs.stringify({filePathName: clickItem.filePathname, id: clickItem.id})
        }
      },
      // 删除文件
      deleteImgItem (e, imgItem, i, isRequired, applyNode) {
        e.stopPropagation()
        this.$confirm('确认删除此文件吗', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$emit('deleteFileItem', {imgItem, index: i, isRequired, applyNode})
        }).catch(() => { this.$message.info('已取消删除') })
      },
      // 保存文件
      saveUploadFiles () {
        this.$emit('saveUploadFiles')
      }
    }
  }
</script>

<style scoped lang="scss">
  @import "../../styles/fileUpload";
</style>
