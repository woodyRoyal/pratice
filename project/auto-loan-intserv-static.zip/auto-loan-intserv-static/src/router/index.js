import Vue from 'vue'
import Router from 'vue-router'

/* layout */
import Layout from '../views/layout/Layout'

/* login */
import Login from '../views/login/'
import authRedirect from '../views/login/authredirect'
import sendPWD from '../views/login/sendpwd'
import reset from '../views/login/reset'
import packageConfig from 'package'

/* error page */
const Err404 = (resolve) => require(['../views/error/404'], resolve)
const Err401 = (resolve) => require(['../views/error/401'], resolve)
const Home = (resolve) => require(['../views/layout/Home'], resolve)
const Blank = (resolve) => require(['../views/layout/Blank.vue'], resolve) // 三级菜单使用

/* system */

Vue.use(Router)

/* 经销商上线 */
const DealerOnline = (resolve) => require(['../views/dealer/dealerOnline.vue'], resolve)
const DealerInfo = (resolve) => require(['../views/dealer/dealerInfo.vue'], resolve)

/* 经销商维护 */
const DealerMaintain = (resolve) => require(['../views/dealerMaintain/dealerMaintain.vue'], resolve)
const DealerInfoMaintain = (resolve) => require(['../views/dealerMaintain/dealerInfoMaintain.vue'], resolve)

/* 内部用户管理  */
const InnerUserManage = (resolve) => require(['../views/innerManage/user.vue'], resolve)
const InnerStationManage = (resolve) => require(['../views/innerManage/station.vue'], resolve)
const InnerAllStation = (resolve) => require(['../views/innerManage/allStation.vue'], resolve)

/* B端用户管理 */
const BUser = (resolve) => require(['../views/bManage/user.vue'], resolve)

/* 设置 */
const PasswordEdit = (resolve) => require(['../views/setting/passwordEdit.vue'], resolve)

/* 放款 */
const FangKuan = (resolve) => require(['../views/fangkuan/fangkuanIndex.vue'], resolve)
const FangKuanDetail = (resolve) => require(['../views/fangkuan/fangkuanDetail.vue'], resolve)
const FangKuanTaskRemove = (resolve) => require(['../views/fangkuan/taskRemove.vue'], resolve)
const SPAccount = (resolve) => require(['../views/fangkuan/spAccount.vue'], resolve)

/* 贷后 */
const DaiHou = (resolve) => require(['../views/daihou/daihouIndex.vue'], resolve)
const DaiHouDetail = (resolve) => require(['../views/daihou/daihouDetail.vue'], resolve)
const GuiDang = (resolve) => require(['../views/daihou/guidang.vue'], resolve)
const DaiHouUpload = (resolve) => require(['../views/daihou/daihouUpload.vue'], resolve)
const DaihouUploadDetail = (resolve) => require(['../views/daihou/daihouUploadDetail/fileUpload.vue'], resolve)

/* 业务管理 */
const ProductManage = (resolve) => require(['../views/productManage/index.vue'], resolve)
const ProductManageDetail = (resolve) => require(['../views/productManage/productDetail.vue'], resolve)
const SwitchCapital = (resolve) => require(['../views/switchCapital/switchCapital.vue'], resolve)
const AttachedCompanyManage = (resolve) => require(['../views/attachedCompanyManage/attachedCompanyIndex'], resolve)
const AttachedCompanyManageDetail = (resolve) => require(['../views/attachedCompanyManage/attachedCompanyDetail'], resolve)
const CustomerRepayCard = (resolve) => require(['../views/customerRepayCard/repayCardList'], resolve)
/* 财务管理 */
const HistoryRepay = (resolve) => require(['../views/financialManage/historyPay.vue'], resolve)
const PayCheck = (resolve) => require(['../views/financialManage/payCheck.vue'], resolve)
const RepayConfirm = (resolve) => require(['../views/financialManage/repaymentConfirm.vue'], resolve)
const RepayHistory = (resolve) => require(['../views/financialManage/repaymentHistory.vue'], resolve)
const RepayWriteOff = (resolve) => require(['../views/financialManage/repaymentWriteOff.vue'], resolve)
const RepayWriteOffCheck = (resolve) => require(['../views/financialManage/repaymentWriteOffCheck.vue'], resolve)
const RepayWriteOffCheckDeail = (resolve) => require(['../views/financialManage/repaymentWriteOffCheckDetail.vue'], resolve)
const RepayConfirmDetail = (resolve) => require(['../views/financialManage/repaymentConfirmDetail.vue'], resolve)
const RepayHistoryDetail = (resolve) => require(['../views/financialManage/repaymentHistoryDetail.vue'], resolve)
const CustomerRepayment = (resolve) => require(['../views/financialManage/customerRepayment.vue'], resolve)
const DepositAccount = (resolve) => require(['../views/financialManage/depositAccount.vue'], resolve)
const CutRepayment = (resolve) => require(['../views/financialManage/cutRepayment.vue'], resolve)

/* 申请进度查询 */
const ApplyProgress = (resolve) => require(['../views/applyProgress/index.vue'], resolve)
const ApplyProgressDetail = (resolve) => require(['../views/applyProgress/applyProgressDetail.vue'], resolve)

/* 业务报表 */
// 运营信息表
const OperationTable = (resolve) => require(['../views/businessReport/operationReport.vue'], resolve)
const GpsTable = (resolve) => require(['../views/businessReport/gpsInfoQuery.vue'], resolve)

/* 公告 */
const NoticePublish = (resolve) => require(['../views/webNotice/noticePublish.vue'], resolve)

// data decryption
const Decryption = (resolve) => require(['../views/decryption'], resolve)
/**
 * icon : the icon show in the sidebar
 * hidden : if hidden:true will not show in the sidebar
 * redirect : if redirect:noredirect will not redirct in the levelbar
 * noDropdown : if noDropdown:true will not has submenu
 * meta : { role: ['admin'] }  will control the page role
 */

export const constantRouterMap = [
  {path: '/', redirect: '/home/index', hidden: true},
  {path: '/login', component: Login, hidden: true},
  {path: '/authredirect', component: authRedirect, hidden: true},
  {path: '/sendpwd', component: sendPWD, hidden: true},
  {path: '/reset', component: reset, hidden: true},
  {path: '/404', component: Err404, hidden: true},
  {path: '/401', component: Err401, hidden: true},
  {path: '/all-station', component: InnerAllStation, hidden: true},
  {path: '/dealer-info/:id', component: DealerInfo, hidden: true},
  {path: '/dealer-maintain/:id', component: DealerInfoMaintain, hidden: true},
  {path: '/fangkuanDetail/:applyId/:applyType', component: FangKuanDetail, hidden: true},
  {path: '/daihouDetail/:applyId/:applyType', component: DaiHouDetail, hidden: true},
  {path: '/daihouUploadDetail/:applyId', component: DaihouUploadDetail, hidden: true},
  {path: '/product-detail/:serialNo/:productId', component: ProductManageDetail, hidden: true},
  {path: '/apply-progress-detail/:itemId/:identityType', component: ApplyProgressDetail, hidden: true},
  {path: '/repayment-write-off-check-detail/:bookType/:bookId/:applyId/:userId/:billLoanNo', component: RepayWriteOffCheckDeail, hidden: true},
  {path: '/repayment-confirm-detail/:bookType/:bookId/:applyId/:userId/:billLoanNo', component: RepayConfirmDetail, hidden: true},
  {path: '/repayment-history-detail/:bookType/:bookId/:applyId/:userId/:billLoanNo', component: RepayHistoryDetail, hidden: true},
  {path: '/attached-company-detail/:id/:statusCode', component: AttachedCompanyManageDetail, hidden: true},
  {
    path: '/home',
    component: Layout,
    hidden: true,
    children: [
      {path: 'index', component: Home, name: '首页'},
    ],
  },
]

export default new Router({
  mode: 'hash',
  // mode: 'history', //后端支持可开
  scrollBehavior: () => ({y: 0}),
  base: '/' + packageConfig.name,
  routes: constantRouterMap,
})

// 路由菜单树
export const asyncRouterMapTree = [
  {
    path: '/fangkuan', // 有三级菜单 需要把二级菜单路径写全
    component: Layout,
    name: '放款管理',
    icon: 'iconfont icon-money-a',
    children: [
      {
        path: 'fangkuan',
        component: FangKuan,
        name: '放款审核首页',
      },
      {
        path: 'fangkuan-transfer',
        component: FangKuanTaskRemove,
        name: '任务转件',
      },
      {
        path: 'sp-account',
        component: SPAccount,
        name: 'SP服务费台账',
      },
    ],
  },
  {
    path: '/daihou', // 有三级菜单 需要把二级菜单路径写全
    component: Layout,
    name: '贷后管理',
    icon: 'iconfont icon-daihouguanli',
    children: [
      {
        path: 'daihou',
        component: DaiHou,
        name: '贷后管理首页',
      },
      {
        path: 'upload',
        component: DaiHouUpload,
        name: '贷后资料上传',
      },
      {
        path: 'guidang',
        component: GuiDang,
        name: '归档明细表',
      },
    ],
  },
  {
    path: '/finance',
    component: Layout,
    name: '财务管理',
    icon: 'iconfont icon-caiwu',
    children: [
      {
        path: '/finance/financial',
        component: Blank,
        name: '付款',
        icon: 'iconfont icon-guanjiankey50',
        children: [
          {
            path: 'pay-check',
            component: PayCheck,
            name: '付款确认',
            icon: 'iconfont icon-guanjiankey50',
          },
          {
            path: 'history-repay',
            component: HistoryRepay,
            name: '历史付款记录',
            icon: 'iconfont icon-guanjiankey50',
          },
        ],
      },
      {
        path: '/finance/repayment',
        component: Blank,
        name: '还款',
        icon: 'iconfont icon-guanjiankey50',
        children: [
          {
            path: 'repayment-book',
            component: RepayWriteOff,
            name: '还款勾稽',
            icon: 'iconfont icon-guanjiankey50',
          },
          {
            path: 'repayment-book-check',
            component: RepayWriteOffCheck,
            name: '还款勾稽审核',
            icon: 'iconfont icon-guanjiankey50',
          },
          {
            path: 'repayment-confirm',
            component: RepayConfirm,
            name: '还款确认',
            icon: 'iconfont icon-guanjiankey50',
          },
          {
            path: 'repayment-book-history',
            component: RepayHistory,
            name: '还款勾稽历史',
            icon: 'iconfont icon-guanjiankey50',
          },
          {
            path: 'customer-repay',
            component: CustomerRepayment,
            name: '回款记录查询',
            icon: 'iconfont icon-guanjiankey50',
          }, {
            path: 'deposit-account',
            component: DepositAccount,
            name: '保证金台账',
            icon: 'iconfont icon-guanjiankey50',
          },
        ],
      },
      {
        path: '/finance/check',
        component: Blank,
        name: '对账',
        icon: 'iconfont icon-guanjiankey50',
        children: [{
          path: 'cut-payment',
          component: CutRepayment,
          name: '对公扣款',
          icon: 'iconfont icon-guanjiankey50',
        }],
      },
    ],
  },
  {
    path: '/distributor',
    component: Layout,
    name: '经销商管理',
    icon: 'iconfont icon-jingxiaoshang',
    children: [
      {
        path: 'online',
        component: DealerOnline,
        name: '经销商上线',
        icon: 'iconfont icon-guanjiankey50',
      },
      {
        path: 'maintain',
        component: DealerMaintain,
        name: '经销商信息维护页',
        icon: 'iconfont icon-guanjiankey50',
      },
    ],
  },
  {
    path: '/business',
    component: Layout,
    name: '业务管理',
    icon: 'iconfont icon-yewu',
    children: [
      {
        path: 'produtManage',
        component: ProductManage,
        name: '产品管理',
        icon: 'iconfont icon-guanjiankey50',
      },
      {
        path: 'web-notice',
        component: NoticePublish,
        name: '公告发布',
        icon: 'iconfont icon-guanjiankey50',
      },
      {
        path: 'switch-capital',
        component: SwitchCapital,
        name: '资方切换',
        icon: 'iconfont icon-guanjiankey50',
      },
      {
        path: 'repaymentCard',
        component: CustomerRepayCard,
        name: '客户还款卡变更',
        icon: 'iconfont icon-guanjiankey50',
      },
      {
        path: 'attachedCompany',
        component: AttachedCompanyManage,
        name: '挂靠公司管理',
        icon: 'iconfont icon-guanjiankey50',
      },
    ],
  },
  {
    path: '/report',
    component: Layout,
    name: '业务报表',
    icon: 'iconfont icon-report',
    children: [
      {
        path: 'operation-table',
        component: OperationTable,
        name: '运营信息表',
        icon: 'iconfont icon-guanjiankey50',
      },
      {
        path: 'gps-table',
        component: GpsTable,
        name: 'GPS信息查询表',
        icon: 'iconfont icon-guanjiankey50',
      },
    ],
  },
  {
    path: '/inner',
    component: Layout,
    name: '内部用户管理',
    icon: 'iconfont icon-yonghu1',
    children: [
      {
        path: 'user',
        component: InnerUserManage,
        name: '用户管理',
      },
      {
        path: 'station',
        component: InnerStationManage,
        name: '岗位管理',
      },
    ],
  },
  {
    path: '/bside',
    component: Layout,
    name: 'B端用户中心',
    icon: 'iconfont icon-yonghu',
    children: [
      {
        path: 'user-b',
        component: BUser,
        name: 'B端用户管理',
      },
    ],
  },
  {
    path: '/apply',
    component: Layout,
    name: '申请进度查询',
    icon: 'iconfont icon-chart38',
    children: [
      {
        path: 'progress',
        component: ApplyProgress,
        name: '申请进度查询表',
      },
    ],
  },
  {
    path: '/data-decryption',
    component: Layout,
    name: '用户数据解密',
    icon: 'iconfont icon-daihouguanli',
    children: [
      {
        path: 'decryption',
        component: Decryption,
        name: '用户数据解密',
      },
    ],
  },
  {
    path: '/setting',
    component: Layout,
    name: '设置',
    icon: 'iconfont icon-shezhi1',
    children: [
      {
        path: 'edit',
        component: PasswordEdit,
        name: '密码修改',
        icon: 'iconfont icon-kdw',
      },
    ],
  },
]

// 路由树转换为键值对对象 path为key
function routerTreeListToMapObj (treeList) {
  let mapObj = {}
  treeList.map((item) => transObj(item, mapObj))
  return mapObj
}

// 转换对象
function transObj (source, target) {
  if (!source.path) {
    return
  }
  target[source.path] = {}
  if (source.name) {
    target[source.path].name = source.name
  }
  if (source.component) {
    target[source.path].component = source.component
  }
  if (source.icon) {
    target[source.path].icon = source.icon
  }
  if (source.noDropdown) {
    target[source.path].noDropdown = source.noDropdown
  }
  // 递归处理子菜单
  if (source.children && source.children.length > 0) {
    source.children.map((item) => transObj(item, target))
  }
  return target
}

// 输出路由映射对象
export const asyncRouterMapObj = routerTreeListToMapObj(asyncRouterMapTree)

// “*” 匿名路由须放在最后
export const lastRouterConst = [
  {path: '*', redirect: '/home/index', hidden: true},
]
