import fetch from '../utils/fetch'

export default {
  // 拉去上传文件
  fetchUploadFile (data) {
    return fetch({
      url: 'proposerImage/getImageDataByTypeNew',
      method: 'get',
      params: data
    })
  },
  // 经销商列表查询
  fetchDealerData (data) {
    return fetch({
      url: 'dealerInfo/queryDealerSummaryInfo',
      method: 'post',
      data
    })
  },
  // 基础信息查询
  fetchBaseData (dealerId) {
    return fetch({
      url: 'dealerInfo/queryDealerInformation',
      method: 'get',
      params: { dealerId }
    })
  },
  // 基础信息保存
  fetchSaveBaseData (data) {
    return fetch({
      url: 'dealerInfo/saveDealerInformation',
      method: 'post',
      data
    })
  },
  // 获取系统用户信息
  fetchSystemUserInfo (data) {
    return fetch({
      url: 'dealerStaff/queryDealerStaffList',
      method: 'post',
      data
    })
  },
  // 系统用户信息新增接口
  fetchSystemUserInfoAdd (data) {
    return fetch({
      url: 'dealerStaff/saveDealerStaff',
      method: 'post',
      data
    })
  },
  // 系统用户信息编辑接口
  fetchSystemUserInfoEdit (data) {
    return fetch({
      url: 'dealerStaff/updateDealerStaff',
      method: 'post',
      data
    })
  },
  // 删除经销商用户信息
  fetchDeleteDealerStaff (id) {
    return fetch({
      url: 'dealerStaff/deleteDealerStaff',
      method: 'get',
      params: {id}
    })
  },
  // 提交上线申请
  fetchSubmitDealerApplication (dealerId) {
    return fetch({
      url: 'dealerInfo/submitDealerApplication',
      method: 'get',
      params: {dealerId}
    })
  },
  // 置为有效或者无效
  fetchUpdateDealerInvalidSetting (data) {
    return fetch({
      url: 'dealerInfo/updateDealerInvalidSetting',
      method: 'post',
      data
    })
  },
  // 获取区域经理下拉
  fetchFindUsersByKind (kind) {
    return fetch({
      url: 'intserv/manage/findUsersByKind',
      method: 'get',
      params: { kind }
    })
  }
}
