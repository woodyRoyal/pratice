import fetch from '../utils/fetch'

export function getTableDataInfo (data) {
  return fetch({
    method: 'post',
    url: 'config/product/queryProductList',
    data
  })
}

// 查询产品信息
export function queryProductById (serialNo) {
  return fetch({
    method: 'get',
    url: '/config/product/findProductBySerialNo',
    params: {serialNo}
  })
}

// 保存产品信息
export function saveProductInfo (data) {
  return fetch({
    method: 'post',
    url: '/config/product/saveConfig',
    data
  })
}

// 获取产品配置页面的融资项目列表
export function listFinancing (params) {
  return fetch({
    method: 'get',
    url: '/config/product/listFinancing',
    params
  })
}

// 获取文件资料树
export function fileTreeList (applyId) {
  return fetch({
    method: 'get',
    url: '/proposerImage/getProductImageMenu',
    params: {applyId}
  })
}

// 查询规则引擎
export function ruleList (productId) {
  return fetch({
    method: 'get',
    url: '/drools/queryDrools',
    params: {productId}
  })
}

// 产品启用
export function productUse (serialNo) {
  return fetch({
    method: 'get',
    url: '/config/product/enableProduct',
    params: {serialNo}
  })
}

// 产品停用
export function productUnuse (serialNo) {
  return fetch({
    method: 'get',
    url: '/config/product/disableProduct',
    params: {serialNo}
  })
}

// 规则引擎模板
export function ruleTemplate (params) {
  return fetch({
    method: 'get',
    url: '/drools/queryTemplate',
    params
  })
}

// 规则引擎
export function productRules (productId) {
  return fetch({
    method: 'get',
    url: '/drools/queryDrools',
    params: {productId}
  })
}
