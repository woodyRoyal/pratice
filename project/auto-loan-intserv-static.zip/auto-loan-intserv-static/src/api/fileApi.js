import fetch from 'utils/fetch'
export default{
// 文件上传 接口地址
  uploadApi: process.env.BASE_API + '/upload/fileImportService/decryptFile',
  // 查询已加密文件
  queryDecryptedFile (data) {
    return fetch({
      url: '/restfulservice/encryptedDataService/queryDecryptedFile',
      method: 'post',
      data
    })
  },
  downLoadApi: process.env.BASE_API + '/download/encryptedDataService/downloadDecryptedFile'
}
