import fetch from '../utils/fetch'
export const dict = {
  bookTypeDict: {1: '租金勾稽', 2: '提前结清勾稽', 3: '回购'},
  advanceTypeDict: {
    1: '换车',
    2: '退车',
    3: '处置结清',
    4: '核销结清',
    5: '正常结清'
  },
  auditStatus: {
    1: '催收待审核',
    20: '催收审核中',
    21: '待财务审批',
    22: '催收已拒绝',
    23: '催收已通过',
    30: '财务审核中',
    31: '财务已通过',
    32: '财务已拒绝'
  },
  stepDict: {
    1: '申请提交',
    2: '催收审核',
    3: '财务确认'
  },
  repayPlansStatus: {
    0: '作废',
    1: '正常',
    2: '结清',
    3: '逾期'
  },
  repayBankDict: {
    'NBCB': '宁波银行',
    'BOS': '上海银行'
  }
}

// 确认付款
export function payCheckList (data) {
  return fetch({
    method: 'post',
    url: '/applyTransfer/page',
    data
  })
}
// 确认批量确认
export function confirmPay (data) {
  return fetch({
    method: 'post',
    url: '/applyTransfer/doManualTransfer',
    data
  })
}

// 付款银行
export function payBank (params) {
  return fetch({
    method: 'get',
    url: 'applyTransfer/channelBank',
    params
  })
}

// 付款记录
export function payHistory (data) {
  return fetch({
    method: 'post',
    url: '/applyTransfer/query',
    data
  })
}

// 导出文件生成（付款确认）
export function payCheckGet (data) {
  return fetch({
    method: 'post',
    url: '/applyTransfer/exportAsync',
    data
  })
}

// 导出文件生成(历史付款)
export function historyPayGet (data) {
  return fetch({
    method: 'post',
    url: '/applyTransfer/queryExportAsync',
    data
  })
}

// 还款勾稽
export function repaymentWriteOffList (data) {
  return fetch({
    method: 'post',
    url: '/repayment/book/unsettledApplies',
    data
  })
}

// 还款勾稽历史
export function repaymentHistoryList (data) {
  return fetch({
    method: 'post',
    url: '/report/query/repaymentHistory',
    data
  })
}

// 审批历史
export function approveHistoryList (bookId) {
  return fetch({
    method: 'post',
    url: '/repayment/book/auditSteps?bookId=' + bookId
    // data: {bookId}
  })
}

// 还款勾稽审核列表
export function repayWriteOffCheckList (data) {
  return fetch({
    method: 'post',
    url: '/repayment/book/toBeLeaderAuditedList',
    data
  })
}

// 财务还款确认
export function repayConfirmList (data) {
  return fetch({
    method: 'post',
    url: '/repayment/book/toBeCashierAuditedList',
    data
  })
}

// 到账银行下拉接口
export function dueBankList (applyId) {
  return fetch({
    method: 'post',
    url: '/repayment/book/miscellaneousBookInfo?applyId=' + applyId
  })
}

// 查询还款计算计划（弃用）
export function repaymentPlans (userId, billLoanNo, applyId) {
  return fetch({
    method: 'post',
    url: '/repayment/book/repaymentPlans',
    data: {userId, billLoanNo, applyId}
  })
}

// 查询还款计算计划（新)
export function queryRepaymentDetailInfo (data) {
  return fetch({
    method: 'post',
    url: '/repayment/book/queryRepaymentDetailInfo',
    data
  })
}

// 提交租金勾稽申请
export function rentRepaymentBook (data) {
  return fetch({
    method: 'post',
    url: '/repayment/book/addRentRepaymentBook',
    data
  })
}

// 付款流水号校验
export function repaySerialNoApi (data) {
  return fetch({
    method: 'post',
    url: '/repayment/book/checkRepaySerialNo',
    data
  })
}

// 提交提前结清勾稽申请
export function beforeRentRepaymentBook (data) {
  return fetch({
    method: 'post',
    url: '/repayment/book/addAdvanceSettleRepaymentBook',
    data
  })
}

// 提前结清计算
export function calculate (billLoanNo, userId) {
  return fetch({
    method: 'post',
    url: '/repayment/book/calculateAdvanceSettle',
    data: {billLoanNo, userId}
  })
}

// 勾稽详情
export function rentRepaymentInfo (bookId) {
  return fetch({
    method: 'post',
    url: '/repayment/book/bookDetail?id=' + bookId
  })
}

// 审核
export function leaderAudit (data) {
  return fetch({
    method: 'post',
    url: '/repayment/book/leaderAudit',
    data
  })
}

// 财务审核提交
export function cashierAudit (data) {
  return fetch({
    method: 'post',
    url: '/repayment/book/cashierAudit',
    data
  })
}

// 客户回款记录列表
export function customerRepayList (data) {
  return fetch({
    method: 'post',
    url: '/repayment/writeOff/reportPage',
    data
  })
}

// 客户回款记录下载
export function customerRepayDownload (data) {
  return fetch({
    method: 'post',
    url: '/report/download/loadRepaymentWriteOffReport',
    data
  })
}

// 回购金额
export function searchBuyBackAmount (applyId) {
  return fetch({
    method: 'get',
    url: '/repayment/book/searchBuyBackAmount',
    params: {applyId}
  })
}
// 回购申请提交
export function buyBackSubmit (data) {
  return fetch({
    method: 'post',
    url: '/repayment/book/addBuyBackBook',
    data
  })
}
// 回购审核提交
export function buyBackCheckSubmit (data) {
  return fetch({
    method: 'post',
    url: '/repayment/book/buyBackAudit',
    data
  })
}
// 回购审核结果轮询
export function buyBackCheckResultPolling (id, rollCount) {
  return fetch({
    method: 'post',
    url: '/repayment/book/rollBuyBackResult',
    data: {id, rollCount}
  })
}
// 财务确认审核结果轮询
export function financialCheckResultPolling (id, rollCount) {
  return fetch({
    method: 'post',
    url: '/repayment/book/rollAdvanceSettleResult',
    data: {id, rollCount}
  })
}

// 还款勾稽历史下载
export function repaymentHistoryListExport (data) {
  return fetch({
    method: 'post',
    url: '/report/file/repaymentHistory',
    data
  })
}

// 获取保证金台账列表
export function getDepositList (data) {
  return fetch({
    method: 'post',
    url: '/finance/excel/depositBillPages',
    data
  })
}

// 修改
export function editDepositList (data) {
  return fetch({
    method: 'post',
    url: '/finance/excel/updateDepositBill',
    data
  })
}

// 导入sp台账
export function importSPList (data) {
  return fetch({
    method: 'post',
    url: '/finance/excel/import',
    data
  })
}

// 导出
export function exportDepositList (data) {
  return fetch({
    method: 'post',
    url: '/finance/excel/export/depositBill',
    data
  })
}

// 对公扣款查询
export function getcutRepaymentApi (data) {
  return fetch({
    method: 'post',
    url: '/report/query/fundRepayInfo',
    data
  })
}

// 对公扣款下载
export function getcutRepaymentExportApi (data) {
  return fetch({
    method: 'post',
    url: '/report/file/fundRepayInfo',
    data
  })
}

// 对公扣款下载
export function prepareTrialBalance (data) {
  return fetch({
    method: 'post',
    url: '/repayment/book/prepareTrialBalance',
    data
  })
}
