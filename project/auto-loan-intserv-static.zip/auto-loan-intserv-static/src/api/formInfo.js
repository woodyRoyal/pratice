import fetch from '../utils/fetch'

// 个人件
export function proposerInfo (data) {
  return fetch({
    method: 'post',
    url: '/proposer/getProposerWithDefaultData?applyId=' + data.applyId
  })
}

// 企业件
export function companyInfomation (params) {
  return fetch({
    method: 'get',
    url: '/proposer/queryCompanyByApplyIdWithDefaultData',
    params
  })
}

// 查询联系人列表
export function contactList (data) {
  return fetch({
    method: 'post',
    url: '/proposer/queryContactsByBO',
    data
  })
}

// 查询担保人信息
export function getGuaranteeInfo (id) {
  return fetch({
    method: 'get',
    url: '/proposerSurety/queryProposerById',
    params: {id}
  })
}

// 车辆融资字典
export function financialDict (params) {
  return fetch({
    method: 'get',
    url: '/applyFinancing/getApplyFinancingDict',
    params
  })
}

// 获取融资信息
export function financialInfo (params) {
  return fetch({
    method: 'get',
    url: '/applyFinancing/getApplyFinancing',
    params
  })
}

// 保存融资信息
export function saveFinancialInfo (data) {
  return fetch({
    method: 'post',
    url: '/applyFinancing/saveOrUpdateApplyFinancing',
    data
  })
}

// 计算融资信息
export function caculateFinancialInfo (data) {
  return fetch({
    method: 'post',
    url: '/applyFinancing/calculateApplyFinancing',
    data
  })
}

// 获取车辆信息
export function vehicleInfo (params) {
  return fetch({
    method: 'get',
    url: '/car/queryCarInfoByApplyId',
    params
  })
}

// 渠道下拉
export function supplies (data) {
  return fetch({
    method: 'post',
    url: '/dealerInfo/queryChannelDropDown',
    data
  })
}

// 渠道信息的销售经理
export function saleManagerList (kind) {
  return fetch({
    method: 'get',
    url: '/intserv/manage/findUsersByKind',
    params: {kind}
  })
}
