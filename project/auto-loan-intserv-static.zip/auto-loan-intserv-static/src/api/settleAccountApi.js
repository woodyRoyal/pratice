import fetch from '../utils/fetch'

export default {
  tableData: function (data) {
    return fetch({
      method: 'post',
      url: '',
      data
    })
  }
}
