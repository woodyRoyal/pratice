import fetch from '../utils/fetch'

export function gpsReport (data) {
  return fetch({
    method: 'post',
    url: '/applyTransfer/queryGpsInfoByBO',
    data,
  })
}

export function gpsReportExport (data) {
  return fetch({
    method: 'post',
    url: '/applyTransfer/queryGpsExport',
    data,
  })
}

export function queryOperateInfo (data) {
  return fetch({
    method: 'post',
    url: '/report/manage/queryOperateInfo',
    data,
  })
}

export function operateInfoReportExport (data) {
  return fetch({
    method: 'post',
    url: '/report/download/loadOperateInfo',
    data,
  })
}

export function queryOperateInfoAsync (data) {
  return fetch({
    method: 'post',
    url: '/report/manage/queryOperateInfoAsync',
    data,
  })
}

export function queryReportResult (data) {
  return fetch({
    method: 'post',
    url: '/report/manage/queryReportResult',
    data,
  })
}