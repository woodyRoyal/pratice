import fetch from '../utils/fetch'

/* ----------菜单管理---------- */

// 获取菜单树
export function fetchMenuTree () {
  return fetch({
    url: 'restfulservice/rbacMenuService/findRbacMenuTree',
    method: 'get'
  })
}

// 新增或修改菜单
export function fetchSaveOrUpdateMenu (rbacMenu) {
  const data = {
    rbacMenu
  }
  return fetch({
    url: 'restfulservice/rbacMenuService/saveOrUpdate',
    method: 'post',
    data
  })
}

// 批量删除菜单
export function fetchDeleteMenuByIdList (idList) {
  const data = {
    idList
  }
  return fetch({
    url: 'restfulservice/rbacMenuService/deleteByIdList',
    method: 'post',
    data
  })
}

/* ----------用户管理---------- */

// 获取审批系统用户
export function fetchSyncAllUser () {
  return fetch({
    url: 'user/syncAllUser',
    method: 'post'
  })
}

// 获取用户列表
// export function fetchUserList (username, displayName, pageable) {
//   return fetch({
//     url: 'restfulservice/rbacUserService/findRbacUser',
//     method: 'get',
//     params: {username, displayName, pageable}
//   })
// }

// 获取角色列表
export function fetchRoleList2 () {
  return fetch({
    url: 'role/queryAllRoles',
    method: 'get'
  })
}

// 获取用户列表
export function fetchUserList (username, roleId, status, pageNo, pageSize) {
  const data = {
    username,
    roleId,
    status
  }
  return fetch({
    url: 'user/queryUserListByPage/' + pageNo + '/' + pageSize,
    method: 'post',
    data
  })
}

// 编辑、禁用、启用接口
export function fetchEditeOrEnableOrDisableUser (id, status, username, roleId) {
  const data = {
    id,
    status,
    username,
    roleId
  }
  return fetch({
    url: 'user/updUser',
    method: 'post',
    data
  })
}

// 获取用户名是否已存在 true存在 false不存在
export function fetchUsernameIsExists (username) {
  return fetch({
    url: 'restfulservice/rbacUserService/userNameExists',
    method: 'get',
    params: {username}
  })
}

// 新增或修改用户
export function fetchSaveOrUpdateUser (rbacUser) {
  const data = {
    rbacUser
  }
  return fetch({
    url: 'restfulservice/rbacUserService/saveOrUpdate',
    method: 'post',
    data
  })
}

// 修改用户角色
export function fetchUpdateUserRole (userId, rbacUserRoleList) {
  const data = {
    userId,
    rbacUserRoleList
  }
  return fetch({
    url: 'restfulservice/rbacUserService/saveRbacUserRole',
    method: 'post',
    data
  })
}

// 重置密码
export function fetchResetPassword (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/rbacUserService/resetPassword',
    method: 'post',
    data
  })
}

// 禁用
export function fetchDisableUser (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/rbacUserService/disable',
    method: 'post',
    data
  })
}

// 启用
export function fetchEnableUser (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/rbacUserService/enable',
    method: 'post',
    data
  })
}

// 锁定
export function fetchLockUser (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/rbacUserService/lock',
    method: 'post',
    data
  })
}

// 解锁
export function fetchUnlockUser (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/rbacUserService/unLock',
    method: 'post',
    data
  })
}

// 修改密码
export function fetchUpdatePassword (oldPassword, newPassword) {
  const data = {
    oldPassword, newPassword
  }
  return fetch({
    url: 'restfulservice/rbacUserService/updatePassword',
    method: 'post',
    data
  })
}

/* ----------分组管理---------- */

// 获取分组树
export function fetchGroupTree () {
  return fetch({
    url: 'restfulservice/rbacGroupService/findRbacGroupTree',
    method: 'get'
  })
}

// 获取分组列表
export function fetchGroupList (code, name, pageable) {
  return fetch({
    url: 'restfulservice/rbacGroupService/findRbacGroup',
    method: 'get',
    params: {code, name, pageable}
  })
}

// 新增或修改分组
export function fetchSaveOrUpdateGroup (rbacGroup) {
  const data = {
    rbacGroup
  }
  return fetch({
    url: 'restfulservice/rbacGroupService/saveOrUpdate',
    method: 'post',
    data
  })
}

// 批量删除分组
export function fetchDeleteGroupByIdList (idList) {
  const data = {
    idList
  }
  return fetch({
    url: 'restfulservice/rbacGroupService/deleteByIdList',
    method: 'post',
    data
  })
}

/* ----------角色管理---------- */

// // 获取角色列表
// export function fetchRoleList (name, pageable) {
//   return fetch({
//     url: 'restfulservice/rbacRoleService/findRbacRole',
//     method: 'get',
//     params: {name, pageable}
//   })
// }

// 启用或禁用角色
export function fetchForbidRole (id, valid) {
  return fetch({
    url: 'role/forbid/' + id + '/' + valid,
    method: 'post'
  })
}
// 获取角色列表
export function fetchRoleList (pageNo, pageSize, totalRecord) {
  const data = {
    pageNo, pageSize, totalRecord
  }
  return fetch({
    url: 'role/queryRoleListByPage',
    method: 'post',
    data
  })
}

// 新增角色
export function fetchAddRole (query) {
  const data = query
  return fetch({
    url: 'role/add',
    method: 'post',
    data
  })
}

// 修改角色
export function fetchUpdateRole (query) {
  const data = query
  return fetch({
    url: 'role/update',
    method: 'post',
    data
  })
}

// 删除角色
export function fetchDeleteRoleById (id) {
  return fetch({
    url: 'role/delete/' + id,
    method: 'post'
  })
}

/* ----------权限管理---------- */

// // 获取权限树
// export function fetchPermissionTree () {
//   return fetch({
//     url: 'restfulservice/rbacPermissionService/findRbacPermissionTree',
//     method: 'get'
//   })
// }

// 获取权限树
export function fetchPermissionTree () {
  return fetch({
    url: 'menu/queryAllMenus',
    method: 'get'
  })
}

// 获取权限列表
export function fetchPermissionList (name, pageable) {
  return fetch({
    url: 'restfulservice/rbacPermissionService/findRbacPermission',
    method: 'get',
    params: {name, pageable}
  })
}

// 新增或修改权限
export function fetchSaveOrUpdatePermission (rbacPermission) {
  const data = {
    rbacPermission
  }
  return fetch({
    url: 'restfulservice/rbacPermissionService/saveOrUpdate',
    method: 'post',
    data
  })
}

// 批量删除权限
export function fetchDeletePermissionByIdList (idList) {
  const data = {
    idList
  }
  return fetch({
    url: 'restfulservice/rbacPermissionService/deleteByIdList',
    method: 'post',
    data
  })
}

/* ----------定时任务---------- */

// 获取所有任务列表
export function fetchScheduleList () {
  return fetch({
    url: 'scheduleTask/getAllTask',
    method: 'get'
  })
}

// 新增或修改任务
export function fetchSaveOrUpdateSchedule (task) {
  return fetch({
    url: 'scheduleTask/saveOrUpdateTask',
    method: 'post',
    data: task
  })
}

// 删除任务
export function fetchDeleteScheduleById (taskId) {
  return fetch({
    url: 'scheduleTask/deleteTask/' + taskId,
    method: 'post'
  })
}

// 暂停任务
export function fetchPauseScheduleById (taskId) {
  return fetch({
    url: 'scheduleTask/pauseTask/' + taskId,
    method: 'post'
  })
}

// 重启任务
export function fetchResumeScheduleById (taskId) {
  return fetch({
    url: 'scheduleTask/resumeTask/' + taskId,
    method: 'post'
  })
}

// 执行一次任务
export function fetchRunOnceScheduleById (taskId) {
  return fetch({
    url: 'scheduleTask/runOnceTask/' + taskId,
    method: 'post'
  })
}

// 启动任务
export function fetchStartScheduleById (taskId) {
  return fetch({
    url: 'scheduleTask/startTask/' + taskId,
    method: 'post'
  })
}

// 停止任务
export function fetchStopScheduleById (taskId) {
  return fetch({
    url: 'scheduleTask/stopTask/' + taskId,
    method: 'post'
  })
}

// 删除任务
export function handleDeleteSchedule (taskId) {
  return fetch({
    url: 'scheduleTask/deleteTask/' + taskId,
    method: 'post'
  })
}

/* ----------参数设置---------- */
/* 参数分类 */

// 获取参数分类列表
export function fetchParamClassList (classCode, className, pageable) {
  return fetch({
    url: 'restfulservice/paramClassService/findParamClass',
    method: 'get',
    params: {classCode, className, pageable}
  })
}

// 删除参数分类
export function fetchDeleteParamClassById (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/paramClassService/deleteById',
    method: 'post',
    data
  })
}

// 新增或修改参数分类
export function fetchSaveOrUpdateParamClass (paramClass) {
  const data = {
    paramClass
  }
  return fetch({
    url: 'restfulservice/paramClassService/saveOrUpdate',
    method: 'post',
    data
  })
}

/* 参数 */

// 获取参数列表
export function fetchParamList (classId, pageable) {
  return fetch({
    url: 'restfulservice/paramParamService/findParamParam',
    method: 'get',
    params: {classId, pageable}
  })
}

// 删除参数
export function fetchDeleteParamById (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/paramParamService/deleteById',
    method: 'post',
    data
  })
}

// 新增或修改参数
export function fetchSaveOrUpdateParam (paramParam) {
  const data = {
    paramParam
  }
  return fetch({
    url: 'restfulservice/paramParamService/saveOrUpdate',
    method: 'post',
    data
  })
}
