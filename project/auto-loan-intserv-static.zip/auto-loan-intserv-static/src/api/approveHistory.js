import fetch from '../utils/fetch'

export function approveHistory (data) {
  return fetch({
    method: 'post',
    url: '/approve/queryComplexApproveRecord',
    data
  })
}

// 历史关联申请
export function applyRelateList (data) {
  return fetch({
    method: 'post',
    url: '/apply/applyRelate',
    data
  })
}
