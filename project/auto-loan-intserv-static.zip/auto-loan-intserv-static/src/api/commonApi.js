import fetch from '../utils/fetch'
export const UPLOAD_URL = process.env.NODE_ENV === 'development' ? 'http://t1-cdw.2345.com' + process.env.FILEUPLOAD_URL : window.location.origin + process.env.FILEUPLOAD_URL

// 所有节点
export const dict = {
  allCurrentNodeDict: {
    0: '发起流程',
    1: '待提报',
    2: '一级代理商复核',
    3: '风控审核',
    4: '风控初审',
    5: '风控复核',
    6: '合同录入',
    7: '发起请款',
    8: '请款资料审核',
    9: '放款经办',
    10: '放款复核',
    11: '贷后资料归档',
    12: '贷后资料归档审核',
    13: '贷后资料已归档',
    14: '结束',
    101: '财务放款中'
  }
}

// get字典接口
export function dictionary (params) {
  return fetch({
    method: 'get',
    url: '/dictionary/getDictionaryByCategory',
    params
  })
}

// post字典接口
export function dictionaryPost (data) {
  return fetch({
    method: 'post',
    url: '/dictionary/getDictionaryByCategoryList',
    data
  })
}

// 获取地区树
export function getTreeArea () {
  return fetch({
    method: 'get',
    url: '/address/queryProvincesAndCities'
  })
}
// 获取所有省份
export function getProvince () {
  let belongKey = '000'
  return fetch({
    method: 'get',
    url: 'address/queryAddressByBelongKey',
    params: {belongKey}
  })
}

// 获取tabs个数
export function tabList (params) {
  return fetch({
    method: 'get',
    url: 'apply/queryCreditPersonInfo',
    params
  })
}

// 审核节点
export function currentNodeLists () {
  return fetch({
    method: 'get',
    url: '/apply/getWorkbenchNodeList',
    params: {workbenchStatus: 6}
  })
}

// 获取资源树
export function getSourceTree () {
  let rootId = 0
  return fetch({
    url: 'intserv/manage/resourceTree',
    method: 'get',
    params: {rootId}
  })
}

// 获取所有岗位
export function getAllPost () {
  return fetch({
    url: 'intserv/manage/allPost',
    method: 'get'
  })
}

// 公告列表
export function noticeList (data) {
  return fetch({
    method: 'post',
    url: '/notice/queryNoticeList',
    data
  })
}

// 公告保存
export function noticeSave (data) {
  return fetch({
    method: 'post',
    url: '/notice/saveNotice',
    data
  })
}
