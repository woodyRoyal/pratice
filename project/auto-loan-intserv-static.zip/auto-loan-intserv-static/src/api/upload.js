import fetch from '../utils/fetch'

// 电核文件
export function telVerifyData (applyId) {
  return fetch({
    method: 'get',
    url: '/call/queryCallList',
    params: {applyId}
  })
}

// 提报文件/请款和贷后文件 资料类别
export function getFileMenuTree (data) {
  return fetch({
    method: 'post',
    url: '/proposerImage/getImageMenuPc',
    data
  })
}

// 文件拉取（单个拉取）
export function filesGet (data) {
  return fetch({
    method: 'post',
    url: '/proposerImage/getImageDataPc',
    data
  })
}

// 文件拉取（多个拉取）
export function filesListGet (data) {
  return fetch({
    method: 'post',
    url: 'proposerImage/getImageDataPcSplitCategory',
    data
  })
}

// 文件保存（单个保存）
export function saveUploadFiles (data) {
  return fetch({
    method: 'post',
    url: '/fileRecord/saveFileCategory',
    data
  })
}

// 文件保存（多个保存）
export function saveUploadFilesList (data) {
  return fetch({
    method: 'post',
    url: 'fileRecord/saveFileCategoryList',
    data
  })
}

// 文件删除
export function deleteImgItem (data) {
  return fetch({
    method: 'post',
    url: '/fileRecord/removeSingle',
    data
  })
}

// 经销商上线文件菜单
export function dealerImgMenu (params) {
  return fetch({
    method: 'get',
    url: '/proposerImage/getImageMenuByType',
    params
  })
}

// 贷后审核首页查询 驾驶证文件等接口
export function daihouGetFile (params) {
  return fetch({
    method: 'get',
    url: '/proposerImage/getListImageDataByType',
    params
  })
}

// 提前结清勾稽模块的文件拉取
export function financialGetFile (params) {
  return fetch({
    method: 'get',
    url: '/proposerImage/getImageDataByType',
    params
  })
}

// 提前结清勾稽模块的文件上传
export function financialSaveFile (data) {
  return fetch({
    method: 'post',
    url: '/fileRecord/saveOrUpdateFileRecordNew',
    data
  })
}
