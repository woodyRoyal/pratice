import fetch from '../utils/fetch'

// 银行卡鉴权
export function checkBankCard (data) {
  return fetch({
    method: 'post',
    url: '/bankcard/signRequest',
    data
  })
}

// 判断是否需要健全
export function checkNeedCheck (data) {
  return fetch({
    method: 'post',
    url: '/bankcard/needSign',
    data
  })
}

// 确认验证码
export function msgCodeConfirm (data) {
  return fetch({
    method: 'post',
    url: '/bankcard/signConfirm',
    data
  })
}
