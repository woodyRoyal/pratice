import fetch from '../utils/fetch'

export const FANGKUAN_WS_URL = process.env.NODE_ENV === 'development' ? process.env.FANGKUAN_WS_URL : 'wss://' + window.location.host + process.env.FANGKUAN_WS_URL

// 获取列表数据
export function getFkList (data) {
  return fetch({
    method: 'post',
    url: '/loanHome/queryLoanReviewHomeList',
    data
  })
}

// 检验是否可以办理
export function checkToDetail (applyId) {
  return fetch({
    method: 'get',
    url: '/intserv/manage/bindingTask',
    params: {applyId}
  })
}

export function getApplyMoneyInfo (applyId) {
  return fetch({
    method: 'get',
    url: '/requestPayment/queryPaymentInfoByApplyId',
    params: {applyId}
  })
}

export function getCompactInfo (applyId) {
  return fetch({
    method: 'get',
    url: '/contract/queryContractInfoByApplyId',
    params: {applyId}
  })
}

// GPS定位
export function gpsLocation (applyId) {
  return fetch({
    method: 'get',
    url: '/intserv/manage/locationGpsInfo',
    params: {applyId}
  })
}

// GPS图片
export function getGpsImg (data) {
  return fetch({
    method: 'post',
    url: '/apply/data/queryGpsImageInfo',
    data
  })
}

export function receiptInfo (applyId) {
  return fetch({
    method: 'get',
    url: '/requestPayment/getCarInvoiceDetailInfo',
    params: {applyId}
  })
}

// 获取sp台账列表
export function getSPList (data) {
  return fetch({
    method: 'post',
    url: '/finance/excel/spServiceBillPages',
    data
  })
}

// 修改
export function editSPList (data) {
  return fetch({
    method: 'post',
    url: '/finance/excel/updateSpServiceFeeBill',
    data
  })
}

// 导入sp台账
export function importSPList (data) {
  return fetch({
    method: 'post',
    url: '/finance/excel/import',
    data
  })
}

// 导出
export function exportSpList (data) {
  return fetch({
    method: 'post',
    url: '/finance/excel/export/spServiceFeeBill',
    data
  })
}
