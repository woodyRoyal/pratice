<template>
  <div>
    <span class="form-title">客户还款信息</span>
    <el-table :data="tableData" class="tableData">
      <el-table-column label="审批节点" prop=""></el-table-column>
      <el-table-column label="审批结果">
        <template slot-scope="scope">
          {{scope.row.auditResult === 1 ? '通过' : '退回申请'}}
        </template>
      </el-table-column>
      <el-table-column label="审批备注" prop="auditRemark"></el-table-column>
      <el-table-column label="审批人员" prop=""></el-table-column>
      <el-table-column label="审批时间" prop=""></el-table-column>
    </el-table>
    <div class="clearfix">
      <el-pagination
        class="tablePagination"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="page.currentPage"
        :page-size="page.pageSize"
        :page-sizes="page.pageSizesArr"
        layout="total, sizes, prev, pager, next, jumper"
        :total="page.total">
      </el-pagination>
    </div>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        tableData: [],
        page: {
          currentPage: 1,
          pageSize: 10,
          pageSizesArr: [10, 20, 30, 40],
          total: 0
        }
      }
    },
    methods: {
      handleSizeChange () {},
      handleCurrentChange () {}
    }
  }
</script>
<style lang="scss">
  .tablePagination {
    float: right;
    margin: 5px 0;
  }
  .form-title{
    font-size: 14px;
    color: #333;
    font-weight: 700;
  }
  .tableData{
    margin-top: 5px;
  }
</style>
