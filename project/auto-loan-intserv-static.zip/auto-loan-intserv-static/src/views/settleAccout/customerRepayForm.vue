<template>
  <div class="customerRepayInfoForm">
    <span class="form-title">客户还款信息</span>
    <el-form :model="customerRepayInfo" size="small">
      <el-row :gutter="5">
        <el-col :span="6">
          <el-form-item label="提前还款总金额" label-width="110px" class="redLable">
            <el-input v-model="customerRepayInfo.region" disabled class="redFont"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="提前还款本金" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="提前还款利息" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="提前还款费用" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="5">
        <el-col :span="6">
          <el-form-item label="已到期本金" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled class="redFont"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="已到期利息" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="已到期费用" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="逾期罚息" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="5">
        <el-col :span="6">
          <el-form-item label="逾期复利" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled class="redFont"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="违约金" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="滞缴金额" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <el-form :model="customerRepayInfo" size="small">
      <el-row :gutter="5">
        <el-col :span="6">
          <el-form-item label="提前还款总金额" label-width="110px" class="redLable">
            <el-input v-model="customerRepayInfo.region" disabled class="redFont"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="提前还款本金" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="提前还款利息" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="提前还款费用" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="5">
        <el-col :span="6">
          <el-form-item label="已到期本金" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled class="redFont"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="已到期利息" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="已到期费用" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="逾期罚息" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="5">
        <el-col :span="6">
          <el-form-item label="逾期复利" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled class="redFont"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="违约金" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="滞缴金额" label-width="110px" >
            <el-input v-model="customerRepayInfo.region" disabled></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        customerRepayInfo: {}
      }
    }
  }
</script>
<style lang="scss">
  .form-title{
    font-size: 14px;
    color: #333;
    font-weight: 700;
    display: block;
    margin-bottom: 5px;
  }
  .customerRepayInfoForm{
    margin-top: 5px;
    .el-form-item--mini.el-form-item, .el-form-item--small.el-form-item {
      margin-bottom: 8px;
    }
    .redFont.el-input.is-disabled .el-input__inner, .el-cascader.is-disabled .el-cascader__label {
      color: red;
    }
    .el-form-item.redLable.el-form-item--small {
      .el-form-item__label{
        color: red;
      }
    }
    .el-form {
      border: 1px solid #ccc;
      padding: 8px 8px 3px;
    }
    .el-form:nth-child(2n-1) {
      border-top: none;
    }
  }
</style>
