<template>
  <div>
    <el-form size="small" :inline="true" v-model="queryForm">
      <el-form-item label="申请编号">
        <el-input placeholder="输入申请编号" maxlength="8" v-model="queryForm.applyId"></el-input>
      </el-form-item>
      <el-form-item label="客户名称">
        <el-input placeholder="输入客户名称" maxlength="20" v-model="queryForm.name"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="queryReset">重置</el-button>
        <el-button type="primary" @click="queryData">查询</el-button>
      </el-form-item>
    </el-form>
    <el-table :data="tableData" border>
      <el-table-column label="申请编号" prop=""></el-table-column>
      <el-table-column label="客户名称" prop="name"></el-table-column>
      <el-table-column label="申请类型" prop="applyType"></el-table-column>
      <el-table-column label="企业/挂靠名称">
        <template slot-scope="scope">
          {{scope.row.companyName === '' ? '/' : scope.row.companyName}}
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="mini">资方结清</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--操作弹窗-->
    <el-dialog title="资方结清" :visible.sync="dialogFormVisible" width="80%" class="customerRepayInfoDialog">
      <!--<el-table :data="customerRepayTable">-->
        <!--<el-table-column label="期数" prop="term"></el-table-column>-->
        <!--<el-table-column label="应还日期" prop="term"></el-table-column>-->
        <!--<el-table-column label="月租" prop="term"></el-table-column>-->
        <!--<el-table-column label="本金" prop="term"></el-table-column>-->
        <!--<el-table-column label="利息" prop="term"></el-table-column>-->
        <!--<el-table-column label="剩余本金" prop="term"></el-table-column>-->
        <!--<el-table-column label="还款状态">-->
          <!--<template slot-scope="scope">-->
            <!--{{}}-->
          <!--</template>-->
        <!--</el-table-column>-->
        <!--<el-table-column label="逾期天数">-->
          <!--<template slot-scope="scope">-->
            <!--{{}}-->
          <!--</template>-->
        <!--</el-table-column>-->
      <!--</el-table>-->
      <!--&lt;!&ndash; 分页 &ndash;&gt;-->
      <!--<div class="clearfix">-->
        <!--<el-pagination-->
          <!--class="tablePagination"-->
          <!--@size-change="customerRepayHandleSizeChange"-->
          <!--@current-change="customerRepayHandleCurrentChange"-->
          <!--:current-page="customerRepayTablePage.currentPage"-->
          <!--:page-size="customerRepayTablePage.pageSize"-->
          <!--:page-sizes="customerRepayTablePage.pageSizesArr"-->
          <!--layout="total, sizes, prev, pager, next, jumper"-->
          <!--:total="customerRepayTablePage.total">-->
        <!--</el-pagination>-->
      <!--</div>-->
      <CustomerRepayTable></CustomerRepayTable>
      <div class="settleApply-customerRepayInfoForm">
        <span>客户还款信息</span>
        <el-form :model="customerRepayInfo" size="small" :rules="customerRepayInfoRules" ref="customerRepayInfo">
          <el-row>
            <el-col :span="8">
              <el-form-item label="提前还款金额" label-width="107px" class="is-required">
                <el-input v-model="customerRepayInfo.name" disabled class="redFont"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="5">
            <el-col :span="8">
              <el-form-item label="提前还款本金" label-width="107px" >
                <el-input v-model="customerRepayInfo.region" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="提前还款利息" label-width="107px" >
                <el-input v-model="customerRepayInfo.region" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="提前还款费用" label-width="107px" >
                <el-input v-model="customerRepayInfo.region" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="5">
            <el-col :span="8">
              <el-form-item label="已到期本金" label-width="107px" >
                <el-input v-model="customerRepayInfo.region" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="已到期利息" label-width="107px" >
                <el-input v-model="customerRepayInfo.region" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="已到期费用" label-width="107px" >
                <el-input v-model="customerRepayInfo.region" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="5">
            <el-col :span="8">
              <el-form-item label="逾期罚息" label-width="107px" >
                <el-input v-model="customerRepayInfo.region" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="逾期复利" label-width="107px" >
                <el-input v-model="customerRepayInfo.region" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="违约金" label-width="107px" >
                <el-input v-model="customerRepayInfo.region" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="5">
            <el-col :span="8">
              <el-form-item label="溢缴费用" label-width="107px" >
                <el-input v-model="customerRepayInfo.name" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item label="备注信息" label-width="107px" prop="remark">
            <el-input v-model="customerRepayInfo.remark" autocomplete="off" type="textarea" :autosize="{minRows: 3}"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="customerRepayInfo-dialog-footer">
        <el-button type="primary" size="mini" @click="showFileDialog">上传凭证</el-button>
        <el-button type="primary" size="mini" @click="settleApplySubmit">提交申请</el-button>
      </div>
    </el-dialog>
    <!--文件上传弹窗-->
    <el-dialog title="请上传相关附件" :visible.sync="fileDialogVisible" class="write-off-dialog" :show-close="false">
      <p>温馨提示:系统支持上传的文件类型(*.pdf,*.docx,*.doc,*.jpg,*.jpeg,*.bmp,*.png,*.zip,*.rar,*.msg,*.eml,*.txt,*.wav</p>
      <p>单个word文件最大不能超过50.0MB;单个excel文件最大不能超过50.0MB;单个图片最大不能超过50.0MB;单个pdf文件最大不能超过50.0MB;单个压缩包文件最大不能超过20.0MB;</p>
      <FileUpload :pictureList="pictureList" @savePicItem="savePicItemFn"></FileUpload>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeFileDialog" size="mini">关 闭</el-button>
        <el-button type="primary" @click="fileDialogVisible = false" size="mini">保 存</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import settleApplyApi from '../../api/settleAccountApi'
  import FileUpload from '../../components/DialoginnerFileupload/fileupload'
  import CustomerRepayTable from './customerRepayTable'
  export default {
    data () {
      return {
        queryForm: {
          applyId: null,
          name: ''
        },
        tableData: [],
        dialogFormVisible: false,
        customerRepayTable: [],
        customerRepayTablePage: {
          currentPage: 1,
          pageSize: 10,
          pageSizesArr: [10, 20, 30, 40],
          total: 0
        },
        customerRepayInfo: {
          name: '22.00'
        },
        customerRepayInfoRules: {
          remark: [{required: true, message: '内容不可为空', trigger: 'blur'}]
        },
        fileDialogVisible: false,
        pictureList: [{
          dictKey: 'book_file',
          fileRecordVOList: [],
          name: '还款勾稽凭证'
        }]
      }
    },
    components: { FileUpload, CustomerRepayTable },
    methods: {
      queryReset () {
        this.queryForm = {
          applyId: null,
          name: ''
        }
        this.queryData()
      },
      queryData () {
        settleApplyApi.tableData().then(res => {
          if (res.data.respCode === '1000') this.tableData = res.data.body
        }).catch(err => { console.log(err) })
      },
      // 提交申请
      settleApplySubmit () {
        this.$refs['customerRepayInfo'].validate(valid => {})
      },
      // 上传凭证
      showFileDialog () {
        this.fileDialogVisible = true
      },
      // 保存图片
      savePicItemFn (val) {
        this.pictureList.forEach(item => {
          if (item.dictKey === val.item.dictKey) {
            item.fileRecordVOList.push(val.data)
          }
        })
      },
      // 关闭
      closeFileDialog () {
        this.fileDialogVisible = false
        this.pictureList.forEach(item => {
          item.fileRecordVOList = []
        })
      }
    }
  }
</script>
<style lang="scss">
  .tablePagination {
    float: right;
    margin: 5px 0;
  }
  .settleApply-customerRepayInfoForm{
    .el-form-item--mini.el-form-item, .el-form-item--small.el-form-item {
      margin-bottom: 8px;
    }
    .redFont.el-input.is-disabled .el-input__inner, .el-cascader.is-disabled .el-cascader__label {
      color: red;
    }
  }
  .customerRepayInfo-dialog-footer{
    display: flex;
    justify-content: center;
  }
  .customerRepayInfoDialog {
    .el-dialog__header {
      padding: 10px 20px;
    }
    .el-dialog__body{
      padding: 0 20px;
    }
  }
</style>
