<template>
  <!--提报附件-->
  <div ref="applyTbUploadWrap" class="apply-tb-upload-wrap">
    <!--文件上传-->
    <FileUpload
      applyNode="identity_file"
      :showSaveButton="true"
      :isSaveLoading="isSaveLoading"
      :hideSideTitle="false"
      :hideAllUploadSwitch="false"
      :hideTree="false"
      :hideDeleteBtn="false"
      :necessaryUploadData="requiredFilesList"
      :unNecessaryUploadData="notRequiredFilesList"
      :optionalTreeData="optionalFileKindsTreeData"
      @changeUnNecessaryUploadData="changeUnNecessaryUploadDataHandle"
      @changeNecessaryUploadData="changeNecessaryUploadDataHandle"
      @showPicView="showPicViewHandle"
      @deleteFileItem='deleteFileItemHandle'
      @saveUploadFiles="saveUploadFilesHandle"
    ></FileUpload>
    <!--电核文件-->
    <PhoneHistory :telVerifyData="telVerifyData"></PhoneHistory>
    <!--<div>
      <h5>电核文件</h5>
      <el-table :data="telVerifyData">
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="电核对象">
          <template slot-scope="scope">
            {{phoneRelationDict[scope.row.relationType] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="手机号/归属地">
          <template slot-scope="scope">
            {{scope.row.phoneBelong || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="电联结果">
          <template slot-scope="scope">
            {{callingResultDict[scope.row.callResult] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="支付宝">
          <template slot-scope="scope">
            {{alipayDict[scope.row.aliPay] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="微信">
          <template slot-scope="scope">
            {{wechatDict[scope.row.weChat] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="审批备注">
          <template slot-scope="scope">
            {{scope.row.remark || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="审核节点">
          <template slot-scope="scope">
            {{dict.allCurrentNodeDict[scope.row.currentNode + ''] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="操作人">
          <template slot-scope="scope">
            {{scope.row.operatorName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="结束时间">
          <template slot-scope="scope">
            {{scope.row.createAt || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <a :href="scope.row.voicePath" target="_blank" class="voiceFile">{{formatSecondEn1(scope.row.chatDuration / 1000)}}</a>
          </template>
        </el-table-column>
      </el-table>
    </div>-->
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import {formatSecondEn1} from '../../../utils/formatDate'
  import {deleteFileApiCallback} from '../../../utils/constant'
  import {getFileMenuTree, filesGet, saveUploadFiles, deleteImgItem, telVerifyData} from '../../../api/upload'
  import {dict} from '../../../api/commonApi.js'
  import FileUpload from '../../../components/fileUpload/index'
  import PhoneHistory from '../phoneHistory/phoneHistory'
  export default {
    data () {
      return {
        formatSecondEn1,
        dict,
        optionalFileKindsTreeData: [], // 文件树
        defaultProps: {
          children: 'list',
          label: 'dictName'
        },
        requiredFilesList: [], // 必传文件
        notRequiredFilesList: [], // 非必传文件
        telVerifyData: [], // 电核文件
        isSaveLoading: false,
        isDownload: false
      }
    },
    computed: {
      ...mapGetters(['applyId', 'phoneRelationDict', 'alipayDict', 'wechatDict', 'callingResultDict'])
    },
    mounted () {
      this.fileMenuList()
      this.getFilesData()
      this.getTelVerifyData()
      this.autoHeight()
      window.addEventListener('resize', this.autoHeight)
    },
    destroyed () {
      window.removeEventListener('resize', this.autoHeight)
    },
    components: { FileUpload, PhoneHistory },
    methods: {
      // 选传文件树
      fileMenuList () {
        getFileMenuTree({applyId: this.applyId, categoryList: [], showFaultFile: false}).then(res => {
          if (res.data.respCode === '1000') this.optionalFileKindsTreeData = res.data.body
        })
      },
      // 获取文件
      getFilesData () {
        filesGet({applyId: this.applyId, showFaultFile: true}).then(res => {
          if (res.data.respCode === '1000') {
            const {requiredFileCategoryListVos, notRequiredFileCategoryListVos} = res.data.body
            this.requiredFilesList = requiredFileCategoryListVos
            this.notRequiredFilesList = notRequiredFileCategoryListVos
          }
        }).catch(error => { console.log(error) })
      },
      // 保存文件
      saveUploadFilesHandle () {
        this.isSaveLoading = true
        let apiParams = {applyId: this.applyId, requiredFileCategoryListVos: this.requiredFilesList, notRequiredFileCategoryListVos: this.notRequiredFilesList}
        saveUploadFiles(apiParams).then(res => {
          this.isSaveLoading = false
          if (res.data.respCode === '1000') {
            this.$message.success('保存成功')
            this.getFilesData()
          }
        }).catch(error => {
          this.isSaveLoading = false
          console.log(error)
        })
      },
      /* // 删除回调
      deleteFileApiCallback (data) {
        let copyImgItem = JSON.parse(JSON.stringify(data.imgItem))
        copyImgItem.relatedId = this.applyId
        copyImgItem.relatedGroup = 'other_file'
        copyImgItem.fileCategory = 'fault_file'
        let forEachData = []
        let faultFileExists = false
        forEachData = data.isRequired ? this.requiredFilesList : this.notRequiredFilesList
        // 删除
        forEachData.forEach(item => {
          item.pictureListVOList.forEach(item => {
            if (item.dictKey === data.imgItem.fileCategory) item.fileRecordVOList.splice(data.index, 1)
          })
        })
        // 添加
        if (this.notRequiredFilesList.length) {
          this.notRequiredFilesList.forEach(item => {
            item.pictureListVOList.forEach(k => {
              if (k.dictKey === 'fault_file') faultFileExists = !faultFileExists
            })
          })
          if (faultFileExists) { // 有
            this.notRequiredFilesList.forEach(item => {
              item.pictureListVOList.forEach(k => {
                if (k.dictKey === 'fault_file') k.fileRecordVOList.push({...copyImgItem})
              })
            })
          } else { // 无
            let checkOtherFile = this.notRequiredFilesList.filter(item => {
              if (item.dictCategory === 'other_file') {
                item.pictureListVOList.push({
                  dictKey: 'fault_file',
                  fileRecordVOList: [{...copyImgItem}],
                  name: '误传文件'})
              } else {
                return item
              }
            })
            if (!checkOtherFile.length) {
              this.notRequiredFilesList.push(
                {categoryDesc: '其他文件',
                  dictCategory: 'other_file',
                  pictureListVOList: [{
                    dictKey: 'fault_file',
                    fileRecordVOList: [{...copyImgItem}],
                    name: '误传文件'}]
                }
              )
            }
          }
        } else {
          this.notRequiredFilesList.push(
            {categoryDesc: '其他文件',
              dictCategory: 'other_file',
              pictureListVOList: [{
                dictKey: 'fault_file',
                fileRecordVOList: [{...copyImgItem}],
                name: '误传文件'}]
            }
          )
        }
      }, */
      // 删除文件
      deleteFileItemHandle (data) {
        let copyImgItem = JSON.parse(JSON.stringify(data.imgItem))
        copyImgItem.relatedId = this.applyId
        copyImgItem.relatedGroup = 'other_file'
        copyImgItem.fileCategory = 'fault_file'
        deleteImgItem(copyImgItem).then(res => {
          if (res.data.respCode === '1000') {
            const _vue = this
            const deleteCbParam = {
              _vue,
              relatedId: this.applyId,
              fileData: data,
              dictCategory: 'other_file',
              dictKey: 'fault_file'
            }
            deleteFileApiCallback(deleteCbParam)
            this.$message.success('删除成功')
          }
        }).catch(err => { console.log(err) })
      },
      // 文件预览
      showPicViewHandle (data) {
        this.$emit('getPicViewData', data)
      },
      // 替换非必传文件
      changeUnNecessaryUploadDataHandle (data) {
        this.notRequiredFilesList = data.notRequiredFilesList
      },
      // 替换必传文件
      changeNecessaryUploadDataHandle (data) {
        this.requiredFilesList = data.requiredFilesList
      },
      // 电核文件
      getTelVerifyData () {
        telVerifyData(this.applyId).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            data.forEach(item => {
              item.phoneBelong = item.phone + '/' + item.belongPlace
            })
            this.telVerifyData = data
          }
        }).catch(error => { console.log(error) })
      },
      // 自适应高度
      autoHeight () {
        let clientHeight = document.documentElement.clientHeight
        this.$refs['applyTbUploadWrap'].style.height = (clientHeight - 55) + 'px'
      }
    }
  }
</script>

<style lang="scss" scoped>
  .voiceFile{
    text-decoration: underline;
    color: #2fa4e7;
  }
  .apply-tb-upload-wrap{
    overflow-y: auto;
  }
</style>
