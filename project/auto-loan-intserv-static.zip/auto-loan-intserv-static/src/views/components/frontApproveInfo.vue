<template>
  <div class="wrap">
    <div class="tableTitle clearfix">
      <span class="table-title-word">预审批信息</span>
    </div>
    <el-table :data="approveData" border>
      <el-table-column label="序号" align="center" type="index"></el-table-column>
      <el-table-column label="姓名" align="center" width="60%">
        <template slot-scope="scope">
            {{scope.row.customerName || '/'}}
        </template>
      </el-table-column>
      <el-table-column label="身份" align="center">
        <template slot-scope="scope">
            {{phoneRelationDict[scope.row.relation] || '/'}}
        </template>
      </el-table-column>
      <el-table-column label="身份证号" align="center">
        <template slot-scope="scope">
            {{scope.row.customerIdNo || '/'}}
        </template>
      </el-table-column>
      <el-table-column label="电话" align="center">
        <template slot-scope="scope">
            {{scope.row.customerPhone || '/'}}
        </template>
      </el-table-column>
      <el-table-column label="银行卡号" align="center">
        <template slot-scope="scope">
            {{scope.row.bankCardNum || '/'}}
        </template>
      </el-table-column>
      <el-table-column label="预审批时间" align="center">
        <template slot-scope="scope">
            {{scope.row.preAduitTime || '/'}}
        </template>
      </el-table-column>
      <el-table-column label="预审批结果" align="center">
        <template slot-scope="scope">
            {{scope.row.result || '/'}}
        </template>
      </el-table-column>
      <el-table-column label="不通过原因" align="center">
        <template slot-scope="scope">
            {{scope.row.reason || '/'}}
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
  import { approveList } from '../../api/caseHandle.js'
  import { mapGetters } from 'vuex'
  export default {
    data () {
      return {
        approveData: []
      }
    },
    computed: {
      ...mapGetters(['applyId', 'phoneRelationDict'])
    },
    mounted () {
      this.getApproveList(this.applyId)
    },
    methods: {
      getApproveList (val) {
        approveList({applyId: val}).then(res => {
          if (res.data.respCode === '1000') this.approveData = res.data.body
        }).catch(error => { console.log(error) })
      }
    }
  }
</script>
<style lang="scss" scoped>
  @import "style.scss";
</style>
