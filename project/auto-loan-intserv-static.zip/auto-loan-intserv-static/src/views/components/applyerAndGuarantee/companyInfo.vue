<template>
  <div class="companyWrap">
    <div class="formModuleTitle"><span>企业信息</span></div>
    <el-form label-position="top" size="mini" :model="companyInfo">
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="企业名称">
            <el-input disabled v-model="companyInfo.name"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="组织机构代码（或统一社会信用代码）">
            <el-input disabled v-model="companyInfo.creditId"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="营业执照编号">
            <el-input disabled v-model="companyInfo.businessLicense"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="法人姓名">
            <el-input disabled v-model="companyInfo.legalPerson"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="法人身份证号">
            <el-input disabled v-model="companyInfo.legalId"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="法人手机号码">
            <el-input disabled v-model="companyInfo.phone"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="企业所在省份-城市">
            <el-cascader disabled :options="provinceCityList" v-model="companyInfo.newProvinceCity" :props="props"></el-cascader>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="企业所在地址">
            <el-input disabled v-model="companyInfo.companyAddress"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="企业经营地省份-城市">
            <el-cascader disabled :options="provinceCityList" v-model="companyInfo.newRealProvinceCity" :props="props"></el-cascader>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="企业经营地址">
            <el-input disabled v-model="companyInfo.companyRealAddress"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="企业联系电话">
            <el-input disabled v-model="companyInfo.tel"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="企业性质">
            <el-select disabled v-model="companyInfo.companyNature">
              <el-option v-for="(item, index) in natureList" :key="index" :label="item.dictName" :value="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="企业从事行业">
            <el-select disabled v-model="companyInfo.companyIndustry">
              <el-option v-for="(item, index) in industryList" :key="index" :label="item.dictName" :value="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <div class="formModuleTitle"><span>还款卡信息</span></div>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="还款卡开户行">
            <el-select v-model="repayCardInfo.bankCode" placeholder="请选择" disabled>
              <el-option v-for="item in bankNameList" :key="item.dictValue" :label="item.dictName" :value="item.dictKey"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="还款卡账号">
            <el-input v-model="repayCardInfo.debitCardNum" placeholder="请输入" :maxlength="19" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="银行预留手机号">
            <el-input v-model="repayCardInfo.phone" placeholder="请输入" :maxlength="11" disabled></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  export default {
    props: ['companyInfo', 'repayCardInfo'],
    data () {
      return {
        rowGutter: 10,
        colSpan: 8,
        // 省份城市配置
        props: {
          value: 'key',
          label: 'name',
          children: 'list'
        }
      }
    },
    computed: {
      ...mapGetters(['provinceCityList', 'industryList', 'natureList', 'bankNameList'])
    }
  }
</script>

<style lang="scss" scoped>
  @import "../style";
</style>
