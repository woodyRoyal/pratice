<template>
  <div>
    <div class="formModuleTitle"><span>还款卡信息</span></div>
    <div class="repayCardInfoWrap">
      <el-form :model="repayCardInfo" label-position="top" size="small">
        <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="还款卡开户行">
                <el-select v-model="repayCardInfo.bankCode" placeholder="请选择" disabled>
                  <el-option :label="item.dictName" :value="item.dictKey" v-for="item in bankNameList" :key="item.dictValue"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="还款卡账号">
                <el-input v-model="repayCardInfo.debitCardNum" placeholder="请输入" :maxlength="19" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="银行预留手机号">
                <el-input v-model="repayCardInfo.phone" placeholder="请输入" :maxlength="11" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
      </el-form>
    </div>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  export default {
    props: ['repayCardInfo'],
    data () {
      return {
        rowGutter: 10,
        colSpan: 8
      }
    },
    computed: {
      ...mapGetters(['bankNameList'])
    }
  }
</script>

<style lang="scss" scoped>
  @import "../style";
</style>
