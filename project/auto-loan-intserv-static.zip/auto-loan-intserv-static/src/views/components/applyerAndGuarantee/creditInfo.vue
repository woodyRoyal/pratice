<template>
  <div class="creditWrap">
    <div class="formModuleTitle"><span>征信信息</span></div>
    <el-form label-position="top" size="mini" :model="creditInfo">
      <el-form-item label="征信渠道">
        <el-select v-model="creditInfo.creditChannel" disabled>
          <el-option v-for="(item, index) in creditChannelList" :key="index" :label="item.dictName" :value="item.dictValue"></el-option>
        </el-select>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  export default {
    props: ['creditInfo'],
    data () {
      return {}
    },
    computed: {
      ...mapGetters(['creditChannelList'])
    }
  }
</script>

<style lang="scss" scoped>
  @import "../style";
</style>
