<template>
  <div class="applyer-info-wrap" ref="applyerInfoWrap">
    <!--个人件-->
    <div v-if="+applyType === 0">
      <basicInfo :basicInfo="basicInfo"></basicInfo>
      <occupationInfo :occupationalInfo="occupationalInfo"></occupationInfo>
      <resideInfo :resideInfo="resideInfo"></resideInfo>
      <relationInfo
        :relationInfo="relationInfo"
        v-if="basicInfo.married === 0 || basicInfo.married === 1 || basicInfo.married === 2 || basicInfo.married === 5"
      >
      </relationInfo>
      <creditInfo :creditInfo="creditInfo"></creditInfo>
      <RepayCard :repayCardInfo="personalRepayCardInfo"></RepayCard>
      <withCompanyInfo :withCompanyInfo="withCompanyInfo" v-if="attached === 1"></withCompanyInfo>
    </div>
    <!--企业件-->
    <div v-else>
      <companyInfo :companyInfo="companyInfoData" :repayCardInfo="enterpriseRepayCardInfo"></companyInfo>
    </div>
    <!--联系人-->
    <contactInfo></contactInfo>
    <operatorsInfo :applyId="applyId"></operatorsInfo>
  </div>
</template>

<script>
  import basicInfo from './basicInfo'
  import occupationInfo from './occupationInfo'
  import resideInfo from './resideInfo'
  import relationInfo from './relationInfo'
  import creditInfo from './creditInfo'
  import RepayCard from './repayCardInfo'
  import withCompanyInfo from './withCompanyInfo'
  import companyInfo from './companyInfo'
  import contactInfo from './contactInfo'
  import operatorsInfo from './operatorsInfo'
  import {mapGetters} from 'vuex'
  import {proposerInfo, companyInfomation} from '../../../api/formInfo.js'
  export default {
    components: {
      basicInfo,
      occupationInfo,
      resideInfo,
      relationInfo,
      withCompanyInfo, // 挂靠（企业）
      creditInfo,
      RepayCard,
      companyInfo, // 企业件
      contactInfo,
      operatorsInfo
    },
    data () {
      return {
        basicInfo: {
          name: '',
          cardType: null,
          cardId: '',
          sex: null,
          birth: '',
          age: null,
          licenceIssuing: null,
          expiryDateStart: '',
          isExpiryDateEndLong: '',
          expiryDateEnd: '',
          married: null,
          phone: '',
          race: '',
          education: null,
          academicDegree: null
        },
        occupationalInfo: {
          companyName: '',
          tel: '',
          industry: null,
          newProvinceCity: [],
          address: ''
        },
        resideInfo: {
          newProvinceCity: [],
          address: '',
          newFamilyProvinceCity: [],
          familyAddress: ''
        },
        relationInfo: {
          name: '',
          relation: null,
          cardId: '',
          phone: '',
          selfCredit: null,
          compaynName: ''
        },
        withCompanyInfo: {
          name: '',
          creditId: '',
          businessLicense: '',
          legalPerson: '',
          legalId: '',
          phone: null,
          newCompanyProvinceCity: [],
          companyAddress: '',
          newCompanyRealProvinceCity: [],
          companyRealAddress: '',
          tel: '',
          companyNature: null,
          companyIndustry: null
        },
        creditInfo: {
          creditChannel: null
        },
        personalRepayCardInfo: {
          bankCode: null,
          debitCardNum: '',
          phone: null
        },
        attached: null,
        companyInfoData: {
          name: '',
          creditId: '',
          businessLicense: '',
          legalPerson: '',
          legalId: '',
          phone: null,
          newProvinceCity: [],
          companyAddress: '',
          newRealProvinceCity: [],
          companyRealAddress: '',
          tel: '',
          companyNature: null,
          companyIndustry: null
        },
        enterpriseRepayCardInfo: {
          bankCode: null,
          debitCardNum: '',
          phone: null
        }
      }
    },
    computed: {
      ...mapGetters(['applyId', 'applyType'])
    },
    created () {
      if (+this.applyType === 0) {
        proposerInfo({applyId: this.applyId}).then(res => {
          if (res.data.respCode === '1000') {
            const {proposerVO, occupationalInfoVO, resideVO, relativesVO, companyVO, creditVO, replamentCardInfo, attached} = res.data.body
            if (proposerVO.expiryDateEnd === '长期') {
              proposerVO.isExpiryDateEndLong = '长期'
              proposerVO.expiryDateEnd = ''
            } else {
              proposerVO.isExpiryDateEndLong = '非长期'
            }
            proposerVO.phone = proposerVO.phone
            proposerVO.cardId = proposerVO.cardId
            proposerVO.name = proposerVO.name
            this.basicInfo = proposerVO
            occupationalInfoVO.newProvinceCity = [occupationalInfoVO.province, occupationalInfoVO.city]
            this.occupationalInfo = occupationalInfoVO
            resideVO.newProvinceCity = [resideVO.province, resideVO.city]
            resideVO.newFamilyProvinceCity = [resideVO.familyProvince, resideVO.familyCity]
            this.resideInfo = resideVO
            relativesVO.phone = relativesVO.phone
            relativesVO.cardId = relativesVO.cardId
            relativesVO.name = relativesVO.name
            this.relationInfo = relativesVO
            if (+attached === 1) {
              companyVO.newProvinceCity = [companyVO.companyProvince, companyVO.companyCity]
              companyVO.newRealProvinceCity = [companyVO.companyRealProvince, companyVO.companyRealCity]
            } else {
              companyVO.newProvinceCity = []
              companyVO.newRealProvinceCity = []
            }
            this.withCompanyInfo = companyVO
            this.creditInfo = creditVO
            replamentCardInfo.phone = replamentCardInfo.phone
            replamentCardInfo.debitCardNum = replamentCardInfo.debitCardNum
            this.personalRepayCardInfo = replamentCardInfo
            this.attached = attached
          }
        }).catch(error => { console.log(error) })
      } else {
        companyInfomation({applyId: this.applyId}).then(res => {
          if (res.data.respCode === '1000') {
            const {companyVO, replamentCardInfo} = res.data.body
            companyVO.newProvinceCity = [companyVO.companyProvince, companyVO.companyCity]
            companyVO.newRealProvinceCity = [companyVO.companyRealProvince, companyVO.companyRealCity]
            this.companyInfoData = companyVO
            this.enterpriseRepayCardInfo = replamentCardInfo
          }
        }).catch(error => { console.log(error) })
      }
    },
    mounted () {
      this.autoHeight()
      // 根据屏幕高度动态改变元素高度
      window.addEventListener('resize', this.autoHeight)
    },
    destroyed () {
      // 组件销毁移除监听
      window.removeEventListener('resize', this.autoHeight)
    },
    methods: {
      // 自适应高度
      autoHeight () {
        let screenHeight = document.documentElement.clientHeight
        this.$refs.applyerInfoWrap.style.height = (screenHeight - 55) + 'px'
      }
    }
  }
</script>

<style lang="scss" scoped>
  .applyer-info-wrap{
    overflow-x: hidden;
    overflow-y: auto;
  }
</style>
