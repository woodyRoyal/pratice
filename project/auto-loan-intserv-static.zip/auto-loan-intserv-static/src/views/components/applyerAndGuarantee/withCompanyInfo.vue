<template>
  <div class="withCompanyWrap">
    <div class="formModuleTitle"><span>挂靠企业信息</span></div>
    <el-form label-position="top" size="mini" :model="withCompanyInfo">
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="企业名称">
            <el-input disabled v-model="withCompanyInfo.name"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="组织机构代码（或统一社会信用代码）">
            <el-input disabled v-model="withCompanyInfo.creditId"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="营业执照编号">
            <el-input disabled v-model="withCompanyInfo.businessLicense"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="法人姓名">
            <el-input disabled v-model="withCompanyInfo.legalPerson"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="法人身份证号">
            <el-input disabled v-model="withCompanyInfo.legalId"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="法人手机号码">
            <el-input disabled v-model="withCompanyInfo.phone"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="企业所在省份-城市">
            <el-cascader disabled :options="provinceCityList" v-model="withCompanyInfo.newProvinceCity" :props="props"></el-cascader>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="企业所在地址">
            <el-input disabled v-model="withCompanyInfo.companyAddress"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="企业经营地省份-城市">
            <el-cascader disabled :options="provinceCityList" v-model="withCompanyInfo.newRealProvinceCity" :props="props"></el-cascader>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="企业经营地址">
            <el-input disabled v-model="withCompanyInfo.companyRealAddress"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="企业联系电话">
            <el-input disabled v-model="withCompanyInfo.tel"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="企业性质">
            <el-select disabled v-model="withCompanyInfo.companyNature">
              <el-option v-for="(item, index) in natureList" :key="index" :label="item.dictName" :value="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="企业从事行业">
            <el-select disabled v-model="withCompanyInfo.companyIndustry">
              <el-option v-for="(item, index) in industryList" :key="index" :label="item.dictName" :value="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan"></el-col>
        <el-col :span="colSpan"></el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  export default {
    props: ['withCompanyInfo'],
    data () {
      return {
        rowGutter: 10,
        colSpan: 8,
        // 省份城市配置
        props: {
          value: 'key',
          label: 'name',
          children: 'list'
        }
      }
    },
    computed: {
      ...mapGetters(['provinceCityList', 'industryList', 'natureList'])
    }
  }
</script>

<style lang="scss" scoped>
  @import "../style";
</style>
