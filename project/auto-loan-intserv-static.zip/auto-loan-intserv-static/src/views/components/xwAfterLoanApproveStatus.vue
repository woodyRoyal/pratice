<template>
  <div class="new-nets-module" v-if="isShowNewNetsModule" v-cloak>
    <ul>
      <li class="xw-approve-status-wrap">
        <div>
          <span>新网银行贷后归档1审批状态：</span>
          <el-tag size="small" v-if="newNetsInfo.task1StatusDesc">{{newNetsInfo.task1StatusDesc}}</el-tag>
        </div>
        <div>
          <span>审批结论：</span>
          <el-tag size="small" v-if="newNetsInfo.task1ApprovalDesc">{{newNetsInfo.task1ApprovalDesc}}</el-tag>
        </div>
      </li>
      <li>
        <span>拒绝/补件原因：</span>
        <span>{{newNetsInfo.task1Code}}</span>
      </li>
      <li>
        <span>原因描述：</span>
        <span>{{newNetsInfo.task1Desc}}</span>
      </li>
      <li class="row-line"></li>
      <li class="xw-approve-status-wrap">
        <div>
          <span>新网银行贷后归档2审批状态：</span>
          <el-tag size="small" v-if="newNetsInfo.task2StatusDesc">{{newNetsInfo.task2StatusDesc}}</el-tag>
        </div>
        <div>
          <span>审批结论：</span>
          <el-tag size="small" v-if="newNetsInfo.task2ApprovalDesc">{{newNetsInfo.task2ApprovalDesc}}</el-tag>
        </div>
      </li>
      <li>
        <span>拒绝/补件原因：</span>
        <span>{{newNetsInfo.task2Code}}</span>
      </li>
      <li>
        <span>原因描述：</span>
        <span>{{newNetsInfo.task2Desc}}</span>
      </li>
      <li style="text-align:center">
        <span class="nets-btns">
          <el-button type="primary" size="mini" @click="filesToNewNets">贷后资料提交新网</el-button>
          <el-button type="primary" size="mini" @click="getNewNetsDaiHouApproveHandle">查询新网审核接口</el-button>
          <el-button type="primary" size="mini" @click="backBuy">确认回购</el-button>
        </span>
      </li>
    </ul>
  </div>
</template>
<script>
  export default {
    props: {
      isShowNewNetsModule: {
        type: Number,
        required: true
      },
      newNetsInfo: {
        type: Object,
        required: true
      }
    },
    methods: {
      filesToNewNets () {
        this.$emit('filesToNewNetsHandle')
      },
      getNewNetsDaiHouApproveHandle () {
        this.$emit('queryXWApprove')
      },
      backBuy () {
        this.$emit('backBuyHandle')
      }
    }
  }
</script>
<style lang="scss" scoped>
  .new-nets-module{
    box-sizing: border-box;
    padding: 0 11px;
    margin: 5px 0 10px;
    ul {
      li{
        height: 35px;
        line-height: 35px;
        font-size: 14px;
        div {
          display: inline-block;
          &:nth-child(even) {
            margin-left: 80px;
          }
        }
        // display: flex;
        // flex-direction: row;
        // align-items: left;
        // height: 25px;
        // font-size: 14px;
        &.xw-approve-status-wrap{
          // justify-content: space-between;
        }
      }
      .row-line{
        height: 1px;
        width: 100%;
        background: #ccc;
        margin: 5px 0;
      }
    }
  }
  .nets-btns{
      display: inline-block;
      // width: 500px;
  }
</style>
