<template>
  <div class="user-wrapper">
    <el-form :inline="true" :model="queryForm">
      <el-form-item label="操作账号:">
        <el-input size="small" v-model="queryForm.username"></el-input>
      </el-form-item>
      <el-form-item label="姓名:">
        <el-input size="small" v-model="queryForm.displayName"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="primary" @click="handleSearch">查询</el-button>
        <el-button size="mini" type="primary" @click="handlReset">重置</el-button>
      </el-form-item>
    </el-form>
    <!-- 表格数据 -->
    <el-table border :data="tableData" :max-height="maxHeight">
      <el-table-column label="序号">
        <template slot-scope="scope">
          <span>{{scope.$index + 1}}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作账号" prop="username"></el-table-column>
      <el-table-column label="姓名" prop="displayName"></el-table-column>
      <el-table-column label="状态">
        <template slot-scope="scope">
          <span>{{ scope.row.valid ? '有效' : '无效' }}</span>
        </template>
      </el-table-column>
      <!--<el-table-column label="登录状态" prop=""></el-table-column>-->
      <el-table-column label="锁定状态">
        <template slot-scope="scope">
          <span>{{ scope.row.locked ? '锁定' : '未锁定' }}</span>
        </template>
      </el-table-column>
      <el-table-column label="岗位名称" prop="postName"></el-table-column>
      <!--<el-table-column label="用户最近登录时间" prop=""></el-table-column>-->
      <!--<el-table-column label="最近签退时间" prop=""></el-table-column>-->
      <el-table-column label="操作" width="250">
        <template slot-scope="scope">
          <el-button type="primary" size="mini" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button type="primary" size="mini" disabled>解锁</el-button>
          <el-button type="primary" size="mini" @click="handleResetPass(scope.row)">重置密码</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页对象 -->
    <!-- 分页对象 -->
    <div class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagable.pageNo" :page-sizes="pageSizes"
                     :page-size="pagable.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagable.totalRecord">
      </el-pagination>
    </div>
    <!-- 弹框 -->
    <el-dialog title='用户信息' :visible.sync="dialogVisible" width="50%" @close="handleDialogClose('addOrEditForm')">
      <el-form :model="addOrEditForm" :rules="rules" ref="addOrEditForm" label-width="100px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="操作账号:" prop="username">
              <el-input size="small" class="width" disabled v-model="addOrEditForm.username"></el-input>
            </el-form-item>
            <el-form-item label="手机号:" prop="phone">
              <el-input size="small" class="width" v-model="addOrEditForm.phone"></el-input>
            </el-form-item>
            <el-form-item label="邮箱:" prop="mail">
              <el-input size="small" class="width" v-model="addOrEditForm.mail"></el-input>
            </el-form-item>
            <el-form-item label="岗位信息:" prop="postIds">
              <el-select v-model="addOrEditForm.postIds" size="small" multiple collapse-tags class="width" multiple collapse-tags>
                <el-option v-for="item in allPostList" :label="item.name" :key="item.id" :value="item.id"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="姓名:" prop="displayName">
              <el-input size="small" class="width" v-model="addOrEditForm.displayName"  disabled></el-input>
            </el-form-item>
            <el-form-item label="电呼坐席号:" prop="serviceNum">
              <el-input size="small" class="width" v-model="addOrEditForm.serviceNum"></el-input>
            </el-form-item>
            <el-form-item label="用户状态:" prop="valid">
              <el-select size="small" v-model="addOrEditForm.valid" class="width">
                <el-option v-for="item in isWorkList" :label="item.dictName" :value="item.dictValue" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="handleAddOrEditConfirm">确 定</el-button>
  </span>
    </el-dialog>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import userApi from '../../api/user'
  export default {
    computed: {
      ...mapGetters([
        'allPostList'
      ])
    },
    data () {
      let regPhone = /^1[0-9]{10}$/ // 手机号验证规则
      let regEmail = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/ // 邮箱验证规则
      let phone = (rule, value, callback) => {
        if (value.trim() === '') {
          callback()
        } else {
          if (!regPhone.test(value.trim())) {
            callback(new Error('请输入正确的手机号格式'))
          } else {
            callback()
          }
        }
      }
      let mail = (rule, value, callback) => {
        if (value.trim() === '') {
          callback()
        } else {
          if (!regEmail.test(value)) {
            callback(new Error('请输入正确的邮箱地址'))
          } else {
            callback()
          }
        }
      }
      return {
        queryForm: {
          username: '',
          displayName: ''
        }, // 查询表单
        dialogVisible: false, // 弹框dialog
        addOrEditForm: {
          phone: '',
          mail: '',
          username: '',
          displayName: '',
          serviceNum: '',
          postIds: [],
          valid: null
        }, // 编辑弹框
        rules: {
          phone: [
            { validator: phone, trigger: 'blur' }
          ],
          valid: [
            { required: true, message: '请选择状态', trigger: 'change' }
          ],
          username: [
            { required: true, message: '请输入操作账号', trigger: 'blur' }
          ],
          displayName: [
            { required: true, message: '请输入姓名', trigger: 'blur' }
          ],
          mail: [
            { validator: mail, trigger: 'blur' }
          ],
          postIds: [
            {required: true, message: '请选择岗位信息', trigger: 'change'}
          ]
        }, // 规则
        // 是否有效
        isWorkList: [
          {dictValue: true, dictName: '有效'},
          {dictValue: false, dictName: '无效'}
        ],
        tableData: [],
        pagable: {
          pageNo: 1,
          pageSize: 10,
          totalRecord: null // 总记录数
        },
        maxHeight: 100,
        pageSizes: [10, 20, 30, 40]
      }
    },
    mounted () {
      // 获取所有岗位
      this.getAllPost()
      // 获取数据
      this.getTableData()
      // 调整高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    destroyed () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // 表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let h = document.documentElement.clientHeight
          this.maxHeight = h - 250
        })
      },
      handleSearch () {
        this.getTableData()
      },
      // 重置
      handlReset () {
        this.queryForm = {
          username: '',
          displayName: ''
        }
        this.pagable = {
          pageNo: 1,
          pageSize: 10,
          totalRecord: null // 总记录数
        }
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        let data = {
          displayName: this.queryForm.displayName || null,
          username: this.queryForm.username || null,
          pageNum: this.pagable.pageNo,
          pageSize: this.pagable.pageSize
        }
        userApi.fetchUser(data)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.tableData = res.body.list
              this.pagable.totalRecord = res.body.total
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagable.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagable.pageNo = val
        this.getTableData()
      },
      // 点击编辑
      handleEdit (val) {
        userApi.fetchFindUserById(val.id)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.dialogVisible = true
              this.addOrEditForm = Object.assign({}, res.body)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 所有岗位信息
      getAllPost () {
        if (!this.allPostList.length) {
          this.$store.dispatch('getAllPost')
        }
      },
      // 弹框关闭
      handleDialogClose (formName) {
        this.$refs[formName].resetFields()
        this.addOrEditForm = {
          phone: '',
          mail: '',
          username: '',
          displayName: '',
          serviceNum: '',
          postIds: [],
          valid: null
        }
      },
      // 重置密码
      handleResetPass (val) {
        this.$confirm('是否确定重置密码?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.handleResetPassAgain(val)
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消操作'
          })
        })
      },
      // 确认重置密码
      handleResetPassAgain (val) {
        let data = {
          id: val.id
        }
        userApi.fetchResetPassword(data)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.$message.success('密码重置成功')
              this.getTableData()
            } else {
              this.$message.warning(res.respMsg)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 用户管理提交编辑表单
      handleAddOrEditConfirm () {
        this.submitForm('addOrEditForm')
      },
      // 提交表单
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            // window.alert('submit!')
            // todo 请求编辑借口
            this.handleEditConfirm()
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      // 请求编辑接口
      handleEditConfirm () {
        userApi.fetchEditForm(this.addOrEditForm)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.$message.success('编辑成功')
              this.dialogVisible = false
              this.getTableData()
            }
          })
          .catch(error => {
            console.log(error)
          })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .user-wrapper {
   .width {
     width: 90%;
   }
    .el-form-item {
     margin-bottom: 15px;
    }
  }
</style>