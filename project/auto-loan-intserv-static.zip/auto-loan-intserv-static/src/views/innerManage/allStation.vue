<template>
  <div class="all-station-wrapper">
    <!-- 查询条件 -->
    <el-form :inline="true">
      <el-form-item label="岗位:">
        <el-select value="" size="small">
          <el-option value=""></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="状态:">
        <el-select value="" size="small">
          <el-option value=""></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" size="small">查询</el-button>
        <el-button type="primary" size="small">重置</el-button>
      </el-form-item>
    </el-form>

    <!-- 表格数据 -->
    <el-table border>
      <el-table-column align="center" label="序号"></el-table-column>
      <el-table-column align="center" label="岗位名称"></el-table-column>
      <el-table-column align="center" label="操作账号"></el-table-column>
      <el-table-column align="center" label="姓名"></el-table-column>
      <el-table-column align="center" label="用户最近登录时间"></el-table-column>
      <el-table-column align="center" label="状态"></el-table-column>
    </el-table>
  </div>
</template>