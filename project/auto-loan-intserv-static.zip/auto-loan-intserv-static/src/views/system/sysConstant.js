/* 系统管理相关 常量 */

// 定时任务状态
export const SCHEDULE_STATUS = {
  'NONE': '停止',
  'NORMAL': '启动',
  'PAUSED': '暂停',
  'RUNNING': '执行中',
  'DELETED': '删除',
  'STOPPED': '已停止',
  'ERROR': '错误'
}

// 账号
export const STATUS = {
  '': '不限',
  '0': '禁用状态',
  '1': '启用状态'
}
