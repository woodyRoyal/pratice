<!--角色管理-->
<template>
  <div class="role-manage">
    <!--表单-->
    <el-form :inline="true" :model="queryFormData" class="form-user-defined">
      <el-row>
        <el-col :span="12" class="form-btn">
          <el-form-item>
            <el-button size="small" type="primary" icon="plus" @click="openRoleDialog">新增</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row style="width: 100%"
              :max-height="500">
      <el-table-column align="center" label="ID" prop="id"></el-table-column>

      <el-table-column align="center" label="角色名">
        <template slot-scope="scope">
          <span>{{ scope.row.role }}</span>
        </template>
      </el-table-column>

      <el-table-column align="center" label="描述" show-overflow-tooltip>
        <template slot-scope="scope">
          <span>{{ scope.row.description }}</span>
        </template>
      </el-table-column>

      <!--<el-table-column align="center" label="拥有权限" min-width="300px">-->
      <!--<template slot-scope="scope">-->
      <!--<span v-if="scope.row.id === 1">所有权限</span>-->
      <!--<el-popover placement="top" v-else>-->
      <!--<span v-for="(item, index) in scope.row.permissionList">-->
      <!--{{ index + 1 == scope.row.permissionList.length ? permissionListMap[item] : permissionListMap[item] + ","-->
      <!--}}-->
      <!--</span>-->
      <!--<div slot="reference" class="name-wrapper">-->
      <!--<span v-for="(item, index) in scope.row.permissionList">-->
      <!--{{ index + 1 == scope.row.permissionList.length ? permissionListMap[item] : permissionListMap[item] + ","-->
      <!--}}-->
      <!--</span>-->
      <!--</div>-->
      <!--</el-popover>-->
      <!--</template>-->
      <!--</el-table-column>-->

      <el-table-column align="center" label="状态">
        <template slot-scope="scope">
          <!-- 0 禁用; 1 启用 -->
          <span v-if="scope.row.valid === 1">启用</span>
          <span v-else style="color: red;">禁用</span>
        </template>
      </el-table-column>

      <el-table-column align="center" label="操作" min-width="100px">
        <template slot-scope="scope">
          <div>
            <el-button type="primary" @click='handleEditRole(scope.row)' size="mini"
                       icon="edit">编辑
            </el-button>
            <el-button v-if="scope.row.valid == '1'" type="warning"
                       @click="handleEnableOrDisableUserType(scope.row, 0)" size="mini">禁用
            </el-button>
            <el-button v-if="scope.row.valid == '0'" type="success"
                       @click="handleEnableOrDisableUserType(scope.row, 1)" size="mini">启用
            </el-button>
            <el-button type="danger" @click="handleDeleteRole(scope.row)" icon="delete2"
                       size="mini">删除
            </el-button>
          </div>
        </template>
      </el-table-column>
    </el-table>
    <!--分页-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="queryFormData.pageNo" :page-sizes="pageSizes"
                     :page-size="queryFormData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="queryFormData.totalRecord">
      </el-pagination>
    </div>
    <!--新增角色-->
    <el-dialog :title="dialogTitle" width="30%" :visible.sync="dialogFormVisible" @close="handleDialogClose"
               class="add-edit-role-dialog">
      <el-form :model="addRoleform" :rules="addFormRules" ref="addRoleform" label-width="90px">
        <el-form-item label="角色名" prop="role">
          <el-input v-model="addRoleform.role" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="描述" prop="description">
          <el-input v-model="addRoleform.description" auto-complete="off"></el-input>
        </el-form-item>
        <!--<el-form-item label="可审批产品">-->
        <!--<el-checkbox size="small">大额分期</el-checkbox>-->
        <!--<el-checkbox size="small">商贷王</el-checkbox>-->
        <!--</el-form-item>-->
        <el-form-item label="权限" prop="permissionList" class="is-required">
          <el-tree show-checkbox highlight-current style="max-height: 300px;overflow: auto"
                   ref="roleTree"
                   default-expand-all
                   @check-change="handleCheckChange"
                   :data="permissionTreeData"
                   check-strictly
                   node-key="id" :props="permissionTreeProps">
          </el-tree>
        </el-form-item>
        <el-form-item label="是否启用" prop="valid">
          <el-radio class="radio" v-model="addRoleform.valid" :label="1">是</el-radio>
          <el-radio class="radio" v-model="addRoleform.valid" :label="0">否</el-radio>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleCancelRole">取 消</el-button>
        <el-button type="primary" @click="handleConfirmRole(addOrUpdateStatus)">保 存</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import ElSelectTree from '../../components/SelectTree/selectTree.vue'
  import {
    fetchRoleList,
    fetchPermissionTree,
    fetchAddRole,
    fetchUpdateRole,
    fetchDeleteRoleById,
    fetchForbidRole
  } from '../../api/sys'

  export default {
    components: {
      ElSelectTree
    },
    data () {
      // 权限
      const validatePermission = (rule, value, callback) => {
        if (!value || value.length === 0) {
          callback(new Error('请选择权限'))
        } else {
          callback()
        }
      }
      return {
        // 查询表单参数
        queryFormData: {
          type: 1, // 分页查询
          role: '', // 角色名
          pageSize: 100, // 每页条数
          pageNo: 1, // 页码
          totalRecord: null, // 总记录数
          totalPage: null, // 总页数
          valid: null
        },
        pageSizes: [50, 100, 200, 500],

        tableData: null, // 表数据
        listLoading: false,

        dialogFormVisible: false, // 显示新增角色框
        dialogTitle: '新增角色',
        addOrUpdateStatus: 1, // 1 新增 2 更新

        permissionTreeData: [], // 权限树数据
        permissionListMap: {}, // 权限数据对象
        permissionTreeProps: { // 权限树配置 字段映射
          children: 'children',
          label: 'name',
          id: 'id'
        },

        addRoleform: { // 新增角色表单
          id: '', // 角色id
          role: '', // 管理员名称
          description: '', // 角色描述
          permissionList: '', // 权限ids
          valid: 1 // 1_有效角色 0_无效角色
        },
        // 新增角色表单输入验证规则
        addFormRules: {
          role: [
            {required: true, message: '请输入角色名', trigger: 'blur'}
          ],
          permissionList: [
            {validator: validatePermission, trigger: 'change'}
          ]
        }
      }
    },
    mounted () {
      // 获取权限树接口
      this.getPermissionTree()
      // 获取表格数据
      this.getTableData()
    },
    methods: {
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.queryFormData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.queryFormData.pageNo = val
        this.getTableData()
      },
      // 搜索按钮
      handleSearchData () {
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        this.listLoading = true
        fetchRoleList(this.queryFormData.pageNo, this.queryFormData.pageSize, this.queryFormData.totalRecord)
          .then(response => {
            let res = response.data
            if (res.result) {
              // 遍历处理数据
              this.tableData = res.result.content
              this.queryFormData.pageNo = res.result.pageNo
              this.queryFormData.pageSize = res.result.pageSize
              this.queryFormData.totalRecord = res.result.totalRecord
              this.queryFormData.totalPage = res.result.totalPage
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 获取权限树
      getPermissionTree () {
        fetchPermissionTree()
          .then(response => {
            console.log(response)
            let res = response.data
            if (res.result) {
              // 遍历处理数据
              this.permissionTreeData = res.result
              this.permissionListMap = this.treeListToMapObj(this.permissionTreeData)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      treeListToMapObj (treeList) {
        let mapObj = {}
        treeList.map(item => this.transObj(item, mapObj))
        return mapObj
      },
      transObj (source, target) {
        if (!source) {
          return
        }
        if (source.id) {
          target[source.id] = source.name
        }
        // 递归处理子菜单
        if (source.children && source.children.length > 0) {
          source.children.map(item => this.transObj(item, target))
        }
        return target
      },
      // 点击新增按钮，打开dialog
      openRoleDialog () {
        this.dialogFormVisible = true
        this.dialogTitle = '新增角色'
        this.addOrUpdateStatus = 1
      },
      // 清空树节点的选择
      resetChecked () {
        this.$refs.roleTree.setCheckedKeys([])
      },
      // 通过key设置
      setCheckedKeys (keys) {
        this.$refs.roleTree.setCheckedKeys(keys)
      },
      // Dialog 关闭的回调
      handleDialogClose () {
        // 表单置空
        this.addRoleform = {
          id: '', // 角色id
          role: '', // 管理员名称
          description: '', // 角色描述
          permissionList: '', // 权限ids
          valid: 1 // 1_有效角色 0_无效角色
        }
        this.resetChecked()
        this.$refs['addRoleform'].resetFields()
      },
      // 点击编辑按钮，打开dialog
      handleEditRole (role) {
        this.dialogTitle = '编辑角色'
        this.addOrUpdateStatus = 2
        this.dialogFormVisible = true
        this.addRoleform = Object.assign({}, role)
        // 给权限树赋值（等视图渲染完再，不然undefined）
        this.$nextTick(() => {
          this.setCheckedKeys(role.permissionList)
        })
      },
      // 处理权限树选中事件
      handleCheckChange (data, checked, indeterminate) {
        this.addRoleform.permissionList = this.$refs.roleTree.getCheckedKeys()
      },
      // 确认添加或修改角色
      handleConfirmRole (value) {
        this.submitForm('addRoleform', value)
      },
      // 取消添加或修改角色
      handleCancelRole () {
        this.dialogFormVisible = false
      },
      submitForm (formName, value) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (value === 1) {
              this.addRole(this.addRoleform)
            } else {
              this.updateRole(this.addRoleform)
            }
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      // 新增角色
      addRole (role) {
        fetchAddRole(role)
          .then(response => {
            let res = response.data
            if (res.result) {
              this.$message.success('操作成功')
              this.dialogFormVisible = false
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 修改角色
      updateRole (role) {
        fetchUpdateRole(role)
          .then(response => {
            let res = response.data
            if (res.result) {
              this.$message.success('操作成功')
              this.dialogFormVisible = false
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 删除当前角色
      handleDeleteRole (role) {
        this.deleteRoles(role.id, role.role)
      },
      // 删除角色
      deleteRoles (roleId, roleName) {
        this.$confirm('确认删除角色【' + roleName + '】吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          fetchDeleteRoleById(roleId)
            .then(response => {
              let res = response.data
              if (res.result) {
                this.$message.success('操作成功')
                this.getTableData()
              }
            })
            .catch(e => {
              console.log(e)
            })
        }).catch(() => {
        })
      },
      // 启用或禁用
      handleEnableOrDisableUserType (user, vaild) {
        this.addRoleform.id = user.id
        this.addRoleform.valid = user.valid ? 0 : 1
        // this.addRoleform.username = user.username
        // this.addRoleform.roleId = user.roleId
        fetchForbidRole(this.addRoleform.id, this.addRoleform.valid)
          .then(response => {
            if (response.data.code === '000') {
              this.$message.success((vaild === 1 ? '启用' : '禁用') + '成功')
              user.valid = vaild
              this.getTableData()
            }
          })
          .catch(error => {
            console.log(error)
            this.dialogFormVisible = false
          })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .form-user-defined {
    .el-form-item {
      margin-right: 20px;
      margin-bottom: 10px;
    }
    .form-btn {
      .el-form-item {
        margin-right: 0;
      }
    }
  }

  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

</style>
