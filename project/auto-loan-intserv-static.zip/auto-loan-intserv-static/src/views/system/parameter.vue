<!--参数设置-->
<template>
  <el-row :gutter="20">
    <el-col :span="10">
      <!--表单-->
      <el-form :inline="true" :model="queryClassFormData" class="form-user-defined">
        <el-row>
          <el-col :span="6" class="form-btn">
            <el-form-item>
              <el-button size="small" type="primary" icon="plus" @click="dialogClassFormVisible = true">新增分类</el-button>
            </el-form-item>
          </el-col>
          <el-col :span="18" style="text-align: right;" class="form-btn">
            <el-form-item>
              <el-input size="small" class="length-1" v-model="queryClassFormData.classCode"
                        placeholder="请输入分类码"></el-input>
            </el-form-item>
            <el-form-item>
              <el-input @keyup.enter.native="" size="small" class="length-2" placeholder="请输入分类名"
                        v-model="queryClassFormData.className">
                <el-button slot="append" type="primary" size="small" v-waves @click="handleClassSearchData">搜索
                </el-button>
              </el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <!--表格-->
      <el-table :data="classTableData" v-loading="classListLoading" border fit highlight-current-row
                style="width: 100%">
        <el-table-column align="center" label="分类码">
          <template slot-scope="scope">
            <span v-show="!scope.row.editable">{{ scope.row.classCode }}</span>
            <el-input v-show="scope.row.editable" size="small" v-model="scope.row.classCode"></el-input>
          </template>
        </el-table-column>

        <el-table-column align="center" label="分类名">
          <template slot-scope="scope">
            <span v-show="!scope.row.editable">{{ scope.row.className }}</span>
            <el-input v-show="scope.row.editable" size="small" v-model="scope.row.className"></el-input>
          </template>
        </el-table-column>

        <el-table-column align="center" label="操作">
          <template slot-scope="scope">
            <el-button v-show="!scope.row.editable" type="primary" @click='scope.row.editable=true' size="mini"
                       icon="edit">修改
            </el-button>
            <el-button v-show="scope.row.editable" @click="scope.row.editable=false" size="mini"
                       icon="close">取消
            </el-button>
            <el-button v-show="scope.row.editable" type="success" @click="handleUpdateClass(scope.row)" size="mini"
                       icon="check">完成
            </el-button>
            <el-button type="danger" @click="handleDeleteClass(scope.row.id)" icon="delete2"
                       size="mini">删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <!--分页-->
      <div v-show="!classListLoading" class="pagination-container">
        <el-pagination @size-change="handleClassSizeChange" @current-change="handleClassCurrentChange"
                       :current-page.sync="queryClassFormData.index" :page-sizes="queryClassFormData.pageSizes"
                       :page-size="queryClassFormData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                       :total="queryClassFormData.totalRecord">
        </el-pagination>
      </div>
      <!--新增分类-->
      <el-dialog title="新增分类" width="30%" :visible.sync="dialogClassFormVisible" @close="handleClassDialogClose">
        <el-form :model="addClassform" :rules="addClassFormRules" ref="addClassform" label-width="80px">
          <el-form-item label="分类码" prop="classCode">
            <el-input v-model="addClassform.classCode" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="分类名" prop="className">
            <el-input v-model="addClassform.className" auto-complete="off"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="handleAddClassCancel">取 消</el-button>
          <el-button type="primary" @click="handleAddClassConfirm">确 定</el-button>
        </div>
      </el-dialog>
    </el-col>
    <el-col :span="14">
      <!--表单-->
      <el-form :inline="true" :model="queryParamFormData" class="form-user-defined">
        <el-row>
          <el-col :span="6" class="form-btn">
            <el-form-item>
              <el-button size="small" type="success" icon="plus" @click="dialogParamFormVisible = true">新增参数</el-button>
            </el-form-item>
          </el-col>
          <el-col :span="18" style="text-align: right;" class="form-btn">
            <el-form-item label="参数分类">
              <el-select v-model="queryParamFormData.classId" size="small" filterable class="length-2"
                         placeholder="请选择分类">
                <el-option label="所有" value=""></el-option>
                <el-option v-for="item in classListData" :key="item.id" :label="item.className" :value="item.id">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" size="small" v-waves @click="handleParamSearchData">搜索</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <!--表格-->
      <el-table :data="paramTableData" v-loading="paramListLoading" border fit highlight-current-row
                style="width: 100%">
        <el-table-column align="center" label="参数码">
          <template slot-scope="scope">
            <span v-show="!scope.row.editable">{{ scope.row.paramCode }}</span>
            <el-input v-show="scope.row.editable" size="small" v-model="scope.row.paramCode"></el-input>
          </template>
        </el-table-column>

        <el-table-column align="center" label="参数名">
          <template slot-scope="scope">
            <span v-show="!scope.row.editable">{{ scope.row.paramName }}</span>
            <el-input v-show="scope.row.editable" size="small" v-model="scope.row.paramName"></el-input>
          </template>
        </el-table-column>

        <el-table-column align="center" label="所属分类">
          <template slot-scope="scope">
            <span v-show="!scope.row.editable">{{ classListMap[scope.row.classId] }}</span>
            <el-select v-show="scope.row.editable" v-model="scope.row.classId" size="small" filterable
                       placeholder="请选择分类">
              <el-option v-for="item in classListData" :key="item.id" :label="item.className" :value="item.id">
              </el-option>
            </el-select>
          </template>
        </el-table-column>

        <el-table-column align="center" label="操作">
          <template slot-scope="scope">
            <el-button v-show="!scope.row.editable" type="primary" @click='scope.row.editable=true' size="mini"
                       icon="edit">修改
            </el-button>
            <el-button v-show="scope.row.editable" @click="scope.row.editable=false" size="mini"
                       icon="close">取消
            </el-button>
            <el-button v-show="scope.row.editable" type="success" @click="handleUpdateParam(scope.row)" size="mini"
                       icon="check">完成
            </el-button>
            <el-button type="danger" @click="handleDeleteParam(scope.row.id)" icon="delete2"
                       size="mini">删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <!--分页-->
      <div v-show="!classListLoading" class="pagination-container">
        <el-pagination @size-change="handleParamSizeChange" @current-change="handleParamCurrentChange"
                       :current-page.sync="queryParamFormData.index" :page-sizes="queryParamFormData.pageSizes"
                       :page-size="queryParamFormData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                       :total="queryParamFormData.totalRecord">
        </el-pagination>
      </div>
      <!--新增参数-->
      <el-dialog title="新增参数" width="30%" :visible.sync="dialogParamFormVisible" @close="handleParamDialogClose">
        <el-form :model="addParamform" :rules="addParamFormRules" ref="addParamform" label-width="80px">
          <el-form-item label="参数码" prop="paramCode">
            <el-input v-model="addParamform.paramCode" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="参数名" prop="paramName">
            <el-input v-model="addParamform.paramName" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="分类" prop="classId" class="is-required">
            <el-select v-model="addParamform.classId" size="small" filterable placeholder="请选择分类">
              <el-option v-for="item in classListData" :key="item.id" :label="item.className" :value="item.id">
              </el-option>
            </el-select>
          </el-form-item>

        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="handleAddParamCancel">取 消</el-button>
          <el-button type="primary" @click="handleAddParamConfirm">确 定</el-button>
        </div>
      </el-dialog>
    </el-col>
  </el-row>
</template>

<script>
  import {
    fetchParamClassList,
    fetchSaveOrUpdateParamClass,
    fetchDeleteParamClassById,
    fetchParamList,
    fetchSaveOrUpdateParam,
    fetchDeleteParamById
  } from '../../api/sys'

  export default {
    computed: {
      // 分类表分页参数
      queryClassPage () {
        return {
          pageNo: this.queryClassFormData.index, // 页码
          pageSize: this.queryClassFormData.pageSize // 每页显示的记录数
        }
      },
      // 参数表分页参数
      queryParamPage () {
        return {
          pageNo: this.queryClassFormData.index, // 页码
          pageSize: this.queryClassFormData.pageSize // 每页显示的记录数
        }
      }
    },
    data () {
      // 新增参数 校验分类
      const validateClassId = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请选择分类'))
        } else {
          callback()
        }
      }
      return {
        /* ---------------参数分类数据 start--------------- */
        // 查询分类表表单参数
        queryClassFormData: {
          classCode: '',
          className: '',
          pageSize: 10, // 每页条数
          index: 1, // 页码
          totalRecord: null, // 总记录数
          totalPage: null, // 总页数
          pageSizes: [10, 50, 100]
        },
        classTableData: null, // 表数据
        classListLoading: false,
        dialogClassFormVisible: false, // 显示新增分类框
        addClassform: { // 新增分类表单
          classCode: '',
          className: ''
        },
        // 新增分类表单输入验证规则
        addClassFormRules: {
          classCode: [
            {required: true, message: '请输入分类码', trigger: 'blur'}
          ],
          className: [
            {required: true, message: '请输入分类名', trigger: 'blur'}
          ]
        },
        /* ---------------参数分类数据 end--------------- */

        /* ---------------参数数据 start--------------- */
        // 查询参数表表单参数
        queryParamFormData: {
          paramCode: '',
          paramName: '',
          parentId: null,
          classId: '',
          pageSize: 10, // 每页条数
          index: 1, // 页码
          totalRecord: null, // 总记录数
          totalPage: null, // 总页数
          pageSizes: [10, 50, 100]
        },
        classListData: [], // 分类列表数据
        classListMap: {}, // 分类列表对象
        paramTableData: null, // 表数据
        paramListLoading: false,
        dialogParamFormVisible: false, // 显示新增参数框
        addParamform: { // 新增参数表单
          paramCode: '',
          paramName: '',
          parentId: null,
          classId: ''
        },
        // 新增参数表单输入验证规则
        addParamFormRules: {
          paramCode: [
            {required: true, message: '请输入参数码', trigger: 'blur'}
          ],
          paramName: [
            {required: true, message: '请输入参数名', trigger: 'blur'}
          ],
          classId: [
            {validator: validateClassId, trigger: 'change'}
          ]
        }
        /* ---------------参数数据 end--------------- */
      }
    },
    mounted () {
      // 分页获取分类表数据
      this.getClassTableData()
      // 全量获取分类列表
      this.getClassList()
      // 分页获取参数表数据
      this.getParamTableData()
    },
    methods: {
      /* ---------------参数分类方法 start--------------- */
      // 处理分页每页显示数改变事件
      handleClassSizeChange (val) {
        this.queryClassFormData.pageSize = val
        this.getClassTableData()
      },
      // 处理页码改变事件
      handleClassCurrentChange (val) {
        this.queryClassFormData.index = val
        this.getClassTableData()
      },
      // 搜索按钮
      handleClassSearchData () {
        this.getClassTableData()
      },
      // 获取参数分类表数据
      getClassTableData () {
        this.classListLoading = true
        fetchParamClassList(this.queryClassFormData.classCode, this.queryClassFormData.className, JSON.stringify(this.queryClassPage))
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              // 遍历处理数据
              this.classTableData = response.data.data.content.map(item => {
                // 给每一行增加是否可编辑的字段
                item.editable = false
                return item
              })
              this.queryClassFormData.totalRecord = response.data.data.totalRecord
              this.queryClassFormData.totalPage = response.data.data.totalPage
            }
            this.classListLoading = false
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 修改分类信息
      handleUpdateClass (pclass) {
        // 隐藏可编辑框
        for (let item of this.classTableData) {
          if (item.id === pclass.id) {
            // 隐藏可编辑框
            item.editable = false
            break
          }
        }
        console.log(pclass)
        // 提交数据
        this.saveOrUpdateClass(pclass)
      },
      // 新增或修改分类
      saveOrUpdateClass (pclass) {
        fetchSaveOrUpdateParamClass(JSON.stringify(pclass))
          .then(res => {
            if (res.data.errorCode === 0 && res.data.data) {
              this.$message.success('操作成功')
              this.dialogClassFormVisible = false
              this.getClassTableData()
              this.getClassList()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 确认添加分类
      handleAddClassConfirm () {
        this.submitClassForm('addClassform')
      },
      // 取消添加分类
      handleAddClassCancel () {
        this.dialogClassFormVisible = false
        this.resetClassForm('addClassform')
      },
      submitClassForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.saveOrUpdateClass(this.addClassform)
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetClassForm (formName) {
        this.$refs[formName].resetFields()
      },
      // add Dialog 关闭的回调
      handleClassDialogClose () {
        this.resetClassForm('addClassform')
      },
      // 删除当前分类
      handleDeleteClass (id) {
        this.$confirm('确认删除此参数分类吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          fetchDeleteParamClassById(id)
            .then(res => {
              if (res.data.errorCode === 0) {
                this.$message.success('操作成功')
                this.getClassTableData()
              }
            })
            .catch(e => {
              console.log(e)
            })
        }).catch(() => {
        })
      },
      /* ---------------参数分类方法 end--------------- */

      /* ---------------参数方法 start--------------- */
      // 参数相关方法
      // 处理分页每页显示数改变事件
      handleParamSizeChange (val) {
        this.queryParamFormData.pageSize = val
        this.getParamTableData()
      },
      // 处理页码改变事件
      handleParamCurrentChange (val) {
        this.queryParamFormData.index = val
        this.getParamTableData()
      },
      // 搜索按钮
      handleParamSearchData () {
        this.getParamTableData()
      },
      // 获取参数表数据
      getParamTableData () {
        this.paramListLoading = true
        fetchParamList(this.queryParamFormData.classId, JSON.stringify(this.queryParamPage))
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              // 遍历处理数据
              this.paramTableData = response.data.data.content.map(item => {
                // 给每一行增加是否可编辑的字段
                item.editable = false
                return item
              })
              this.queryParamFormData.totalRecord = response.data.data.totalRecord
              this.queryParamFormData.totalPage = response.data.data.totalPage
            }
            this.paramListLoading = false
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取分类列表
      getClassList () {
        fetchParamClassList()
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              this.classListData = response.data.data.content
              // 数组转map对象
              const classList = response.data.data.content
              if (classList && classList.length > 0) {
                for (let item of classList) {
                  this.classListMap[item.id] = item.className
                }
              }
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 修改参数信息
      handleUpdateParam (param) {
        // 隐藏可编辑框
        for (let item of this.paramTableData) {
          if (item.id === param.id) {
            // 隐藏可编辑框
            item.editable = false
            break
          }
        }
        console.log(param)
        // 提交数据
        this.saveOrUpdateParam(param)
      },
      // 新增或修改参数
      saveOrUpdateParam (param) {
        fetchSaveOrUpdateParam(JSON.stringify(param))
          .then(res => {
            if (res.data.errorCode === 0 && res.data.data) {
              this.$message.success('操作成功')
              this.dialogParamFormVisible = false
              this.getParamTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 确认添加参数
      handleAddParamConfirm () {
        this.submitParamForm('addParamform')
      },
      // 取消添加参数
      handleAddParamCancel () {
        this.dialogParamFormVisible = false
        this.resetParamForm('addParamform')
      },
      submitParamForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.saveOrUpdateParam(this.addParamform)
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetParamForm (formName) {
        this.$refs[formName].resetFields()
      },
      // add Dialog 关闭的回调
      handleParamDialogClose () {
        this.resetParamForm('addParamform')
      },
      // 删除当前参数
      handleDeleteParam (id) {
        this.$confirm('确认删除此参数吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          fetchDeleteParamById(id)
            .then(res => {
              if (res.data.errorCode === 0) {
                this.$message.success('操作成功')
                this.getParamTableData()
              }
            })
            .catch(e => {
              console.log(e)
            })
        }).catch(() => {
        })
      }
      /* ---------------参数方法 end--------------- */
    }
  }
</script>

<style lang="scss" scoped>
  .form-user-defined {
    .el-form-item {
      margin-right: 20px;
      margin-bottom: 10px;
    }
    .form-btn {
      .el-form-item {
        margin-right: 0;
      }
    }
    .length-1 {
      width: 110px;
    }
    .length-2 {
      width: 180px;
    }
  }

</style>
