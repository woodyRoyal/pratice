<!--定时任务-->
<template>
  <div>
    <div class="add-btn">
      <el-button size="small" type="primary" icon="plus" @click="dialogFormVisible = true">新增</el-button>
    </div>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row style="width: 100%">
      <el-table-column align="center" label="任务名" min-width="100px">
        <template slot-scope="scope">
          <el-popover placement="top">
            <span>{{ scope.row.taskName }}</span>
            <div slot="reference" class="name-wrapper">
              <span v-show="!scope.row.editable">{{ scope.row.taskName }}</span>
            </div>
          </el-popover>
          <el-input v-show="scope.row.editable" size="small" v-model="scope.row.taskName"></el-input>
        </template>
      </el-table-column>

      <el-table-column align="center" label="任务分组">
        <template slot-scope="scope">
          <span>{{ scope.row.taskGroup }}</span>
        </template>
      </el-table-column>

      <el-table-column align="center" label="描述">
        <template slot-scope="scope">
          <el-popover placement="top">
            <span>{{ scope.row.desc }}</span>
            <div slot="reference" class="name-wrapper">
              <span v-show="!scope.row.editable">{{ scope.row.desc }}</span>
            </div>
          </el-popover>
          <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 5}" v-show="scope.row.editable" size="small"
                    v-model="scope.row.desc"></el-input>
        </template>
      </el-table-column>
      <el-table-column align="center" label="类型">
        <template slot-scope="scope">
          <span v-show="!scope.row.editable">{{ scope.row.type == 1 ? "cron" : "simple" }}</span>
          <el-radio-group v-show="scope.row.editable" v-model="scope.row.type">
            <el-radio :label="1">cron</el-radio>
            <el-radio :label="2">simple</el-radio>
          </el-radio-group>
        </template>
      </el-table-column>
      <el-table-column align="center" label="CRON表达式">
        <template slot-scope="scope">
          <span v-show="!scope.row.editable">{{ scope.row.cronExpression }}</span>
          <el-input v-show="scope.row.editable" size="small" v-model="scope.row.cronExpression"></el-input>
        </template>
      </el-table-column>
      <el-table-column align="center" label="时间间隔">
        <template slot-scope="scope">
          <span v-show="!scope.row.editable">{{ scope.row.repeatInterval }}</span>
          <el-input-number v-show="scope.row.editable" size="small"
                           v-model="scope.row.repeatInterval"></el-input-number>
        </template>
      </el-table-column>
      <el-table-column align="center" label="jobClass">
        <template slot-scope="scope">
          <el-popover placement="top">
            <span>{{ scope.row.jobClass }}</span>
            <div slot="reference" class="name-wrapper">
              <span v-show="!scope.row.editable">{{ scope.row.jobClass }}</span>
            </div>
          </el-popover>
          <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 5}" v-show="scope.row.editable" size="small"
                    v-model="scope.row.jobClass"></el-input>
        </template>
      </el-table-column>
      <el-table-column align="center" label="状态">
        <template slot-scope="scope">
          <span>{{ scheduleStatusMap[scope.row.status] }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="正在运行">
        <template slot-scope="scope">
          <span>{{ scope.row.isRunning ? "是" : "否" }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="上次执行时间" min-width="120px">
        <template slot-scope="scope">
          <span>{{ scope.row.preRunningTime }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="下次执行时间">
        <template slot-scope="scope">
          <span>{{ scope.row.nextRunningTime }}</span>
        </template>
      </el-table-column>

      <el-table-column align="center" label="操作" min-width="260px">
        <template slot-scope="scope">
          <el-button v-show="!scope.row.editable" type="primary" @click='scope.row.editable=true' size="mini"
                     icon="edit">修改
          </el-button>
          <el-button v-show="scope.row.editable" @click="scope.row.editable=false" size="mini"
                     icon="close">取消
          </el-button>
          <el-button v-show="scope.row.editable" type="success" @click="handleUpdateSchedule(scope.row)" size="mini"
                     icon="check">完成
          </el-button>

          <el-button v-show="scope.row.status == 'NORMAL' || scope.row.status == 'RUNNING'" size="mini"
                     @click="handlePauseSchedule(scope.row.taskId)">暂停
          </el-button>
          <el-button v-show="scope.row.status != 'DELETED'" @click="handleResumeSchedule(scope.row.taskId)"
                     size="mini">重启
          </el-button>
          <el-button @click="handleRunOnceSchedule(scope.row.taskId)"
                     size="mini">执行一次
          </el-button>
          <el-button v-show="scope.row.status != 'NORMAL'" @click="handleStartSchedule(scope.row.taskId)"
                     size="mini">启动
          </el-button>
          <el-button @click="handleStopSchedule(scope.row.taskId)"
                     size="mini">停止
          </el-button>
          <el-button v-show="scope.row.status != 'RUNNING'" type="danger" icon="delete2" size="mini"
                     @click="handleDeleteSchedule(scope.row.taskId)">删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <!--新增任务-->
    <el-dialog title="新增任务" width="30%" :visible.sync="dialogFormVisible">
      <el-form :model="addScheduleform" :rules="addFormRules" ref="addScheduleform" label-width="100px">
        <el-form-item label="任务名" prop="taskName">
          <el-input v-model="addScheduleform.taskName" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="任务分组" prop="taskGroup">
          <el-input v-model="addScheduleform.taskGroup" disabled></el-input>
        </el-form-item>
        <el-form-item label="描述" prop="desc">
          <el-input v-model="addScheduleform.desc" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="jobClass" prop="jobClass">
          <el-input v-model="addScheduleform.jobClass" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="类型" prop="type" class="is-required">
          <el-radio-group v-model="addScheduleform.type">
            <el-radio :label="1">cron</el-radio>
            <el-radio :label="2">simple</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="CRON表达式" prop="cronExpression" v-show="addScheduleform.type==1">
          <el-input v-model="addScheduleform.cronExpression" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="时间间隔" prop="repeatInterval" v-show="addScheduleform.type==2">
          <el-input-number size="small" v-model="addScheduleform.repeatInterval"></el-input-number>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleAddScheduleCancel">取 消</el-button>
        <el-button type="primary" @click="handleAddScheduleConfirm">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import {
    fetchScheduleList,
    fetchSaveOrUpdateSchedule,
    fetchDeleteScheduleById,
    fetchPauseScheduleById,
    fetchResumeScheduleById,
    fetchRunOnceScheduleById,
    fetchStartScheduleById,
    fetchStopScheduleById
  } from '../../api/sys'
  import { SCHEDULE_STATUS } from './sysConstant'

  export default {
    data () {
      // 权限
      const validatePermission = (rule, value, callback) => {
        if (!value || value.length === 0) {
          callback(new Error('请选择权限'))
        } else {
          callback()
        }
      }
      return {
        tableData: null, // 表数据
        listLoading: false,

        scheduleStatusMap: SCHEDULE_STATUS, // 定时任务状态
        dialogFormVisible: false, // 显示新增任务框

        addScheduleform: { // 新增任务表单
          taskName: '',
          taskGroup: 'default',
          desc: '',
          jobClass: '',
          type: 1,
          cronExpression: '',
          repeatInterval: 0
        },
        // 新增任务表单输入验证规则
        addFormRules: {
          name: [
            {required: true, message: '请输入任务名', trigger: 'blur'}
          ],
          permissionIdList: [
            {validator: validatePermission, trigger: 'change'}
          ]
        }
      }
    },
    mounted () {
      this.getTableData()
    },
    methods: {
      // 获取表格数据
      getTableData () {
        this.listLoading = true
        fetchScheduleList()
          .then(response => {
            let data = response.data
            if (data && data.result) {
              // 遍历处理数据
              this.tableData = data.result.map(item => {
                // 给每一行增加是否可编辑的字段
                item.editable = false
                return item
              })
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 修改任务信息
      handleUpdateSchedule (schedule) {
        // 隐藏可编辑框
        for (let item of this.tableData) {
          if (item.taskId === schedule.taskId) {
            // 隐藏可编辑框
            item.editable = false
            break
          }
        }
        // 提交数据
        this.saveOrUpdateSchedule(schedule)
      },
      // 新增或修改任务
      saveOrUpdateSchedule (schedule) {
        fetchSaveOrUpdateSchedule(JSON.stringify(schedule))
          .then(res => {
            if (res.data.result !== null) {
              this.$message.success('操作成功')
              this.dialogFormVisible = false
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 删除当前任务
      handleDeleteSchedule (taskId) {
        this.$confirm('确认删除此定时任务吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          fetchDeleteScheduleById(taskId)
            .then(res => {
              if (res.data.result !== null) {
                this.$message.success('操作成功')
                this.getTableData()
              }
            })
            .catch(e => {
              console.log(e)
            })
        }).catch(() => {
        })
      },
      // 暂停任务
      handlePauseSchedule (taskId) {
        fetchPauseScheduleById(taskId)
          .then(res => {
            if (res.data.result !== null) {
              this.$message.success('操作成功')
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 重启任务
      handleResumeSchedule (taskId) {
        fetchResumeScheduleById(taskId)
          .then(res => {
            if (res.data.result !== null) {
              this.$message.success('操作成功')
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 任务 启动一次
      handleRunOnceSchedule (taskId) {
        fetchRunOnceScheduleById(taskId)
          .then(res => {
            if (res.data.result !== null) {
              this.$message.success('操作成功')
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 启动任务
      handleStartSchedule (taskId) {
        fetchStartScheduleById(taskId)
          .then(res => {
            if (res.data.result !== null) {
              this.$message.success('操作成功')
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 停止任务
      handleStopSchedule (taskId) {
        fetchStopScheduleById(taskId)
          .then(res => {
            if (res.data.result !== null) {
              this.$message.success('操作成功')
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 确认添加任务
      handleAddScheduleConfirm () {
        this.submitForm('addScheduleform')
      },
      // 取消添加任务
      handleAddScheduleCancel () {
        this.dialogFormVisible = false
        this.resetForm('addScheduleform')
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.saveOrUpdateSchedule(this.addScheduleform)
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      // add Dialog 关闭的回调
      handleDialogClose () {
        this.resetForm('addScheduleform')
      }
    }
  }
</script>

<style lang="scss" scoped>
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
