<template>
  <div class="wrap">
    <div class="tableTitle clearfix"><span class="table-title-word">审批任务</span></div>
    <table>
      <tbody>
      <tr>
        <td>申请编号</td>
        <td>
          {{summaryInfo.applyNum || '/'}}
          <el-tag type="warning" size="mini" v-if="summaryInfo.specialPermit">特批</el-tag>
          <el-tag type="warning" size="mini" v-if="summaryInfo.reconsideration">复议</el-tag>
          <span @click="toApproveHistory" class="toApproveHistory">关联申请</span>
        </td>
        <td>提报店名称</td>
        <td class="wordsStyle">{{summaryInfo.storeName || '/'}}</td>
      </tr>
      <tr>
        <td>客户名称</td>
        <td class="wordsStyle">
          {{summaryInfo.customerName }}
          <span>（信用评级：{{ summaryInfo.riskCustomerLevel || '/' }})</span>
        </td>
        <td>产品方案</td>
        <td>{{summaryInfo.productName || '/'}}</td>
      </tr>
      <tr>
        <td>申请类型</td>
        <td>{{applyType[summaryInfo.applyType] || '/'}}</td>
        <td>租赁类型</td>
        <td>{{leaseType[summaryInfo.leaseType] || '/'}}</td>
      </tr>
      <tr>
        <td>是否先抵押后放款</td>
        <td>{{summaryInfo.isLoanFirst || '/'}}</td>
        <td>车辆类型</td>
        <td>{{carType[summaryInfo.carType] || '/'}}</td>
      </tr>
      <tr>
        <td>发动机号</td>
        <td>{{summaryInfo.carEngine || '/'}}</td>
        <td>车架号</td>
        <td>{{summaryInfo.carVin || '/'}}</td>
      </tr>
      <tr>
        <td>合同编号</td>
        <td>{{summaryInfo.contractNum || '/'}}</td>
        <td>合同放款日期</td>
        <td>{{summaryInfo.contractEffectDate || '/'}}</td>
      </tr>
      <tr>
        <td style="color: red;">合同状态</td>
        <td>{{summaryInfo.contractStatus || '/'}}</td>
        <td>车系类别</td>
        <td>{{summaryInfo.carSeriesDesc || '/'}}</td>
      </tr>
      <tr>
        <td>当前资方</td>
        <td colspan="3">{{capitalDict[summaryInfo.capital] || '/'}}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>
<script>
  import { summuryInfo } from '../../api/caseHandle.js'
  import { mapGetters } from 'vuex'
  import {LEASETYPE, CARTYPE, APPLYTYPE} from '../../utils/constant'
  export default {
    data () {
      return {
        leaseType: LEASETYPE,
        carType: CARTYPE,
        applyType: APPLYTYPE,
        // 概要信息备注
        summaryInfo: {
          applyNum: null,
          storeName: '',
          customerName: '',
          productName: '',
          applyType: null,
          leaseType: null,
          isLoanFirst: '',
          carType: null,
          carEngine: '',
          carVin: '',
          contractNum: '',
          contractEffectDate: '',
          contractStatus: '',
          capital: '',
          carSeriesDesc: '',
          riskCustomerLevel: ''
        },
        capitalDict: {
          '2345': '2345',
          'EX-XW': '新网银行',
          'EX-ZB': '众邦银行'
        }
      }
    },
    computed: {
      ...mapGetters(['applyId'])
    },
    mounted () {
      this.getSummaryInfo(this.applyId) // 获取概要信息
    },
    methods: {
      getSummaryInfo (val) {
        summuryInfo({applyId: val}).then(res => {
          if (res.data.respCode === '1000') {
            this.summaryInfo = res.data.body
            const {capital} = res.data.body
            this.$store.dispatch('saveCaseCapital', {capital}) // 存储资方信息
          }
        }).catch(error => { console.log(error) })
      },
      toApproveHistory () {
        this.$emit('changeTabActiveName', {tabName: '7'})
      }
    }
  }
</script>
<style lang="scss" scoped>
  table {
    border: 1px solid #ccc;
    border-collapse: collapse;
    table-layout: fixed;
    width: 100%;
    td {
      border: 1px solid #ccc;
      padding: 5px;
      font-size: 14px;
      word-wrap: break-word;
      width: 80px;
      &:nth-child(2n) {
        text-align: center;
        vertical-align: middle;
        display: table-cell;
        vertical-align: middle;
      }
      &:nth-child(2n-1) {
        width: 90px;
      }
    }
  }
  h5{
    margin: 5px 0;
  }
  .toApproveHistory{
    color: red;
    text-decoration: underline;
    cursor: pointer;
  }
</style>
