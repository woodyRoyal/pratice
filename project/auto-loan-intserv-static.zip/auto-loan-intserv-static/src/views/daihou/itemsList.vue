<template>
  <div class="materialWrap">
    <div>
      <el-button type="primary" class="materialSaveBtn" @click="saveMaterial" size="mini">保存</el-button>
      <h5>客户实物资料明细</h5>
      <div class="applyType">
        <span>客户类型</span>
        <span v-if="customerType === 1">个人客户</span>
        <span v-else-if="customerType === 2">企业客户</span>
        <span v-else>挂靠客户</span>
      </div>
      <el-table :data="materialList" style="width: 100%" border>
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="资料名称">
          <template slot-scope="scope">
            {{scope.row.fileName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="应收分数">
          <template slot-scope="scope">
            {{scope.row.quantity || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="是否通过">
          <template slot-scope="scope">
            <el-radio-group v-model="scope.row.pass">
              <el-radio :label="1">是</el-radio>
              <el-radio :label="0">否</el-radio>
            </el-radio-group>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div>
      <el-button type="primary" class="cardRecordSaveBtn" size="mini" @click='cardRecordSave'>保存</el-button>
      <h5>产证档案信息</h5>
      <el-form label-position="top" size="small" :model="cardRecordData" ref="cardRecordData" :rules="cardRecordDataRule">
        <el-form-item label="档案保存备注" prop="remark">
          <el-input type="textarea" maxlength="200" v-model="cardRecordData.remark"></el-input>
        </el-form-item>
        <el-form-item label="用车性质" prop="vehicleProperty">
          <el-select v-model="cardRecordData.vehicleProperty">
            <el-option v-for="(item, index) in vehiclePropertyList" :key="index" :label="item.dictName" :value="item.dictValue"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
  import {getItemLists, materialSave, getCardRecordInfo, cardRecordSave} from '../../api/caseHandle'
  import {mapGetters} from 'vuex'
  export default {
    data () {
      return {
        customerType: null,
        materialList: [],
        cardRecordData: {
          vehicleProperty: null
        },
        cardRecordDataRule: {
          remark: [{required: true, trigger: 'blur', message: '内容不可为空'}],
          vehicleProperty: [{required: true, trigger: 'change', message: '内容不可为空'}]
        }
      }
    },
    computed: {
      ...mapGetters(['applyId', 'vehiclePropertyList'])
    },
    mounted () {
      this.itemLists()
      this.cardRecordGet()
    },
    methods: {
      // 客户实物明细
      itemLists () {
        getItemLists(this.applyId).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            this.customerType = data.customerType
            this.materialList = data.materialList
          } else {
            this.$message.warning(res.data.respCode)
          }
        }).catch(error => { console.log(error) })
      },
      // 客户实物保存
      saveMaterial () {
        let data = {applyId: this.applyId, customerType: this.customerType, materialList: this.materialList}
        materialSave(data).then(res => {
          if (res.data.respCode === '1000') {
            this.$message.success('保存成功')
          } else {
            this.$message.warning(res.data.respCode)
          }
        }).catch(error => { console.log(error) })
      },
      // 产证档案信息获取
      cardRecordGet () {
        getCardRecordInfo(this.applyId).then(res => {
          if (res.data.respCode === '1000') {
            this.cardRecordData = res.data.body
          }
        }).catch(error => { console.log(error) })
      },
      // 产证档案保存
      cardRecordSave () {
        this.$refs['cardRecordData'].validate(valid => {
          if (valid) {
            this.cardRecordData.applyId = this.applyId
            cardRecordSave(this.cardRecordData).then(res => {
              if (res.data.respCode === '1000') this.$message.success('保存成功')
            }).catch(error => { console.log(error) })
          } else {
            this.$message.warning('请检查必填字段')
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  h5{
    margin: 5px 0;
  }
  .applyType{
    font-size: 14px;
    margin-bottom: 5px;
  }
  .materialSaveBtn, .cardRecordSaveBtn{
    float: right;
  }
</style>
