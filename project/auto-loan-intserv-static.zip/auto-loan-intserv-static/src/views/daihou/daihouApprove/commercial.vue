<template>
  <div class="commercialWrap">
    <div>
      <div class="formModuleTitle"><span>保单信息（商业险）</span></div>
      <el-form label-position="top" size="small">
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="商业险公司" :label-width="formLable" class="is-required">
              <el-select disabled v-model="commInsurance.insuranceCompany">
                <el-option v-for="(item, index) in insuranceCompanyList" :key="index" :value="item.dictValue" :label="item.dictName"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="商业保险单号" :label-width="formLable" class="is-required">
              <el-input disabled v-model="commInsurance.policyNumber"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="商业险金额(元)" :label-width="formLable" class="is-required">
              <el-input disabled v-model="commInsurance.insuranceAmount"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="商业险保单失效日" :label-width="formLable" class="is-required">
              <el-date-picker type="date" disabled v-model="commInsurance.expirationDate" value-format="yyyy-MM-dd"></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div>
      <div class="formModuleTitle"><span>保单信息（交强险）</span></div>
      <el-form label-position="top" size="small">
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="交强险公司" :label-width="formLable" class="is-required">
              <el-select disabled v-model="compInsurance.insuranceCompany">
                <el-option v-for="(item, index) in insuranceCompanyList" :key="index" :value="item.dictValue" :label="item.dictName"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="交强险保单号" :label-width="formLable" class="is-required">
              <el-input disabled v-model="compInsurance.policyNumber"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="交强险金额(元)" :label-width="formLable" class="is-required">
              <el-input disabled v-model="compInsurance.insuranceAmount"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="交强险保单失效日" :label-width="formLable" class="is-required">
              <el-date-picker type="date" disabled v-model="compInsurance.expirationDate" value-format="yyyy-MM-dd"></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  export default {
    props: ['commercialData'],
    data () {
      return {
        rowGutter: 10,
        colSpan: 8,
        formLable: '152px',
        commInsurance: {},
        compInsurance: {}
      }
    },
    computed: {
      ...mapGetters(['insuranceCompanyList'])
    },
    mounted () {
      const {commInsurance, compInsurance} = this.commercialData
      this.commInsurance = commInsurance
      this.compInsurance = compInsurance
    }
  }
</script>

<style scoped>

</style>
