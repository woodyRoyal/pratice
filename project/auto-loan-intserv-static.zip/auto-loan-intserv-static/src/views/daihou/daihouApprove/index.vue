<template>
  <div class="approve-index-wrap" ref="approveIndexWrap">
    <InsideApproveRemark></InsideApproveRemark>
    <TbRemark></TbRemark>
    <CarRegister :carRegisterInfo="carRegisterInfo" v-if="carRegisterInfo"></CarRegister>
    <Express :expressInfo="expressInfo" v-if="expressInfo"></Express>
    <Receipt :invoiceData="invoiceData" v-if="invoiceData"></Receipt>
    <Commercial :commercialData="commercialData" v-if="commercialData"></Commercial>
    <!--<file :fileLists="fileLists" v-if="fileLists"></file>-->
  </div>
</template>

<script>
  import InsideApproveRemark from '../../components/insideApproveRemark'
  import TbRemark from '../../components/tbInfoRemark'
  import CarRegister from './carRegister'
  import Express from './kuaidi'
  import Receipt from './fapiao'
  import Commercial from './commercial'
  import {getApplyMoneyInfo} from '../../../api/fangkuan' // 贷后也要用到该接口的内容
  import {getDaihouApproveFormInfo} from '../../../api/daihou' // 贷后也要用到该接口的内容
  import {mapGetters} from 'vuex'
  export default {
    data () {
      return {
        commercialData: null,
        invoiceData: {
          salesUnit: '',
          invoiceCode: '',
          invoiceAmount: '',
          invoiceAmountTax: '',
          invoiceNumber: '',
          taxpayerNumber: '',
          billingDate: '',
          resultCode: '',
          resultMsg: ''
        },
        replamentCardData: {
          accountType: null,
          name: '',
          bankType: null,
          bankAddrName: '',
          bankNum: null,
          debitCardNum: null,
          phone: null,
          payCardCredNum: null
        },
        carRegisterInfo: {
          productionLicenseId: null,
          registerLicenseId: null,
          mortgageDate: null,
          manufactureDate: null,
          carLicencePlate: null
        },
        expressInfo: {
          expressId: null,
          sendDate: null,
          company: null,
          content: null,
          remark: null
        }
      }
    },
    components: {
      InsideApproveRemark,
      TbRemark,
      CarRegister,
      Express,
      Receipt,
      Commercial
    },
    computed: {
      ...mapGetters(['applyId'])
    },
    mounted () {
      this.getInfo(this.applyId)
      this.getCarRegisterInfo(this.applyId)
      this.autoHeight()
      window.addEventListener('resize', this.autoHeight)
    },
    destroyed () {
      window.removeEventListener('resize', this.autoHeight)
    },
    methods: {
      // 发票相关信息
      getInfo (val) {
        getApplyMoneyInfo(val).then(res => {
          if (res.data.respCode === '1000') {
            const {commercialInsurance, compulsoryInsurance, invoiceVO} = res.data.body
            this.commercialData = {commInsurance: commercialInsurance, compInsurance: compulsoryInsurance}
            this.invoiceData = invoiceVO
          }
        }).catch(error => { console.log(error) })
      },
      getCarRegisterInfo (val) {
        getDaihouApproveFormInfo(val).then(res => {
          if (res.data.respCode === '1000') {
            const {carRegisterVO, expressVO} = res.data.body
            this.carRegisterInfo = carRegisterVO
            this.expressInfo = expressVO
          }
        }).catch(error => { console.log(error) })
      },
      autoHeight () {
        let clientHeight = document.documentElement.clientHeight
        this.$refs['approveIndexWrap'].style.height = (clientHeight - 55) + 'px'
      }
    }
  }
</script>

<style scoped lang="scss">
  .approve-index-wrap{
    overflow-y: auto;
    overflow-x: hidden;
  }
</style>
