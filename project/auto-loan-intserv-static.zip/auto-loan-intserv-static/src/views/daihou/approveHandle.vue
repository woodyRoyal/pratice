<template>
  <div class="approveHandle">
    <div class="materialWrap">
      <!--客户实物资料明细-->
      <div>
        <div class="tableTitle clearfix">
          <span class="table-title-word">客户实物资料明细</span>
          <el-button type="primary" class="materialSaveBtn" @click="saveMaterial" size="mini">保存</el-button>
        </div>
        <div class="applyType">
          <span>客户类型: </span>
          <el-tag size="small" type="danger" v-if="customerType === 1">个人客户</el-tag>
          <el-tag size="small" type="danger" v-else-if="customerType === 2">企业客户</el-tag>
          <el-tag size="small" type="danger" v-else>挂靠客户</el-tag>
        </div>
        <el-table :data="materialList" style="width: 100%" border>
          <el-table-column label="序号" type="index"></el-table-column>
          <el-table-column label="资料名称">
            <template slot-scope="scope">
              {{scope.row.fileName || '/'}}
            </template>
          </el-table-column>
          <el-table-column label="应收分数">
            <template slot-scope="scope">
              {{scope.row.quantity || '/'}}
            </template>
          </el-table-column>
          <el-table-column label="是否通过">
            <template slot-scope="scope">
              <el-radio-group v-model="scope.row.pass">
                <el-radio :label="1">是</el-radio>
                <el-radio :label="0">否</el-radio>
              </el-radio-group>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <!--产证档案信息-->
      <div>
        <div class="tableTitle clearfix">
          <span class="table-title-word">产证档案信息</span>
          <el-button type="primary" class="cardRecordSaveBtn" size="mini" @click='cardRecordSaveHandle'>保存</el-button>
        </div>
        <el-form label-position="top" size="small" :model="cardRecordData" ref="cardRecordData" :rules="cardRecordDataRule">
          <el-form-item label="档案保存备注" prop="remark">
            <el-input type="textarea" maxlength="200" v-model="cardRecordData.remark"></el-input>
          </el-form-item>
          <el-form-item label="用车性质" prop="vehicleProperty">
            <el-select v-model="cardRecordData.vehicleProperty">
              <el-option v-for="(item, index) in vehiclePropertyList" :key="index" :label="item.dictName" :value="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!--审批操作-->
    <div>
      <div class="formModuleTitle">
        <span class="formModuleTitle-words">审批操作</span>
        <span class="important-tips" v-if="Boolean(isShowNewNetsModule)" v-cloak>重要提示：请达到通过条件再提交新网审核！以避免资料不全产生代偿。如“贷1或贷2”审核结果“拒绝”无需在推送</span>
      </div>
      <!--新网-->
      <XwAfterLoanApproveRes
        :is-show-new-nets-module="isShowNewNetsModule"
        :new-nets-info="newNetsInfo"
        @filesToNewNetsHandle="filesToNewNets"
        @queryXWApprove="getNewNetsDaiHouApproveHandle"
        @backBuyHandle="backBuy"
      >
      </XwAfterLoanApproveRes>
      <!--审批操作form-->
      <el-form :model="approveHandleData" label-position="left" size="mini" :rules="approveHandleDataRules" ref="approveHandleData" :inline-message="true">
        <el-form-item label="审批意见" label-width="18%" prop="operateResult">
          <el-select v-model="approveHandleData.operateResult">
            <el-option v-for="(item, index) in approveHandleList" :key="index" :label="item.desc" :value="item.result"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="审批备注" label-width="18%" prop="approveRemarks">
          <el-input type='textarea' v-model="approveHandleData.approveRemarks"  :maxlength="500" :rows="8" :autosize="true"></el-input>
        </el-form-item>
        <el-form-item label="经销商提醒" label-width="18%" prop="approveRemind">
          <el-input type='textarea' v-model="approveHandleData.approveRemind"  :maxlength="500" :rows="8" :autosize="true"></el-input>
        </el-form-item>
      </el-form>
      <div class="handleBtns">
        <div>
          <el-button type="primary" size="small" @click="submitFn" :loading="submitLoading">提交</el-button>
        </div>
      </div>
    </div>
    <!--回购dialog-->
    <el-dialog title="重要提示" :visible.sync="buyBackDialogVisible" @closed="backBuyClosed">
      <p style="text-align: center">请确认是否需要操作回购</p>
      <el-form :model="buyBackData" :rules="buyBackDataRule" ref="buyBackData">
        <el-form-item label="备注" prop="buyBackReason">
          <el-input type="textarea" v-model="buyBackData.buyBackReason"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="buyBackDialogVisible = false">取 消</el-button>
        <el-button size="mini" type="primary" @click="confirmBuyBack">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import XwAfterLoanApproveRes from '../components/xwAfterLoanApproveStatus'
  import {
    getItemLists,
    materialSave,
    getCardRecordInfo,
    cardRecordSave,
    daihouApproveHandleList,
    newNetsDaiHouApproveHandle,
    filesUploadNewNets,
    buyBackFromNewNets,
    haveRead,
    approveSubmit} from '../../api/caseHandle.js'
  export default {
    components: { XwAfterLoanApproveRes },
    data () {
      return {
        customerType: null,
        materialList: [], // 客户实物
        cardRecordData: {
          vehicleProperty: null
        },
        cardRecordDataRule: {
          remark: [{required: true, trigger: 'blur', message: '内容不可为空'}],
          vehicleProperty: [{required: true, trigger: 'change', message: '内容不可为空'}]
        },
        windowCloseTimer: null,
        approveHandleList: [], // 审批意见选项
        approveHandleData: {},
        approveHandleDataRules: {
          operateResult: [{required: true, message: '内容不得为空', trigger: 'change'}],
          approveRemarks: [{required: true, message: '内容不得为空', trigger: 'blur'}]
        },
        // 查询已读
        queryHaveRead: {
          applyId: null
        },
        isShowNewNetsModule: 0, // 是否显示新网
        // 新网信息
        newNetsInfo: {
          task1StatusDesc: '',
          task1ApprovalDesc: '',
          task1Code: '',
          task1Desc: '',
          task2StatusDesc: '',
          task2ApprovalDesc: '',
          task2Code: '',
          task2Desc: ''
        },
        buyBackDialogVisible: false, // 回购弹窗显示
        // 确认回购数据
        buyBackData: {
          applyId: null,
          buyBackReason: ''
        },
        buyBackDataRule: {
          buyBackReason: [{required: true, message: '内容不得为空', trigger: 'blur'}]
        },
        submitLoading: false
      }
    },
    mounted () {
      this.itemLists()
      this.cardRecordGet()
      this.getApproveHandleList()
      this.getNewNetsDaiHouApproveHandle()
    },
    computed: {
      ...mapGetters(['authority', 'applyId', 'applyType', 'vehiclePropertyList', 'storeCapital'])
    },
    methods: {
      // 客户实物
      itemLists () {
        getItemLists(this.applyId).then(res => {
          if (res.data.respCode === '1000') {
            const { customerType, materialList } = res.data.body
            this.customerType = customerType
            this.materialList = materialList
          }
        }).catch(error => { console.log(error) })
      },
      // 客户实物保存
      saveMaterial () {
        let data = {applyId: this.applyId, customerType: this.customerType, materialList: this.materialList}
        materialSave(data).then(res => {
          if (res.data.respCode === '1000') this.$message.success('保存成功')
        }).catch(error => { console.log(error) })
      },
      // 产证档案
      cardRecordGet () {
        getCardRecordInfo(this.applyId).then(res => {
          if (res.data.respCode === '1000') this.cardRecordData = res.data.body
        }).catch(error => { console.log(error) })
      },
      // 产证档案保存
      cardRecordSaveHandle (needMsgBox = true) {
        return new Promise((resolve, reject) => {
          this.$refs['cardRecordData'].validate(valid => {
            if (valid) {
              this.cardRecordData.applyId = this.applyId
              cardRecordSave(this.cardRecordData).then(res => {
                if (res.data.respCode === '1000') {
                  if (needMsgBox) this.$message.success('产证档案信息保存成功')
                  resolve(1)
                }
              }).catch(err => {
                reject(err)
              })
            } else {
              resolve(0) // 用于 submitLoading 的判断
              if (needMsgBox) this.$message.warning('请检查产证档案信息必填字段')
            }
          })
        })
      },
      // 审批意见下拉
      getApproveHandleList () {
        daihouApproveHandleList({}).then(res => {
          if (res.data.respCode === '1000') this.approveHandleList = res.data.body
        }).catch(error => { console.log(error) })
      },
      // 查询新网审核结果
      getNewNetsDaiHouApproveHandle () {
        newNetsDaiHouApproveHandle(this.applyId).then(res => {
          if (res.data.respCode === '1000') {
            this.newNetsInfo = res.data.body || {}
            this.isShowNewNetsModule = JSON.stringify(this.newNetsInfo) !== '{}' ? 1 : 0
          }
        }).catch(err => { console.log(err) })
      },
      // 贷后资料提交新网
      filesToNewNets () {
        this.$confirm('<p style="color: red; text-align: left">请确认已按需求更新材料，为避免不合格被回购，请确认后操作</p>', '贷后资料推送', {
          cancelButtonText: '取消',
          confirmButtonText: '确认推送',
          dangerouslyUseHTMLString: true,
          center: true
        }).then(() => {
          filesUploadNewNets(this.applyId).then(res => {
            if (res.data.respCode === '1000') this.$message.success('操作成功')
          })
        }).catch(() => {})
      },
      // 校验已读
      checkHaveRead (needMsgBox = true) {
        this.queryHaveRead.applyId = this.applyId
        return new Promise((resolve, reject) => {
          haveRead(this.queryHaveRead).then(res => {
            if (res.data.respCode === '1000') {
              const flag = res.data.body
              if (!flag) {
                if (needMsgBox) this.$message.warning('请检查未读的消息')
              }
              resolve(res.data.body)
            }
          }).catch(err => {
            reject(err)
          })
        })
      },
      // 确认是否要提交
      confirmSubmit () {
        return new Promise(resolve => {
          this.$confirm('<p style="color: red; text-align: left">请仔细检查资料推送状态及审核结果，避免资料未推送，请确认后操作</p>', '提交归档', {
            cancelButtonText: '取消',
            confirmButtonText: '确认归档',
            dangerouslyUseHTMLString: true,
            center: true
          }).then(() => {
            resolve(1)
          }).catch(() => {
            resolve(0)
          })
        })
      },
      // 提交
      async submitFn () {
        let sureSubmit = 1
        if (this.storeCapital === 'EX-XW' && this.approveHandleData.operateResult !== 'sendback' && this.approveHandleData.operateResult) sureSubmit = await this.confirmSubmit()
        if (!sureSubmit) return false
        this.submitLoading = true
        let haveReadStatus = null
        let cardRecordSaveStatus = null
        try {
          haveReadStatus = await this.checkHaveRead(false)
          cardRecordSaveStatus = await this.cardRecordSaveHandle(false)
          if (!haveReadStatus || !cardRecordSaveStatus) {
            this.$message.warning('请检查未读信息或产证档案')
            this.submitLoading = false
            return false
          }
        } catch (e) {
          this.submitLoading = false
          return false
        }
        // 审批操作校验
        this.$refs['approveHandleData'].validate(valid => {
          if (!valid) {
            this.submitLoading = false
            this.$message.warning('请检查审批操作的必填字段')
          } else {
            if (haveReadStatus && cardRecordSaveStatus) this.submitAjax()
          }
        })
      },
      // 提交ajax
      submitAjax () {
        this.approveHandleData.applyId = this.applyId
        if (this.storeCapital === 'EX-ZB') this.$emit('updateFilePushLoading', {loading: true})
        approveSubmit(this.approveHandleData).then(res => {
          this.submitLoading = false
          if (this.storeCapital === 'EX-ZB') this.$emit('updateFilePushLoading', {loading: false})
          if (res.data.respCode === '1000') {
            this.$message.success('操作完成，页面即将关闭！')
            this.$refs['approveHandleData'].resetFields()
            window.onbeforeunload = null
            clearTimeout(this.windowCloseTimer)
            this.windowCloseTimer = setTimeout(() => { window.close() }, 3000)
          }
        }).catch(error => {
          this.submitLoading = false
          if (this.storeCapital === 'EX-ZB') this.$emit('updateFilePushLoading', {loading: false})
          console.log(error)
        })
      },
      // 回购
      backBuy () {
        this.buyBackDialogVisible = true
        this.$refs['buyBackData'] && this.$refs['buyBackData'].resetFields()
      },
      // 确认回购
      confirmBuyBack () {
        this.$refs['buyBackData'].validate(valid => {
          if (valid) {
            this.buyBackData.applyId = this.applyId
            buyBackFromNewNets(this.buyBackData).then(res => {
              if (res.data.respCode === '1000') {
                this.$message.success('操作成功')
                this.buyBackDialogVisible = false
              } else {
                this.$message.warning('操作失败，不满足回购要求')
                this.buyBackDialogVisible = false
              }
            }).catch(err => { console.log(err) })
          } else {
            this.$message.warning('请检查必填信息')
          }
        })
      },
      // 回购弹窗关闭
      backBuyClosed () {
        this.$refs['buyBackData'] && this.$refs['buyBackData'].resetFields()
      }
    }
  }
</script>
<style lang="scss" scoped>
  p{
    margin: 0;
  }
  .important-tips{
    color: red;
    font-size: 12px;
    float: right;
    margin-right: 2px;
  }
  .applyType{
    font-size: 14px;
    margin-bottom: 5px;
  }
  .materialSaveBtn, .cardRecordSaveBtn{
    float: right;
  }
  .approveHandle{
    margin-top: 5px;
  }
  .materialWrap{
    >div{
      margin-top: 5px;
    }
  }
  .handleBtns{
    width: 100%;
    &>div{
      float: right;
    }
  }
  .formModuleTitle{
    align-items: center;
    >span {
      &.formModuleTitle-words{
        width: 64px;
        flex-shrink: 0;
        border-bottom: 2px solid #0156b7;
      }
      &:nth-child(2){
        border-bottom: none;
      }
    }
  }
  .el-message-box__message p{
    color: red !important;
  }
</style>
