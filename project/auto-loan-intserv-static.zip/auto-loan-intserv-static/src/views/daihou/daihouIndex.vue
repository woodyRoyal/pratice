<!--贷后管理首页-->
<template>
  <div>
    <!--查询表单-->
    <div class="queryArea">
      <el-form label-position="left" size="small" :inline="true">
        <!-- <el-row :gutter="rowGutter"> -->
          <!-- <el-col :span="colSpan"> -->
            <!-- checkApplyId(queryData.oldApplyId, 'oldApplyId',7) -->
            <el-form-item label="申请编号" :label-width="formLable">
              <el-input maxlength="8" v-model="queryData.applyId" @blur="checkApplyId(queryData.applyId)" placeholder="输入申请编号" onkeypress='return(/^[0-9]*$/.test(String.fromCharCode(event.keyCode)))'></el-input>
            </el-form-item>
            <el-form-item label="申请编号(老)" :label-width="formLable">
              <el-input maxlength="7" v-model="queryData.oldApplyNo" @blur="checkApplyId(queryData.oldApplyNo,'oldApplyNo',7)" placeholder="申请编号(老)" onkeypress='return(/^[0-9]*$/.test(String.fromCharCode(event.keyCode)))'></el-input>
            </el-form-item>
          <!-- </el-col> -->
          <!-- <el-col :span="colSpan"> -->
            <el-form-item label="客户姓名" :label-width="formLable">
              <el-input maxlength="20" v-model="queryData.name" placeholder="输入客户姓名"></el-input>
            </el-form-item>
          <!-- </el-col> -->
          <!-- <el-col :span="colSpan"> -->
            <el-form-item label="合同号码" :label-width="formLable">
              <el-input v-model="queryData.contractNum" placeholder="输入合同号码"></el-input>
            </el-form-item>
          <!-- </el-col> -->
          <!-- <el-col :span="colSpan"> -->
            <el-form-item>
              <div class="queryBtnsArea">
                <el-button size="small" type="primary" @click="queryFn">查询</el-button>
                <el-button size="small" type="primary" @click="resetQueryFn">重置</el-button>
              </div>
            </el-form-item>
          <!-- </el-col> -->
        <!-- </el-row> -->
      </el-form>
    </div>
    <!--列表-->
    <div class="listArea">
      <el-table :data="listData" border style="width: 100%">
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="申请编号">
          <template slot-scope="scope">
            {{scope.row.applyId || '/'}}
            <el-tag type="warning" size="mini" v-if="scope.row.specialPermit">特批</el-tag>
            <el-tag type="warning" size="mini" v-if="scope.row.reconsideration">复议</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="申请编号(老)" >
          <template slot-scope="scope">
            <!--老系统显示 oldApplyNo，新系统显示 '/'-->
            {{scope.row.oldApplyNo || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="申请类型">
          <template slot-scope="scope">
            {{applyType[scope.row.applyType] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="客户名称">
          <template slot-scope="scope">
            {{scope.row.name || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="产品方案">
          <template slot-scope="scope">
            {{scope.row.productName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="租赁类型">
          <template slot-scope="scope">
            {{leaseType[scope.row.leaseType] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="车辆类型">
          <template slot-scope="scope">
            {{carType[scope.row.carType] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="融资额">
          <template slot-scope="scope">
            {{scope.row.amount || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="首付（%）">
          <template slot-scope="scope">
            {{scope.row.downPaymentRate === null ? '/' : scope.row.downPaymentRate}}
          </template>
        </el-table-column>
        <el-table-column label="任务类型">
          <template slot-scope="scope">
            {{daihouTaskTypeDict[scope.row.taskType] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="任务创建时间">
          <template slot-scope="scope">
            {{scope.row.created || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="操作" fixed="right">
          <template slot-scope="scope">
            <!--operatorId = '' 代表案子不在任何人手里，可以被领取 、 operatorId === userId 代表自己已经领取了-->
            <el-button v-if="!scope.row.operatorId || Number(scope.row.operatorId) === Number(userId)" size="small" type="text" @click="handleCase(scope.row)">我要办理</el-button>
            <el-button v-else disabled size="small" type="text">我要办理</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="clearfix">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="page.pageNum"
          :page-sizes="page.pageSizeArr"
          :page-size="page.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="page.total"
          class="tablePage">
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
  import {APPLYTYPE, LEASETYPE, CARTYPE, checkApplyId} from '../../utils/constant'
  import {checkToDetail, listInfo} from '../../api/daihou'
  import {mapGetters} from 'vuex'
  export default {
    data () {
      return {
        applyType: APPLYTYPE,
        leaseType: LEASETYPE,
        carType: CARTYPE,
        checkApplyId,
        rowGutter: 10,
        colSpan: 6,
        formLable: '100px',
        queryData: {
          oldApplyNo: null,
          applyId: null,
          name: null,
          contractNum: null
        },
        listData: [],
        page: {
          pageNum: 1,
          pageSize: 10,
          pageSizeArr: [10, 20, 30, 40],
          total: 0
        }
      }
    },
    mounted () {
      this.getListInfo()
    },
    computed: {
      ...mapGetters(['daihouTaskTypeDict', 'userId'])
    },
    methods: {
      getListInfo () {
        this.queryData.pageSize = this.page.pageSize
        this.queryData.pageNum = this.page.pageNum
        listInfo(this.queryData).then(res => {
          if (res.data.respCode === '1000') {
            this.listData = res.data.body.list
            this.page.total = res.data.body.total
          }
        }).catch(error => { console.log(error) })
      },
      // 我要办理
      handleCase (val) {
        checkToDetail(val.id).then(res => {
          if (res.data.respCode === '1000') {
            window.open('#/daihouDetail/' + val.id + '/' + val.applyType, '_blank')
          }
        }).catch(error => { console.log(error) })
      },
      queryFn () {
        this.getListInfo()
      },
      resetQueryFn () {
        for (let k in this.queryData) {
          this.queryData[k] = null
        }
        this.getListInfo()
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.getListInfo()
      },
      handleCurrentChange (val) {
        this.page.pageNum = val
        this.getListInfo()
      }
    }
  }
</script>

<style lang="scss" scoped>
  .queryBtnsArea{
    float: right;
  }
  .listArea{
    width: 100%;
  }
</style>
