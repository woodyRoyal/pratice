<template>
  <div class="dealer-base-info-wrapper">
    <el-form label-position="top" label-width="180px" :model="dealerInfoForm" :rules="rules" ref="dealerInfoForm">
    <p class="title">基本信息</p>
      <el-row>
        <el-col :span="8">
          <el-form-item label="经销商简称：" prop="dealerInfoVO.shortName">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerInfoVO.shortName"></el-input>
          </el-form-item>
          <el-form-item label="店面联系人：" prop="dealerInfoVO.linkman">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerInfoVO.linkman"></el-input>
          </el-form-item>
          <el-form-item label="店面省份-城市：" prop="cityProvince">
            <el-cascader class="width" size="small" :options="provinceCityList" v-model="cityProvince" :props="props"></el-cascader>
          </el-form-item>
          <el-form-item label="区域经理：" prop="dealerInfoVO.regionalManager">
            <el-select v-model="dealerInfoForm.dealerInfoVO.regionalManager" placeholder="请选择" size="small" class="width">
              <el-option v-for="item in regionalManager" :label="item.displayName" :value="item.id" :key="item.id"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="经销商全称：" prop="dealerInfoVO.fullName">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerInfoVO.fullName" @blur="handleFullNameBlur"></el-input>
          </el-form-item>
          <el-form-item label="店面联系人手机号：" prop="dealerInfoVO.linkmanPhone">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerInfoVO.linkmanPhone" :maxlength="11"></el-input>
          </el-form-item>
          <el-form-item label="店面地址：" prop="dealerInfoVO.address">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerInfoVO.address"></el-input>
          </el-form-item>
          <el-form-item label="放款主体：" prop="dealerInfoVO.loanOrg">
            <el-select v-model="dealerInfoForm.dealerInfoVO.loanOrg" size="small" class="width">
              <el-option v-for="item in loanOrg" :value="item.dictValue" :label="item.dictName" :key="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="统一社会信用代码：" prop="dealerInfoVO.creditCode">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerInfoVO.creditCode"></el-input>
          </el-form-item>
          <el-form-item label="店面联系电话：" prop="dealerInfoVO.storePhone">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerInfoVO.storePhone"></el-input>
          </el-form-item>
          <el-form-item label="销售上级：" prop="dealerInfoVO.parentBody">
            <!--<el-select  v-model="dealerInfoForm.dealerInfoVO.parentBody" placeholder="请选择" size="small" class="width">-->
              <!--<el-option value="1">1</el-option>-->
            <!--</el-select>-->
            <el-cascader size="small" class="width" :options="parentBodyData" v-model="dealerInfoForm.dealerInfoVO.parentBody" :props="parentBodyProps" :show-all-levels="false"></el-cascader>
          </el-form-item>
          <el-form-item label="放款主体对应抵押省份：" prop="dealerInfoVO.mortgageProvince">
            <el-select multiple collapse-tags v-model="dealerInfoForm.dealerInfoVO.mortgageProvince" size="small" class="width" @change="handleChooseProvince">
              <el-option value="">全选/取消</el-option>
              <el-option v-for="item in provinceList" :label="item.tarToponym" :value="item.tarAddkey" :key="item.tarAddkey"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
    <p class="title">资质信息</p>
      <el-row>
        <el-col :span="8">
          <el-form-item label="店面属性：" prop="dealerCreditVo.storeType">
            <el-select v-model="dealerInfoForm.dealerCreditVo.storeType" placeholder="请选择" size="small" class="width">
              <el-option v-for="item in storeType" :value="item.dictValue" :key="item.dictValue" :label="item.dictName"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="GPS厂商授权：" prop="dealerCreditVo.gpsSupplier">
            <el-select v-model="dealerInfoForm.dealerCreditVo.gpsSupplier" placeholder="请选择" size="small" class="width">
              <el-option v-for="item in gpsSupplier" :value="item.dictValue" :key="item.dictValue" :label="item.dictName"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="经销商等级：" prop="dealerCreditVo.dealerClass">
            <el-select v-model="dealerInfoForm.dealerCreditVo.dealerClass" placeholder="请选择" size="small" class="width">
              <el-option v-for="item in dealerClass" :value="item.dictValue" :key="item.dictValue" :label="item.dictName"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="业务种类：" prop="dealerCreditVo.bizLines">
            <el-checkbox-group v-model="dealerInfoForm.dealerCreditVo.bizLines" @change="handleCheckedBizLinesChange">
              <el-checkbox v-for="item in businessType" :label="item.dictValue" :key="item.dictValue">{{item.dictName}}</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
          <el-form-item label="新车是否先抵押后放款：" prop="dealerCreditVo.newCarLoanType">
            <el-radio-group v-model="dealerInfoForm.dealerCreditVo.newCarLoanType" @change="handleCheckedNewCarLoanTypeChange">
              <el-radio v-for="item in yesOrNoList" :label="item.dictValue" :key="item.dictValue">{{item.dictName}}</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="租赁属性：" prop="dealerCreditVo.leaseType">
            <el-checkbox-group v-model="dealerInfoForm.dealerCreditVo.leaseType" @change="handleCheckedNewCarLoanTypeChange">
              <el-checkbox v-for="item in leaseTypeList" :label="item.dictValue" :key="item.dictValue">{{ item.dictName }}</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
          <el-form-item label="二手车是否先抵押后放款：" prop="dealerCreditVo.oldCarLoanType">
            <el-radio-group v-model="dealerInfoForm.dealerCreditVo.oldCarLoanType" @change="handleCheckedNewCarLoanTypeChange">
              <el-radio v-for="item in yesOrNoList" :label="item.dictValue" :key="item.dictValue">{{item.dictName}}</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
      </el-row>
    <p class="title">保证金信息</p>
      <el-row>
        <el-col :span="8">
          <el-form-item label="业务保证金(元)：" prop="dealerDepositVO.bizDeposit">
            <el-input size="small" class="width" v-model.number="dealerInfoForm.dealerDepositVO.bizDeposit" onkeypress='return( /[\d]/.test(String.fromCharCode(event.keyCode)))'></el-input>
          </el-form-item>
          <el-form-item label="保证金备注：" prop="dealerDepositVO.depositRemark">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerDepositVO.depositRemark" ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="基础保证金（元）：" prop="dealerDepositVO.baseDeposit">
            <el-input size="small" class="width" v-model.number="dealerInfoForm.dealerDepositVO.baseDeposit" onkeypress='return( /[\d]/.test(String.fromCharCode(event.keyCode)))'></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="担保比例：" prop="dealerDepositVO.depositRate">
            <el-select v-model="dealerInfoForm.dealerDepositVO.depositRate"  placeholder="请选择" size="small" class="width">
              <el-option v-for="item in depositRate" :value="item.dictValue" :key="item.dictValue" :label="item.dictName"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
    <p class="title">开票信息</p>
      <el-row>
        <el-col :span="8">
          <el-form-item label="单位名称：" prop="dealerInvoiceVo.invoiceUnitName">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerInvoiceVo.invoiceUnitName"></el-input>
          </el-form-item>
          <el-form-item label="纳税人识别号：" prop="dealerInvoiceVo.dealerTaxId">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerInvoiceVo.dealerTaxId"></el-input>
          </el-form-item>
          <el-form-item label="税率：" prop="dealerInvoiceVo.invoiceRate">
            <el-select v-model="dealerInfoForm.dealerInvoiceVo.invoiceRate" placeholder="请选择" size="small" class="width">
              <el-option v-for="item in invoiceRate" :label="item.dictName" :value="item.dictValue" :key="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="单位通讯地址：" prop="dealerInvoiceVo.invoiceUnitAddress">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerInvoiceVo.invoiceUnitAddress"></el-input>
          </el-form-item>
          <el-form-item label="银行账户：" prop="dealerInvoiceVo.bankAccount">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerInvoiceVo.bankAccount"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="开户银行：" prop="dealerInvoiceVo.bankName">
            <el-select v-model="dealerInfoForm.dealerInvoiceVo.bankName" placeholder="请选择" size="small" class="width">
              <el-option v-for="item in dealerAccountBank" :label="item.dictName" :value="item.dictValue" :key="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="单位电话：" prop="dealerInvoiceVo.invoiceUnitTel">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerInvoiceVo.invoiceUnitTel"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    <p class="title">收款账号信息</p>
      <el-row>
        <el-col :span="8">
          <!--<el-form-item label="单位名称：" prop="dealerAccountVO.unitName">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerAccountVO.unitName"></el-input>
          </el-form-item>-->
          <el-form-item label="收款方账户名：" prop="dealerAccountVO.accountName">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerAccountVO.accountName"></el-input>
          </el-form-item>
          <el-form-item label="收款账号：" prop="dealerAccountVO.account">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerAccountVO.account"></el-input>
          </el-form-item>
          <el-form-item label="开户行省份-城市：" prop="accountCityProvince">
            <el-cascader class="width" size="small" :options="provinceCityList" v-model="accountCityProvince" :props="props"></el-cascader>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="账户类型：" prop="dealerAccountVO.accountType">
            <el-select v-model="dealerInfoForm.dealerAccountVO.accountType" placeholder="请选择" size="small" class="width" disabled>
              <el-option v-for="item in accountType" :label="item.dictName" :value="item.dictValue" :key="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="收款方支行：" prop="dealerAccountVO.branchName">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerAccountVO.branchName"></el-input>
          </el-form-item>
          <el-form-item label="备注：">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerAccountVO.remark"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="收款方银行：" prop="dealerAccountVO.bankName">
            <el-select  v-model="dealerInfoForm.dealerAccountVO.bankName" placeholder="请选择" size="small" class="width">
              <el-option v-for="item in dealerAccountBank" :label="item.dictName" :value="item.dictValue" :key="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="收款方移动电话：" prop="dealerAccountVO.phone">
            <el-input size="small" class="width" v-model="dealerInfoForm.dealerAccountVO.phone" :maxlength="11"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    <p class="title">授权区域</p>
      <el-form-item label="授权区域：" prop="areaId">
        <el-tree class="tree-height" @check="handleNodeClick" ref="menuTree" node-key="key" :data="provinceCityWholeList" show-checkbox :props="defaultProps"></el-tree>
      </el-form-item>
    <p class="title">信息备注</p>
      <el-form-item label="备注：">
         <el-input type="textarea" v-model="dealerInfoForm.dealerInfoVO.remark" :autosize="{ minRows: 5}" size="small" class="width1"></el-input>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  import dealerApi from '../../api/dealer'
  import userApi from '../../api/user'
  import { mapGetters } from 'vuex'
  export default {
    computed: {
      ...mapGetters([
        'loanOrg',
        'provinceKeyList',
        'provinceList',
        'dealerAccountBank',
        'provinceCityWholeList',
        'provinceCityList',
        'gpsSupplier',
        'accountType',
        'businessType',
        'dealerClass',
        'depositRate',
        'storeType',
        // 'bankNameList',
        'invoiceRate'
      ])
    },
    mounted () {
      // 获取销售上级
      this.getParentBody()
      // 区域经理
      this.getRegionalManager()
      // 获取城市下拉
      this.getProvinceCityList()
      // 获取所有省份下拉
      this.getProvince()
      if (this.$route.params.id !== 'null') {
        this.getBaseInfo()
      }
    },
    props: {
    },
    data () {
      let regPhone = /^1[0-9]{10}$/
      let cityProvince = (rule, value, callback) => {
        if (!this.cityProvince.length) {
          callback(new Error('请选择店面省份-城市'))
        } else {
          callback()
        }
      }
      let accountCityProvince = (rule, value, callback) => {
        if (!this.accountCityProvince.length) {
          callback(new Error('请选择开户省份-城市'))
        } else {
          callback()
        }
      }
      let areaId = (rule, value, callback) => {
        if (!this.$refs.menuTree.getCheckedNodes().length) {
          callback(new Error('请选择授权区域'))
        } else {
          callback()
        }
      }
      let phone = (rule, value, callback) => {
        if (value.trim() === '') {
          callback(new Error('请输入手机号'))
        } else {
          if (!regPhone.test(value)) {
            callback(new Error('请输入正确的手机号格式'))
          } else {
            callback()
          }
        }
      }
      return {
        regionalManager: [], // 区域经理
        parentBodyData: [],
        leaseTypeList: [
          {'dictValue': 1, 'dictName': '直租'},
          {'dictValue': 0, 'dictName': '回租'}
        ],
        yesOrNoList: [
          {'dictValue': 1, 'dictName': '是'},
          {'dictValue': 0, 'dictName': '否'}
        ],
        cityProvince: [], // 省份城市
        areaId: [], // 授权区域
        defaultProps: {
          children: 'list',
          label: 'name'
        },
        parentBodyProps: {
          children: 'children',
          label: 'orgName',
          value: 'orgId'
        },
        accountCityProvince: [],
        // 省份城市配置
        props: {
          value: 'key',
          label: 'name',
          children: 'list'
        },
        // 业务种类
        dealerInfoForm: {
          dealerAccountVO: {
            unitName: '',
            accountName: '',
            phone: '',
            accountType: 1,
            account: '',
            bankName: '',
            branchName: '',
            city: '',
            province: '',
            remark: ''
          },
          dealerAreaVOList: [],
          dealerCreditVo: {
            storeType: '',
            gpsSupplier: '',
            dealerClass: '',
            bizLines: [],
            newCarLoanType: null,
            leaseType: [],
            oldCarLoanType: ''
          },
          dealerDepositVO: {
            bizDeposit: '',
            depositRemark: '',
            baseDeposit: '',
            depositRate: ''
          },
          dealerInfoVO: {
            mortgageProvince: [],
            loanOrg: '',
            shortName: '',
            linkman: '',
            regionalManager: '',
            fullName: '',
            linkmanPhone: '',
            address: '',
            creditCode: '',
            storePhone: '',
            city: '',
            province: '',
            parentBody: [],
            remark: ''
          },
          dealerInvoiceVo: {
            invoiceUnitName: '',
            dealerTaxId: '',
            invoiceRate: '',
            invoiceUnitAddress: '',
            bankAccount: '',
            bankName: '',
            invoiceUnitTel: ''
          }
        },
        rules: {
          // 基础信息
          'dealerInfoVO.shortName': [
            { required: true, message: '请输入经销商名称', trigger: 'blur' }
          ],
          'dealerInfoVO.linkman': [
            { required: true, message: '请输入店面联系人', trigger: 'blur' }
          ],
          cityProvince: [
            { required: true, validator: cityProvince, message: '请选择店面省份-城市', trigger: 'change' }
          ],
          'dealerInfoVO.regionalManager': [
            { required: true, message: '请选择区域经理', trigger: 'change' }
          ],
          'dealerInfoVO.fullName': [
            { required: true, message: '请输入经销商全称', trigger: 'blur' },
            { max: 30, message: '经销商全称长度限30个字', trigger: 'blur' }
          ],
          'dealerInfoVO.linkmanPhone': [
            { required: true, validator: phone, trigger: 'blur' }
          ],
          'dealerInfoVO.address': [
            { required: true, message: '请输入店面地址', trigger: 'blur' }
          ],
          'dealerInfoVO.loanOrg': [
            { required: true, message: '请选择放款主体', trigger: 'change' }
          ],
          'dealerInfoVO.creditCode': [
            { required: true, message: '请输入统一社会信用代码', trigger: 'blur' }
          ],
          'dealerInfoVO.storePhone': [
            { required: true, message: '请输入店面联系电话', trigger: 'blur' }
          ],
          'dealerInfoVO.parentBody': [
            { required: true, message: '请选择销售上级', trigger: 'change' }
          ],
          'dealerInfoVO.mortgageProvince': [
            { required: true, message: '请选择放款主体对应抵押省份', trigger: 'change' }
          ],
          // 最后一栏的备注
          'dealerInfoVO.remark': [
            { max: 500, message: '备注长度限500个字', trigger: 'blur' }
          ],
          // 资质信息
          'dealerCreditVo.storeType': [
            { required: true, message: '请选择店面属性', trigger: 'change' }
          ],
          'dealerCreditVo.gpsSupplier': [
            { required: true, message: '请选择GPS厂商授权', trigger: 'change' }
          ],
          'dealerCreditVo.dealerClass': [
            { required: true, message: '请选择经销商等级', trigger: 'change' }
          ],
          'dealerCreditVo.newCarLoanType': [
            { required: true, message: '请选择新车是否先抵押后放款', trigger: 'change' }
          ],
          'dealerCreditVo.leaseType': [
            { required: true, message: '请选择租赁属性', trigger: 'change' }
          ],
          'dealerCreditVo.oldCarLoanType': [
            { required: true, message: '请选择二手车是否先抵押后放款', trigger: 'change' }
          ],
          // 保证金信息
          'dealerDepositVO.bizDeposit': [
            { required: true, message: '请输入业务保证金', trigger: 'blur' }
          ],
          'dealerDepositVO.baseDeposit': [
            { required: true, message: '请输入基础保证金', trigger: 'blur' }
          ],
          'dealerDepositVO.depositRate': [
            { required: true, message: '请选择担保比例', trigger: 'change' }
          ],
          // 开票信息
          'dealerInvoiceVo.invoiceUnitName': [
            { required: true, message: '请输入单位名称', trigger: 'blur' }
          ],
          'dealerInvoiceVo.dealerTaxId': [
            { required: true, message: '请输入纳税人识别号', trigger: 'blur' }
          ],
          'dealerInvoiceVo.invoiceRate': [
            { required: true, message: '请选择税率', trigger: 'change' }
          ],
          'dealerInvoiceVo.invoiceUnitAddress': [
            { required: true, message: '请输入单位通讯地址', trigger: 'blur' }
          ],
          'dealerInvoiceVo.bankAccount': [
            { required: true, message: '请输入银行账户', trigger: 'blur' }
          ],
          'dealerInvoiceVo.bankName': [
            { required: true, message: '请选择开户银行', trigger: 'change' }
          ],
          'dealerInvoiceVo.invoiceUnitTel': [
            { required: true, message: '请输入单位电话', trigger: 'blur' }
          ],
          // 收款账号信息
          'dealerAccountVO.unitName': [
            { required: true, message: '请输入单位名称', trigger: 'blur' }
          ],
          'dealerAccountVO.accountName': [
            { required: true, message: '请输入收款方账户名', trigger: 'blur' }
          ],
          'dealerAccountVO.phone': [
            { required: true, validator: phone, trigger: 'blur' }
          ],
          'dealerAccountVO.accountType': [
            { required: true, message: '请选择账户类型', trigger: 'change' }
          ],
          'dealerAccountVO.account': [
            { required: true, message: '请输入收款账号', trigger: 'blur' }
          ],
          accountCityProvince: [
            { required: true, validator: accountCityProvince, message: '请选择开户省份-城市', trigger: 'change' }
          ],
          'dealerAccountVO.bankName': [
            { required: true, message: '请选择收款方银行', trigger: 'change' }
          ],
          'dealerAccountVO.branchName': [
            { required: true, message: '请输入收款方支行', trigger: 'blur' }
          ],
          // 授权区域
          areaId: [
            { required: true, validator: areaId, trigger: 'change' }
          ]
        }
      }
    },
    methods: {
      getProvinceCityList () {
        if (!this.provinceCityList.length) {
          this.$store.dispatch('getAreaTree')
        }
      },
      getProvince () {
        if (!this.provinceList.length) {
          this.$store.dispatch('getProvince')
        }
      },
      // 获取销售上级
      getParentBody () {
        let data = {
          orgId: 0,
          subQueryFlag: true,
          subQueryLev: 3
        }
        userApi.fetchQueryOrgList(data)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.parentBodyData = JSON.parse(res.body)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取区域经理
      getRegionalManager () {
        dealerApi.fetchFindUsersByKind('INSIDE_SALES')
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.regionalManager = res.body
              console.log(this.regionalManager)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 省全选
      handleChooseProvince () {
        this.dealerInfoForm.dealerInfoVO.mortgageProvince.forEach((item, index) => {
          if (item === '') {
            if (this.dealerInfoForm.dealerInfoVO.mortgageProvince.length === this.provinceKeyList.length + 1) {
              this.dealerInfoForm.dealerInfoVO.mortgageProvince = []
            } else {
              this.dealerInfoForm.dealerInfoVO.mortgageProvince = this.provinceKeyList
            }
          }
        })
      },
      // 业务种类
      handleCheckedBizLinesChange (value) {
        console.log(this.dealerInfoForm.dealerCreditVo.bizLines)
      },
      // 新车是否先抵押后放款
      handleCheckedNewCarLoanTypeChange () {
      },
      // 获取回显基本信息
      getBaseInfo () {
        dealerApi.fetchBaseData(this.$route.params.id)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.cityProvince = []
              this.areaId = []
              this.dealerInfoForm = res.body
              this.cityProvince = this.dealerInfoForm.dealerInfoVO.province ? [this.dealerInfoForm.dealerInfoVO.province, this.dealerInfoForm.dealerInfoVO.city] : []
              this.accountCityProvince = this.dealerInfoForm.dealerAccountVO.province ? [this.dealerInfoForm.dealerAccountVO.province, this.dealerInfoForm.dealerAccountVO.city] : []
              if (this.dealerInfoForm.dealerCreditVo.bizLines.length) {
                this.dealerInfoForm.dealerCreditVo.bizLines = this.dealerInfoForm.dealerCreditVo.bizLines.map(item => {
                  return parseInt(item)
                })
              }
              if (this.dealerInfoForm.dealerCreditVo.leaseType.length) {
                this.dealerInfoForm.dealerCreditVo.leaseType = this.dealerInfoForm.dealerCreditVo.leaseType.map(item => {
                  return parseInt(item)
                })
              }
              this.dealerInfoForm.dealerCreditVo.gpsSupplier = parseInt(this.dealerInfoForm.dealerCreditVo.gpsSupplier)
              this.dealerInfoForm.dealerInvoiceVo.bankName = parseInt(this.dealerInfoForm.dealerInvoiceVo.bankName)
              this.dealerInfoForm.dealerAccountVO.bankName = parseInt(this.dealerInfoForm.dealerAccountVO.bankName)
              this.dealerInfoForm.dealerAreaVOList.forEach(item => {
                this.areaId.push(item.areaId)
              })
              this.$refs.menuTree.setCheckedKeys(this.areaId)
              // this.dealerInfoForm.dealerAccountVO.accountName = this.dealerInfoForm.dealerInfoVO.fullName
              this.dealerInfoForm.dealerAccountVO.accountType = 1
              if (this.dealerInfoForm.dealerInfoVO.parentBody.length) {
                this.dealerInfoForm.dealerInfoVO.parentBody = this.dealerInfoForm.dealerInfoVO.parentBody.map(item => {
                  return parseInt(item)
                })
              }
              this.dealerInfoForm.dealerInfoVO.regionalManager = this.dealerInfoForm.dealerInfoVO.regionalManager ? parseInt(this.dealerInfoForm.dealerInfoVO.regionalManager) : this.dealerInfoForm.dealerInfoVO.regionalManager
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      saveData () {
        this.submitForm('dealerInfoForm')
      },
      submitFormParent (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$emit('submitCheck', true)
          } else {
            this.$emit('submitCheck', false)
            console.log('error submit!!')
            return false
          }
        })
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.saveDataAgain()
          } else {
            this.$message.warning('请检查基本信息是否填写完整或是否存在格式错误')
            return false
          }
        })
      },
      // 保存表单
      saveDataAgain () {
        console.log('保存表单')
        this.dealerInfoForm.dealerAccountVO.city = this.accountCityProvince.length ? this.accountCityProvince[1] : ''
        this.dealerInfoForm.dealerAccountVO.province = this.accountCityProvince.length ? this.accountCityProvince[0] : ''
        this.dealerInfoForm.dealerInfoVO.province = this.cityProvince.length ? this.cityProvince[0] : ''
        this.dealerInfoForm.dealerInfoVO.city = this.cityProvince.length ? this.cityProvince[1] : ''
        this.handleNodeClick()
        this.dealerInfoForm.dealerAreaVOList = this.areaId
        // todo
        dealerApi.fetchSaveBaseData(this.dealerInfoForm)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.$router.push({path: res.body + ''})
              this.getBaseInfo()
              this.$emit('skipPage')
              this.$message.success('保存成功')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 树节点
      handleNodeClick (data) {
        let arr = this.$refs.menuTree.getCheckedNodes()
        let brr = []
        arr.forEach(item => {
          brr.push({'areaId': item.key})
        })
        this.areaId = brr
      },
      // 经销商全称移入
      handleFullNameBlur () {
        this.dealerInfoForm.dealerAccountVO.accountName = this.dealerInfoForm.dealerInfoVO.fullName
      }
    }
  }
</script>

<style lang="scss" scoped>
.dealer-base-info-wrapper{
  padding-left: 10px;
  /*background: #F2F2F2;  */
  .title{
    margin:0;
    font-size:15px;
    background: #E6E9EE;
    /*padding-left: 10px;*/
    margin-bottom: 10px;
  }
  .width {
    width: 80%;
  }
  .width1 {
    width: 50%;
    margin-top:10px;
  }
  .width2 {
    width: 30%;
  }
  .tree-height{
    max-height: 300px;
    overflow: auto;
    width: 33%;
  }
}
</style>
