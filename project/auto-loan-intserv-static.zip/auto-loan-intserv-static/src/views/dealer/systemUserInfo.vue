<template>
  <div class="system-user-info-wrapper">
    <p style="font-size:14px;">系统用户信息<span style="margin-left: 20px;color:blue;cursor: pointer" @click="handleAdd">+新增</span></p>
    <!-- 数据展示 -->
    <el-table border :data="systemUserInfoData" :max-height="maxHeight">
     <el-table-column align="center" label="序号">
       <template slot-scope="scope">
         <span>{{ scope.$index + 1 }}</span>
       </template>
     </el-table-column>
     <el-table-column align="center" label="操作账号" prop="staffCode"></el-table-column>
     <el-table-column align="center" label="账号姓名" prop="staffName"></el-table-column>
     <el-table-column align="center" label="经销商账号等级" prop="orgClass">
       <template slot-scope="scope">
         <span>{{ dealerStaffClassDict[scope.row.orgClass] }}</span>
       </template>
     </el-table-column>
     <el-table-column align="center" label="手机号" prop="staffPhone"></el-table-column>
     <el-table-column align="center" label="邮箱地址">
       <template slot-scope="scope">
         <span>{{ scope.row.staffEmail ? scope.row.staffEmail : '--'}}</span>
       </template>
     </el-table-column>
     <el-table-column align="center" label="操作">
       <template slot-scope="scope">
         <el-button type="primary" size="mini" @click="handleEdit(scope.row)">编辑</el-button>
         <!--<el-button type="danger" size="mini" @click="handleDelete(scope.row)">删除</el-button>-->
       </template>
     </el-table-column>
    </el-table>
    <!-- 分页 -->
    <div class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagable.pageNo" :page-sizes="pageSizes"
                     :page-size="pagable.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagable.totalRecord">
      </el-pagination>
    </div>
    <!-- 弹框 -->
    <el-dialog :title="isAddOrEdit ? '用户信息-新增' : '用户信息-编辑'"  :visible.sync="dialogVisible" width="60%" @close="handleDialogClose('addOrEditForm')">
      <el-form label-position="right" label-width="120px" :model="addOrEditForm" ref="addOrEditForm" :rules="rules" >
        <el-row>
          <el-col :span="12">
            <el-form-item label="手机号:" prop="staffPhone">
              <el-input size="small" class="width" v-model="addOrEditForm.staffPhone" :maxlength="11"></el-input>
            </el-form-item>
            <el-form-item label="账号等级:" prop="orgClass">
              <el-select v-model="addOrEditForm.orgClass" placeholder="请选择" size="small" class="width">
                <el-option v-for="item in dealerStaffClass" :label="item.dictName" :key="item.dictValue" :value="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="邮箱地址:" prop="staffEmail">
              <el-input size="small" class="width" v-model="addOrEditForm.staffEmail"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="账号姓名:" prop="staffName">
              <el-input size="small" class="width" v-model="addOrEditForm.staffName"></el-input>
            </el-form-item>
            <el-form-item label="用户状态:" prop="status">
              <el-select v-model="addOrEditForm.status"  :disabled="!isAddOrEdit" placeholder="请选择" size="small" class="width">
                <el-option v-for="item in isUseOrNoList" :label="item.dictName" :value="item.dictValue" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">关 闭</el-button>
        <el-button type="primary" @click="handleAddOrEditSave">保 存</el-button>
      </span>
    </el-dialog>

  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import dealerApi from '../../api/dealer'
  export default {
    computed: {
      ...mapGetters([
        'dealerStaffClass',
        'dealerStaffClassDict'
      ])
    },
    data () {
      let regPhone = /^1[0-9]{10}$/
      let regEmail = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/
      let phone = (rule, value, callback) => {
        if (value.trim() === '') {
          callback(new Error('请输入手机号'))
        } else {
          if (!regPhone.test(value)) {
            callback(new Error('请输入正确的手机号格式'))
          } else {
            callback()
          }
        }
      }
      let email = (rule, value, callback) => {
        if (value.trim() === '') {
          callback()
        } else {
          if (!regEmail.test(value)) {
            callback(new Error('请输入正确的邮箱地址'))
          } else {
            callback()
          }
        }
      }
      return {
        isUseOrNoList: [
          {'dictValue': 1, 'dictName': '有效'},
          {'dictValue': 2, 'dictName': '无效'}
        ],
        systemUserInfoData: [], // 系统数据
        // 新增或者编辑表单
        addOrEditForm: {
          id: null,
          staffPhone: '', // 手机号
          orgClass: '', // 账号等级
          staffEmail: '', // 邮箱地址
          staffName: '', // 账号姓名
          status: '' // 用户状态
        },
        // 是新增还是编辑
        isAddOrEdit: false,
        dialogVisible: false,
        pagable: {
          pageNo: 1,
          pageSize: 100,
          totalRecord: null // 总记录数
        },
        maxHeight: 750,
        pageSizes: [50, 100, 200, 500],
        // 表单验证规则
        rules: {
          staffPhone: [
            { required: true, validator: phone, trigger: 'blur' }
          ],
          orgClass: [
            { required: true, message: '请选择账号等级', trigger: 'change' }
          ],
          staffName: [
            { required: true, message: '请输入账号姓名', trigger: 'blur' }
          ],
          status: [
            { required: true, message: '请选择用户状态', trigger: 'change' }
          ],
          staffEmail: [
            { validator: email, trigger: 'blur' }
          ]
        }
      }
    },
    mounted () {
      if (this.$route.params.id !== 'null') {
        this.getSystemUserInfo() // 获取系统用户信息
      }
    },
    methods: {
      // 点击编辑按钮
      handleEdit (val) {
        this.addOrEditForm = Object.assign({}, val)
        this.addOrEditForm.orgClass = parseInt(this.addOrEditForm.orgClass)
        // this.addOrEditForm.status = parseInt(this.addOrEditForm.status)
        this.isAddOrEdit = false
        this.dialogVisible = true
      },
      // 点击新增按钮
      handleAdd () {
        this.isAddOrEdit = true
        this.dialogVisible = true
      },
      // 编辑或者新建保存
      handleAddOrEditSave () {
        this.submitForm('addOrEditForm')
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.isAddOrEdit) {
              // 请求新新增接口
              this.getAddForm()
            } else {
              // 请求编辑接口
              this.getEditForm()
            }
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      getAddForm () {
        let data = {
          dealerId: this.$route.params.id,
          staffPhone: this.addOrEditForm.staffPhone, // 手机号
          orgClass: this.addOrEditForm.orgClass, // 账号等级
          staffEmail: this.addOrEditForm.staffEmail, // 邮箱地址
          staffName: this.addOrEditForm.staffName, // 账号姓名
          status: this.addOrEditForm.status // 用户状态
        }
        dealerApi.fetchSystemUserInfoAdd(data)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.dialogVisible = false
              this.$message.success('新增成功')
              this.getSystemUserInfo()
            } else {
              this.dialogVisible = false
              this.$message.warning(res.respMsg)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      getEditForm () {
        let data = {
          dealerId: this.$route.params.id,
          id: this.addOrEditForm.id,
          staffPhone: this.addOrEditForm.staffPhone, // 手机号
          orgClass: this.addOrEditForm.orgClass, // 账号等级
          staffEmail: this.addOrEditForm.staffEmail, // 邮箱地址
          staffName: this.addOrEditForm.staffName, // 账号姓名
          status: this.addOrEditForm.status // 用户状态
        }
        dealerApi.fetchSystemUserInfoEdit(data)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.dialogVisible = false
              this.$message.success('编辑成功')
              this.getSystemUserInfo()
            } else {
              this.dialogVisible = false
              this.$message.warning(res.respMsg)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取系统用户信息
      getSystemUserInfo () {
        let data = {
          dealerId: this.$route.params.id,
          pageNum: this.pagable.pageNo,
          pageSize: this.pagable.pageSize
        }
        dealerApi.fetchSystemUserInfo(data)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.systemUserInfoData = res.body.list
              /* this.systemUserInfoData.forEach(item => {
                item.status = 1
              }) */
              this.pagable.totalRecord = res.body.total
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 弹框关闭
      handleDialogClose (formName) {
        this.$refs[formName].resetFields()
        this.addOrEditForm = {
          id: null,
          staffPhone: '', // 手机号
          orgClass: '', // 账号等级
          staffEmail: '', // 邮箱地址
          staffName: '', // 账号姓名
          status: '' // 用户状态
        }
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagable.pageSize = val
        this.getSystemUserInfo()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagable.pageNo = val
        this.getSystemUserInfo()
      },
      // 删除按钮
      handleDelete (val) {
        this.$confirm('是否确定删除该用户?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.handleDeleteAgain(val)
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      },
      handleDeleteAgain (val) {
        dealerApi.fetchDeleteDealerStaff(val.id)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.$message.success('删除成功')
              this.getSystemUserInfo()
            }
          })
          .catch(error => {
            console.log(error)
          })
      }
    }
  }
</script>

<style lang="scss" scoped>
.system-user-info-wrapper {
  .width {
    width: 180px;
  }
}
</style>