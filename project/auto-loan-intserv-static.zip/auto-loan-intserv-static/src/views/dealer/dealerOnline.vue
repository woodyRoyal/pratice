<template>
  <div class="dealer-online-wrapper">
    <!--<el-breadcrumb>
      <el-breadcrumb-item>经销商管理</el-breadcrumb-item>
      <el-breadcrumb-item>经销商上线</el-breadcrumb-item>
    </el-breadcrumb>
    <hr/>-->
    <!-- 查询表单 -->
    <el-form :inline="true" :form="queryForm">
      <el-form-item label="经销商简称:">
        <el-input size="small" v-model="queryForm.shortName"></el-input>
      </el-form-item>
      <el-form-item label="经销商等级:">
        <el-select v-model="queryForm.dealerClass" placeholder="请选择" size="small">
          <el-option v-for="item in dealerClass" :label="item.dictName" :value="item.dictValue" :key="item.dictValue"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
         <el-button type="primary" size="mini" @click="handleSearch">查询</el-button>
         <el-button type="primary" size="mini" @click="handleReset">重置</el-button>
         <el-button type="primary" size="mini" @click="handleOnlineSubmit">上线申请</el-button>
      </el-form-item>
    </el-form>
    <!-- tab -->
    <el-tabs v-model="approveStatus">
      <el-tab-pane label="待提交" name="0">
        <el-table border :data="waitSubmitData" :max-height="maxHeight">
          <el-table-column align="center" label="序号">
            <template slot-scope="scope">
              <span>{{ scope.$index + 1 }}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="经销商代码" prop="id"></el-table-column>
          <el-table-column align="center" label="经销商全称" prop="fullName"></el-table-column>
          <el-table-column align="center" label="店面属性">
            <template slot-scope="scope">
              <span>{{ storeTypeDict[scope.row.storeType] }}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="保证金">
            <template slot-scope="scope">
              <span>{{ scope.row.bizDeposit + '.00'}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="经销商等级">
            <template slot-scope="scope">
              <span>{{ dealerClassDict[scope.row.dealerClass] }}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="审核备注" prop="approveRemake"></el-table-column>
          <el-table-column align="center" label="操作" width="150">
            <template slot-scope="scope">
              <el-button type="primary" size="mini" @click="handleEdit(scope.row)">编辑</el-button>
              <el-button type="danger" size="mini" disabled>删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      <!--<el-tab-pane label="审核中" name="1">审核中</el-tab-pane>-->

      <!-- 分页对象 -->
      <div class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagable.pageNo" :page-sizes="pageSizes"
                     :page-size="pagable.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagable.totalRecord">
      </el-pagination>
    </div>
    </el-tabs>
  </div>
</template>

<script>
  import dealerApi from '../../api/dealer'
  import { mapGetters } from 'vuex'
  export default {
    computed: {
      ...mapGetters([
        'dealerClass',
        'dealerClassDict',
        'storeTypeDict'
      ])
    },
    data () {
      return {
        queryForm: {
          shortName: '',
          dealerClass: null
        },
        maxHeight: 100,
        approveStatus: '0',
        waitSubmitData: [], // 待提交数据
        pagable: {
          pageNo: 1,
          pageSize: 10,
          totalRecord: null // 总记录数
        },
        pageSizes: [10, 20, 30, 40]
      }
    },
    mounted () {
      this.getTableData()
      // 调整高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    destroyed () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // 表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let h = document.documentElement.clientHeight
          this.maxHeight = h - 290
        })
      },
      // 查询接口
      handleSearch () {
        this.getTableData() // 获取数据
      },
      // 重置接口
      handleReset () {
        this.queryForm = {
          shortName: '',
          dealerClass: null
        }
        this.pagable = {
          pageNo: 1,
          pageSize: 10,
          totalRecord: null // 总记录数
        }
        this.getTableData()
      },
      // 编辑接口
      handleEdit (val) {
        window.open('#/dealer-info/' + val.id)
      },
      getTableData () {
        let data = {
          shortName: this.queryForm.shortName,
          dealerClass: this.queryForm.dealerClass === '' ? null : this.queryForm.dealerClass,
          approveStatus: parseInt(this.approveStatus),
          pageNum: this.pagable.pageNo,
          pageSize: this.pagable.pageSize
        }
        dealerApi.fetchDealerData(data)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.waitSubmitData = res.body.list
              this.pagable.totalRecord = res.body.total
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 点击上线申请
      handleOnlineSubmit () {
        window.open('#/dealer-info/null')
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagable.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagable.pageNo = val
        this.getTableData()
      }
    }
  }
</script>

<style lang="scss" scoped>
  .dealer-online-wrapper{

  }
</style>