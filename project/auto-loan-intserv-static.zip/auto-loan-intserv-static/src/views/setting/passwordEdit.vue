<template>
  <div class="password-edit-wrapper">
    <div>密码修改</div>
    <hr/>
    <el-form label-width="150px" :model="editForm" ref="editForm" :rules="rules">
      <el-form-item label="当前密码:" prop="oldPassword">
        <el-input type="password" size="small" class="width" v-model="editForm.oldPassword"></el-input>
      </el-form-item>
      <el-form-item label="新密码:" prop="newPassword1">
        <el-input type="password" size="small" class="width" v-model="editForm.newPassword1"></el-input>
      </el-form-item>
      <el-form-item label="确认新密码:" prop="newPassword2">
        <el-input type="password" size="small" class="width" v-model="editForm.newPassword2"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" size="small" @click="handleConfirm">确定</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import userApi from '../../api/user'
  export default {
    computed: {
      ...mapGetters([
        'userId'
      ])
    },
    data () {
      let reg = /^([0-9])|((?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]){6,12}$/
      let password = (rule, value, callback) => {
        if (value.trim() === '') {
          callback(new Error('密码不能为空'))
        } else {
          if (!reg.test(value)) {
            callback(new Error('密码必须为6-12位的纯数字或者数字和字母的组合'))
          } else {
            callback()
          }
        }
      }
      return {
        editForm: {
          oldPassword: '',
          newPassword1: '',
          newPassword2: ''
        },
        rules: {
          oldPassword: [
            { required: true, validator: password, trigger: 'blur' }
          ],
          newPassword1: [
            { required: true, validator: password, trigger: 'blur' }
          ],
          newPassword2: [
            { required: true, validator: password, trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      // 确认修改
      handleConfirm () {
        this.submitForm('editForm')
      },
      // 表单校验
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.handleConfirmAgain()
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      // 再次确认
      handleConfirmAgain () {
        let data = {
          id: this.userId,
          oldPassword: this.editForm.oldPassword,
          newPassword1: this.editForm.newPassword1,
          newPassword2: this.editForm.newPassword2
        }
        userApi.fetchUpdateUserPassword(data)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.$message.success('密码修改成功')
              this.resetForm('editForm')
            } else {
              this.$message.warning(res.respMsg)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 重置表单
      resetForm (formName) {
        this.$refs[formName].resetFields()
        this.editForm = {
          oldPassword: '',
          newPassword1: '',
          newPassword2: ''
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .password-edit-wrapper {
    .el-form-item {
      margin-bottom: 16px;
    }
    .width {
      width: 50%;
    }
  }
</style>