<template>
  <div class="menu-wrapper">
    <template v-for="item in routes">
      <template v-if="!item.hidden&&item.children">  
        <!--无子菜单 有侧边框 -->
        <!-- 后端给的路由表 children下面还有children Array(0) 所以由!item.children[0].children变为!item.children[0].children,length -->
        <!--item.noDropdown 并且判断是否是true-->
        <router-link v-if="item.noDropdown && item.children.length===1 && !item.children[0].children.length"
                    :to="item.path+'/'+item.children[0].path" :key="item.children[0].name">
          <el-menu-item :index="item.path+'/'+item.children[0].path" :class="{'submenu-title-noDropdown':!isNest}">
            <i v-if="item.children[0].icon" :class="item.children[0].icon" aria-hidden="true"></i>
            <span>{{item.children[0].name}}</span>
          </el-menu-item>
        </router-link>

        <el-submenu v-else :index="item.name||item.path" :key="item.name">
          <template slot="title">
            <i v-if="item.icon" :class="item.icon" aria-hidden="true"></i>
            <span>{{(item.name)}}</span>
          </template>

          <template v-for="child in item.children">
            <template v-if="!child.hidden">
              <!-- 递归调用组件 多级嵌套菜单-->
              <sidebar-item :is-nest="true" class="nest-menu" v-if="child.children && child.children.length>0"
                            :routes="[child]" :key="child.path"></sidebar-item>

              <router-link v-else :to="item.path+'/'+child.path" :key="child.name">
                <el-menu-item :index="item.path+'/'+child.path">
                  <i v-if="child.icon" :class="child.icon" aria-hidden="true"></i>
                  <span>{{child.name}}</span>
                </el-menu-item>
              </router-link>
            </template>
          </template>
        </el-submenu>
      </template>
    </template>
  </div>
</template>

<script>
  export default {
    name: 'SidebarItem',
    props: {
      routes: {
        type: Array
      },
      isNest: {
        type: Boolean,
        default: false
      }
    },
    methods: {}
  }
</script>

