/**
* Created by zuo on 2017/9/14.
*/

<template>
  <div class="home-content">欢迎使用 {{currentSysName}} v{{version}}</div>
</template>

<script type="text/ecmascript-6">
  import packageConfig from 'package'
  import { mapGetters } from 'vuex'

  export default {
    components: {},
    computed: {
      ...mapGetters([
        'username',
        'token'
      ])
    },
    data () {
      return {
        currentSysName: packageConfig.sysname, // 当前系统名称
        version: packageConfig.version // 当前系统名称
      }
    },
    mounted () {
      console.log('loading..........')
      // this.refreshLoad()
    },
    methods: {
      refreshLoad () {
        let user = {
          username: this.username,
          token: this.token
        }
        this.$store.dispatch('RefreshLoad', user).then(res => {
          console.log('refresh loaded sso...' + res)
        }).catch(err => {
          console.log(err)
        })
      }
    }
  }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  .home-content {
    margin: 0 auto;
    color: #99A9BF;
    width: 340px;
    position: relative;
    top: 30%;
    font-size: 18px;
  }
</style>
