<template>
  <div class="navbar-wrapper">
    <div class="logo" :class="!sidebar.opened ? 'logo-collapse-width' : 'logo-width'">
      <img class="logo-img-title" src="../../assets/img/slogan2.png" v-if="sidebar.opened"
           @click="gotoUcenter"/>
      <img class="logo-img" src="../../assets/img/logo.png" v-else
           @click="gotoUcenter"/>
    </div>
    <div class="sys-list">
      <ul ref="systemListUl">
        <li v-for="(item, index) in systemList" class="system-list-li" v-if="item.sysCode !== 'ucenter'"
            :class="{'is-active': item.sysCode === currentSysName}" @click="handleChooseSys(item)">
          {{item.sysName}}
        </li>
      </ul>
    </div>
    <div class="arrow">
      <div class="arrow-left arrow-left-active" @click="handleSwitchSystem('left')" v-if="isShowLeft"><i class="el-icon-arrow-left"></i></div>
      <div class="arrow-left arrow-left-inactive" v-else><i class="el-icon-arrow-left"></i></div>
      <div class="arrow-right arrow-right-active" @click="handleSwitchSystem('right')" v-if="isShowRight"><i class="el-icon-arrow-right"></i></div>
      <div class="arrow-right arrow-right-inactive" v-else><i class="el-icon-arrow-right"></i></div>
    </div>
    <div class="user-info">
      <a title="退出" @click="logout">[退出]</a>
      <span>{{displayName}}</span>
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import packageConfig from 'package'
  // import { UCENTER_LOGIN_URL } from 'api/login'

  export default {
    data () {
      return {
        currentSysName: packageConfig.name, // 当前系统名称
        totalSysMenuWidth: 0, // 导航菜单总宽度
        boxClientWidth: 0, // 导航菜单最大宽度
        isShowLeft: false, // 是否显示左箭头
        isShowRight: false, // 是否显示右箭头
        moveValue: 100,
        dialogVisible: false,
        sortableObj: null,
        sysIdList: [] // 排序后的系统code
      }
    },
    computed: {
      ...mapGetters([
        'sidebar',
        'displayName',
        'systemList',
        'username',
        'token',
        'source'
      ])
    },
    mounted () {
      this.$nextTick(() => {
        this.initSystemMenu()
      })
      window.addEventListener('resize', this.initSystemMenu)
    },
    deactivated () {
      window.removeEventListener('resize', this.initSystemMenu)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.initSystemMenu)
    },
    methods: {
      toggleSideBar () {
        this.$store.dispatch('ToggleSideBar')
      },
      logout () {
        this.$store.dispatch('FilterLogout').then(() => {
          window.open('about:blank', '_self').close()
        })
        /* this.$store.dispatch('LogoutUcenter').then((val) => {
          if (val) {
            console.log('logout error!!!' + val)
            this.$message.warning(val)
          } else {
            if (this.source === 'oa') {
              window.location.href = UCENTER_LOGIN_URL
            } else {
              this.$router.push({path: '/login'})
            }
            // 返回到登录页
          }
        }) */
      },
      // 处理跳转系统
      handleChooseSys (sys) {
        // 当前系统不跳转 非当前才跳转
        if (sys.sysCode !== this.currentSysName) {
          window.open(sys.defaultUrl + '?username=' + this.username + '&token=' + this.token) // 打开新窗口
        }
      },
      // 初始 计算是否需要左右切换箭头
      initSystemMenu () {
        this.boxClientWidth = this.$refs.systemListUl.clientWidth // 外面的容器
        let list = document.getElementsByClassName('system-list-li') // 所有列表元素
        this.totalSysMenuWidth = 0
        for (let i = 0; i < list.length; i++) {
          this.totalSysMenuWidth += list[i].offsetWidth // 所有列表元素的总宽度
        }
        let listBox = this.$refs.systemListUl // ul列表 主要是移动它的left值
        let listLeft = listBox.style.left ? listBox.style.left : '0px' // 当前位置
        let leftNum = parseInt(listLeft.substring(0, listLeft.indexOf('px'))) // 当前位置
        // 显示箭头
        if (this.totalSysMenuWidth > this.boxClientWidth) {
          if (leftNum === 0) {
            this.isShowLeft = false
            this.isShowRight = true
          } else {
            this.isShowLeft = true
            this.isShowRight = true
          }
        } else {
          this.isShowLeft = false
          this.isShowRight = false
          listBox.style.left = 0
        }
      },
      // 处理左右滑动导航菜单
      handleSwitchSystem (direction) {
        let listBox = this.$refs.systemListUl // ul列表 主要是移动它的left值
        let listLeft = listBox.style.left ? listBox.style.left : '0px' // 当前位置
        let leftNum = parseInt(listLeft.substring(0, listLeft.indexOf('px'))) // 当前位置
        let _offset = this.totalSysMenuWidth - this.boxClientWidth // 右边的偏移量 总共可以移动的距离

        if (direction === 'left') { // 向左
          if (leftNum >= -this.moveValue) { // 左边界 左不可点 右可点
            listBox.style.left = 0
            this.isShowLeft = false
            this.isShowRight = true
          } else { // 左可点 右可点
            listBox.style.left = (leftNum + this.moveValue) + 'px'
            this.isShowLeft = true
            this.isShowRight = true
          }
        } else { // 向右
          if (Math.abs(leftNum) - _offset >= 0) { // 右边界 左可点 右不可点
            listBox.style.left = -Math.abs(leftNum) + 'px'
            this.isShowLeft = true
            this.isShowRight = false
          } else {
            listBox.style.left = (leftNum - this.moveValue) + 'px'
            listBox = this.$refs.systemListUl // ul列表 主要是移动它的left值
            listLeft = listBox.style.left ? listBox.style.left : '0px' // 当前位置
            leftNum = parseInt(listLeft.substring(0, listLeft.indexOf('px'))) // 当前位置
            _offset = this.totalSysMenuWidth - this.boxClientWidth // 右边的偏移量 总共可以移动的距离
            if (Math.abs(leftNum) - _offset >= 0) { // 右边界
              this.isShowLeft = true
              this.isShowRight = false
            } else {
              if (leftNum === 0) {
                this.isShowLeft = false
                this.isShowRight = true
              } else {
                this.isShowLeft = true
                this.isShowRight = true
              }
            }
          }
        }
      },
      gotoUcenter () {
        window.location.href = process.env.UCENTER_API
      }
    }
  }
</script>
<style lang="scss" scoped>
  .navbar-wrapper {
    background-color: #324157;
    display: flex;
    /*左侧logo*/
    .logo {
      cursor: pointer;
      height: 40px;
      .logo-img-title {
        margin: 8px 24px;
      }
      .logo-img {
        margin: 8px 12px;
      }
    }
    /*长*/
    .logo-width {
      width: 180px;
    }
    /*短*/
    .logo-collapse-width {
      width: 50px
    }
    /*中间各个系统*/
    .sys-list {
      flex: 1;
      height: 40px;
      overflow: hidden; // 超出隐藏
      ul {
        position: relative; // 可以移动
        white-space: nowrap; // 不换行
        li {
          display: inline-block;
          color: #bfcbd9;
          cursor: pointer;
          font-size: 14px;
          padding: 0 10px;
          line-height: 40px;
          height: 40px;
          border-bottom: none;
          &:hover {
            color: #fff;
            border-bottom: 4px solid #2fc0ff;
          }
        }
        .is-active {
          color: #20a0ff;
          border-bottom: 4px solid #2fc0ff;
        }
      }
    }
    /* 箭头 */
    .arrow {
      display: flex;
      width: 80px;
      height: 40px;
      .arrow-left, .arrow-right {
        width: 40px;
        line-height: 40px;
        font-size: 14px;
        text-align: center;
        &:hover {
          background-color: #475669;
        }
      }

      .arrow-left-active, .arrow-right-active {
        cursor: pointer;
        color: #fff;
      }
      .arrow-left-inactive, .arrow-right-inactive {
        color: #333;
        &:hover {
          background-color: transparent;
        }
      }
    }
    /*设置*/
    .settings {
      width: 40px;
      height: 40px;
      line-height: 40px;
      color: #bfcbd9;
      cursor: pointer;
      text-align: center;
      &:hover {
        background-color: #475669;
        color: #fff;
      }
    }
    /*右侧登录用户信息*/
    .user-info {
      /*width: 160px;*/
      height: 40px;
      font-size: 12px;
      color: #bfcbd9;
      line-height: 40px;
      padding-right: 10px;
      display: flex;
      flex-direction: row-reverse;
      span {
        padding: 0 10px;
      }
      a {
        color: #95A5B4;
        &:hover {
          color: #20a0ff;
        }
      }
    }
    /*自定义dialog*/
    .defined-control-dialog-wrapper {
      position: fixed;
      z-index: 9999;
      left: 0;
      right: 0;
      top: 0;
      bottom: 0;
      margin: auto;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, .5);
      .defined-control-dialog {
        width: 80%;
        height: 240px;
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        margin: auto;
        border-radius: 2px;
        box-shadow: 0 1px 3px rgba(0,0,0,.3);
        border: 8px solid #666;
        border-color: rgba(0,0,0,.25);
        z-index: 99999;
        background-color: #fff;
        .dialog-header {
          padding: 0 20px;
        }
        .sys-list-wrapper {
          padding: 0 20px;
          height: 120px;
          ul {
            background-color: #324157;
            li {
              display: inline-block;
              color: #bfcbd9;
              cursor: move;
              font-size: 14px;
              padding: 0 10px;
              line-height: 40px;
              height: 40px;
              border-bottom: none;
              /*&:hover {*/
              /*color: #fff;*/
              /*border-bottom: 4px solid #2fc0ff;*/
              /*}*/
            }
            /*拖动的样式*/
            .sortable-ghost {
              background-color: #20a0ff;
            }
          }
        }
        .dialog-footer {
          padding: 0 20px;
          float: right;
        }
      }
    }
  }
</style>
