<template>
  <div class="station-wrapper">
    <el-form :inline="true">
      <el-form-item label="岗位名称:">
        <el-select size="small" value="">
          <el-option value=""></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="状态:">
        <el-select size="small" value="">
          <el-option v-for="item in isWorkList" :value="item.dictValue" :label="item.dictName" :key="item.dictValue"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="primary" @click="handleSearch">查询</el-button>
        <el-button size="mini" type="primary" @click="handleReset">重置</el-button>
      </el-form-item>
    </el-form>
    <!-- 查询数据 -->
    <span class="font" @click="handleAdd">+新增岗位</span>
    <el-table style="margin-top: 5px;" border :data="tableData">
      <el-table-column align="center" label="序号"></el-table-column>
      <el-table-column align="center" label="岗位代码"></el-table-column>
      <el-table-column align="center" label="岗位名称"></el-table-column>
      <el-table-column align="center" label="创建时间"></el-table-column>
      <el-table-column align="center" label="状态"></el-table-column>
      <el-table-column align="center" label="操作" min-width="160">
        <template slot-scope="scope">
          <el-button size="mini" type="primary" @click="handleEdit">编辑岗位功能</el-button>
          <el-button size="mini" type="primary">查看岗位用户</el-button>
          <el-button size="mini" type="danger" @click="deleteStation(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页对象 -->
    <div class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagable.pageNo" :page-sizes="pageSizes"
                     :page-size="pagable.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagable.totalRecord">
      </el-pagination>
    </div>
    <!-- 新增岗位dialog -->
    <el-dialog :title= "isAddOrEdit ? '岗位信息-新增' : '岗位信息-编辑'" :visible.sync="dialogVisible" width="50%" @close="handleDialogClose('addOrEditForm')">
      <el-form :inline="true" :model="addOrEditForm" :rules="rules" ref="addOrEditForm">
        <el-form-item label="岗位编号:">
          <el-input size="small"></el-input>
        </el-form-item>
        <el-form-item label="岗位名称:">
          <el-input size="small"></el-input>
        </el-form-item>
        <div>
          <el-form-item>
            <el-button size="small" type="primary" @click="expandOrShrink">{{isExpandOrNot ? '闭合' : '展开'}}</el-button>
            <el-button size="small" type="primary" @click="chooseAllTree">选定全部</el-button>
            <el-button size="small" type="primary" @click="cancelAllTree">取消选定</el-button>
          </el-form-item>
        </div>
        <el-form-item>
          <el-tree :default-expand-all="isExpandOrNot" node-key="key" ref="tree" :data="treeData" show-checkbox :props="defaultProps" class="tree-height"></el-tree>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="handleAddOrEditForm">确 定</el-button>
  </span>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    data () {
      return {
        treeData: [{
          label: '一级 1',
          key: 1,
          children: [{
            label: '二级 1-1',
            key: 2,
            children: [{
              label: '三级 1-1-1',
              key: 3
            }]
          }]
        }], // 树数据
        defaultProps: {
          children: 'children',
          label: 'label'
        },
        isExpandOrNot: false, // 展开或者闭合
        isWorkList: [
          {dictValue: 1, dictName: '有效'},
          {dictValue: 0, dictName: '无效'}
        ],
        isAddOrEdit: false,
        addOrEditForm: {}, // 新增或编辑表单
        rules: {}, // 表单验证规则
        dialogVisible: false, // 新增岗位或编辑岗位dialog
        tableData: [{}],
        pagable: {
          pageNo: 1,
          pageSize: 100,
          totalRecord: null // 总记录数
        },
        pageSizes: [50, 100, 200, 500]
      }
    },
    methods: {
      // 获取表格数据
      getTableData () {},
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagable.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagable.pageNo = val
        this.getTableData()
      },
      // 查询表格数据
      handleSearch () {
        this.getTableData()
      },
      // 搜索条件重置
      handleReset () {},
      // 删除岗位
      deleteStation (val) {
        let flag = true
        if (flag) {
          this.$confirm('当前该岗位有关联用户,不可直接删除,请先将用户移除该岗位?', '警告', {
            confirmButtonText: '查看岗位用户',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            // todo 跳转岗位用户
          }).catch(() => {
          })
        } else {
          this.$confirm('请确认是否删除该岗位?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.deleteStationAgain(val)
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除'
            })
          })
        }
      },
      // 删除岗位
      deleteStationAgain (val) {
        // todo 请求删除岗位接口
      },
      // 新增岗位
      handleAdd () {
        this.dialogVisible = true
        this.isAddOrEdit = true
      },
      // 编辑岗位
      handleEdit () {
        this.dialogVisible = true
        this.isAddOrEdit = false
      },
      // 树形展开或者闭合
      expandOrShrink () {
        this.isExpandOrNot = !this.isExpandOrNot
        this.$refs.tree.store._getAllNodes().forEach((item, index) => {
          this.$refs.tree.store._getAllNodes()[index].expanded = this.isExpandOrNot
        })
      },
      // 树选中全部
      chooseAllTree () {
      },
      // 取消选择
      cancelAllTree () {
        this.$refs.tree.setCheckedKeys([])
      },
      // 弹框关闭
      handleDialogClose (formName) {
        this.$refs[formName].resetFields()
      },
      // 弹框确认
      handleAddOrEditForm () {
        this.submitForm('addOrEditForm')
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            window.alert('submit!')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .station-wrapper {
    .font{
      color:blue;
      cursor: pointer;
      font-size:14px;
    }
    .tree-height{
      max-height: 300px;
      overflow: auto;
      width: 300px;
    }
    .el-form-item {
      margin-bottom: 10px;
    }
  }
</style>