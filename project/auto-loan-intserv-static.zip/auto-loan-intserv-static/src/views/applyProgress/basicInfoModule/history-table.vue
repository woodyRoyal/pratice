<template>
  <div class="pageWrap history-tab">
    <div class="formModuleTitle"><span>审批历史记录</span></div>
       <el-table :data="tableData" border style="width: 100%">
          <el-table-column label="序号" align="center" width="50" prop="listNum"></el-table-column>
          <el-table-column label="审批节点" align="center" prop="nodeDesc">
            <template slot-scope="scope">
                {{scope.row.nodeDesc || '/'}}
            </template>
          </el-table-column>
          <el-table-column label="审批结果" align="center" prop="resultsDesc">
            <template slot-scope="scope">
                {{scope.row.resultsDesc || '/'}}
            </template>
          </el-table-column>
          <el-table-column label="审批编码" align="center" prop="codeDesc">
            <template slot-scope="scope">
                {{scope.row.codeDesc || '/'}}
            </template>
          </el-table-column>
          <el-table-column label="经销商提醒" align="center" prop="dealerRemindContent">
            <template slot-scope="scope">
                {{scope.row.dealerRemindContent || '/'}}
            </template>
          </el-table-column>
          <el-table-column label="SP操作提醒" align="center" prop="remarks">
            <template slot-scope="scope">
                {{scope.row.remarks || '/'}}
            </template>
          </el-table-column>
          <el-table-column label="审批人员" align="center" prop="approveUser">
            <template slot-scope="scope">
                {{scope.row.approveRole || '/'}}
            </template>
          </el-table-column>
          <el-table-column label="审批时间" align="center" prop="created">
            <template slot-scope="scope">
                {{scope.row.created || '/'}}
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          layout="sizes,total, prev, pager, next,jumper"
          @current-change="handleCurrentChange"
          :page-size="pagination.pageSize"
          :page-sizes="pagination.pageSizesArr"
          @size-change="handleSizeChange"
          :current-page="pagination.currentPage"
          :total="pagination.total">
        </el-pagination>
  </div>
</template>
<script>
import { getApproveList } from '../../../api/applyProgress.js'
export default {
  data () {
    return {
      itemId: null,
      // 控件间距
      labelWidth: '140px',
      controlSpacing: 20,
      // 控件占据
      controlPieces: 8,
      tableData: [],
      pagination: {
        pageSize: 10,
        pageSizesArr: [10, 20, 30, 40],
        currentPage: 1,
        total: 0
      },
      formData: {},
      formRules: {}
    }
  },
  created () {
    this.itemId = this.$route.params.itemId
    this.getInfo()
  },
  methods: {
    getInfo (val) {
      let d1 = { applyId: this.itemId }
      let data = val ? Object.assign(d1, val) : d1
      getApproveList(data).then(res => {
        if (res.data.respCode === '1000') {
          let data = res.data.body.list
          if (data.length) {
            this.pagination.total = res.data.body.total
            data.forEach((item, index) => {
              item.listNum = (this.pagination.total - (this.pagination.pageSize * (this.pagination.currentPage - 1))) - index
            })
            this.tableData = data
          }
        }
      }).catch(error => { console.log(error) })
    },
    handleCurrentChange (val) {
      this.pagination.currentPage = val
      this.getInfo({
        pageNum: this.pagination.currentPage,
        pageSize: this.pagination.pageSize
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.getInfo({
        pageNum: this.pagination.currentPage,
        pageSize: this.pagination.pageSize
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.el-pagination {
  float: right;
  margin-top: 5px;
}
.pageWrap {
  overflow: hidden;
}
</style>
