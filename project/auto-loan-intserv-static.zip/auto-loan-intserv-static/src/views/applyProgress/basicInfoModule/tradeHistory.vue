<template>
  <div class="trade-history">
    <div class="tableTitle clearfix">
      <div class="table-title-word">
        交易记录
      </div>
      <div class="trade-history-form">
        <el-form size="small"
                 :inline="true">
          <el-form-item label="扣款结果">
            <el-select v-model="queryData.result">
              <el-option label="成功"
                         :value="2"></el-option>
              <el-option label="失败"
                         :value="3"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="日期">
            <el-date-picker v-model="dateRange"
                            type="daterange"
                            range-separator="-"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期"
                            value-format="yyyy-MM-dd">
            </el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary"
                       size="mini"
                       @click="getTradeHistory">
              查询
            </el-button>
            <el-button type="primary"
                       size="mini"
                       @click="resetQuery">
              重置
            </el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <el-table :data="tableData"
              border>
      <el-table-column label="第几期">
        <template slot-scope="scope">
          {{ scope.row.periods || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="时间">
        <template slot-scope="scope">
          {{ scope.row.repayDate || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="扣款金额">
        <template slot-scope="scope">
          {{ fmoney(scope.row.amount || '/') }}
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          {{ relateTypeDict[scope.row.relateType] || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="操作结果">
        <template slot-scope="scope">
          {{ +scope.row.result === 2 ? '成功' : '失败' || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="扣款失败原因">
        <template slot-scope="scope">
          {{ scope.row.errorMsg || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="扣款户名">
        <template slot-scope="scope">
          {{ scope.row.bankAccountName || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="扣款账号">
        <template slot-scope="scope">
          {{ scope.row.bankAccount || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="扣款银行">
        <template slot-scope="scope">
          {{ bankCodeDict[scope.row.bankCode] || '/' }}
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination-container">
      <el-pagination :current-page="pageable.pageNo"
                     :page-sizes="pageable.pageSizes"
                     :page-size="pageable.pageSize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="pageable.totalRecord"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import { tradeHistory } from '../../../api/applyProgress.js'
import { fmoney } from '../../../utils/constant'
import { mapGetters } from 'vuex'
export default {
  data () {
    return {
      fmoney,
      tableData: [],
      pageable: {
        pageNo: 1,
        pageSize: 5,
        pageSizes: [5, 10, 15, 20],
        totalRecord: 0,
      },
      queryData: {
        result: null,
      },
      dateRange: [],
      relateTypeDict: {
        'withhold': '系统代扣',
        'manual': '手动代扣',
        'chargeBacks': '手动代扣',
        'book': '对公还款',
        'fund': '资方代扣',
        'auto_writeoff': '自动冲抵',
      },
      bankCodeDict: {},
    }
  },
  computed: {
    ...mapGetters(['bankNameList']),
  },
  mounted () {
    this.getTradeHistory()
    this.translationDic(this.bankNameList, this.bankCodeDict)
  },
  methods: {
    handleSizeChange (val) {
      this.pageable.pageSize = val
      this.getTradeHistory()
    },
    handleCurrentChange (val) {
      this.pageable.pageNo = val
      this.getTradeHistory()
    },
    // 交易记录
    getTradeHistory () {
      this.queryData.applyId = this.$route.params.itemId
      this.queryData.pageSize = this.pageable.pageSize
      this.queryData.pageNum = this.pageable.pageNo
      if (this.dateRange.length > 0) {
        this.queryData.repayDateStart = this.dateRange[0]
        this.queryData.repayDateEnd = this.dateRange[1]
      }
      tradeHistory(this.queryData).then((res) => {
        if (res.data.respCode === '1000') {
          let data = res.data.body
          this.tableData = data.list
          this.pageable.totalRecord = data.total
        }
      }).catch((err) => { console.log(err) })
    },
    resetQuery () {
      for (let k in this.queryData) {
        this.queryData[k] = null
      }
      this.dateRange = []
      this.getTradeHistory()
    },
    translationDic (arr, dict) {
      arr.forEach((item) => {
        dict[item.dictKey] = item.dictName
      })
    },
  },
}
</script>

<style scoped lang="scss">
.tableTitle {
  margin: 10px 0;
}
.table-title-word {
  margin-right: 5px;
  height: 40px;
  line-height: 40px;
}
</style>
