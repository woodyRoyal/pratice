<template>
  <div class="pageWrap dealers-Tab">
    <div class="applyprogress-module-title">经销商提醒</div>
     <el-table :data="tableData" border style="width: 100%">
        <el-table-column label="序号" align="center" width="50" prop="listNum"></el-table-column>
        <el-table-column label="提醒内容" align="center" prop="remindContent">
          <template slot-scope="scope">
              {{scope.row.remindContent || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="发起提醒人" align="center" prop="reminder">
          <template slot-scope="scope">
              {{scope.row.reminder || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="操作时间" align="center" prop="created">
          <template slot-scope="scope">
              {{scope.row.created || '/'}}
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
      layout="sizes,total, prev, pager, next,jumper"
      @current-change="handleCurrentChange"
      :page-size="pagination.pageSize"
      :page-sizes="pagination.pageSizesArr"
      @size-change="handleSizeChange"
      :current-page="pagination.currentPage"
      :total="pagination.total"
      >
      </el-pagination>
  </div>
</template>
<script>
import { getRemindList } from '../../../api/applyProgress.js'
export default {
  data () {
    return {
      itemId: null,
      labelWidth: '140px',
      controlSpacing: 20, // 控件间距
      controlPieces: 8, // 控件占据
      tableData: [],
      pagination: {
        pageSize: 5,
        pageSizesArr: [5, 10, 15, 20],
        currentPage: 1,
        total: 0
      },
      formData: {},
      formRules: {}
    }
  },
  created () {
    this.itemId = this.$route.params.itemId ? +this.$route.params.itemId : null
    this.getInfo()
  },
  methods: {
    getInfo (val) {
      let d1 = {
        applyId: this.itemId,
        remindType: 1,
        pageSize: this.pagination.pageSize,
        pageNum: this.pagination.currentPage
      }
      let data = val ? Object.assign(d1, val) : d1
      if (this.itemId) {
        getRemindList(data).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body.list
            if (data.length) {
              this.pagination.total = res.data.body.total
              data.forEach((item, index) => {
                item.listNum = (this.pagination.total - (this.pagination.pageSize * (this.pagination.currentPage - 1))) - index
              })
              this.tableData = data
            }
          }
        }).catch(error => { console.log(error) })
      }
    },
    handleCurrentChange (val) {
      this.pagination.currentPage = val
      this.getInfo({
        pageNum: this.pagination.currentPage,
        pageSize: this.pagination.pageSize
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.getInfo({
        pageNum: this.pagination.currentPage,
        pageSize: this.pagination.pageSize
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.el-pagination {
  float: right;
  margin-top: 5px;
}
.pageWrap {
  overflow: hidden;
}
</style>
