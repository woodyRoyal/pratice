<template>
  <div v-if="newNetsData.applyId !== null ">
    <div class="tableTitle clearfix"><span class="table-title-word">新网银行</span></div>
    <table class="self-table-comp" :model="newNetsData">
      <tbody>
      <tr>
        <td>新网风控审核结果</td>
        <td>
          {{auditStatus[newNetsData.auditStatusReal]}}
          <el-button size="mini" type="primary" @click="updateNewNetsData" v-if="newNetsData.auditStatusReal === '5'" :loading="newNetsLoading">{{newNetsLoading === true ? '刷新中' : '刷新'}}</el-button>
        </td>
        <td>个人评分</td>
        <td>{{newNetsData.personRate}}</td>
      </tr>
      <tr>
        <td>手机号码</td>
        <td>{{newNetsData.phone}}</td>
        <td>查询日期</td>
        <td>{{newNetsData.queryDate}}</td>
      </tr>
      <tr>
        <td>拒绝原因</td>
        <td>{{newNetsData.rejectReason}}</td>
        <td>备注</td>
        <td>{{newNetsData.remake}}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
  export default {
    props: ['newNetsData', 'newNetsLoading'],
    data () {
      return {
        auditStatus: {
          '0': '拒绝',
          '1': '通过',
          '2': '处理中',
          '3': '异常',
          '4': '等待处理',
          '5': '未获取'
        }
      }
    },
    methods: {
      updateNewNetsData () {
        this.$emit('updateNewNetsDataHandle')
      }
    }
  }
</script>

<style scoped lang="scss"></style>
