<template>
  <div class="creditWrap self-creditWrap" ref="selfCreditWrap">
    <el-tabs v-model="activeName" @tab-click="tabClick">
      <el-tab-pane v-for="(item, index) in tabList" :key="index" :label="item.name" :name="(index + 1) + ''">
        <div>
          <Newnets :newNetsData="newNetsData" @updateNewNetsDataHandle="getNewNetsData" :newNetsLoading="newNetsLoading"></Newnets>
          <AttachedCompany :attachedCompanyData="attachedCompanyVo"></AttachedCompany>
          <PengYuan :pYTableData="pYTableData"></PengYuan>
          <ZhongBang :zhongBangData="zhongBangData"></ZhongBang>
          <Chouzhou :chouZhouData="chouZhouData"></Chouzhou>
          <Daikuanwang :dkwData="dkwData"></Daikuanwang>
          <Qianhai :qianHaiData="qianHaiData"></Qianhai>
          <Ja :jiaoData="jiaoData"></Ja>
          <Tongdun :tongdunData="tongdunData" :tongdunPage="tongdunPage" @updateData="updateTdData"></Tongdun>
          <Hf :huiFaData="huiFaData"></Hf>
        </div>
      </el-tab-pane>
      <OperatorsInfo :applyId="itemId" v-if="itemId"></OperatorsInfo>
    </el-tabs>
  </div>
</template>
<script>
  import { tabList, chouzhouDataInfo, DkwQhInfo, hfInfo, zhongBangDataInfo, JaInfo, newNetsDataInfo, pyDataInfo, tdInfo, getAttachedCompanyInfo } from '../../../api/applyProgress'
  import {fmoney} from '../../../utils/constant'
  import Daikuanwang from './daikuanwang'
  import Qianhai from './qianhai'
  import Ja from './jiao'
  import Tongdun from './tongdun'
  import Hf from './huifa'
  import Chouzhou from './chouzhou'
  import Newnets from './newnets'
  import PengYuan from './pengyuan'
  import ZhongBang from './zhongbang'
  import AttachedCompany from './attachedCompany'
  import OperatorsInfo from './../../components/applyerAndGuarantee/operatorsInfo'
  export default {
    props: ['outerActiveTableName', 'innerActiveTableName'],
    data () {
      return {
        activeName: '1',
        tabList: [],
        itemId: null,
        activeId: null,
        activeType: null,
        chouZhouData: {
          mobile: '',
          ifParserReport: '',
          queryDate: '',
          personalScore: '',
          riskResult: '',
          note: ''
        },
        zhongBangData: {
          show: false,
          auditStatus: '',
          effectiveDate: '',
          resultMessage: '',
          generalScore: '',
          debtScore: '',
          overdueScore: ''
        },
        dkwData: {
          show: false,
          applied: null,
          overdueCnt: '',
          maxOverdueDays: '',
          borrowedCnt: '',
          lastBorrowedDate: '',
          lastBorrowedShouldPayDate: '',
          lastBorrowedRealPayDate: '',
          lastBorrowedOverdueDays: '',
          latestBehaviorScore: '',
          applyScore: ''
        },
        huiFaData: {
          shixin: [],
          xianchu: [],
          qianshui: [],
          xiangao: [],
          zuifan: [],
          feizheng: [],
          zhixing: [],
          qiankuan: [],
          shenpan: [],
          caipan: [],
          weifa: []
        },
        jiaoData: {
          show: false,
          curStatusDesc: '',
          element3Desc: '',
          feeConsumeDesc: '',
          intimeDesc: '',
          ispInfo: ''
        },
        newNetsData: {
          applyId: null,
          auditStatusReal: '',
          personRate: '',
          phone: '',
          queryDate: '',
          rejectReason: '',
          remake: ''
        },
        pYTableData: {},
        qianHaiData: {
          show: false,
          credooScore: '',
          dataBuildTime: '',
          defaultRiskScore: ''
        },
        tongdunData: {
          finalScore: '',
          riskItems: [],
          total: 0
        },
        tongdunPage: {
          pageNum: 1,
          pageSize: 10,
          total: 0,
          pageSizes: [10, 15, 20]
        },
        attachedCompanyVo: {
          show: false,
          companyName: '',
          unifiedSocialCreditCode: '',
          submitStatusDesc: '',
          remark: '',
          attachedCount: null,
          attachedAmount: '',
          xwAttachedCount: null,
          xwAttachedAmount: '',
          riskResult: ''
        },
        newNetsLoading: false
      }
    },
    components: {
      Daikuanwang,
      Qianhai,
      Ja,
      Tongdun,
      Hf,
      Chouzhou,
      Newnets,
      PengYuan,
      ZhongBang,
      AttachedCompany,
      OperatorsInfo
    },
    mounted () {
      const {itemId} = this.$route.params
      this.itemId = itemId ? +itemId : null
      this.getTabList(this.itemId)
    },
    methods: {
      getTabList (val) {
        tabList({applyId: val}).then(res => {
          if (res.data.respCode === '1000') {
            this.tabList = res.data.body
            const id = this.activeId = this.tabList[0].id
            const type = this.activeType = this.tabList[0].type
            this.getCreditInfoData(id, type)
          }
        }).catch(error => { console.log(error) })
      },
      tabClick (tab) {
        this.pYTableData = {}
        this.attachedCompanyVo = {
          show: false,
          companyName: '',
          unifiedSocialCreditCode: '',
          submitStatusDesc: '',
          remark: '',
          attachedCount: null,
          attachedAmount: '',
          xwAttachedCount: null,
          xwAttachedAmount: '',
          riskResult: ''
        }
        const tabLab = tab.label
        this.tabList.forEach(item => {
          if (tabLab === item.name) {
            this.activeId = item.id
            this.activeType = item.type
            this.getCreditInfoData(item.id, item.type)
          }
        })
      },
      getCreditInfoData (id, type) {
        this.getNewNetsData(id, type)
        if (type === 0) {
          this.getAttachedCompanyData()
          this.getPyData()
        }
        this.getZhongBangData(id, type)
        this.getChouZhouData(id, type)
        this.getDkwInfo(type)
        this.getQhInfo(type)
        this.getJaInfo(type)
        this.getHfInfo(type)
        this.getTdInfo(type)
      },
      // 新网
      getNewNetsData (id = this.activeId, type = this.activeType) {
        this.newNetsLoading = true
        newNetsDataInfo(id, type).then(res => {
          this.newNetsLoading = false
          if (res.data.respCode === '1000') this.newNetsData = res.data.body
        }).catch(err => { console.log(err) })
      },
      // 挂靠公司
      getAttachedCompanyData () {
        getAttachedCompanyInfo(this.itemId).then(res => {
          if (res.data.respCode === '1000') {
            const data = res.data.body
            if (data.attachedAmount !== null) data.attachedAmount = fmoney(data.attachedAmount / 100)
            if (data.xwAttachedAmount !== null) data.xwAttachedAmount = fmoney(data.xwAttachedAmount / 100)
            data.show = false
            for (let k in data) {
              if (data[k] !== '' && data[k] !== null && k !== 'show') data.show = true
            }
            this.attachedCompanyVo = data
          }
        }).catch(err => { console.log(err) })
      },
      // 鹏元
      getPyData () {
        pyDataInfo(this.itemId).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            data.show = false
            this.pYTableData = data
            for (let k in this.pYTableData) {
              if (this.pYTableData[k] !== '' && k !== 'applyId' && k !== 'show') this.pYTableData.show = true
            }
          }
        }).catch(err => { console.log(err) })
      },
      // 众邦
      getZhongBangData (id, type) {
        zhongBangDataInfo(id, type).then(res => {
          if (res.data.respCode === '1000') {
            const data = res.data.body
            data.show = false
            const keyArr = Object.keys(JSON.parse(JSON.stringify(data)))
            for (let k = 0; k < keyArr.length; k++) {
              if (keyArr[k] !== 'show' && data[keyArr[k]] !== '' && data[keyArr[k]] !== null) {
                data.show = true
                break
              }
            }
            this.zhongBangData = data
          }
        }).catch(err => { console.log(err) })
      },
      // 稠州
      getChouZhouData (id, type) {
        chouzhouDataInfo(id, type).then(res => {
          if (res.data.respCode === '1000') this.chouZhouData = res.data.body
        }).catch(err => { console.log(err) })
      },
      // 贷款王
      getDkwInfo (type) {
        let data = {
          applyId: this.itemId,
          type
        }
        DkwQhInfo(data).then(res => {
          if (res.data.respCode === '1000') {
            const {creditDkwInfoVO} = res.data.body
            creditDkwInfoVO.show = false
            this.dkwData = creditDkwInfoVO
            let keyArr = Object.keys(JSON.parse(JSON.stringify(this.dkwData)))
            for (let k = 0; k < keyArr.length; k++) {
              if (keyArr[k] !== 'show' && this.dkwData[keyArr[k]] !== '') {
                this.dkwData.show = true
                break
              }
            }
          }
        })
      },
      // 前海
      getQhInfo (type) {
        let data = {
          applyId: this.itemId,
          type
        }
        DkwQhInfo(data).then(res => {
          if (res.data.respCode === '1000') {
            const {creditQianHaiVO} = res.data.body
            creditQianHaiVO.show = false
            this.qianHaiData = creditQianHaiVO
            let keyArr = Object.keys(JSON.parse(JSON.stringify(this.qianHaiData)))
            for (let k = 0; k < keyArr.length; k++) {
              if (this.qianHaiData[keyArr[k]] !== '' && this.qianHaiData[keyArr[k]] !== null && keyArr[k] !== 'show') {
                this.qianHaiData.show = true
                break
              }
            }
          }
        })
      },
      // 集奥
      getJaInfo (type) {
        let data = {
          applyId: this.itemId,
          type
        }
        JaInfo(data).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            data.show = false
            this.jiaoData = data
            let keyArr = Object.keys(JSON.parse(JSON.stringify(this.jiaoData)))
            for (let k = 0; k < keyArr.length; k++) {
              if (keyArr[k] !== 'show' && this.jiaoData[keyArr[k]] !== '' && this.jiaoData[keyArr[k]] !== null) {
                this.jiaoData.show = true
                break
              }
            }
          }
        })
      },
      // 汇法
      getHfInfo (type) {
        let data = {
          applyId: this.itemId,
          type
        }
        hfInfo(data).then(res => {
          if (res.data.respCode === '1000') {
            const {shixin, xianchu, qianshui, xiangao, zuifan, feizheng, zhixing, qiankuan, shenpan, caipan, weifa} = res.data.body
            this.huiFaData.shixin = shixin
            this.huiFaData.xianchu = xianchu
            this.huiFaData.qianshui = qianshui
            this.huiFaData.xiangao = xiangao
            this.huiFaData.zuifan = zuifan
            this.huiFaData.feizheng = feizheng
            this.huiFaData.zhixing = zhixing
            this.huiFaData.qiankuan = qiankuan
            this.huiFaData.shenpan = shenpan
            this.huiFaData.caipan = caipan
            this.huiFaData.weifa = weifa
          }
        })
      },
      // 同盾
      getTdInfo (type) {
        let data = {
          applyId: this.itemId,
          type,
          pageNum: this.tongdunPage.pageNum,
          pageSize: this.tongdunPage.pageSize
        }
        tdInfo(data).then(res => {
          if (res.data.respCode === '1000') {
            this.tongdunData = res.data.body
            this.tongdunPage.total = res.data.body.total
          }
        }).catch(err => { console.log(err) })
      },
      updateTdData (val) {
        if (val.pageSize) this.tongdunPage.pageSize = val.pageSize
        if (val.pageNum) this.tongdunPage.pageSize = val.pageNum
        this.getTdInfo(this.activeType)
      }
    }
  }
</script>
<style lang="scss" scoped>
  .self-creditWrap{
    overflow-y: auto;
    overflow-x: hidden;
  }
</style>
