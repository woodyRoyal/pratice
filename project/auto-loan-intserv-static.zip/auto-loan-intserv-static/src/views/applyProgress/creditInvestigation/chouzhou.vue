<template>
  <div v-if="chouZhouData && JSON.stringify(chouZhouData) !== '{}'">
    <div class="tableTitle clearfix"><span class="table-title-word">稠州银行</span></div>
    <table class="self-table-comp" :model="chouZhouData">
      <tbody>
      <tr>
        <td>手机号码</td>
        <td>{{chouZhouData.mobile}}</td>
        <td style="min-width: 109px">是否查的征信报告</td>
        <td>{{chouZhouData.ifParserReport}}</td>
      </tr>
      <tr>
        <td>查询日期</td>
        <td>{{chouZhouData.queryDate}}</td>
        <td>个人评分</td>
        <td>{{chouZhouData.personalScore}}</td>
      </tr>
      <tr>
        <td style="min-width: 121px">风控预审批判定结果</td>
        <td>{{chouZhouData.riskResult}}</td>
        <td>备注</td>
        <td>{{chouZhouData.note}}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
  export default {
    props: ['chouZhouData'],
    data () {
      return {}
    }
  }
</script>

<style scoped>

</style>
