<template>
  <div v-if="jiaoData.show">
    <div class="tableTitle clearfix"><span class="table-title-word">集奥征信</span></div>
    <table class="self-table-comp" :model="jiaoData">
      <tbody>
      <tr>
        <td>当前状态</td>
        <td>{{jiaoData.curStatusDesc}}</td>
        <td>三要素验证</td>
        <td>{{jiaoData.element3Desc}}</td>
      </tr>
      <tr>
        <td>月消费档次（元）</td>
        <td>{{jiaoData.feeConsumeDesc}}</td>
        <td>在网时长（月）</td>
        <td>{{jiaoData.intimeDesc}}</td>
      </tr>
      <tr>
        <td>运营商信息</td>
        <td>{{jiaoData.ispInfo}}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>
<script>
  export default {
    props: ['jiaoData'],
    data () {
      return {}
    }
  }
</script>
<style lang="scss" scoped></style>
