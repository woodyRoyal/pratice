<template>
  <div class="guaranteeInfo">
    <div class="tableTitle clearfix"><span class="table-title-word">担保人信息</span></div>
    <el-table :data="guaranteeList" style="width: 100%">
      <el-table-column label="序号" type="index" align="center"></el-table-column>
      <el-table-column label="担保人姓名" prop="suretyName" align="center"></el-table-column>
      <el-table-column label="与申请人关系" prop="relationship" align="center">
         <template slot-scope="scope">
          <span>{{suretyRelationDict[scope.row.relation]}}</span>
        </template>
      </el-table-column>
      <el-table-column label="手机号码" prop="phone" align="center"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button size="mini" @click="handleEdit(scope.$index, scope.row)">查看</el-button>
        </template>
      </el-table-column>
    </el-table>
    <addGuarantee
      v-if="dialogFormVisible"
      @closeDialogForm='closeDialogForm'
      :guaranteeItemId='guaranteeItemId'
      >
    </addGuarantee>
  </div>
</template>
<script>
  import { getGuaranteeListInfo } from '../../../api/applyProgress.js'
  import addGuarantee from './addGuarantee'
  import {mapGetters} from 'vuex'
  export default {
    data () {
      return {
        itemId: null,
        tableData: [],
        guaranteeList: [],
        dialogFormVisible: false,
        guaranteeItemId: null,
        firstGuarantee: false
      }
    },
    components: {
      addGuarantee
    },
    computed: {
      ...mapGetters(['suretyRelationDict'])
    },
    mounted () {
      this.itemId = this.$route.params.itemId ? +this.$route.params.itemId : null
      if (this.itemId) this.getGuaranteeListInfo()
    },
    methods: {
      getGuaranteeListInfo () {
        getGuaranteeListInfo(this.itemId).then(res => {
          if (res.data.respCode === '1000') this.guaranteeList = res.data.body
        }).catch(error => { console.log(error) })
      },
      handleEdit (index, row) {
        const {proposerId} = row
        this.dialogFormVisible = true
        this.guaranteeItemId = proposerId
        // if (index === 0) this.firstGuarantee = true
      },
      closeDialogForm () {
        this.dialogFormVisible = false
      }
    }
  }
</script>
<style lang="scss" scoped>
.guaranteeInfo {
  position: relative;
}
.addGuarantee {
  position: absolute;
  right: 0;
  top: -5px;
}
</style>

