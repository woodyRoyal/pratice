<template>
  <div class="applyTbPersonalWrap personal-applyTbPersonalWrap" ref="applyTbPersonalWrap">
    <!-- 基本信息 -->
    <el-form :model="proposerVO" label-position='top' :size="formSize" ref="proposerVO">
      <div>
        <div class="formModuleTitle"><span>基本信息</span></div>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="申请人姓名" class="is-required">
              <el-input v-model="proposerVO.nameStr" auto-complete="off" disabled maxlength="20" placeholder="请输入"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="证件类型" class="is-required">
              <el-select v-model="proposerVO.cardType" placeholder="请选择" disabled>
                <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in cardTypeList" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="证件号码" class="is-required">
              <el-input v-model="proposerVO.cardIdStr" auto-complete="off" disabled placeholder="请输入" maxlength="18"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="性别" class="is-required">
              <el-select v-model="proposerVO.sex" disabled>
                <el-option label="男" :value="0"></el-option>
                <el-option label="女" :value="1"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="出生日期" class="is-required">
              <el-date-picker type="date" placeholder="选择日期" v-model="proposerVO.birth" value-format="yyyy-MM-dd" disabled></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="年龄" class="is-required">
              <el-input v-model="proposerVO.age" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="签发机关" class="is-required">
              <el-input v-model="proposerVO.licenceIssuing" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="证件有效期（起）" class="is-required">
              <el-date-picker v-model="proposerVO.expiryDateStart" type="date" placeholder="选择日期" value-format="yyyy-MM-dd" disabled></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="证件有效期（止）" class="is-required">
              <div class="expiryDateEndWrap">
                <el-radio v-model="isExpiryDateEndLong" label="长期" disabled>长期</el-radio>
                <el-radio v-model="isExpiryDateEndLong" label="非长期" disabled>非长期</el-radio>
                <el-date-picker v-model="proposerVO.expiryDateEnd" type="date" placeholder="选择日期" value-format="yyyy-MM-dd" disabled></el-date-picker>
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="婚姻状况" class="is-required">
              <el-select v-model="proposerVO.married" placeholder="请选择" disabled>
                <el-option :label="item.dictName" :value="item.dictValue" v-for="item in marriedList" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="手机号码" class="is-required">
              <el-input v-model="proposerVO.phoneStr" auto-complete="off" disabled maxlength="11" placeholder="请输入"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="民族" class="is-required">
              <el-input v-model="proposerVO.race" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="承租人最高学历" class="is-required">
              <el-select v-model="proposerVO.education" placeholder="请选择" disabled>
                <el-option :label="item.dictName" :value="item.dictValue" v-for="(item, index) in educationList" :key="index"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="承租人最高学位" class="is-required">
              <el-select v-model="proposerVO.academicDegree" placeholder="请选择" disabled>
                <el-option :label="item.desc" :value="item.code" v-for="(item, index) in academicDegreeDict" :key="index"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </div>
    </el-form>
    <!-- 职业信息 -->
    <el-form :model="occupationalInfoVO" label-position='top' :size="formSize" ref="occupationalInfoVO">
      <div>
        <div class="formModuleTitle"><span>职业信息</span></div>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="单位名称" class="is-required">
              <el-input v-model="occupationalInfoVO.companyName" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="单位所在地省份-城市" class="is-required">
              <el-cascader :options="provinceCityList" v-model="occupationalInfoVO.provinceCity" :props="props" disabled></el-cascader>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="单位详细地址" class="is-required">
              <el-input v-model="occupationalInfoVO.address" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="公司行业" prop="industry" class="is-required">
              <el-select v-model="occupationalInfoVO.industry" placeholder="请选择" disabled>
                <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in industryList" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="单位电话" class="is-required">
              <el-input v-model="occupationalInfoVO.telStr" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </div>
    </el-form>
    <!-- 居住信息 -->
    <el-form :model="resideVO" label-position='top' :size="formSize" ref="resideVO">
      <div>
        <div class="formModuleTitle"><span>居住信息</span></div>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="现居所在地省份-城市" class="is-required">
              <el-cascader :options="provinceCityList" v-model="resideVO.provinceCity" :props="props" disabled></el-cascader>
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item label="居住详细地址" class="is-required">
              <el-input v-model="resideVO.address" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="户籍所在地省份-城市" class="is-required">
              <el-cascader :options="provinceCityList" v-model="resideVO.familyProvinceCity" :props="props" disabled></el-cascader>
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item label="户籍详细地址" class="is-required">
              <el-input v-model="resideVO.familyAddress" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </div>
    </el-form>
    <!-- 直系亲属 -->
    <el-form :model="relativesVO" label-position='top' :size="formSize" ref="relativesVO" v-if="proposerVO.married === 0 || proposerVO.married === 1 || proposerVO.married === 2 || proposerVO.married === 5" key="relativesModule">
      <div>
        <div class="formModuleTitle"><span>配偶或亲属</span></div>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="姓名" class="is-required">
              <el-input v-model="relativesVO.nameStr" auto-complete="off" maxlength="20" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="与申请人关系" class="is-required">
              <el-select v-model="relativesVO.relation" placeholder="请选择" disabled>
                <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in relativesRelationList" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="身份证号码" class="is-required">
              <el-input v-model="relativesVO.cardIdStr" auto-complete="off" maxlength="18" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="手机号码" class="is-required">
              <el-input v-model="relativesVO.phoneStr" auto-complete="off" maxlength="11" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="自查征信" class="is-required">
              <el-select v-model="relativesVO.selfCredit" placeholder="请选择" disabled>
                <el-option label="是" :value="0"></el-option>
                <el-option label="否" :value="1"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="单位名称">
              <el-input v-model="relativesVO.compaynName" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </div>
    </el-form>
    <!-- 征信 -->
    <el-form :model="creditVO" label-position='top' :size="formSize" ref="creditVO">
      <div>
        <div class="formModuleTitle"><span>征信信息</span></div>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="征信渠道" class="is-required">
              <el-select v-model="creditVO.creditChannel" placeholder="请选择" disabled>
                <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in creditChannelList" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </div>
    </el-form>
    <!--还款卡信息-->
    <el-form :model="repayCardInfo" label-position="top" :size="formSize" ref="repayCardInfo">
      <div>
        <div class="formModuleTitle"><span>还款卡信</span></div>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="还款卡开户行" class="is-required">
              <el-select v-model="repayCardInfo.bankCode" placeholder="请选择" disabled>
                <el-option :label="item.dictName" :value="item.dictKey" v-for="item in bankNameList" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="还款卡账号" class="is-required">
              <el-input v-model="repayCardInfo.debitCardNumStr" placeholder="请输入" :maxlength="19" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="银行预留手机号" class="is-required">
              <el-input v-model="repayCardInfo.phoneStr" placeholder="请输入" :maxlength="11" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </div>
    </el-form>
    <!-- 挂靠信息 -->
    <el-form :model="companyVO" label-position="top" v-if="+attached === 1" :size="formSize" ref="companyVO">
      <div>
        <div class="formModuleTitle"><span>挂靠企业信息</span></div>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="企业名称" class="is-required">
              <el-input v-model="companyVO.name" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="组织机构代码（或统一社会信息代码）" class="is-required">
              <el-input v-model="companyVO.creditId" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="营业执照编号" class="is-required">
              <el-input v-model="companyVO.businessLicense" auto-complete="off" maxlength="18" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="法人姓名" class="is-required">
              <el-input v-model="companyVO.legalPersonStr" auto-complete="off" placeholder="请输入" maxlength="20" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="法人身份证号" class="is-required">
              <el-input v-model="companyVO.legalIdStr" auto-complete="off" maxlength="18" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="法人手机号码" class="is-required">
              <el-input v-model="companyVO.phoneStr" auto-complete="off" maxlength="11" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="企业所在省份-城市" class="is-required">
              <el-cascader :options="provinceCityList" v-model="companyVO.companyProvinceCity" :props="props" disabled></el-cascader>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="企业所在地址" class="is-required">
              <el-input v-model="companyVO.companyAddress" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="企业经营地省份-城市" class="is-required" label-width="158px">
              <el-cascader :options="provinceCityList" v-model="companyVO.companyRealProvinceCity" :props="props" disabled></el-cascader>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="企业经营地址" class="is-required">
              <el-input v-model="companyVO.companyRealAddress" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="企业联系电话" class="is-required">
              <el-input v-model="companyVO.telStr" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="企业性质" class="is-required">
              <el-select v-model="companyVO.companyNature" placeholder="请选择" disabled>
                <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in natureList" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="企业从事行业" class="is-required">
              <el-select v-model="companyVO.companyIndustry" placeholder="请选择" disabled>
                <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in industryList" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </div>
    </el-form>
    <!-- 担保人信息 -->
    <GuaranteeInfo></GuaranteeInfo>
    <!-- 联系人信息 -->
    <ContactsInfo :type="1"></ContactsInfo>
  </div>
</template>
<script>
  import GuaranteeInfo from './guaranteeInfo.vue'
  import ContactsInfo from './contactsInfo.vue'
  import { getPersonalInfo, academicDegreeDict } from '../../../api/applyProgress.js'
  import {mapGetters} from 'vuex'
  // import {formatName, formatPhone, formatPapers} from '../../../filters'
  export default {
    props: ['outerActiveTableName', 'innerActiveTableName'],
    data () {
      return {
        formSize: 'small',
        itemId: null,
        academicDegreeDict,
        props: {
          value: 'key',
          label: 'name',
          children: 'list'
        },
        proposerVO: {
          type: 1, // 申请人和担保人用的一张表，为了区分
          name: '',
          cardType: null,
          cardId: null,
          sex: null,
          birth: null,
          age: null,
          licenceIssuing: null,
          expiryDateStart: null,
          expiryDateEnd: null,
          married: null,
          phone: null,
          race: null,
          education: null,
          academicDegree: null
        }, // 基本信息
        occupationalInfoVO: {
          companyName: '',
          provinceCity: null,
          address: '',
          industry: null,
          tel: null
        }, // 职业信息
        resideVO: {
          provinceCity: null,
          address: '',
          familyProvinceCity: null,
          familyAddress: ''
        }, // 居住信息
        relativesVO: {
          name: '',
          relation: null,
          cardId: null,
          phone: null,
          selfCredit: null,
          compaynName: ''
        }, // 亲属信息
        creditVO: {
          creditChannel: null,
          id: null,
          type: 1
        }, // 征信
        repayCardInfo: {
          id: null,
          bankCode: '',
          bankCardNo: null,
          reservePhone: null,
          capital: '2345'
        }, // 还款卡信息
        companyVO: {
          name: '',
          creditId: '',
          businessLicense: '',
          legalPerson: '',
          legalId: '',
          phone: '',
          companyAddress: '',
          companyRealAddress: '',
          tel: '',
          companyProvinceCity: null,
          companyRealProvinceCity: null,
          companyNature: null,
          companyIndustry: null
        }, // 挂靠企业
        attached: 0, // 是否挂靠
        controlSpacing: 10,
        controlPieces: 8,
        isExpiryDateEndLong: '非长期',
        clientHeight: null
      }
    },
    components: {GuaranteeInfo, ContactsInfo},
    mounted () {
      this.itemId = this.$route.params.itemId ? this.$route.params.itemId : null
      if (this.itemId) this.getInfo(this.itemId)
      this.autoHeight()
      window.addEventListener('resize', this.autoHeight)
    },
    destroyed () {
      window.removeEventListener('resize', this.autoHeight)
    },
    computed: {
      ...mapGetters([
        'cardTypeList',
        'marriedList',
        'educationList',
        'proposerTitleList',
        'industryList',
        'natureList',
        'resideNatureList',
        'creditChannelList',
        'relativesRelationList',
        'bankNameList',
        'provinceCityList'
      ])
    },
    methods: {
      // 数据拉取
      getInfo (val) {
        getPersonalInfo(val).then(res => {
          if (res.data.respCode === '1000') {
            const {proposerVO, occupationalInfoVO, resideVO, relativesVO, replamentCardInfo, creditVO, attached, companyVO} = res.data.body
            if (proposerVO.expiryDateEnd === '长期') {
              proposerVO.expiryDateEnd = ''
              this.isExpiryDateEndLong = '长期'
            } else {
              this.isExpiryDateEndLong = '非长期'
            }
            proposerVO.nameStr = proposerVO.name
            proposerVO.cardIdStr = proposerVO.cardId
            proposerVO.phoneStr = proposerVO.phone
            this.proposerVO = proposerVO // 基本信息
            occupationalInfoVO.provinceCity = occupationalInfoVO.province && occupationalInfoVO.city ? [occupationalInfoVO.province, occupationalInfoVO.city] : null
            occupationalInfoVO.telStr = proposerVO.tel
            this.occupationalInfoVO = occupationalInfoVO // 职业
            resideVO.provinceCity = resideVO.province && resideVO.city ? [resideVO.province, resideVO.city] : null
            resideVO.familyProvinceCity = resideVO.familyProvince && resideVO.familyCity ? [resideVO.familyProvince, resideVO.familyCity] : null
            this.resideVO = resideVO // 居住
            relativesVO.nameStr = relativesVO.name
            relativesVO.cardIdStr = relativesVO.cardId
            relativesVO.phoneStr = relativesVO.phone
            this.relativesVO = relativesVO // 亲属
            replamentCardInfo.debitCardNumStr = replamentCardInfo.debitCardNum
            replamentCardInfo.phoneStr = replamentCardInfo.phone
            this.repayCardInfo = replamentCardInfo // 还款卡
            this.creditVO = creditVO // 征信
            this.attached = attached || 0 // 挂靠
            if (+this.attached === 1) {
              companyVO.companyProvinceCity = companyVO.companyProvince && companyVO.companyCity ? [companyVO.companyProvince, companyVO.companyCity] : null
              companyVO.companyRealProvinceCity = companyVO.companyRealProvince && companyVO.companyRealCity ? [companyVO.companyRealProvince, companyVO.companyRealCity] : null
            }
            this.companyVO = companyVO // 公司信息
          }
        }).catch(error => { console.log(error) })
      },
      autoHeight () {
        this.clientHeight = document.documentElement.clientHeight
        this.$refs['applyTbPersonalWrap'].style.height = (this.clientHeight - 80) + 'px'
      }
    }
  }
</script>
<style lang="scss" scoped>
  .el-select{
    width: 100%;
  }
  .el-date-editor.el-input, .el-date-editor.el-input__inner {
    width: 100%;
  }
  .personal-applyTbPersonalWrap{
    overflow-x: hidden;
    overflow-y: auto;
  }
</style>
