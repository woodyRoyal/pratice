<template>
  <div ref="fileOuterWrap"
       class="outerWrap">
    <!--提报文件-->
    <div v-if="tbMustPicModulesList.length || tbNotMustPicModulesList.length">
      <FileUpload
        apply-node="identity_file"
        :show-save-button="false"
        :hide-tree="true"
        :hide-side-title="true"
        :hide-all-upload-switch="true"
        :hide-delete-btn="true"
        :necessary-upload-data="tbMustPicModulesList"
        :un-necessary-upload-data="tbNotMustPicModulesList"
        @showPicView="showPicViewHandle"
      ></FileUpload>
    </div>
    <!--内部上传文件-->
    <div v-if="internalAuditFile.length">
      <!--<div class="applyprogress-module-title">提报文件</div>-->
      <FileUpload
        apply-node="internal_audit_file"
        :show-save-button="false"
        :hide-tree="true"
        :hide-side-title="true"
        :hide-all-upload-switch="true"
        :hide-delete-btn="true"
        :necessary-upload-data="internalAuditFile"
        :un-necessary-upload-data="[]"
        @showPicView="showPicViewHandle"
      ></FileUpload>
    </div>
    <!--请款文件-->
    <div v-if="qkMustPicModulesList.length || qkNotMustPicModulesList.length">
      <!--<div class="applyprogress-module-title">请款文件</div>-->
      <FileUpload
        apply-node="request_loan_attachment"
        :show-save-button="false"
        :hide-tree="true"
        :hide-side-title="true"
        :hide-all-upload-switch="true"
        :hide-delete-btn="true"
        :necessary-upload-data="qkMustPicModulesList"
        :un-necessary-upload-data="qkNotMustPicModulesList"
        @showPicView="showPicViewHandle"
      ></FileUpload>
    </div>
    <!--贷后文件-->
    <div v-if="dhMustPicModulesList.length || dhNotMustPicModulesList.length">
      <FileUpload
        apply-node="post_loan_upload"
        :show-save-button="false"
        :hide-tree="true"
        :hide-side-title="true"
        :hide-all-upload-switch="true"
        :hide-delete-btn="true"
        :necessary-upload-data="dhMustPicModulesList"
        :un-necessary-upload-data="dhNotMustPicModulesList"
        @showPicView="showPicViewHandle"
      ></FileUpload>
    </div>
    <!--图片预览-->
    <div v-if="showPicView"
         v-drag
         class="pic-view-wrap">
      <PicView v-if="showPicView"
               :img-item-list="imgItemList"
               :click-item="clickItem"
               @closePicView="closePicViewHandle"></PicView>
    </div>
  </div>
</template>

<script>
  import {filesGet, filesListGet} from '../../../api/upload'
  import FileUpload from '../../../components/fileUpload/index'
  import PicView from '../../../components/PicView/index'
  export default {
    components: {FileUpload, PicView},
    data () {
      return {
        itemId: null,
        showPicView: false,
        imgItemList: [],
        clickItem: {},
        tbMustPicModulesList: [], // 提报
        tbNotMustPicModulesList: [], // 提报
        qkMustPicModulesList: [], // 请款
        qkNotMustPicModulesList: [], // 请款
        dhMustPicModulesList: [], // 贷后
        dhNotMustPicModulesList: [], // 贷后
        internalAuditFile: [], // 内部
      }
    },
    mounted () {
      const {itemId} = this.$route.params
      this.itemId = itemId ? +itemId : null
      if (this.itemId) {
        this.getTbFiles()
        this.getAllFiles()
      }
      this.autoHeight()
      window.addEventListener('resize', this.autoHeight)
    },
    destroyed () {
      window.removeEventListener('resize', this.autoHeight)
    },
    methods: {
      // 获取提报文件资料
      getTbFiles () {
        filesGet({applyId: this.itemId, showFaultFile: true}).then((res) => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            this.tbNotMustPicModulesList = data.notRequiredFileCategoryListVos
            this.tbMustPicModulesList = data.requiredFileCategoryListVos
          }
        }).catch((error) => { console.log(error) })
      },
      getAllFiles () {
        const apiData = {applyId: this.itemId, categoryList: ['internal_request_loan_attachment', 'post_loan_upload', 'internal_audit_file'], showFaultFile: true}
        filesListGet(apiData).then((res) => {
          if (res.data.respCode === '1000') {
            const applyMoneyData = res.data.body[0]
            const afterLendData = res.data.body[1]
            const internalAuditData = res.data.body[2]
            this.qkMustPicModulesList = applyMoneyData.requiredFileCategoryListVos
            this.qkNotMustPicModulesList = applyMoneyData.notRequiredFileCategoryListVos
            this.dhMustPicModulesList = afterLendData.requiredFileCategoryListVos
            this.dhNotMustPicModulesList = afterLendData.notRequiredFileCategoryListVos
            this.internalAuditFile = internalAuditData.requiredFileCategoryListVos
          }
        })
      },
      autoHeight () {
        this.clientHeight = document.documentElement.clientHeight
        this.$refs['fileOuterWrap'].style.height = (this.clientHeight - 80) + 'px'
      },
      showPicViewHandle (data) {
        this.showPicView = true
        this.imgItemList = data.imgItemList
        this.clickItem = data.clickItem
      },
      closePicViewHandle () {
        this.showPicView = false
      },
    },
  }
</script>

<style lang="scss" scoped>
  .outerWrap{
    overflow-y: auto;
  }
  .pic-view-wrap{
    position: absolute;
    top: 0;
    left: 50%;
    background: #fff;
    z-index: 1000;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.3);
  }
</style>
