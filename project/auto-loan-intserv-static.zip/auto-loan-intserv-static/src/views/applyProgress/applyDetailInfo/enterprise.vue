<template>
  <div class="wrap-2 applyTbEnterPriseWrap">
    <el-form :model="companyVO" label-position='top' size="small" ref="companyVO">
      <!-- 企业信息 -->
      <div>
        <div class="formModuleTitle"><span>企业信息</span></div>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="企业名称" class="is-required">
              <el-input v-model="companyVO.name" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="组织机构代码(或统一社会信息代码)" class="is-required">
              <el-input v-model="companyVO.creditId" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="营业执照编号" class="is-required">
              <el-input v-model="companyVO.businessLicense" auto-complete="off" maxlength="18" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="法人姓名" class="is-required">
              <el-input v-model="companyVO.legalPersonStr" auto-complete="off" disabled placeholder="请输入" maxlength="20"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="法人身份证号" class="is-required">
              <el-input v-model="companyVO.legalIdStr" auto-complete="off" maxlength="18" disabled placeholder="请输入"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="法人手机号码" class="is-required">
              <el-input v-model="companyVO.phoneStr" auto-complete="off" maxlength="11" disabled placeholder="请输入"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="企业所在省份-城市" class="is-required">
              <el-cascader :options="provinceCityList" v-model="companyVO.companyProvinceCity" :props="props" disabled></el-cascader>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="企业所在地址" class="is-required">
              <el-input v-model="companyVO.companyAddress" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="企业经营地省份-城市" class="is-required">
              <el-cascader :options="provinceCityList" v-model="companyVO.companyRealProvinceCity" :props="props" disabled></el-cascader>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="企业经营地址" class="is-required">
              <el-input v-model="companyVO.companyRealAddress" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="企业联系电话">
              <el-input v-model="companyVO.telStr" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="企业性质">
              <el-select v-model="companyVO.companyNature" placeholder="请选择" disabled>
                <el-option  v-for="item in natureList" :key="item.dictValue" :label="item.dictName"  :value="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="企业从事行业">
              <el-select v-model="companyVO.companyIndustry" placeholder="请选择" disabled>
                <el-option v-for="item in industryList" :key="item.dictValue" :label="item.dictName"  :value="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <div class="formModuleTitle"><span>还款卡信息</span></div>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="还款卡开户行">
              <el-select v-model="repayCardInfo.bankCode" placeholder="请选择" disabled>
                <el-option v-for="item in bankNameList" :key="item.dictValue" :label="item.dictName" :value="item.dictKey"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="还款卡账号">
              <el-input v-model="repayCardInfo.debitCardNumStr" placeholder="请输入" :maxlength="19" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="银行预留手机号">
              <el-input v-model="repayCardInfo.phoneStr" placeholder="请输入" :maxlength="11" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </div>
    </el-form>
    <!-- 担保人信息 -->
    <GuaranteeInfo></GuaranteeInfo>
    <!-- 联系人信息 -->
    <ContactsInfo :type='1'></ContactsInfo>
  </div>
</template>
<script>
  import GuaranteeInfo from './guaranteeInfo.vue'
  import ContactsInfo from './contactsInfo.vue'
  import {getEnterpriseInfo} from '../../../api/applyProgress.js'
  import {formatName, formatPhone, formatPapers} from '../../../filters'
  import {mapGetters} from 'vuex'
  export default {
    props: ['outerActiveTableName', 'innerActiveTableName'],
    data () {
      return {
        itemId: null,
        companyProvinceCity: [],
        companyRealProvinceCity: [],
        props: {
          value: 'key',
          label: 'name',
          children: 'list'
        },
        companyVO: {
          name: '',
          creditId: null,
          businessLicense: null,
          legalPerson: null,
          legalId: null,
          phone: null,
          companyProvinceCity: null,
          companyAddress: '',
          companyRealProvinceCity: null,
          companyRealAddress: '',
          tel: null,
          companyNature: null,
          companyIndustry: null
        },
        repayCardInfo: {
          bankCode: null,
          debitCardNum: null,
          phone: null
        },
        controlSpacing: 10,
        controlPieces: 8
      }
    },
    components: { GuaranteeInfo, ContactsInfo },
    computed: {
      ...mapGetters(['industryList', 'natureList', 'creditChannelList', 'provinceCityList', 'bankNameList'])
    },
    mounted () {
      this.itemId = this.$route.params.itemId ? +this.$route.params.itemId : null
      if (this.itemId) this.getInfo(this.itemId)
    },
    methods: {
      // 数据拉取函数
      getInfo (val) {
        getEnterpriseInfo({applyId: val}).then(res => {
          if (res.data.respCode === '1000') {
            // let data = res.data.body
            const {companyVO, replamentCardInfo} = res.data.body
            companyVO.companyProvinceCity = companyVO.companyProvince && companyVO.companyCity ? [companyVO.companyProvince, companyVO.companyCity] : null
            companyVO.companyRealProvinceCity = companyVO.companyRealProvince && companyVO.companyRealCity ? [companyVO.companyRealProvince, companyVO.companyRealCity] : null
            companyVO.legalPersonStr = formatName(companyVO.legalPerson, 1)
            companyVO.legalIdStr = formatPapers(companyVO.legalId, 1)
            companyVO.phoneStr = formatPhone(companyVO.phone, 1)
            companyVO.telStr = formatPhone(companyVO.tel, 1)
            this.companyVO = companyVO
            replamentCardInfo.debitCardNumStr = formatPapers(replamentCardInfo.debitCardNum, 1)
            replamentCardInfo.phoneStr = formatPhone(replamentCardInfo.phone, 1)
            this.repayCardInfo = replamentCardInfo
          }
        }).catch(error => { console.log(error) })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .el-select{
    width: 100%;
  }
  .el-date-editor.el-input, .el-date-editor.el-input__inner {
    width: 100%;
  }
  .el-cascader--small{
    width: 100%;
  }
</style>
