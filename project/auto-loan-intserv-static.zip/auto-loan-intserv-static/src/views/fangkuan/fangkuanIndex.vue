<template>
  <div>
    <!--查询表单-->
    <div class="queryArea">
      <el-form label-position="left" size="small">
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="申请编号" :label-width="formLable">
              <el-input maxlength="8" v-model="queryData.applyId" @blur="checkApplyId(queryData.applyId)" placeholder="输入申请编号" onkeypress='return(/^[0-9]*$/.test(String.fromCharCode(event.keyCode)))'></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="客户姓名" :label-width="formLable">
              <el-input maxlength="20" v-model="queryData.name" placeholder="输入客户姓名"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="申请类型" :label-width="formLable">
              <el-select v-model="queryData.applyType" placeholder="请选择">
                <el-option label="个人" :value="0"></el-option>
                <el-option label="企业" :value="1"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="车辆类型" :label-width="formLable">
              <el-select v-model="queryData.carType" placeholder="请选择">
                <el-option label="新车" :value="0"></el-option>
                <el-option label="二手车" :value="1"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="任务类型" :label-width="formLable">
              <el-select v-model="queryData.taskType" placeholder="请选择">
                <el-option :label="item.dictName" :value="item.dictValue" v-for="(item, index) in loanTaskType" :key="index"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item>
              <div class="queryBtnsArea">
                <el-button size="small" type="primary" @click="queryFn">查询</el-button>
                <el-button size="small" type="primary" @click="resetQueryFn">重置</el-button>
              </div>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <!--列表-->
    <div class="listArea">
      <el-table :data="listData" border style="width: 100%">
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="申请编号">
          <template slot-scope="scope">
            {{scope.row.applyId || '/'}}
            <el-tag type="warning" size="mini" v-if="scope.row.specialPermit">特批</el-tag>
            <el-tag type="warning" size="mini" v-if="scope.row.reconsideration">复议</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="申请类型">
          <template slot-scope="scope">
            {{APPLYTYPE[scope.row.applyType] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="客户名称">
          <template slot-scope="scope">
            {{scope.row.name || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="产品方案">
          <template slot-scope="scope">
            {{scope.row.productName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="租赁类型">
          <template slot-scope="scope">
            {{LEASETYPE[scope.row.leaseType] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="车辆类型">
          <template slot-scope="scope">
            {{CARTYPE[scope.row.carType] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="期数">
          <template slot-scope="scope">
            {{scope.row.term || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="融资额">
          <template slot-scope="scope">
            {{scope.row.amount || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="首付（%）">
          <template slot-scope="scope">
            {{scope.row.downPaymentRate === null ? '/' : scope.row.downPaymentRate}}
          </template>
        </el-table-column>
        <el-table-column label="任务类型">
          <template slot-scope="scope">
            {{loanTaskTypeDict[scope.row.taskType] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="任务创建时间">
          <template slot-scope="scope">
            {{scope.row.created || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="最近初审人员" v-if="checkRole()">
          <template slot-scope="scope">
            {{scope.row.preliminaryApprove || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="待审核人员">
          <template slot-scope="scope">
            {{scope.row.userName || '————'}}
          </template>
        </el-table-column>
        <el-table-column label="操作" fixed="right">
          <template slot-scope="scope">
            <el-button type="text" @click="handleCase(scope.row)">我要办理</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="clearfix">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="page.pageNum"
          :page-sizes="page.pageSizeArr"
          :page-size="page.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="page.total"
          class="tablePage">
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
  import {APPLYTYPE, LEASETYPE, CARTYPE, checkApplyId} from 'utils/constant'
  import {getFkList, checkToDetail} from '../../api/fangkuan'
  import {mapGetters} from 'vuex'
  export default {
    data () {
      return {
        APPLYTYPE,
        LEASETYPE,
        CARTYPE,
        checkApplyId,
        rowGutter: 10,
        colSpan: 8,
        formLable: '70px',
        queryData: {
          applyId: null,
          applyType: null,
          carType: null,
          name: '',
          taskType: null
        },
        listData: [],
        page: {
          pageNum: 1,
          pageSize: 10,
          pageSizeArr: [10, 20, 30, 40],
          total: 0
        }
      }
    },
    mounted () {
      this.fkList()
      this.checkRole()
    },
    computed: {
      ...mapGetters(['authority', 'loanTaskType', 'loanTaskTypeDict'])
    },
    methods: {
      checkRole () {
        if (this.authority === 'OP_LOAN_REVIEW') {
          return 1 // 放款复核
        } else {
          return 0 // 放款经办
        }
      },
      fkList () {
        this.queryData.pageSize = this.page.pageSize
        this.queryData.pageNum = this.page.pageNum
        getFkList(this.queryData).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body.list
            this.listData = data
            this.page.total = res.data.body.total
          }
        }).catch(error => { console.log(error) })
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.fkList()
      },
      handleCurrentChange (val) {
        this.page.pageNum = val
        this.fkList()
      },
      queryFn () {
        this.fkList()
      },
      resetQueryFn () {
        for (let k in this.queryData) {
          this.queryData[k] = null
        }
        this.fkList()
      },
      handleCase (val) {
        checkToDetail(val.id).then(res => {
          if (res.data.respCode === '1000') {
            window.open('#/fangkuanDetail/' + val.id + '/' + val.applyType)
          } else {
            this.fkList()
          }
        }).catch(error => { console.log(error) })
      } // 我要办理
    }
  }
</script>

<style lang="scss" scoped>
.queryArea{
  .el-select{
    width: 100%;
  }
}
  .queryBtnsArea{
    float: right;
  }
  .listArea{
    width: 100%;
  }
</style>
