<template>
  <div class="wrap">
    <div class="tableTitle"><span class="table-title-word">审批任务</span></div>
    <table>
      <tbody>
        <tr>
          <td>申请编号</td>
          <td>
            {{summaryInfo.applyNum || '/'}}
            <el-tag type="warning" size="mini" v-if="summaryInfo.specialPermit">特批</el-tag>
            <el-tag type="warning" size="mini" v-if="summaryInfo.reconsideration">复议</el-tag>
            <span @click="toApproveHistory" class="toApproveHistory">关联申请</span>
          </td>
          <td>提报店名称</td>
          <td class="wordsStyle">{{summaryInfo.storeName || '/'}}</td>
        </tr>
        <tr>
          <td>客户名称</td>
          <td class="wordsStyle">
            {{summaryInfo.customerName | formatName}}
            <span>（信用评级：{{ summaryInfo.riskCustomerLevel || '/' }})</span>
          </td>
          <td>产品方案</td>
          <td>{{summaryInfo.productName || '/'}}</td>
        </tr>
        <tr>
          <td>融资期限</td>
          <td>{{summaryInfo.term || '/'}}期</td>
          <td>融资总额</td>
          <td>{{summaryInfo.amount || '/'}}</td>
        </tr>
        <tr>
          <td>GPS个数</td>
          <td>{{summaryInfo.gpsNum === null ? '/' : summaryInfo.gpsNum}}</td>
          <td>申请类型</td>
          <td>{{applyType[summaryInfo.applyType] || '/'}}</td>
        </tr>
        <tr>
          <td>是否融保险</td>
          <td>{{summaryInfo.isInsurance || '/'}}</td>
          <td>租赁类型</td>
          <td>{{leaseType[summaryInfo.leaseType] || '/'}}</td>
        </tr>
        <tr>
          <td>是否先抵押后放款</td>
          <td>{{summaryInfo.isLoanFirst || '/'}}</td>
          <td>车辆类型</td>
          <td>{{carType[summaryInfo.carType] || '/'}}</td>
        </tr>
        <tr>
          <td>发动机号</td>
          <td>{{summaryInfo.carEngine || '/'}}</td>
          <td>车架号</td>
          <td>{{summaryInfo.carVin || '/'}}</td>
        </tr>
        <tr>
          <td>合同编号</td>
          <td>{{summaryInfo.contractNum || '/'}}</td>
          <td style="color: red">自动审批结果</td>
          <td style="color: red">{{summaryInfo.auditStatus || '/'}}</td>
        </tr>
        <tr>
          <td>车系类别</td>
          <td colspan="3">{{summaryInfo.carSeriesDesc || '/'}}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
<script>
import { summuryInfo } from '../../api/caseHandle.js'
import {LEASETYPE, CARTYPE, APPLYTYPE} from '../../utils/constant'
import { mapGetters } from 'vuex'
export default {
  data () {
    return {
      leaseType: LEASETYPE,
      carType: CARTYPE,
      applyType: APPLYTYPE,
      // 概要信息备注
      summaryInfo: {
        applyNum: null,
        specialPermit: null,
        reconsideration: null,
        storeName: '',
        customerName: '',
        productName: '',
        term: null,
        amount: null,
        gpsNum: null,
        applyType: null,
        isLoanFirst: '',
        carType: null,
        carEngine: '',
        carVin: '',
        contractNum: '',
        auditStatus: '',
        capital: '',
        carSeriesDesc: '',
        riskCustomerLevel: ''
      },
      capitalDict: {
        '2345': '2345',
        'EX-XW': '新网银行',
        'EX-ZB': '众邦银行'
      }
    }
  },
  computed: {
    ...mapGetters(['applyId'])
  },
  mounted () {
    this.getSummaryInfo(this.applyId)
  },
  methods: {
    getSummaryInfo (val) {
      summuryInfo({applyId: val}).then(res => {
        if (res.data.respCode === '1000') {
          this.summaryInfo = res.data.body
          const {capital} = res.data.body
          this.$store.dispatch('saveCaseCapital', {capital}) // 存储资方信息
        }
      }).catch(error => { console.log(error) })
    },
    toApproveHistory () {
      this.$emit('changeTabActiveName', {tabName: '7'})
    }
  }
}
</script>
<style lang="scss" scoped>
table {
  border: 1px solid #ccc;
  border-collapse: collapse;
  table-layout: fixed;
  width: 100%;
  td {
    border: 1px solid #ccc;
    padding: 5px;
    font-size: 14px;
    word-wrap: break-word;
    width: 80px;
    &:nth-child(2n) {
      text-align: center;
      vertical-align: middle;
      display: table-cell;
      vertical-align: middle;
    }
    &:nth-child(2n-1) {
      width: 90px;
    }
  }
}
h5{
  margin: 5px 0;
}
.toApproveHistory{
  color: red;
  text-decoration: underline;
  cursor: pointer;
}
</style>
