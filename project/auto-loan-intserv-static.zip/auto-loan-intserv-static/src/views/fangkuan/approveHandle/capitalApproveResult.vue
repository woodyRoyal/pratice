<template>
  <div class="capital-approve-res-module">
    <!--新网-->
    <ul v-if="storeCapital === 'EX-XW'" >
      <li>
        <span>新网风控准入结果：</span>
        <el-tag size="small" type="danger" v-if="capitalApproveData.capitalRiskAuditStatus === '0'">拒 绝</el-tag>
        <el-tag size="small" type="success" v-else-if="capitalApproveData.capitalRiskAuditStatus === '1'">通 过</el-tag>
        <el-tag size="small" type="warning" v-else-if="capitalApproveData.capitalRiskAuditStatus === '2'">处理中</el-tag>
        <el-tag size="small" type="danger" v-else-if="capitalApproveData.capitalRiskAuditStatus === '3'">异 常</el-tag>
      </li>
      <li>
        <span>人脸对比结果：</span>
        <el-tag size="small" type="info" v-if="capitalApproveData.capitalFaceVerifyStatus === '0'">未 知</el-tag>
        <el-tag size="small" type="success" v-else-if="capitalApproveData.capitalFaceVerifyStatus === '1'">通 过</el-tag>
        <el-tag size="small" type="danger" v-else-if="capitalApproveData.capitalFaceVerifyStatus === '2'">拒 绝</el-tag>
        <el-tag size="small" type="warning" v-else-if="capitalApproveData.capitalFaceVerifyStatus === '3'">等 待</el-tag>
      </li>
      <li class="refused-reason" v-if="capitalApproveData.capitalFaceVerifyReason">
        <span>人脸识别拒绝原因：</span>
        <span>{{capitalApproveData.capitalFaceVerifyReason}}</span>
      </li>
    </ul>
    <!--众邦-->
    <ul v-if="storeCapital === 'EX-ZB'" >
      <li>
        <span>众邦准入审批结果：</span>
        <el-tag size="small" type="danger" v-if="capitalApproveData.capitalRiskAuditStatus === '0'">拒 绝</el-tag>
        <el-tag size="small" type="success" v-else-if="capitalApproveData.capitalRiskAuditStatus === '1'">通 过</el-tag>
        <el-tag size="small" type="warning" v-else-if="capitalApproveData.capitalRiskAuditStatus === '2'">处理中</el-tag>
        <el-tag size="small" type="danger" v-else-if="capitalApproveData.capitalRiskAuditStatus === '3'">异 常</el-tag>
      </li>
      <li class="refused-reason" v-if="capitalApproveData.capitalRiskAuditStatus === '0'">
        <span>众邦准入审批结果描述：</span>
        <span>{{capitalApproveData.capitalRiskAuditDesc}}</span>
      </li>
      <li>
        <span>众邦授信审批结果：</span>
        <el-tag size="small" type="danger" v-if="capitalApproveData.creditApprovalStatus === '0'">拒 绝</el-tag>
        <el-tag size="small" type="success" v-else-if="capitalApproveData.creditApprovalStatus === '1'">通 过</el-tag>
        <el-tag size="small" type="warning" v-else-if="capitalApproveData.creditApprovalStatus === '2'">处理中</el-tag>
      </li>
      <li class="refused-reason" v-if="capitalApproveData.creditApprovalStatus === '0'">
        <span>众邦授信审批结果描述：</span>
        <span>{{capitalApproveData.creditApprovalDesc}}</span>
      </li>
    </ul>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default {
    props: ['capitalApproveData'],
    data () {
      return {}
    },
    computed: {
      ...mapGetters(['storeCapital'])
    }
  }
</script>
<style lang="scss">
  .capital-approve-res-module{
    box-sizing: border-box;
    margin: 5px 0 10px;
    ul {
      display: flex;
      flex-wrap: wrap;
      li{
        width: 50%;
        margin-bottom: 4px;
        display: flex;
        flex-direction: row;
        align-items: center;
        font-size: 14px;
        span:first-child{
          /*font-size: 14px;*/
          width: 127px;
          font-weight: 700;
        }
      }
      li.refused-reason{
        width: 100%;
        align-items: flex-start;
      }
    }
  }
</style>
