<template>
  <div class="gpsWrap">
    <div class="formModuleTitle"><span>GPS信息</span></div>
    <div v-if="gpsData.showFlag">
      <div>
        <el-button size="mini" type="primary" @click="locationGps">GPS定位</el-button>
      </div>
      <el-form label-position="top" size="small">
        <!--有线GPS-->
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="有线GPS厂商" :label-width="formLable" class="is-required">
              <el-select disabled v-model="gpsData.wiredSupplier">
                <el-option v-for="(item, index) in gpsSupplier" :key="index" :value="item.dictValue" :label="item.dictName"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="有线GPS设备号" :label-width="formLable" class="is-required">
              <el-input disabled v-model="gpsData.wiredDeviceNum"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="有线GPS是否激活" :label-width="formLable" class="is-required">
              <el-select disabled v-model="gpsData.wiredActivationStatus">
                <el-option :value="0" label="未激活"></el-option>
                <el-option :value="1" label="激活"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <!--无线GPS-->
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="无线GPS厂商" :label-width="formLable" class="is-required">
              <el-select disabled v-model="gpsData.wirelessSupplier">
                <el-option v-for="(item, index) in gpsSupplier" :key="index" :value="item.dictValue" :label="item.dictName"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="无线GPS设备号" :label-width="formLable" class="is-required">
              <el-input disabled v-model="gpsData.wirelessDeviceNum"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="无线GPS是否激活" :label-width="formLable" class="is-required">
              <el-select disabled v-model="gpsData.wirelessActivationStatus">
                <el-option :value="0" label="未激活"></el-option>
                <el-option :value="1" label="激活"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="店面联系人" :label-width="formLable" class="is-required">
              <el-input disabled v-model="gpsData.contact"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="店面联系人电话" :label-width="formLable" class="is-required">
              <el-input disabled v-model="gpsData.contactPhone"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="安装日期" :label-width="formLable" class="is-required">
              <el-date-picker type="datetime" placeholder="选择时间" value-format="yyyy-MM-dd HH:mm:ss" disabled v-model="gpsData.installDate"></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="安装所在省份-城市" label-width="141px" class="is-required">
              <el-cascader disabled :options="provinceCityList" :props="props" v-model="gpsData.provinceCity"></el-cascader>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="安装地址" :label-width="formLable" class="is-required">
              <el-input disabled v-model="gpsData.address"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan"></el-col>
        </el-row>
      </el-form>
    </div>
    <div v-else>此车不装GPS</div>
    <div v-if="gpsData.showFlag">
      <el-dialog :visible.sync="dialogTableVisible">
        <el-table :data="tableData" border>
          <el-table-column label="设备号">
            <template slot-scope="scope">
              {{scope.row.imei}}
            </template>
          </el-table-column>
          <el-table-column label="sim卡号">
            <template slot-scope="scope">
              {{scope.row.sim}}
            </template>
          </el-table-column>
          <el-table-column label="设备类型">
            <template slot-scope="scope">
              {{scope.row.deviceType}}
            </template>
          </el-table-column>
          <el-table-column label="运行状态">
            <template slot-scope="scope">
              {{scope.row.activationStatusDesc}}
            </template>
          </el-table-column>
          <el-table-column label="车架号">
            <template slot-scope="scope">
              {{scope.row.carVin}}
            </template>
          </el-table-column>
          <el-table-column label="定位时间">
            <template slot-scope="scope">
              {{scope.row.locationTime}}
            </template>
          </el-table-column>
          <el-table-column label="定位地址">
            <template slot-scope="scope">
              {{scope.row.locationAdd}}
            </template>
          </el-table-column>
        </el-table>
      </el-dialog>
      <div class="formModuleTitle"><span>GPS图片</span></div>
      <div>
        <el-button type="primary" size="mini" @click="reFreshGpsImg(1)" :loading="imgLoading">{{imgLoading ? '图片请求中' : '点击刷新'}}</el-button>
        <p class="gps-img-hint" v-if="gpsImgList.length === 0">暂无GPS图片</p>
        <ul class="gps-img-list-wrap">
          <li v-for="(item, index) in gpsImgList" :key="index" @click="showBigImg(item)"><img :src='item.filePathname' :alt="item.filePathname"></li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import {gpsLocation, getGpsImg} from '../../../api/fangkuan'
  export default {
    props: ['gpsData'],
    data () {
      return {
        rowGutter: 10,
        colSpan: 8,
        formLable: '136px',
        props: {
          value: 'key',
          label: 'name',
          children: 'list'
        },
        dialogTableVisible: false,
        tableData: [], // gps定位信息
        gpsImgList: [],
        imgLoading: false
      }
    },
    computed: {
      ...mapGetters(['provinceCityList', 'gpsSupplier', 'applyId'])
    },
    created () {
      if (this.provinceCityList.length === 0) this.$store.dispatch('getAreaTree')
    },
    mounted () {
      this.reFreshGpsImg()
    },
    methods: {
      locationGps () {
        this.dialogTableVisible = true
        gpsLocation(this.applyId)
          .then(res => {
            if (res.data.respCode === '1000') this.tableData = res.data.body
          })
          .catch(error => { console.log(error) })
      },
      reFreshGpsImg (refreshType = 0) {
        this.imgLoading = true
        getGpsImg({applyId: this.applyId, refreshType})
          .then(res => {
            this.imgLoading = false
            if (res.data.respCode === '1000') this.gpsImgList = res.data.body
          })
          .catch(err => {
            this.imgLoading = false
            console.log(err)
          })
      },
      showBigImg (item) {
        this.$emit('getGpsImgData', {
          imgItemList: this.gpsImgList,
          clickItem: item
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .el-button{
    margin-bottom: 5px;
  }
  .gps-img-hint{
    text-align: center;
    color: #409eff;
    font-weight: 700;
  }
  .gps-img-list{
    width: 100%;
    overflow-x: auto;
  }
  .gps-img-list-wrap{
    cursor: pointer;
    display: flex;
    white-space: nowrap;
    overflow-x: auto;
    li {
      width: 240px;
      height: 240px;
      flex-shrink: 0;
      img{
        display: block;
        width: 100%;
        height: 100%;
      }
    }
    li + li{
      margin-left: 5px;
    }
  }
</style>
