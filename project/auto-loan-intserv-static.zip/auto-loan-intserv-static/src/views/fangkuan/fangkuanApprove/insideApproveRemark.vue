<template>
  <div>
    <div class="warp clearfix">
      <div class="tableTitle">
        <span>内部审批备注</span>
        <div v-if="pagination.total !== 0" class="readStatus">
          <!--<span :class="[isRead === 0 ? 'notRead' : 'okRead']">({{isRead === 0 ? '未读':'已读'}})</span>-->
          <!--<span v-if="isRead === 0" @click="toRead" class="readBtn">已读</span>-->
          <el-tag :type="isRead === 0 ? 'danger': 'success'" size="small">{{isRead === 0 ? '未 读':'已 读'}}</el-tag>
          <el-button type="primary" size="mini" @click="toRead" style="margin-left: 10px">已 读</el-button>
        </div>
      </div>
      <el-table :data="listData" border>
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="提醒内容">
          <template slot-scope="scope">
            {{scope.row.remindContent || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="审批人员">
          <template slot-scope="scope">
            {{scope.row.remindRole || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="操作人">
          <template slot-scope="scope">
            {{scope.row.name || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="操作时间">
          <template slot-scope="scope">
            {{scope.row.operatorTime || '/'}}
          </template>
        </el-table-column>
      </el-table>
      <div class="paginationWrap">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pagination.currentPage" :page-sizes="pagination.pageSizes" :page-size="pagination.pageSize"
        layout="total, sizes, prev, pager, next, jumper" :total="pagination.total">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import { insideApproveRemark, haveRead, read } from '../../../api/caseHandle.js'
export default {
  data () {
    return {
      isRead: null,
      pagination: {
        currentPage: 1,
        pageSizes: [5, 10, 15],
        total: 0,
        pageSize: 5
      },
      // 查询条件
      queryData: {
        applyId: null,
        pageSize: 5,
        pageNum: 1,
        remindType: 2 // 内部审批固定值
      },
      // 列表数据
      listData: [],
      // 查询已读
      queryHaveRead: {
        applyId: null
      },
      // 读取消息数据
      toReadData: {
        applyId: null
      }
    }
  },
  computed: {
    ...mapGetters(['applyId'])
  },
  mounted () {
    this.queryData.applyId = this.applyId
    this.getInsideApproveRemark() // 获取列表数据
    this.getHaveRead() // 拉取已读状态
  },
  methods: {
    getHaveRead () {
      this.queryHaveRead.applyId = this.applyId
      haveRead(this.queryHaveRead).then(res => {
        if (res.data.respCode === '1000') this.isRead = res.data.body
      }).catch(error => { console.log(error) })
    },
    // 获取列表数据
    getInsideApproveRemark () {
      this.queryData.pageNum = this.pagination.currentPage
      this.queryData.pageSize = this.pagination.pageSize
      insideApproveRemark(this.queryData).then(res => {
        if (res.data.respCode === '1000') {
          this.listData = res.data.body.list
          this.pagination.total = res.data.body.total
        }
      }).catch(error => { console.log(error) })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.getInsideApproveRemark()
    },
    handleCurrentChange (val) {
      this.pagination.currentPage = val
      this.getInsideApproveRemark()
    },
    // 标记已读
    toRead () {
      this.toReadData.applyId = this.applyId
      read(this.toReadData).then(res => {
        if (res.data.respCode === '1000') this.isRead = res.data.body
      }).catch(error => { console.log(error) })
    }
  }
}
</script>
<style lang="scss" scoped>
  .warp{
    font-size: 14px;
  }
  .tableTitle{
    margin-bottom: 8px;
    overflow: hidden;
    height: 28px;
    line-height: 28px;
    >span{
      float: left;
    }
  }
  .readStatus{
    float: left;
    margin-left: 20px;
  }
  .paginationWrap{
    float: right;
    margin-top: 10px;
  }
</style>
