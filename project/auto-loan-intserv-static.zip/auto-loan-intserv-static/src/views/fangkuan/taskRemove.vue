<template>
  <div class="approverListWrap">
    <div>
      <div class="primaryWrap">
        <h5 class="approverListTitle">放款经办</h5>
        <ul>
          <li v-for="(item, index) in approverList.auditUsers" :key="index" @click="getTaskListByAuditApprover(item)" :class="{active: item.selected}">
            <span>{{item.username}}</span>
            <span>{{item.taskNum}}</span>
          </li>
        </ul>
      </div>
      <div class="reviewWrap">
        <h5 class="approverListTitle">放款复核</h5>
        <ul>
          <li v-for="(item, index) in approverList.reviewUsers" :key="index" @click="getTaskListByReviewApprover(item)" :class="{active: item.selected}">
            <span>{{item.username}}</span>
            <span>{{item.taskNum}}</span>
          </li>
        </ul>
      </div>
    </div>
    <div class="caseTable">
      <el-form label-position="top" size="mini">
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="申请编号">
              <el-input maxLength="8" v-model="queryTaskList.applyId" onkeypress='return(/^[0-9]*$/.test(String.fromCharCode(event.keyCode)))' @blur="checkApplyId"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="客户名称">
              <el-input v-model="queryTaskList.name" maxlength="20"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <div class="queryBtns">
              <el-button type="primary" size="mini" @click="getTaskList">查询</el-button>
              <el-button type="primary" size="mini" @click="queryReset">重置</el-button>
            </div>
          </el-col>
        </el-row>
      </el-form>
      <el-table ref="multipleTable" :data="taskListData" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange" border>
        <el-table-column type="selection"></el-table-column>
        <el-table-column label="申请编号">
          <template slot-scope="scope">
            {{scope.row.applyId}}
            <el-tag type="warning" size="mini" v-if="scope.row.specialPermit">特批</el-tag>
            <el-tag type="warning" size="mini" v-if="scope.row.reconsideration">复议</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="客户名称">
          <template slot-scope="scope">
            {{scope.row.name}}
          </template>
        </el-table-column>
        <el-table-column label="申请类型">
          <template slot-scope="scope">
            {{applyType[scope.row.applyType]}}
          </template>
        </el-table-column>
        <el-table-column label="产品方案">
          <template slot-scope="scope">
            {{scope.row.productName}}
          </template>
        </el-table-column>
        <el-table-column label="租赁类型">
          <template slot-scope="scope">
            {{leaseType[scope.row.leaseType]}}
          </template>
        </el-table-column>
        <el-table-column label="车辆类型">
          <template slot-scope="scope">
            {{carType[scope.row.carType]}}
          </template>
        </el-table-column>
        <el-table-column label="融资额">
          <template slot-scope="scope">
            {{scope.row.amount}}
          </template>
        </el-table-column>
        <el-table-column label="首付（%）">
          <template slot-scope="scope">
            {{scope.row.downPaymentRate}}
          </template>
        </el-table-column>
        <el-table-column label="任务类型">
          <template slot-scope="scope">
            {{loanTaskTypeDict[scope.row.taskType]}}
          </template>
        </el-table-column>
        <el-table-column label="任务创建时间">
          <template slot-scope="scope">
            {{scope.row.created}}
          </template>
        </el-table-column>
        <el-table-column label="任务名称">
          <template slot-scope="scope">
            {{taskNameDict[+scope.row.taskName]}}
          </template>
        </el-table-column>
        <el-table-column label="操作人员">
          <template slot-scope="scope">
            {{scope.row.operatorName}}
          </template>
        </el-table-column>
      </el-table>
      <div class="pageWrap">
        <el-button type="primary" size="mini" class="taskRemoveBtn" @click="taskRemoveFn">批量转件</el-button>
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="page.pageNum"
          :page-sizes="page.pageSizeArr"
          :page-size="page.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="page.total" class="page">
        </el-pagination>
      </div>
    </div>
    <el-dialog title="任务转件" :visible.sync="dialogTableVisible" @closed="taskDialogClosed">
      <el-table :data="taskRemoveApprovers">
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="姓名">
          <template slot-scope="scope">
            {{scope.row.username}}
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="text" size="mini" @click="task_Remove(scope.row)">转件</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
  import {approvers, taskList, taskListRemove, confirmRemove} from '../../api/taskRemove'
  import {LEASETYPE, APPLYTYPE, CARTYPE} from '../../utils/constant'
  import { formatSecondCH } from '../../utils/formatDate'
  import {mapGetters} from 'vuex'
  export default {
    data () {
      return {
        leaseType: LEASETYPE,
        applyType: APPLYTYPE,
        carType: CARTYPE,
        formatSecondCH,
        approverList: {},
        caseTableData: [],
        page: {
          pageNum: 1,
          pageSize: 10,
          pageSizeArr: [10, 20, 30, 40],
          total: null
        },
        timer: null,
        queryTaskList: {
          account: null,
          applyId: null,
          name: null,
          taskName: null
        },
        taskListData: [], // 转件任务列表
        taskRemoveApprovers: [], // 转件人员列表
        selectedTask: [], // 选择的需要转件的案件
        dialogTableVisible: false,
        applyIds: [], // 需要转件的案件
        taskNameDict: {9: '放款经办', 10: '放款复核'}
      }
    },
    mounted () {
      this.getApprovers()
      this.getTaskList()
      this.fetchPolling()
    },
    destroyed () {
      clearInterval(this.timer)
    },
    computed: {
      ...mapGetters(['loanTaskTypeDict'])
    },
    methods: {
      // 获取放款审核人员
      getApprovers () {
        approvers().then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            data.auditUsers.unshift({staffCode: null, taskNum: data.auditTaskNum, username: '全部'})
            data.auditUsers.forEach(item => {
              item.selected = false
              item.taskName = 9
            })
            data.reviewUsers.unshift({staffCode: null, taskNum: data.reviewTaskNum, username: '全部'})
            data.reviewUsers.forEach(item => {
              item.selected = false
              item.taskName = 10
            })
            this.approverList = data
          }
        }).catch(error => { console.log(error) })
      },
      // 获取任务列表
      getTaskList () {
        this.queryTaskList.pageSize = this.page.pageSize
        this.queryTaskList.pageNum = this.page.pageNum
        taskList(this.queryTaskList).then(res => {
          if (res.data.respCode === '1000') {
            this.taskListData = res.data.body.list
            this.page.total = res.data.body.total
          }
        }).catch(error => { console.log(error) })
      },
      // 点击放款经办人员查询
      getTaskListByAuditApprover (item) {
        this.approverList.auditUsers.forEach(i => {
          if (i.staffCode === item.staffCode) {
            i.selected = true
            this.queryTaskList.account = item.staffCode
            this.queryTaskList.taskName = item.taskName
            this.getTaskList()
          } else {
            i.selected = false
          }
        })
        // 放款复核样式全部初始化
        this.approverList.reviewUsers.forEach(i => {
          i.selected = false
        })
      },
      // 点击放款复核人员查询
      getTaskListByReviewApprover (item) {
        this.approverList.reviewUsers.forEach(i => {
          if (i.staffCode === item.staffCode) {
            i.selected = true
            this.queryTaskList.account = item.staffCode
            this.queryTaskList.taskName = item.taskName
            this.getTaskList()
          } else {
            i.selected = false
          }
        })
        // 放款经办样式全部初始化
        this.approverList.auditUsers.forEach(i => {
          i.selected = false
        })
      },
      // 获取任务转件人员列表
      getTaskRemoveApprover (val) {
        taskListRemove({applyIds: val}).then(res => {
          this.taskRemoveApprovers = res.data.body.batchTransferUsers
        }).catch(error => { console.log(error) })
      },
      // 查询转件列表接口轮询
      fetchPolling () {
        clearInterval(this.timer)
        this.timer = setInterval(() => {
          this.getTaskList()
        }, 60000)
      },
      // 选中的案件
      handleSelectionChange (val) {
        this.selectedTask = val
      },
      // 批量转件
      taskRemoveFn () {
        if (this.selectedTask.length) {
          this.dialogTableVisible = true
          let applyIds = this.selectedTask.map(item => {
            return item.id
          })
          this.applyIds = applyIds
          this.getTaskRemoveApprover(applyIds)
        } else {
          this.$message.warning('请至少选择一条任务')
        }
      },
      // 确认转件
      task_Remove (item) {
        let data = {
          applyIds: this.applyIds,
          staffCode: item.staffCode
        }
        confirmRemove(data).then(res => {
          if (res.data.respCode === '1000') {
            this.$message.success('操作成功')
            this.taskDialogClosed()
            this.getTaskList() // 列表数据
            this.getApprovers() // 人员数据
          }
        }).catch(error => { console.log(error) })
      },
      // 转件弹窗关闭
      taskDialogClosed () {
        this.dialogTableVisible = false
        this.applyIds = []
        this.$refs.multipleTable.clearSelection()
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.getTaskList()
      },
      handleCurrentChange (val) {
        this.page.pageNum = val
        this.getTaskList()
      },
      // 重置
      queryReset () {
        this.queryTaskList.name = null
        this.queryTaskList.taskName = null
        this.queryTaskList.applyId = null
        // 放款经办样式全部初始化
        this.approverList.auditUsers.forEach(i => {
          i.selected = false
        })
        // 放款复核样式全部初始化
        this.approverList.reviewUsers.forEach(i => {
          i.selected = false
        })
        this.getTaskList()
      },
      checkApplyId () {
        if (this.queryTaskList.applyId && !(/^[0-9]*$/.test(this.queryTaskList.applyId))) {
          this.queryTaskList.applyId = null
          this.$message.warning('输入有误请重新输入')
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .approverListWrap{
    display: flex;
    >div:nth-child(1){
      width: 10%;
      margin-right: 10px;
    }
    >div:nth-child(2){
      width: 90%;
    }
    ul{
      border: 1px solid #000;
      border-bottom: none;
    }
    li{
      display: flex;
      border-bottom: 1px solid #000;
      height: 28px;
      justify-content: space-around;
      align-items: center;
      cursor: pointer;
      span{
        text-align: center;
        &:nth-child(1){
          width: 50%;
          font-size: 14px;
        }
        &:nth-child(2){
          width: 33px;
          background-color: #f56c6c;
          border-radius: 10px;
          color: #fff;
          font-size: 12px;
          height: 22px;
          line-height: 19px;
          padding: 0 6px;
          text-align: center;
          white-space: nowrap;
          border: 1px solid #fff;
        }
      }
    }
  }
  .queryBtns{
    box-sizing: border-box;
    padding-top: 37px;
  }
  .primaryWrap{
    margin-bottom: 10px;
  }
  .approverListTitle{
    margin: 0 0 8px 0;
  }
  .taskRemoveBtn{
    float: left;
    margin-top: 1px;
  }
  .pageWrap{
    .page{
      float: right;
      margin-bottom: 5px;
    }
  }
  .active{
    background: #ccc;
  }
</style>
