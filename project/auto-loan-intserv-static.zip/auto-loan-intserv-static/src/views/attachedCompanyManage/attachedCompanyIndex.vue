<template>
  <div>
    <el-form label-position="top" size="small" :model="queryParam" ref="queryForm">
      <el-row :gutter="5">
        <el-col :span="8">
          <el-form-item label="挂靠公司名称">
            <el-input v-model="queryParam.companyName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="挂靠公司统一社会信用代码">
            <el-input v-model="queryParam.unifiedSocialCreditCode"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="挂靠公司法人身份证号" prop="legalPersonCertId">
            <el-input v-model="queryParam.legalPersonCertId" maxlength="18"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="5">
        <el-col :span="8">
          <el-form-item label="挂靠公司法人姓名">
            <el-input v-model="queryParam.legalPersonName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="挂靠公司法人手机号" prop="legalPersonPhone">
            <el-input v-model="queryParam.legalPersonPhone" maxlength="11"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="经销商简称">
            <el-input v-model="queryParam.dealerName"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="5">
        <el-col :span="8">
          <el-form-item label="状态">
            <el-select v-model="queryParam.submitStatus">
              <el-option v-for="item in statusOptions" :key="item.code" :value="item.code" :label="item.desc"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item>
            <div class="form-query-btn-wrap">
              <el-button type="primary" @click="getTableData">查 询</el-button>
              <el-button @click="restQuery">重 置</el-button>
            </div>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <el-table border :data="tableData">
      <el-table-column label="序号" type="index" align="center"></el-table-column>
      <el-table-column label="挂靠公司名称" align="center" prop="companyName"></el-table-column>
      <el-table-column label="挂靠公司统一社会信用代码" align="center" prop="unifiedSocialCreditCode" min-width="160"></el-table-column>
      <el-table-column label="挂靠公司法人姓名" align="center" prop="legalPersonName"></el-table-column>
      <el-table-column label="挂靠公司法人身份证号" align="center" prop="legalPersonCertId"></el-table-column>
      <el-table-column label="挂靠公司法人手机号" align="center" prop="legalPersonPhone"></el-table-column>
      <el-table-column label="提交时间" align="center" prop="submitTime"></el-table-column>
      <el-table-column label="提交人" align="center" prop="staffName"></el-table-column>
      <el-table-column label="提交经销商" align="center" prop="dealerName" min-width="160"></el-table-column>
      <el-table-column label="在贷数量" align="center" prop="attachedCount"></el-table-column>
      <el-table-column label="在贷金额" align="center">
        <template slot-scope="scope">
          {{fMoney(scope.row.attachedAmount / 100)}}
        </template>
      </el-table-column>
      <el-table-column label="状态" align="center" prop="submitStatusDesc"></el-table-column>
      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <el-button type="text" @click="() => { toDetailInfo(scope.row) }">查看详情</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="clearfix">
      <el-pagination
        @size-change="pageSizeChange"
        @current-change="pageNumChange"
        :current-page="page.pageNum"
        :page-sizes="page.pageSizeArr"
        :page-size="page.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="page.total"
        class="tablePage">
      </el-pagination>
    </div>
  </div>
</template>
<script>
  import {phoneRegxp, idCardRegxp, fmoney} from '../../utils/constant'
  import {getAttachedCompanyList} from '../../api/attachedCompanyApi'
  export default {
    data () {
      return {
        statusOptions: [
          {code: 0, desc: '待提交'},
          {code: 1, desc: '已提交'},
          {code: 2, desc: '提交失败'},
          {code: 3, desc: '审核中'},
          {code: 4, desc: '审核通过'},
          {code: 5, desc: '审核拒绝'},
          {code: 6, desc: '补件'}
        ],
        queryParam: {
          companyName: '',
          unifiedSocialCreditCode: '',
          legalPersonCertId: '',
          legalPersonName: '',
          legalPersonPhone: '',
          dealerName: '',
          submitStatus: ''
        },
        tableData: [],
        fMoney: fmoney,
        page: {
          pageNum: 1,
          pageSize: 10,
          pageSizeArr: [10, 20, 30, 40, 50],
          total: 0
        }
      }
    },
    mounted () {
      this.getTableData()
    },
    methods: {
      getTableData () {
        const {regxp1, regxp2} = idCardRegxp
        const {legalPersonPhone, legalPersonCertId} = this.queryParam
        if ((legalPersonPhone !== '') && (!phoneRegxp.test(legalPersonPhone))) {
          this.$message.warning('挂靠公司法人手机号输入有误')
          this.queryParam.legalPersonPhone = ''
          return false
        }
        if (legalPersonCertId !== '' && (!(regxp1.test(legalPersonCertId) || regxp2.test(legalPersonCertId)))) {
          this.queryParam.legalPersonCertId = ''
          this.$message.warning('挂靠公司法人身份证号输入有误')
          return false
        }
        const apiData = {...this.queryParam, pageNum: this.page.pageNum, pageSize: this.page.pageSize}
        getAttachedCompanyList(apiData).then(res => {
          const {respCode, body} = res.data
          if (respCode === '1000') {
            const {total, list} = body
            this.tableData = list
            this.page.total = total
          }
        }).catch(err => { console.error(err) })
      },
      restQuery () {
        this.queryParam = {
          companyName: '',
          unifiedSocialCreditCode: '',
          legalPersonCertId: '',
          legalPersonName: '',
          legalPersonPhone: '',
          dealerName: '',
          submitStatus: ''
        }
        this.page.pageNum = 1
        this.page.pageSize = 10
        this.getTableData()
      },
      pageSizeChange (pageSize) {
        this.page.pageSize = pageSize
        this.getTableData()
      },
      pageNumChange (pageNum) {
        this.page.pageNum = pageNum
        this.getTableData()
      },
      toDetailInfo (row) {
        const timeStamp = new Date().getTime()
        const {id, submitStatus} = row
        window.open(`#/attached-company-detail/${id}/${submitStatus}`, `${timeStamp}`)
      }
    }
  }
</script>
<style lang="scss" scoped>
  .form-query-btn-wrap{
    padding-top: 42px;
  }
</style>
