<template>
  <div class="outerWrap">
    <el-button type="primary" size="mini" @click="saveProduct" v-if="windowName !== '查看'" class="savePageBtn" :disabled="singleControl">保存本页内容</el-button>
    <!--基本信息-->
    <h5>请填写产品信息</h5>
    <el-form size="small" label-position="left" :model="productBasic" :rules="productBasicRule" ref="productBasic">
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan12" v-if="serialNo">
          <el-form-item label="产品ID" prop="serialNo">
            <el-input disabled v-model="productBasic.serialNo"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan12">
          <el-form-item label="产品名称" prop="productName">
            <el-input maxlength="20" placeholder="请输入" v-model="productBasic.productName"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
          <el-col :span="24">
            <el-form-item label="产品描述" prop="productDesc">
              <el-input type="textarea" maxlength="500" placeholder="请输入" v-model="productBasic.productDesc" :autosize="{ minRows: 2, maxRows: 4}"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      <h5>产品资方选择选择</h5>
      <el-row :gutter="rowGutter">
        <el-col :span="12">
          <el-form-item label="产品资方" prop="capital">
            <el-select v-model="productBasic.capital" size="small">
              <el-option v-for="(item, index) in productProgramList" :value="item.code" :label="item.desc" :key="index"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否进自动审批" prop="autoApprove">
            <el-select v-model="productBasic.autoApprove" size="small" placeholder="请选择">
              <el-option :value="1" label="是"></el-option>
              <el-option :value="2" label="否"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <!--产品参数配置-->
    <div class="simpleParamsWrap">
      <!--产品参数-->
      <h5>产品参数配置</h5>
      <el-form size="small" label-position="left" :rules="simpleParamsRules" :model="simpleParams" ref="simpleParams">
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan8">
            <el-form-item label="租赁类型" prop="lease_type">
              <el-checkbox-group v-model="simpleParams.lease_type">
                <el-checkbox-button v-for="item in radios.leaseType" :key="item.dictValue" :label="item.dictValue">{{item.dictName}}</el-checkbox-button>
              </el-checkbox-group>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan8">
            <el-form-item label="车辆类型" prop="car_type">
              <el-checkbox-group v-model="simpleParams.car_type">
                <el-checkbox-button v-for="item in radios.carType" :key="item.dictValue" :label="item.dictValue">{{item.dictName}}</el-checkbox-button>
              </el-checkbox-group>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan8">
            <el-form-item label="车系类别" prop="car_series">
              <el-checkbox-group v-model="simpleParams.car_series">
                <el-checkbox-button v-for="item in radios.carSerise" :key="item.dictValue" :label="item.dictValue">{{item.dictName}}</el-checkbox-button>
              </el-checkbox-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan8">
            <!--单选-->
            <el-form-item label="贴息方式" prop="interest_subsidy">
              <el-radio-group v-model="simpleParams.interest_subsidy">
                <el-radio-button v-for="item in radios.interestSubsidy" :key="item.dictValue" :label="item.dictValue">{{item.dictName}}</el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan8">
            <!--单选-->
            <el-form-item label="还款方式" prop="repayment_method">
              <el-radio-group v-model="simpleParams.repayment_method">
                <el-radio-button v-for="item in radios.repaymentMethod" :key="item.dictValue" :label="item.dictValue">{{item.dictName}}</el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan8">
            <!--单选-->
            <el-form-item label="还款频率" prop="repayment_frequency">
              <el-radio-group v-model="simpleParams.repayment_frequency">
                <el-radio-button v-for="item in radios.repaymentFrequency" :key="item.dictValue" :label="item.dictValue">{{item.dictName}}</el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan8">
            <!--单选-->
            <el-form-item label="利率类型" prop="interest_rate_type">
              <el-radio-group v-model="simpleParams.interest_rate_type">
                <el-radio-button v-for="item in radios.interestRateType" :key="item.dictValue" :label="item.dictValue">{{item.dictName}}</el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan8">
            <el-form-item label="融资期限" prop="term">
              <el-checkbox-group v-model="simpleParams.term" @change="termChange">
                <el-checkbox-button v-for="item in radios.terms" :key="item.dictValue" :label="item.dictValue">{{item.dictName}}</el-checkbox-button>
              </el-checkbox-group>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan8">
            <!--单选-->
            <el-form-item label="保证金冲抵" prop="deposit_charge_against">
              <el-radio-group v-model="simpleParams.deposit_charge_against">
                <el-radio-button v-for="item in radios.depositChargeAgainst" :key="item.dictValue" :label="item.dictValue">{{item.dictName}}</el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan8">
            <el-form-item label="店面属性" prop="store_type">
              <el-checkbox-group v-model="simpleParams.store_type">
                <el-checkbox-button v-for="item in radios.storeType" :key="item.dictValue" :label="item.dictValue">{{item.dictName}}</el-checkbox-button>
              </el-checkbox-group>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan8">
            <!--单选-->
            <el-form-item label="手续费扣款方式" prop="fee_payment_method">
              <el-radio-group v-model="simpleParams.fee_payment_method">
                <el-radio-button v-for="item in radios.feePaymentMethod" :key="item.dictValue" :label="item.dictValue">{{item.dictName}}</el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan8">
            <el-form-item label="申请类型" prop="apply_type">
              <el-checkbox-group v-model="simpleParams.apply_type">
                <el-checkbox-button v-for="item in radios.applyType" :key="item.dictValue" :label="item.dictValue">{{item.dictName}}</el-checkbox-button>
              </el-checkbox-group>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <!--产品手续费率设置-->
    <div class="productFeeWrap">
      <h5 class="is-required-self-right">产品手续费率设置</h5>
      <el-row :gutter="10" v-if="simpleParams.term.length">
        <el-col :span="4"><div class="productFeeTableHeader">融资期限</div></el-col>
        <el-col :span="5"><div class="productFeeTableHeader is-required-self-right">保证金比例（%）</div></el-col>
        <el-col :span="5"><div class="productFeeTableHeader is-required-self-right">年化结算利率（%）</div></el-col>
        <el-col :span="5"><div class="productFeeTableHeader is-required-self-right">手续费率（%）</div></el-col>
        <!--<el-col :span="5">对应万元系数</el-col>-->
      </el-row>
      <el-row v-if="simpleParams.term.indexOf(12) > -1" :gutter="5">
          <el-form :rules="termRules" :model="term12" ref="term12">
            <el-col :span="4"><div class="productFeeInnerLeft">{{term12.term}}期</div></el-col>
            <el-col :span="5">
              <el-form-item prop="earnestMoney">
                <el-input v-model="term12.earnestMoney" :size="termSetSize"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="5">
              <el-form-item prop="apr">
                <el-input v-model="term12.apr" :size="termSetSize"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="5">
              <el-form-item prop="fee">
                <el-input v-model="term12.fee" :size="termSetSize"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="5">
            </el-col>
          </el-form>
      </el-row>
      <el-row v-if="simpleParams.term.indexOf(24) > -1" :gutter="5">
        <el-form :rules="termRules" :model="term24" ref="term24">
          <el-col :span="4"><div class="productFeeInnerLeft">{{term24.term}}期</div></el-col>
          <el-col :span="5">
            <el-form-item prop="earnestMoney">
              <el-input v-model="term24.earnestMoney" :size="termSetSize"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item prop="apr">
              <el-input v-model="term24.apr" :size="termSetSize"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item prop="fee">
              <el-input v-model="term24.fee" :size="termSetSize"></el-input>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>
      <el-row v-if="simpleParams.term.indexOf(36) > -1" :gutter="5">
        <el-form :rules="termRules" :model="term36" ref="term36">
          <el-col :span="4"><div class="productFeeInnerLeft">{{term36.term}}期</div></el-col>
          <el-col :span="5">
            <el-form-item prop="earnestMoney">
              <el-input v-model="term36.earnestMoney" :size="termSetSize"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item prop="apr">
              <el-input v-model="term36.apr" :size="termSetSize"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item prop="fee">
              <el-input v-model="term36.fee" :size="termSetSize"></el-input>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>
      <el-row v-if="simpleParams.term.indexOf(48) > -1" :gutter="5">
        <el-form :rules="termRules" :model="term48" ref="term48">
          <el-col :span="4"><div class="productFeeInnerLeft">{{term48.term}}期</div></el-col>
          <el-col :span="5">
            <el-form-item prop="earnestMoney">
              <el-input v-model="term48.earnestMoney" :size="termSetSize"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item prop="apr">
              <el-input v-model="term48.apr" :size="termSetSize"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item prop="fee">
              <el-input v-model="term48.fee" :size="termSetSize"></el-input>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>
    </div>
    <!--产品适用范围选择-->
    <h5>产品适用范围选择</h5>
    <el-form size="small" label-position="left">
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan12">
          <el-form-item label="适用机构选择" class="is-required">
            <el-button type="primary" size="mini" @click="selectDealerArea">点击选择适用区域</el-button>
            <span :class="[+orgParams.length === 0 ? 'orgUnSelected': 'orgSelected']">{{+orgParams.length === 0 ? '未选择':'已选择' }}</span>
          </el-form-item>
        </el-col>
        <!--<el-col :span="colSpan12">
          <el-form-item label="适用车辆选择">
            <el-button type="primary" size="mini">点击选择适用车辆</el-button>
          </el-form-item>
        </el-col>-->
      </el-row>
    </el-form>
    <!--融资项目设置-->
    <h5>融资项目设置</h5>
    <el-table :data="financialParams" border>
      <el-table-column label="项目" align="center">
        <template slot-scope="scope">
          {{scope.row.financingName}}
        </template>
      </el-table-column>
      <el-table-column label="是否可融" align="center">
        <template slot-scope="scope">
          <el-checkbox v-model="scope.row.financing" @change="checkAllVal(scope.row)"></el-checkbox>
        </template>
      </el-table-column>
      <el-table-column label="首付" align="center">
        <template slot-scope="scope">
          <el-checkbox v-model="scope.row.downPayment" :disabled="!scope.row.financing"></el-checkbox>
        </template>
      </el-table-column>
      <el-table-column label="保证金" align="center">
        <template slot-scope="scope">
          <el-checkbox v-model="scope.row.deposit" :disabled="!scope.row.financing"></el-checkbox>
        </template>
      </el-table-column>
      <el-table-column label="手续费" align="center">
        <template slot-scope="scope">
          <el-checkbox v-model="scope.row.fee" :disabled="!scope.row.financing"></el-checkbox>
        </template>
      </el-table-column>
    </el-table>
    <!--产品必传资料设置-->
    <h5>产品资料设置</h5>
    <el-form size="small">
      <el-form-item label="资料选择" class="is-required">
        <el-button size="mini" type="primary" @click="selectMustUpload">点此选择材料</el-button>
        <span :class="[+productDatas.length === 0 ? 'orgUnSelected': 'orgSelected']">{{+productDatas.length === 0 ? '未选择':'已选择' }}</span>
      </el-form-item>
    </el-form>
    <!--规则引擎设置-->
    <h5>规则引擎</h5>
    <!--<el-button type="primary" size="mini" class="editorRuleBtn" @click="dialogRulesVisible = true">编辑规则</el-button>-->
    <el-table :data="editorRuleData" border style="width: 100%" class="rulesTable">
      <el-table-column align="center" width="60">
        <template slot-scope="scope">
          <el-checkbox v-model="scope.row.status" @change="ruleChange(scope.row)" :disabled="scope.row.disabled"></el-checkbox>
        </template>
      </el-table-column>
      <el-table-column type="index" label="序号"></el-table-column>
      <el-table-column align="left" label="规则">
        <template slot-scope="scope">
          <div v-html="scope.row.ruleDesc" class="inputWrap"></div>
        </template>
      </el-table-column>
    </el-table>
    <!--融资计算器规则-->
    <div class="calculateRuleWrap">
      <h5>融资计算器规则</h5>
      <el-form :model="calculateRuleData" size="mini" :rules="calculateRuleDataRules" ref="calculateRuleData">
        <el-form-item prop="gpsLoanRate">
          <span class="self-required">GPS放款额=GPS融资额*</span><el-input v-model="calculateRuleData.gpsLoanRate"></el-input>
        </el-form-item>
        <el-form-item prop="theftInsureLoanRate">
          <span class="self-required">盗抢险放款额=盗抢险*</span><el-input v-model="calculateRuleData.theftInsureLoanRate"></el-input>
        </el-form-item>
        <el-form-item prop="manageFee">
          <span class="self-required">租前管理费为</span><el-input v-model="calculateRuleData.manageFee"></el-input>
        </el-form-item>
        <el-form-item prop="companyManageFee">
          <span class="self-required">中卡车系且为个人挂靠件、企业件时租前管理费为</span><el-input v-model="calculateRuleData.companyManageFee"></el-input>
        </el-form-item>
      </el-form>
    </div>
    <!--选择必传资料-->
    <el-dialog title="选择资料" :visible.sync="dialogFileTreeVisible" @closed="fileDialogClosed">
      <el-tree
        :data="fileTreeData"
        :props="fileDefaultProps"
        show-checkbox
        node-key="dictValue"
        :default-expanded-keys="fileDefaultExpandedKeys"
        ref="filesTree">
      </el-tree>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFileTreeVisible = false" size="mini">取 消</el-button>
        <el-button type="primary" @click="confirmFileSelect" size="mini">确 定</el-button>
      </div>
    </el-dialog>
    <!--适用机构选择-->
    <el-dialog title="适用机构选择" :visible.sync="dialogDealerareaVisible" class="dialogDealer" @closed="dealerDialogClosed">
      <el-tree
        :data="orgData"
        ref="dealerTree"
        show-checkbox
        node-key="orgId"
        :default-expanded-keys="dealerDefaultExpandedKeys"
        :props="orgDefaultProps">
      </el-tree>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogDealerareaVisible = false" size="mini">取 消</el-button>
        <el-button type="primary" @click="confirmDealerSelect" size="mini">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import {dictionaryPost} from '../../api/commonApi.js'
  import {queryProductById, listFinancing, fileTreeList, saveProductInfo, ruleTemplate, productRules} from '../../api/productManage.js'
  import userApi from '../../api/user.js'
  import {accMul} from '../../utils/constant'
  export default {
    data () {
      let checkDigtal = (rule, value, callback) => {
        if (value === '' || value === null) {
          callback(new Error('内容不可为空'))
        } else if (!(/^[0-9]+(.[0-9]*)?$/.test(value))) {
          callback(new Error('输入有误'))
        } else {
          callback()
        }
      }
      /* let checkDigtalNotShould = (rule, value, callback) => {
        if ((value !== null && value !== '') && (!(/^[0-9]+(.[0-9]*)?$/.test(value)))) {
          callback(new Error('输入有误'))
        } else {
          callback()
        }
      } */
      return {
        rowGutter: 10,
        colSpan12: 12,
        colSpan8: 8,
        termSetSize: 'small',
        windowName: null,
        serialNo: null,
        productId: null,
        productName: '',
        productDesc: '',
        dialogFileTreeVisible: false,
        dialogDealerareaVisible: false,
        dialogRulesVisible: false,
        fileTreeData: [],
        // 机构树数据
        orgData: [],
        fileDefaultProps: {
          children: 'list',
          label: 'dictName'
        },
        // 机构树基础配置
        orgDefaultProps: {
          children: 'children',
          id: 'orgId',
          label: 'orgName'
        },
        // 机构树默认展开数据
        dealerDefaultExpandedKeys: [],
        fileDefaultExpandedKeys: [],
        // 产品参数配置选项
        radios: {},
        // ---------------------
        productBasic: {
          id: null,
          productName: null,
          productDesc: null,
          capital: null,
          autoApprove: null
        }, // 产品基本信息
        simpleParams: {
          lease_type: [],
          car_type: [],
          car_series: [],
          interest_subsidy: null,
          repayment_method: null,
          repayment_frequency: 1,
          interest_rate_type: null,
          term: [],
          deposit_charge_against: 0,
          store_type: [],
          fee_payment_method: null,
          apply_type: []
        }, // 产品参数数据
        // 产品资方
        productProgramList: [{code: 0, desc: '自有资金'}, {code: 1, desc: '新网银行'}, {code: 2, desc: '众邦银行'}],
        // 产品手续费率设置
        term12: {term: 12, earnestMoney: 0, apr: null, fee: 0},
        term24: {term: 24, earnestMoney: 0, apr: null, fee: 0},
        term36: {term: 36, earnestMoney: 0, apr: null, fee: 0},
        term48: {term: 48, earnestMoney: 0, apr: null, fee: 0},
        orgParams: [], // 产品适用区域选择
        financialParams: [], // 融资项目数据
        productDatas: [], // 产品必传资料数组
        /* productRulesData: {}, // 产品规则数据
        saveRuleData: {}, */
        editorRuleData: [], // 编辑产品规则数据
        productBasicRule: {
          serialNo: [{required: true, trigger: 'blur', message: '内容不可为空'}],
          productName: [{required: true, trigger: 'blur', message: '内容不可为空'}],
          capital: [{required: true, trigger: 'change', message: '内容不可为空'}],
          autoApprove: [{required: true, trigger: 'change', message: '内容不可为空'}]
        }, // 产品基本信息校验
        termRules: {
          earnestMoney: [{required: true, trigger: 'blur', validator: checkDigtal}],
          apr: [{required: true, trigger: 'blur', validator: checkDigtal}],
          fee: [{required: true, trigger: 'blur', validator: checkDigtal}]
        }, // 产品手续费率校验
        simpleParamsRules: {
          lease_type: [{required: true, trigger: 'change', message: '内容不可为空'}],
          car_type: [{required: true, trigger: 'change', message: '内容不可为空'}],
          car_series: [{required: true, trigger: 'change', message: '内容不可为空'}],
          interest_subsidy: [{required: true, trigger: 'change', message: '内容不可为空'}],
          repayment_method: [{required: true, trigger: 'change', message: '内容不可为空'}],
          repayment_frequency: [{required: true, trigger: 'change', message: '内容不可为空'}],
          interest_rate_type: [{required: true, trigger: 'change', message: '内容不可为空'}],
          term: [{required: true, trigger: 'change', message: '内容不可为空'}],
          deposit_charge_against: [{required: true, trigger: 'change', message: '内容不可为空'}],
          store_type: [{required: true, trigger: 'change', message: '内容不可为空'}],
          fee_payment_method: [{required: true, trigger: 'change', message: '内容不可为空'}],
          apply_type: [{required: true, trigger: 'change', message: '内容不可为空'}]
        }, // 产品参数校验
        calculateRuleData: {
          gpsLoanRate: null,
          theftInsureLoanRate: null,
          manageFee: null,
          companyManageFee: null
        }, // 融资计算器配置数据
        calculateRuleDataRules: {
          gpsLoanRate: [{required: true, trigger: 'blur', validator: checkDigtal}],
          theftInsureLoanRate: [{required: true, trigger: 'blur', validator: checkDigtal}],
          manageFee: [{required: true, trigger: 'blur', validator: checkDigtal}],
          companyManageFee: [{required: true, trigger: 'blur', validator: checkDigtal}]
        }, // 融资计算器配置校验
        windowCloseTimer: null,
        singleControl: false
      }
    },
    mounted () {
      this.windowName = window.name.slice(0, 2)
      this.getAllRadios()
      // 新增初始化融资项目设置
      if (+this.$route.params.serialNo === 0 && +this.$route.params.productId === 0) {
        this.getListFinancing()
        this.getRuleTemplate()
      }
      if (this.$route.params.serialNo && +this.$route.params.serialNo !== 0) {
        this.serialNo = +this.$route.params.serialNo // 查询产品配置参数
        this.productId = +this.$route.params.productId // 查询规则引擎参数
        this.queryProduct()
        this.getRulesList()
      }
    },
    methods: {
      getAllRadios () {
        dictionaryPost({
          category: [
            'lease_type',
            'car_type',
            'car_series',
            'interest_subsidy',
            'repayment_method',
            'repayment_frequency',
            'interest_rate_type',
            'term',
            'deposit_charge_against',
            'store_type',
            'fee_payment_method',
            'apply_type'
          ]
        }).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            this.radios = {
              leaseType: data.lease_type,
              carType: data.car_type,
              carSerise: data.car_series,
              interestSubsidy: data.interest_subsidy,
              repaymentMethod: data.repayment_method,
              repaymentFrequency: data.repayment_frequency,
              interestRateType: data.interest_rate_type,
              terms: data.term,
              depositChargeAgainst: data.deposit_charge_against,
              storeType: data.store_type,
              feePaymentMethod: data.fee_payment_method,
              applyType: data.apply_type
            }
          }
        })
      },
      // 控制是否可融
      checkAllVal (val) {
        if (val.financing === false) {
          for (let k in val) {
            if (k !== 'financingName' && k !== 'id' && k !== 'sort' && k !== 'status' && k !== 'financingKey') val[k] = false
          }
        }
      },
      // 融资期限改变
      termChange (val) {
        let arr = [12, 24, 36, 48]
        arr.forEach(item => {
          if (val.indexOf(item) < 0) {
            for (let k in this['term' + item]) {
              if (k !== 'term') {
                this['term' + item][k] = 0
              }
              if (k === 'apr') {
                this['term' + item][k] = null
              }
            }
          }
        })
      },
      // 查询产品详细信息
      queryProduct () {
        queryProductById(this.serialNo).then(res => {
          let data = res.data.body
          this.productBasic = data.productProgramVO // 基础信息
          // 处理单选（后端单选也返回的是数组）
          let radiosArr = ['interest_subsidy', 'repayment_method', 'repayment_frequency', 'interest_rate_type', 'deposit_charge_against', 'fee_payment_method']
          radiosArr.forEach(item => {
            data.simpleParams[item] = data.simpleParams[item].join('')
          })
          this.simpleParams = data.simpleParams // 产品参数
          // 产品手续费率设置，后端返回的是%后的数
          data.aprParams.forEach(item => {
            for (let k in item) {
              if (k !== 'term') {
                item[k] = accMul(item[k], 100)
              }
            }
            this.simpleParams.term.forEach(j => {
              if (j === item.term) {
                this['term' + j] = item // 赋值
              }
            })
          }) // 产品手续费率
          data.financingParams.forEach(item => {
            for (let k in item) {
              if (k !== 'id' && k !== 'sort' && k !== 'status') {
                if (item[k] === 0) {
                  item[k] = false
                } else if (item[k] === 1) {
                  item[k] = true
                }
              }
            }
          })
          this.financialParams = data.financingParams // 融资项目设置
          this.orgParams = data.orgParams // 机构
          this.productDatas = data.productDatas // 资料
          this.calculateRuleData = data.productCalculateConfigVO || {}
        }).catch(error => { console.log(error) })
      },
      // 保存产品信息
      saveProduct () {
        this.singleControl = true
        /* eslint-disable */
        let saveStatus1 = 1
        let saveStatus2 = 0
        let refs = ['productBasic', 'simpleParams', 'calculateRuleData']
        this.simpleParams.term.forEach(item => {
          refs.push('term' + item)
        })
        refs.forEach(item => {
          this.$refs[item].validate(valid => {
            if (!valid) saveStatus1 = 0
          })
        })
        // 融资项目必须要选一个
        this.financialParams.forEach(item => {
          for (let k in item) {
            if (item[k] === true) {
              if (item[k]) saveStatus2 = 1
            }
          }
        })
        let productRules = this.saveProductRules() // 产品规则引擎必填
        if (saveStatus1 && saveStatus2 && this.orgParams.length && this.productDatas.length && productRules.length) {
          let data = {}
          // 基础信息
          data.productProgramVO = this.productBasic
          delete data.productProgramVO.capitalName
          // 产品参数配置 --s
          // 后端单选也需要数组
          let simpleParamsCopy = JSON.parse(JSON.stringify(this.simpleParams)) // 深拷贝
          for (let k in simpleParamsCopy) {
            if (!Array.isArray(simpleParamsCopy[k])) {
              simpleParamsCopy[k] = [+simpleParamsCopy[k]]
            }
          }
          simpleParamsCopy.term = simpleParamsCopy.term.sort((a, b) => {return a-b}) // 融资期限排序
          data.simpleParams = simpleParamsCopy
          // 产品参数配置 --e

          // 产品手续费率 --s
          let aprParams = []
          // 找到选择的对应期数的手续费率，push进新数组
          this.simpleParams.term.forEach(item => {
            aprParams.push(this['term' + item])
          })
          // 百分比相关数据（后端要百分比过后的数）
          let aprParamsCopy = JSON.parse(JSON.stringify(aprParams)) // 深拷贝
          aprParamsCopy.forEach(item => {
            for (let k in item) {
              if (k !== 'term') {
                item[k] = item[k] / 100
              }
            }
          })
          data.aprParams = aprParamsCopy
          // 产品手续费率 --e

          // 适用机构 --s
          data.orgParams = this.orgParams
          // 适用机构 --e

          // 融资项目设置 --s
          let financialParamsCopy = JSON.parse(JSON.stringify(this.financialParams))
          financialParamsCopy.forEach(item => {
            for (let k in item) {
              if (k !== 'id' && k !== 'sort' && k !== 'status') {
                if (item[k] === false) {
                  item[k] = 0
                } else if (item[k] === true) {
                  item[k] = 1
                }
              }
            }
          })
          data.financingParams = financialParamsCopy
          // 融资项目设置 --e

          // 必传资料设置 --s
          data.productDatas = this.productDatas
          // 必传资料设置 --e

          // 产品规则引擎
          data.droolsParamsBO = {
            params: this.saveProductRules(),
            rules: this.editorRuleData
          }
          // 融资计算器
          data.productCalculateConfigVO = this.calculateRuleData
          saveProductInfo(data).then(res => {
            if (res.data.respCode === '1000') {
              this.$message.success('保存成功，页面即将关闭')
              clearTimeout(this.windowCloseTimer)
              this.windowCloseTimer = setTimeout(() => {
                window.close()
              }, 3000)
            } else {
              this.singleControl = false
            }
          }).catch(error => {
            this.singleControl = false
            console.log(error)
          })
        } else if (saveStatus1 === 0) {
          this.singleControl = false
          this.$message.warning('请检查产品信息，产品参数配置，产品手续费率设置，融资计算器规则')
        } else if (this.orgParams.length === 0) {
          this.singleControl = false
          this.$message.warning('请检查适用机构选择')
        } else if (saveStatus2 === 0) {
          this.singleControl = false
          this.$message.warning('请检查融资项目设置')
        } else if (this.productDatas.length === 0) {
          this.singleControl = false
          this.$message.warning('请检查资料选择')
        } else if (productRules.length === 0) {
          this.singleControl = false
          this.$message.warning('请检查规则引擎')
        } else {
          this.singleControl = false
          this.$message.warning('请检查必填信息')
        }
      },
      // 融资项目数据初始化
      getListFinancing () {
        listFinancing().then(res => {
          let data = res.data.body
          let newData = data.map(item => {
            return {...item, deposit: false, downPayment: false, fee: false, financing: false}
          })
          this.financialParams = newData
        }).catch(error => { console.log(error) })
      },
      // 机构树
      getOrgTree () {
        userApi.fetchQueryOrgList({orgId: 0, subQueryFlag: true}).then(res => {
          if (res.data.respCode === '1000') {
            this.orgData = JSON.parse(res.data.body)
          }
        }).catch(error => { console.log(error) })
      },
      // 资料树
      getFileTree () {
        fileTreeList().then(res => {
          this.fileTreeData = res.data.body
        }).catch(error => { console.log(error) })
      },
      // 点击选择适用机构按钮
      selectDealerArea () {
        // 获取树数据
        if (!this.orgData.length) this.getOrgTree()
        this.dialogDealerareaVisible = true
        // 处理异步
        if (this.orgParams.length !== 0) {
          // 渲染和展开数据
          this.$nextTick(() => {
            this.$refs.dealerTree.setCheckedKeys(this.orgParams)
            this.dealerDefaultExpandedKeys = this.orgParams
          })
        } else {
          this.$nextTick(() => {
            this.$refs.dealerTree.setCheckedKeys(this.orgParams)
            this.dealerDefaultExpandedKeys = this.orgParams
          })
        }
      },
      // 确认选择适用机构
      confirmDealerSelect () {
        this.dialogDealerareaVisible = false
        this.orgParams = this.$refs.dealerTree.getCheckedKeys(true)
      },
      // 适用机构关闭回调
      dealerDialogClosed () {
        if (!this.orgParams.length) this.orgData = [] // 如果确认选择的时候，是空的，要清空树结构源数据
      },
      // 点击选择必传资料
      selectMustUpload () {
        this.dialogFileTreeVisible = true
        if (!this.fileTreeData.length) this.getFileTree()
        // 处理异步
        if (this.productDatas.length !== 0) {
          // 渲染和展开数据
          this.$nextTick(() => {
            this.$refs.filesTree.setCheckedKeys(this.productDatas)
            this.fileDefaultExpandedKeys = this.productDatas
          })
        } else {
          this.$nextTick(() => {
            this.$refs.filesTree.setCheckedKeys(this.productDatas)
            this.fileDefaultExpandedKeys = this.productDatas
          })
        }
      },
      // 资料必传确认选择
      confirmFileSelect () {
        this.dialogFileTreeVisible = false
        this.productDatas = this.$refs.filesTree.getCheckedKeys(true)
      },
      // 必传文件关闭回调
      fileDialogClosed () {
        if (!this.productDatas.length) this.fileTreeData = []
      },
      // 产品规则初始化
      getRuleTemplate () {
        ruleTemplate().then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            data.forEach(item => {
              item.disabled = false
            })
            this.editorRuleData = data
          }
        }).catch(error => { console.log(error) })
      },
      // 查询产品规则引擎
      getRulesList () {
        productRules(this.productId).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            data.forEach(item => {
              item.disabled = false
            })
            this.editorRuleData = data
            this.$nextTick(() => {
              this.checkRuleValue()
            })
          }
        }).catch(error => { console.log(error) })
      },
      saveProductRules () {
        let valArr = []
        let newArr = this.editorRuleData.filter(item => {
          if (item.status === true) return item
        })
        if (newArr.length !== 0) {
          newArr.forEach(item => {
            if (item.paramNames.length > 0) {
              item.paramNames.forEach(k => {
                if (document.getElementById(k).value !== null && document.getElementById(k).value !== '') {
                  valArr.push({name: k, value: document.getElementById(k).value})
                }
              })
            } else if (item.paramNames.length === 0) {
              valArr.push({name: '', value: ''})
            }
          })
        }
        return valArr
      },
      ruleChange (val) {
        const {paramNames} = val
        if (!val.status) {
          for (let k = 0; k < paramNames.length; k++) {
            if (!document.getElementById(paramNames[k]).value) break
            document.getElementById(paramNames[k]).value = null
          }
        }
        // 几条规则存在互斥关系
        if (val.id === 7) {
          if (val.status) {
            this.editorRuleData.forEach(item => {
              if (item.id === 14 || item.id === 15 || item.id === 19 || item.id === 20) {
                if (item.status) item.status = !item.status
                item.disabled = true
              }
            })
          } else {
            this.editorRuleData.forEach(item => {
              if (item.id === 14 || item.id === 15 || item.id === 19 || item.id === 20) item.disabled = false
            })
          }
        }
        if (val.id === 14) {
          if (val.status) {
            this.editorRuleData.forEach(item => {
              if (item.id === 7 || item.id === 15 || item.id === 19 || item.id === 20) {
                if (item.status) item.status = !item.status
                item.disabled = true
              }
            })
          } else {
            this.editorRuleData.forEach(item => {
              if (item.id === 7 || item.id === 15 || item.id === 19 || item.id === 20) item.disabled = false
            })
          }
        }
        if (val.id === 15) {
          if (val.status) {
            this.editorRuleData.forEach(item => {
              if (item.id === 7 || item.id === 14 || item.id === 19 || item.id === 20) {
                if (item.status) item.status = !item.status
                item.disabled = true
              }
            })
          } else {
            this.editorRuleData.forEach(item => {
              if (item.id === 7 || item.id === 14 || item.id === 19 || item.id === 20) item.disabled = false
            })
          }
        }
        if (val.id === 19) {
          if (val.status) {
            this.editorRuleData.forEach(item => {
              if (item.id === 7 || item.id === 14 || item.id === 15 || item.id === 20) {
                if (item.status) item.status = !item.status
                item.disabled = true
              }
            })
          } else {
            this.editorRuleData.forEach(item => {
              if (item.id === 7 || item.id === 14 || item.id === 15 || item.id === 20) item.disabled = false
            })
          }
        }
        if (val.id === 20) {
          if (val.status) {
            this.editorRuleData.forEach(item => {
              if (item.id === 7 || item.id === 14 || item.id === 15 || item.id === 19) {
                if (item.status) item.status = !item.status
                item.disabled = true
              }
            })
          } else {
            this.editorRuleData.forEach(item => {
              if (item.id === 7 || item.id === 14 || item.id === 15 || item.id === 19) item.disabled = false
            })
          }
        }
      },
      checkRuleValue () {
        let arr = []
        this.editorRuleData.forEach(item => {
          arr.push(...item.paramNames)
        })
        arr.forEach(item => {
          if (document.getElementById(item) !== null) {
            document.getElementById(item).addEventListener('blur', () => {
              let val = document.getElementById(item).value
              if (!/^[0-9]+(.[0-9]*)?$/.test(val) && +val >= 0) {
                document.getElementById(item).value = null
                this.$message.warning('输入有误')
              }
            })
          }
          // console.log(document.getElementById(item))
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
  h5{
    margin: 8px 0;
    font-size: 14px
  }
  .productFeeTableHeader, .productFeeInnerLeft{
    width: 100%;
    text-align: center;
    height: 55px;
    line-height: 55px;
  }
  .productFeeInnerLeft{
    line-height: 40px;
    &:after{
      content: '*';
      color: #f56c6c;
      margin-left: 4px;
    }
  }
  .outerWrap{
    padding: 0 8px 0 5px;
  }
  .editorRuleBtn{
    margin-bottom: 5px;
  }
  .orgUnSelected{
    color: red;
  }
  .orgSelected{
    color: green;
  }
  .savePageBtn{
    float: right;
  }
  .inputWrap{
    text-align: left;
    box-sizing: border-box;
    padding-left: 10px;
  }
  .is-required-self-left{
    &:before{
      content: '*';
      color: #f56c6c;
      margin-right: 4px;
    }
  }
  .is-required-self-right{
    &:after{
      content: '*';
      color: #f56c6c;
      margin-right: 4px;
    }
  }
</style>
