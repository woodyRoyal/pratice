<template>
  <div>
    <el-form size="small" label-position="left">
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="产品编号" label-width="70px">
            <el-input v-model="queryData.serialNo"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="产品名称" label-width="70px">
            <el-input v-model="queryData.productName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="生效状态" label-width="70px">
            <el-select v-model="queryData.enable">
              <el-option :value="1" label="生效"></el-option>
              <el-option :value="0" label="未生效"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item>
            <el-button size="mini" type="primary" @click="getTableData">查询</el-button>
            <el-button size="mini" type="primary" @click="resetQuery">重置</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <el-button size="mini" type="text" @click="toDetail('add', '')">新增产品</el-button>
    <el-table border style="width: 100%" :data="tableData">
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="产品编号" align="center">
        <template slot-scope="scope">
          {{scope.row.serialNo}}
        </template>
      </el-table-column>
      <el-table-column label="产品名称" align="center">
        <template slot-scope="scope">
          {{scope.row.productName}}
        </template>
      </el-table-column>
      <el-table-column label="生效状态" align="center">
        <template slot-scope="scope">
          {{scope.row.enable === 1 ? '生效':'未生效'}}
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="toDetail('check', scope.row)">查看</el-button>
          <el-button type="text" size="mini" @click="toDetail('editor', scope.row)" :disabled="+scope.row.enable === 1">修改</el-button>
          <el-button type="text" size="mini" v-if="+scope.row.enable === 0" @click="useFn(scope.row.serialNo)">启用</el-button>
          <el-button type="text" size="mini" v-else @click="stopUseFn(scope.row.serialNo)">停用</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      class='listPagination'
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="page.pageNum"
      :page-size="page.pageSize"
      :page-sizes="page.pageSizeArr"
      layout="total, sizes, prev, pager, next, jumper"
      :total="page.total">
    </el-pagination>
  </div>
</template>
<script>
  import {getTableDataInfo, productUse, productUnuse} from '../../api/productManage.js'
  export default {
    data () {
      return {
        rowGutter: 10,
        colSpan: 6,
        tableData: [{}],
        queryData: {},
        page: {
          total: 0,
          pageNum: 1,
          pageSize: 10,
          pageSizeArr: [10, 20, 30, 40]
        }
      }
    },
    mounted () {
      this.getTableData()
    },
    methods: {
      getTableData () {
        this.queryData.pageNum = this.page.pageNum
        this.queryData.pageSize = this.page.pageSize
        getTableDataInfo(this.queryData).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data
            this.tableData = data.body.list
            this.page.total = data.body.total
          }
        }).catch(error => {
          console.log(error)
        })
      },
      resetQuery () {
        for (let k in this.queryData) {
          this.queryData[k] = null
        }
        this.getTableData()
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.getTableData()
      },
      handleCurrentChange (val) {
        this.page.pageNum = val
        this.getTableData()
      },
      toDetail (v1, v2) {
        let timeStamp = new Date().getTime()
        if (v1 === 'add') {
          window.open('#/product-detail/0/0', `新增${timeStamp}`)
        } else if (v1 === 'check') {
          window.open(`#/product-detail/${v2.serialNo}/${v2.id}`, `查看${timeStamp}`)
        } else if (v1 === 'editor') {
          window.open(`#/product-detail/${v2.serialNo}/${v2.id}`, `编辑${timeStamp}`)
        }
      },
      useFn (val) {
        productUse(val).then(res => {
          if (res.data.respCode === '1000') {
            this.$message.success('启用成功')
            this.getTableData()
          }
        }).catch(error => { console.log(error) })
      },
      stopUseFn (val) {
        productUnuse(val).then(res => {
          if (res.data.respCode === '1000') {
            this.$message.success('停用成功')
            this.getTableData()
          }
        }).catch(error => { console.log(error) })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .listPagination{
    margin-top: 10px;
    float: right;
  }
</style>
