<template>
  <div class="repayment-history-queryForm-wrap">
    <el-form size="small" label-position="left">
      <el-row :gutter="10">
        <el-col :span="8">
          <el-form-item label="申请编号" label-width="68px">
            <el-input v-model="queryData.applyDisplayId" @blur="checkApplyId(queryData.applyDisplayId)" maxlength="8"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="资方" label-width="68px">
            <el-select v-model="queryData.capital">
              <el-option v-for="(key, value, index) in capitals" :key="index" :value="value" :label="key"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="扣款类型" label-width="96px">
            <el-select v-model="queryData.fundRepayType">
              <el-option v-for="(key, value, index) in fundRepayTypes" :key="index" :label="key" :value="value"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="10">
        <el-col :span="8">
          <el-form-item label="扣款时间（起）" label-width="110px">
            <el-date-picker v-model="queryData.repayDateBegin" type="datetime" placeholder="选择日期" value-format="yyyy-MM-dd HH:mm:ss"></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="扣款时间（止）" label-width="110px">
            <el-date-picker v-model="queryData.repayDateEnd" type="datetime" placeholder="选择日期" value-format="yyyy-MM-dd HH:mm:ss"></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-button type="primary" size="mini" @click="resetQuery">重置</el-button>
          <el-button type="primary" size="mini" @click="getgetcutRepaymentApi">查询</el-button>
          <el-button type="primary" size="mini" @click="downLoadTable" :loading="exportLoading">{{this.exportLoading ? '下载中' : '下载'}}</el-button>
        </el-col>
    </el-row>
    </el-form>
    <div class="dataTable">
      <el-table :data="tableData" border>
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="申请编号">
          <template slot-scope="scope">
            {{scope.row.applyDisplayId || '/'}}
            <el-tag type="warning" size="mini" v-if="scope.row.specialPermit">特批</el-tag>
            <el-tag type="warning" size="mini" v-if="scope.row.reconsideration">复议</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="资方">
          <template slot-scope="scope">
            {{scope.row.capitalName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="扣款类型">
          <template slot-scope="scope">
            {{scope.row.fundRepayTypeStr || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="扣款时间">
          <template slot-scope="scope">
            {{scope.row.repaymentDate || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="扣款金额">
          <template slot-scope="scope">
            {{fMoney(scope.row.repaymentAmount) || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="期次">
          <template slot-scope="scope">
            {{scope.row.periods || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="扣款流水号">
          <template slot-scope="scope">
            {{scope.row.repayFlowNo || '/'}}
          </template>
        </el-table-column>
      </el-table>
      <div style="overflow: hidden">
        <el-pagination
          class='listPagination'
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="page.pageNum"
          :page-size="page.pageSize"
          :page-sizes="page.pageSizeArr"
          layout="total, sizes, prev, pager, next, jumper"
          :total="page.total">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
  import {checkApplyId, CAPITAL, FUNDREPAYTYPE, fmoney} from '../../utils/constant'
  import {getcutRepaymentApi, getcutRepaymentExportApi} from '../../api/financialManage'
  import {downLoadPolling} from '../../api/daihou'
  const qs = require('qs')
  export default {
    data () {
      return {
        capitals: CAPITAL,
        fundRepayTypes: FUNDREPAYTYPE,
        checkApplyId,
        fMoney: fmoney,
        queryData: {},
        tableData: [],
        exportLoading: false,
        page: {
          pageNum: 1,
          pageSize: 10,
          pageSizeArr: [10, 20, 30, 40],
          total: 0
        }
      }
    },
    mounted () {
      this.getgetcutRepaymentApi()
    },
    methods: {
      handleSizeChange (val) {
        this.page.pageSize = val
        this.getgetcutRepaymentApi()
      },
      handleCurrentChange (val) {
        this.page.pageNum = val
        this.getgetcutRepaymentApi()
      },
      getgetcutRepaymentApi () {
        if (
          new Date(this.queryData.repayDateBegin).getTime() >
          new Date(this.queryData.repayDateEnd).getTime()
        ) {
          this.queryData.repayDateEnd = ''
          this.queryData.repayDateBegin = ''
          this.$message.warning('扣款时间起不得大于扣款时间止')
        }
        this.queryData.pageSize = this.page.pageSize
        this.queryData.pageNum = this.page.pageNum
        return new Promise((resolve, reject) => {
          getcutRepaymentApi(this.queryData).then(res => {
            if (res.data.respCode === '1000') {
              let data = res.data.body
              this.tableData = data.list
              this.page.total = data.total
              resolve(1)
            } else {
              resolve(0)
            }
          }).catch(error => {
            reject(error)
            console.log(error)
          })
        })
      },
      // 文件导出
      downLoadTable () {
        if (this.exportLoading) {
          this.$message.warning('文件正在生成')
          return false
        } else {
          this.exportLoading = true // 开启loading
          this.getgetcutRepaymentApi().then(res => {
            if (res && this.tableData.length !== 0) {
              // 点击导出
              getcutRepaymentExportApi(this.queryData).then(res => {
                if (res.data.respCode === '1000') {
                  let exportSerialNo = res.data.body.serialNo
                  clearInterval(this.exportTimer)
                  // 接口轮询
                  this.exportTimer = setInterval(() => {
                    downLoadPolling(exportSerialNo).then(res => {
                      // 不管成功或失败，关闭loading
                      this.exportLoading = false
                      if (res.data.respCode === '1000') {
                        let data = res.data.body
                        if (data.status) {
                          // 生成成功
                          clearInterval(this.exportTimer)
                          // 导出
                          window.location.href = process.env.BASE_API + '/download/export?' + qs.stringify({filename: data.filename, storePath: data.storePath})
                        }
                      } else {
                        clearInterval(this.exportTimer)
                        // 生成失败
                        this.$message.warning('文件生成失败')
                      }
                    }).catch(error => { console.log(error) })
                  }, 1000)
                } else {
                  this.exportLoading = false // 关闭loading
                }
              }).catch(error => {
                this.exportLoading = false // 关闭loading
                console.log(error)
              })
            } else {
              this.exportLoading = false // 关闭loading
              this.$message.warning('该筛选条件下无数据可下载')
            }
          }).catch(error => {
            this.exportLoading = false // 关闭loading
            console.log(error)
          })
        }
      },
      resetQuery () {
        for (let k in this.queryData) {
          this.queryData[k] = null
        }
        this.getgetcutRepaymentApi()
      },
      toDetail (row) {
        window.open(`#/repayment-history-detail/${row.bookType}/${row.bookId}/${row.applyId}/${row.userId}/${row.billLoanNo}`)
      }
    }
  }
</script>
<style lang="scss" scoped>
  .listPagination{
    margin-top: 5px;
    float: right;
  }
</style>
