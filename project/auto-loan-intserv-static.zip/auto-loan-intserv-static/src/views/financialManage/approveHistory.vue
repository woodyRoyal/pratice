<template>
  <div class="approve-history">
    <div class="tableTitle clearfix"><span class="table-title-word">审批历史</span></div>
    <el-table :data="approveHistoryData" class="approveHistoryData" border>
      <el-table-column label="审批节点">
        <template slot-scope="scope">
          {{dict.stepDict[scope.row.step]}}
        </template>
      </el-table-column>
      <el-table-column label="审批结果" prop="auditResult">
        <template slot-scope="scope">
          {{scope.row.auditResult === 1 ? '通过' : (scope.row.auditResult === 2 ? '拒绝' : '退回')}}
        </template>
      </el-table-column>
      <el-table-column label="审批备注" prop="remark"></el-table-column>
      <el-table-column label="审批人员" prop="operator"></el-table-column>
      <el-table-column label="审批时间" prop="createAt"></el-table-column>
    </el-table>
  </div>
</template>
<script>
  import {dict} from '../../api/financialManage'
  export default {
    props: ['approveHistoryData'],
    data () {
      return {
        dict,
        page: {
          pageNum: 1,
          pageSize: 10,
          pageSizeArr: [10, 20, 30, 40],
          total: 10
        }
      }
    },
    methods: {
      handleSizeChange (val) {
        this.page.pageSize = val
      },
      handleCurrentChange (val) {
        this.page.pageNum = val
      }
    }
  }
</script>
<style lang="scss" scoped>
  .approve-history{
    margin-top: 10px;
  }
  .listPagination{
    float: right;
    margin-top: 5px;
  }
</style>
