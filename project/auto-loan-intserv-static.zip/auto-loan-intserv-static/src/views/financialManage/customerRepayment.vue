<!--回款记录查询-->
<template>
  <div>
    <el-form size="small" label-position="left" :inline="true" class="customer-query-form">
      <el-form-item label="申请编号">
        <el-input v-model="queryData.applyDisplayId" maxlength="8" @change="checkApplyId(queryData.applyDisplayId, 'applyDisplayId')"></el-input>
      </el-form-item>
      <el-form-item label="申请编号(老)">
        <el-input v-model="queryData.oldApplyId" maxlength="7" @change="checkApplyId(queryData.oldApplyId, 'oldApplyId',7)"></el-input>
      </el-form-item>
      <el-form-item label="扣款日期起">
        <el-date-picker type="date" value-format="yyyy-MM-dd" v-model="queryData.repayDateBegin"></el-date-picker>
      </el-form-item>
      <el-form-item label="扣款日期止">
        <el-date-picker type="date" value-format="yyyy-MM-dd" v-model="queryData.repayDateEnd"></el-date-picker>
      </el-form-item>
      <el-form-item>
        <div class="customer-query-reset">
          <el-button type="primary" size="mini" @click="getCustomerRepayList">查询</el-button>
          <el-button size="mini" @click="resetQuery">重置</el-button>
          <el-button type="primary" size="mini" :loading="exportLoading" @click="tableDownload">{{exportLoading ? '下载中' : '下载'}}</el-button>
        </div>
      </el-form-item>
    </el-form>
    <div class="dataTableWrap">
      <el-table border :data="tableData">
        <el-table-column label="序号" type="index" align="center"></el-table-column>
        <el-table-column label="订单号" align="center">
          <template slot-scope="scope">
            {{scope.row.repayFlowNo}}
          </template>
        </el-table-column>
        <el-table-column label="申请编号" align="center">
          <template slot-scope="scope">
            {{scope.row.applyDisplayId}}
            <el-tag type="warning" size="mini" v-if="scope.row.specialPermit">特批</el-tag>
            <el-tag type="warning" size="mini" v-if="scope.row.reconsideration">复议</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="申请编号(老)" align="center">
          <template slot-scope="scope">
            <!--老系统显示 oldApplyId，新系统显示 '/'-->
            {{scope.row.oldApplyId || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="客户姓名" align="center">
          <template slot-scope="scope">
            {{scope.row.customerName}}
          </template>
        </el-table-column>
        <el-table-column label="扣款日期" align="center">
          <template slot-scope="scope">
            {{scope.row.withholdDate}}
          </template>
        </el-table-column>
        <el-table-column label="扣款总金额" align="center">
          <template slot-scope="scope">
            {{scope.row.amountStr}}
          </template>
        </el-table-column>
        <el-table-column label="本金" align="center">
          <template slot-scope="scope">
            {{scope.row.principalStr}}
          </template>
        </el-table-column>
        <el-table-column label="利息" align="center">
          <template slot-scope="scope">
            {{scope.row.interestStr}}
          </template>
        </el-table-column>
        <el-table-column label="费用" align="center">
          <template slot-scope="scope">
            {{scope.row.feeStr}}
          </template>
        </el-table-column>
        <el-table-column label="滞纳金" align="center">
          <template slot-scope="scope">
            {{scope.row.lateFeeStr}}
          </template>
        </el-table-column>
        <el-table-column label="放款日期" align="center">
          <template slot-scope="scope">
            {{scope.row.transferDate}}
          </template>
        </el-table-column>
        <el-table-column label="扣款渠道" align="center">
          <template slot-scope="scope">
            {{scope.row.withholdChannel}}
          </template>
        </el-table-column>
        <el-table-column label="扣款资方" align="center">
          <template slot-scope="scope">
            {{scope.row.capital}}
          </template>
        </el-table-column>
        <el-table-column label="还款日期" align="center">
          <template slot-scope="scope">
            {{scope.row.repayDate}}
          </template>
        </el-table-column>
        <el-table-column label="是否小贷" align="center">
          <template slot-scope="scope">
            {{scope.row.micro}}
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <el-pagination
      class="listPagination"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="page.currentPage"
      :page-size="page.pageSize"
      :page-sizes="page.pageSizesArr"
      layout="total, sizes, prev, pager, next, jumper"
      :total="page.total">
    </el-pagination>
  </div>
</template>
<script>
  import {checkApplyId} from '../../utils/constant'
  // customerRepayList
  import {customerRepayDownload} from '../../api/financialManage.js'
  import {customerRepayList2} from '../../api/baobiao.js'
  import {reportDownloadPolling} from '../../api/daihou'
  const qs = require('qs')
  export default {
    data () {
      return {
        checkApplyId,
        queryData: {
          repayDateBegin: null,
          repayDateEnd: null,
          oldApplyId: null,
          applyDisplayId: null
        },
        tableData: [],
        page: {
          currentPage: 1,
          pageSize: 10,
          pageSizesArr: [10, 20, 30, 40],
          total: 0
        },
        exportLoading: false,
        exportTimer: null
      }
    },
    mounted () {
      this.getCustomerRepayList()
    },
    methods: {
      getCustomerRepayList () {
        if (this.queryData.repayDateBegin && this.queryData.repayDateEnd) {
          if (new Date(this.queryData.repayDateBegin).getTime() > new Date(this.queryData.repayDateEnd).getTime()) {
            this.queryData.repayDateBegin = ''
            this.queryData.repayDateEnd = ''
            this.$message.warning('扣款日期起不得大于扣款日期止')
          }
        }
        this.queryData.pageNo = this.page.currentPage
        this.queryData.pageSize = this.page.pageSize
        return new Promise((resolve, reject) => {
          customerRepayList2(this.queryData).then(res => {
            if (res.data.respCode === '1000') {
              let data = res.data.body
              this.tableData = data.list
              this.page.total = data.total
              resolve(1)
            } else {
              resolve(0)
            }
          }).catch(err => { console.log(err) })
        })
      },
      resetQuery () {
        for (let k in this.queryData) {
          this.queryData[k] = null
        }
        this.getCustomerRepayList()
        this.exportLoading = false
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.getCustomerRepayList()
      },
      handleCurrentChange (val) {
        this.page.currentPage = val
        this.getCustomerRepayList()
      },
      tableDownload () {
        if (this.exportLoading) {
          this.$message.warning('文件正在生成')
          return false
        } else {
          this.exportLoading = true // 开启loading
          this.getCustomerRepayList().then(data => {
            if (data && this.tableData.length > 0) {
              customerRepayDownload(this.queryData).then(res => {
                if (res.data.respCode === '1000') {
                  let exportSerialNo = res.data.body.serialNo
                  clearInterval(this.exportTimer)
                  this.exportTimer = setInterval(() => {
                    reportDownloadPolling('report_repayment_write_off', exportSerialNo).then(res => {
                      if (res.data.respCode === '1000') {
                        let data = res.data.body
                        if (data.status) {
                          clearInterval(this.exportTimer)
                          // 导出
                          window.location.href = process.env.BASE_API + '/download/export?' + qs.stringify({filename: data.filename, storePath: data.storePath})
                          this.exportLoading = false // 关闭loading
                        }
                      } else {
                        this.exportLoading = false // 关闭loading
                        clearInterval(this.exportTimer)
                      }
                    }).catch(err => { console.log(err) })
                  }, 1000)
                } else {
                  this.exportLoading = false
                }
              }).catch(err => { console.log(err) })
            } else {
              this.exportLoading = false // 关闭loading
              this.$message.warning('该筛选条件下无表格可下载')
            }
          })
        }
      }
    }
  }
</script>
<style lang="scss" scoped>
  .listPagination{
    float: right;
    margin-top: 5px;
  }
</style>
