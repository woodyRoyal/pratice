<template>
  <div class="repayment-history-queryForm-wrap">
    <el-form size="mini" label-position="left" :inline="true">
      <!-- <el-row :gutter="10"> -->
        <!-- <el-col :span="8"> -->
          <el-form-item label="申请编号" label-width="68px">
            <el-input v-model="queryData.applyDisplayId" @blur="checkApplyId(queryData.applyDisplayId)" maxlength="8"></el-input>
          </el-form-item>
          <el-form-item label="申请编号(老)" label-width="100px">
              <el-input maxlength="7" v-model="queryData.oldApplyNo" @blur="checkApplyId(queryData.oldApplyNo,'oldApplyNo',7)" placeholder="申请编号(老)" onkeypress='return(/^[0-9]*$/.test(String.fromCharCode(event.keyCode)))'></el-input>
            </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="8"> -->
          <el-form-item label="客户名称" label-width="68px">
            <el-input v-model="queryData.customerName" @blur="emptyNameCheck(queryData.customerName)"></el-input>
          </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="8"> -->
          <el-form-item label="勾稽类型" label-width="68px">
            <el-select v-model="queryData.bookType">
              <el-option v-for="(key, value, index) in bookTypeDict" :key="index" :value="value" :label="key"></el-option>
            </el-select>
          </el-form-item>
        <!-- </el-col> -->
      <!-- </el-row> -->
      <!-- <el-row :gutter="10"> -->
        <!-- <el-col :span="8"> -->
          <el-form-item label="提前结清类型" label-width="96px">
            <el-select v-model="queryData.advanceType">
              <el-option v-for="(key, value, index) in advanceTypeDict" :key="index" :label="key" :value="value"></el-option>
            </el-select>
          </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="8"> -->
          <el-form-item label="审核状态" label-width="68px">
            <el-select v-model="queryData.auditStatus">
              <el-option v-for="(key, value, index) in auditStatus" :key="index" :label="key" :value="value"></el-option>
            </el-select>
          </el-form-item>
        <!-- </el-col> -->
      <!-- </el-row> -->



      <!-- <el-row :gutter="10"> -->
        <!-- <el-col :span="8"> -->
          <el-form-item label="申请时间（起）" label-width="110px">
            <el-date-picker v-model="queryData.applyTimeStart" type="datetime" placeholder="选择日期" value-format="yyyy-MM-dd HH:mm:ss"></el-date-picker>
          </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="8"> -->
          <el-form-item label="申请时间（终）" label-width="110px">
            <el-date-picker v-model="queryData.applyTimeEnd" type="datetime" placeholder="选择日期" value-format="yyyy-MM-dd HH:mm:ss"></el-date-picker>
          </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="8"> -->
          <el-button type="primary" size="mini" @click="resetQuery">重置</el-button>
          <el-button type="primary" size="mini" @click="getRepaymentHistoryList">查询</el-button>
          <el-button type="primary" size="mini" @click="downLoadTable" :loading="exportLoading">{{this.exportLoading ? '下载中' : '下载'}}</el-button>
        <!-- </el-col> -->
    <!-- </el-row> -->
    </el-form>
    <div class="dataTable">
      <el-table :data="tableData" border>
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="申请编号">
          <template slot-scope="scope">
            {{scope.row.applyDisplayId || '/'}}
            <el-tag type="warning" size="mini" v-if="scope.row.specialPermit">特批</el-tag>
            <el-tag type="warning" size="mini" v-if="scope.row.reconsideration">复议</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="申请编号(老)" >
          <template slot-scope="scope">
            <!--老系统显示 oldApplyNo，新系统显示 '/'-->
            {{scope.row.oldApplyNo || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="勾稽类型">
          <template slot-scope="scope">
            {{scope.row.bookType && bookTypeDict[scope.row.bookType]}}
          </template>
        </el-table-column>
        <el-table-column label="提前结清类型">
          <template slot-scope="scope">
            {{advanceTypeDict[scope.row.advanceType] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="是否小贷">
          <template slot-scope="scope">
            {{scope.row.isMicroCredit == 1 ? '是' : '否'}}
          </template>
        </el-table-column>
        <el-table-column label="是否特殊还款">
          <template slot-scope="scope">
             {{scope.row.special == 1 ? '是' :'否'}}
          </template>
        </el-table-column>
        <el-table-column label="客户名称">
          <template slot-scope="scope">
            {{scope.row.customerName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="企业/挂靠企业名称">
          <template slot-scope="scope">
            {{scope.row.companyName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="经销商名称">
          <template slot-scope="scope">
            {{scope.row.dealerName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="预计到账时间">
          <template slot-scope="scope">
            {{scope.row.expectedTransferTime || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="收款银行">
          <template slot-scope="scope">
            {{scope.row.dueBankName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="收款账号">
          <template slot-scope="scope">
            {{scope.row.dueAccount || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="待确认金额">
          <template slot-scope="scope">
            {{scope.row.transferAmount === 0 ? '/' : (fMoney(scope.row.transferAmount / 100) || '/') }}
          </template>
        </el-table-column>
        <el-table-column label="勾稽申请时间">
          <template slot-scope="scope">
            {{scope.row.createAt || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="勾稽完成时间（结清日期）">
          <template slot-scope="scope">
            {{scope.row.finishTime || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="勾稽余额">
          <template slot-scope="scope">
            {{fMoney(scope.row.bookBalance / 100) || '0'}}
          </template>
        </el-table-column>
        <el-table-column label="勾稽金额">
          <template slot-scope="scope">
            {{fMoney(scope.row.bookAmount / 100) || '0'}}
          </template>
        </el-table-column>
        <el-table-column label="付款日期">
          <template slot-scope="scope">
            {{scope.row.repayDate || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="付款人">
          <template slot-scope="scope">
            {{scope.row.repayName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="付款金额">
          <template slot-scope="scope">
            {{fMoney(scope.row.repayAmt / 100) || '0'}}
          </template>
        </el-table-column>
        <el-table-column label="付款流水号">
          <template slot-scope="scope">
            <span class="tb-serialNo" v-html="`${scope.row.repaySerialNo + (scope.row.repayNum > 1 ? '<i>...</i>' : '') || '/'}`"></span>
          </template>
        </el-table-column>
        <el-table-column label="勾稽申请操作员">
          <template slot-scope="scope">
            {{scope.row.operatorName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="审核状态">
          <template slot-scope="scope">
            {{auditStatus[scope.row.auditStatus] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="text" size="mini" @click="toDetail(scope.row)">查看详情</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div style="overflow: hidden">
        <el-pagination
          class='listPagination'
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="page.pageNum"
          :page-size="page.pageSize"
          :page-sizes="page.pageSizeArr"
          layout="total, sizes, prev, pager, next, jumper"
          :total="page.total">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
  import {checkApplyId, fmoney} from '../../utils/constant'
  import {dict, repaymentHistoryList, repaymentHistoryListExport} from '../../api/financialManage'
  import {downLoadPolling} from '../../api/daihou'
  const {bookTypeDict, advanceTypeDict, auditStatus} = dict
  const qs = require('qs')
  export default {
    data () {
      return {
        dict,
        bookTypeDict,
        advanceTypeDict,
        auditStatus,
        checkApplyId,
        fMoney: fmoney,
        queryData: {
          customerName: null
        },
        tableData: [],
        exportLoading: false,
        page: {
          pageNum: 1,
          pageSize: 10,
          pageSizeArr: [10, 20, 30, 40],
          total: 0
        }
      }
    },
    mounted () {
      this.getRepaymentHistoryList()
    },
    methods: {
      handleSizeChange (val) {
        this.page.pageSize = val
        this.getRepaymentHistoryList()
      },
      handleCurrentChange (val) {
        this.page.pageNum = val
        this.getRepaymentHistoryList()
      },
      getRepaymentHistoryList () {
        this.queryData.pageSize = this.page.pageSize
        this.queryData.pageNum = this.page.pageNum
        return new Promise((resolve, reject) => {
          repaymentHistoryList(this.queryData).then(res => {
            if (res.data.respCode === '1000') {
              let data = res.data.body
              this.tableData = data.list
              this.page.total = data.total
              resolve(1)
            } else {
              resolve(0)
            }
          }).catch(error => {
            reject(error)
            console.log(error)
          })
        })
      },
      // 文件导出
      downLoadTable () {
        if (this.exportLoading) {
          this.$message.warning('文件正在生成')
          return false
        } else {
          this.exportLoading = true // 开启loading
          this.getRepaymentHistoryList().then(res => {
            if (res && this.tableData.length !== 0) {
              // 点击导出
              repaymentHistoryListExport(this.queryData).then(res => {
                if (res.data.respCode === '1000') {
                  let exportSerialNo = res.data.body.serialNo
                  clearInterval(this.exportTimer)
                  // 接口轮询
                  this.exportTimer = setInterval(() => {
                    downLoadPolling(exportSerialNo).then(res => {
                      // 不管成功或失败，关闭loading
                      this.exportLoading = false
                      if (res.data.respCode === '1000') {
                        let data = res.data.body
                        if (data.status) {
                          // 生成成功
                          clearInterval(this.exportTimer)
                          // 导出
                          window.location.href = process.env.BASE_API + '/download/export?' + qs.stringify({filename: data.filename, storePath: data.storePath})
                        }
                      } else {
                        clearInterval(this.exportTimer)
                        // 生成失败
                        this.$message.warning('文件生成失败')
                      }
                    }).catch(error => { console.log(error) })
                  }, 1000)
                } else {
                  this.exportLoading = false // 关闭loading
                }
              }).catch(error => {
                this.exportLoading = false // 关闭loading
                console.log(error)
              })
            } else {
              this.exportLoading = false // 关闭loading
              this.$message.warning('该筛选条件下无数据可下载')
            }
          }).catch(error => {
            this.exportLoading = false // 关闭loading
            console.log(error)
          })
        }
      },
      resetQuery () {
        for (let k in this.queryData) {
          this.queryData[k] = null
        }
        this.getRepaymentHistoryList()
      },
      toDetail (row) {
        window.open(`#/repayment-history-detail/${row.bookType}/${row.bookId}/${row.applyId}/${row.userId}/${row.billLoanNo}`)
      },
      emptyNameCheck (val) {
        if (val !== null && val.trim() === '') {
          this.queryData.customerName = null
        }
      }
    }
  }
</script>
<style lang="scss" scoped>
  .listPagination{
    margin-top: 5px;
    float: right;
  }
</style>
<style lang="scss">
.tb-serialNo {
  i {
    color: red;
    font-weight: bolder;
  }
}
</style>
