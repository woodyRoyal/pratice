<template>
  <div>
    <div class="tableTitle clearfix">
      <span class="table-title-word">客户还款明细</span>
      <el-button type="text"
                 size="mini"
                 @click="getRepaymentPlans">
        点此刷新
      </el-button>
      <i>当前资方：<el-tag type="danger"
                      size="mini">{{ currentCapitalName }}</el-tag></i>
    </div>
    <el-table :data="repaymentList"
              border
              height="310px">
      <el-table-column label="期数"
                       prop="periodNo"
                       min-width="40"></el-table-column>
      <el-table-column label="应还日期"
                       prop="repayDate"></el-table-column>
      <el-table-column label="月租">
        <template slot-scope="scope">
          {{ fmoney(scope.row.monthlyRentAmount / 100) }}
        </template>
      </el-table-column>
      <el-table-column label="本金">
        <template slot-scope="scope">
          {{ fmoney(scope.row.principal / 100) }}
        </template>
      </el-table-column>
      <el-table-column label="利息">
        <template slot-scope="scope">
          {{ fmoney(scope.row.interest / 100) }}
        </template>
      </el-table-column>
      <el-table-column label="费用">
        <template slot-scope="scope">
          {{ fmoney(scope.row.fee / 100) }}
        </template>
      </el-table-column>
      <el-table-column label="剩余本金">
        <template slot-scope="scope">
          {{ fmoney(scope.row.leftPrincipalAfterThisPlan / 100) }}
        </template>
      </el-table-column>
      <!-- <el-table-column label="当前应还金额">
        <template slot-scope="scope">
          {{fMoney(scope.row.currentPeriodNeedRepayAmount / 100)}}
        </template>
      </el-table-column> -->
      <el-table-column label="当前应还总金额">
        <template slot-scope="scope">
          <span class="redSign"> {{ fmoney(scope.row.currentPeriodNeedRepayAmount / 100) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="当前应还本金">
        <template slot-scope="scope">
          {{ fmoney(scope.row.remainPrincipal / 100) }}
        </template>
      </el-table-column>
      <el-table-column label="当前应还利息">
        <template slot-scope="scope">
          {{ fmoney(scope.row.remainInterest / 100) }}
        </template>
      </el-table-column>
      <el-table-column label="当前应还费用">
        <template slot-scope="scope">
          {{ fmoney(scope.row.remainFee / 100) }}
        </template>
      </el-table-column>
      <el-table-column label="当前应还逾期滞纳金">
        <template slot-scope="scope">
          <span class="redSign"> {{ fmoney(scope.row.remainOverduePenalty / 100) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="已还总金额">
        <template slot-scope="scope">
          {{ fmoney(scope.row.currentPeriodRepayAmount / 100) }}
        </template>
      </el-table-column>
      <el-table-column label="已还本金">
        <template slot-scope="scope">
          {{ fmoney(scope.row.repayPrincipal / 100) }}
        </template>
      </el-table-column>
      <el-table-column label="已还利息">
        <template slot-scope="scope">
          {{ fmoney(scope.row.repayInterest / 100) }}
        </template>
      </el-table-column>
      <el-table-column label="已还费用">
        <template slot-scope="scope">
          {{ fmoney(scope.row.repayFee / 100) }}
        </template>
      </el-table-column>
      <el-table-column label="已还逾期滞纳金">
        <template slot-scope="scope">
          {{ fmoney(scope.row.repayOverduePenalty / 100) }}
        </template>
      </el-table-column>
      <el-table-column label="当前资方"
                       prop="repPlanCapitalName"
                       min-width="140"></el-table-column>
      <el-table-column label="还款状态">
        <template slot-scope="scope">
          <div :class="+scope.row.overdueDays > 0 ? 'redSign' : ''">
            {{ dict.repayPlansStatus[scope.row.status] }}
          </div>
        </template>
      </el-table-column>
      <el-table-column label="逾期天数"
                       prop="overdueDays"
                       min-width="60">
        <template slot-scope="scope">
          <div :class="+scope.row.overdueDays > 0 ? 'redSign' : ''">
            {{ scope.row.overdueDays }}
          </div>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
import { fmoney } from '../../utils/constant'
import { dict } from '../../api/financialManage'
export default {
  props: ['repaymentList', 'currentCapitalName'],
  data () {
    return {
      fmoney: fmoney,
      dict,
    }
  },
  methods: {
    getRepaymentPlans () {
      this.$emit('listenGetRepaymentPlans')
    },
  },
}
</script>
<style lang="scss" scoped>
.tableTitle {
  button {
    margin-left: 8px;
  }
  .table-title-word {
    height: 32px;
    line-height: 32px;
  }
  i {
    font-style: normal;
    float: right;
    height: 33px;
    line-height: 33px;
  }
}
.redSign {
  color: red;
}
</style>
