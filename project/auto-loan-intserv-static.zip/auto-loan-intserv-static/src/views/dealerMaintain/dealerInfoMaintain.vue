<template>
  <div class="dealer-info-wrapper">
    <el-tabs v-model="status" @tab-click="handleTabClick">
      <el-tab-pane label="基本信息" name="0">
        <dealerBaseInfo ref="baseInfoPart"></dealerBaseInfo>
      </el-tab-pane>
      <el-tab-pane label="系统用户信息" name="1" :disabled="isShow">
        <systemUserInfo></systemUserInfo>
      </el-tab-pane>
      <el-tab-pane label="附件" name="2" :disabled="isShow">
        <attachment ref="attachment"></attachment>
      </el-tab-pane>
      <!--<el-tab-pane label="操作日志" name="3" :disabled="isShow"></el-tab-pane>-->
    </el-tabs>
  </div>
</template>

<script>
  // import {getImgMenuByArr} from 'api/upload.js'
  import dealerBaseInfo from './dealerMaintainBaseInfo'
  import systemUserInfo from './systemUserMaintainInfo.vue'
  import attachment from './attachmentMaintain.vue'
  export default {
    components: {
      dealerBaseInfo, systemUserInfo, attachment
    },
    data () {
      return {
        isShow: true,
        status: '0',
        selectData: [], // 所有字典数据
        bizLinesData: [], // 业务种类
        systemUserInfoData: [], // 系统用户数据
        dealerInfoForm: {} // 基板信息
      }
    },
    mounted () {
      if (this.$route.params.id !== 'null') {
        this.isShow = false
      } else {
        this.isShow = true
      }
    },
    watch: {
      $route: {
        handler: function (val, oldVal) {
          if (val.params.id !== 'null') {
            this.isShow = false
          } else {
            this.isShow = true
          }
        }
      }
    },
    methods: {
      // 页数跳转
      skipPage () {
        if (this.status === '2') {
          this.status = '0'
          return false
        }
        this.status = parseInt(this.status) + 1 + ''
      },
      // 表头点击事件
      handleTabClick () {
      }
    }
  }
</script>

<style lang="scss" scoped>
  .dealer-info-wrapper{
    .position{
      position: absolute;
      right: 110px;
      top: 5px;
      z-index: 20;
    }
    .position1 {
      right:20px;
    }
  }
</style>