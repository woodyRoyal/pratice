// // 本地路由
// import { lastRouterConst, constantRouterMap, asyncRouterMapTree } from 'src/router'
// 后端路由
import { lastRouterConst, constantRouterMap, asyncRouterMapObj } from 'src/router'

// 后端路由
function addRouterAttribute (menu) {
  if (!asyncRouterMapObj[menu.path]) {
    return menu
  }
  if (asyncRouterMapObj[menu.path].component) {
    menu.component = asyncRouterMapObj[menu.path].component
  }
  // 先取表里的名称
  if (!menu.name) {
    menu.name = asyncRouterMapObj[menu.path].name
  }
  if (asyncRouterMapObj[menu.path].icon) {
    menu.icon = asyncRouterMapObj[menu.path].icon
  }
  if (asyncRouterMapObj[menu.path].noDropdown) {
    menu.noDropdown = asyncRouterMapObj[menu.path].noDropdown
  }
  if (menu.children && menu.children.length > 0) {
    menu.children = menu.children.map(item => addRouterAttribute(item))
  }
  return menu
}

// 菜单树转换为菜单数组
function menuTreeToList (source, target, parentPath) {
  if (!source) {
    return target
  }
  let path = ''
  if (parentPath === '') {
    path = source.path
  } else if (source.path.startsWith('/')) {
    path = source.path
  } else {
    path = parentPath + '/' + source.path
  }

  target.push(path)
  // 递归处理子菜单
  if (source.children && source.children.length > 0) {
    source.children.map(item => menuTreeToList(item, target, path))
  }
  return target
}

let cacheMenuPath = window.localStorage.getItem('Alr-MenuPath')
const permission = {
  state: {
    routers: constantRouterMap, // 静态路由
    addRouters: [], // 可访问的路由表（左侧菜单信息）
    menuPathList: cacheMenuPath ? JSON.parse(cacheMenuPath) : [] // url 信息
  },

  mutations: {
    SET_ROUTERS: (state, routers) => {
      state.addRouters = routers // 存储可以访问的菜单信息
      state.routers = constantRouterMap.concat(routers).concat(lastRouterConst) // 合并匿名路由、菜单信息（左侧菜单路由）、静态路由（白名单）
      // 主要是将菜单信息组合起来，不在以嵌套形式，将父子路由信息组合，生成完整的和地址栏一样的url信息
      let menuPathList = []
      for (let j = 0, len = state.routers.length; j < len; j++) {
        menuTreeToList(state.routers[j], menuPathList, '')
      }
      state.menuPathList = menuPathList // 存储 url 信息
      window.localStorage.setItem('Alr-MenuPath', JSON.stringify(menuPathList))
    },
    CLEAR_ROUTERS: (state) => {
      state.routers = constantRouterMap
      state.addRouters = []
      state.menuPathList = []
    }
  },

  actions: {
    GenerateRoutes ({commit}, data) {
      return new Promise(resolve => {
        // 后端路由
        const accessedRouters = data.map(item => addRouterAttribute(item)) // 根据返回的菜单信息，生成可以访问的菜单信息
        commit('SET_ROUTERS', accessedRouters) // 保存可访问的菜单信息
        // // 本地路由
        // commit('SET_ROUTERS', asyncRouterMapTree)
        resolve()
      })
    },
    // 清空路由
    ClearRouters ({commit}) { commit('CLEAR_ROUTERS') }
  }
}

export default permission
