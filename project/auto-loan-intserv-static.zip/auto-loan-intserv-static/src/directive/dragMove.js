
  const vueDragMove = {}
  vueDragMove.install = (Vue, options = {}) => {
    Vue.directive('drag', {
      bind (el, binding) {
        el.onmousedown = (e) => {
          let clientH = document.documentElement.clientHeight
          let clientW = document.documentElement.clientWidth
          let elW = el.offsetWidth
          let elH = el.offsetHeight
          // let dialogTitle = document.querySelector('.change-history-dialog-title')
          /*// 点击位置临界值
          let clickPosYMin = el.offsetTop // 最小值
          let clickPosYMax = el.offsetTop + dialogTitle.offsetHeight // 最大值
          let clickPosXMin = el.offsetLeft
          let clickPosXMax = el.offsetLeft + dialogTitle.offsetWidth*/
          let clickPosX = e.clientX
          let clickPosY = e.clientY
          /* if ((clickPosX > clickPosXMin && clickPosX < clickPosXMax) && (clickPosY > clickPosYMin && clickPosY > clickPosYMax)) {
            // 鼠标变化
            dialogTitle.className = 'change-history-dialog-title move-sign'
          } */
          // 鼠标点击位置距离元素上左距离
          let disX = clickPosX - el.offsetLeft
          let disY = clickPosY - el.offsetTop
          document.onmousemove = (ev) => {
            let moveX = ev.clientX - disX
            let moveY = ev.clientY - disY
            if (moveX < 1) {
              moveX = 1
            } else if (moveX >= clientW - elW) {
              moveX = clientW - elW
            }
            if (moveY < 1) {
              moveY = 1
            } else if (moveY >= clientH - elH) {
              moveY = clientH - elH
            }
            el.style.left = moveX + 'px'
            el.style.top = moveY + 'px'
          }
          document.onmouseup = (e) => {
            document.onmousemove = document.onmouseup = null
          }
          return false
        }
      }
    })
  }
  export default vueDragMove
