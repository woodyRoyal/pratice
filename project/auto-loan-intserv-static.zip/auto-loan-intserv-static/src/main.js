// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import ElementUI from 'element-ui'
import { MessageBox } from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import NProgress from 'nprogress' // Progress 进度条
import 'nprogress/nprogress.css'// Progress 进度条 样式
import 'normalize.css/normalize.css'// normalize.css 样式格式化
import 'styles/index.scss' // 全局自定义的css样式
import * as filters from './filters' // 全局vue filter
import errLog from 'store/errLog'// error log组件
import VueClipboard from 'vue-clipboard2' // 复制到剪贴板
import Cookies from 'js-cookie'
import { getQueryString } from 'utils/index'
import vueDragMove from './directive/dragMove' // 查看修改历史记录的指令
import './styles/iconfont.css'

Vue.use(ElementUI)
Vue.use(vueDragMove)
Vue.use(VueClipboard)

// register global utility filters.
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})

// router judge
function hasRouter (routers, path) {
  if (path === '/') return true
  if (!routers) return true
  return routers.indexOf(path) >= 0
}

console.log('当前的环境是:', process.env.NODE_ENV)

// 从互金后台进入子系统，由于域名不相同，互金后台存的UC-Token和UC-Username获取不到，需要通过URL再获取并存到cookie中
let urlUsername = getQueryString('username')
let urlToken = getQueryString('token')
let ucToken = ''
let ucUsername = ''
// 如果路径上没有token和username（直接通过子系统登录页进入）
if (!urlToken || !urlUsername) {
  ucToken = Cookies.get('Alr-Token') // 前端自定义的token
  ucUsername = Cookies.get('Alr-Username') // 用户名
  console.log('ucToken: ' + ucToken + ', ucUsername: ' + ucUsername)
} else {
  ucUsername = urlUsername // 用户名
  ucToken = urlToken // 互进后台系统登录成功后的token
  store.dispatch('ResetMsg')
  // 从互金后台进入车贷运营管理系统，向cookie中存入用户名和token
  Cookies.set('Alr-Token', ucToken)
  Cookies.set('Alr-Username', ucUsername)
}

router.beforeEach((to, from, next) => {
  NProgress.start() // 开启Progress
  if (to.path === '/login') {
    next()
  } else {
    const {token, addRouters, menuList, menuPathList} = store.getters
    // 从vuex中判断是否有用户名和token（一开始没有）
    if (token) {
      // 判断当前用户是否已有可访问的路由表
      if (addRouters.length === 0) {
        // 生成可访问的路由表
        store.dispatch('GenerateRoutes', menuList).then(() => {
          router.addRoutes(store.getters.addRouters)
          store.getters.addRouters.length === 0 ? next() : next(to.path)
        })
      } else {
        // 没有动态改变权限的需求可直接next() 删除下方权限判断
        if (hasRouter(menuPathList, to.path)) {
          next()
        } else {
          // 详情 /detail/:id 匹配
          if (to.path.indexOf('/detail/') > -1) {
            next()
          } else if (to.path.indexOf('/dealer-info/') > -1) {
            next()
          } else if (to.path.indexOf('/fangkuanDetail/') > -1) {
            next()
          } else if (to.path.indexOf('/daihouDetail/') > -1) {
            next()
          } else if (to.path.indexOf('/daihouUploadDetail/') > -1) {
            next()
          } else if (to.path.indexOf('/dealer-maintain/') > -1) {
            next()
          } else if (to.path.indexOf('/product-detail/') > -1) {
            next()
          } else if (to.path.indexOf('/apply-progress-detail/') > -1) {
            next()
          } else if (to.path.indexOf('/repayment-write-off-check-detail/') > -1) {
            next()
          } else if (to.path.indexOf('/repayment-confirm-detail/') > -1) {
            next()
          } else if (to.path.indexOf('/repayment-history-detail/') > -1) {
            next()
          } else if (to.path.indexOf('/attached-company-detail/') > -1) {
            next()
          } else {
            next({path: '/home/index'})
          }
        }
      }
    } else {

      if (process.env.NODE_ENV !== 'development') {
        if (ucToken && ucUsername) {
          console.log('ucToken、ucUsername都存在')
        } else {
          console.log('路由跳转，不是开发环境，检测到ucToken、ucUsername其中一个或多个失效')
          MessageBox.alert('用户信息已过期, 请重新登录', '提示', {
            confirmButtonText: '确定',
            type: 'warning',
            callback: action => {
              window.open('about:blank', '_self').close()
            }
          })
          return false
        }
      }

      // 无token
      let user = {
        username: ucUsername,
        token: ucToken
      }
      store.dispatch('LoginByUsernameAndToken', {user}).then(res => {
        // 如果报错（没有token，或者其他错误）
        if (res) {
          MessageBox.alert(res + ', 请重新登录', '提示', {
            confirmButtonText: '确定',
            type: 'warning',
            callback: action => {
              // 登出并返回到登录页
              window.location.href = process.env.UCENTER_API + '#/login'
            }
          })
          return false
        } else {
          // 登录成功，跳入子系统
          next({
            path: '/home/index'
          })
        }
      }).catch(err => {
        console.log(err)
      })
    }
  }
  NProgress.done() // 在hash模式下 改变手动改变hash 重定向回来 不会触发afterEach 暂时hack方案 ps：history模式下无问题，可删除该行！
})

router.afterEach(() => {
  NProgress.done() // 结束Progress
})


// 生产环境错误日志
if (process.env === 'production') {
  Vue.config.errorHandler = function (err, vm) {
    console.log(err, window.location.href)
    errLog.pushLog({
      err,
      url: window.location.href,
      vm
    })
  }
}


new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
