import axios from 'axios'
import { Message, MessageBox } from 'element-ui'
import store from '../store'
import NProgress from 'nprogress' // Progress 进度条

const service = axios.create({
  baseURL: process.env.UCENTER_SERVER_API, // api的base_url
  timeout: 50000, // 指定请求超时的毫秒数(0 表示无超时时间)
  withCredentials: true, // 表示跨域请求时是否需要使用凭证 自动set-cookie
  headers: {'Content-Type': 'application/json;charset=UTF-8'}
})

// request拦截器
service.interceptors.request.use(config => {
  NProgress.start() // 开启进度条
  if (config.method === 'get') {
    config.params = {
      _t: Date.parse(new Date()),
      ...config.params
    }
  }
  return config
}, error => {
  // Do something with request error
  return Promise.reject(error)
})

// response拦截器
service.interceptors.response.use(
  response => {
    const data = response.data
    if (data) {
      const code = parseInt(data.respCode)
      if (code === -100) { // 未登录
        MessageBox.alert(data.respMsg + '（' + code + '）', '提示', {
          confirmButtonText: '重新登录',
          type: 'warning',
          callback: action => {
            // 登出并返回到登录页
            store.dispatch('FilterLogout').then(() => {
              window.location.href = process.env.UCENTER_API + '#/login'
            })
          }
        })
      } else if (code !== 1000) {
        Message({
          message: data.message + '（' + code + '）',
          type: 'error'
        })
      }
      // 关闭进度条
      NProgress.done()
      return response
    } else {
      // 关闭进度条
      NProgress.done()
      return response
    }
  },
  error => {
    if (error.response && error.response.status === 404) {
      Message({
        message: '网络连接异常',
        type: 'error'
      })
    } else {
      Message({
        message: '请求系统发生错误，' + error.message,
        type: 'error'
      })
    }
    // 关闭进度条
    NProgress.done()
    return Promise.reject(error)
  }
)

export default service
