import axios from 'axios'
import { Message, MessageBox } from 'element-ui'
import store from '../store'
import NProgress from 'nprogress' // Progress 进度条
// 创建axios实例
const service = axios.create({
  baseURL: process.env.BASE_API, // api的base_url
  timeout: 240000, // 指定请求超时的毫秒数(0 表示无超时时间)
  withCredentials: true, // 表示跨域请求时是否需要使用凭证 自动set-cookie
  headers: {'Content-Type': 'application/json;charset=UTF-8'},
})
// request拦截器
service.interceptors.request.use((config) => {
  NProgress.start()
  if (config.method === 'get') {
    config.params = {
      _t: Date.parse(new Date()),
      ...config.params,
    }
  }
  return config
}, (error) => Promise.reject(error))

// respone拦截器
service.interceptors.response.use(
  (response) => {
    const data = response.data
    if (data) {
      const code = data.respCode
      if (parseInt(code,0) === 1008) { // 未登录
        MessageBox.alert(data.respMsg + '（' + code + '）', '提示', {
          confirmButtonText: '重新登录',
          type: 'warning',
          callback: () => {
            // 登出并返回到空白页
            store.dispatch('FilterLogout').then(() => {
              window.open('about:blank', '_self').close()
            })
          },
        })
      } else if (code !== '1000' && code !== 'buyback_in_process' && code !== 'advance_settle_in_progress' && code !== 'POLLING_AFTER_WAIT') {
        // buyback_in_process 和 advance_settle_in_progress 为业务特殊code，无须提示
        Message({
          message: data.respMsg,
          type: 'error',
        })
      }
      // 关闭进度条
      NProgress.done()
      return response
    } else {
      // 关闭进度条
      NProgress.done()
      return response
    }
  },
  (error) => {
    if (error.response && error.response.status === 404) {
      Message({
        message: '网络连接异常',
        type: 'error',
      })
    } else {
      Message({
        message: '请求系统发生错误，' + error.message,
        type: 'error',
      })
    }
    // 关闭进度条
    NProgress.done()
    return Promise.reject(error)
  }
)

export default service
