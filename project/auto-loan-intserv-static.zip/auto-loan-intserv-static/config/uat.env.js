/*
 * 线上测试环境
 * 域名：http://t1-managerdaikuan.2345.com/
 * 不同域名时需写明
 * */
module.exports = {
  NODE_ENV: '"uat"',
  BASE_API: '"/autoloan-bus"',
  UCENTER_SERVER_API: '"/autoloan-bus/ucenter/"', // fetchUCenter base api
  FILEUPLOAD_URL: '"/autoloan-bus/fileStoreClient/uploadFile"', // 文件上传url地址
  FANGKUAN_WS_URL: '"/autoloan-bus/loan/loanStatistics/"', // 放款webSocket
  UCENTER_API: '"http://t1-managerdaikuan.2345.com/ucenter/"' // 互金后台 base api
}
