/* 本地测试环境 */
module.exports = {
  NODE_ENV: '"development"',
  BASE_API: '"http://t1-cdw.2345.com/autoloan-bus"', // D2
  UCENTER_SERVER_API: '"http://t1-cdw.2345.com/autoloan-bus/ucenter"', // fetchUCenter服务 base_api 获取验证码、独立系统登入使用
  FILEUPLOAD_URL: '"/autoloan-bus/fileStoreClient/uploadFile"', // 文件上传url地址,
  FANGKUAN_WS_URL: '"wss://t1-cdw.2345.com/autoloan-bus/loan/loanStatistics/"', // 放款webSocket
  UCENTER_API: '"http://t1-managerdaikuan.2345.com/ucenter/"' // 互金后台 base api
}
