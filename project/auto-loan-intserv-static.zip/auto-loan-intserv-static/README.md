# 2345 互金报表系统-前端工程 #
[线上地址](https://managerdaikuan.2345.com/bi-web/)

**注意：该项目目前使用element-ui@2.0.*版本, 最低兼容 Vue 2.3.*, 兼容IE9及以上浏览器

## 安装
```bash
    # 1、安装Git
    # 2、安装Node.js
    # 3、安装vue
    npm install vue-cli -g
    # 4、安装webpack
    npm install webpack -g
    # 5、安装依赖，在项目路径下执行
    npm install
    # 6、WebStorm 配置 js版本、启用ESLint代码校验
    File -> Settings -> Languages & Frameworks -> JavaScript ->
         JavaScript language version 选择 ECMAScript 6
    File -> Settings -> Languages & Frameworks -> JavaScript ->
         Code Quality Tools -> ESLint -> Enable
    .vue 文件如果没有ESLint错误提示，可能还需要安装WebStorm的ESLint插件
    # 7、本地运行项目
    npm run dev

    **注意：
    npm速度慢可用yarn替代 (npm install yarn -g)
    建议不要用cnpm 或者可以通过如下操作解决npm速度慢的问题
    npm install --registry=https://registry.npm.taobao.org

    如果安装依赖过程中出现node-scss安装失败，可能需要安装Microsoft Visual Studio，
    node-scss需要GCC编译环境，windows建议安装VS2013，Linux需要升级gcc至4.8以上，MacOS需要安装XCode**
```

## 发布
```bash
    # 发布测试环境
    npm run build:uat

    # 发布生产环境
    npm run build:pro
```

## 部署
```bash
    # Nginx 部署配置 同一域名下不同项目
    server {
        listen       8082;
        server_name  localhost;

        #charset koi8-r;

        #access_log  logs/host.access.log  main;

        location /bi-web/ {
            root   D:/test;  # 需指定到包含“bi-web”文件夹的目录 D:\workspace-web\test1\bi-web
            index  index.html;
            # try_files $uri /bi-web/index.html; # 当路由mode: 'hash' 不需要，'history' 时需要设置解决刷新问题
        }
    }
```
