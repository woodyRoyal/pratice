hyapp-cli 的工具类方法

## 本地测试

```
npm run build:dev
```

## 打包

```
npm run build
```

## 提示

- 每次文件有变动，必须打包，因为 package.json main 指向的是 dist/hyapp-utils.js
