import Vue from 'vue';
import Router from 'vue-router';
import Home from './views/Home.vue';

Vue.use(Router);

const ocRouter = [];
const routerMap = [{
		path: 'toast',
		name: 'Toast'
	},
	{
		path: 'dialog',
		name: 'Dialog'
	},
	{
		path: 'loading',
		name: 'Loading'
	},
	{
		path: 'popup',
		name: 'Popup'
	},
	{
		path: 'button',
		name: 'Button'
	},
	{
		path: 'overlay',
		name: 'Overlay'
	},
	{
		path: 'icon',
		name: 'Icon'
	},
	{
		path: 'tabs',
		name: 'Tabs'
	},
	{
		path: 'scroll',
		name: 'Scroll'
	},
	{
		path: 'cell',
		name: 'Cell'
	},
	{
		path: 'picker',
		name: 'Picker'
	},
	{
		path: 'lunarPicker',
		name: 'LunarPicker'
	},
	{
		path: 'addressPicker',
		name: 'AddressPicker'
	},
	{
		path: 'datePicker',
		name: 'DatePicker'
	},
	{
		path: 'noticeBar',
		name: 'NoticeBar'
	},
	{
		path: 'input',
		name: 'Input'
	},
	{
		path: 'radio',
		name: 'Radio'
	},
	{
		path: 'checkbox',
		name: 'Checkbox'
	},
	{
		path: 'noticeBar',
		name: 'NoticeBar'
	},
	{
		path: 'collapse',
		name: 'Collapse'
	},
	{
		path: 'switch',
		name: 'Switch'
	},
	{
		path: 'scrollNumber',
		name: 'scrollNumber'
	}
];

routerMap.forEach((it) => {
	ocRouter.push({
		path: `/design/${it.path}`,
		name: it.name,
		component: () => import(`./demo/${it.path}.vue`),
		meta: {
			title: it.name,
			keepAlive: true
		}
	});
});

export default new Router({
	routes: [{
			path: '/',
			name: 'home',
			component: Home
		},
		{
			path: '/design',
			name: 'design',
			component: () => import('./views/Design.vue'),
			redirect: '/design/button',
			children: ocRouter
		},
		// ...ocRouter
	],
	// mode: 'history'
});