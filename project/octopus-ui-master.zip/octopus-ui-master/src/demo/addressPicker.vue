<template>
    <div class="page">
        <h1>地址选择器</h1>
        <section class="demo">
            <h2>地址选择器 - 传统</h2>
            <div class="btn" @click="display1 = true">选择地址</div>
            <div class="ret">当前选择的地址：{{ address1 }}</div>
            <oc-address-picker
                v-show="display1"
                :init-address="['宁夏', '银川', '西夏区']"
                :is-single-column="true"
                confirm-btn-text="选择"
                title="请选择地址"
                @cancel="display1 = false"
                @confirm="onConfirm1"
            />
        </section>
        <section class="demo">
            <h2>地址选择器 - 简易插槽自定义</h2>
            <div class="btn" @click="display2 = true">选择地址</div>
            <div class="ret">当前选择的地址：{{ address2 }}</div>
            <oc-address-picker
                v-show="display2"
                :init-address="['福建', '宁德', '屏南县']"
                :show-toolbar="false"
                @cancel="display2 = false"
                @change="onChange2"
                @confirm="onConfirm2"
            >
                <template #columns-top>
                    <div class="slot-columns-top">选择日期</div>
                </template>
                <template #columns-bottom>
                    <div class="slot-columns-bottom">
                        <div class="slot-btn" @click="display2 = false">取消</div>
                        <div class="slot-btn" @click="onConfirm2()">确定</div>
                    </div>
                </template>
            </oc-address-picker>
        </section>
    </div>

</template>

<script>
    export default {
        name: 'AddressPickerDemo',
        data() {
            return {
                address1: null,
                display1: false,
                address2: null,
                display2: false
            };
        },
        methods: {
            onConfirm1(data) {
                this.address1 = data.map(item => item.val).join(' - ');
                this.display1 = false;
            },
            onChange2(data) {
                this._address2 = data.map(item => item.val).join(' - ');
            },
            onConfirm2(data) {
                if (data) {
                    this.address2 = data.map(item => item.val).join(' - ');
                } else {
                    this.address2 = this._address2;
                }
                this.display2 = false;
            }
        }
    };
</script>

<style lang="scss" scoped>
    .page {
        margin: 10px;
    }

    .demo {
        margin-top: 15px;
        margin-left: 5px;
    }

    h1 {
        margin-bottom: 12px;
        font-size: 20px;
        color: #ff5040;
    }

    h2 {
        font-size: 18px;
        color: #ff00ff;
    }

    .btn {
        position: relative;
        display: inline-block;
        box-sizing: border-box;
        margin-top: 10px;
        padding: 0 5px;
        height: 30px;
        text-align: center;
        border-radius: 4px;
        line-height: 30px;
        font-size: 16px;
        color: #fff;
        background-color: #1989fa;
    }

    .ret {
        margin-top: 10px;
    }

    .slot-columns-top {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 50px;
        border-bottom: 1px dashed #FFE8E8E8;
        font-size: 24px;
        color: orange;
    }

    .slot-columns-bottom {
        display: flex;
        height: 50px;
        border-top: 1px dashed #FFE8E8E8;
        .slot-btn {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-grow: 1;
            color: orange;
            &:first-of-type {
                border-right: 1px dashed #FFE8E8E8;
            }
        }
    }
</style>