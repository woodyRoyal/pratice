<template>
    <div>
        <section>
            <h1>单元格</h1>
            <div style="margin: 0 -16px; padding-bottom: 16px; background: #f5f5f5;">
                <oc-cell-group border>
                    <oc-cell icon="toast_success" title="1123" url="http://www.2345.com"></oc-cell>
                    <oc-cell icon="toast_success" title="1123" desc="44566"></oc-cell>
                </oc-cell-group>

                <oc-cell-group>
                    <oc-cell title="1123" to="dialog"></oc-cell>
                    <oc-cell title="1123" desc="44566"></oc-cell>
                </oc-cell-group>

                <oc-cell-group>
                    <oc-cell>
                        <template slot="sub-title">12355</template>
                        <input type="text">
                    </oc-cell>
                    <oc-cell>
                        <input type="text">
                    </oc-cell>
                </oc-cell-group>

                <div style="display: flex; margin-bottom: 10px;">
                    <oc-cell-group border>
                        <oc-cell><input type="text" value="1111"></oc-cell>
                    </oc-cell-group>
                    <span>
                        12231151
                    </span>
                </div>
                

                <oc-cell-group>
                    <oc-cell icon="toast_success" title="1123" subTitle="2345" desc="44566">
                        <oc-button slot="desc" type="warning" size="small">slot内容</oc-button>
                    </oc-cell>
                    <oc-cell icon="toast_success" title="1123" url="http://www.2345.com" subTitle="2345" desc="44566"></oc-cell>
                    <oc-cell icon="toast_success" title="1123" subTitle="2345" desc="44566">
                        <oc-icon slot="desc" name="check"></oc-icon>
                    </oc-cell>
                    <oc-cell icon="toast_success" title="1123" subTitle="2345" desc="44566"></oc-cell>
                </oc-cell-group>
            </div>
        </section>
    </div>
</template>

<script>
export default {
    name: 'DemoCell',
    data() {
        return {};
    },
    // mounted() {},
    methods: {}
};
</script>

<style lang="scss">
</style>
