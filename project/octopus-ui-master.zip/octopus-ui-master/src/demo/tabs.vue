<template>
    <div>
        <section>
            <h1>基础用法</h1>
            <oc-tabs @tab-switch="tabSwitch">
                <oc-tab-panel
                    v-for="(it, idx) in editableTabs"
                    :key="it.title"
                    :title="it.title"
                    :icon="it.icon"
                    :disabled="it.disabled"
                    >
                    {{ it.title }} 、 {{ idx + 1 }}
                </oc-tab-panel>
            </oc-tabs>
        </section>

        <section>
            <h1>带icon</h1>
            <oc-tabs @tab-switch="tabSwitch">
                <oc-tab-panel
                    v-for="(it, idx) in editableTabs2"
                    :key="it.title"
                    :title="it.title"
                    :icon="it.icon"
                    :disabled="it.disabled"
                    >
                    {{ it.title }} 、 {{ idx + 1 }}
                </oc-tab-panel>
            </oc-tabs>
        </section>
        <section>
            <h1>禁用</h1>
            <oc-tabs @tab-switch="tabSwitch">
                <oc-tab-panel
                    v-for="(it, idx) in editableTabs3"
                    :key="it.title"
                    :title="it.title"
                    :icon="it.icon"
                    :disabled="it.disabled"
                    >
                    {{ it.title }} 、 {{ idx + 1 }}
                </oc-tab-panel>
            </oc-tabs>
        </section>
        <section>
            <h1>链接</h1>
            <oc-tabs @tab-switch="tabSwitch">
                <oc-tab-panel
                    v-for="(it, idx) in editableTabs4"
                    :key="it.title"
                    :title="it.title"
                    :icon="it.icon"
                    :href="it.href"
                    :disabled="it.disabled"
                    >
                    {{ it.title }} 、 {{ idx + 1 }}
                </oc-tab-panel>
            </oc-tabs>
        </section>
        <section>
            <h1>滚动</h1>
            <oc-tabs @tab-switch="tabSwitch">
                <oc-tab-panel
                    v-for="(it, idx) in editableTabs5"
                    :key="it.title"
                    :title="it.title"
                    :icon="it.icon"
                    :disabled="it.disabled"
                    >
                    {{ it.title }} 、 {{ idx + 1 }}
                </oc-tab-panel>
            </oc-tabs>
        </section>
    </div>
</template>

<script>
export default {
    name: 'DemoTab',
    data() {
        return {
            editableTabs: [
                {
                    title: '标签1'
                },
                {
                    title: '标签2'
                },
                {
                    title: '标签3'
                },
                {
                    title: '标签4'
                }
            ],
            editableTabs2: [
                {
                    title: '标签1',
                    icon: 'check'
                },
                {
                    title: '标签2',
                    icon: 'check'
                }
            ],
            editableTabs3: [
                {
                    title: '标签1'
                },
                {
                    title: '标签2',
                    disabled: true
                },
                {
                    title: '标签3'
                }
            ],
            editableTabs4: [
                {
                    title: '标签1'
                },
                {
                    title: '标签2',
                    href: 'https://www.baidu.com'
                },
                {
                    title: '标签3'
                }
            ],
            editableTabs5: [
                {
                    title: '标签1'
                },
                {
                    title: '标签2'
                },
                {
                    title: '标签3'
                },
                {
                    title: '标签4'
                },
                {
                    title: '标签5'
                },
                {
                    title: '标签6'
                }
            ],
        };
    },
    // mounted() {},
    methods: {
        tabSwitch(index, event, disabled) {
            console.log(index + '--' + event.target + '--' + disabled);
        }
    }
};
</script>

<style lang="scss">
</style>
