<template>
    <div class="page">
        <h1>单选框</h1>
        <section class="demo">
            <h2>单选框 - 常规风格</h2>
            <oc-radio-group v-model="model1">
                <ul>
                    <li>
                        <oc-radio label="A">选项A</oc-radio>
                    </li>
                    <li>
                        <oc-radio label="B">选项B</oc-radio>
                    </li>
                    <li>
                        <oc-radio label="C">选项C</oc-radio>
                    </li>
                    <li>
                        <oc-radio label="D" disabled>选项D</oc-radio>
                    </li>
                </ul>
            </oc-radio-group>
            <div class="ret">已选择的选项：{{ model1 }}</div>
        </section>

        <section class="demo">
            <h2>单选框 - 常规风格内容居左</h2>
            <oc-radio-group v-model="model2">
                <ul>
                    <li>
                        <oc-radio label="A" label-position="left">选项A</oc-radio>
                    </li>
                    <li>
                        <oc-radio label="B" label-position="left">选项B</oc-radio>
                    </li>
                    <li>
                        <oc-radio label="C" label-position="left">选项C</oc-radio>
                    </li>
                </ul>
            </oc-radio-group>
            <div class="ret">已选择的选项：{{ model2 }}</div>
        </section>

        <section class="demo">
            <h2>单选框 - 插槽简易自定义</h2>
            <oc-radio-group v-model="model3">
                <ul>
                    <li>
                        <oc-radio label="A" label-position="left">
                            <template #icon="{ checked }">
                                <div class="slot-icon">{{ checked ? '★' : '☆' }}</div>
                            </template>
                            <template #default="{ checked }">
                                <div class="slot-text">A-{{ checked ? '已勾选' : '未勾选' }}</div>
                            </template>
                        </oc-radio>
                    </li>
                    <li>
                        <oc-radio label="B" label-position="left">
                            <template #icon="{ checked }">
                                <div class="slot-icon">{{ checked ? '★' : '☆' }}</div>
                            </template>
                            <template #default="{ checked }">
                                <div class="slot-text">B-{{ checked ? '已勾选' : '未勾选' }}</div>
                            </template>
                        </oc-radio>
                    </li>
                    <li>
                        <oc-radio label="C" label-position="left">
                            <template #icon="{ checked }">
                                <div class="slot-icon">{{ checked ? '★' : '☆' }}</div>
                            </template>
                            <template #default="{ checked }">
                                <div class="slot-text">C-{{ checked ? '已勾选' : '未勾选' }}</div>
                            </template>
                        </oc-radio>
                    </li>
                </ul>
            </oc-radio-group>
            <div class="ret">已选择的选项：{{ model3 }}</div>
        </section>
        <section class="demo">
            <h2>单选框 - 自定义样式</h2>
            <oc-radio-group
                v-model="model4" class="cus-radio-group">
                <oc-radio label="A">
                    <template #icon="{ checked, disabled }">
                        <div
                            :class="['charge-item', { 'charge-choose': checked, 'is-disabled': disabled }]">
                            <div class="charge-amount">30元</div>
                            <div class="charge-money">售价30.00元</div>
                            <div class="charge-gold">+10000金币</div>
                        </div>
                    </template>
                </oc-radio>
                <oc-radio label="B">
                    <template #icon="{ checked, disabled }">
                        <div
                            :class="['charge-item', { 'charge-choose': checked, 'is-disabled': disabled }]">
                            <div class="charge-amount">50元</div>
                            <div class="charge-money">售价50.00元</div>
                            <div class="charge-gold">+20000金币</div>
                        </div>
                    </template>
                </oc-radio>
                <oc-radio label="C" disabled>
                    <template #icon="{ checked, disabled }">
                        <div
                            :class="['charge-item', { 'charge-choose': checked, 'is-disabled': disabled }]">
                            <div class="charge-amount">100元</div>
                            <div class="charge-money">售价100.00元</div>
                            <div class="charge-gold">+30000金币</div>
                        </div>
                    </template>
                </oc-radio>
            </oc-radio-group>
            <div class="ret">已选择的选项：{{ model4 }}</div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'RadioDemo',
        data() {
            return {
                model1: 'D',
                model2: 'C',
                model3: null,
                model4: null
            };
        }
    };
</script>

<style lang="scss" scoped>
    .page {
        margin: 10px;
    }

    .demo {
        margin-top: 15px;
        margin-left: 5px;
    }

    h1 {
        margin-bottom: 12px;
        font-size: 20px;
        color: #ff5040;
    }

    h2 {
        font-size: 18px;
        color: #ff00ff;
    }

    .ret {
        margin-top: 10px;
        color: 14px;
    }

    ul {
        margin-left: 5px;
        width: 150px;
    }

    li {
        margin-top: 5px;
    }

    .slot-icon {
        font-size: 24px;
        color: #aaa;
    }

    .slot-text {
        text-align: left;
        color: 14px;
    }
    .cus-radio-group {
        display: flex;
    }
    .charge-item {
        position: relative;
        display: flex;
        padding: 10px 10px;
        flex-direction: column;
        justify-content: center;
        text-align: center;
        border: 2px solid #e6e6e6;
        border-radius: 5px;
        .charge-amount {
            color: #333;
            font-size: 18PX;
        }
        .charge-money {
            font-size: 12PX;
            color: #888;
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
        }
        .charge-gold {
            font-size: 12PX;
            color: #ff5040;
        }
        &.is-disabled {
            background: #eee;
        }
        &.charge-choose {
            &::before {
                content: '';
                width: 40px;
                height: 40px;
                position: absolute;
                background-size: 100% 100%;
                top: 0;
                left: 0;
                color: #fff;
            }
            border: 2px solid #ff5040;
        }
    }
</style>