<template>
    <div class="page">
        <section class="demo">
            <h2>农历选择器 - 定制主题标题色</h2>
            <div class="btn" @click="display1 = true">选择农历日期</div>
            <oc-lunar-picker
                v-show="display1"
                :line-count="5"
                :topic-color="'pink'"
                @cancel="display1 = false"
                @confirm="onConfirm1"
            />
            <p class="ret">农历：{{ lunarMessage1 }}</p>
            <p class="ret">公历：{{ solarMessage1 }}</p>
        </section>
        <section class="demo">
            <h2>农历选择器 - 定制行数，初始日期，起、终年</h2>
            <div class="btn" @click="display2 = true">选择农历日期</div>
            <oc-lunar-picker
                v-show="display2"
                :line-count="7"
                :start-year="1990"
                :init-date="[1991, 5, 4, 2]"
                :end-year="2000"
                @cancel="display2 = false"
                @confirm="onConfirm2"
            />
            <p class="ret">农历：{{ lunarMessage2 }}</p>
            <p class="ret">公历：{{ solarMessage2 }}</p>
        </section>
    </div>

</template>

<script>
    export default {
        name: 'LunarPickerDemo',
        data() {
            return {
                lunarMessage1: null,
                solarMessage1: null,
                lunarMessage2: null,
                solarMessage2: null,
                display1: false,
                display2: false
            };
        },
        methods: {
            onCancel() {
                this.display = false;
            },
            onConfirm1({ lunar, solar }) {
                this.lunarMessage1 = lunar.reduce((a, b) => `${a} ${b.text}`, '');
                this.solarMessage1 = solar.reduce((a, b) => `${a} ${b.text}`, '');
                this.display1 = false;
            },
            onConfirm2({ lunar, solar }) {
                this.lunarMessage2 = lunar.reduce((a, b) => `${a} ${b.text}`, '');
                this.solarMessage2 = solar.reduce((a, b) => `${a} ${b.text}`, '');
                this.display2 = false;
            }
        }
    };
</script>

<style lang="scss" scoped>
    .page {
        margin: 10px;
    }

    .demo {
        margin-top: 15px;
        margin-left: 5px;
    }

    h1 {
        margin-bottom: 12px;
        font-size: 20px;
        color: #ff5040;
    }

    h2 {
        font-size: 18px;
        color: #ff00ff;
    }

    .ret {
        margin-top: 10px;
        color: 14px;
    }

    .btn {
        position: relative;
        display: inline-block;
        box-sizing: border-box;
        margin-top: 10px;
        padding: 0 5px;
        height: 30px;
        text-align: center;
        border-radius: 4px;
        line-height: 30px;
        font-size: 16px;
        color: #fff;
        background-color: #1989fa;
    }
</style>