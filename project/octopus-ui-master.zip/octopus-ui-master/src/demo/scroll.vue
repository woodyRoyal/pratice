<template>
    <div>
        <oc-scroll direction="y" style="height: 100px;" :data="data1">
            <template #default="{data}">
                <p>{{ data }}</p>
            </template>
        </oc-scroll>
        <oc-scroll
            direction="y"
            :listenScroll="true"
            :pullup="true"
            :pulldown="true"
            :options="{
                stop: 60,
                threshold: 90,
                startX: 0,
                pullDownRefresh: true,
                pullUpLoad: true
            }"
            @scroll="scroll"
            @pulling-up="pullingUp"
            @pulling-down="pullingDown"
            style="height: 200px;"
            :data="data"
        >
            <template #default="{data}">
                <ul>
                    <li v-for="(it, idx) in data" :key="idx">{{ it }}</li>
                </ul>
            </template>
        </oc-scroll>

        <oc-scroll
            direction="x"
            :listenScroll="true"
            @scroll="scroll"
            :options="{
                snap: {
                    loop: false,
                    threshold: 0.1,
                    stepX: 110,
                    stepY: 0,
                    easing: {
                        style: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
                        fn: function(t) {
                            return t * (2 - t);
                        }
                    }
                }
            }"
            style="height: 200px; margin-top: 20px;"
            :data="data2"
        >
            <template #default="{data}">
                <ul class="group" ref="group">
                    <li v-for="(it, idx) in data" :key="idx">第{{idx + 1}}个方块</li>
                </ul>
            </template>
        </oc-scroll>
    </div>
</template>

<script>
export default {
    name: 'DemoScroll',
    data() {
        return {
            data1:
                '一段很长很长的文案一段很长很长的文案一段一段很长很长的文案一段很长很长的文案一段一段很长很长的文案一段很长很长的文案一段一段很长很长的文案一段很长很长的文案一段一段很长很长的文案一段很长很长的文案一段一段很长很长的文案一段很长很长的文案一段一段很长很长的文案一段很长很长的文案一段一段很长很长的文案一段很长很长的文案一段一段很长很长的文案一段很长很长的文案一段',
            data: [1, 2, 3, 4, 5, 6, 7, 8, 9],
            data2: [1, 2, 3, 4, 5, 6, 7, 8, 9]
        };
    },
    mounted() {
        const el = this.$refs.group;
        const li = el.querySelectorAll('li');
        console.log(li[0].offsetWidth, li.length);
        const liWidth = li[0].offsetWidth;
        this.$refs.group.style.width = (liWidth + 10) * (li.length - 1) + liWidth + 'px';
    },
    methods: {
        scroll() {
            console.log('滚动');
        },
        getData() {
            return new Promise((resolve) => {
                setTimeout(() => {
                    resolve(
                        [9, 8, 7, 6, 5, 4, 3, 2, 1].sort(() => {
                            return Math.random() > 0.5 ? -1 : 1;
                        })
                    );
                }, 2000);
            });
        },
        async pullingUp(ctx) {
            this.data = this.data.concat(await this.getData());
            ctx.finishPullUp();
            console.log('上拉加载完成');
        },
        async pullingDown(ctx) {
            this.data = await this.getData();
            ctx.finishPullDown();
            console.log('数据更新完成，停止下拉刷新');
        }
    },
    components: {}
};
</script>

<style lang="scss" scoped>
li {
    height: 40px;
    line-height: 40px;
    // @include thinLine(red, 0, 0, 1, 0);
    &:last-child {
        border-bottom: none;
    }
}
.group {
    // display: flex;
    // justify-content: space-between;
    // align-items: center;
    // flex-wrap: nowrap;
    // width: 810px;
    // height: 100px;
    // width: 1000px;
    white-space: nowrap;
    li {
        // position: absolute;
        // flex: 1 0 30%;
        display: inline-block;
        width: 100px;
        height: 60px;
        vertical-align: middle;
        border: 1px solid red;
        font-size: 12px;
        margin-right: 10px;
        &:last-child {
            margin-right: 0;
        }
    }
}
</style>
