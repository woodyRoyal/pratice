<template>
    <div class="test-scroll">
        <section>
            <h1>函数调用</h1>
            <oc-button type="primary" @click="showDialog1">提示弹窗</oc-button>
            <oc-button type="primary" @click="showDialog2">确认弹窗</oc-button>
            <oc-button type="primary" @click="showDialog3">自定义内容弹窗</oc-button>
            <oc-button type="primary" @click="showDialog4">自定UI弹窗-动态组件</oc-button>
            <oc-button type="warning" @click="showDialog5">自定UI弹窗2-锁定背景</oc-button>
            <oc-button type="warning" @click="showDialog6">同引入InnerC，内容更新</oc-button>
        </section>
        <section>
            <h1>组件调用</h1>
            <oc-button type="primary" @click="showTpl">组件调用</oc-button>
            <!-- <component :is="dynamicCompnent"></component> -->
            <!-- <inner-a></inner-a> -->
            <!-- <inner-a></inner-a>
            <inner-b></inner-b>
            <inner-c></inner-c> -->
        </section>
        <oc-dialog
            :visible.sync="visible"
            type="confirm"
            title="标题"
            content="2385"
            @confirm="confirmCb"
            @cancel="cancelCb"
            @show="showCb"
            @hide="hideCb"
        >
            <span slot="title"> | slot标题</span>
            <div style="font-size: 12px;">这是一行辅助文字这是一行辅助文字</div>
            <oc-button type="warning" size="small">普通按钮组件</oc-button>
        </oc-dialog>


        <!-- <div>
            <div class="tupian"></div>
            <h1><strong>{{ this.coin }}</strong><span>金币</span></h1>
            <p>明日签到可领<em>{{ nextCoin }}金币</em></p>
            <oc-button type="danger" block radius="99em" @click="closeDialog">我知道了</oc-button>
        </div> -->
    </div>
</template>

<script>
import InnerA from '@/components/InnerA';
import InnerB from '@/components/InnerB';
import InnerC from '@/components/InnerC';

const nameArr = [InnerA, InnerB, InnerC];

export default {
    name: 'DemoDialog',
    // components: {
    //     InnerC
    // },
    data() {
        return {
            items: 10,
            visible: false,
            coin: 500,
            nextCoin: 20,
            imgSrc: 'http://iph.href.lu/2000x1000',
            eh: 2
        };
    },
    computed: {
        dynamicCompnent () {
            return nameArr[this.eh];
        }
    },
    mounted() {
        setInterval(() => {
            this.eh = Math.floor((Math.random() * nameArr.length));
        }, 3000);
    },
    methods: {
        showCb() {
            console.log('开启');
        },
        hideCb() {
            console.log('注销');
        },
        confirmCb() {
            console.log('确定');
        },
        cancelCb() {
            console.log('取消');
        },
        showTpl() {
            this.visible = true;
        },
        showDialog1() {
            this.$OcDialog.alert({
                title: 'alert弹窗',
                content: '按钮可以设置成高亮',
                confirmTextLight: true,
                onConfirm() {
                    console.log('确定');
                },
                onShow() {
                    console.log('开启');
                },
                onHide() {
                    console.log('注销');
                }
            });
        },
        showDialog2() {
            this.$OcDialog.confirm({
                title: 'alert弹窗',
                content: '按钮高亮颜色设置，一般多行文字才可能设置居左',
                contentAlign: 'left',
                align: 'bottom',
                maskOpacity: 70,
                confirmTextLight: 'orange',
                onConfirm() {
                    console.log('确定');
                },
                onCancel() {
                    console.log('取消');
                },
                onShow() {
                    console.log('开启');
                },
                onHide() {
                    console.log('注销');
                }
            });
        },
        showDialog3() {
            this.$OcDialog.confirm({
                title: 'confirm弹层',
                content: (h) => {
                    return h('div', null, [
                        h('img', {
                            domProps: {
                                src: this.imgSrc
                            }
                        })
                    ]);
                },
                onConfirm() {
                    console.log('确定');
                },
                onCancel() {
                    console.log('取消');
                },
                onShow() {
                    console.log('开启');
                },
                onHide() {
                    console.log('注销');
                }
            });
        },
        showDialog4() {
            const d = this.$OcDialog({
                content: (h) => {
                    return h(this.dynamicCompnent, {
                        props: {
                            coin: this.coin,
                            nextCoin: this.nextCoin
                        },
                        on: {
                            closeDialog () {
                                d.hide();
                            }
                        }
                    });
                },
                canCloseByMask: true,
                onMask() {
                    console.log('背景');
                },
                onClose() {
                    console.log('关闭');
                },
                onShow() {
                    console.log('开启');
                },
                onHide() {
                    console.log('注销');
                }
            });
        },
        showDialog5() {
            window.d = this.$OcDialog({
                mainTransitionName: 'hehe',
                mainTransitionType: 'transition',
                closeIconName: 'cross-circle-light',
                content: (h) => {
                    return h(InnerC, {
                        props: {
                            coin: 6090,
                            nextCoin: 700
                        },
                        on: {
                            closeDialog: this.closeDialog
                        }
                    });
                },
                onShow() {
                    console.log('开始');
                },
                onClose() {
                    console.log('X关闭');
                },
                onHide() {
                    console.log('注销');
                }
            });
        },
        showDialog6() {
            window.d2 = this.$OcDialog({
                mainTransitionName: 'hehe',
                mainTransitionType: 'transition',
                closeIconName: 'cross-circle-light',
                content: (h) => {
                    return h(InnerC, {
                        props: {
                            coin: this.coin,
                            nextCoin: this.nextCoin
                        },
                        on: {
                            closeDialog() {
                                window.d2.hide();
                            }
                        }
                    });
                },
                onShow() {
                    console.log('开始');
                },
                onClose() {
                    console.log('X关闭');
                },
                onHide() {
                    console.log('注销');
                }
            });
        },
        closeDialog() {
            window.d.hide();
        }
    }
};
</script>

<style lang="scss">
.test-scroll {
    height: 200vh;
}
.ctr {
    p {
        margin-bottom: 15px;
        text-align: left;
    }
}

.abc {
    .oc-dialog {
        &-custom {
            width: 75vw;
        }
    }
}

// .hehe-enter-active {
//     // transition: all 0.5s cubic-bezier(0.05, 1, 1, 1.19);
//     animation-duration: 0.6s;
//     animation-name: bounceIn;
//     &::after {
//         // animation: Rotate2 linear 800ms 400ms infinite;
//         opacity: 0;
//     }
// }
// .hehe-leave-active {
//     animation-duration: 0.4s;
//     animation-name: bounceOut;
//     // animation-direction: alternate;
//     &::after {
//         opacity: 0;
//     }
// }

// .hehe-enter-active, .hehe-leave-active {
//   transition: opacity .5s;
// }
// .hehe-enter, .hehe-leave-to{
//   opacity: 0;
// }
// @keyframes bounceIn {
//     from,
//     20%,
//     40%,
//     60%,
//     80%,
//     to {
//         animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
//     }

//     0% {
//         opacity: 0;
//         transform: scale3d(0.3, 0.3, 0.3);
//     }

//     20% {
//         transform: scale3d(1.1, 1.1, 1.1);
//     }

//     40% {
//         transform: scale3d(0.9, 0.9, 0.9);
//     }

//     60% {
//         opacity: 1;
//         transform: scale3d(1.03, 1.03, 1.03);
//     }

//     80% {
//         transform: scale3d(0.97, 0.97, 0.97);
//     }

//     to {
//         opacity: 1;
//         transform: scale3d(1, 1, 1);
//     }
// }

// @keyframes bounceOut {
//     20% {
//         transform: scale3d(0.9, 0.9, 0.9);
//     }

//     50%,
//     55% {
//         opacity: 1;
//         transform: scale3d(1.1, 1.1, 1.1);
//     }

//     to {
//         opacity: 0;
//         transform: scale3d(0.3, 0.3, 0.3);
//     }
// }
@keyframes Rotate2 {
    // from {
    //     opacity: 1;
    // }
    to {
        transform: rotateZ(360deg);
    }
}
</style>
