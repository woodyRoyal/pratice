<template>
    <div class="page">
        <h1>开关</h1>
        <section class="demo">
            <h2>开关--默认</h2>
            <oc-switch v-model="switchValue1" @onChange="switchChange"></oc-switch>
            <div class="ret">开关状态：{{ switchValue1 }}</div>
        </section>
        <section class="demo">
            <h2>开关--禁用</h2>
            <oc-switch v-model="switchValue1" :disabled="true"></oc-switch>
            <oc-switch 
                v-model="switchValue1"
                activeColor="#409eff"
                inactiveColor="#dcdfe6"
                :disabled="true"
            ></oc-switch>
            <oc-switch 
                v-model="switchValue1"
                activeColor="#13ce66"
                inactiveColor="#ff4949"
                :disabled="true"
            ></oc-switch>
            <oc-switch 
                v-model="switchValue1"
                activeColor="#2b88e3"
                inactiveColor="#f5f5f5"
                :disabled="true"
            ></oc-switch>
            <div class="ret">开关状态：{{ switchValue1 }}</div>
        </section>
        <section class="demo">
            <h2>开关--修改颜色（支持渐变色）</h2>
            <oc-switch 
                v-model="switchValue2"
                activeColor="#409eff"
                inactiveColor="#dcdfe6"
            ></oc-switch>
            <oc-switch 
                v-model="switchValue2"
                activeColor="#13ce66"
                inactiveColor="#ff4949"
            ></oc-switch>
            <oc-switch 
                v-model="switchValue2"
                activeColor="#2b88e3"
                inactiveColor="#f5f5f5"
            ></oc-switch>
            <oc-switch
                v-model="switchValue2"
                activeColor="linear-gradient(to left, #ff6c49 0%, #ff9a3d 100%)"
                inactiveColor="linear-gradient(180deg, #ffe666, #fc3)"
            ></oc-switch>
            <div class="ret">开关状态：{{ switchValue2 }}</div>
        </section>
        <section class="demo">
            <h2>开关--修改状态默认值</h2>
            <oc-switch 
                v-model="switchValue3"
                activeValue="open"
                inactiveValue="close"
            ></oc-switch>
            <div class="ret">开关状态：{{ switchValue3 }}</div>
        </section>
        <section class="demo">
            <h2>开关--改变宽度</h2>
            <oc-switch v-model="switchValue4" activeValue="a" :width="40"></oc-switch>
            <oc-switch v-model="switchValue4" activeValue="a" :width="54"></oc-switch>
            <div class="ret">开关状态：{{ switchValue4 }}</div>
        </section>
        <section class="demo">
            <h2>开关--prevent default</h2>
            <oc-switch v-model="switchValue5" :preventDefault="true" @onClick="switchClick"></oc-switch>
            <div class="ret">开关状态：{{ switchValue5 }}</div>
        </section>
    </div>
</template>

<script>
export default {
    name: 'DemoSwitch',
    data() {
        return {
            switchValue1: false,
            switchValue2: true,
            switchValue3: 'open',
            switchValue4: false,
            switchValue5: false,
        };
    },
    // mounted() {},
    methods: {
        switchChange(msg) {
            console.log('switch change:', msg);
            // this.$OcToast({
            //     msg: msg ? '开启' : '关闭',
            //     hasMask: true,
            //     maskOpacity: 0.1, // 设置透明度小于1，可以隐藏遮罩层
            // });
        },
        switchClick(val) {
            this.$OcToast.loading({
                msg: '加载中...',
                duration: 1000,
                onHide: () => {
                    this.switchValue5 = !val;
                }
            });
        }
    }
};
</script>

<style lang="scss" scoped>
.page {
    margin: 10px;
}

.demo {
    margin-top: 15px;
    margin-left: 5px;
}

h1 {
    margin-bottom: 12px;
    font-size: 20px;
    color: #ff5040;
}

h2 {
    font-size: 18px;
    color: #ff00ff;
}

.ret {
    margin-top: 10px;
    color: 14px;
}

ul {
    margin-left: 5px;
    width: 150px;
}

li {
    margin-top: 5px;
}

.slot-icon {
    font-size: 24px;
    color: #aaa;
}

.slot-text {
    text-align: left;
    color: 14px;
}
.oc-switch {
    margin-right: 20px;
}
</style>
