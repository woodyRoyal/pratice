<template>
    <div class="page">
        <h1>通知栏</h1>
        <section class="demo">
            <h2>通知栏 - 水平方向顺序滚动</h2>
            <oc-notice-bar
                type="horizon"
                background-color="yellow"
                background-opacity=".3"
                text-color="orange"
                gutter="30vw"
                :list="list"
                :delay="1000"
                :speed="7"
            />
        </section>
        <section class="demo">
            <h2>通知栏 - 水平方向来回滚动</h2>
            <oc-notice-bar
                type="horizon"
                background-color="yellow"
                background-opacity=".3"
                text-color="blue"
                gutter="10vw"
                :is-link="true"
                :quiver="true"
                :list="list"
                :delay="1000"
                :speed="7"
            />
        </section>
        <section class="demo">
            <h2>通知栏 - 垂直方向滚动</h2>
            <oc-notice-bar
                type="vertical"
                background-color="yellow"
                background-opacity=".3"
                text-color="#666"
                :list="list"
                :delay="1000"
            />
        </section>
    </div>
</template>

<script>
    export default {
        name: 'NoticeBarDemo',
        data() {
            return {
                list: [
                    '你是人间的**四月天**，笑响点亮了四面风；轻灵，在春的光艳中交舞着变，',
                    '你是四月天里的*云烟，黄*着风的软，星子在，无意中闪，细雨点洒在花前',
                    '草长***莺飞***二月天'
                ]
            };
        }
    };
</script>

<style lang="scss" scoped>
    .page {
        margin: 10px;
    }

    .demo {
        margin-top: 15px;
        margin-left: 5px;
    }

    h1 {
        margin-bottom: 12px;
        font-size: 20px;
        color: #ff5040;
    }

    h2 {
        margin-bottom: 15px;
        font-size: 18px;
        color: #ff00ff;
    }
</style>