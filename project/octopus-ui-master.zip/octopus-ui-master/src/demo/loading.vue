<template>
    <div>
        <oc-loading name="spinner" color="#333"></oc-loading>
        <oc-loading name="spinner" is-white vertical style="background: rgba(0,0,0,.5)"></oc-loading>
        <oc-loading></oc-loading>

        <oc-loading name="googleCircle" color="red">1244</oc-loading>
        <oc-button type="danger" block @click="showToast1">Toast-加载中</oc-button>
        <oc-button type="danger" block @click="showToast2">Toast-加载中</oc-button>
        <oc-button type="danger" block @click="showToast3">Toast-加载中</oc-button>
    </div>
</template>

<script>
export default {
    name: 'DemoToast',
    data() {
        return {
            visible: false,
            coinNum: 100
        };
    },
    // mounted() {},
    methods: {
        showToast1() {
            const d = this.$OcToast.loading({
                msg: '加载中...',
                hasMask: true,
                onShow() {
                    console.log('显示一个loading');
                },
                onHide() {
                    console.log('关闭一个loading');
                }
            });
            setTimeout(() => {
                d._onHide();
            }, 4000);
        },
        showToast2() {
            const d = this.$OcToast.loading({
                msg: '加载中2...',
                loadingIcon: 'spinner',
                hasMask: true,
                onShow() {
                    console.log('显示一个loading');
                },
                onHide() {
                    console.log('关闭一个loading');
                }
            });
            setTimeout(() => {
                d._onHide();
            }, 4000);
        },
        showToast3() {
            const d = this.$OcToast.loading({
                msg: '加载中3...',
                loadingIcon: 'googleCircle',
                hasMask: true,
                onShow() {
                    console.log('显示一个loading');
                },
                onHide() {
                    console.log('关闭一个loading');
                }
            });
            setTimeout(() => {
                d._onHide();
            }, 4000);
        }
    }
};
</script>

<style lang="scss">
</style>
