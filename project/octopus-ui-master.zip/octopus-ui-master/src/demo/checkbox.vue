<template>
    <div class="page">
        <h1>多选框</h1>
        <section class="demo">
            <h2>多选框 - 常规风格</h2>
            <oc-checkbox-group v-model="model1">
                <ul>
                    <li>
                        <oc-checkbox label="A">选项A</oc-checkbox>
                    </li>
                    <li>
                        <oc-checkbox label="B">选项B</oc-checkbox>
                    </li>
                    <li>
                        <oc-checkbox label="C">选项C</oc-checkbox>
                    </li>
                    <li>
                        <oc-checkbox label="D" disabled>选项D</oc-checkbox>
                    </li>
                    <li>
                        <oc-checkbox label="E" disabled>选项E</oc-checkbox>
                    </li>
                </ul>
            </oc-checkbox-group>
            <div class="ret">已选择的选项：{{ text1 }}</div>
        </section>

        <section class="demo">
            <h2>多选框 - 常规风格内容居左</h2>
            <oc-checkbox-group v-model="model2">
                <ul>
                    <li>
                        <oc-checkbox label="A" label-position="left">选项A</oc-checkbox>
                    </li>
                    <li>
                        <oc-checkbox label="B" label-position="left">选项B</oc-checkbox>
                    </li>
                    <li>
                        <oc-checkbox label="C" label-position="left">选项C</oc-checkbox>
                    </li>
                </ul>
            </oc-checkbox-group>
            <div class="ret">已选择的选项：{{ text2 }}</div>
        </section>

        <section class="demo">
            <h2>多选框 - 插槽简易自定义</h2>
            <oc-checkbox-group v-model="model3">
                <ul>
                    <li>
                        <oc-checkbox label="A">
                            <template #icon="{ checked }">
                                <div class="slot-icon" :class="{ 'checked': checked }">{{ checked ? '★' : '☆' }}</div>
                            </template>
                            <div class="slot-text">选项A</div>
                        </oc-checkbox>
                    </li>
                    <li>
                        <oc-checkbox label="B">
                            <template #default="{ checked }">
                                <div class="slot-text" :class="{ 'checked': checked }">选项B-{{ checked ? '已勾选' : '未勾选' }}</div>
                            </template>
                        </oc-checkbox>
                    </li>
                </ul>
            </oc-checkbox-group>
            <div class="ret">已选择的选项：{{ text3 }}</div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'AddressPickerDemo',
        data() {
            return {
                model1: ['E'],
                model2: [],
                model3: []
            };
        },
        computed: {
            text1() {
                return this.model1.join(' - ');
            },
            text2() {
                return this.model2.join(' - ');
            },
            text3() {
                return this.model3.join(' - ');
            }
        },
        methods: {

        }
    };
</script>

<style lang="scss" scoped>
    .page {
        margin: 10px;
    }

    .demo {
        margin-top: 15px;
        margin-left: 5px;
    }

    h1 {
        margin-bottom: 12px;
        font-size: 20px;
        color: #ff5040;
    }

    h2 {
        font-size: 18px;
        color: #ff00ff;
    }

    .ret {
        margin-top: 10px;
        color: 14px;
    }

    ul {
        margin-left: 5px;
        width: 150px;
    }

    li {
        margin-top: 5px;
    }

    .slot-icon {
        font-size: 24px;
        color: #3097fd;
    }

    .slot-text {
        text-align: right;
        color: 14px;
        &.checked {
            color: orange;
            text-decoration: underline;
        }
    }
</style>