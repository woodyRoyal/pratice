<template>
    <div class="page">
        <h1>折叠面板</h1>
        <section class="demo">
            <h2>折叠面板 - 一般模式</h2>
            <oc-collapse v-model="model1">
                <oc-collapse-item title="if 如果" label="小羊诗歌" name="if 如果">
                    <p>谁能听见我，听见我，我内心深处的呐喊</p>
                    <p>谁能告诉我，告诉我，到哪里去寻找真爱</p>
                    <p>你可了解我，了解我，我因思念你心破碎</p>
                    <p>你可知道我，知道我，我对你的爱永不灭</p>
                </oc-collapse-item>
                <oc-collapse-item title="大鱼" name="大鱼">
                    <p>海浪无声将夜幕深深淹没</p>
                    <p>漫过天空尽头的角落</p>
                    <p>大鱼在梦境的缝隙里游过</p>
                    <p>凝望你沉睡的轮廓</p>
                </oc-collapse-item>
                <oc-collapse-item
                    title="冬音"
                    name="冬音"
                    disabled
                >
                    <h3>(3)</h3>
                    <p>foo</p>
                    <p>bar</p>
                </oc-collapse-item>
                <oc-collapse-item title="Love Story" name="Love Story">
                    <p>On a balcony in summer air</p>
                    <p>See the party the ball gowns</p>
                    <p>I see you make your way through the crowd and say hello little did I know</p>
                </oc-collapse-item>
            </oc-collapse>
            <div class="ret">已展开项：{{ text1 }}</div>
        </section>
        <hr>
        <section class="demo">
            <h2>折叠面板 - 手风琴模式</h2>
            <oc-collapse v-model="model2" accordion>
                <oc-collapse-item title="if 如果" label="小羊诗歌" name="if 如果">
                    <p>谁能听见我，听见我，我内心深处的呐喊</p>
                    <p>谁能告诉我，告诉我，到哪里去寻找真爱</p>
                    <p>你可了解我，了解我，我因思念你心破碎</p>
                    <p>你可知道我，知道我，我对你的爱永不灭</p>
                </oc-collapse-item>
                <oc-collapse-item title="大鱼" name="大鱼">
                    <p>海浪无声将夜幕深深淹没</p>
                    <p>漫过天空尽头的角落</p>
                    <p>大鱼在梦境的缝隙里游过</p>
                    <p>凝望你沉睡的轮廓</p>
                </oc-collapse-item>
                <oc-collapse-item title="冬音" name="冬音">
                    <p>纯音乐，请您欣赏</p>
                </oc-collapse-item>
                <oc-collapse-item title="Love Story" name="Love Story">
                    <p>On a balcony in summer air</p>
                    <p>See the party the ball gowns</p>
                    <p>I see you make your way through the crowd and say hello little did I know</p>
                </oc-collapse-item>
            </oc-collapse>
            <div class="ret">已展开项：{{ model2 }}</div>
        </section>

    </div>
</template>

<script>
    export default {
        name: 'CollapseDemo',
        data() {
            return {
                model1: ['大鱼'],
                model2: null
            };
        },
        computed: {
            text1() {
                return this.model1.join('，');
            }
        },
        methods: {

        }
    };
</script>

<style lang="scss" scoped>
    .page {
        margin: 10px;
    }

    .demo {
        margin-top: 15px;
        margin-left: 5px;
    }

    h1 {
        margin-bottom: 12px;
        font-size: 20px;
        color: #ff5040;
    }

    h2 {
        font-size: 18px;
        color: #ff00ff;
    }

    .ret {
        margin-top: 10px;
        color: 14px;
    }

    ul {
        margin-left: 5px;
        width: 150px;
    }

    li {
        margin-top: 5px;
    }

    .slot-icon {
        font-size: 18px;
        color: #aaa;
    }
    .slot-text {
        text-align: right;
        color: 14px;
    }
</style>