<template>
    <div>
        <section>
            <h1>函数调用</h1>
            <oc-button type="primary" @click="showToast1">Toast-成功</oc-button>
            <oc-button type="primary" icon="right" iconPosition="right" plain @click="showToast2">Toast-失败</oc-button>
            <oc-button type="primary" @click="showToast7">Toast-纯文字</oc-button>
            <oc-button type="primary" @click="showToast8">Toast-长纯文字</oc-button>
            <oc-button type="primary" @click="showToast4">Toast-自定义内容-组件</oc-button>
            <oc-button type="warning" @click="showToast5">Toast-自定义内容-创作</oc-button>
            <oc-button type="warning" @click="showToast6">Toast-自定义内容-创作2</oc-button>
            <oc-button type="danger" block @click="showToast3">Toast-加载中</oc-button>
        </section>
        <section>
            <h1>组件调用</h1>
            <oc-button type="primary" @click="showTpl">组件调用-父级class修改</oc-button>
        </section>
        <oc-toast
            :visible.sync="visible"
            custom-class="abc"
            :has-mask="true"
            type="warn"
            msg="11jdja"
            @onShow="showCb"
            @onHide="hideCb"
            >slot取代msg的内容</oc-toast
        >
        <!-- <oc-toast
            :visible.sync="visible"
            custom-class="abc"
            :has-mask="true"
            type="warn"
            msg="23456"
            @onShow="showCb"
            @onHide="hideCb"
            >314151515</oc-toast
        > -->
    </div>
</template>

<script>
export default {
    name: 'DemoToast',
    data() {
        return {
            visible: false,
            coinNum: 100
        };
    },
    // mounted() {},
    methods: {
        showCb() {
            console.log('显示Toast回调');
        },
        hideCb() {
            console.log('关闭Toast回调');
            this.visible = false;
        },
        showTpl() {
            this.visible = true;
        },
        showToast1() {
            this.$OcToast.success({
                msg: 'Toast成功状态，居底',
                align: 'bottom',
                // duration: 0,
                onShow() {
                    console.log('显示1');
                },
                onHide() {
                    console.log('关闭1');
                }
            });
            // this.$OcToast.fail({
            //     msg: 'Toast失败状态，居顶',
            //     align: 'top',
            //     onShow() {
            //         console.log('显示2');
            //     },
            //     onHide() {
            //         console.log('关闭2');
            //     }
            // });
        },
        showToast2() {
            this.$OcToast.fail({
                msg: 'Toast失败状态，居顶',
                // duration: 1000,
                align: 'top',
                onShow() {
                    console.log('显示2');
                },
                onHide() {
                    console.log('关闭2');
                }
            });
        },
        showToast3() {
            const d = this.$OcToast.loading({
                msg: '加载中...',
                hasMask: true,
                maskOpacity: '50',
                onShow() {
                    console.log('显示一个loading');
                },
                onHide() {
                    console.log('关闭一个loading');
                }
            });
            setTimeout(() => {
                d._onHide();
            }, 4000);
        },
        showToast4() {
            this.$OcToast({
                msg(h) {
                    return h(
                        'oc-button',
                        {
                            props: {
                                type: 'warning',
                                icon: 'check'
                            }
                        },
                        'button组件'
                    );
                }
            });
        },
        showToast5() {
            this.$OcToast({
                customClass: 'ennn',
                msg: (h) => {
                    return h('div', [
                        h(
                            'div',
                            {
                                class: 'gold-coin-txt'
                            },
                            [h('strong', `+${this.coinNum}`), h('span', '金币')]
                        ),
                        h('div', {
                            class: 'gold-coin-img'
                        })
                    ]);
                }
                // hasMask: true
            });
        },
        showToast6() {
            this.$OcToast({
                msg: (h) => {
                    return h('div', [
                        h('oc-icon', {
                            style: {
                                marginRight: '10px',
                                fontSize: '20px',
                                verticalAlign: 'top'
                            },
                            props: {
                                name: 'tip-circle'
                            }
                        }),
                        '这是一条反馈信息'
                    ]);
                }
            });
        },
        showToast7() {
            this.$OcToast({
                msg: 'Toast纯文字'
            });
        },
        showToast8() {
            this.$OcToast('Toast纯文字---文字很长，会有两行');
        }
    }
};
</script>

<style lang="scss">
.ennn {
    .inner {
        width: 102px;
        padding: 8px 0 0;
        text-align: center;
    }
}
.gold-coin {
    &-img {
        width: 100%;
        height: 87px;
        margin-top: -4px;
        background: url(~@/assets/images/toast_coin.png) 50% 50% no-repeat;
        background-size: 100%;
    }
    &-txt {
        font-size: 12px;
        color: #fdf020;
        strong {
            // display: inline-block;
            margin-right: 2px;
            font-weight: 800;
            font-size: 18px;
        }
        span {
            vertical-align: text-bottom;
        }
    }
}

.abc {
    .inner {
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 0 2px rgba(0, 0, 0, 0.4);
        color: #000;
    }
}
</style>
