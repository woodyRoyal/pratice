<template>
    <div class="page">
        <h1>日期选择器</h1>
        <section class="demo">
            <h2>日期选择器</h2>
            <div class="btn" @click="display1 = true">选择</div>
            <div class="ret">当前选择的时间：{{ text1 }}</div>
            <oc-date-picker
                v-show="display1"
                :init-date="[1994, 2, 22]"
                confirm-btn-text="选择"
                title="请选择日期"
                @cancel="display1 = false"
                @confirm="onConfirm1"
            />
        </section>

        <section class="demo">
            <h2>时钟选择器</h2>
            <div class="btn" @click="display2 = true">选择</div>
            <div class="ret">当前选择的时间：{{ text2 }}</div>
            <oc-date-picker
                v-show="display2"
                :is-clock="true"
                :init-date="[16, 16]"
                confirm-btn-text="选择"
                title="请选择时间"
                @cancel="display2 = false"
                @confirm="onConfirm2"
            />
        </section>
    </div>

</template>

<script>
    export default {
        name: 'DatePickerDemo',
        data() {
            return {
                display1: false,
                display2: false,
                date1: [],
                date2: []
            };
        },
        computed: {
            text1() {
                return this.date1.map(item => item.text).join(' - ');
            },
            text2() {
                return this.date2.map(item => item.text).join(' - ');
            }
        },
        methods: {
            onConfirm1(data) {
                this.date1 = data;
                this.display1 = false;
            },
            onConfirm2(data) {
                this.date2 = data;
                this.display2 = false;
            }
        }
    };
</script>

<style lang="scss" scoped>
    .page {
        margin: 10px;
    }

    .demo {
        margin-top: 15px;
        margin-left: 5px;
    }

    h1 {
        margin-bottom: 12px;
        font-size: 20px;
        color: #ff5040;
    }

    h2 {
        font-size: 18px;
        color: #ff00ff;
    }

    .btn {
        position: relative;
        display: inline-block;
        box-sizing: border-box;
        margin-top: 10px;
        padding: 0 5px;
        height: 30px;
        text-align: center;
        border-radius: 4px;
        line-height: 30px;
        font-size: 16px;
        color: #fff;
        background-color: #1989fa;
    }

    .ret {
        margin-top: 10px;
    }

    .slot-columns-top {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 50px;
        border-bottom: 1px dashed #FFE8E8E8;
        font-size: 24px;
        color: orange;
    }

    .slot-columns-bottom {
        display: flex;
        height: 50px;
        border-top: 1px dashed #FFE8E8E8;
        .slot-btn {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-grow: 1;
            color: orange;
            &:first-of-type {
                border-right: 1px dashed #FFE8E8E8;
            }
        }
    }
</style>