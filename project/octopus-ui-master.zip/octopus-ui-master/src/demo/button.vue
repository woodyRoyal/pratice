<template>
    <div>
        <section>
            <h1>按钮类型</h1>
            <oc-button>默认按钮</oc-button>
            <oc-button type="primary" style="width: 200px;">主要按钮</oc-button>
            <oc-button type="warning">警告按钮</oc-button>
            <oc-button type="danger">危险按钮</oc-button>
        </section>
        <section>
            <h1>朴素按钮</h1>
            <oc-button type="primary" plain>朴素按钮</oc-button>
            <oc-button type="warning" plain>朴素按钮</oc-button>
            <oc-button type="danger" plain>朴素按钮</oc-button>
        </section>
        <section>
            <h1>禁用状态</h1>
            <oc-button type="primary" disabled>禁用状态</oc-button>
        </section>
        <section>
            <h1>图标按钮</h1>
            <oc-button type="primary" icon="check">主页</oc-button>
            <oc-button type="primary" plain icon="check" iconPosition="right">主页</oc-button>
        </section>
        <section>
            <h1>加载按钮</h1>
            <oc-button type="primary" loading block>Toast-加载中</oc-button>
        </section>
        <section>
            <h1>按钮样式</h1>
            <oc-button type="primary" radius="0">直角按钮</oc-button>
            <oc-button type="primary" round>圆角按钮</oc-button>
            <oc-button type="primary" size="big">大尺寸按钮</oc-button>
            <oc-button type="primary" size="small">小尺寸按钮</oc-button>
            <oc-button type="primary" size="big" plain round>大尺寸按钮</oc-button>
            <oc-button type="primary" size="small" plain round>小尺寸按钮</oc-button>
        </section>
        <section>
            <h1>通栏按钮</h1>
            <oc-button type="primary" block round icon="check">满行按钮</oc-button>
            <oc-button type="primary" block plain icon="check">满行按钮</oc-button>
        </section>
    </div>
</template>

<script>
export default {
    name: 'ocbutton',
    data() {
        return {};
    },
    // mounted() {},
    methods: {}
};
</script>

<style lang="scss"></style>
