<template>
    <div>
        <section>
            <oc-button type="primary" @click="showMask">打开遮罩层</oc-button>
        </section>
        <oc-overlay :visible="visible" mask-transition-name="fade" z-index="100" :isLock-scroll="true" @on-mask="clickMaskClose"></oc-overlay>
    </div>
</template>

<script>
export default {
    name: 'DemoToast',
    data() {
        return {
            visible: false
        };
    },
    // mounted() {},
    methods: {
        showMask() {
            this.visible = true;
        },
        clickMaskClose() {
            this.visible = false;
            console.log(11111);
        }
    }
};
</script>