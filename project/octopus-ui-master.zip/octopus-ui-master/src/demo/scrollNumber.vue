<template>
  <div class="page">
    <h1>滚动数字</h1>
    <section class="demo">
        <h2>常规动画</h2>
        <oc-scroll-number 
          class="scroll-num1"
          :duration="duration"
          speedMode="single"
          :current="current1"></oc-scroll-number>
          <oc-button @click="change1">随机改变</oc-button>
    </section>
    <section class="demo">
        <h2>每位数字的动画同时完成</h2>
        <oc-scroll-number 
          class="scroll-num2"
          :duration="duration"
          :original="origin2"
          :current="current2"></oc-scroll-number>
        <oc-button @click="change2">切换</oc-button>
    </section>
    <section class="demo">
        <h2>修改颜色(同字体)</h2>
        <oc-scroll-number 
          class="scroll-num3"
          :duration="duration"
          :original="origin2"
          :current="current2"></oc-scroll-number>
    </section>
  </div>
</template>

<script>
export default {
  data() {
    return {
      current1: 8893,
      origin1: '0000',
      current2: 5.01,
      origin2: 6.66,
      duration: 2000
    };
  },
  methods: {
    change1 () {
      this.current1 = (Math.random()*1000 - 1).toFixed(2);
    },
    change2 () {
      this.current2 = this.current2 === 5.01 ? 6.66 : 5.01;
    }
  }
};
</script>

<style scoped lang="scss">
  .page {
      margin: 10px;
  }

  .demo {
      margin-top: 15px;
      margin-left: 5px;
  }

  h1 {
      margin-bottom: 12px;
      font-size: 20px;
      color: #ff5040;
  }

  h2 {
      font-size: 18px;
      color: #ff00ff;
  }
.scroll-num1 {
  font-size: 20px;
  font-weight: bold;
}
.scroll-num2 {
  font-size: 60px;
  font-weight: bold;
}
.scroll-num3 {
  color: #ff5040;
  font-size: 30px;
  font-weight: bold;
}
</style>