<template>
    <div>
        <section>
            <h1>自带ICON</h1>
            <oc-list-icon :list="iconList1"></oc-list-icon>
        </section>
        <section>
            <h1>示意ICON</h1>
            <oc-list-icon :list="iconList2"></oc-list-icon>
        </section>
    </div>
</template>

<script>
import OcListIcon from './../components/ListIcon';
export default {
    name: 'DemoIcon',
    data() {
        return {
            iconList1: [
                'tick-circle',
                'cross-circle',
                'cross-circle-light',
                'tip-circle',
                'cross',
            ],
            iconList2: [
                'left',
                'right',
                'eye',
                'eye-slash',
                'info-circle',
                'question-circle',
                'exclamation-circle',
                'minus-circle',
                'plus-circle',
                'loading'
            ]
        };
    },
    // mounted() {},
    methods: {},
    components: {
        OcListIcon
    }
};
</script>

<style lang="scss"></style>
