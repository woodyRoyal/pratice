<template>
    <div class="page">
        <oc-cell-group>
            <oc-cell>
                <oc-input
                    ref="input"
                    type="textarea"
                    label="标签文字"
                    placeholder="placeholder"
                    :clearable="true"
                    v-model="val"
                    required
                    clickable
                    autosize
                    label-width="60px"
                    error-message="love is zero"
                    error-message-class="love is zero"
                >
                </oc-input>
            </oc-cell>
            <oc-cell>
                <oc-input
                    ref="input"
                    type="text"
                    label="标签a文字"
                    placeholder="这是一个input"
                    :clearable="true"
                    v-model="val2"
                    required
                    clickable
                    autosize
                    error-message="love is zero"
                    error-message-class="love is zero"
                >
                    <template #button>
                        <oc-button size="small">发送短信</oc-button>
                    </template>
                </oc-input>
            </oc-cell>
            <oc-cell>
                <oc-input
                    ref="input"
                    type="password"
                    label="密码"
                    placeholder="这是一个input"
                    :clearable="true"
                    v-model="val2"
                    required
                    clickable
                    autosize
                    error-message="love is zero"
                    error-message-class="love is zero"
                >
                </oc-input>
            </oc-cell>
        </oc-cell-group>
    </div>
</template>

<script>
    export default {
        name: 'FieldDemo',
        data() {
            return {
                val: '',
                val2: ''
            };
        },
        // mounted() {}
    };
</script>

<style lang="scss" scoped>
    .page {
        margin: 10px;
    }

    .demo {
        margin-top: 15px;
        margin-left: 5px;
    }

</style>