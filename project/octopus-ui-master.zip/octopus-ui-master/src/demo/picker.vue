<template>
    <div class="page">
        <h1>选择器</h1>
        <section class="demo">
            <h2>选择器 - 关联数组</h2>
            <oc-picker
                title="标题1"
                list-align="center"
                :multi-array="multiArray1"
                :line-count="7"
                :init-indices="[0, 2, 1]"
                :is-single-column="false"
                @cancel="onCancel"
                @change="onChange"
                @confirm="onConfirm"
            />
            <div class="ret">{{ text1 }}</div>
        </section>
        <section class="demo">
            <h2>选择器 - 关联数组 - 单列模式</h2>
            <oc-picker
                :multi-array="multiArray1"
                :line-count="5"
                :init-indices="[-1]"
                :is-single-column="true"
                @cancel="onCancel"
                @change="onChange"
                @confirm="onConfirm"
            />
            <div class="ret">{{ text1 }}</div>
        </section>
        <section class="demo">
            <h2>选择器 - 非关联数组、简易插槽</h2>
            <oc-picker
                :show-toolbar="true"
                :is-linkage="false"
                :is-single-column="true"
                :multi-array="multiArray2"
                :line-count="5"
                @cancel="onCancel"
                @change="onChange"
                @confirm="onConfirm"
            >
            </oc-picker>
            <div class="ret">{{ text2 }}</div>
        </section>
    </div>
</template>

<script>

    export default {
        name: 'PickerDemo',
        data() {
            return {
                multiArray1: [
                    ['A', 'B', 'C'],
                    [['Aa', 'Ab', 'Ac'], ['Ba', 'Bb', 'Bc'], ['Ca', 'Cb', 'Cc']],
                    [
                        [['Aa1', 'Aa2', 'Aa3'], ['Ab1', 'Ab2', 'Ab3'], ['Ac1', 'Ac2', 'Ac3']],
                        [['Ba1', 'Ba2', 'Ba3'], ['Bb1', 'Bb2', 'Bb3'], ['Bc1', 'Bc2', 'Bc3']],
                        [['Ca1', 'Ca2', 'Ca3'], ['Cb1', 'Cb2', 'Cb3'], ['Cc1', 'Cc2', 'Cc3']]
                    ]
                ],
                text1: null,
                multiArray2: [
                    ['A', 'B', 'C', 'D', 'E'],
                    ['a', 'b', 'c', 'd'],
                    ['1', '2', '3']
                ],
                text2: null
            };
        },
        methods: {
            onCancel() {
                console.log(111);
            },
            onChange(data) {
                console.log(data);
            },
            onConfirm(data) {
                console.log(data);
            }
        }
    };
</script>

<style lang="scss" scoped>
    .page {
        margin: 10px;
    }

    .demo {
        margin-top: 30px;
        margin-left: 5px;
    }

    h1 {
        margin-bottom: 12px;
        font-size: 20px;
        color: #ff5040;
    }

    h2 {
        font-size: 18px;
        color: #ff00ff;
    }

    .ret {
        margin-top: 10px;
        color: 14px;
    }

    .slot-columns-top {
        height: 40px;
        line-height: 40px;
        border-bottom: 1px dotted #e5e5e5;
        text-align: center;
        font-size: 16px;
        color: orange;
    }
</style>