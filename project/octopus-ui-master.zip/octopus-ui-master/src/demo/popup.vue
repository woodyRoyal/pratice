<template>
    <div class="test-scroll">
        <section>
            <h1>组件调用</h1>
            <oc-button type="primary" @click="showTpl">组件调用</oc-button>
            <oc-button type="primary" @click="showTpl2">组件调用-右方弹出</oc-button>
            <oc-button type="primary" @click="showTpl3">组件调用-下方弹出</oc-button>
            <oc-button type="primary" @click="showTpl4">组件调用-左方弹出</oc-button>
        </section>
        <oc-popup
            :visible.sync="visible"
            :has-close-icon="true"
            :canCloseByMask="true"
            @on-show="showCb"
            @on-hide="hideCb"
        >
            <div style="background: #fff; width: 200px;">
                <span slot="title"> | slot标题</span>
                <div style="font-size: 12px;">这是一行辅助文字这是一行辅助文字</div>
            </div>
        </oc-popup>
        <oc-popup
            :visible.sync="visible2"
            :has-close-icon="true"
            :canCloseByMask="true"
            align="right"
            @on-show="showCb"
            @on-hide="hideCb"
            @on-mask="maskCb"
        >
            <div style="background: #fff; width: 200px;">
                <span slot="title"> | slot标题</span>
                <div style="font-size: 12px;">这是一行辅助文字这是一行辅助文字</div>
            </div>
        </oc-popup>
        <oc-popup
            :visible.sync="visible3"
            :has-close-icon="true"
            :canCloseByMask="true"
            align="bottom"
            @on-show="showCb"
            @on-hide="hideCb"
            @on-close="closeCb"
        >   
            <div style="background: #fff; width: 100%; height: 200px;">
                <span slot="title"> | slot标题</span>
                <div style="font-size: 12px;">这是一行辅助文字这是一行辅助文字</div>
            </div>
        </oc-popup>
        <oc-popup
            :visible.sync="visible4"
            :has-close-icon="true"
            :canCloseByMask="true"
            align="left"
            @on-show="showCb"
            @on-hide="hideCb"
        >
            <div style="background: #fff; width: 200px; height: 100%;">
                <span slot="title"> | slot标题</span>
                <div style="font-size: 12px;">这是一行辅助文字这是一行辅助文字</div>
            </div>
        </oc-popup>
    </div>
</template>

<script>

export default {
    name: 'DemoPopup',
    data() {
        return {
            visible: false,
            visible2: false,
            visible3: false,
            visible4: false,
            coin: 500,
            nextCoin: 20,
            imgSrc: 'http://iph.href.lu/2000x1000',
            eh: 0
        };
    },
    // mounted() {},
    methods: {
        showCb() {
            console.log('展示');
        },
        hideCb() {
            console.log('关闭');
        },
        maskCb() {
            console.log('点击遮罩层');
        },
        closeCb() {
            console.log('点击X');
        },
        showTpl() {
            this.visible = true;
        },
        showTpl2() {
            this.visible2 = true;
        },
        showTpl3() {
            this.visible3 = true;
        },
        showTpl4() {
            this.visible4 = true;
        }
    }
};
</script>

<style lang="scss">
</style>
