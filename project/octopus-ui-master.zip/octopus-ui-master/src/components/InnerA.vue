<template>
    <div style="padding: 20px; background: #fff;">{{ text }}</div>
</template>

<script>
export default {
    name: 'InnerA',
    props: {
        text: {
            type: String,
            default: 'a'
        }
    },
    data() {
        return {};
    },
    methods: {
    }
};
</script>

<style lang="scss">
</style>
