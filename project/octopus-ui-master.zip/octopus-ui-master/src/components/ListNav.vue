<template>
    <ul>
        <li v-for="(it, idx) in data" :key="idx">
            <router-link :to="it.path">{{ it.title }}<oc-icon name="right"></oc-icon></router-link>
        </li>
    </ul>
</template>

<script>
export default {
    name: 'OcListNav',
    props: {
        data: {
            type: Array,
            default: () => []
        }
    },
    data() {
        return {};
    },
    // mounted() {},
    methods: {}
};
</script>

<style lang="scss" scoped>
@import '@/assets/css/mixin/_mixin.scss';

ul {
    margin: 0 -16px;
    padding-left: 16px;
    @include bd-top(#e8e8e8);
}
li {
    height: 48px;
    // margin: 0 -16px;
    // padding-left: 16px;
    @include bd-bottom(#e8e8e8);
    a {
        display: flex;
        align-items: center;
        height: 100%;
        margin-left: -16px;
        padding-left: 16px;
        font-size: 16px;
        // margin-top: -1px;
        // border-top: 1px solid #f4f5f6;
    }
    .oc-icon {
        margin-left: auto;
        margin-right: 16px;
        color: $font-color-w;
    }
    &:last-child {
        border-bottom: 0;
    }
    &:active {
        border-bottom: 0;
        a {
            background: #f4f5f6;
        }
    }
}
</style>
