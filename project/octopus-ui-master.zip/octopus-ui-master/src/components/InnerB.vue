<template>
    <div style="padding: 20px; background: #fff;">{{ text }}</div>
</template>

<script>
export default {
    name: 'InnerB',
    props: {
        text: {
            type: String,
            default: 'b'
        }
    },
    data() {
        return {};
    },
    methods: {
    }
};
</script>

<style lang="scss">
</style>
