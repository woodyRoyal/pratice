<template>
    <div class="xq-coin-a abc">
        <div class="tupian"></div>
        <h1><strong>{{ coin }}</strong><span>金币</span></h1>
        <p>明日签到可领<em>{{ nextCoin }}金币</em></p>
        <oc-button type="danger" block round @click="closeDialog">我知道了</oc-button>
    </div>
</template>

<script>
export default {
    name: 'InnerC',
    props: {
        coin: {
            type: [String, Number],
            default: '--'
        },
        nextCoin: {
            type: [String, Number],
            default: '--'
        }
    },
    data() {
        return {};
    },
    watch: {
        coin() {
            console.log(1111);
        }
    },
    methods: {
        closeDialog() {
            this.$emit('closeDialog');
        }
    }
};
</script>

<style lang="scss">
    .xq-coin-a {
        position: relative;
        width: 16.875rem;
        margin: 0 auto;
        padding: 20px 25px;
        background: #fff;
        border-radius: 8px;
        text-align: center;
        &::after {
            content: '';
            position: absolute;
            left: 50%;
            top: 0;
            z-index: -1;
            width: 200px;
            height: 200px;
            margin: -40px 0 0 -100px;
            background: red;
            animation: Rotate2 linear 800ms infinite;
        }
        & + .oc-popup-close {
            // border: 1px solid blue;
            left: 50%;
            top: auto;
            bottom: -70px;
            transform: translateX(-50%);
            width: 40px;
            height: 40px;
            font-size: 40px;
            color: #fff;
        }

        .tupian {
            width: 153px;
            height: 99px;
            margin: -50px auto 4px;
            background: url(~@/assets/images/dialog_coin.png) 50% 50% no-repeat;
            background-size: 100%;
        }
        h1 {
            margin-bottom: 8px;
            font-size: 17px;
            color: #ff5040;
            span {
                margin-left: 2px;
                vertical-align: text-bottom;
            }
        }
        p {
            margin-bottom: 30px;
            font-size: 14px;
            color: #1a1a1a;
        }
        strong {
            font-weight: 800;
            font-size: 32px;
        }
        em {
            margin-left: 4px;
            color: #ff5040;
        }
    }


    .hehe-enter-active {
    // transition: all 0.5s cubic-bezier(0.05, 1, 1, 1.19);
    animation-duration: 0.6s;
    animation-name: bounceIn;
    &::after {
        // animation: Rotate2 linear 800ms 400ms infinite;
        opacity: 0;
    }
}
.hehe-leave-active {
    animation-duration: 0.4s;
    animation-name: bounceOut;
    // animation-direction: alternate;
    &::after {
        opacity: 0;
    }
}

.hehe-enter-active, .hehe-leave-active {
  transition: opacity .5s;
}
.hehe-enter, .hehe-leave-to{
  opacity: 0;
}
@keyframes bounceIn {
    from,
    20%,
    40%,
    60%,
    80%,
    to {
        animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
    }

    0% {
        opacity: 0;
        transform: scale3d(0.3, 0.3, 0.3);
    }

    20% {
        transform: scale3d(1.1, 1.1, 1.1);
    }

    40% {
        transform: scale3d(0.9, 0.9, 0.9);
    }

    60% {
        opacity: 1;
        transform: scale3d(1.03, 1.03, 1.03);
    }

    80% {
        transform: scale3d(0.97, 0.97, 0.97);
    }

    to {
        opacity: 1;
        transform: scale3d(1, 1, 1);
    }
}

@keyframes bounceOut {
    20% {
        transform: scale3d(0.9, 0.9, 0.9);
    }

    50%,
    55% {
        opacity: 1;
        transform: scale3d(1.1, 1.1, 1.1);
    }

    to {
        opacity: 0;
        transform: scale3d(0.3, 0.3, 0.3);
    }
}
</style>
