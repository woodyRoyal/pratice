<template>
    <ul>
        <li v-for="it in list" :key="it">
            <oc-icon :name="it"></oc-icon>
            <span>{{ it }}</span>
        </li>
    </ul>
</template>

<script>
export default {
    name: 'OcListNav',
    props: {
        list: {
            type: Array,
            default: () => []
        }
    },
    data() {
        return {};
    },
    // mounted() {},
    methods: {
    }
};
</script>

<style lang="scss" scoped>
ul {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}
    li {
        width: 20%;
        margin: 0 2% 8px;
        margin-bottom: 8px;
        background: rgba(0, 0, 0, .4);
        text-align: center;
        span {
            display: block;
            overflow: hidden;
            white-space: nowrap;
            font-size: 12px;
        }
    }
</style>
