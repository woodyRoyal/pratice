import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import "@/assets/js/iconfont.js";

import OCUI from "../packages";
import locale from '../packages/locale/lang/en-US';

Vue.use(OCUI, {
  toastDuration: 2000,
  locale: locale 
});

// import OcDialog from '../packages/Dialog';
// import OcIcon from '../packages/Icon';
// import OcButton from '../packages/Button';

// Vue.prototype.$UICONFIG =  {
//   toastDuration: 2000,
// };
// Vue.use(OcDialog).use(OcIcon).use(OcButton);

new Vue({
  router,
  render: h => h(App)
}).$mount("#app");