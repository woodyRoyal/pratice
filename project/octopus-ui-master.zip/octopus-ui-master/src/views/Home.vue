<template>
    <article class="p-index">
        <!-- <div class="ccc ccc1">1px按钮</div>
        <div class="ccc ccc4" style="margin-top: 40px;">1px按钮</div> -->
        <header class="theme">
            <h1>Octopus UI</h1>
            <p>基于 Vue 2.x 的移动端组件库</p>
        </header>
        <section class="oc-item" v-for="it in list" :key="it.title">
            <oc-sticky class="m-sticky" top="-1" class-name="abc"><h1>{{ it.title }}</h1></oc-sticky>
            <oc-list-nav :data="it.item"></oc-list-nav>
        </section>
    </article>
</template>

<script>
import '@/assets/js/iconfont2.js';
// import '@/assets/js/iconfont3.js';

import OcListNav from './../components/ListNav';
export default {
    name: 'home',
    data() {
        return {
            list: [
                {
                    title: '基础组件',
                    item: [
                        {
                            path: '/design/button',
                            title: 'Button 按钮'
                        },
                        {
                            path: '/design/icon',
                            title: 'Icon 图标'
                        },
                        {
                            path: '/design/cell',
                            title: 'Cell 单元格'
                        },
                        {
                            path: '/design/overlay',
                            title: 'Overlay 遮罩层'
                        },
                        {
                            path: '/design/scroll',
                            title: 'Scroll 滚动'
                        },
                        {
                            path: '/design/popup',
                            title: 'Popup 弹层'
                        },
                        {
                            path: '/design/picker',
                            title: 'Picker 选择器'
                        }
                    ]
                },
                {
                    title: '反馈组件',
                    item: [
                        {
                            path: '/design/dialog',
                            title: 'Dialog 弹窗'
                        },
                        {
                            path: '/design/toast',
                            title: 'Toast 轻提示'
                        },
                        {
                            path: '/design/loading',
                            title: 'Loading 加载中'
                        }
                    ]
                },
                {
                    title: '表单组件',
                    item: [
                        {
                            path: '/design/input',
                            title: 'Input 输入框'
                        },
                        {
                            path: '/design/radio',
                            title: 'Radio 单选框'
                        },
                        {
                            path: '/design/checkbox',
                            title: 'Checkbox 复选框'
                        },
                        {
                            path: '/design/switch',
                            title: 'switch 开关'
                        },
                    ]
                },
                {
                    title: '展示组件',
                    item: [
                        {
                            path: '/design/noticeBar',
                            title: 'NoticeBar 通告栏'
                        },
                        {
                            path: '/design/collapse',
                            title: 'Collapse 折叠面板'
                        },
                        {
                            path: '/design/scrollNumber',
                            title: 'ScrollNumber 滚动数字'
                        }
                    ]
                },
                {
                    title: '业务组件',
                    item: [
                        {
                            path: '/design/lunarPicker',
                            title: 'LunarPicker 日历选择器'
                        },
                        {
                            path: '/design/addressPicker',
                            title: 'AddressPicker 地址选择器'
                        }
                    ]
                },
                {
                    title: '导航组件',
                    item: [
                        {
                            path: '/design/tabs',
                            title: 'Tabs 标签页'
                        }
                    ]
                }
            ]
        };
    },
    mounted() {
        // setTimeout(() => {
        //     alert(screen.width);
        // }, 4000);
        console.log(`布局视口: ${document.documentElement.clientWidth}px`);
        console.log(`视觉视口: ${window.innerWidth}px`);
        console.log(`理想视口: ${screen.width}px`);
        console.log(`DPR: ${window.devicePixelRatio}`);
    },
    methods: {},
    components: {
        OcListNav
    }
};
</script>

<style lang="scss">
* {
    margin: 0;
    padding: 0;
}
html,
body {
    height: 100%;
}
#app {
    position: absolute;
    left: 0;
    right: 0;
    min-height: 100%;
    text-align: left;
}
.p-index {
    padding: 16px;
    box-sizing: border-box;
    .theme {
        margin-bottom: 16px;
        h1 {
            font-weight: bold;
            font-size: 32px;
        }
        p {
            color: 14px;
        }
    }
    .oc-item {
        margin-bottom: 8px;
        padding: 0 16px;
        background: #fff;
        border-radius: 4px;
        box-shadow: 0 1px 8px darken(#f4f5f6, 4);
        h1 {
            padding: 16px 0;
        }
        .m-sticky {
            transition: all 300ms ease-in 100ms;
            background: #fff;
        }
        .abc {
            height: 40px;
            background: red;
        }
    }
}

// .ccc1 {
//     @include thinLine(blue);
// }
// .ccc2 {
//     @include thinLine(red, 1, 1, 1, 1);
// }
// .ccc3 {
//     @include thinLine(red, 1, 1, 1, 0);
// }
// .ccc4 {
//     @include thinLine(blue, 1, 1, 1, 1, 18);
// }
</style>
