<template>
    <article class="design">
        <header class="design-hd">
            <div class="cell-left">
                <router-link to="/"><oc-icon name="left"></oc-icon></router-link>
            </div>
            <h1 class="cell-center">{{ $route.meta.title }}</h1>
            <div class="cell-right"></div>
        </header>
        <main class="design-bd">
            <keep-alive>
                <router-view v-if="$route.meta.keepAlive"></router-view>
            </keep-alive>
            <router-view v-if="!$route.meta.keepAlive"></router-view>
        </main>
    </article>
</template>

<script>
export default {
    name: 'design',
    data() {
        return {};
    },
    // mounted() {},
    methods: {}
};
</script>

<style lang="scss">
.design {
    min-height: 100vh;
    padding-top: 48px;
    background: #fff;
    box-sizing: border-box;
    &-hd {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 501;
        display: flex;
        height: 48px;
        background: #2f97fd;
        box-shadow: 0 1px 4px rgba(#2f97fd, 0.6);
        * {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .cell-left,
        .cell-right {
            width: 72px;
            a {
                color: #fff;
            }
        }
        .cell-left {
            justify-content: flex-start;
            a {
                padding-left: 16px;
            }
        }
        .cell-right {
            justify-content: flex-end;
            a {
                padding-right: 16px;
            }
        }
        .cell-center {
            overflow: hidden;
            flex: 1;
            font-weight: bold;
            font-size: 24px;
            color: #fff;
            text-shadow: 1px 1px darken(#2f97fd, 4);
        }
    }
    &-bd {
        padding: 16px;
        section {
            margin-bottom: 8px;
            & > h1 {
                margin-bottom: 8px;
            }
            & > .oc-button {
                margin: 0 8px 8px 0;
            }
        }
    }
}
</style>
