const path = require('path');
const CopyPlugin = require('copy-webpack-plugin');
const LodashModulePlugin = require('lodash-webpack-plugin');
const ENV_TYPE = process.env.npm_lifecycle_event;

let config;

if (ENV_TYPE !== 'lib') {
  config = {
    productionSourceMap: false,
    publicPath: '/demo',
    pages: {
      index: {
        entry: 'src/main.js',
        template: 'public/index.html',
        filename: 'index.html',
        chunks: ['chunk-vendors', 'chunk-common', 'index']
      },
    },
    chainWebpack: (config) => {
      config.resolve.alias
        .set('@', path.resolve('src'))
        .set('~', path.resolve('packages'));
      // config.resolve.symlinks(true)
    },
    configureWebpack: config => {
      // console.log(config);
    },
    css: {
      loaderOptions: {
        sass: {
          // data: `@import '@/assets/css/mixin/_mixin.scss';`
        }
      }
    },
    devServer: {
      overlay: {
        warnings: true,
        errors: true
      },
      open: true, //配置自动启动浏览器
    },
    lintOnSave: process.env.NODE_ENV !== 'production' // 生产构建时禁用 eslint-loader
  };
} else {
  const fs = require('fs');

  const join = path.join;
  const resolve = (dir) => path.join(__dirname, dir);

  const entry = (function () {
    let files = fs.readdirSync(resolve('packages'));
    const componentEntries = files.reduce((ret, item) => {
      const itemPath = join('packages', item);
      const isDir = fs.statSync(itemPath).isDirectory();
      if (isDir) {
        ret[item] = resolve(join(itemPath, 'index.js'));
      }
      return ret;
    }, {});
    return componentEntries;
  })();

  config = {
    productionSourceMap: false,
    outputDir: resolve('lib'),
    chainWebpack: (config) => {
      config.optimization.delete('splitChunks');
      config.plugins.delete('copy');
      config.plugins.delete('preload');
      config.plugins.delete('prefetch');
      config.plugins.delete('html');
      config.plugins.delete('hmr');
      config.entryPoints.delete('app');

      config.resolve.alias
        .set('@', path.resolve('src'))
        .set('~', path.resolve('packages'));

      config.module
        .rule('js')
        .include.add(/packages/).end()
        .use('babel')
        .loader('babel-loader')
        .tap(options => {
          return options;
        });
      
      config.externals({
        'vue': 'vue',
        'vue-router': 'VueRouter'
      });
    },
    lintOnSave: true,
    configureWebpack: {
      entry: entry,
      output: {
        filename: 'Oc[name]/index.js',
        libraryTarget: 'commonjs2',
        libraryExport: 'default',
        library: 'octopus-ui'
      },
      resolve: {
        extensions: ['.js', '.vue', '.json', 'css']
      },
      plugins: [
        new CopyPlugin([
          {
            from: resolve('src/assets/css/mixin/*.scss'),
            to: resolve('lib/mixin'),
            flatten: true
          },
          {
            from: resolve('src/assets/css/theme/*.scss'),
            to: resolve('lib/style/Oc[name].[ext]')
          }
        ]),
        new LodashModulePlugin()
      ]
    },
    css: {
      extract: {
        filename: 'style/Oc[name].css'
      },
      sourceMap: false,
      loaderOptions: {
        // sass: {
        //   data: `@import '@/assets/css/mixin/_mixin.scss';`
        // }
        // css: {
        //   localIdentName: '[name]-[hash]',
        //   camelCase: 'only'
        // }
      },
      // 启用 CSS modules for all css / pre-processor files.
      // modules: false
    },
    devServer: {
      port: 8080,
      open: true
    }
  };
}

module.exports = config;