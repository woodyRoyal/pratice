module.exports = {
  root: true,
  env: {
    node: true
  },
  'extends': [
    'plugin:vue/essential',
    'eslint:recommended',
    '@ued2345'
  ],
  rules: {
    'no-console': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    "no-multiple-empty-lines": [
      1,
      {
        "max": 2
      }
    ],
    "no-mixed-spaces-and-tabs": [
      2,
      "smart-tabs"
    ],
    "semi": [
      2,
      "always"
    ],
    "indent": [
      0,
      4
    ],
    "no-console": "off",
    "no-bitwise": "off"
  },
  plugins: [
    'vue'
  ],
  parserOptions: {
    parser: 'babel-eslint'
  },
  overrides: [{
    files: [
      '**/__tests__/*.{j,t}s?(x)'
    ],
    env: {
      mocha: true
    }
  }]
}