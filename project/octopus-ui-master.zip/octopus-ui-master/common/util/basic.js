export const isDef = val => val !== void 0 && val !== null;
