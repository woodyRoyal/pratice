import LunarPicker from './LunarPicker.vue';
import '@/assets/css/theme/LunarPicker.scss';

LunarPicker.install = function (Vue) {
    Vue.component(LunarPicker.name, LunarPicker);
};

export default LunarPicker;
