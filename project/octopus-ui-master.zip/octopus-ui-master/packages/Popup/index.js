import OcPopup from './Popup.vue';
import '@/assets/css/theme/Popup.scss';

OcPopup.install = (Vue) => {
	Vue.component(OcPopup.name, OcPopup);
};

export default OcPopup;