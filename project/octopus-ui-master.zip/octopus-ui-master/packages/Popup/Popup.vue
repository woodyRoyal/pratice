<template>
    <div v-show="isParentVisible" :class="['oc-popup', alignClass]" :style="styleObject">
        <oc-overlay v-if="hasMask" :visible="visible" :opacity="maskOpacity" :mask-transition-name="maskTransitionName" z-index="-1" :is-lock-scroll="isLockScroll" @mask="maskHandler"></oc-overlay>
        <transition :type="mainTransitionType" :name="mainTransitionName || animationName" @after-leave="afterLeave">
            <div v-show="visible" :class="['oc-popup-inner', dialogClassName]" :style="hasCloseIcon ? 'position: relative' : ''">
                <slot></slot>
                <div v-if="hasCloseIcon" class="oc-popup-close" @click="closeHandler">
                    <oc-icon :name="closeIconName"></oc-icon>
                </div>
            </div>
        </transition>
    </div>
</template>

<script>
// import OcIcon from '../Icon';
import OcOverlay from '../Overlay';
import _ from 'lodash';

const preClass = 'oc-popup';

export default {
    name: 'OcPopup',
    components: {
        // OcIcon,
        OcOverlay
    },
    props: {
        visible: {
            type: Boolean,
            default: false
        },
        zIndex: [Number, String],
        align: {
            type: String,
            default: 'center'
        },
        closeIconName: {
            type: String,
            default: 'cross'
        },
        hasMask: {
            type: Boolean,
            default: true
        },
        maskOpacity: [Number, String],
        hasCloseIcon: {
            type: Boolean,
            default: false
        },
        maskTransitionName: {
            type: String,
            default: 'fade'
        },
        mainTransitionName: {
            type: String,
            default: ''
        },
        mainTransitionType: {
            type: String,
            default: 'animation'
        },
        isLockScroll: {
            type: Boolean,
            default: true
        },
        canCloseByMask: {
            type: Boolean,
            default: false
        },
        dialogClassName: [String, Object]
    },
    data() {
        return {
            isParentVisible: false // 顶层v-if控制变量
        };
    },
    computed: {
        styleObject() {
            if (this.zIndex) {
                return {
                    zIndex: this.zIndex
                };
            }
            return {};
        },
        alignClass() {
            return {
                [`${preClass}-top`]: this.align === 'top',
                [`${preClass}-right`]: this.align === 'right',
                [`${preClass}-bottom`]: this.align === 'bottom',
                [`${preClass}-left`]: this.align === 'left',
            };
        },
        animationName() {
            let name;
            switch(this.align) {
                case 'top':
                    name = 'ocBounceInTop';
                    break;
                case 'right':
                    name = 'ocBounceInRight';
                    break;
                case 'bottom':
                    name = 'ocBounceInBottom';
                    break;
                case 'left':
                    name = 'ocBounceInLeft';
                    break;
                default:
                    name = 'ocBounceIn';
            }
            return name;
        }
    },
    // mounted() {},
    watch: {
        visible: {
            handler(val) {
                if (val) {
                    this.isParentVisible = val;
                    this.$nextTick(() => {
                        this._onShow();
                    });
                }
            },
            immediate: true
        }
    },
    methods: {
        closeHandler: _.throttle(function (e) {
            this.$emit('close', e);
            this._onHide();
        }, 500, {'trailing': false}),
        maskHandler: _.throttle(function (e) {
            this.$emit('mask', e);
            if (this.canCloseByMask) {
                this._onHide();
            }
        }, 500, {'trailing': false}),
        _onShow() {
            this.$emit('show');
        },
        _onHide() {
            this.$emit('update:visible', false);
        },
        afterLeave() {
            this.isParentVisible = false;
            this.$emit('hide');
        }
    }
};
</script>
