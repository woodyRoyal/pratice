import OcSticky from './Sticky.vue';
// import '@/assets/css/theme/Icon.scss';

OcSticky.install = (Vue) => {
  Vue.component(OcSticky.name, OcSticky);
};
export default OcSticky;