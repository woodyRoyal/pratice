import Radio from './Radio.vue';
import '@/assets/css/theme/Radio.scss';

Radio.install = function (Vue) {
    Vue.component(Radio.name, Radio);
};

export default Radio;
