<template>
    <transition>
        <div class="oc-tab-panel hide">
            <slot></slot>
        </div>
    </transition>
</template>
<script>
export default {
    name: 'OcTabPanel',
    props: {},
    data() {
        return {};
    },
    computed: {},
    // mounted() {},
    methods: {}
};
</script>