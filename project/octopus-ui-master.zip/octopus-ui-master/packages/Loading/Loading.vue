<template>
    <div :class="['oc-loading', typeClass, vertical ? 'oc-loading-vertical' : '']">
        <div v-if="name==='googleCircle'" class="oc-loading-inner" :style="styleObject">
            <svg viewBox="25 25 50 50">
                <circle cx="50" cy="50" r="20" fill="none"></circle>
            </svg>
        </div>
        <div v-else-if="name==='spinner'" class="oc-loading-inner" :style="styleObject">
            <svg viewBox='0 0 100 100'>
                <rect width='7' height='20' x='46.5' y='40' fill='currentColor' style="opacity: 1" rx='5' ry='5' transform='translate(0 -30)'/>
                <rect width='7' height='20' x='46.5' y='40' fill='currentColor' style="opacity: .95" rx='5' ry='5' transform='rotate(30 105.98 65)'/>
                <rect width='7' height='20' x='46.5' y='40' fill='currentColor' style="opacity: .90" rx='5' ry='5' transform='rotate(60 75.98 65)'/>
                <rect width='7' height='20' x='46.5' y='40' fill='currentColor' style="opacity: .85" rx='5' ry='5' transform='rotate(90 65 65)'/>
                <rect width='7' height='20' x='46.5' y='40' fill='currentColor' style="opacity: .80" rx='5' ry='5' transform='rotate(120 58.66 65)'/>
                <rect width='7' height='20' x='46.5' y='40' fill='currentColor' style="opacity: .75" rx='5' ry='5' transform='rotate(150 54.02 65)'/>
                <rect width='7' height='20' x='46.5' y='40' fill='currentColor' style="opacity: .70" rx='5' ry='5' transform='rotate(180 50 65)'/>
                <rect width='7' height='20' x='46.5' y='40' fill='currentColor' style="opacity: .65" rx='5' ry='5' transform='rotate(-150 45.98 65)'/>
                <rect width='7' height='20' x='46.5' y='40' fill='currentColor' style="opacity: .60" rx='5' ry='5' transform='rotate(-120 41.34 65)'/>
                <rect width='7' height='20' x='46.5' y='40' fill='currentColor' style="opacity: .55" rx='5' ry='5' transform='rotate(-90 35 65)'/>
                <rect width='7' height='20' x='46.5' y='40' fill='currentColor' style="opacity: .50" rx='5' ry='5' transform='rotate(-60 24.02 65)'/>
                <rect width='7' height='20' x='46.5' y='40' fill='currentColor' style="opacity: .45" rx='5' ry='5' transform='rotate(-30 -5.98 65)'/>
            </svg>
        </div>
        <div v-else-if="name==='circle'" class="oc-loading-inner" :style="styleObject">
            <svg viewBox="0 0 64 64" :style="styleObject">
                <defs>
                    <linearGradient x1="100%" y1="100%" x2="13.4031169%" y2="100%" :id="`${linearId}1`">
                        <stop stop-color="currentColor"></stop>
                        <stop stop-color="currentColor" stop-opacity=".5" offset="100%"></stop>
                    </linearGradient>
                    <linearGradient x1="100%" y1="100%" x2="13.0704753%" y2="100%" :id="`${linearId}2`">
                        <stop stop-color="currentColor" stop-opacity="0"></stop>
                        <stop stop-color="currentColor" stop-opacity=".5" offset="100%"></stop>
                    </linearGradient>
                </defs>
                <g>
                    <path d="M32,2 C48.5685425,2 62,15.4314575 62,32 L54,32 L54,32 C54,19.8497355 44.1502645,10 32,10 C19.8497355,10 10,19.8497355 10,32 L2,32 C2,15.4314575 15.4314575,2 32,2 Z" :fill="`url(#${linearId}1)`"></path>
                    <path d="M32,32 C48.5685425,32 62,45.4314575 62,62 L54,62 L54,62 C54,49.8497355 44.1502645,40 32,40 C19.8497355,40 10,49.8497355 10,62 L2,62 C2,45.4314575 15.4314575,32 32,32 Z" :fill="`url(#${linearId}2)`" transform="translate(32.000000, 47.000000) scale(1, -1) translate(-32.000000, -47.000000)"></path>
                </g>
            </svg>
        </div>
        <oc-icon v-else class="oc-loading-inner" :name="name"></oc-icon>
        <div class="oc-loading-text" v-if="hasText">
            <slot>{{ loadingText }}</slot>
        </div>
    </div>
</template>

<script>
// import Locale from '@/mixins/locale.js';

const preClass = 'oc-loading';

export default {
    name: 'OcLoading',
    // mixins: [Locale],
    props: {
        name: {
            type: String,
            default: 'circle'
        },

        color: String,
        vertical: {
            type: Boolean,
            default: false
        },
        isWhite: {
            type: Boolean,
            default: false
        },
        loadingText: {
            type: String,
            default: '加载中...'
        },
        hasText: {
            type: Boolean,
            default: true
        }
    },
    data() {
        return {};
    },
    computed: {
        styleObject() {
            if (this.color) {
                return {
                    color: this.color
                };
            }
            return {};
        },
        typeClass() {
            const classArr = [`${preClass}-${this.name}`];
            if (this.isWhite) {
                classArr.push(`${preClass}-white`);
            }
            if (typeof this.vertical === 'boolean' && !this.vertical) {
                classArr.push(`${preClass}-small`);
            }
            return classArr;
        },
        linearId() {
            return Math.random().toString(36).slice(-8);
        }
    },
    watch: {
    },
    methods: {}
};
</script>