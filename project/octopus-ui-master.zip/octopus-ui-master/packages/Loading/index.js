import OcLoading from './Loading.vue';
import '@/assets/css/theme/Loading.scss';

OcLoading.install = (Vue) => {
	Vue.component(OcLoading.name, OcLoading);
};

export default OcLoading;