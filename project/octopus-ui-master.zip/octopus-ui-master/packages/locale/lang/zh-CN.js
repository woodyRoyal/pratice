export default {
    dialog: {
      confirm: '确定',
      cancel: '取消'
    },
    loading: '加载中..',
    picker: {
      confirm: '确定',
      cancel: '取消',
      placeholder: '请选择'
    },
    addressPicker: {
      areaEmpty: '请选择地址'
    }
  };