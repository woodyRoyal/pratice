export default {
    dialog: {
      confirm: 'OK',
      cancel: 'Cancel',
    },
    loading: 'Loading...',
    picker: {
      confirm: 'Ok',
      cancel: 'Cancel',
      placeholder: 'Select'
    },
    addressPicker: {
      areaEmpty: 'Select Area'
    }
  };