import Vue from 'vue';
// import { deepAssign } from '../utils/deep-assign';
import defaultMessages from './lang/zh-CN';

const proto = Vue.prototype;
const { defineReactive } = Vue.util;

defineReactive(proto, '$vantLang', 'zh-CN');
defineReactive(proto, '$vantMessages', {
  'zh-CN': defaultMessages
});

function isDef(value) {
  return value !== undefined && value !== null;
}

function isObj(x) {
  const type = typeof x;
  return x !== null && (type === 'object' || type === 'function');
}

function assignKey(to, from, key) {
  const val = from[key];

  if (!isDef(val)) {
    return;
  }

  if (!hasOwnProperty.call(to, key) || !isObj(val) || typeof val === 'function') {
    to[key] = val;
  } else {
    // eslint-disable-next-line no-use-before-define
    to[key] = deepAssign(Object(to[key]), from[key]);
  }
}

function deepAssign (to, from) {
  Object.keys(from).forEach(key => {
    assignKey(to, from, key);
  });

  return to;
}

export default {
  messages() {
    return proto.$vantMessages[proto.$vantLang];
  },

  use(lang, messages) {
    proto.$vantLang = lang;
    this.add(messages);
  },

  add(messages = {}) {
    deepAssign(proto.$vantMessages, messages);
  }
};

// import { get } from '..';

// const camelizeRE = /-(\w)/g;
// function camelize(str) {
//   return str.replace(camelizeRE, (_, c) => c.toUpperCase());
// }

// export function createI18N(name) {
//   const prefix = camelize(name) + '.';

//   return function(path, ...args) {
//     const message = get(locale.messages(), prefix + path) || get(locale.messages(), path);
//     return typeof message === 'function' ? message(...args) : message;
//   };
// }
