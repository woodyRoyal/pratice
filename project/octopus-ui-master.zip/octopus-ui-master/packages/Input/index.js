import Field from './Input.vue';
import '@/assets/css/theme/Input.scss';

Field.install = function (Vue) {
    Vue.component(Field.name, Field);
};

export default Field;
