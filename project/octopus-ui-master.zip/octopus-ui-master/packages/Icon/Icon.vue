<template>
    <div class="oc-icon">
        <img v-if="isUrl" :src="name" />
        <svg v-else aria-hidden="true">
            <use :xlink:href="useName"></use>
        </svg>
    </div>
</template>
<script>
import '@/assets/js/iconfont.js';

export default {
    name: 'OcIcon',
    props: {
        name: {
            type: String,
            default: '',
            valide: true
        }
    },
    data() {
        return {
            isUrl: false
        };
    },
    computed: {
        useName() {
            return `#icon-${this.name}`;
        }
    },
    watch: {
        name: {
            handler() {
                const imgReg = /\.(png|jpe?g|gif|svg)(\?.*)?$/;
                if (imgReg.test(this.name)) {
                    this.isUrl = true;
                } else {
                    // const IMG = new Image();
                    // IMG.onload = () => {
                    //     this.isUrl = true;
                    // };
                    // IMG.onerror = () => {
                    //     this.isUrl = false;
                    // };
                    // IMG.src = this.name;
                    this.isUrl = false;
                }
            },
            immediate: true
        }
    },
    methods: {}
};
</script>