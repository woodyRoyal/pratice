import Tabs from './Tabs.vue';
import '@/assets/css/theme/Tabs.scss';

Tabs.install = function (Vue) {
  Vue.component(Tabs.name, Tabs);
};

export default Tabs;