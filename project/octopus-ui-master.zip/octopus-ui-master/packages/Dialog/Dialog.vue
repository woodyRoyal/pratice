<template>
    <oc-popup
        :visible.sync="isVisible"
        :has-close-icon="hasCloseIcon"
        :can-close-byMask="canCloseByMask"
        :align="align"
        :z-index="zIndex"
        :close-icon-name="closeIconName"
        :has-mask="hasMask"
        :mask-opacity="maskOpacity"
        :maskTransitionName="maskTransitionName"
        :mainTransitionName="mainTransitionName"
        :mainTransitionType="mainTransitionType"
        :is-lock-scroll="isLockScroll"
        :can-close-by-mask="canCloseByMask"
        @show="showHandler"
        @hide="hideHandler"
        @close="closeHandler"
        @mask="maskHandler"
        :class="[this.customClass ? this.customClass : '']"
        :dialog-class-name="dialogClass"
    >
        <slot v-if="isCustom">
            <div :class="[this.contentAlign === 'left' ? 'alingLeft' : '']">{{ this.content }}</div>
        </slot>
        <template v-else>
            <div class="oc-dialog-hd">
                <slot name="title">{{ this.title }}</slot>
            </div>
            <div class="oc-dialog-bd">
                <slot>
                    <div :class="[this.contentAlign === 'left' ? 'alingLeft' : '']">{{ this.content }}</div>
                </slot>
            </div>
            <div class="oc-dialog-ft">
                <a href="javascript:;" v-if="type === 'confirm'" @click="cancelHandler">{{ cancelText }}</a>
                <a href="javascript:;" :class="{'active': isLight ? true : false}" :style="styleObject" @click="confirmHandler">{{ confirmText }}</a>
            </div>
        </template>
    </oc-popup>
</template>

<script>
import OcPopup from '../Popup';
// import Locale from '@/mixins/locale.js';
import _ from 'lodash';

export default {
    name: 'OcDialog',
    components: {
        OcPopup
    },
    // mixins: [Locale],
    props: {
        visible: {
            type: Boolean,
            default: false
        },
        type: {
            type: String,
            default: ''
        },
        title: {
            type: [String, Function],
            default: ''
        },
        customClass: {
            type: String,
            default: ''
        },
        zIndex: [Number, String],
        content: {
            type: [String, Function],
            default: ''
        },
        align: {
            type: String,
            default: 'center'
        },
        contentAlign: {
            type: String,
            default: ''
        },
        cancelText: {
            type: String,
            default: '取消'
        },
        confirmText: {
            type: String,
            default: '确认'
        },
        closeIconName: {
            type: String,
            default: 'cross'
        },
        confirmTextLight: {
            type: [Boolean, String],
            default: false
        },
        hasMask: {
            type: Boolean,
            default: true
        },
        maskOpacity: [Number, String],
        isFunctional: {
            type: Boolean,
            default: false
        },
        maskTransitionName: {
            type: String,
            default: 'fade'
        },
        mainTransitionName: {
            type: String,
            default: ''
        },
        mainTransitionType: {
            type: String,
            default: 'animation'
        },
        isLockScroll: {
            type: Boolean,
            default: true
        },
        onShow: {
            type: [Function, Object],
            default: null
        },
        onHide: {
            type: [Function, Object],
            default: null
        },
        onConfirm: {
            type: [Function, Object],
            default: null
        },
        onCancel: {
            type: [Function, Object],
            default: null
        },
        onClose: {
            type: [Function, Object],
            default: null
        },
        onMask: {
            type: [Function, Object],
            default: null
        },
        canCloseByMask: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            isVisible: false
        };
    },
    computed: {
        isLight() {
            if (typeof this.confirmTextLight === 'boolean') {
                return true;
            }
            return false;
        },
        styleObject() {
            if (!this.isLight) {
                return {
                    color: this.confirmTextLight
                };
            }
            return {};
        },
        isCustom() {
            return this.type !== 'alert' && this.type !== 'confirm';
        },
        dialogClass() {
            return {
                'oc-dialog-alert': this.type === 'alert',
                'oc-dialog-confirm': this.type === 'confirm',
                'oc-dialog-custom': this.isCustom
            };
        },
        hasCloseIcon() {
            if (['alert', 'confirm'].indexOf(this.type) < 0) {
                return true;
            }
            return false;
        }
    },
    watch: {
        visible: {
            handler(val) {
                this.isVisible = val;
            },
            immediate: true
        }
    },
    methods: {
        confirmHandler: _.throttle(function (e) {
            if (this.isFunctional) {
                typeof this.onConfirm === 'function' && this.onConfirm();
            } else {
                this.$emit('confirm', e);
            }
            this._onHide();
        }, 500, {'trailing': false}),
        cancelHandler: _.throttle(function (e) {
            if (this.isFunctional) {
                typeof this.onCancel === 'function' && this.onCancel();
            } else {
                this.$emit('cancel', e);
            }
            this._onHide();
        }, 500, {'trailing': false}),
        closeHandler: _.throttle(function (e) {
            if (this.isFunctional) {
                typeof this.onClose === 'function' && this.onClose();
            } else {
                this.$emit('close', e);
            }
            // 这个方法会触发popup的close，下面的_onHide是为了dialog状态的变更（watch）
            this._onHide();
        }, 500, {'trailing': false}),
        maskHandler: _.throttle(function (e) {
            if (this.isFunctional) {
                typeof this.onMask === 'function' && this.onMask();
            } else {
                this.$emit('mask', e);
            }
            // 这个方法会触发popup的mask，下面的_onHide是为了dialog状态的变更（watch）
            this._onHide();
        }, 500, {'trailing': false}),
        showHandler() {
            if (this.isFunctional) {
                typeof this.onShow === 'function' && this.onShow();
            } else {
                this.$emit('show');
            }
        },
        hideHandler() {
            if (this.isFunctional) {
                this.onHide && this.onHide();
            } else {
                this.$emit('hide');
            }
        },
        _onHide() {
            if (this.isFunctional) {
                this.visible = false;
            } else {
                this.$emit('update:visible', false);
            }
        }
    }
};
</script>