import OcCellGroup from './CellGroup';
import '@/assets/css/theme/CellGroup.scss';

OcCellGroup.install = (Vue) => {
  Vue.component(OcCellGroup.name, OcCellGroup);
};
export default OcCellGroup;