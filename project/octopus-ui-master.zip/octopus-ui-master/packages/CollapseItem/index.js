import CollapseItem from './CollapseItem.vue';
import '@/assets/css/theme/CollapseItem.scss';

CollapseItem.install = function (Vue) {
    Vue.component(CollapseItem.name, CollapseItem);
};

export default CollapseItem;
