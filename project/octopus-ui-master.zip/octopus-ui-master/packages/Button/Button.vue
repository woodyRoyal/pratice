<template>
    <div
        role="button"
        :class="classes"
        :type="nativeType"
        @click="clickHandler"
    >
        <template v-if="loading">
            <oc-icon name="loading"></oc-icon>
            <div>{{ loadingText }}</div>
        </template>
        <template v-else>
            <oc-icon v-if="icon" :name="icon"></oc-icon>
            <div v-if="$slots.default"><slot></slot></div>
        </template>
    </div>
</template>

<script>
import _ from 'lodash';

export default {
    name: 'OcButton',
    props: {
        type: {
            type: String,
            default: 'default'
        },
        nativeType: {
            type: String,
            default: 'button'
        },
        plain: {
            type: Boolean,
            default: false
        },
        block: {
            type: Boolean,
            default: false
        },
        loading: {
            type: Boolean,
            default: false
        },
        loadingText: {
            type: String,
            default: '加载中...'
        },
        disabled: {
            type: Boolean,
            default: false
        },
        round: {
            type: Boolean,
            default: false
        },
        icon: {
            type: String,
            default: ''
        },
        iconPosition: {
            type: String,
            default: 'left'
        },
        size: {
            type: String,
            default: 'normal'
        }
    },
    data() {
        return {};
    },
    // mounted() {},
    computed: {
        classes() {
            return [
                'oc-button',
                `is-${this.type}`,
                `is-${this.size}`,
                `is-position-${this.iconPosition}`,
                {
                    'is-plain': this.plain,
                    'is-block': this.block,
                    'is-disabled': this.disabled,
                    'is-round': this.round,
                    'is-loading': this.loading
                }
            ];
        }
    },
    watch: {},
    methods: {
        clickHandler: _.throttle(function (e) {
            if (this.disabled || this.loading) return;
            this.$emit('click', e);
        }, 500, {'trailing': false})
    }
};
</script>