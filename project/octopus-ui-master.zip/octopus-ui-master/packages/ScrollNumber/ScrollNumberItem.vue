<template>
    <div class="scroll-number-item" :style="numberItemStyle">
        <div class="scroll-number-line" ref="numberItem" :style="style">
            <span class="scroll-number" v-for="item in numLen" :key="item">
                {{item - 1}}
            </span>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'OcScrollNumberItem',
        props: {
            from: {
                type: Number,
                default: 0
            },
            to: {
                type: Number,
                default: 0
            },
            duration: {
                type: Number,
                default: 2000
            },
            speedMode: {
                default: 'duration',
                type: String
            },
            singleLasting: {
                type: Number,
                default: 200
            }
        },
        data() {
            return {
                numberItem: null,
                initNum: this.from,
                numLen: 10
            };
        },
        mounted() {
            this.numberItem = this.$refs.numberItem;
        },
        computed: {
            diff() {
                return this.to - this.initNum;
            },

            originOffset() {
                return this.initNum * this.height / 10;
            },
            height() {
                return this.numberItem && this.numberItem.offsetHeight;
            },
            numberItemStyle() {
                return {
                    height: `${this.height && this.height / this.numLen}px`
                };
            },
            animeDuration() {
                return this.speedMode === 'duration' ? this.duration : Math.abs(this.singleLasting * this.diff);
            },
            style() {
                return {
                    transform: `translateY(${-this.height * this.diff/10}px)`,
                    transition: `transform ease-in-out ${this.animeDuration}ms`,
                    top: `-${this.originOffset}px`
                };
            }
        }
    };
</script>