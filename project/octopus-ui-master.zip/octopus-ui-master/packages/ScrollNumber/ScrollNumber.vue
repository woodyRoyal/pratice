<template>
	<div class="oc-scroll-number">
		<template v-for="(item,index) in numbers" >
			<ScrollNumberItem
				v-if="typeof item.to === 'number'"
				:key="`scroll_number_${index}`"
				:changeFlag="item.changeFlag"
				:speedMode="speedMode"
				:duration="duration"
				:singleLasting="singleLasting"
				:from="item.from"
				:to="item.to" /><slot name="dot"><span class="scroll-dot-item" :key="`dot_${index}`" v-if="item.to === '.'">.</span></slot>
		</template>
	</div>
</template>

<script>
import ScrollNumberItem from './ScrollNumberItem.vue';

export default {
	name: 'OcScrollNumber',
	components: {
		ScrollNumberItem
	},
	props: {
		original: {
			default: '0',
			type: [String, Number]
		},
		current: {
			required: true,
			default: 0,
			type: [Number, String]
		},
		speedMode: {
			type: String,
			default: 'duration'
		},
		singleLasting: {
			type: Number
		},
		duration: {
			type: Number
		}
	},
	computed: {
		numbers() {
			const _current = this.current;
			const _original = this.original;
			const _currArray = (_current + '').split('');
			const _oriArray = (_original + '').split('');
			let changeFlag = false;
			const numberArray = _currArray.map((item, index) => {
				const _from = isNaN(Number(_oriArray[index])) ? _oriArray[index] : Number(_oriArray[index]);
				const _to = isNaN(Number(_currArray[index])) ? _currArray[index] : Number(_currArray[index]);
				if(_from !== _to) changeFlag = true;
				return {
					from: _from,
					to: _to,
					changeFlag: changeFlag
				};
			});
			return [...numberArray];
		}
	},
};
</script>
