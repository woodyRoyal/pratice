import OcOverlay from './Overlay.vue';
import '@/assets/css/theme/Overlay.scss';

OcOverlay.install = (Vue) => {
	Vue.component(OcOverlay.name, OcOverlay);
};

export default OcOverlay;