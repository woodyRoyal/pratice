import OcScroll from './Scroll.vue';
import '@/assets/css/theme/Scroll.scss';

OcScroll.install = (Vue) => {
  Vue.component(OcScroll.name, OcScroll);
};
export default OcScroll;