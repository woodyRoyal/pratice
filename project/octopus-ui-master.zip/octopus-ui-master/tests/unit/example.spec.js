import { expect } from 'chai';
import { mount  } from '@vue/test-utils';

// import Vue from 'vue';
import Button from '~/Button/Button.vue';
import Icon from '~/Icon/Icon.vue';
import Overlay from '~/Overlay/Overlay.vue';
import Popup from '~/Popup/Popup.vue';
import Dialog from '~/Dialog/Dialog.vue';

 mount(Icon);
 mount(Overlay);
 mount(Popup);

// 挂载元素并返回已渲染的文本的工具函数
// function getRenderedText (Component, propsData) {
//   return mount(Component, propsData);
// }

describe('Button', () => {
  it('icon设置right', () => {
    const wrapper = mount(Button, {
      propsData: {
        iconPosition: 'right'
      }
    });
    expect(wrapper.classes('is-position-right')).to.eq(true);
  });
});


describe('Dialog', () => {

  // const wrapper = mount(Dialog, {
  //   confirmText: '确定2',
  //   type: 'alert'
  // });

  it('渲染按钮', () => {
    const wrapper = mount(Dialog, {
      confirmText: '确定2',
      type: 'alert'
    });
    wrapper.vm.$nextTick(() => {
      expect(wrapper.contains('.oc-dialog-ft')).to.eq(true);
    });
    
    // expect(wrapper.html()).contains('<a href="javascript:;">确定2</a>');

    // expect(getRenderedText(Dialog, {
    //   cancelText: '取消2',
    //   type: 'confirm'
    // })).toBe('取消2');
    // expect(wrapper.classes('is-position-right')).to.eq(true);
  });
});
