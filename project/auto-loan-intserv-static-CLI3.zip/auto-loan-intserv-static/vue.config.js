const webpack = require('webpack');
const path = require('path');
const TerserPlugin = require('terser-webpack-plugin');
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
const AddAssetHtmlPlugin = require('add-asset-html-webpack-plugin')
const CompressionWebpackPlugin = require('compression-webpack-plugin');
const glob = require('glob-all');
const PurgecssPlugin = require('purgecss-webpack-plugin');
const productionGzipExtensions = /\.(js|css|json|txt|html|ico|svg)(\?.*)?$/i;
const resolve = (dir) => path.join(__dirname, dir);
const IS_PROD = ['production', 'prod'].includes(process.env.NODE_ENV);
module.exports = {
  publicPath: IS_PROD ? '/' : '/', //如果部署不在是根路径需要做修改
  outputDir: 'auto-loan-intserv-static',
  assetsDir: 'assets',
  lintOnSave: false,
  productionSourceMap: false,
  parallel: require('os').cpus().length > 1,
  devServer: {
    open: true,
    port: 8081,
    proxy: {
      '/autoloan-bus': {
        target: 'http://t1-cdw.2345.com',
        ws: false,
        changOrigin: true, // 是否将请求header中的origin修改为目标地址
        // pathRewrite: {
        //   '^/api': ''
        // }
      },
      '/ucenter': {
        target: 'http://t1-managerdaikuan.2345.com',
        ws: false,
        changOrigin: true, // 是否将请求header中的origin修改为目标地址
      },
    },
    overlay: {
      warnings: true,
      errors: true,
    },
  },
  configureWebpack: (config) => {
    config.resolve.extensions = ['.js', '.vue', '.css', '.json']
    config.plugins.push(
      new webpack.DllReferencePlugin({
        context: process.cwd(),
        manifest: resolve('dll/dll_manifest.json'),
      }),
      new webpack.DllReferencePlugin({
        context: process.cwd(),
        manifest: resolve('dll/element_manifest.json'),
      }),
      new webpack.DllReferencePlugin({
        context: process.cwd(),
        manifest: resolve('dll/vuePolymerizationLib_manifest.json'),
      }),
      new AddAssetHtmlPlugin({
        filepath: resolve('dll/*.js'),
      })
    )
    if (IS_PROD) {
      config.optimization = {
        splitChunks: {
          chunks: 'all',
          minSize: 30000,
          minChunks: 1,
          maxAsyncRequests: 5,
          maxInitialRequests: 3,
          automaticNameDelimiter: '~',
          name: true,
          cacheGroups: {
            vendors: {
              test: /[\\/]node_modules[\\/]/,
              priority: -10,
              name: 'vendors',
            },
            default: {
              minChunks: 2,
              priority: -20,
              reuseExistingChunk: true,
              name: 'commons',
            },
          },
        },
        minimizer: [
          /*eslint camelcase: "off"*/
          new TerserPlugin({
            terserOptions: {
              ecma: undefined,
              warnings: false,
              parse: {},
              compress: {
                drop_console: true,
                drop_debugger: true,
                pure_funcs: ['console.log'], // 移除console
              },
            },
          }),
        ],
      };
      config.plugins.push(
        //开启gzip压缩
        new CompressionWebpackPlugin({
          filename: '[path].gz[query]',
          algorithm: 'gzip',
          test: productionGzipExtensions,
          threshold: 10240,
          minRatio: 0.8,
        }),
        // 去除多余css
        new PurgecssPlugin({
          paths: glob.sync([resolve('src/**/*.vue'), resolve('src/**/*.scss'), resolve('src/**/*.css')]),
          extractors: [
            {
              extractor: class Extractor {
                static extract (content) {
                  const validSection = content.replace(
                    /<style([\s\S]*?)<\/style>+/gim,
                    ''
                  );
                  return validSection.match(/[A-Za-z0-9-_:/]+/g) || [];
                }
              },
              extensions: ['html', 'vue'],
            },
          ],
          whitelist: ['html', 'body'],
          whitelistPatterns: [/el-.*/],
          whitelistPatternsChildren: [/^token/, /^pre/, /^code/],
        })
      );
    }
  },
  chainWebpack: (config) => {
    // 修复HMR
    config.resolve.symlinks(true);
    config
      .plugin('provide')
      .use(webpack.ProvidePlugin, [{
        $: 'jquery',
        jQuery: 'jquery',
        'windows.jQuery': 'jquery',
      }]);
    config.plugin('html').tap(
      (args) => {
        args[0].favicon = resolve('public/favicon.ico')
        return args;
      })

    config.resolve.alias
      .set('@', resolve('src'))
      .set('package', resolve('package.json'))
      .set('src', resolve('src'))
      .set('assets', resolve('src/assets'))
      .set('components', resolve('src/components'))
      .set('views', resolve('src/views'))
      .set('styles', resolve('src/styles'))
      .set('api', resolve('src/api'))
      .set('utils', resolve('src/utils'))
      .set('store', resolve('src/store'))
      .set('router', resolve('src/router'))
      .set('mock', resolve('src/mock'))
      .set('vendor', resolve('src/vendor'))
      .set('static', resolve('static'))
      .set('jquery', 'jquery')
    // 打包分析
    if (process.env.IS_ANALYZ) {
      config.plugin('webpack-report')
        .use(BundleAnalyzerPlugin, [{
          analyzerMode: 'server',
          openAnalyzer: true,
        }]);
    }
    if (IS_PROD) {
      // 压缩图片
      config.module
        .rule('images')
        .use('image-webpack-loader')
        .loader('image-webpack-loader')
        .options({
          mozjpeg: {
            progressive: true,
            quality: 65,
          },
          optipng: {
            enabled: false,
          },
          pngquant: {
            quality: [0.65, 0.90],
            speed: 4,
          },
          gifsicle: {
            interlaced: false,
          },
          webp: {
            quality: 75,
          },
        });
    }
  },
};
