import { dictionaryPost, getTreeArea, getProvince, getSourceTree, getAllPost } from '../../api/commonApi.js'

let cacheAllOption = window.localStorage.getItem('alrAllOption')

if (!cacheAllOption) {
  cacheAllOption = {}
} else {
  cacheAllOption = JSON.parse(cacheAllOption)
}

const dict = {
  state: {
    allPostList: [], // 获取所有岗位
    sourceTree: [], // 获取所有资源树
    provinceCityList: [],
    provinceCityWholeList: [], // 包含全国
    provinceList: [], // 所有省份
    provinceKeyList: [], // 所有省份的key
    dealerAccountBank: cacheAllOption.dealer_account_bank, // 开户银行
    loanTaskType: cacheAllOption.loan_task_type_drop_down, // 放款查询任务类型
    loanTaskTypeDict: cacheAllOption.loanTaskTypeDict || {},
    daihouTaskTypeDict: cacheAllOption.daihouTaskTypeDict || {}, // 贷后任务类型字典
    purposeList: cacheAllOption.purpose, // 购车目的
    tradeCardTypeList: cacheAllOption.trade_card_type, // 交易证件类型
    marriedList: cacheAllOption.married, // 婚姻关系
    educationList: cacheAllOption.education, // 学历
    cardTypeList: cacheAllOption.card_type, // 证件类型
    proposerTitleList: cacheAllOption.proposer_titile, // 申请人职务
    industryList: cacheAllOption.industry, // 所属行业
    natureList: cacheAllOption.nature, // 企业性质
    resideNatureList: cacheAllOption.reside_nature, // 房屋性质
    relativesRelationList: cacheAllOption.relation, // 亲属与客户关系
    bankNameList: cacheAllOption.bank_name, // 开户行
    // selfCreditList: cacheAllOption.self_credit, // 自查征信
    creditChannelList: cacheAllOption.credit_channel, // 征信渠道
    suretyRelationDict: cacheAllOption.suretyRelationDict || {}, // 联系人与申请人关系（申请人信息）
    suretyRelationList: cacheAllOption.surety_relation, // 担保人与申请人关系下拉
    sendBackList: cacheAllOption.send_back, // 退回方式下拉
    contactRelationList: cacheAllOption.contact_relation, // 新增联系人身份下拉
    phoneRelationDict: cacheAllOption.phoneRelationDict || {}, // 电话核实字典
    insuranceCompanyList: cacheAllOption.insurance_company, // 保险公司
    accountType: cacheAllOption.account_type, // 收款方类型
    businessType: cacheAllOption.business_type, // 业务种类
    dealerClass: cacheAllOption.dealer_class, // 经销商等级
    dealerClassDict: cacheAllOption.dealerClassDict || {}, // 经销商等级对象
    depositRate: cacheAllOption.deposit_rate, // 担保比例
    invoiceRate: cacheAllOption.invoice_rate, // 税率
    gpsSupplier: cacheAllOption.gps_supplier, // gps供应商
    storeType: cacheAllOption.store_type, // 店面属性
    loanOrg: cacheAllOption.loan_org, // 放款主体
    storeTypeDict: cacheAllOption.storeTypeDict || {}, // 店面属性对象
    vehiclePropertyList: cacheAllOption.vehicle_property, // 用车性质下拉
    vehiclePropertyDict: cacheAllOption.vehiclePropertyDict || {}, // 用车性质字典
    dealerStaffClass: cacheAllOption.dealer_staff_class, // 账号等级
    dealerStaffClassDict: cacheAllOption.dealerStaffClassDict || {},
    alipay: cacheAllOption.alipay_check_results, // 支付宝
    wechat: cacheAllOption.weChat_check_results, // 微信
    callingResult: cacheAllOption.call_results, // 电联结果
    alipayDict: cacheAllOption.alipayDict || {},
    wechatDict: cacheAllOption.wechatDict || {},
    callingResultDict: cacheAllOption.callingResultDict || {}
  },
  actions: {
    // 省市
    getAreaTree: ({commit, state}, payload) => {
      getTreeArea().then(res => {
        state.provinceCityList = res.data.body
        let provinceCityWholeList = [
          {
            'list': [],
            'name': '全国区域',
            'key': '000'
          }
        ]
        provinceCityWholeList[0].list = res.data.body
        state.provinceCityWholeList = provinceCityWholeList
      })
    },
    // 获取所有省份
    getProvince: ({commit, state}, payload) => {
      getProvince().then(res => {
        state.provinceList = res.data.body
        state.provinceList.forEach((item, index) => {
          state.provinceKeyList[index] = item.tarAddkey
        })
      })
    },
    // 获取所有资源树
    getSourceTree: ({commit, state}, payload) => {
      getSourceTree().then(res => {
        state.sourceTree = res.data.body
      })
    },
    // 获取所有岗位
    getAllPost: ({commit, state}, payload) => {
      getAllPost().then(res => {
        state.allPostList = res.data.body
      })
    },
    // 个人、担保人、企业信息数据字典
    getAllOptions: ({commit, state}, payload) => {
      dictionaryPost({
        category: [
          'loan_org',
          'dealer_staff_class',
          'dealer_account_bank',
          'business_type',
          'dealer_class',
          'account_type',
          'store_type',
          'deposit_rate',
          'invoice_rate',
          'loan_task_type_drop_down',
          'task_type',
          'purpose',
          'trade_card_type',
          'married',
          'education',
          'card_type',
          'proposer_titile',
          'industry', 'nature',
          'reside_nature',
          'relation',
          'bank_name',
          'self_credit',
          'credit_channel',
          'surety_relation',
          'send_back',
          'contact_relation',
          'phone_relation',
          'insurance_company',
          'gps_supplier',
          'vehicle_property',
          'call_results',
          'alipay_check_results',
          'wechat_check_results'
        ]
      }).then(res => {
        let data = res.data.body
        let translationDic = (arr, dict) => {
          arr.forEach(item => {
            dict[item.dictValue] = item.dictName
          })
        }
        state.purposeList = data.purpose
        state.tradeCardTypeList = data.trade_card_type
        state.marriedList = data.married
        state.educationList = data.education
        state.cardTypeList = data.card_type
        state.proposerTitleList = data.proposer_titile
        state.industryList = data.industry
        state.natureList = data.nature
        state.resideNatureList = data.reside_nature
        state.relativesRelationList = data.relation
        state.bankNameList = data.bank_name
        // state.selfCreditList = data.self_credit
        state.creditChannelList = data.credit_channel
        state.suretyRelationList = data.surety_relation
        translationDic(data.surety_relation, state.suretyRelationDict)
        data.suretyRelationDict = state.suretyRelationDict
        state.sendBackList = data.send_back
        state.loanTaskType = data.loan_task_type_drop_down
        state.contactRelationList = data.contact_relation
        translationDic(data.phone_relation, state.phoneRelationDict)
        translationDic(data.loan_task_type_drop_down, state.loanTaskTypeDict)
        data.phoneRelationDict = state.phoneRelationDict
        data.loanTaskTypeDict = state.loanTaskTypeDict
        translationDic(data.task_type, state.daihouTaskTypeDict)
        data.daihouTaskTypeDict = state.daihouTaskTypeDict
        state.insuranceCompanyList = data.insurance_company
        state.gpsSupplier = data.gps_supplier
        state.accountType = data.account_type
        state.businessType = data.business_type
        state.dealerClass = data.dealer_class
        translationDic(data.dealer_class, state.dealerClassDict)
        data.dealerClassDict = state.dealerClassDict
        state.storeType = data.store_type
        translationDic(data.store_type, state.storeTypeDict)
        data.storeTypeDict = state.storeTypeDict
        state.depositRate = data.deposit_rate
        state.invoiceRate = data.invoice_rate
        state.vehiclePropertyList = data.vehicle_property
        state.dealerAccountBank = data.dealer_account_bank
        state.dealerStaffClass = data.dealer_staff_class
        translationDic(data.dealer_staff_class, state.dealerStaffClassDict)
        data.dealerStaffClassDict = state.dealerStaffClassDict
        translationDic(data.vehicle_property, state.vehiclePropertyDict)
        data.vehiclePropertyDict = state.vehiclePropertyDict
        // 支付宝
        data.alipay_check_results.forEach(item => {
          item.selected = false
        })
        state.alipay = data.alipay_check_results
        translationDic(data.alipay_check_results, state.alipayDict)
        data.alipayDict = state.alipayDict
        // 微信
        data.weChat_check_results.forEach(item => {
          item.selected = false
        })
        state.wechat = data.weChat_check_results
        translationDic(data.weChat_check_results, state.wechatDict)
        data.wechatDict = state.wechatDict
        // 电联
        data.call_results.forEach(item => {
          item.selected = false
        })
        state.callingResult = data.call_results
        translationDic(data.call_results, state.callingResultDict)
        data.callingResultDict = state.callingResultDict
        state.loanOrg = data.loan_org
        window.localStorage.setItem('alrAllOption', JSON.stringify(data))
      })
    }
  }
}
export default dict
