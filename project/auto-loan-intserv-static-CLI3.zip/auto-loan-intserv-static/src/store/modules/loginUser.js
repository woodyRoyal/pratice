import { loginByUsername, getUserInfo, loginByUsernameAndToken } from '../../api/login'
import Cookies from 'js-cookie'

/* // 权限树转换为权限数组
function permissionTreeToList (source, target) {
  target.push(source.permission)
  // 递归处理子菜单
  if (source.children && source.children.length > 0) {
    source.children.map(item => permissionTreeToList(item, target))
  }
  return target
} */

// 清除缓存数据
function clearAllCacheData () {
  // 清除本域名下所有cookie数据
  const cookies = Cookies.get()
  for (let key in cookies) {
    Cookies.remove(key)
  }
  // 清除本域名下所有localStorage数据
  const storage = window.localStorage
  storage.clear()
}

// 登录成功，用户所有信息和后端返回的菜单信息存储在localStorage中
let cacheUser = window.localStorage.getItem('Alr-User') // 用户所有信息
const cacheMenu = window.localStorage.getItem('Alr-Menu') // 后端返回的菜单信息
if (!cacheUser) {
  cacheUser = {
    id: '',
    username: '',
    displayName: '',
    token: ''
  }
} else {
  cacheUser = JSON.parse(cacheUser)
}

const loginUser = {
  state: {
    userId: cacheUser.id, // 用户id
    token: Cookies.get('Alr-Token'), // 登录成功后，前端自定义的token
    username: cacheUser.username, // 用户登录名
    displayName: cacheUser.displayName, // 用户显示名
    authority: Cookies.get('authority'), // 权限
    serviceNum: Cookies.get('serviceNum'), // 坐席号用户拨打软电话
    menuList: cacheMenu ? JSON.parse(cacheMenu) : [] // 后端返回的菜单信息
  },

  mutations: {
    SET_USER_ID: (state, userId) => {
      state.userId = userId
    },
    SET_TOKEN: (state, token) => {
      state.token = token
      Cookies.set('Alr-Token', token)
    },
    SET_USERNAME: (state, username) => {
      state.username = username
      Cookies.set('Alr-Username', username)
    },
    SET_DISPLAY_NAME: (state, displayName) => {
      state.displayName = displayName
    },
    SET_AUTHORITY: (state, authority) => {
      state.authority = authority
      Cookies.set('authority', authority)
    },
    SET_SERVICENUM: (state, serviceNum) => {
      state.serviceNum = serviceNum
      Cookies.set('serviceNum', serviceNum)
    },
    SET_MENU_LIST: (state, resourceTree) => {
      state.menuList = resourceTree
      window.localStorage.setItem('Alr-Menu', JSON.stringify(resourceTree))
    },
    LOGOUT_USER: state => {
      state.userId = ''
      state.token = ''
      state.username = ''
      state.displayName = ''
      state.authority = ''
      state.serviceNum = ''
      state.menuList = []
    }
  },

  actions: {
    // 作为独立系统的登录，不从互金后台进
    LoginByUsername ({dispatch, commit}, userInfo) {
      const username = userInfo.username.trim()
      return new Promise((resolve, reject) => {
        loginByUsername(username, userInfo.password, userInfo.captchaKey, userInfo.systemCode, userInfo.captchaCode).then(response => {
          const res = response.data
          if (res.respCode === '1000') {
            dispatch('GetUserInfo').then(() => { resolve() }).catch(error => { resolve(error.message) })
          } else {
            resolve(res.respMsg)
          }
        }).catch(error => { reject(error) })
      })
    },
    // 从互金后台进入，以username、token登录
    LoginByUsernameAndToken ({dispatch, commit}, {user}) {
      commit('LOGOUT_USER') // 重置登录信息
      commit('CLEAR_ROUTERS') // 清除路由
      console.log(user)
      return new Promise((resolve, reject) => {
        // resolve()  // 不要登录
        // 登录
        loginByUsernameAndToken(user.username, user.token).then(response => {
          console.log(response)
          const res = response.data
          if (res.respCode === '1000') {
            dispatch('GetUserInfo').then(() => { resolve() }).catch(error => { resolve(error.message) })
          } else {
            resolve(res.respMsg)
          }
        }).catch(error => {
          reject(error)
        })
      })
    },
    // 获取用户信息
    GetUserInfo ({commit, dispatch}) {
      return new Promise((resolve, reject) => {
        if (!(document.cookie || navigator.cookieEnabled)) window.alert('Cookie已被禁用')
        getUserInfo().then(response => {
          const {resourceTree, username, id, kind, serviceNum, displayName} = response.data.body
          if (response.data.respCode === '1000') {
            if (!resourceTree || resourceTree.length === 0) throw new Error('没有可访问的资源')
            window.localStorage.setItem('Alr-User', JSON.stringify(response.data.body)) // 存储登录成功返回的所有信息
            commit('SET_USER_ID', id) // 存储用户userId
            commit('SET_TOKEN', username + '_' + id) // 前端自定义token
            commit('SET_USERNAME', username) // 存储username
            commit('SET_DISPLAY_NAME', displayName) // 储存显示名
            commit('SET_AUTHORITY', kind) // 存储最大岗位权限
            commit('SET_SERVICENUM', serviceNum) // 存储坐席号
            commit('SET_MENU_LIST', resourceTree) // 存储菜单
            dispatch('getAreaTree') // 获取地区数据接口
            dispatch('getAllOptions') // 获取其他下拉框数据接口
          }
          resolve(response)
        }).catch(error => {
          reject(error)
        })
      })
    },
    // 拦截器登出到login
    FilterLogout ({commit}) {
      return new Promise(resolve => {
        commit('LOGOUT_USER')
        commit('CLEAR_ROUTERS')
        // 先清除缓存
        clearAllCacheData()
        resolve()
      })
    },
    // 重置
    ResetMsg ({commit}) {
      commit('LOGOUT_USER')
      commit('CLEAR_ROUTERS')
      // 先清除缓存
      clearAllCacheData()
    },
    // 刷新页面
    RefreshLoad ({dispatch, commit}) {
      let user = {
        username: Cookies.get('UC-Username'),
        token: Cookies.get('UC-Token')
      }
      return new Promise((resolve, reject) => {
        loginByUsernameAndToken(user.username, user.token).then(response => {
          const res = response.data
          if (res.respCode === '1000') {
            commit('SET_TOKEN', user.token)
            commit('SET_USERNAME', user.username)
            resolve()
          } else {
            resolve(res.message)
          }
        }).catch(error => {
          reject(error)
        })
      })
    }
  }
}

export default loginUser
