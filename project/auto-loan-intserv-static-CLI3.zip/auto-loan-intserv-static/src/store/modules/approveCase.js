const approveCase = {
  state: {
    applyId: null,
    applyType: null,
    storeCapital: ''
  },
  mutations: {
    CHANGE_APPLYID_APPLYTYPE: (state, payload) => {
      state.applyId = payload.applyId
      state.applyType = payload.applyType
    },
    CHANGE_CAPITAL: (state, payload) => {
      state.storeCapital = payload.capital
    }
  },
  actions: {
    saveApplyIdApplyType: ({commit, state}, payload) => {
      commit('CHANGE_APPLYID_APPLYTYPE', {applyId: payload.applyId, applyType: payload.applyType})
    },
    saveCaseCapital: ({commit, state}, payload) => {
      commit('CHANGE_CAPITAL', payload)
    }
  }
}

export default approveCase
