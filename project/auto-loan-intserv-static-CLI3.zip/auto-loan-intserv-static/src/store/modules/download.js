import {downLoadPolling, reportDownloadPolling} from '../../api/daihou' // 轮询接口通用
import { Notification } from 'element-ui'
const qs = require('qs')
const downloadParam = {
  operationReportTimer: null,
  operationReportNotification: null,
  approveResultTimer: null,
  approveResultNotification: null,
  applyProgressTimer: null,
  applyProgressNotification: null,
}
const downloadStore = {
  state: {
    operationDownloadLoading: false,
    approveResultDownloadLoading: false,
    applyProgressDownloadLoading: false,
    spDownloadLoading: false,
    depositDownloadLoading: false,
  },
  mutations: {
    CHANGE_LOADING_STATUS: (state, payload) => {
      const {moduleName, value} = payload
      state[moduleName] = value
    },
  },
  actions: {
    downloadPollingApi ({dispatch, commit}, payload) {
      const {serialNo, timer, notification, loading} = payload

      commit('CHANGE_LOADING_STATUS', {moduleName: loading, value: true}) // 按钮loading

      downloadParam[notification] = Notification({
        title: '下载提示',
        message: '后台数据生成中',
        type: 'success',
        duration: 0,
      }) // 提示

      return new Promise((resolve, reject) => {
        clearInterval(downloadParam[timer])
        downloadParam[timer] = null

        downloadParam[timer] = setInterval(() => {
          downLoadPolling(serialNo).then((res) => {
            const {respCode, body} = res.data
            if (respCode === '1000') {
              const {status, filename, storePath} = body
              if (status) {
                clearInterval(downloadParam[timer])
                downloadParam[timer] = null

                downloadParam[notification].close()

                commit('CHANGE_LOADING_STATUS', {moduleName: loading, value: false})

                window.location.href = process.env.VUE_APP_BASE_API + '/download/export?' + qs.stringify({filename, storePath})
                resolve(1)
              }
            } else {
              clearInterval(downloadParam[timer])
              downloadParam[timer] = null

              downloadParam[notification].close()

              commit('CHANGE_LOADING_STATUS', {moduleName: loading, value: false})
              reject(respCode)
            }
          }).catch((err) => {
            clearInterval(downloadParam[timer])
            downloadParam[timer] = null

            downloadParam[notification].close()

            commit('CHANGE_LOADING_STATUS', {moduleName: loading, value: false})
            reject(err)
            console.error(err)
          })
        }, 1000)
      })
    },
    reportDownloadPollingApi ({dispatch, commit}, payload) {
      const {reportKey, serialNo, timer, notification, loading} = payload

      commit('CHANGE_LOADING_STATUS', {moduleName: loading, value: true}) // 按钮loading

      downloadParam[notification] = Notification({
        title: '下载提示',
        message: '后台数据生成中',
        type: 'success',
        duration: 0,
      }) // 提示

      return new Promise((resolve, reject) => {
        clearInterval(downloadParam[timer])
        downloadParam[timer] = null

        downloadParam[timer] = setInterval(() => {
          reportDownloadPolling(reportKey, serialNo).then((res) => {
            const {respCode, body} = res.data
            if (respCode === '1000') {
              const {status, filename, storePath} = body
              if (status) {
                clearInterval(downloadParam[timer])
                downloadParam[timer] = null

                downloadParam[notification].close()

                commit('CHANGE_LOADING_STATUS', {moduleName: loading, value: false})

                window.location.href = process.env.VUE_APP_BASE_API + '/download/export?' + qs.stringify({filename, storePath})
                resolve(1)
              }
            } else {
              clearInterval(downloadParam[timer])
              downloadParam[timer] = null

              downloadParam[notification].close()

              commit('CHANGE_LOADING_STATUS', {moduleName: loading, value: false})
              reject(respCode)
            }
          }).catch((err) => {
            clearInterval(downloadParam[timer])
            downloadParam[timer] = null

            downloadParam[notification].close()

            commit('CHANGE_LOADING_STATUS', {moduleName: loading, value: false})
            reject(err)
            console.error(err)
          })
        }, 1000)
      })
    },
  },
}

export default downloadStore
