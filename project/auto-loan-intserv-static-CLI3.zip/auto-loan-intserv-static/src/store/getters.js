const getters = {
  pkg: state => state.pkg,
  sidebar: state => state.app.sidebar,
  visitedViews: state => state.app.visitedViews,

  // 登陆用户信息
  userId: state => state.loginUser.userId,
  username: state => state.loginUser.username,
  displayName: state => state.loginUser.displayName,
  token: state => state.loginUser.token,
  authority: state => state.loginUser.authority,
  serviceNum: state => state.loginUser.serviceNum, // 坐席號
  roleList: state => state.loginUser.roleList,
  menuList: state => state.loginUser.menuList,
  permissionList: state => state.loginUser.permissionList,
  systemList: state => state.loginUser.systemList,
  // 菜单权限
  permissionRouters: state => state.permission.routers,
  addRouters: state => state.permission.addRouters,
  menuPathList: state => state.permission.menuPathList,

  // applyid
  applyId: state => state.approveCase.applyId,
  // applyType
  applyType: state => state.approveCase.applyType,
  // 案件资方
  storeCapital: state => state.approveCase.storeCapital,

  // 放款任务类型
  loanTaskType: state => state.dict.loanTaskType,
  loanTaskTypeDict: state => state.dict.loanTaskTypeDict,
  // 贷后任务类型
  daihouTaskTypeDict: state => state.dict.daihouTaskTypeDict,
  // 省市
  provinceCityList: state => state.dict.provinceCityList,
  // 所有省份
  provinceList: state => state.dict.provinceList,
  // 所有省份的key值
  provinceKeyList: state => state.dict.provinceKeyList,
  // 包含全国
  provinceCityWholeList: state => state.dict.provinceCityWholeList,
  // 电话联系人身份字典
  phoneRelationDict: state => state.dict.phoneRelationDict,
  // 新增联系人下拉
  contactRelationList: state => state.dict.contactRelationList,
  // 婚姻
  marriedList: state => state.dict.marriedList,
  // 学历
  educationList: state => state.dict.educationList,
  // 证件类型
  cardTypeList: state => state.dict.cardTypeList,
  // 申请人职务
  proposerTitleList: state => state.dict.proposerTitleList,
  // 所属行业
  industryList: state => state.dict.industryList,
  // 企业性质
  natureList: state => state.dict.natureList,
  // 房屋性质
  resideNatureList: state => state.dict.resideNatureList,
  // 亲属与客户关系
  relativesRelationList: state => state.dict.relativesRelationList,
  // 开户行
  bankNameList: state => state.dict.bankNameList,
  // 征信渠道
  creditChannelList: state => state.dict.creditChannelList,
  // 申请人联系人的关系
  suretyRelationDict: state => state.dict.suretyRelationDict,
  // 担保人与申请人关系下拉
  suretyRelationList: state => state.dict.suretyRelationList,
  // 购车目的
  purposeList: state => state.dict.purposeList,
  // 交易证件类型
  tradeCardTypeList: state => state.dict.tradeCardTypeList,
  // 退回方式
  sendBackList: state => state.dict.sendBackList,
  // gps厂商
  gpsSupplier: state => state.dict.gpsSupplier,
  // 保险公司
  insuranceCompanyList: state => state.dict.insuranceCompanyList,
  // 收款方类型
  accountType: state => state.dict.accountType,
  // 业务种类
  businessType: state => state.dict.businessType,
  // 经销商等级
  dealerClass: state => state.dict.dealerClass,
  // 经销商等级对象
  dealerClassDict: state => state.dict.dealerClassDict,
  // 担保比例
  depositRate: state => state.dict.depositRate,
  // 税率
  invoiceRate: state => state.dict.invoiceRate,
  // 店面属性
  storeType: state => state.dict.storeType,
  // 放款主体
  loanOrg: state => state.dict.loanOrg,
  // 店面属性对象
  storeTypeDict: state => state.dict.storeTypeDict,
  // 开户银行
  dealerAccountBank: state => state.dict.dealerAccountBank,
  // 账号等级
  dealerStaffClass: state => state.dict.dealerStaffClass,
  dealerStaffClassDict: state => state.dict.dealerStaffClassDict,
  // 新窗口大图片
  bigImgSrc: state => state.app.bigImgSrc,
  // 用车性质
  vehiclePropertyList: state => state.dict.vehiclePropertyList,
  // 用车性质字典
  vehiclePropertyDict: state => state.dict.vehiclePropertyDict,
  // 支付宝
  alipay: state => state.dict.alipay,
  // 微信
  wechat: state => state.dict.wechat,
  // 电联结果
  callingResult: state => state.dict.callingResult,
  // 支付宝字典
  alipayDict: state => state.dict.alipayDict,
  // 微信字典
  wechatDict: state => state.dict.wechatDict,
  // 电联字典
  callingResultDict: state => state.dict.callingResultDict,
  // 资源树
  sourceTree: state => state.dict.sourceTree,
  // 获取所有岗位
  allPostList: state => state.dict.allPostList,
  // 运营信息表下载按钮是否禁用
  operationDownloadLoading: state => state.downloadStore.operationDownloadLoading,
  // 申请进度查询下载按钮是否禁用
  applyProgressDownloadLoading: state => state.downloadStore.applyProgressDownloadLoading,
  // sp台账下载
  spDownloadLoading: state => state.downloadStore.spDownloadLoading,
  // 保证金台账
  depositDownloadLoading: state => state.downloadStore.depositDownloadLoading
}
export default getters
