import Vue from 'vue'
import Vuex from 'vuex'
import app from './modules/app'
import loginUser from './modules/loginUser'
import permission from './modules/permission'
import approveCase from './modules/approveCase' // 审批
import dict from './modules/dictionary' // 字典
import downloadStore from './modules/download' // 下载
import getters from './getters'

Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    app,
    loginUser,
    permission,
    approveCase,
    dict,
    downloadStore
  },
  getters
})

export default store
