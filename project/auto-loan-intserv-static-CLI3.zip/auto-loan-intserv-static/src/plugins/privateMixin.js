export default {
  data () {
    return {
      loading: false,
      tableData: [],
      tableTotal: 0,
    }
  },
  methods: {
    queryResetForm () {
      if (this.queryForm) {
        for (const key in this.queryForm) {
          this.queryForm[key] = ''
        }
      }
    },
  },
}
