<template>
  <div>
    <div class="imgList">
      <div v-for="(item, index) in pictureList" :key="index" class="fileupload-outer-wrap">
        <ul class="img-list-wrap" ref="imgListWrap">
          <!--文件list-->
          <li v-for="(k, i) in item.fileRecordVOList" :key="i" class="img-item-wrap">
            <a :href="k.filePathname" target="_blank" @click.prevent="fileView(k)">
              <img :src="k.filePathname" :alt="k.name" :type="k.fileType" v-if="checkFileType(k.fileType)">
              <img src="../../assets/fileImg.png" :alt="k.name" :type="k.fileType" v-else>
            </a>
            <span>{{k.name}}</span>
          </li>
          <!--历史记录不需要显示上传按钮-->
          <li class="upload-whole-btn" @click="trigger(item.dictKey)" v-if="+history !== 1">
            <!--上传logo-->
            <span>
                <i class="el-icon-upload"></i>
                <strong>将文件拖到此处，或点击上传，支持批量上传</strong>
              </span>
            <!--文件上传区域-->
            <div class="dropArea" @drop="dropHandle($event, item.dictKey)" @dragover="dragoverHandle($event)" @dragenter="dragenterHandle($event)"></div>
            <!--文件上传按钮-->
            <input :ref="item.dictKey" :class='item.dictKey' type="file" name="upload"  multiple='multiple' @change="dropHandle($event, item.dictKey)" />
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
  import { UPLOAD_URL } from '../../api/commonApi.js'
  import PictureView from 'viewerjs'
  import 'viewerjs/dist/viewer.css'
  const qs = require('qs')
  export default {
    props: ['pictureList', 'history'],
    data () {
      return {
        viewer: null
      }
    },
    methods: {
      // 触发弹窗
      trigger (v) {
        this.$refs[v][0].value = '' // 先清空上次的值
        this.$refs[v][0].click()
      },
      // 拖拽上传
      dropHandle (e, v) {
        e.preventDefault()
        this.fileUpload(e, v)
      },
      dragOverHandle (e) { e.preventDefault() },
      // 移入
      dragEnterHandle (e) { e.preventDefault() },
      // 文件上传主要代码
      fileUpload (e, v) {
        let fileList = e.target.files || e.dataTransfer.files // 点击上传和拖拽上传获取文件的方式不一样
        // FileList 数据类型
        Array.prototype.forEach.call(fileList, file => {
          let fd = new FormData()
          fd.append('inputStream', file)
          fd.append('fileCategory', v)
          let xhr = new XMLHttpRequest()
          xhr.onreadystatechange = () => {
            if(xhr.status === 200 && xhr.readyState === 4) {
              if (JSON.parse(xhr.response).respCode === '1000') {
                let data = JSON.parse(xhr.response).body
                this.pictureList.forEach(item => {
                  if (item.dictKey === data.fileCategory) {
                    data.relatedGroup = 'repayment_book_file'
                    this.$emit('savePicItem', ({item, data}))
                  }
                })
              } else {
                this.$message.warning(JSON.parse(xhr.response).respMsg)
              }
            } else if (xhr.status !== 200 && xhr.readyState === 4){
              this.$message.warning('上传失败')
            }
          }
          xhr.open('post', UPLOAD_URL, true)
          xhr.send(fd)
        })
      },
      // 校验是否是图片
      checkFileType (val) {
        if (/^jpg$/i.test(val) || /^jpeg$/i.test(val) || /^png$/i.test(val)) {
          return 1
        } else {
          return 0
        }
      },
      // 预览
      fileView (imgItem) {
        let checkArr = ['jpg', 'jpeg', 'bmp', 'png', 'JPG', 'PNG', 'JPEG', 'BMP']
        if (checkArr.indexOf(imgItem.fileType) > -1) {
          let viewDom = this.$refs.imgListWrap[0]
          this.viewer = new PictureView(viewDom, {
            filter (img) {
              return (img.complete && (checkArr.indexOf(img.getAttribute('type')) > -1))
            },
            hidden () {
              this.viewer.destroy()
            },
            ready () {
              this.viewer.update()
            },
            transition: false
          })
        } else {
          // 非图片文件，文件下载
          window.location.href = process.env.VUE_APP_BASE_API + '/fileStoreClient/downloadFile?' + qs.stringify({filePathName: imgItem.filePathname, id: imgItem.id || null})
        }
      }
    }
  }
</script>

<style scoped lang="scss">
</style>
