/**
* 网页电话组件
* Created by zuo on 2018/1/10.
*/

<template>
  <div>
    <!-- 最小化窗口时显示 -->
    <div id="callsip-minimize" class="minimize" :class="{'calling': callStatus === '3'}" v-show="isMinimized">
      <div @click="handleRestoreDialog" title="还原">
        <i class="iconfont" :class="[callStatus === '3' ? 'icon-webrtcing' : 'icon-webrtc']"></i>
        <span>{{ callTime }}</span>
      </div>
    </div>
    <!-- 还原窗口时显示 -->
    <div id="callsip-restore" class="restore" v-show="!isMinimized">
      <!--<div class="title" @mousedown="handleMousedown('callsip-restore', $event)">-->
      <div class="title">
        <h2>网络电话 <i :class="registerStatusClass" :title="RegisterStatusMap[registerStatus]"></i></h2>
        <div class="zoom" @click="handleSmallDialog" title="最小化">
          <i class="el-icon-minus"></i>
        </div>
      </div>
      <div class="content">
        <audio id="local-audio" muted="muted"></audio>
        <audio id="remote-audio"></audio>
        <!--通话中-->
        <div v-if="callStatus === '3'" title="点击挂断" class="hangup">
          <a @click="hangup"><i class="iconfont icon-guaduan"></i></a>
        </div>
        <!--通话结束-->
        <div v-else-if="callStatus === '4'">
          <a @click="hangup"><i class="iconfont icon-keyitonghua grey"></i></a>
        </div>
        <!--已注册-->
        <div v-else>
          <a @click="hangup"><i class="iconfont icon-keyitonghua"></i></a>
        </div>
        <div class="status-desc" :class="{'red': callStatus === '3'}">{{ CallStatusMap[callStatus] }}<span
          v-if="callStatus === '4'" class="dotting"></span>
        </div>
      </div>
      <!--<div style="text-align: center; font-size: 14px;">{{ currentIP }}</div>-->
      <div style="text-align: right; font-size: 14px;">{{ callTime }}</div>
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { fetchFreeSwitchDomains } from '../../api/caseHandle'

  // 注册状态
  const RegisterStatusMap = {
    '-2': '注册失败',
    '-1': '未注册',
    '0': '已注册',
  }

  // 通话状态
  const CallStatusMap = {
    '0': '无通话',
    '1': '新建通话',
    '2': '拨号中',
    '3': '通话中',
    '4': '通话结束'
  }
  export default {
    computed: {
      ...mapGetters([ 'serviceNum']),
      registerStatusClass () {
        if (this.registerStatus === '0') {
          return 'el-icon-success green'
        } else if (this.registerStatus === '-2') {
          return 'el-icon-error red'
        } else {
          return 'el-icon-warning yellow'
        }
      }
    },
    data () {
      return {
        // serviceNum: 'S1003',
        callTime: '00:00', // 计时
        timeOut: null, // 定时器
        isMinimized: true, // 是否最小化
        RegisterStatusMap, // callSip对象的注册状态
        CallStatusMap, // callSip对象的通话状态

        registerStatus: '-1', // callSip对象的注册状态
        callStatus: '0', // callSip对象的通话状态

        callSipMap: null, // 多个实例 ip为key sip对象为value
        currentIP: '', // 当前通话的ip
        freeswitchIPList: null, // 多个freeswitch外呼地址列表
        freeswitchDomainList: null // 多个freeswitch外呼域名列表
      }
    },
    mounted () {
      this.checkBrowserVersion()
      // 刷新、关闭页面提醒
      window.onbeforeunload = function () {
        event.returnValue = '确定离开当前页面吗？'
      }
      // 启用HTML5 Notification 桌面通知功能
      /* if (window.Notification && window.Notification.permission !== 'denied') {
        window.Notification.requestPermission()
      } */
      // 获取freeswitchIP域名列表
      this.getFreeSwitchDomainList()
    },
    methods: {
      checkBrowserVersion () {
        const userAgent = navigator.userAgent //取得浏览器的userAgent字符串
        let isOpera = userAgent.indexOf('Opera') > -1 //判断是否Opera浏览器
        let isIE = userAgent.indexOf('compatible') > -1 && userAgent.indexOf('MSIE') > -1 && !isOpera //判断是否IE浏览器
        if (isIE) {
          window.alert('此浏览器不支持网络电话功能')
        }
      },
      // 获取freeswitchIP对应的域名列表
      getFreeSwitchDomainList () {
        fetchFreeSwitchDomains()
          .then(response => {
            console.log('获取freeswitchIP对应的域名列表')
            let res = response.data
            if (res.respCode === '1000' && res.body) {
              this.freeswitchDomainList = res.body
              this.initCallSip()
              console.log(this.freeswitchDomainList)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 初始化注册CallSip
      initCallSip () {
        const local = document.getElementById('local-audio')
        const remote = document.getElementById('remote-audio')
        // 根据ip创建多个实例
        if (this.freeswitchDomainList && this.freeswitchDomainList.length > 0) {
          this.callSipMap = {}
          for (let item of this.freeswitchDomainList) {
            console.log('new CallSip...freeswitchIP: ' + item + ', serviceNum: ' + this.serviceNum)
            // 密码统一
            // 最后一个参数 是否开启wss
            this.callSipMap[item] = process.env.NODE_ENV === 'production'
              ? new CallSip(item, this.serviceNum, 'cb0b2a75DKW1', local, remote, true)
              : new CallSip(item, this.serviceNum, '1234', local, remote, true)
            // 最后一个参数 是否开启wss
            // this.callSipMap[item] = new CallSip(item, this.serviceNum, '1234', local, remote, true)
          }
        }
        // 将多个实例注册
        if (this.callSipMap) {
          for (let key in this.callSipMap) {
            this.callSipMap[key].register(this.registerSuccess, this.registerFailed)
            this.callSipMap[key].addListener(this.newCallback, this.ringingCallback, this.connectedCallback, this.endedCallback)
          }
        }
      },
      // 注册成功回调
      registerSuccess (ip) {
        this.registerStatus = '0'
        console.log('%c' + ip + ': register success!', 'color: green')
      },
      // 注册失败回调
      registerFailed (ip) {
        this.registerStatus = '-2'
        console.log('%c' + ip + ': register failed!', 'color: red')
      },
      // 新建通话回调
      newCallback (ip) {
        console.log('%c' + ip + ': newCallback success!', 'color: blue')
        this.callStatus = '1'
        clearInterval(this.timeOut)
        this.time_fun()
        /* if (window.Notification.permission === 'granted') {
          let n = new window.Notification('通知', {
            body: '您有一个新电话!',
            icon: 'http://bpic.588ku.com/element_origin_min_pic/17/10/31/73ada91fac9d8e1aa7d3d5a3d821937c.jpg'
          })
        } */
      },
      ringingCallback (ip) {
        console.log('%c' + ip + ': ringingCallback success!', 'color: blue')
        this.callStatus = '2'
        this.currentIP = ip
      },
      // 通话连接成功回调
      connectedCallback (ip) {
        console.log('%c' + ip + ': connectedCallback success!', 'color: blue')
        this.callStatus = '3'
        this.currentIP = ip
      },
      // 通话结束回调
      endedCallback (ip) {
        console.log('%c' + ip + ': endedCallback success!', 'color: blue')
        this.callStatus = '4'
        clearInterval(this.timeOut)
        // 设置当前电话状态
        // this.$store.dispatch('GetCurrentCallStatus', 'STATUS_END_CALL')
      },
      // 挂断电话
      hangup () {
        this.callStatus = '4'
        // 设置当前电话状态
        // this.$store.dispatch('GetCurrentCallStatus', 'STATUS_END_CALL')
        let currentSip = this.callSipMap[this.currentIP]
        if (currentSip) {
          currentSip.hangup()
          console.log(this.currentIP + ': hangup!')
        }
      },
      // 缩小窗口
      handleSmallDialog () {
        this.isMinimized = true
      },
      // 还原窗口
      handleRestoreDialog () {
        this.isMinimized = false
      },
      // 拖拽
      handleMousedown (elementId, event) {
        let box = document.getElementById(elementId)
        let e = event || window.event
        let x = e.clientX - box.offsetLeft
        let y = e.clientY - box.offsetTop
        if (x >= 0 && y >= 0) {
          document.onmousemove = function (even) {
            let ev = even || window.event
            let cx = document.documentElement.clientWidth || document.body.clientWidth
            let ch = document.documentElement.clientHeight || document.body.clientHeight
            box.style.top = ev.clientY - y + 'px'
            box.style.left = ev.clientX - x + 'px'
            if (ev.clientX - x < 0) {
              box.style.left = 0
            } else if (ev.clientX - x > cx - box.offsetWidth) {
              box.style.left = cx - box.offsetWidth + 'px'
            }
            if (ev.clientY - y < 0) {
              box.style.top = 0
            } else if (ev.clientY > ch - box.offsetHeight) {
              box.style.top = ch - box.offsetHeight + 'px'
            }
            // 兼容IE6-8  阻止默认事件
            if (box.setCapture) {
              box.setCapture()
            }
          }
          document.onmouseup = function () {
            document.onmousemove = null
            document.onmouseup = null
            // 释放阻止事件
            if (box.releaseCapture) {
              box.releaseCapture()
            }
          }
        }
        return false
      },
      two_char (n) {
        return n >= 10 ? n : '0' + n
      },
      time_fun () {
        let _this = this
        let sec = 0
        this.callTime = '00:00'
        this.timeOut = setInterval(function () {
          sec++
          let date = new Date(0, 0)
          date.setSeconds(sec)
          let m = date.getMinutes()
          let s = date.getSeconds()
          _this.callTime = _this.two_char(m) + ':' + _this.two_char(s)
        }, 1000)
      }
    }
  }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  .minimize {
    width: 42px;
    height: 68px;
    position: fixed;
    z-index: 2100;
    right: 18%;
    bottom: 0;
    color: #324157;
    .status-desc0 {
      cursor: move;
    }
    .iconfont {
      cursor: pointer;
      font-size: 40px;
    }
  }

  .calling {
    color: #F56C6C;
  }

  .restore {
    width: 180px;
    height: 120px;
    position: fixed;
    /* 通话弹窗 应该超出弹窗 el-dialog 2001  蒙层 maskDiv 2002 */
    z-index: 2100;
    right: 18%;
    bottom: 0;
    color: #333;
    font-size: 20px;
    border: 1px solid #EBEEF5;
    border-radius: 2px;
    background-color: #EBEEF5;
    box-shadow: 0 1px 3px rgba(0, 0, 0, .3);
    .title {
      /*cursor: move;*/
      position: relative;
      margin: 5px;
      font-size: 14px;
      h2 {
        font-size: 14px;
        height: 27px;
        line-height: 24px;
        border-bottom: 1px solid #A1B4B0;
      }
      .zoom {
        position: absolute;
        top: 2px;
        right: 0;
        font-size: 14px;
        width: 30px;
        height: 100%;
        cursor: pointer;
        text-align: center;
      }
    }
    .content {
      display: flex;
      justify-content: center;
      align-items: center;
      .status-desc {
        margin-left: 5px;
      }
      .iconfont {
        font-size: 40px;
        color: #303133;
      }
      .hangup {
        .iconfont {
          color: #F56C6C;
        }
        .iconfont:hover {
          font-size: 46px;
        }
      }
    }
  }

  .red {
    color: #F56C6C;
  }

  .grey {
    color: #C0C4CC;
  }

  .green {
    color: #67C23A;
  }

  .yellow {
    color: #E6A23C;
  }

  /* CSS3 实现点点点loading动画 start */
  .dotting {
    display: inline-block;
    width: 10px;
    min-height: 2px;
    padding-right: 2px;
    border-left: 2px solid currentColor;
    border-right: 2px solid currentColor;
    background-color: currentColor;
    background-clip: content-box;
    box-sizing: border-box;
    animation: dot 4s infinite step-start both;
  }

  .dotting:before {
    content: '...';
  }

  /* IE8 */
  .dotting::before {
    content: '';
  }

  :root .dotting {
    margin-left: 2px;
    padding-left: 2px;
  }

  /* IE9+ */
  @keyframes dot {
    25% {
      border-color: transparent;
      background-color: transparent;
    }
    /* 0个点 */
    50% {
      border-right-color: transparent;
      background-color: transparent;
    }
    /* 1个点 */
    75% {
      border-right-color: transparent;
    }
    /* 2个点 */
  }

  /* CSS3 实现点点点loading动画 end */
</style>
