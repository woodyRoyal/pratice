/**
* Created by zuo on 2017/8/18.
* APlayer：https://www.npmjs.com/package/aplayer  https://aplayer.js.org/docs/#/
*/

<template>
  <el-tooltip :content="content" placement="bottom" effect="light">
    <div>{{label}}</div>
  </el-tooltip>
</template>

<script type="text/ecmascript-6">
  export default {
    props: {
      content: {
        type: String,
        default: ''
      },
      label: {
        type: String,
        default: ''
      }
    }
  }

</script>

<style lang="scss" rel="stylesheet/scss" scoped>

</style>
