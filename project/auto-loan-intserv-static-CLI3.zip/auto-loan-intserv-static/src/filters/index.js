import Moment from 'moment'
function replacepos (text, start, stop, replacetext) {
  if (stop) {
    let startStr = text.substring(0, start)
    let endStr = text.substring(stop)
    return startStr + replacetext + endStr
  } else {
    return replacetext + text.substring(start + 1)
  }
}
function replacMaxNumber (text, replacetext) {
  let startStr = text.substring(0, 4)
  let endStr = text.substring(text.length - 4)
  let replaceStr = ''
  for (let i = 0; i < text.length - 8; i++) {
    replaceStr = replaceStr + replacetext
  }
  return startStr + replaceStr + endStr
}
function pluralize (time, label) {
  if (time === 1) {
    return time + label
  }
  return time + label + 's'
}
export function timeAgo (time) {
  const between = Date.now() / 1000 - Number(time)
  if (between < 3600) {
    return pluralize(~~(between / 60), ' minute')
  } else if (between < 86400) {
    return pluralize(~~(between / 3600), ' hour')
  } else {
    return pluralize(~~(between / 86400), ' day')
  }
}
// 日期格式化
export function parseTime (value, pattern) {
  if (!value) {
    return ''
  }
  if (typeof value === 'string') {
    value = new Date(value)
  }
  pattern = pattern || 'YYYY-MM-DD HH:mm:ss'
  return Moment(value).format(pattern)
}

export function formatTime (time, option) {
  time = +time * 1000
  const d = new Date(time)
  const now = Date.now()

  const diff = (now - d) / 1000

  if (diff < 30) {
    return '刚刚'
  } else if (diff < 3600) { // less 1 hour
    return Math.ceil(diff / 60) + '分钟前'
  } else if (diff < 3600 * 24) {
    return Math.ceil(diff / 3600) + '小时前'
  } else if (diff < 3600 * 24 * 2) {
    return '1天前'
  }
  if (option) {
    return parseTime(time, option)
  } else {
    return d.getMonth() + 1 + '月' + d.getDate() + '日' + d.getHours() + '时' + d.getMinutes() + '分'
  }
}

/* 数字 格式化 */
export function nFormatter (num, digits) {
  const si = [
    {value: 1E18, symbol: 'E'},
    {value: 1E15, symbol: 'P'},
    {value: 1E12, symbol: 'T'},
    {value: 1E9, symbol: 'G'},
    {value: 1E6, symbol: 'M'},
    {value: 1E3, symbol: 'k'}
  ]
  for (let i = 0; i < si.length; i++) {
    if (num >= si[i].value) {
      return (num / si[i].value + 0.1).toFixed(digits).replace(/\.0+$|(\.[0-9]*[1-9])0+$/, '$1') + si[i].symbol
    }
  }
  return num.toString()
}

export function html2Text (val) {
  const div = document.createElement('div')
  div.innerHTML = val
  return div.textContent || div.innerText
}

export function toThousandslsFilter (num) {
  return (+num || 0).toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')
}

/**
 * 秒转为 天小时分秒
 * @param sec
 * @return
 */
export function formatSecond (seconds) {
  if (seconds === 0) {
    return '0秒'
  }
  if (!seconds) {
    return '-'
  }
  if (isNaN(seconds)) {
    return '-'
  }
  let sec = parseInt(seconds)
  let timeStr = sec + '秒'
  if (sec > 60) {
    let second = sec % 60
    let min = parseInt(sec / 60)
    timeStr = min + '分' + second + '秒'
    if (min > 60) {
      min = parseInt(sec / 60) % 60
      let hour = parseInt(sec / 3600)
      timeStr = hour + '小时' + min + '分' + second + '秒'
      if (hour > 24) {
        hour = parseInt(sec / 3600) % 24
        let day = parseInt(sec / 3600 / 24)
        timeStr = day + '天' + hour + '小时' + min + '分' + second + '秒'
      }
    }
  }
  return timeStr
}

/**
 * 毫秒转为 天小时分秒
 * @param millisecond
 * @return
 */
export function formatMillisecond (millisecond) {
  if (millisecond === 0) {
    return '0秒'
  }
  if (!millisecond) {
    return '-'
  }
  if (isNaN(millisecond)) {
    return '-'
  }
  let sec = parseInt(millisecond / 1000)
  let timeStr = sec + '秒'
  if (sec > 60) {
    let second = sec % 60
    let min = parseInt(sec / 60)
    timeStr = min + '分' + second + '秒'
    if (min > 60) {
      min = parseInt(sec / 60) % 60
      let hour = parseInt(sec / 3600)
      timeStr = hour + '小时' + min + '分' + second + '秒'
      if (hour > 24) {
        hour = parseInt(sec / 3600) % 24
        let day = parseInt(sec / 3600 / 24)
        timeStr = day + '天' + hour + '小时' + min + '分' + second + '秒'
      }
    }
  }
  return timeStr
}
// 过滤姓名
export function formatName (value, type) {
  if (value) {
    return replacepos(value, 0, 0, '*')
  } else {
    if (type) {
      return value
    } else {
      return '/'
    }
  }
}

// 手机号
export function formatPhone (value, type) {
  if (value) {
    let valueStr = value + ''
    return replacepos(valueStr, 3, 7, '****')
  } else {
    if (type) {
      return value
    } else {
      return '/'
    }
  }
}

// 银行卡/身份证
export function formatPapers (value, type) {
  if (value) {
    let valueStr = value + ''
    return replacMaxNumber(valueStr, '*')
  } else {
    if (type) {
      return value
    } else {
      return '/'
    }
  }
}
// 判断哪个选择哪个字段
export function selectField (str, original) {
  if (str && str.indexOf('*') > -1) {
    return original
  } else {
    return str
  }
}

// 数字保留两位
export function twoFloat (value) {
  let val = Math.round(parseFloat(Number(value)) * 100) / 100
  let s = val.toString().split('.')
  if (s.length === 1) {
    val = val.toString() + '.00'
    return val
  }
  if (s.length > 1) {
    if (s[1].length < 2) {
      val = val.toString() + '0'
    }
    return val
  }
}

/**
 * 0：未完成 1：已失败 2：已过期 3：报告获取中 4：已完成
 * @param msg
 * @return
 */
export function statusToMsg (status) {
  switch (Number(status)) {
  case 0:
    return '未完成'
  case 1:
    return '已失败'
  case 2:
    return '已过期'
  case 3:
    return '报告获取中'
  case 4:
    return '已完成'
  }
}
