import { Message } from 'element-ui';
import { UPLOAD_URL } from '@/api/commonApi.js'
/**
 * 上传通用函数
 * 入参必须是对象
 * @param url
 * @param file
 * @return promise
 */
export function fileUpload (o) {
  return new Promise((resolve, reject) => {
    let fd = new FormData()
    const { url = UPLOAD_URL, ...arg } = o
    Object.keys(arg).forEach((k) => {
      fd.append(k, arg[k])
    })
    let xhr = new XMLHttpRequest()
    xhr.onreadystatechange = () => {
      if (xhr.status === 200 && xhr.readyState === 4) {
        let res = JSON.parse(xhr.response)
        if (res.respCode === '1000') {
          resolve(res.body)
        } else {
          Message.error(res.respMsg || '上传图片失败请重新上传');
          reject(res)
        }
      } else if (xhr.status !== 200 && xhr.readyState === 4) {
        Message.error('上传图片失败请重新上传');
        reject(xhr)
      }
    }
    xhr.open('post', url, true)
    xhr.send(fd)
  })

}
