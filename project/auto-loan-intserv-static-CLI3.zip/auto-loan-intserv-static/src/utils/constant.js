export const LEASETYPE = {
  0: '回租',
  1: '直租'
}
export const CARTYPE = {
  0: '新车',
  1: '二手车'
}
export const APPLYTYPE = {
  0: '个人',
  1: '企业'
}
export const APPLYTYPES = {
  1: '个人',
  2: '企业',
  3: '挂靠'
}
export const CAPITAL = {
  'EX-XW': '新网',
  'EX-ZB': '众邦',
  'EX-UNION-ZB': '众邦联合'
}
export const FUNDREPAYTYPE = {
  10: '强制代偿',
  7: '强制结清',
  9: '代偿',
  8: '结清'
}
/* eslint-disable */
// 价格格式化
export function fmoney (s, n) {
  if(/^([0-9]+|[0-9]{1,3}(,[0-9]{3})*)(.[0-9]{1,2})?$/.test(s) && ((s + '').indexOf(",") > -1)){
    return s
  } else if (/^[0-9]+(.[0-9]+)?$/.test(s)) {
    n = n > 0 && n <= 20 ? n : 2;
    s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + "";
    var l = s
        .split(".")[0]
        .split("")
        .reverse(),
      r = s.split(".")[1],
      t = "";
    for (var i = 0; i < l.length; i++) {
      t += l[i] + ((i + 1) % 3 == 0 && i + 1 != l.length ? "," : "");
    }
    return (
      t
        .split("")
        .reverse()
        .join("") +
      "." +
      r
    );
  } else {
    return '0.00';
  }
}

// 金额恢复
export function rmoney(val) {
  val = val + ''
  if(/^([0-9]+|[0-9]{1,3}(,[0-9]{3})*)(.[0-9]{1,2})?$/.test(val)){
    if (val.indexOf(",")) {
      let a = val.split(".");
      if (a[1] === "00") {
        val = a[0].split(",").join("");
      } else {
        a[1] = a[1].slice(0, 2);
        a[0] = a[0].split(",").join("");
        val = a.join(".");
      }
    } else {
      let b = val.split(".");
      if (b[1] === "00") {
        val = b[0];
      } else {
        b[1] = b[1].slice(0, 2);
        val = b.join(".");
      }
    }
    return val;
  }else {
    return '0'
  }
}

// 乘法精度丢失
export function accMul(arg1,arg2) {
  var m=0,s1=arg1.toString(),s2=arg2.toString();
  try{m+=s1.split(".")[1].length}catch(e){}
  try{m+=s2.split(".")[1].length}catch(e){}
  return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m)
}
/* eslint-enable */

// 合同号正则
export const contractNoReg = /^(?=.*[a-z])(?=.*\d)(?=.*[_])[^]*$/

// 电话号码正则
export const phoneRegxp = /^1[0-9]{10}$/

// 车架号正则
export const vinRegXp = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{17}$/

// 身份证正则
export const idCardRegxp = {
  regxp1: /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/,
  regxp2: /^[1-9]\d{5}\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{2}[0-9Xx]$/
}

// 校验查询form applyId
export function checkApplyId (val, item, no = 8) {
  let rex = new RegExp(`^\\d{${no}}$`)
  if (val && (!rex.test(val))) {
    this.$message.warning('申请编号输入有误')
    if (item && this.queryData[item]) {
      this.queryData[item] = null
    } else {
      if (this.queryData.applyId) this.queryData.applyId = null
      if (this.queryData.oldApplyId) this.queryData.oldApplyId = null
      if (this.queryData.applyNum) this.queryData.applyNum = null
      if (this.queryData.applyDisplayId) this.queryData.applyDisplayId = null
    }
  } else if (val === '' && item) {
    this.queryData[item] = null
  }
}

// 客户还款卡变更 校验查询form applyId
export function checkCustomerApplyId (val) {
  if (val && (!/^\d{8}$/.test(val))) {
    this.$message.warning('输入有误')
    this.queryData.applyId = null
    if (this.queryData.applyNum) this.queryData.applyNum = null
  }
}

// 校验查询form 手机号
export function checkQueryPhone (val) {
  if (val && (!phoneRegxp.test(val))) {
    this.$message.warning('手机号输入有误')
    if (this.queryData.customPhone) this.queryData.customPhone = null
  }
}

/* // 校验合同号
export function checkContractNum (val) {
  if (val && (!/^(?=.*[a-z])(?=.*\d)(?=.*[_])[^]*$/.test(val))) {
    this.$message.warning('输入有误')
    this.queryData.contractNum = null
    if (this.queryData.contractNo) this.queryData.contractNo = null
  }
} */

/* // 校验车架号
export function checkCarvin (val) {
  if (val && (!vinRegXp.test(val))) {
    this.$message.warning('输入有误')
    this.queryData.carVin = null
  }
} */

// 更改文件格式
export function changePicFileType (fileName) {
  const ldot = fileName.lastIndexOf('.') + 1
  const fileRealName = fileName.substring(0, ldot)
  return fileRealName + 'jpg'
}

// 文件删除回调
const nameDict = {
  'fault_file_request_loan': '请款的误传文件',
  'fault_file_post_loan': '贷后误传文件',
  'fault_file': '误传文件'
}
const categoryDescDict = {
  'other_file': '其他文件',
  'request_loan_attachment': '请款附件',
  'post_loan_upload': '贷后附件'
}
export function deleteFileApiCallback (deleteCbParam) {
  const {_vue, relatedId, fileData, dictCategory, dictKey} = deleteCbParam
  let imgItem = JSON.parse(JSON.stringify(fileData.imgItem))
  imgItem.relatedId = relatedId
  imgItem.relatedGroup = dictCategory
  imgItem.fileCategory = dictKey
  let faultFileExists = false
  let otherFileExists = false
  let forEachData = fileData.isRequired ? _vue.requiredFilesList : _vue.notRequiredFilesList
  // 删除指定文件
  forEachData.forEach(item => {
    item.pictureListVOList.forEach(item => {
      if (item.dictKey === fileData.imgItem.fileCategory) item.fileRecordVOList.splice(fileData.index, 1)
    })
  })
  // 风控上传文件、放款上传文件、申请提报不需要添加至误传文件中
  if (dictKey !== 'risk_upload_file' && dictKey !== 'operate_upload_file' && dictKey !== 'identity_file') {
    if (_vue.notRequiredFilesList.length) {
      // 遍历是否有误传文件
      _vue.notRequiredFilesList.forEach(item => {
        item.pictureListVOList.forEach(k => {
          if (k.dictKey === dictKey) faultFileExists = !faultFileExists
        })
      })
      if (faultFileExists) { // 有误传文件
        _vue.notRequiredFilesList.forEach(item => {
          item.pictureListVOList.forEach(k => {
            if (k.dictKey === dictKey) k.fileRecordVOList.push({...imgItem})
          })
        })
      } else { // 无误传文件
        // 遍历是否有父类
        _vue.notRequiredFilesList.forEach(item => {
          // 有父类，添加含有删除文件的误传文件子类
          if (item.dictCategory === dictCategory) {
            item.pictureListVOList.push({
              dictKey,
              fileRecordVOList: [{...imgItem}],
              name: nameDict[dictKey]
            })
            otherFileExists = !otherFileExists
          }
        })
        // 无父类，添加整体
        if (!otherFileExists) {
          _vue.notRequiredFilesList.push({
            categoryDesc: categoryDescDict[dictCategory],
            dictCategory,
            pictureListVOList: [{
              dictKey,
              fileRecordVOList: [{...imgItem}],
              name: nameDict[dictKey]}]
          })
        }
      }
    } else {
      _vue.notRequiredFilesList.push({
        categoryDesc: categoryDescDict[dictCategory],
        dictCategory,
        pictureListVOList: [{
          dictKey,
          fileRecordVOList: [{...imgItem}],
          name: nameDict[dictKey]}]
      })
    }
  }
}
