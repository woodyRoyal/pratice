<template>
  <div class="history-wrap" ref="historyWrap">
    <div>
      <div class="tableTitle clearfix">
        <span class="table-title-word">审批历史记录</span>
      </div>
      <el-table :data="approveData" border style="width: 100%">
        <el-table-column label="序号" prop="num" width="50%"></el-table-column>
        <el-table-column label="审批节点" prop="nodeDesc"></el-table-column>
        <el-table-column label="审批结果" prop="resultsDesc"></el-table-column>
        <el-table-column label="审批编码" prop="codeDesc"></el-table-column>
        <el-table-column label="审批备注" prop="internalRemindContent"></el-table-column>
        <el-table-column label="经销商提醒" prop="dealerRemindContent"></el-table-column>
        <el-table-column label="SP操作提醒" prop="remarks"></el-table-column>
        <el-table-column label="审批人员" prop="approveRole"></el-table-column>
        <el-table-column label="操作人姓名" prop="approveUserName"></el-table-column>
        <el-table-column label="审批时间" prop="created"></el-table-column>
      </el-table>
      <div class="clearfix">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="page.pageNum" :page-sizes="page.pageSizeArr"
                       :page-size="page.pageSize"
                       layout="total, sizes, prev, pager, next, jumper"
                       :total="page.total"
                       class="pagination">
        </el-pagination>
    </div>
    </div>
    <div>
      <div class="tableTitle clearfix">
        <span class="table-title-word">历史关联申请</span>
      </div>
      <el-table :data="applyRelateListData" border style="width: 100%">
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="申请编号">
          <template slot-scope="scope">
            {{scope.row.relateApplyDisplayId}}
            <el-tag type="warning" size="mini" v-if="scope.row.specialPermit">特批</el-tag>
            <el-tag type="warning" size="mini" v-if="scope.row.reconsideration">复议</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="申请类型">
          <template slot-scope="scope">
            {{scope.row.relateApplyType === 1 ? '企业' : '个人'}}
          </template>
        </el-table-column>
        <el-table-column label="客户名称" prop="relateCustomerName"></el-table-column>
        <el-table-column label="申请日期" prop="relateApplyTime"></el-table-column>
        <el-table-column label="提报店名称" prop="relateDealerName"></el-table-column>
        <el-table-column label="申请状态" prop="relateCurrentStatus"></el-table-column>
        <el-table-column label="当前节点" prop="relateCurrentNode"></el-table-column>
        <el-table-column label="与此案件匹配字段">
          <template slot-scope="scope">
            <ul>
              <li v-for="(item, index) in scope.row.relateMatchInfoList" :key="index">{{item}}</li>
            </ul>
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="text" @click="toDetailInfoHandle(scope.row)" v-if="scope.row.own">查看详情</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="clearfix">
        <el-pagination @size-change="handleApplyRelateSizeChange" @current-change="handleApplyRelateCurrentChange" :current-page="applyRelatePage.pageNum" :page-sizes="applyRelatePage.pageSizeArr"
                       :page-size="applyRelatePage.pageSize"
                       layout="total, sizes, prev, pager, next, jumper"
                       :total="applyRelatePage.total"
                       class="pagination">
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
  import {approveHistory, applyRelateList} from '../../api/approveHistory'
  import {mapGetters} from 'vuex'
  export default {
    data () {
      return {
        approveData: [],
        applyRelateListData: [],
        page: {
          pageNum: 1,
          pageSize: 10,
          pageSizeArr: [10, 20, 30, 40],
          total: 0
        },
        applyRelatePage: {
          pageNum: 1,
          pageSize: 10,
          pageSizeArr: [10, 20, 30, 40],
          total: null
        }
      }
    },
    mounted () {
      this.getApproveHistoryList()
      this.getApplyRelateList()
      this.autoTableMaxHeight()
      window.addEventListener('resize', this.autoTableMaxHeight)
    },
    destroyed () { window.removeEventListener('resize', this.autoTableMaxHeight) },
    computed: {
      ...mapGetters(['applyId'])
    },
    methods: {
      getApproveHistoryList () {
        let data = {applyId: this.applyId, pageNum: this.page.pageNum, pageSize: this.page.pageSize}
        approveHistory(data).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body.list
            if (data.length) {
              this.page.total = res.data.body.total
              data.forEach((item, index) => {
                item.num = (this.page.total - (this.page.pageSize * (this.page.pageNum - 1))) - index
              })
              this.approveData = data
            }
          }
        }).catch(error => { console.log(error) })
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.getApproveHistoryList()
      },
      handleCurrentChange (val) {
        this.page.pageNum = val
        this.getApproveHistoryList()
      },
      getApplyRelateList () {
        applyRelateList({applyId: this.applyId, pageNum: this.applyRelatePage.pageNum, pageSize: this.applyRelatePage.pageSize}).then(res => {
          if (res.data.respCode === '1000') {
            this.applyRelateListData = res.data.body.list
            this.applyRelatePage.total = res.data.body.total
          }
        }).catch(err => { console.log(err) })
      },
      handleApplyRelateSizeChange (val) {
        this.applyRelatePage.pageSize = val
        this.getApplyRelateList()
      },
      handleApplyRelateCurrentChange (val) {
        this.applyRelatePage.pageNum = val
        this.getApplyRelateList()
      },
      toDetailInfoHandle (val) {
        if (+val.own === 1) window.open(`#/apply-progress-detail/${val.relateApplyId}/${val.relateApplyType}`)
      },
      autoTableMaxHeight () {
        let clientH = document.documentElement.clientHeight
        this.$refs.historyWrap.style.height = (clientH - 60) + 'px'
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import "style.scss";
  .history-wrap{
    display: flex;
    flex-direction: column;
    overflow-y: auto;
  }
  .pagination{
    float: right;
  }
  .history_Apply{
    margin-top: 10px;
  }
  .readStatus{
    font-size: 14px;
    margin-bottom: 7px;
  }
  .readStatus-title{
    font-size: 16px;
  }
</style>
