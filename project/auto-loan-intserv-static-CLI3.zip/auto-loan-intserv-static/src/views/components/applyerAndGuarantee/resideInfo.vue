<template>
  <div class="resideWrap">
    <div class="formModuleTitle"><span>居住信息</span></div>
    <el-form label-position="top" size="mini">
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="现居住所在省份-城市">
            <el-cascader disabled :options="provinceCityList" v-model="resideInfo.newProvinceCity" :props="props"></el-cascader>
          </el-form-item>
        </el-col>
        <el-col :span="16">
          <el-form-item label="居住详细地址">
            <el-input disabled v-model="resideInfo.address"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="户籍地省份-城市">
            <el-cascader disabled :options="provinceCityList" v-model="resideInfo.newFamilyProvinceCity" :props="props"></el-cascader>
          </el-form-item>
        </el-col>
        <el-col :span="16">
          <el-form-item label="户籍地详细地址">
            <el-input disabled v-model="resideInfo.familyAddress"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  export default {
    props: ['resideInfo'],
    data () {
      return {
        rowGutter: 10,
        colSpan: 8,
        props: {
          value: 'key',
          label: 'name',
          children: 'list'
        } // 省份城市配置
      }
    },
    computed: {
      ...mapGetters(['provinceCityList', 'resideNatureList'])
    }
  }
</script>

<style lang="scss" scoped>
  @import "../style";
</style>
