<template>
  <div class="occupationWrap">
    <div class="formModuleTitle"><span>职业信息</span></div>
    <el-form label-position="top" size="mini" :model="occupationalInfo">
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="单位名称">
            <el-input disabled v-model="occupationalInfo.companyName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="单位所在地省份-城市">
            <el-cascader disabled :options="provinceCityList" v-model="occupationalInfo.newProvinceCity" :props="props"></el-cascader>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="单位详细地址">
            <el-input disabled v-model="occupationalInfo.address"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan" v-if="occupationalInfo.industry !== null">
          <el-form-item label="公司行业">
            <el-select disabled v-model="occupationalInfo.industry">
              <el-option v-for="(item, index) in industryList" :key="index" :label="item.dictName" :value="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="单位电话">
            <el-input disabled v-model="occupationalInfo.tel"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan"></el-col>
        <el-col :span="colSpan"></el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  export default {
    props: ['occupationalInfo'],
    data () {
      return {
        rowGutter: 10,
        colSpan: 8,
        props: {
          value: 'key',
          label: 'name',
          children: 'list'
        } // 省份城市配置
      }
    },
    mounted () {},
    computed: {
      ...mapGetters(['provinceCityList', 'proposerTitleList', 'industryList', 'natureList'])
    }
  }
</script>

<style lang="scss" scoped>
  @import "../style";
</style>
