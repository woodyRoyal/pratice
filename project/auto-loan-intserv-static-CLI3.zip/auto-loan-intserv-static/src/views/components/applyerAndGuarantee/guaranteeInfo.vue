<template>
  <div class="moduleWrap" ref="moduleWrap">
    <div v-if="tabList.length === 0" class="no-guarantee-hint">该申请人无担保人信息</div>
    <el-tabs v-model="activeName" @tab-click="tabClick">
      <el-tab-pane v-for="(item,index) in tabList" :key="item.name" :label="item.name" :name="(index + 1) + ''">
        <relationWithApplyer :proposerSuretyInfo="proposerSuretyInfo"></relationWithApplyer>
        <basicInfo :basicInfo="basicInfo"></basicInfo>
        <occupationInfo :occupationalInfo="occupationalInfo"></occupationInfo>
        <resideInfo :resideInfo="resideInfo"></resideInfo>
        <relationInfo :relationInfo="relationInfo" v-if="basicInfo.married === 1 || basicInfo.married === 5"></relationInfo>
        <creditInfo :creditInfo="creditInfo"></creditInfo>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
  import relationWithApplyer from './relationWithApplyer'
  import basicInfo from './basicInfo'
  import occupationInfo from './occupationInfo'
  import resideInfo from './resideInfo'
  import relationInfo from './relationInfo'
  import creditInfo from './creditInfo'
  import {getGuaranteeInfo} from '../../../api/formInfo.js'
  import { tabList } from '../../../api/commonApi'
  import {mapGetters} from 'vuex'
  export default {
    data () {
      return {
        tabList: [],
        activeName: '1',
        proposerSuretyInfo: {
          relation: null
        },
        basicInfo: {
          name: '',
          cardType: null,
          cardId: '',
          sex: null,
          birth: '',
          age: null,
          licenceIssuing: null,
          expiryDateStart: '',
          isExpiryDateEndLong: '',
          expiryDateEnd: '',
          married: null,
          phone: '',
          race: '',
          education: null,
          academicDegree: null
        },
        occupationalInfo: {
          companyName: '',
          tel: '',
          industry: null,
          newProvinceCity: [],
          address: ''
        },
        resideInfo: {
          newProvinceCity: [],
          address: '',
          newFamilyProvinceCity: [],
          familyAddress: ''
        },
        relationInfo: {
          name: '',
          relation: null,
          cardId: '',
          phone: '',
          selfCredit: null,
          compaynName: ''
        },
        creditInfo: {
          creditChannel: null
        },
        clientHeight: null
      }
    },
    mounted () {
      this.getTabList()
      this.autoHeight()
      window.addEventListener('resize', this.autoHeight)
    },
    destroyed () {
      window.removeEventListener('resize', this.autoHeight)
    },
    components: {
      relationWithApplyer,
      basicInfo,
      occupationInfo,
      resideInfo,
      relationInfo,
      creditInfo
    },
    computed: {
      ...mapGetters(['applyId', 'applyType'])
    },
    methods: {
      getTabList () {
        tabList({applyId: this.applyId}).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            if (+this.applyType !== 1) {
              this.tabList = data.filter(item => {
                if (item.type >= 2) return item
              })
            } else {
              this.tabList = data.filter(item => {
                if (item.type >= 2 || item.type === 0) return item
              })
            }
            if (this.tabList.length) {
              const id = this.tabList[0].id
              this.getSingleGuaranteeInfo(id)
            }
          }
        }).catch(error => { console.log(error) })
      },
      getSingleGuaranteeInfo (id) {
        getGuaranteeInfo(id).then(res => {
          if (res.data.respCode === '1000') {
            const {proposerVO, proposerSuretyInfoVO, occupationalInfoVO, resideVO, relativesVO, creditVO} = res.data.body
            if (proposerVO.expiryDateEnd === '长期') {
              proposerVO.isExpiryDateEndLong = '长期'
              proposerVO.expiryDateEnd = ''
            } else {
              proposerVO.isExpiryDateEndLong = '非长期'
            }
            this.proposerSuretyInfo = proposerSuretyInfoVO
            proposerVO.name = proposerVO.name
            proposerVO.cardId = proposerVO.cardId
            proposerVO.phone = proposerVO.phone
            this.basicInfo = proposerVO
            occupationalInfoVO.newProvinceCity = [occupationalInfoVO.province, occupationalInfoVO.city]
            occupationalInfoVO.tel = occupationalInfoVO.tel
            this.occupationalInfo = occupationalInfoVO
            resideVO.newProvinceCity = [resideVO.province, resideVO.city]
            resideVO.newFamilyProvinceCity = [resideVO.familyProvince, resideVO.familyCity]
            this.resideInfo = resideVO
            this.relationInfo = relativesVO
            this.creditInfo = creditVO
          }
        })
      },
      tabClick (tab) {
        const tabLab = tab.label
        this.tabList.forEach(item => {
          if (tabLab === item.name) {
            this.getSingleGuaranteeInfo(item.id)
          }
        })
      },
      autoHeight () {
        const clientHeight = document.documentElement.clientHeight
        this.$refs['moduleWrap'].style.height = (clientHeight - 55) + 'px'
      }
    }
  }
</script>

<style lang="scss" scoped>
  .moduleWrap{
    overflow-y: auto;
    overflow-x: hidden;
  }
  .no-guarantee-hint{
    text-align: center;
    color: #409eff;
    font-size: 36px;
    font-weight: 700;
    margin-top: 50px;
  }
</style>
