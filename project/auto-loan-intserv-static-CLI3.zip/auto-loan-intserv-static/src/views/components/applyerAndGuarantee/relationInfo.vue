<template>
  <div>
    <div class="formModuleTitle"><span>亲属或配偶信息</span></div>
    <div class="relationInfoWrap">
      <el-form label-position="top" size="small">
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="姓名">
              <el-input disabled v-model="relationInfo.name"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="与申请人关系">
              <el-select v-model="relationInfo.relation" disabled>
                <el-option v-for="(item, index) in relativesRelationList" :key="index" :label="item.dictName" :value="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="身份证号码">
              <el-input disabled v-model="relationInfo.cardId"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="手机号码">
              <el-input disabled v-model="relationInfo.phone"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="自查征信">
              <el-select v-model="relationInfo.selfCredit" disabled>
                <el-option label="是" :value="0"></el-option>
                <el-option label="否" :value="1"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="单位名称">
              <el-input disabled v-model="relationInfo.compaynName"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  export default {
    props: ['relationInfo'],
    data () {
      return {
        rowGutter: 10,
        colSpan: 8
      }
    },
    computed: {
      ...mapGetters(['relativesRelationList', 'bankNameList'])
    },
    methods: {
      showRedSign (v1) {
        let nowTime = new Date().getTime()
        let checkDate = new Date(v1).getTime()
        // 有效期小于30天，标红显示
        let dVal = checkDate - nowTime
        return dVal < 30 * 24 * 60 * 60 * 1000
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import "../style";
</style>
