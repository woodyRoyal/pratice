<template>
  <div>
    <div class="formModuleTitle"><span>联系人信息</span></div>
    <el-table :data="tableData" border style="width: 100%">
      <el-table-column label="联系人姓名" width="80" type="index"></el-table-column>
      <el-table-column label="联系人姓名">
        <template slot-scope="scope">
          {{scope.row.name}}
        </template>
      </el-table-column>
      <el-table-column label="与申请人关系">
        <template slot-scope="scope">
          {{suretyRelationDict[scope.row.relation]}}
        </template>
      </el-table-column>
      <el-table-column label="手机号码">
        <template slot-scope="scope">
          {{scope.row.phone}}
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import {contactList} from '../../../api/formInfo.js'
  import {formatPhone, formatPapers, formatName} from '../../../filters'
  export default {
    data () {
      return {
        tableData: []
      }
    },
    mounted () {
      this.getContactList()
      console.log(formatPhone, formatPapers, formatName)
    },
    computed: {
      ...mapGetters(['applyId', 'suretyRelationDict'])
    },
    methods: {
      getContactList () {
        contactList({applyId: this.applyId, type: 1}).then(res => {
          if (res.data.respCode === '1000') {
            res.data.body.forEach(t => {
              t.phone = t.phone
              t.name = t.name
            })
            this.tableData = res.data.body
          }
        }).catch(error => { console.log(error) })
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import "../style";
</style>
