<template>
  <div class="basicInfoWrap">
    <div class="formModuleTitle"><span>基本信息</span></div>
    <el-form label-position="top" size="mini" :model="basicInfo">
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="申请人姓名">
            <el-input disabled v-model="basicInfo.name"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="证件类型">
            <el-select v-model="basicInfo.cardType" disabled>
              <el-option v-for="(item, index) in cardTypeList" :key="index" :label="item.dictName" :value="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="证件号">
            <el-input disabled v-model="basicInfo.cardId"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="性别">
            <el-select disabled v-model="basicInfo.sex">
              <el-option label="男" :value="0"></el-option>
              <el-option label="女" :value="1"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="出生日期">
            <el-input disabled v-model="basicInfo.birth"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="年龄">
            <el-input disabled v-model="basicInfo.age"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="签发机关">
            <el-input disabled v-model="basicInfo.licenceIssuing"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="证件有效期（起）">
            <el-input disabled v-model="basicInfo.expiryDateStart"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="证件有效期（止）">
            <div class="expiryDateEndWrap">
              <el-radio v-model="basicInfo.isExpiryDateEndLong" label="长期" disabled>长期</el-radio>
              <el-radio v-model="basicInfo.isExpiryDateEndLong" label="非长期" disabled>非长期</el-radio>
              <el-date-picker v-model="basicInfo.expiryDateEnd" type="date" placeholder="选择日期" value-format="yyyy-MM-dd" disabled :class="{redSign: showRedSign(basicInfo.expiryDateEnd)}"></el-date-picker>
            </div>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="婚姻状况">
            <el-select v-model="basicInfo.married" disabled>
              <el-option v-for="(item, index) in marriedList" :key="index" :label="item.dictName" :value="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="手机号">
            <el-input disabled v-model="basicInfo.phone"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="民族">
            <el-input disabled v-model="basicInfo.race"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter" v-if="basicInfo.education !== null && basicInfo.academicDegree !== null">
        <el-col :span="colSpan">
          <el-form-item label="承租人最高学历">
            <el-select v-model="basicInfo.education" placeholder="请选择" disabled>
              <el-option :label="item.dictName" :value="item.dictValue" v-for="(item, index) in educationList" :key="index"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="承租人最高学位">
            <el-select v-model="basicInfo.academicDegree" placeholder="请选择" disabled>
              <el-option :label="item.desc" :value="item.code" v-for="(item, index) in academicDegreeDict" :key="index"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import {academicDegreeDict} from '../../../api/applyProgress.js'
  export default {
    props: ['basicInfo'],
    data () {
      return {
        academicDegreeDict,
        rowGutter: 10,
        colSpan: 8
      }
    },
    computed: {
      ...mapGetters(['marriedList', 'educationList', 'cardTypeList'])
    },
    methods: {
      showRedSign (v1) {
        if (v1 === '') return
        let nowTime = new Date().getTime()
        let checkDate = new Date(v1).getTime()
        // 有效期小于30天，标红显示
        let dVal = checkDate - nowTime
        return dVal < 30 * 24 * 60 * 60 * 1000
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import "../style";
</style>
