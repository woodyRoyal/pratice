<template>
  <div class="relationWithApplyerWrap">
    <div class="formModuleTitle"><span>与申请人关系</span></div>
    <el-form label-position="top" size="small" :model="proposerSuretyInfo">
      <el-row :gutter="controlSpacing">
        <el-col :span="controlSpacing">
          <el-form-item label="与申请人关系" prop="relation">
            <el-select v-model="proposerSuretyInfo.relation" placeholder="请选择" disabled>
              <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in suretyRelationList" :key="item.dictValue"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  export default {
    props: ['proposerSuretyInfo'],
    data () {
      return {
        controlSpacing: 10
      }
    },
    computed: {
      ...mapGetters(['suretyRelationList'])
    }
  }
</script>

<style lang="scss" scoped>
</style>
