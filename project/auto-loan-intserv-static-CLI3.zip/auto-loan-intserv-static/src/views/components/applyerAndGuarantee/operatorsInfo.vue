<template>
  <div v-if="tableData.length>0">
    <div class="formModuleTitle"><span>运营商认证</span></div>
    <el-table :data="tableData"
              border
              style="width: 100%">
      <el-table-column label="认证人">
        <template slot-scope="scope">
          {{scope.row.name}}
        </template>
      </el-table-column>
      <el-table-column label="认证状态">
        <template slot-scope="scope">
          {{scope.row.flag | statusToMsg}}
        </template>
      </el-table-column>
      <el-table-column label="运营商报告">
        <template slot-scope="scope"
                  v-if="scope.row.reportUrl">
          <el-button type="text"
                     @click="queryInfoHandle(scope.row.reportUrl)">点此查看运营商征信报告</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import { getmMobileAuthList } from '@/api/applyProgress'
export default {
  props: ['applyId'],
  data () {
    return {
      tableData: []
    }
  },
  mounted () {
    getmMobileAuthList({ applyId: this.applyId, taskType: 3 }).then((res) => {
      if (res.data.respCode === '1000') {
        this.tableData = res.data.body
      }
    })
  },
  methods: {
    queryInfoHandle (reportUrl) {
      window.open(reportUrl)
    }
  }
}
</script>
