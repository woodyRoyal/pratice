<template>
  <div>
    <div class="formModuleTitle"><span>贷前电联记录</span></div>
    <el-table :data="telVerifyData" border>
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="姓名" prop="name"></el-table-column>
      <el-table-column label="电核对象">
        <template slot-scope="scope">
          {{phoneRelationDict[scope.row.relationType]}}
        </template>
      </el-table-column>
      <el-table-column label="手机号/归属地" width="160">
        <template slot-scope="scope">
          {{scope.row.phoneBelong}}
        </template>
      </el-table-column>
      <el-table-column label="电联结果">
        <template slot-scope="scope">
          {{callingResultDict[scope.row.callResult]}}
        </template>
      </el-table-column>
      <el-table-column label="支付宝/微信">
        <template slot-scope="scope">
          {{(scope.row.aliPay !== null ? alipayDict[scope.row.aliPay] : '') + '/' +  (scope.row.weChat !== null ? wechatDict[scope.row.weChat] : '')}}
        </template>
      </el-table-column>
      <el-table-column label="审批备注">
        <template slot-scope="scope">
          {{scope.row.remark}}
        </template>
      </el-table-column>
      <el-table-column label="审核节点">
        <template slot-scope="scope">
          {{dict.allCurrentNodeDict[scope.row.currentNode + '']}}
        </template>
      </el-table-column>
      <el-table-column label="操作人">
        <template slot-scope="scope">
          {{scope.row.operatorName}}
        </template>
      </el-table-column>
      <el-table-column label="结束时间">
        <template slot-scope="scope">
          {{scope.row.createAt}}
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <a :href="scope.row.voicePath" target="_blank" class="voiceFile" v-if="scope.row.voicePath">{{formatSecondEn1(scope.row.chatDuration / 1000)}}录音</a>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import {dict} from '../../../api/commonApi.js'
  import {formatSecondEn1} from '../../../utils/formatDate'
  export default {
    props: ['telVerifyData'],
    data () {
      return {
        dict,
        formatSecondEn1,
        alipayDict: {},
        wechatDict: {},
        callingResultDict: {}
      }
    },
    mounted () {
      this.alipay.forEach(item => {
        this.alipayDict[item.dictValue] = item.dictName
      })
      this.wechat.forEach(item => {
        this.wechatDict[item.dictValue] = item.dictName
      })
      this.callingResult.forEach(item => {
        this.callingResultDict[item.dictValue] = item.dictName
      })
    },
    computed: {
      ...mapGetters(['phoneRelationDict', 'alipay', 'wechat', 'callingResult'])
    }
  }
</script>

<style scoped lang="scss">
  .voiceFile{
    text-decoration: underline;
    color: #2fa4e7;
  }
</style>
