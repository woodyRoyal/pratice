<template>
  <div class="wrap">
    <span class="table-title-word">经销商信息</span>
    <el-table border>
      <el-table-column label="序号" align="center"></el-table-column>
      <el-table-column label="提报店名称" align="center">
        <template slot-scope="scope">
            {{scope.row.applyId || '/'}}
        </template>
      </el-table-column>
      <el-table-column label="申请件数" align="center">
        <template slot-scope="scope">
            {{scope.row.applyId || '/'}}
        </template>
      </el-table-column>
      <el-table-column label="通过率（%）" align="center">
        <template slot-scope="scope">
            {{scope.row.applyId || '/'}}
        </template>
      </el-table-column>
      <el-table-column label="拒绝率（%）" align="center">
        <template slot-scope="scope">
            {{scope.row.applyId || '/'}}
        </template>
      </el-table-column>
      <el-table-column label="退回率（%）" align="center">
        <template slot-scope="scope">
            {{scope.row.applyId || '/'}}
        </template>
      </el-table-column>
      <el-table-column label="30+逾期率" align="center">
        <template slot-scope="scope">
            {{scope.row.applyId || '/'}}
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
export default {
  data () {
    return {}
  }
}
</script>
<style lang="scss" scoped>
  @import "style.scss";
</style>
