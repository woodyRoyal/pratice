<template>
  <div class="warp clearfix">
      <div class="tableTitle clearfix">
        <span class="table-title-word">提报信息备注</span>
      </div>
      <el-table :data="listData" border>
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="提醒内容">
          <template slot-scope="scope">
            {{scope.row.remindContent || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="任务名称">
          <template slot-scope="scope">
            {{scope.row.taskName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="操作人">
          <template slot-scope="scope">
            {{scope.row.operatorId || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="操作时间">
          <template slot-scope="scope">
            {{scope.row.operatorTime || '/'}}
          </template>
        </el-table-column>
      </el-table>
      <div class="paginationWrap">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pagination.currentPage" :page-sizes="pagination.pageSizes" :page-size="pagination.pageSize"
                       layout="total, sizes, prev, pager, next, jumper" :total="pagination.total">
        </el-pagination>
      </div>
    </div>
</template>
<script>
  import { mapGetters } from 'vuex'
  import { insideApproveRemark } from '../../api/caseHandle.js'
  export default {
    data () {
      return {
        isRead: false,
        pagination: {
          currentPage: 1,
          pageSizes: [5, 10, 15],
          total: 0,
          pageSize: 5
        },
        queryData: {
          applyId: null,
          pageSize: 5,
          pageNum: 1,
          remindType: 3 // 提报固定值
        }, // 查询条件
        listData: [] // 列表数据
      }
    },
    computed: {
      ...mapGetters(['applyId'])
    },
    mounted () {
      this.getTbRemark() // 获取列表数据
    },
    methods: {
      getTbRemark () {
        this.queryData.applyId = this.applyId
        this.queryData.pageNum = this.pagination.currentPage
        this.queryData.pageSize = this.pagination.pageSize
        insideApproveRemark(this.queryData).then(res => {
          if (res.data.respCode === '1000') {
            this.listData = res.data.body.list
            this.pagination.total = res.data.body.total
          }
        }).catch(error => { console.log(error) })
      },
      handleSizeChange (val) {
        this.pagination.pageSize = val
        this.getInsideApproveRemark()
      },
      handleCurrentChange (val) {
        this.pagination.currentPage = val
        this.getInsideApproveRemark()
      }
    }
  }
</script>
<style lang="scss" scoped>
  @import "style.scss";
</style>
