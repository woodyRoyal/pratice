<template>
  <div>
    <span class="form-title">客户还款明细</span>
    <el-table :data="customerRepayTable" class="customerRepayTable">
      <el-table-column label="期数" prop="term"></el-table-column>
      <el-table-column label="应还日期" prop="term"></el-table-column>
      <el-table-column label="月租" prop="term"></el-table-column>
      <el-table-column label="本金" prop="term"></el-table-column>
      <el-table-column label="利息" prop="term"></el-table-column>
      <el-table-column label="剩余本金" prop="term"></el-table-column>
      <el-table-column label="还款状态">
        <template slot-scope="scope">
          {{}}
        </template>
      </el-table-column>
      <el-table-column label="逾期天数">
        <template slot-scope="scope">
          {{}}
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <div class="clearfix">
      <el-pagination
        class="tablePagination"
        @size-change="customerRepayHandleSizeChange"
        @current-change="customerRepayHandleCurrentChange"
        :current-page="customerRepayTablePage.currentPage"
        :page-size="customerRepayTablePage.pageSize"
        :page-sizes="customerRepayTablePage.pageSizesArr"
        layout="total, sizes, prev, pager, next, jumper"
        :total="customerRepayTablePage.total">
      </el-pagination>
    </div>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        customerRepayTable: [],
        customerRepayTablePage: {
          currentPage: 1,
          pageSize: 10,
          pageSizesArr: [10, 20, 30, 40],
          total: 0
        }
      }
    },
    methods: {
      customerRepayHandleSizeChange () {},
      customerRepayHandleCurrentChange () {}
    }
  }
</script>
<style lang="scss">
  .tablePagination {
    float: right;
    margin: 5px 0;
  }
  .form-title{
    font-size: 14px;
    color: #333;
    font-weight: 700;
  }
  .customerRepayTable{
    margin-top: 5px;
  }
</style>
