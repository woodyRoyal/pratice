<template>
  <div>
    <el-form size="small" :inline="true" v-model="queryForm">
      <el-form-item label="申请编号">
        <el-input placeholder="输入申请编号" maxlength="8" v-model="queryForm.applyId"></el-input>
      </el-form-item>
      <el-form-item label="客户名称">
        <el-input placeholder="输入客户名称" maxlength="20" v-model="queryForm.name"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="queryReset">重置</el-button>
        <el-button type="primary" @click="queryData">查询</el-button>
      </el-form-item>
    </el-form>
    <el-table :data="tableData" border>
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="申请编号" prop=""></el-table-column>
      <el-table-column label="客户名称" prop="name"></el-table-column>
      <el-table-column label="申请类型" prop="applyType"></el-table-column>
      <el-table-column label="企业/挂靠名称">
        <template slot-scope="scope">
          {{scope.row.companyName === '' ? '/' : scope.row.companyName}}
        </template>
      </el-table-column>
      <el-table-column label="申请时间" prop="applyType"></el-table-column>
      <el-table-column label="申请操作员" prop="applyType"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="mini">查看详情</el-button>
        </template>
      </el-table-column>
      <div class="clearfix">
        <el-pagination
          class="tablePagination"
          @size-change="settleCheckPageHandleSizeChange"
          @current-change="settleCheckPageHandleCurrentChange"
          :current-page="settleCheckPage.currentPage"
          :page-size="settleCheckPage.pageSize"
          :page-sizes="settleCheckPage.pageSizesArr"
          layout="total, sizes, prev, pager, next, jumper"
          :total="settleCheckPage.total">
        </el-pagination>
      </div>
    </el-table>
    <!--操作弹窗-->
    <el-dialog title="资方结清审核" :visible.sync="dialogFormVisible" width="80%" class="customerRepayInfoDialog">
      <!--客户还款明细-->
      <CustomerRepayTable></CustomerRepayTable>
      <CustomerRepayForm></CustomerRepayForm>
      <div style="margin-top: 10px">
        <el-form size="small" :model="customerRepayInfoCheckForm" :rules="customerRepayInfoCheckFormRules" ref="customerRepayInfoCheckForm">
          <el-form-item label="审批结果选择" label-width="120px" prop="auditResult">
            <el-select v-model="customerRepayInfoCheckForm.auditResult">
              <el-option label="通过" :value="1"></el-option>
              <el-option label="退回申请" :value="0"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="审批备注信息" label-width="120px" prop="auditRemark">
            <el-input type="textarea" :autosize="{minRows: 3}" v-model="customerRepayInfoCheckForm.auditRemark"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div style="display: flex; justify-content: center">
        <el-button type="primary" size="mini" @click="settleApplySubmit">提 交</el-button>
      </div>
      <FileUpload :pictureList="pictureList" @savePicItem="savePicItemFn"></FileUpload>
      <ApproveHistory></ApproveHistory>
      <!--<div slot="footer" class="customerRepayInfo-dialog-footer">
        <el-button type="primary" size="mini" @click="showFileDialog">上传凭证</el-button>
        <el-button type="primary" size="mini" @click="settleApplySubmit">提交申请</el-button>
      </div>-->
    </el-dialog>
    <!--文件上传弹窗-->
    <el-dialog title="请上传相关附件" :visible.sync="fileDialogVisible" class="write-off-dialog" :show-close="false">
      <p>温馨提示:系统支持上传的文件类型(*.pdf,*.docx,*.doc,*.jpg,*.jpeg,*.bmp,*.png,*.zip,*.rar,*.msg,*.eml,*.txt,*.wav</p>
      <p>单个word文件最大不能超过50.0MB;单个excel文件最大不能超过50.0MB;单个图片最大不能超过50.0MB;单个pdf文件最大不能超过50.0MB;单个压缩包文件最大不能超过20.0MB;</p>
      <FileUpload :pictureList="pictureList" @savePicItem="savePicItemFn"></FileUpload>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeFileDialog" size="mini">关 闭</el-button>
        <el-button type="primary" @click="fileDialogVisible = false" size="mini">保 存</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import settleApplyApi from '../../api/settleAccountApi'
  import FileUpload from '../../components/DialoginnerFileupload/fileupload'
  import CustomerRepayTable from './customerRepayTable'
  import CustomerRepayForm from './customerRepayForm'
  import ApproveHistory from './approveHistory'
  export default {
    data () {
      return {
        queryForm: {
          applyId: null,
          name: ''
        },
        tableData: [],
        dialogFormVisible: true,
        customerRepayTable: [],
        settleCheckPage: {
          currentPage: 1,
          pageSize: 10,
          pageSizesArr: [10, 20, 30, 40],
          total: 0
        },
        customerRepayInfo: {
          name: '22.00'
        },
        customerRepayInfoRules: {
          remark: [{required: true, message: '内容不可为空', trigger: 'blur'}]
        },
        customerRepayInfoCheckForm: {
          auditResult: null,
          auditRemark: ''
        },
        customerRepayInfoCheckFormRules: {
          auditResult: [{required: true, message: '内容不可为空', trigger: 'change'}],
          auditRemark: [{required: true, message: '内容不可为空', trigger: 'blur'}]
        },
        fileDialogVisible: false,
        pictureList: [{
          dictKey: 'book_file',
          fileRecordVOList: [],
          name: '还款勾稽凭证'
        }]
      }
    },
    components: { FileUpload, CustomerRepayTable, CustomerRepayForm, ApproveHistory },
    methods: {
      queryReset () {
        this.queryForm = {
          applyId: null,
          name: ''
        }
        this.queryData()
      },
      queryData () {
        settleApplyApi.tableData().then(res => {
          if (res.data.respCode === '1000') this.tableData = res.data.body
        }).catch(err => { console.log(err) })
      },
      settleCheckPageHandleSizeChange () {},
      settleCheckPageHandleCurrentChange () {},
      // 提交申请
      settleApplySubmit () {
        this.$refs['customerRepayInfo'].validate(valid => {})
      },
      // 上传凭证
      showFileDialog () {
        this.fileDialogVisible = true
      },
      // 保存图片
      savePicItemFn (val) {
        this.pictureList.forEach(item => {
          if (item.dictKey === val.item.dictKey) {
            item.fileRecordVOList.push(val.data)
          }
        })
      },
      // 关闭
      closeFileDialog () {
        this.fileDialogVisible = false
        this.pictureList.forEach(item => {
          item.fileRecordVOList = []
        })
      }
    }
  }
</script>
<style lang="scss">
  .tablePagination {
    float: right;
    margin: 5px 0;
  }
  .el-form-item--mini.el-form-item, .el-form-item--small.el-form-item {
    margin-bottom: 14px;
  }
  .customerRepayInfo-dialog-footer{
    display: flex;
    justify-content: center;
  }
  .customerRepayInfoDialog {
    .el-dialog__header {
      padding: 10px 20px;
    }
    .el-dialog__body{
      padding: 0 20px;
    }
  }
</style>
