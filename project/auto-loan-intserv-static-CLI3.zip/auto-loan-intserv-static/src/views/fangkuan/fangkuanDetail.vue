<template>
  <div class="approveHandleWrap">
    <el-row v-if="applyId">
      <el-col :span="14">
        <div id="left"
             ref="left"
             class="left">
          <el-tabs :value="tabActiveName">
            <el-tab-pane label="审核首页"
                         name="1">
              <FangKuanApprove @getGpsImgData="getPicViewDataHandle"
                               @changeTabActiveName="changeTabActiveName"></FangKuanApprove>
            </el-tab-pane>
            <el-tab-pane label="请款附件资料"
                         name="2"
                         :lazy="true">
              <QingKuanFile @getPicViewData="getPicViewDataHandle"></QingKuanFile>
            </el-tab-pane>
            <el-tab-pane label="车辆及融资"
                         name="3"
                         :lazy="true">
              <CarFinancial></CarFinancial>
            </el-tab-pane>
            <el-tab-pane label="申请人信息"
                         name="4"
                         :lazy="true">
              <ApplyerInfo></ApplyerInfo>
            </el-tab-pane>
            <el-tab-pane label="担保人信息"
                         name="5"
                         :lazy="true">
              <GuaranteeInfo></GuaranteeInfo>
            </el-tab-pane>
            <el-tab-pane label="提报附件资料"
                         name="6"
                         :lazy="true">
              <FileUpload @getPicViewData="getPicViewDataHandle"></FileUpload>
            </el-tab-pane>
            <el-tab-pane label="审批历史/历史关联"
                         name="7"
                         :lazy="true">
              <ApproveHistory></ApproveHistory>
            </el-tab-pane>
            <el-tab-pane label="内部附件资料"
                         name="8"
                         :lazy="true">
              <InternalAuditFile @getPicViewData="getPicViewDataHandle"></InternalAuditFile>
            </el-tab-pane>
          </el-tabs>
        </div>
      </el-col>
      <el-col :span="10"
              class="colRight">
        <div ref="rightColumn"
             class="right">
          <summaryInfo @changeTabActiveName="changeTabActiveName"></summaryInfo>
          <approveHandle></approveHandle>
        </div>
      </el-col>
    </el-row>
    <div v-if="showPicView"
         v-drag
         class="pic-view-wrap">
      <PicView v-if="showPicView"
               :img-item-list="imgItemList"
               :click-item="clickItem"
               @closePicView="closePicViewHandle"></PicView>
    </div>
  </div>
</template>
<script>
  import FangKuanApprove from './fangkuanApprove/index'
  import QingKuanFile from './qingkuanFile/index'
  import CarFinancial from './carFinancial/carFinancial.vue'
  import ApplyerInfo from '../components/applyerAndGuarantee/applyerInfo'
  import FileUpload from '../components/tbFile/index'
  import InternalAuditFile from './internalAuditFile/internalAuditFile'
  import ApproveHistory from '../components/approveHistory'
  import GuaranteeInfo from '../components/applyerAndGuarantee/guaranteeInfo'
  import PicView from '../../components/PicView/index'
  import summaryInfo from './summaryInfo.vue'
  import approveHandle from './approveHandle/approveHandle.vue'
  import { VUE_APP_FANGKUAN_WS_URL } from '../../api/fangkuan'
  import { mapGetters } from 'vuex'
  export default {
    data () {
      return {
        fangkuanWebSocketUrl: VUE_APP_FANGKUAN_WS_URL,
        webSocTimer: null,
        tabActiveName: '1',
        showPicView: false, // 预览弹窗
        clickItem: null, // 预览点击项
        imgItemList: null, // 所有图片
      }
    },
    computed: {
      ...mapGetters(['applyId', 'applyType', 'userId', 'provinceCityList']),
    },
    components: {
      FangKuanApprove,
      QingKuanFile,
      CarFinancial,
      ApplyerInfo,
      FileUpload,
      InternalAuditFile,
      ApproveHistory,
      GuaranteeInfo,
      PicView,
      summaryInfo,
      approveHandle,
    },
    created () {
      // 存入 vuex 中
      const {applyId, applyType} = this.$route.params
      if (applyId && (applyType >= 0)) this.$store.dispatch('saveApplyIdApplyType', {applyId: +applyId, applyType: +applyType})
      if (this.provinceCityList.length === 0) this.$store.dispatch('getAreaTree')
    },
    mounted () {
      this.autoHeight()
      window.addEventListener('resize', this.autoHeight)
      // 放款webSocket
      // eslint-disable-next-line
      this.ws = new WebSocket(this.fangkuanWebSocketUrl)
      this.ws.addEventListener('open', this.wsOpen)
      this.ws.addEventListener('message', this.wsMessage)
      this.ws.addEventListener('close', this.wsClose)
    },
    beforeDestroy () {
      clearInterval(this.webSocTimer)
      this.ws.close() // 断开放款webSocket
    },
    destroyed () {
      window.removeEventListener('resize', this.autoHeight)
    },
    methods: {
      /* 放款 */
      // 建立连接，向服务端发送数据
      wsOpen () {
        console.log('%c' + '放款webSocket Connection open ...', 'color: green')
        const {applyId} = this.$route.params
        let sendMsg = {operatorId: this.userId, applyId}
        this.ws.send(JSON.stringify(sendMsg))
        // 每隔3s发送一个空消息
        clearInterval(this.webSocTimer)
        this.webSocTimer = setInterval(() => {
          this.ws.send('')
        }, 3000)
      },
      // 获取数据，处理数据
      wsMessage (event) {
        let data = event.data
        console.log(data)
      },
      // 连接断开的回调
      wsClose (event) {
        clearInterval(this.webSocTimer)
        console.log('%c' + '放款webSocket Connection close ...', 'color: red')
      },
      autoHeight () {
        let clientH = document.documentElement.clientHeight || document.body.clientHeight
        this.$refs.rightColumn.style.height = clientH + 'px'
      },
      changeTabActiveName (payload) {
        const {tabName} = payload
        this.tabActiveName = tabName
      },
      getPicViewDataHandle (data) {
        this.showPicView = true
        this.clickItem = data.clickItem
        this.imgItemList = data.imgItemList
      },
      closePicViewHandle () {
        this.showPicView = false
      },
    },
  }
</script>
<style lang="scss" scoped>
  .left{
    padding: 0 0 0 5px;
  }
  .right{
    box-sizing: border-box;
    padding: 0 5px;
    overflow-y: auto;
  }
  .callMessageBox{
    position: fixed;
    z-index: 12;
    left: 40%;
    top:20%
  }
  .pic-view-wrap{
    position: absolute;
    top: 0;
    left: 50%;
    background: #fff;
    z-index: 1000;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.3);
  }
</style>

