<template>
  <div class="approve-index-wrap" ref="approveIndexWrap">
    <InsideApproveRemark></InsideApproveRemark>
    <TbRemark></TbRemark>
    <RepaymentCard :replamentCardData="replamentCardData" v-if="replamentCardData"></RepaymentCard>
    <Receipt :invoiceData="invoiceData" v-if="invoiceData" @queryReceiptInfo="repeatQueryReceipt"></Receipt>
    <Commercial :commercialData="commercialData" v-if="commercialData"></Commercial>
    <GPS :gpsData="gpsData" @getGpsImgData="getGpsImgDataHandle"  v-if="gpsData"></GPS>
    <!--请款附件资料-->
    <div>
      <div class="formModuleTitle"><span>请款附件资料</span></div>
      <el-button type="primary" size="mini" @click="toQingkuanFile">点击查看</el-button>
    </div>
  </div>
</template>

<script>
  import InsideApproveRemark from '../../components/insideApproveRemark'
  import TbRemark from '../../components/tbInfoRemark'
  import RepaymentCard from './huankuanka'
  import Receipt from './fapiao'
  import Commercial from './commercial'
  import GPS from './gps'
  import {getApplyMoneyInfo, getCompactInfo} from '../../../api/fangkuan'
  import {mapGetters} from 'vuex'
  import {formatName, formatPhone, formatPapers} from '../../../filters'
  export default {
    data () {
      return {
        gpsData: {
          wiredSupplier: null,
          wiredDeviceNum: null,
          wiredActivationStatus: null,
          wirelessSupplier: null,
          wirelessDeviceNum: null,
          wirelessActivationStatus: null,
          contact: null,
          contactPhone: null,
          installDate: null,
          provinceCity: null,
          address: ''
        },
        commercialData: null,
        invoiceData: {
          salesUnit: '',
          invoiceCode: '',
          invoiceAmount: '',
          invoiceAmountTax: '',
          invoiceNumber: '',
          taxpayerNumber: '',
          billingDate: '',
          resultCode: '',
          resultMsg: ''
        },
        replamentCardData: {
          accountType: null,
          name: '',
          bankType: null,
          bankAddrName: '',
          bankNum: null,
          debitCardNum: null,
          phone: null,
          payCardCredNum: null
        }
      }
    },
    components: {
      InsideApproveRemark,
      TbRemark,
      RepaymentCard,
      Receipt,
      Commercial,
      GPS
    },
    computed: {
      ...mapGetters(['applyId'])
    },
    created () {
      this.getInfo(this.applyId)
    },
    mounted () {
      this.autoHeight()
      window.addEventListener('resize', this.autoHeight)
    },
    destroyed () {
      window.removeEventListener('resize', this.autoHeight)
    },
    methods: {
      getInfo (val) {
        getApplyMoneyInfo(val).then(res => {
          if (res.data.respCode === '1000') {
            const {gpsInfoVO, commercialInsurance, compulsoryInsurance, invoiceVO} = res.data.body
            gpsInfoVO.provinceCity = gpsInfoVO.province && gpsInfoVO.city ? [gpsInfoVO.province, gpsInfoVO.city] : null
            this.gpsData = gpsInfoVO
            this.commercialData = {commInsurance: commercialInsurance, compInsurance: compulsoryInsurance}
            this.invoiceData = invoiceVO
          }
        }).catch(error => { console.log(error) })
        getCompactInfo(val).then(res => {
          if (res.data.respCode === '1000') {
            const {replamentCardInfo} = res.data.body
            replamentCardInfo.nameStr = formatName(replamentCardInfo.name, 1)
            replamentCardInfo.bankNumStr = formatPapers(replamentCardInfo.bankNum, 1)
            replamentCardInfo.debitCardNumStr = formatPapers(replamentCardInfo.debitCardNum, 1)
            replamentCardInfo.phoneStr = formatPhone(replamentCardInfo.phone, 1)
            replamentCardInfo.payCardCredNumStr = formatPapers(replamentCardInfo.payCardCredNum, 1)
            this.replamentCardData = replamentCardInfo
          }
        }).catch(error => { console.log(error) })
      },
      getGpsImgDataHandle (data) {
        this.$emit('getGpsImgData', data)
      },
      repeatQueryReceipt () {
        this.getInfo(this.applyId)
      },
      toQingkuanFile () {
        this.$emit('changeTabActiveName', {tabName: '2'})
      },
      autoHeight () {
        let screenHeight = document.documentElement.clientHeight
        this.$refs.approveIndexWrap.style.height = (screenHeight - 55) + 'px'
      }
    }
  }
</script>

<style scoped lang="scss">
  .approve-index-wrap{
    overflow-x: hidden;
    overflow-y: auto;
  }
</style>
