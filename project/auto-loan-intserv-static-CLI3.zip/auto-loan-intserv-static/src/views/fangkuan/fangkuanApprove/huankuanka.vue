<template>
  <div class="huankuankaWrap">
    <div class="formModuleTitle"><span>还款卡信息</span></div>
    <el-form label-position="top" size="small">
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="借记卡账户类型" :label-width="formLable" class="is-required">
            <el-select disabled v-model="replamentCardData.accountType">
              <el-option :value="0" label="个人"></el-option>
              <el-option :value="1" label="企业"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="借记卡开户名" :label-width="formLable" class="is-required">
            <el-input disabled v-model="replamentCardData.nameStr"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="还款卡开户行" :label-width="formLable" class="is-required">
            <el-select disabled v-model="replamentCardData.bankType">
              <el-option v-for="(item, index) in bankNameList" :value="item.dictValue" :label="item.dictName" :key="index"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="网点名称" :label-width="formLable">
            <el-input disabled v-model="replamentCardData.bankAddrName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="开户行号" :label-width="formLable">
            <el-input disabled v-model="replamentCardData.bankNumStr"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="借记卡账号" :label-width="formLable" class="is-required">
            <el-input disabled v-model="replamentCardData.debitCardNumStr"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="银行预留手机号" :label-width="formLable" class="is-required" >
            <el-input disabled v-model="replamentCardData.phoneStr"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="还款卡证件号" :label-width="formLable" class="is-required">
            <el-input disabled v-model="replamentCardData.payCardCredNumStr"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan"></el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  export default {
    props: ['replamentCardData'],
    data () {
      return {
        rowGutter: 10,
        colSpan: 8,
        formLable: '121px'
      }
    },
    computed: {
      ...mapGetters(['bankNameList'])
    },
    mounted () {}
  }
</script>

<style lang="scss" scoped>
</style>
