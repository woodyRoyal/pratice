<template>
  <div class="fapiaoWrap">
    <div class="formModuleTitle"><span>发票信息</span></div>
    <div class="btns">
      <el-button size="mini" type="primary" @click="companyQuery">企业查询</el-button>
      <el-button size="mini" type="primary" @click="receiptQuery">点击查看发票详情</el-button>
      <span v-if="invoiceData.resultCode !== ''">
        <i class="el-icon-info"></i>
        发票查验结果：<el-tag :type="invoiceData.resultCode === 0 ? 'success' : 'warning'">{{invoiceData.resultMsg}}</el-tag>
      </span>
    </div>
    <el-form label-position="top" size="small">
      <el-row :gutter="5">
        <el-col :span="12">
          <el-form-item :label-width="formLable" label="销货单位名称" class="is-required">
            <el-input disabled v-model="invoiceData.salesUnit"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item :label-width="formLable" label="车辆发票代码" class="is-required">
            <el-input disabled v-model="invoiceData.invoiceCode"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="5">
        <el-col :span="12">
          <el-form-item :label-width="formLable" label="车辆发票金额（不含税价）" class="is-required">
            <el-input disabled v-model="invoiceData.invoiceAmount"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item :label-width="formLable" label="车辆发票金额（含税价）" class="is-required">
            <el-input disabled v-model="invoiceData.invoiceAmountTax"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item :label-width="formLable" label="车辆发票号码" class="is-required">
            <el-input disabled v-model="invoiceData.invoiceNumber"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item :label-width="formLable" label="纳税人识别号" class="is-required">
            <el-input disabled v-model="invoiceData.taxpayerNumber"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item :label-width="formLable" label="车辆开票日期" class="is-required">
            <el-date-picker type="date" value-format="yyyy-MM-dd" disabled v-model="invoiceData.billingDate"></el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div class="receiptResInfoDialog" v-drag  v-if="dialogTableVisible">
      <div class="receiptResInfoDialog-title">
        <span>发票结果详情</span>
        <i class="el-icon-close" @click="dialogTableVisible = false"></i>
      </div>
      <el-table :data="receiptInfoData" border :max-height="tableMaxHeight">
        <el-table-column prop="label" label="内容"></el-table-column>
        <el-table-column prop="value" label="值"></el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
  import {receiptInfo} from '../../../api/fangkuan'
  import {mapGetters} from 'vuex'
  export default {
    props: ['invoiceData'],
    data () {
      return {
        rowGutter: 10,
        colSpan: 8,
        formLable: '108px',
        receiptInfoData: [],
        dialogTableVisible: false,
        tableMaxHeight: 200
      }
    },
    computed: {
      ...mapGetters(['applyId'])
    },
    methods: {
      companyQuery () {
        if (this.invoiceData.salesUnit) {
          window.open('https://www.gobaidugle.com/search3?keyword=' + this.invoiceData.salesUnit + '&num=10&one=baidu&two=so&three=sogou&four=baidu', '_blank')
        } else {
          this.$message.warning('暂无销货单位')
        }
      },
      receiptQuery () {
        receiptInfo(this.applyId)
          .then(res => {
            if (res.data.respCode === '1000') {
              this.$emit('queryReceiptInfo') // 更新发票信息
              const {invoiceDetailMap} = res.data.body
              const receiptInfoData = []
              for (const k in invoiceDetailMap) {
                if ({}.hasOwnProperty.call(invoiceDetailMap, k) && k !== 'content' && k !== 'cycs' && k !== 'file_path') {
                  receiptInfoData.push({label: k, value: invoiceDetailMap[k]})
                }
              }
              this.receiptInfoData = receiptInfoData
              this.dialogTableVisible = true
              this.autoTableHeight()
            }
          })
          .catch(err => { console.log(err) })
      },
      autoTableHeight () {
        let clientHeight = document.documentElement.clientHeight
        this.$nextTick(() => {
          this.tableMaxHeight = clientHeight - 300
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .btns{
    margin-bottom: 5px;
    >span{
      font-size: 14px;
      color: #E6A23C;
      font-weight: 700;
    }
  }
  .receiptResInfoDialog{
    width: 80%;
    position: absolute;
    top: 0;
    left: 50%;
    background: #fff;
    z-index: 1000;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.3);
    .receiptResInfoDialog-title {
      cursor: move;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-sizing: border-box;
      padding: 8px 5px;
      >span{
        color: #333;
        box-sizing: border-box;
        padding-left: 5px;
        font-size: 16px;
      }
      .el-icon-close{
        cursor: pointer;
      }
    }
  }
</style>
