<template>
  <!--提报附件-->
  <div ref="applyTbUploadWrap" class="apply-tb-upload-wrap">
    <!--文件上传-->
    <FileUpload
      applyNode="request_loan_attachment"
      :showSaveButton="true"
      :isSaveLoading="isSaveLoading"
      :hideSideTitle="false"
      :hideAllUploadSwitch="false"
      :hideTree="false"
      :hideDeleteBtn="false"
      :necessaryUploadData="requiredFilesList"
      :unNecessaryUploadData="notRequiredFilesList"
      :optionalTreeData="optionalFileKindsTreeData"
      @changeUnNecessaryUploadData="changeUnNecessaryUploadDataHandle"
      @changeNecessaryUploadData="changeNecessaryUploadDataHandle"
      @showPicView="showPicViewHandle"
      @deleteFileItem='deleteFileItemHandle'
      @saveUploadFiles="saveUploadFilesHandle"
    ></FileUpload>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import {getFileMenuTree, filesGet, saveUploadFiles, deleteImgItem} from '../../../api/upload'
  import FileUpload from '../../../components/fileUpload/index'
  import {deleteFileApiCallback} from '../../../utils/constant'
  export default {
    data () {
      return {
        optionalFileKindsTreeData: [], // 文件树
        defaultProps: {
          children: 'list',
          label: 'dictName'
        },
        requiredFilesList: [], // 必传文件
        notRequiredFilesList: [], // 非必传文件
        isSaveLoading: false,
        isDownload: false
      }
    },
    computed: {
      ...mapGetters(['applyId'])
    },
    mounted () {
      this.fileMenuList()
      this.getFilesData()
      this.autoHeight()
      window.addEventListener('resize', this.autoHeight)
    },
    destroyed () {
      window.removeEventListener('resize', this.autoHeight)
    },
    components: { FileUpload },
    methods: {
      // 选传文件树
      fileMenuList () {
        getFileMenuTree({applyId: this.applyId, categoryList: ['request_loan_attachment'], showFaultFile: false}).then(res => {
          if (res.data.respCode === '1000') this.optionalFileKindsTreeData = res.data.body
        })
      },
      // 获取文件
      getFilesData () {
        filesGet({applyId: this.applyId, categoryList: ['request_loan_attachment'], showFaultFile: true}).then(res => {
          if (res.data.respCode === '1000') {
            const {requiredFileCategoryListVos, notRequiredFileCategoryListVos} = res.data.body
            this.requiredFilesList = requiredFileCategoryListVos
            this.notRequiredFilesList = notRequiredFileCategoryListVos
          }
        }).catch(error => { console.log(error) })
      },
      // 保存文件
      saveUploadFilesHandle () {
        this.isSaveLoading = true
        let apiParams = {applyId: this.applyId, requiredFileCategoryListVos: this.requiredFilesList, notRequiredFileCategoryListVos: this.notRequiredFilesList}
        saveUploadFiles(apiParams).then(res => {
          if (res.data.respCode === '1000') {
            this.$message.success('保存成功')
            this.getFilesData()
            this.isSaveLoading = false
          } else {
            this.isSaveLoading = false
          }
        }).catch(error => {
          this.isSaveLoading = false
          console.log(error)
        })
      },
      /* // 删除回调
      deleteFileApiCallback (data) {
        let copyImgItem = JSON.parse(JSON.stringify(data.imgItem))
        copyImgItem.relatedId = this.applyId
        copyImgItem.relatedGroup = 'request_loan_attachment'
        copyImgItem.fileCategory = 'fault_file_request_loan'
        let forEachData = []
        let faultFileExists = false
        if (data.isRequired) {
          forEachData = this.requiredFilesList
        } else {
          forEachData = this.notRequiredFilesList
        }
        // 删除
        forEachData.forEach(item => {
          item.pictureListVOList.forEach(item => {
            if (item.dictKey === data.imgItem.fileCategory) {
              item.fileRecordVOList.splice(data.index, 1)
            }
          })
        })
        // 添加
        if (this.notRequiredFilesList.length) {
          this.notRequiredFilesList.forEach(item => {
            item.pictureListVOList.forEach(k => {
              if (k.dictKey === 'fault_file_request_loan') faultFileExists = !faultFileExists
            })
          })
          if (faultFileExists) {
            this.notRequiredFilesList.forEach(item => {
              item.pictureListVOList.forEach(k => {
                if (k.dictKey === 'fault_file_request_loan') k.fileRecordVOList.push({...copyImgItem})
              })
            })
          } else {
            this.notRequiredFilesList[0].pictureListVOList.push({
              dictKey: 'fault_file_request_loan',
              fileRecordVOList: [{...copyImgItem}],
              name: '请款的误传文件'
            })
          }
        } else {
          this.notRequiredFilesList.push(
            {categoryDesc: '请款附件',
              dictCategory: 'request_loan_attachment',
              pictureListVOList: [{
                dictKey: 'fault_file_request_loan',
                fileRecordVOList: [{...copyImgItem}],
                name: '请款的误传文件'}]
            }
          )
        }
      }, */
      // 删除文件
      deleteFileItemHandle (data) {
        let copyImgItem = JSON.parse(JSON.stringify(data.imgItem))
        copyImgItem.relatedId = this.applyId
        copyImgItem.relatedGroup = 'request_loan_attachment'
        copyImgItem.fileCategory = 'fault_file_request_loan'
        deleteImgItem(copyImgItem).then(res => {
          if (res.data.respCode === '1000') {
            const _vue = this
            const deleteCbParam = {
              _vue,
              relatedId: this.applyId,
              fileData: data,
              dictCategory: 'request_loan_attachment',
              dictKey: 'fault_file_request_loan'
            }
            deleteFileApiCallback(deleteCbParam)
            this.$message.success('删除成功')
          }
        }).catch(err => { console.log(err) })
      },
      // 文件预览
      showPicViewHandle (data) {
        this.$emit('getPicViewData', data)
      },
      // 替换非必传文件
      changeUnNecessaryUploadDataHandle (data) {
        this.notRequiredFilesList = data.notRequiredFilesList
      },
      // 替换必传文件
      changeNecessaryUploadDataHandle (data) {
        this.requiredFilesList = data.requiredFilesList
      },
      // 自适应高度
      autoHeight () {
        let clientHeight = document.documentElement.clientHeight
        this.$refs['applyTbUploadWrap'].style.height = (clientHeight - 55) + 'px'
      }
    }
  }
</script>

<style lang="scss" scoped>
  .apply-tb-upload-wrap{
    overflow-y: auto;
  }
</style>
