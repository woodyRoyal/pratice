<!--回款记录查询-->
<template>
  <div>
    <el-form size="small"
             label-position="left"
             :inline="true"
             class="sp-query-form">
      <el-form-item label="SP名称">
        <el-input v-model="queryData.dealerName"></el-input>
      </el-form-item>
      <el-form-item label="放款月份起">
        <el-date-picker v-model="queryData.loanMonthStart"
                        type="month"
                        value-format="yyyy-MM-dd"></el-date-picker>
      </el-form-item>
      <el-form-item label="放款月份止">
        <el-date-picker v-model="queryData.loanMonthEnd"
                        type="month"
                        value-format="yyyy-MM-dd"></el-date-picker>
      </el-form-item>
      <el-form-item>
        <div class="customer-query-reset">
          <el-button type="primary"
                     size="mini"
                     @click="getCustomerRepayList">
            查询
          </el-button>
          <el-button size="mini"
                     @click="resetQuery">
            重置
          </el-button>
          <el-button type="primary"
                     size="mini"
                     @click="templateDownload">
            模板下载
          </el-button>
          <el-upload
            class="import-file"
            accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel,text/plain"
            :data="importData"
            action=""
            :with-credentials="true"
            :http-request="importExeHandle"
            :show-file-list="false">
            <el-button size="small"
                       type="primary">
              导入
            </el-button>
          </el-upload>
          <el-button
            type="primary"
            size="mini"
            :loading="spDownloadLoading"
            @click="tableDownload"
          >
            {{ spDownloadLoading ? '导出中' : '导出' }}
          </el-button>
        </div>
      </el-form-item>
    </el-form>
    <div class="dataTableWrap">
      <el-table border
                :data="tableData">
        <el-table-column label="序号"
                         type="index"
                         align="center"></el-table-column>
        <el-table-column label="SP名称"
                         align="center"
                         prop="dealerName"></el-table-column>
        <el-table-column label="放款月份"
                         align="center"
                         prop="loanMonth">
          <template slot-scope="scope">
            {{ scope.row.loanMonth | parseTime("YYYY-MM") }}
          </template>
        </el-table-column>
        <el-table-column label="基础服务费-计提"
                         align="center"
                         prop="baseServiceFeeAccrual">
          <template slot-scope="scope">
            <a href="javascript:;"
               @click="editSpHandle(scope.row, '基础服务费-计提', 'baseServiceFeeAccrual')">{{ scope.row.baseServiceFeeAccrual | twoFloat }}</a>
          </template>
        </el-table-column>
        <el-table-column label="基础服务费-付款"
                         align="center"
                         prop="baseServiceFeePayment">
          <template slot-scope="scope">
            <a href="javascript:;"
               @click="editSpHandle(scope.row, '基础服务费-付款', 'baseServiceFeePayment')">{{ scope.row.baseServiceFeePayment | twoFloat }}</a>
          </template>
        </el-table-column>
        <el-table-column label="当月摊销基础服务费"
                         align="center"
                         prop="amortizationBaseServiceFee">
          <template slot-scope="scope">
            <a href="javascript:;"
               @click="editSpHandle(scope.row, '当月摊销基础服务费', 'amortizationBaseServiceFee')">{{ scope.row.amortizationBaseServiceFee | twoFloat }}</a>
          </template>
        </el-table-column>
        <el-table-column label="季度奖励服务费-计提"
                         align="center"
                         prop="quarterlyBonusServiceFeeAccrual">
          <template slot-scope="scope">
            <a href="javascript:;"
               @click="editSpHandle(scope.row, '度奖励服务费-计提', 'quarterlyBonusServiceFeeAccrual')">{{ scope.row.quarterlyBonusServiceFeeAccrual | twoFloat }}</a>
          </template>
        </el-table-column>
        <el-table-column label="季度奖励服务费-付款"
                         align="center"
                         prop="quarterlyBonusServiceFeePayment">
          <template slot-scope="scope">
            <a href="javascript:;"
               @click="editSpHandle(scope.row, '季度奖励服务费-付款', 'quarterlyBonusServiceFeePayment')">{{ scope.row.quarterlyBonusServiceFeePayment | twoFloat }}</a>
          </template>
        </el-table-column>
        <el-table-column label="销售奖励费-计提"
                         align="center"
                         prop="salesBonusFeeAccrual">
          <template slot-scope="scope">
            <a href="javascript:;"
               @click="editSpHandle(scope.row, '销售奖励费-计提', 'salesBonusFeeAccrual')">{{ scope.row.salesBonusFeeAccrual | twoFloat }}</a>
          </template>
        </el-table-column>
        <el-table-column label="销售奖励费-付款"
                         align="center"
                         prop="salesBonusFeePayment">
          <template slot-scope="scope">
            <a href="javascript:;"
               @click="editSpHandle(scope.row, '销售奖励费-付款', 'salesBonusFeePayment')">{{ scope.row.salesBonusFeePayment | twoFloat }}</a>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <el-pagination
      class="listPagination"
      :current-page="page.currentPage"
      :page-size="page.pageSize"
      :page-sizes="page.pageSizesArr"
      layout="total, sizes, prev, pager, next, jumper"
      :total="page.total"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    ></el-pagination>

    <!-- 编辑 -->
    <el-dialog :title="dialogTile"
               :visible.sync="dialogFormVisible">
      <el-form ref="editForm"
               :model="editForm"
               :rules="rules">
        <el-form-item label=""
                      label-width="100"
                      prop="money">
          <el-input v-model="editForm.money"
                    autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="dialogFormVisible = false">
          取 消
        </el-button>
        <el-button type="primary"
                   @click="dialogSubmitHandle">
          提交
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import {mapGetters} from 'vuex'
import { getSPList, exportSpList, importSPList, editSPList } from '../../api/fangkuan'
import {twoFloat} from '../../filters/index'
import {parseEndDay} from '../../utils/formatDate'
// const qs = require('qs')
export default {
  data () {
    let numReg = /^\d+(\.\d+)?$/
    let numValidator = (rule, value, callback) => {
      if (value.trim() === '' || !numReg.test(value)) {
        callback(new Error('录入框不能为空且必须为阿拉伯数字'))
      } else {
        callback()
      }
    }
    return {
      queryData: {
        dealerName: '',
        loanMonthEnd: '',
        loanMonthStart: '',
      },
      tableData: [],
      page: {
        currentPage: 1,
        pageSize: 10,
        pageSizesArr: [10, 20, 30, 40],
        total: 0,
      },
      importData: {},
      exportTimer: null,
      dialogTile: '',
      dialogFormVisible: false,
      editForm: {
        money: '',
        row: {},
        key: '',
      },
      rules: {
        money: [{required: true, validator: numValidator, trigger: 'blur'}],
      },
    }
  },
  computed: {
    ...mapGetters(['spDownloadLoading']),
  },
  mounted () {
    this.getCustomerRepayList()
  },
  methods: {
    getCustomerRepayList () {
      if (this.queryData.loanMonthEnd) this.queryData.loanMonthEnd = parseEndDay(this.queryData.loanMonthEnd)
      if (this.queryData.loanMonthEnd && this.queryData.loanMonthStart) {
        if (
          new Date(this.queryData.loanMonthStart).getTime() >
          new Date(this.queryData.loanMonthEnd).getTime()
        ) {
          this.queryData.loanMonthEnd = ''
          this.queryData.loanMonthStart = ''
          this.$message.warning('放款月份起不得大于放款月份止')
        }
      }
      this.queryData.pageNum = this.page.currentPage
      this.queryData.pageSize = this.page.pageSize
      return new Promise((resolve, reject) => {
        getSPList(this.queryData)
          .then((res) => {
            if (res.data.respCode === '1000') {
              let data = res.data.body
              this.tableData = data.list
              this.page.total = data.total
              resolve(1)
            } else {
              resolve(0)
            }
          })
          .catch((err) => {
            console.log(err)
            resolve(0)
          })
      })
    },
    resetQuery () {
      for (let k in this.queryData) {
        this.queryData[k] = null
      }
      this.getCustomerRepayList()
    },
    handleSizeChange (val) {
      this.page.pageSize = val
      this.getCustomerRepayList()
    },
    handleCurrentChange (val) {
      this.page.currentPage = val
      this.getCustomerRepayList()
    },
    // 编辑
    editSpHandle (row, title = '', key) {
      this.dialogTile = title
      this.dialogFormVisible = true
      this.editForm.money = ''
      this.editForm.key = key
      this.editForm.row = row
    },
    // 编辑提交
    dialogSubmitHandle () {
      this.$refs['editForm'].validate((valid) => {
        if (valid) {
          let {row, key, money: value} = this.editForm
          let data = Object.assign({}, row)
          data[key] = twoFloat(value)
          editSPList(data).then((rst) => {
            this.dialogFormVisible = false
            let res = rst.data
            if (res.respCode === '1000') {
              this.$message.success('修改成功！')
              row[key] = twoFloat(value)
              // this.getCustomerRepayList()
            } else {
              this.$message.warning(res.respMsg)
            }
          })
        } else {
          return false
        }
      })
    },
    // 导入
    importExeHandle (item) {
      // FormData 对象
      const form = new window.FormData()
      // 文件对象
      form.append('billType', 'spServiceFeeBill')
      form.append('inputStream', item.file)
      importSPList(form).then((rst) => {
        if (rst.data.respCode === '1000') {
          this.$message.success('导入数据成功！')
          this.getCustomerRepayList()
        } else {
          this.$message.warning(rst.data.respMsg)
        }
      })
    },
    async tableDownload () {
      if (this.spDownloadLoading) {
        this.$message.warning('文件正在生成')
        return false
      }
      let lists = await this.getCustomerRepayList()
      if (lists && this.tableData.length > 0) {
        exportSpList(this.queryData)
          .then((res) => {
            if (res.data.respCode === '1000') {
              let exportSerialNo = res.data.body.serialNo
              if (!exportSerialNo) return false
              this.$store.dispatch('downloadPollingApi', {
                serialNo: exportSerialNo,
                timer: 'exportTimer',
                notification: 'spReportNotification',
                loading: 'spDownloadLoading',
              })
            }
          })
          .catch((err) => {
            console.log(err)
          })
      } else {
        this.$message.warning('该筛选条件下无表格可下载')
      }
    },
    // 模板下载
    templateDownload () {
      window.location.href = process.env.VUE_APP_BASE_API + '/finance/excel/download/spServiceFeeBillTemplate'
    },
  },
}
</script>
<style lang="scss" scoped>
.listPagination {
  float: right;
  margin-top: 5px;
}
.import-file{
  display:inline-block;
  .el-button--small{
    padding: 7px 15px;
  }
}
.dataTableWrap{
  a{
    color: #627cf1;
  }
}
</style>
<style lang="scss">
.sp-query-form {
  .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 140px;
  }
}
</style>

