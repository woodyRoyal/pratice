<template>
  <div class="approveHandle">
    <div class="tableTitle clearfix">
      <span class="table-title-word">内部审批备注</span>
      <el-button type="primary" size="mini" @click="getCapitalRiskStatus('btnClick')" v-if="storeCapital === 'EX-ZB'">刷新众邦审批结果</el-button>
    </div>
    <!--资方审核结果-->
    <CapitalApproveRes :capitalApproveData="capitalApproveData" v-if="JSON.stringify(capitalApproveData) !== '{}'"></CapitalApproveRes>
    <!--审批具体操作-->
    <el-form :model="approveHandleData" label-position="left" size="mini" :rules="approveHandleDataRules" ref="approveHandleData" :inline-message="true">
      <el-form-item label="审批意见" label-width="18%" prop="operateResult">
        <el-select v-model="approveHandleData.operateResult">
          <el-option v-for="(item, index) in approveHandleList" :key="index" :label="item.desc" :value="item.result"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="审批备注" label-width="18%" prop="approveRemarks">
        <el-input type='textarea' v-model="approveHandleData.approveRemarks"  :maxlength="500" :rows="8" :autosize="true"></el-input>
      </el-form-item>
      <el-form-item label="经销商提醒" label-width="18%" prop="approveRemind">
        <el-input type='textarea' v-model="approveHandleData.approveRemind"  :maxlength="500" :rows="8" :autosize="true"></el-input>
      </el-form-item>
    </el-form>
    <div class="handleBtns">
      <div>
        <el-button type="primary" size="small" @click="submitFn" :loading="isCaseUploading">提交</el-button>
      </div>
    </div>
  </div>
</template>
<script>
  import {approveHandleList, haveRead, approveSubmit, queryCapitalRiskStatus} from '../../../api/caseHandle.js'
  import {mapGetters} from 'vuex'
  import CapitalApproveRes from './capitalApproveResult'
  export default {
    data () {
      return {
        isCaseUploading: false, // 提交loading
        // 三方审批数据
        capitalApproveData: {
          capitalFaceVerifyReason: null,
          capitalFaceVerifyStatus: null,
          capitalRiskAuditDesc: null,
          capitalRiskAuditStatus: null,
          creditApprovalDesc: null,
          creditApprovalStatus: null
        },
        windowCloseTimer: null,
        approveHandleList: [], // 审批意见选项
        // 审批提交数据
        approveHandleData: {
          operateResult: null,
          approveRemarks: '',
          approveRemind: ''
        },
        // 查询已读
        queryHaveRead: {
          applyId: null
        },
        approveHandleDataRules: {
          operateResult: [{required: true, message: '内容不得为空', trigger: 'change'}],
          approveRemarks: [{required: true, message: '内容不得为空', trigger: 'blur'}]
        } // 审批操作校验规则
      }
    },
    mounted () {
      this.getApproveHandleList()
      this.getCapitalRiskStatus()
    },
    computed: {
      ...mapGetters(['authority', 'applyId', 'applyType', 'storeCapital'])
    },
    components: {
      CapitalApproveRes
    },
    methods: {
      // 获取资方审核结果
      getCapitalRiskStatus (type) {
        queryCapitalRiskStatus(+this.applyId).then(res => {
          if (res.data.respCode === '1000') {
            this.capitalApproveData = res.data.body
            if (type === 'btnClick') this.$message.success('操作成功')
          }
        }).catch(err => { console.log(err) })
      },
      // 审批意见
      getApproveHandleList () {
        approveHandleList({applyId: this.applyId}).then(res => {
          if (res.data.respCode === '1000') this.approveHandleList = res.data.body
        }).catch(error => { console.log(error) })
      },
      // 校验已读
      checkHaveRead () {
        this.queryHaveRead.applyId = this.applyId
        return new Promise((resolve, reject) => {
          haveRead(this.queryHaveRead).then(res => {
            if (res.data.respCode === '1000') {
              const flag = res.data.body
              if (!flag) this.$message.warning('请检查未读的消息')
              resolve(res.data.body)
            }
          }).catch(err => {
            reject(err)
          })
        })
      },
      // 提交
      async submitFn () {
        this.isCaseUploading = true
        this.approveHandleData.applyId = this.applyId
        let haveReadStatus = null
        try {
          haveReadStatus = await this.checkHaveRead()
          if (!haveReadStatus) {
            this.isCaseUploading = false
            return false
          }
        } catch (e) {
          this.isCaseUploading = false
          return false
        }
        this.$refs['approveHandleData'].validate(valid => {
          if (!valid) {
            this.isCaseUploading = false
            this.$message.warning('请检查必填字段')
          } else {
            if (haveReadStatus) this.submitAjax()
          }
        })
      },
      // 提交ajax
      submitAjax () {
        approveSubmit(this.approveHandleData).then(res => {
          this.isCaseUploading = false
          if (res.data.respCode === '1000') {
            this.$message.success('操作完成，页面即将关闭！')
            window.onbeforeunload = null // 去除阻止提示
            clearTimeout(this.windowCloseTimer)
            this.windowCloseTimer = setTimeout(() => { window.close() }, 3000)
          }
        }).catch(err => {
          this.isCaseUploading = false
          console.log(err)
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .approveHandle{
    margin-top: 5px;
  }
  .handleBtns{
    width: 100%;
    &>div{
      float: right;
    }
  }
  .table-title-word{
    margin-right: 10px;
  }
</style>
