<template>
  <div class="decryption-index-wrapper">
    <div class="box font-size"> <span class="info-text">导入文件说明：</span>1.文件格式为<span class="import" style="margin-right: 10px;">.txt</span><span>2.单个文件大小不可以超过<span class="import" style="margin-right: 10px;">30M</span></span>
    </div>
    <el-form class="box">
      <el-form-item label="导入待解密文件：" label-width="120">
        <el-upload class="upload-user-defined" name="inputStream" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel,text/plain"
                   :action="uploadExcelUrl" :data="additionalData" :file-list="fileList" :show-file-list="false"
                   :with-credentials="true"
                   :before-upload="handleUploadBefore" :on-success="handleUploadSuccess" :on-error="handleUploadError"
                   :on-progress="handleUploadProgress" :on-change="handleUploadChange" :disabled="isUploading">
           <el-button type="primary" :loading="isUploading" size="mini">选择文件</el-button>
         </el-upload>
        <!--<a href="javascript:;" class="file">选择文件
          <input type="file"  ref="inputFile" title=" " multiple name="upload" @change="handleBulkUploadBefore">
        </a>-->
      </el-form-item>
      <el-form-item  label="已上传:"  label-width="120px">
        <div v-if="!currentFilePathList.length" class="font">暂无已上传文件</div>
        <div v-loading="!allDecryptionSuccess"
             element-loading-text="有文件正在解密，可继续上传文件"
             element-loading-spinner="el-icon-loading"
             element-loading-background="rgba(0, 0, 0, 0.5)"
             style="min-height: 60px;width: 650px;">
         <div class="font" v-for="item in currentFilePathList">{{item.originFileName}}</div>
        </div>
      </el-form-item>
      <div class="box">
        <el-form-item label="导出解密文件：" label-width="120px">
          <!--<el-button type="text" v-if="isSuccess" @click="down">{{downTitle}}</el-button>-->
          <div style="overflow: hidden">
            <el-button v-for="item in decryptionSuccessList" :key="item.decryptFileName" type="text" @click="down(item)" style="display: block">{{ item.decryptFileName}}</el-button>
            <!--<el-button size="mini" type="primary" @click="handleDownloadAll">全部下载</el-button>-->
          </div>
        </el-form-item>
      </div>
    </el-form>
  </div>
</template>

<script>
  import fileApi from '../../api/fileApi.js'
  export default {
    data () {
      return {
        allDecryptionList: [], // 所有解密文件列表
        allDecryptionSuccess: true, // 某一次是否解密成功
        // 当前上传解密的文件
        timer: null,
        currentFilePathList: [],
        allFilePathList: [], // 所有上传的文件
        decryptionSuccessList: [],
        // isSuccess: false,
        // centerDialogVisible: false,
        // status: '解密中',
        fileList: [],
        uploadExcelUrl: fileApi.uploadApi,
        isUploading: false,
        loading: false,
        // downTitle: null,
        total: 0,
        additionalData: {}, // 上传时附带的额外参数
        uploadFileName: '' // 导入文件名
      }
    },
    watch: {
      /* 'total': function () {
        // 次数达到上限，弹窗消失
        if (this.total > 50) {
          this.center()
          this.$message.error('超时：解密文件内容过多或解密失败！')
          // this.status = '解密失败'
          this.total = 0
          // this.isSuccess = false
          // this.centerDialogVisible = false
        }
      } */
    },
    mounted () {},
    destroyed () {
      this.center()
      /* window.clearInterval(this.timer)
      this.timer = null
      this.allDecryptionSuccess = true */
    },
    methods: {
      center () {
        // this.centerDialogVisible = false
        window.clearInterval(this.timer)
        this.timer = null
        this.allDecryptionSuccess = true
      },
      down (val) {
        window.location.href = fileApi.downLoadApi + `?fileName=${val.decryptFileName}&filePath=${val.decryptFileName}`
      },
      handleUploadSuccess (response, file, fileList) {
        this.isUploading = true
        const { respCode, respMsg, body } = response
        if (respCode !== '1000') {
          this.$message.error(respMsg)
          this.isUploading = false
        }
        if (respCode === '1000') {
          this.$message.success('上传成功，进入解密')
          this.isUploading = false
          // this.status = '解密中'
          // this.centerDialogVisible = true
          if (this.currentFilePathList.length >= 10) {
            this.$message.warning('上传文件不超过10个')
            return false
          }
          this.currentFilePathList.push(body)
          // this.currentFilePathList.forEach(t => { t.decryptFileName = t.decryptFileName.substring(t.decryptFileName.lastIndexOf('/') + 1) })
          if (this.allDecryptionSuccess) {
            this.startsetInterval() // 开启定时器
          }
        }
      },
      startsetInterval () {
        this.queryDecryptedFile(this.currentFilePathList)
        let _this = this
        this.timer = setInterval(function () { _this.queryDecryptedFile(_this.currentFilePathList); _this.total += 1 }, 3000)
      },
      handleUploadBefore (file) {
        if (file.name && file.name.length > 0) {
          // this.isSuccess = false // 隐藏上一个解密后的文件（不让其下载）
          const ldot = file.name.lastIndexOf('.')
          const type = file.name.toLowerCase().substring(ldot)
          let count = 0
          if (type === '.txt') {
            count++
          }
          if (!count) {
            this.$message.warning('目前只支持.txt格式的文件')
            return false
          }
          const m = file.size / 1024 / 1024
          if (Math.ceil(m) > 30) {
            this.$message.warning('上传的文件过大，无法上传')
            return false
          }
          let name = file.name
          let isSameName = this.currentFilePathList.some(t => t.originFileName === name)
          if (isSameName) {
            this.$message.warning('请勿重复上传同一文件')
            return false
          }
          // 上传参数名（fix bug: 这次是上次的参数）
          this.additionalData.fileName = this.uploadFileName = file.name
        }
      },
      async queryDecryptedFile (data) {
        fileApi.queryDecryptedFile(JSON.stringify(data))
          .then(response => {
            const { respCode, body } = response.data
            if (respCode === '1000') {
              this.allDecryptionSuccess = false
              this.allDecryptionList = body.list // 所有解密文件列表
              this.decryptionSuccessList = body.list.filter((item) => item.decryptResult === 1)
              // 将参数里面的上传结果置为1
              this.decryptionSuccessList.forEach(t => {
                this.currentFilePathList.forEach(item => {
                  if (item.originFileName === t.originFileName) {
                    item.decryptResult = t.decryptResult
                  }
                })
              })
              if (body.descryptOver) {
                let isAllDecryptionSuccess = this.allDecryptionList.some(t => t.decryptResult === 0 || t.decryptResult === 2)
                let arr = this.allDecryptionList.filter(t => t.decryptResult === 0 || t.decryptResult === 2)
                let str = ''
                arr.forEach(item => { str += (item.originFileName + ',') })
                if (isAllDecryptionSuccess) this.$message.warning('(' + str.substring(0, str.length - 1) + ')' + '文件解密失败')
                if (!isAllDecryptionSuccess) this.$message.success('全部解密成功')
                this.center() // 重置
                /* window.clearInterval(this.timer)
                this.timer = null
                this.allDecryptionSuccess = true */
              }
              return false
            }
            // errorCode不等于0的异常情况
            if (this.timer) {
              this.center()
              /* window.clearInterval(this.timer)
              this.timer = null
              this.allDecryptionSuccess = true */
            } else {
              this.$message.error('解密失败')
              this.allDecryptionSuccess = true
            }
          })
          .catch(error => {
            if (this.timer) {
              this.center()
              /* window.clearInterval(this.timer)
              this.timer = null
              this.allDecryptionSuccess = true */
            } else {
              this.$message.error('解密失败')
              this.allDecryptionSuccess = true
            }
            console.log(error)
          })
      },
      // 文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
      handleUploadChange (file, fileList) {
        this.isUploading = false // 加载关闭
        console.log('上传完成')
      },
      handleUploadProgress (event, file, fileList) {
        this.isUploading = true // 加载中
        console.log('上传中...')
      },
      handleUploadError (err, file, fileList) {
        if (err.status === 404) {
          this.$message.error('上传失败，网络连接异常!')
        } else {
          console.log(err)
          this.$message.error('上传失败!')
        }
      }
      // 原生
      // 批量上传
      /* handleBulkUploadBefore (e) {
        let uploadArr = e.target.files
        if (!uploadArr.length) return // 如果没有则不触发
        let fileNames = [] // 上传文件名
        let inputStreams = [] // 上传文件流
        let fileType = [] // 上传扩展名
        let fileSize = 0 // 上传文件的大小
        for (let i = 0; i < uploadArr.length; i++) {
          fileNames.push(uploadArr[i].name)
          inputStreams.push(uploadArr[i])
          fileType.push(uploadArr[i].name.toLowerCase().substring(uploadArr[i].name.lastIndexOf('.')))
          fileSize += uploadArr[i].size / 1024 / 1024
        }
        console.log(fileSize)
        let isTypeMatch = fileType.every(f => f === '.xlsx' || f === '.xls' || f === '.txt')
        if (!isTypeMatch) {
          this.$message.warning('目前只支持.xlsx 和 .xls 和 .txt格式的文件')
          return false
        }
        if (fileSize > 100) return this.$message.warning('上传的文件不得超过100M')
        // 确定上传
        this.handleBulkUpload(inputStreams, fileNames)
      }, */
      // 确定上传
      /* handleBulkUpload (inputStreams, fileNames) {
        let formData = new FormData()
        formData.append('inputStreams', inputStreams)
        formData.append('fileNames', fileNames)
        fileApi.uploadApi(formData)
          .then(response => {
            // this.isUploading = true
            if (response.errorCode === 2) {
              this.centerDialogVisible = true
              // this.status = '解密失败'
              this.handleClearFiles()
              // this.isUploading = false
            }
            if (response.errorCode !== 0 && response.errorCode !== 2) {
              this.$message.error(response.errorMsg)
              this.handleClearFiles()
              // this.isUploading = false
            }
            if (response.errorCode === 0) {
              this.$message.success('上传成功，进入解密')
              // this.isUploading = false
              // this.status = '解密中'
              this.centerDialogVisible = true
              this.currentFilePathList = response.data
              if (this.currentFilePathList.length) {
                this.queryDecryptedFile(this.currentFilePathList)
                let _this = this
                this.timer = setInterval(function () { _this.queryDecryptedFile(_this.currentFilePathList); _this.total += 1 }, 3000)
              }
            }
          })
          .catch(error => {
            console.log(error)
          })
      } */
    }
  }
</script>
<style lang="scss" scoped>
  .info-text{
    color: red
  }
  .font-size {
    font-size: 15px;
  }
  .el-form-item {
    margin-bottom: 5px;
  }
  .box{
    padding-top: 20px;
    padding-bottom: 20px;
  }
  .upload-user-defined {
    display: inline-block
  }
  .center{
    text-align: center
  }
  .el-button+.el-button {
    margin-left: 0px;
  }
  .font {
    color:#409eff;
    font-size:14px;
  }
  .import {
    color:red;
    text-decoration: underline;
    font-weight: bolder;
    font-size:15px;
  }
</style>
