<!--用户管理-->
<template>
  <div class="user-manage">
    <!--表单-->
    <el-form :inline="true" :model="queryFormData" class="form-user-defined">
      <el-row>
        <el-col class="form-btn">
          <el-form-item label="账号">
            <el-input style="width:100px;" size="small" v-model="queryFormData.username"></el-input>
          </el-form-item>
          <el-form-item label="角色">
            <el-select style="width:100px;" size="small" v-model="queryFormData.roleId">
              <el-option v-for="item in roleListData" :key="item.id" :label="item.role" :value="item.id">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="状态">
            <el-select style="width:100px;" size="small" v-model="queryFormData.status">
              <el-option v-for="(item,index) in status" :label="item" :key="index"
                         :value="index === ''? null :Number(index)"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearchData" size="small">搜索</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row style="width: 100%">
      <el-table-column align="center" prop="displayName" label="显示名"></el-table-column>
      <el-table-column align="center" prop="username" label="账号"></el-table-column>
      <el-table-column align="center" label="角色" min-width="100px" prop="roleName"></el-table-column>
      <el-table-column align="center" label="账号状态">
        <template slot-scope="scope">
          <span v-if="scope.row.status === 1">启用</span>
          <span v-else style="color: red;">禁用</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="编辑权限" min-width="200px">
        <template slot-scope="scope">
          <span v-if="scope.row.id !== userId">
            <el-button v-if="scope.row.id !== 1" type="primary" @click='handleEditUser(scope.row)' size="mini"
                       icon="edit">编辑
            </el-button>
            <!--禁用-->
            <el-button v-if="scope.row.status === 1 && scope.row.id !== 1" type="warning"
                       @click="handleEnableOrDisableUserType(scope.row, 0)"
                       size="mini">
              禁用用户
            </el-button>
             <el-button v-if="scope.row.status === 0 && scope.row.id !== 0" type="success"
                        @click="handleEnableOrDisableUserType(scope.row, 1)"
                        size="mini">
              启用用户
            </el-button>
          </span>
        </template>
      </el-table-column>
    </el-table>
    <!--分页-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="queryFormData.pageNo" :page-sizes="pageSizes"
                     :page-size="queryFormData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="queryFormData.totalRecord">
      </el-pagination>
    </div>

    <!--编辑角色-->
    <el-dialog width="30%" title="编辑" :model="addOrEditUserform" :rules="addOrEditUserform" ref="addOrEditUserform"
               :visible.sync="dialogFormVisible" @close="handleDialogClose"
               class="add-edit-role-dialog">
      <el-form label-width="80px">
        <el-form-item label="员工姓名" prop="role">
          <el-input v-model="addOrEditUserform.username" auto-complete="off" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="分配角色">
          <el-select style="width:150px;" size="small" v-model="addOrEditUserform.roleId">
            <el-option v-for="item in roleListDataFen" :key="item.id" :label="item.role" :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleDialogClose">取 消</el-button>
        <el-button type="primary" @click="handleEnableOrDisableUser">保 存</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import {
    fetchSyncAllUser,
    fetchUserList,
    fetchSystemList,
    fetchRoleList2,
    fetchSaveOrUpdateUser,
    fetchResetPassword,
    fetchUsernameIsExists,
    fetchDisplayNameIsExists,
    fetchEditeOrEnableOrDisableUser,
    fetchBatchUserResultList,
    URL_UPLOAD_BATCH_USER,
    URL_DOWNLOAD_BATCH_TEMPLET,
    URL_DOWNLOAD_BATCH_USER_RESULT
  } from '../../api/sys'
  import { STATUS } from './sysConstant'

  export default {
    computed: {
      ...mapGetters([
        'userId'
      ]),
      additionalData () { // 上传时附带的额外参数
        return {
          'type': this.isBatchAddDialog ? 'insert' : 'update'
        }
      }
    },
    data () {
      // 校验用户名是否可用
      const validateUsername = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入用户名'))
        } else {
          if (value !== this.currentUsername) {
            fetchUsernameIsExists(value)
              .then(response => {
                if (response.data.rtn === '000' && response.data.result.valid === 0) { // 1可用 0 不可用
                  callback(new Error('用户名已存在'))
                } else {
                  callback()
                }
              })
              .catch(error => {
                callback(error)
              })
          } else {
            callback()
          }
        }
      }// 校验显示名是否可用
      const validateDisplayName = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入显示名'))
        } else {
          if (value !== this.currentDisplayName) {
            fetchDisplayNameIsExists(value)
              .then(response => {
                if (response.data.rtn === '000' && response.data.result.valid === 0) { // 1可用 0 不可用
                  callback(new Error('显示名已存在'))
                } else {
                  callback()
                }
              })
              .catch(error => {
                callback(error)
              })
          } else {
            callback()
          }
        }
      }
      return {
        status: STATUS,
        // 查询表单参数
        queryFormData: {
          username: null, // 用户名
          displayName: '', // 显示名
          pageSize: 50, // 每页条数
          pageNo: 1, // 页码
          totalRecord: null, // 总记录数
          totalPage: null, // 总页数
          roleId: null, // 角色
          valid: null,
          status: null
        },
        pageSizes: [50, 100, 200],
        tableData: null, // 表数据
        listLoading: false,

        dialogFormVisible: false, // 显示新增用户框
        isAddDialog: true,

        systemList: [], // 业务系统列表
        systemListMap: {}, // 业务系统对象
        roleListData: [], // 角色列表数据
        roleListDataFen: [], // 分配角色列表数据
        roleListMap: {}, // 角色列表对象
        noLimit: [{'role': '不限', id: null}], // 添加角色列表的不限选择项

        addOrEditUserform: { // 新增用户表单
          id: '',
          username: null,
          displayName: '',
          oaUid: '', // OA系统用户ID
          roleIds: [], // 用户角色id数组 页面使用
          sysIds: [], // 用户角色id数组 页面使用
          valid: 1, // 1_有效用户 0_无效用户
          hasUserExtension: false, // 是否有扩展信息
          userExtension: { // 用户扩展信息
            userId: '', // 用户Id
            serviceNum: '', // 批呼坐席号
            autoAssignCase: 0 // 是否自动分配案件
          },
          roleId: null,
          status: 1
        },

        // 新增用户表单输入验证规则
        addOrEditUserformRules: {
          username: [
            {validator: validateUsername, trigger: 'blur'}
          ],
          displayName: [
            {validator: validateDisplayName, trigger: 'blur'}
          ]
        },
        currentUsername: '', // 当前打开的用户
        currentDisplayName: '', // 当前打开的用户

        isBatchAddDialog: true, // 是否是批量新增
        batchUserdialogVisible: false, // 批量操作用户弹窗
        uploadUsersUrl: '',
        resultTableMaxHeight: 0, // 批量结果表格最大高度
        resultTableData: null, // 结果表数据
        resultListLoading: false,
        operateTime: '', // 导入时间
        successCount: 0, // 成功条数
        failedCount: 0, // 失败条数
        refreshBtnFlag: true, // 刷新按钮限时点击
        uploadBtnLoading: false, // 上传按钮控制

        // 静态地址
        URL_UPLOAD_BATCH_USER, // 批量新增上传地址
        URL_DOWNLOAD_BATCH_TEMPLET, // 批量操作模板地址
        URL_DOWNLOAD_BATCH_USER_RESULT // 导出失败记录地址 type: insert-新增, update-更新
      }
    },
    mounted () {
      this.getSyncAllUser() //  从用户中心拉取审批系统用户
      // this.getTableData()
      // this.getSystemList()
      this.getRoleList() // 获取角色列表
    },
    methods: {
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.queryFormData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.queryFormData.pageNo = val
        this.getTableData()
      },
      // 搜索按钮
      handleSearchData () {
        this.getTableData()
      },
      // 获取审批系统数据
      getSyncAllUser () {
        fetchSyncAllUser().then(response => {
          this.getTableData()
        }).catch(error => {
          console.log(error)
        })
      },
      // 获取表格数据
      getTableData () {
        this.listLoading = true
        fetchUserList(this.queryFormData.username, this.queryFormData.roleId, this.queryFormData.status, this.queryFormData.pageNo, this.queryFormData.pageSize)
          .then(response => {
            if (!response.data.errorMessage) {
              if (!response.data.result.content) {
                let result = response.data.result
                // 遍历处理数据
                this.tableData = result.content
              } else {
                let result = response.data.result
                // 遍历处理数据
                this.tableData = result.content
                this.queryFormData.totalRecord = result.totalRecord
                this.queryFormData.totalPage = result.totalPage
                this.queryFormData.pageNo = result.pageNo
                this.queryFormData.pageSize = result.pageSize
              }
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 获取系统列表
      getSystemList () {
        fetchSystemList()
          .then(response => {
            if (response.data.rtn === '000' && response.data.result) {
              // 数组转map对象
              this.systemList = response.data.result
              if (this.systemList && this.systemList.length > 0) {
                for (let item of this.systemList) {
                  this.systemListMap[item.id] = item.sysName
                }
              }
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      handleConfirmRole () {

      },
      // 获取角色列表
      getRoleList () {
        fetchRoleList2()
          .then(response => {
            if (response.data.code === '000' || response.data.result) {
              this.roleListDataFen = response.data.result
              this.roleListData = response.data.result.concat(this.noLimit)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 点击新增按钮，打开dialog
      openUserDialog () {
        // 打开dialog
        this.isAddDialog = true
        this.dialogFormVisible = true
        this.currentUsername = ''
        this.currentDisplayName = ''
      },
      // 确认添加用户
      handleAddUserConfirm () {
        this.submitForm('addOrEditUserform')
      },
      // 取消添加用户
      handleAddUserCancel () {
        this.dialogFormVisible = false
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let queryParams = {
              id: this.addOrEditUserform.id,
              username: this.addOrEditUserform.username,
              displayName: this.addOrEditUserform.displayName,
              oaUid: this.addOrEditUserform.oaUid,
              roleIds: this.addOrEditUserform.roleIds.join(','),
              sysIds: this.addOrEditUserform.sysIds.join(','),
              valid: this.addOrEditUserform.valid
            }
            if (this.addOrEditUserform.hasUserExtension) {
              queryParams.userExtension = this.addOrEditUserform.userExtension
              queryParams.userExtension.userId = this.addOrEditUserform.id
            } else {
              queryParams.userExtension = null
            }
            this.saveOrUpdateUser(queryParams)
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      // add Dialog 关闭的回调
      handleDialogClose () {
        // 用户表单置空
        this.addOrEditUserform = {
          id: '',
          username: '',
          displayName: '',
          oaUid: '', // OA系统用户ID
          roleIds: [], // 用户角色id数组 页面使用
          sysIds: [], // 用户角色id数组 页面使用
          valid: 1, // 1_有效用户 0_无效用户
          hasUserExtension: false, // 是否有扩展信息
          userExtension: { // 用户扩展信息
            userId: '', // 用户Id
            serviceNum: '', // 批呼坐席号
            autoAssignCase: 0 // 是否自动分配案件
          },
          roleId: null
        }
        this.dialogFormVisible = false
        // this.$refs['addOrEditUserform'].resetFields()
      },
      // 点击编辑按钮，打开dialog
      handleEditUser (user) {
        this.dialogFormVisible = true
        this.addOrEditUserform.id = user.id
        this.addOrEditUserform.username = user.username
        this.addOrEditUserform.roleId = user.roleId
        this.addOrEditUserform.displayName = user.displayName
        // this.addOrEditUserform.oaUid = user.oaUid
        // this.addOrEditUserform.roleIds = user.roleList
        this.addOrEditUserform.status = user.status
        // let arr = []
        // user.sysList.map(item => {
        //    arr.push(item.sysId)
        //      return item
        // })
        // this.addOrEditUserform.sysIds = arr
        // if (user.userExtension) {
        //   this.addOrEditUserform.hasUserExtension = true
        //   this.addOrEditUserform.userExtension = user.userExtension
        //  } else {
        //   this.addOrEditUserform.hasUserExtension = false
        //  }
        //    // 打开dialog
        //   this.isAddDialog = false
        this.currentUsername = user.username
        this.currentDisplayName = user.displayName
      },
      // 新增或修改用户
      saveOrUpdateUser (user) {
        fetchSaveOrUpdateUser(user)
          .then(response => {
            let res = response.data
            if (res.rtn === '000') {
              this.$message.success('操作成功')
              this.dialogFormVisible = false
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 处理重置密码
      handleResetPassword (userId) {
        fetchResetPassword(userId)
          .then(response => {
            if (response.data.rtn === '000') {
              this.$message.success('密码已重置为123456')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 保存用户
      handleEnableOrDisableUser (user, vaild) {
        fetchEditeOrEnableOrDisableUser(this.addOrEditUserform.id, this.addOrEditUserform.status, this.addOrEditUserform.username, this.addOrEditUserform.roleId)
          .then(response => {
            if (response.data.code === '000') {
              this.$message.success('保存成功')
              this.dialogFormVisible = false
              this.getTableData()
            }
          })
          .catch(error => {
            console.log(error)
            this.dialogFormVisible = false
          })
      },
      // 启用或禁用
      handleEnableOrDisableUserType (user, vaild) {
        this.addOrEditUserform.id = user.id
        this.addOrEditUserform.status = user.status ? 0 : 1
        this.addOrEditUserform.username = user.username
        this.addOrEditUserform.roleId = user.roleId
        fetchEditeOrEnableOrDisableUser(this.addOrEditUserform.id, this.addOrEditUserform.status, this.addOrEditUserform.username, this.addOrEditUserform.roleId)
          .then(response => {
            if (response.data.code === '000') {
              this.$message.success((vaild === 1 ? '启用' : '禁用') + '成功')
              user.status = vaild
              this.getTableData()
            }
          })
          .catch(error => {
            console.log(error)
            this.dialogFormVisible = false
          })
      },
      // 点击批量按钮，打开dialog
      openBatchUserDialog (code) {
        // 打开dialog
        this.isBatchAddDialog = code === 1
        this.batchUserdialogVisible = true
      },
      // 上传
      handleSubmitUpload () {
        let uploadFiles = this.$refs['batchUserUploader'].uploadFiles
        if (!uploadFiles || uploadFiles.length === 0) {
          this.$message.warning('请选择文件')
          return false
        }
        if (uploadFiles.length > 1) {
          this.$message.warning('系统只支持上传一个文件')
          return false
        }

        if (!this.uploadBtnLoading) {
          this.$nextTick(() => {
            this.$refs['batchUserUploader'].submit()
            console.log('start upload...')
          })
        }
      },
      // 文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
      handleUploadChange (file, fileList) {
        let uploadFiles = this.$refs['batchUserUploader'].uploadFiles
        if (uploadFiles && uploadFiles.length > 1) { // 只能上传一个文件
          this.$refs['batchUserUploader'].uploadFiles = [file]
        }
      },
      // 文件上传时的钩子
      handleUploadProgress (event, file, fileList) {
        this.uploadBtnLoading = true // 开启提示
        this.resultListLoading = true
        console.log('上传中...')
      },
      // 文件上传成功时的钩子
      handleUploadSuccess (response, file, fileList) {
        console.log('Success upload...')
        let errorCode = response.rtn
        if (errorCode === '000') {
          this.$message.success('上传成功!')
          this.uploadBtnLoading = false
          this.getUploadResult()
          this.getTableData()
        } else if (errorCode === '996' || errorCode === '995' || errorCode === '991') {
          this.$message.error(response.message)
          // 登出并返回到登录页
          this.$store.dispatch('Logout').then(() => {
            this.$router.push({path: '/login', query: {redirect: this.$router.fullPath}})
          })
        } else {
          this.$message.error(response.message)
        }
      },
      // 文件上传失败时的钩子
      handleUploadError (err, file, fileList) {
        console.log('ERR upload...')
        if (err.status === 404) {
          this.$message.error('上传失败，网络连接异常!')
        } else {
          console.log(err)
          this.$message.error('上传失败!')
        }
      },

      // 批量操作弹窗关闭前事件
      handleBatchDialogBeforeClose (done) {
        if (this.uploadBtnLoading) {
          this.$message.info('文件正在上传，请稍后关闭...')
          return false // 阻止关闭弹窗
        }
        done() // 继续关闭弹窗
      },
      // batch Dialog 关闭的回调
      handleBatchDialogClose () {
        // 还原数据
        this.resultTableData = null // 结果表数据
        this.successCount = 0 // 成功条数
        this.failedCount = 0 // 失败条数
        this.operateTime = '' // 失败条数
        this.$refs['batchUserUploader'].clearFiles()
      },
      getUploadResult () {
        let type = this.isBatchAddDialog ? 'insert' : 'update'
        // 获取上传结果
        fetchBatchUserResultList(type)
          .then(response => {
            if (response.data.rtn === '000' && response.data.result) {
              let result = response.data.result
              this.resultTableData = result.failedList // 结果表数据
              this.successCount = result.successCount // 成功条数
              this.failedCount = result.failedCount // 失败条数
              this.operateTime = result.operateTime // 失败条数
            }
            this.resultListLoading = false
          })
          .catch(error => {
            console.log(error)
            this.resultListLoading = false
          })
      },
      // 点击刷新上传结果
      refreshResult () {
        if (this.refreshBtnFlag) {
          this.refreshBtnFlag = false // 刷新间隔标志
          this.resultListLoading = true
          this.getUploadResult()
          setTimeout(() => {
            this.refreshBtnFlag = true
          }, 5000)
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .form-user-defined {
    .el-form-item {
      margin-right: 20px;
      margin-bottom: 10px;
    }
    .form-btn {
      text-align: left;
      .el-form-item {
        margin-right: 0;
      }
    }
  }

  .add-edit-user-dialog {
    .el-form-item {
      margin-bottom: 18px;
    }
    .el-select {
      width: 50%;
    }
  }

  .user-extention {
    background-color: #eef1f6;
    padding-top: 5px;
    .el-form-item {
      margin-bottom: 5px;
    }
  }

  .postscript {
    font-size: 12px;
    margin-left: 100px;
    margin-bottom: 10px;
  }

  .upload-users-form {
    .el-form-item {
      margin-bottom: 0;
    }
    // 用户管理 批量新增 上传组件
    .upload-users {
      .el-upload__tip {
        margin-top: 0;
        position: absolute;
        top: 0;
        left: 200px;
      }
      .el-upload-list {
        width: 60%;
      }
    }
  }

  .upload-result {
    display: flex;
    justify-content: space-between;
    height: 36px;
    line-height: 36px;
    .upload-result-oper {
      .refresh-result {
        width: 30px;
      }
    }
  }
</style>
