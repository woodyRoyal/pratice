<template>
  <div class="attached-company-detail-wrap">
    <div class="form-section-title">企业信息</div>
    <el-form size="small" :model="attachedCompanyForm" ref="attachedCompanyForm">
      <el-row :gutter="5">
        <el-col :span="8">
          <el-form-item label="挂靠公司名称" class="is-required">
            <el-input v-model="attachedCompanyForm.companyName" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="挂靠公司统一社会信用代码" class="is-required">
            <el-input v-model="attachedCompanyForm.unifiedSocialCreditCode" disabled></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="5">
        <el-col :span="8">
          <el-form-item label="挂靠公司法人姓名" class="is-required">
            <el-input v-model="attachedCompanyForm.legalPersonName" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="挂靠公司法人身份证号" class="is-required">
            <el-input v-model="attachedCompanyForm.legalPersonCertId" maxlength="18" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="挂靠公司法人手机号" class="is-required">
            <el-input v-model="attachedCompanyForm.legalPersonPhone" maxlength="11" disabled></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <!--文件-->
    <FileUpload
      applyNode="attached_file"
      :showSaveButton="false"
      :hideSideTitle="false"
      :hideAllUploadSwitch="hideAllUploadSwitch"
      :hideTree="true"
      :hideDeleteBtn="hideDeleteBtn"
      :necessaryUploadData="requiredFilesList"
      :unNecessaryUploadData="notRequiredFilesList"
      :optionalTreeData="[]"
      @showPicView="showPicViewHandle"
    ></FileUpload>
    <!--协议-->
    <div class="check-radio-wrap">
      <el-checkbox v-model="isProtocolSelected" disabled>我已阅读并同意</el-checkbox>
      <el-button type="text" size="small" @click="() => {showProtocolHandle(1)}">《挂靠公司查询信息授权书》</el-button>
      <el-button type="text" size="small" @click="() => {showProtocolHandle(2)}">《挂靠公司法人信息查询信息授权书》</el-button>
    </div>
    <!--审批状态-->
    <el-table border :data="approveTableData">
      <el-table-column label="审批状态" align="center" prop="submitStatusDesc"></el-table-column>
      <el-table-column label="审批描述" align="center" prop="remark"></el-table-column>
    </el-table>
    <!--协议弹窗-->
    <el-dialog :visible.sync="protocolShow">
      <div class="temp-wrap" v-html="templateType === 1 ? protocolTemp.template1 : protocolTemp.template2" ref="tempWrap"></div>
    </el-dialog>
    <!--图片预览-->
    <div class="pic-view-wrap" v-drag v-if="showPicView">
      <PicView v-if="showPicView" :imgItemList="imgItemList" :clickItem="clickItem" @closePicView="closePicViewHandle"></PicView>
    </div>
  </div>
</template>
<script>
  import PicView from '../../components/PicView/index'
  import FileUpload from '../../components/fileUpload/index'
  import protocolTemp from './constant'
  import {getAttachedCompanyDetail} from '../../api/attachedCompanyApi'
  import {formatPhone, formatPapers, formatName} from '../../filters'
  export default {
    data () {
      return {
        attachedCompanyForm: {
          id: null,
          companyName: '',
          unifiedSocialCreditCode: '',
          legalPersonName: '',
          legalPersonCertId: '',
          legalPersonPhone: ''
        },
        requiredFilesList: [], // 必传文件
        notRequiredFilesList: [], // 非必传文件
        isProtocolSelected: true,
        approveTableData: [],
        protocolShow: false,
        templateType: 1,
        protocolTemp,
        showPicView: false,
        clickItem: {}, // 点击的图片
        hideAllUploadSwitch: true, // 隐藏上传控件
        hideDeleteBtn: true // 隐藏删除按钮
      }
    },
    components: {
      FileUpload,
      PicView
    },
    mounted () {
      const {id} = this.$route.params
      this.getFormInfo(id)
    },
    methods: {
      getFormInfo (id) {
        getAttachedCompanyDetail(id).then(res => {
          const {respCode, body} = res.data
          if (respCode === '1000') {
            const {fileCategoryVo, id, authorized, companyName, unifiedSocialCreditCode, legalPersonName, legalPersonCertId, legalPersonPhone, submitStatusDesc, remark} = body
            this.isProtocolSelected = Boolean(authorized)
            this.attachedCompanyForm = {
              id,
              companyName,
              unifiedSocialCreditCode,
              legalPersonName: formatName(legalPersonName),
              legalPersonCertId: formatPapers(legalPersonCertId),
              legalPersonPhone: formatPhone(legalPersonPhone)}
            const {notRequiredFileCategoryListVos, requiredFileCategoryListVos} = fileCategoryVo
            this.requiredFilesList = requiredFileCategoryListVos
            this.notRequiredFilesList = notRequiredFileCategoryListVos
            this.approveTableData = [{submitStatusDesc, remark}]
          }
        }).catch(err => { console.error(err) })
      },
      // 挂靠协议
      showProtocolHandle (type) {
        this.protocolShow = true
        this.templateType = type
      },
      showPicViewHandle (data) {
        this.showPicView = true
        this.imgItemList = data.imgItemList
        this.clickItem = data.clickItem
      },
      closePicViewHandle () {
        this.showPicView = false
      }
    }
  }
</script>
<style lang="scss" scoped>
  .attached-company-detail-wrap{
    margin: 5px;
  }
  .check-radio-wrap{
    display: flex;
    justify-content: center;
    margin-bottom: 10px;
    .el-button--small, .el-button--small.is-round{
      padding: 0 3px;
    }
    .el-button+.el-button{
      margin-left: -7px;
    }
  }
  .form-submit-btn-wrap{
    display: flex;
    justify-content: center;
    margin-bottom: 10px;
  }
  .el-message-box--center{
    padding-bottom: 0;
  }
  .pic-view-wrap{
    position: absolute;
    top: 0;
    left: 50%;
    background: #fff;
    z-index: 1000;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.3);
  }
</style>
