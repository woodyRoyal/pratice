<template>
  <div class="attachment-wrapper">
    <!--<p class="font">-->
      <!--温馨提示：系统支持上上传的文件类型（*.pdf,*.docx,*.doc,*.jpg,*.jpeg,*.bmp,*.png,*.zip,*.rar,*.msg,*.eml,*.txt,*.wav)<br/>-->
      <!--单个word文件最大不能超过50.00MB，单个excel文件最大不能超过50.0MB，单个图片最大不能超过50.0MB，单个pdf文件最大不能超过50.0MB，单个压缩包文件最大不能超过20.0MB。-->
    <!--</p>-->
    <!--<hr style="margin-left:20px;"/>-->
    <div class="fileUploadWrap">
      <FileUpload
        v-if="optionalTreeData.length"
        :showSaveButton="true"
        :hideTree="false"
        applyNode="dealer_file"
        :necessaryUploadData="[]"
        :unNecessaryUploadData="notRequiredFilesList"
        :optionalTreeData="optionalTreeData"
        @changeUnNecessaryUploadData="changeUnNecessaryUploadDataHandle"
        @deleteFileItem='deleteFileItemHandle'
        @showPicView="showPicViewHandle"
        @saveUploadFiles="saveUploadFilesHandle"
      ></FileUpload>
    </div>
    <div class="pic-view-wrap" v-drag v-if="showPicView">
      <PicView v-if="showPicView" :imgItemList="imgItemList" :clickItem="clickItem" @closePicView="closePicViewHandle"></PicView>
    </div>
  </div>
</template>

<script>
  import FileUpload from '../../components/fileUpload/index'
  import {dealerImgMenu, filesGet, saveUploadFiles, deleteImgItem} from '../../api/upload.js'
  import PicView from '../../components/PicView/index'
  export default {
    data () {
      return {
        optionalTreeData: [],
        notRequiredFilesList: [],
        showPicView: false,
        imgItemList: []
      }
    },
    mounted () {
      this.getAttachmentList()
      if (this.$route.params.id !== 'null') this.getAttachmentFilesList() // 拉取图片下拉
    },
    components: { FileUpload, PicView },
    methods: {
      getAttachmentFilesList () {
        filesGet({dealerId: this.$route.params.id, categoryList: ['dealer_file'], showFaultFile: false}).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            // this.requiredFilesList = data.requiredFileCategoryListVos
            this.notRequiredFilesList = data.notRequiredFileCategoryListVos
          }
        }).catch(err => { console.log(err) })
      },
      // 获取附件下拉
      getAttachmentList () {
        dealerImgMenu({dictCategory: 'dealer_file'})
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') this.optionalTreeData = res.body
            console.log(this.optionalTreeData)
          })
          .catch(error => { console.log(error) })
      },
      // 替换非必传文件
      changeUnNecessaryUploadDataHandle (data) {
        this.notRequiredFilesList = data.notRequiredFilesList
      },
      // 文件预览
      showPicViewHandle (data) {
        this.showPicView = true
        this.clickItem = data.clickItem
        this.imgItemList = data.imgItemList
      },
      // 关闭预览弹窗
      closePicViewHandle () {
        this.showPicView = false
      },
      // 删除回调
      deleteFileApiCallback (data) {
        let forEachData = []
        if (data.isRequired) {
          forEachData = this.requiredFilesList
        } else {
          forEachData = this.notRequiredFilesList
        }
        // 删除
        forEachData.forEach(item => {
          item.pictureListVOList.forEach(item => {
            if (item.dictKey === data.imgItem.fileCategory) {
              item.fileRecordVOList.splice(data.index, 1)
            }
          })
        })
      },
      // 删除文件
      deleteFileItemHandle (data) {
        let copyImgItem = JSON.parse(JSON.stringify(data.imgItem))
        copyImgItem.relatedId = this.$route.params.id
        copyImgItem.relatedGroup = 'dealer_file'
        // copyImgItem.fileCategory = 'dealer_file'
        deleteImgItem(copyImgItem).then(res => {
          if (res.data.respCode === '1000') {
            this.deleteFileApiCallback(data)
            this.$message.success('删除成功')
          }
        }).catch(err => { console.log(err) })
      },
      // 保存文件
      saveUploadFilesHandle (data) {
        this.isSaveDisabled = data.isSaveDisabled
        let apiParams = {dealerId: this.$route.params.id, requiredFileCategoryListVos: [], notRequiredFileCategoryListVos: this.notRequiredFilesList}
        saveUploadFiles(apiParams).then(res => {
          if (res.data.respCode === '1000') {
            this.$message.success('保存成功')
            this.getAttachmentFilesList()
            this.isSaveDisabled = false
          } else {
            this.isSaveDisabled = false
          }
        }).catch(error => {
          this.isSaveDisabled = false
          console.log(error)
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .pic-view-wrap{
    position: absolute;
    top: 0;
    left: 50%;
    background: #fff;
    z-index: 1000;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.3);
  }
</style>
