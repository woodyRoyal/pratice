<template>
  <div class="dealer-online-wrapper">
    <!--<el-breadcrumb>
      <el-breadcrumb-item>经销商管理</el-breadcrumb-item>
      <el-breadcrumb-item>经销商信息维护页</el-breadcrumb-item>
    </el-breadcrumb>
    <hr/>-->
    <!-- 查询表单 -->
    <el-form :inline="true" :form="queryForm">
      <el-form-item label="经销商简称:">
        <el-input size="small" v-model="queryForm.shortName"></el-input>
      </el-form-item>
      <el-form-item label="经销商等级:">
        <el-select v-model="queryForm.dealerClass" placeholder="请选择" size="small" clearable>
          <el-option v-for="item in dealerClass" :label="item.dictName" :value="item.dictValue" :key="item.dictValue"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="handleSearch">查询</el-button>
        <el-button type="primary" size="mini" @click="handleReset">重置</el-button>
        <!--<el-button type="primary" size="mini" @click="handleOnlineSubmit">上线申请</el-button>-->
      </el-form-item>
    </el-form>
    <!-- tab -->
        <el-table border :data="waitSubmitData" :max-height="maxHeight">
          <el-table-column align="center" label="序号">
            <template slot-scope="scope">
              <span>{{ scope.$index + 1 }}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="经销商代码" prop="id"></el-table-column>
          <el-table-column align="center" label="经销商全称" prop="fullName"></el-table-column>
          <el-table-column align="center" label="上线时间" prop="applyDate"></el-table-column>
          <el-table-column align="center" label="保证金">
            <template slot-scope="scope">
              <span>{{ scope.row.bizDeposit + '.00'}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="经销商等级">
            <template slot-scope="scope">
              <span>{{ dealerClassDict[scope.row.dealerClass] }}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="操作" width="160">
            <template slot-scope="scope">
              <el-button type="primary" size="mini" @click="handleEdit(scope.row)">编辑</el-button>
              <el-button type="danger" size="mini" v-if="scope.row.status == 1" @click="handleSet(scope.row)">置为无效</el-button>
              <el-button type="danger" size="mini" v-if="scope.row.status == 2" @click="handleSet(scope.row)">置为有效</el-button>
            </template>
          </el-table-column>
        </el-table>

      <!-- 分页对象 -->
      <div class="pagination-container">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                       :current-page.sync="pagable.pageNo" :page-sizes="pageSizes"
                       :page-size="pagable.pageSize" layout="total, sizes, prev, pager, next, jumper"
                       :total="pagable.totalRecord">
        </el-pagination>
      </div>
  </div>
</template>

<script>
  import dealerApi from '../../api/dealer'
  import { mapGetters } from 'vuex'
  export default {
    computed: {
      ...mapGetters([
        'dealerClass',
        'dealerClassDict'
      ])
    },
    data () {
      return {
        queryForm: {
          shortName: '',
          dealerClass: null
        },
        maxHeight: 100,
        approveStatus: '2',
        waitSubmitData: [], // 待提交数据
        pagable: {
          pageNo: 1,
          pageSize: 10,
          totalRecord: null // 总记录数
        },
        pageSizes: [10, 20, 30, 40]
      }
    },
    mounted () {
      this.getTableData()
      // 调整高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    destroyed () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // 表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let h = document.documentElement.clientHeight
          this.maxHeight = h - 250
        })
      },
      // 查询接口
      handleSearch () {
        this.getTableData() // 获取数据
      },
      // 重置接口
      handleReset () {
        this.queryForm = {
          shortName: '',
          dealerClass: null
        }
        this.pagable = {
          pageNo: 1,
          pageSize: 10,
          totalRecord: null // 总记录数
        }
        this.getTableData()
      },
      // 编辑接口
      handleEdit (val) {
        window.open('#/dealer-maintain/' + val.id)
      },
      getTableData () {
        let data = {
          shortName: this.queryForm.shortName,
          dealerClass: this.queryForm.dealerClass === '' ? null : this.queryForm.dealerClass,
          approveStatus: parseInt(this.approveStatus),
          pageNum: this.pagable.pageNo,
          pageSize: this.pagable.pageSize
        }
        dealerApi.fetchDealerData(data)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.waitSubmitData = res.body.list
              this.pagable.totalRecord = res.body.total
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 点击上线申请
      /* handleOnlineSubmit () {
        window.open('#/dealer-info/null')
      }, */
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagable.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagable.pageNo = val
        this.getTableData()
      },
      // 置为有效或者无效
      handleSet (val) {
        let msg = ''
        val.status === 1 ? msg = '此经销商下的全部用户将无法登录，是否确定将该经销商置为无效' : msg = '是否确定将该经销商置为有效'
        this.$confirm(msg, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.handleSetAgain(val)
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      },
      handleSetAgain (val) {
        let data = {
          id: val.id,
          status: val.status === 1 ? 2 : 1
        }
        dealerApi.fetchUpdateDealerInvalidSetting(data)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.$message.success('操作成功')
              this.getTableData()
            }
          })
          .catch(error => {
            console.log(error)
          })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .dealer-online-wrapper{

  }
</style>