<template>
  <div class="applyprogress-detail-wrap">
    <el-row>
      <el-col :span="15">
        <div ref="leftWrap"
             class="leftWrap">
          <el-tabs v-model="activeName">
            <el-tab-pane label="基本信息"
                         name="1">
              <div ref="leftComponents"
                   class="left-components">
                <CustomerInfo :customer-info-data="customerInfoData"></CustomerInfo>
                <OutofDateInfo :outof-date-data="outofDateInfoData"
                               @updateData="updateOutofDateData"></OutofDateInfo>
                <TradeHistory></TradeHistory>
                <PhoneHistory v-if="authority !== 'INSIDE_SALES'"
                              :tel-verify-data="telVerifyData"></PhoneHistory>
                <!--<dealersTable></dealersTable>-->
                <historyTable></historyTable>
              </div>
            </el-tab-pane>
            <el-tab-pane label="申请详情"
                         name="2"
                         :lazy="true">
              <el-tabs v-model="applyInfoActiveName">
                <el-tab-pane label="车辆信息"
                             name="1">
                  <vehicleInfo :outer-active-table-name="activeName"
                               :inner-active-table-name="applyInfoActiveName"></vehicleInfo>
                </el-tab-pane>
                <el-tab-pane label="融资信息"
                             name="2"
                             :lazy="true">
                  <financing :outer-active-table-name="activeName"
                             :inner-active-table-name="applyInfoActiveName"></financing>
                </el-tab-pane>
                <el-tab-pane label="客户信息"
                             name="3"
                             :lazy="true">
                  <personal v-if="identityType === 0"
                            :outer-active-table-name="activeName"
                            :inner-active-table-name="applyInfoActiveName"></personal>
                  <enterprise v-else
                              :outer-active-table-name="activeName"
                              :inner-active-table-name="applyInfoActiveName"></enterprise>
                </el-tab-pane>
                <el-tab-pane label="附件资料"
                             name="4"
                             :lazy="true">
                  <fileUpload :outer-active-table-name="activeName"
                              :inner-active-table-name="applyInfoActiveName"></fileUpload>
                </el-tab-pane>
                <el-tab-pane v-if="authority !== 'INSIDE_SALES'"
                             label="征信信息"
                             name="5"
                             :lazy="true">
                  <CreditInvestigation :outer-active-table-name="activeName"
                                       :inner-active-table-name="applyInfoActiveName"></CreditInvestigation>
                </el-tab-pane>
              </el-tabs>
            </el-tab-pane>
          </el-tabs>
        </div>
      </el-col>
      <el-col :span="9">
        <div class="rightWrap">
          <div class="formModuleTitle">
            <span>概要信息</span>
          </div>
          <table class="self-table-comp">
            <tbody>
              <tr>
                <td>申请编号</td>
                <td>
                  {{ tableData.applyNum || '/' }}
                  <el-tag v-if="tableData.specialPermit"
                          type="warning"
                          size="mini">
                    特批
                  </el-tag>
                  <el-tag v-if="tableData.reconsideration"
                          type="warning"
                          size="mini">
                    复议
                  </el-tag>
                </td>
                <td>提报店名称</td>
                <td>{{ tableData.storeName || '/' }}</td>
              </tr>
              <tr>
                <td>客户名称</td>
                <td>
                  {{ tableData.customerName || '/' }}
                  <span>（信用评级：{{ tableData.riskCustomerLevel || '/' }})</span>
                </td>
                <td>身份证</td>
                <td>{{ tableData.customerIdNo || '/' }}</td>
              </tr>
              <tr>
                <td>手机号</td>
                <td>{{ tableData.phone || '/' }}</td>
                <td>产品方案</td>
                <td>{{ tableData.productName || '/' }}</td>
              </tr>
              <tr>
                <td>融资期限</td>
                <td>{{ tableData.term || '/' }}</td>
                <td>申请类型</td>
                <td>{{ applyType[tableData.applyType] || '/' }}</td>
              </tr>
              <tr>
                <td>融资总额</td>
                <td>{{ tableData.amount || '/' }}</td>
                <td>租赁类型</td>
                <td>{{ leaseType[tableData.leaseType] || '/' }}</td>
              </tr>
              <tr>
                <td>GPS个数</td>
                <td>{{ tableData.gpsNum === null ? '/' : tableData.gpsNum }}</td>
                <td>车辆类型</td>
                <td>{{ carType[tableData.carType] || '/' }}</td>
              </tr>
              <tr>
                <td>是否融保险</td>
                <td>{{ tableData.isInsurance || '/' }}</td>
                <td>每期租金</td>
                <td>{{ tableData.monthlyRent || '/' }}</td>
              </tr>
              <tr>
                <td>是否先抵押后放款</td>
                <td>{{ tableData.isLoanFirst || '/' }}</td>
                <td>首付比例</td>
                <td>{{ tableData.downPaymentRatio === null ? '/' : tableData.downPaymentRatio }}</td>
              </tr>
              <tr>
                <td>车系类别</td>
                <td colspan="3">
                  {{ tableData.carSeriesDesc || '/' }}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
// import dealersTable from './basicInfoModule/dealers-table.vue'
import historyTable from './basicInfoModule/history-table.vue'
import CustomerInfo from './basicInfoModule/customerInfo'
import OutofDateInfo from './basicInfoModule/outofDateInfo'
import TradeHistory from './basicInfoModule/tradeHistory'
import PhoneHistory from '../components/phoneHistory/phoneHistory'
import vehicleInfo from './applyDetailInfo/vehicleInfo.vue'
import financing from './applyDetailInfo/financing.vue'
import personal from './applyDetailInfo/personal.vue'
import enterprise from './applyDetailInfo/enterprise.vue'
import fileUpload from './applyDetailInfo/fileUpload.vue'
import CreditInvestigation from './creditInvestigation/creditInvestigation'
import { getSummaryInfo, customerInfo, outofDateInfo } from '../../api/applyProgress.js'
import { telVerifyData } from '../../api/upload.js'
import { LEASETYPE, APPLYTYPE, CARTYPE } from '../../utils/constant'
import { mapGetters } from 'vuex'
export default {
  components: {
    // dealersTable,
    historyTable,
    CustomerInfo,
    OutofDateInfo,
    TradeHistory,
    PhoneHistory,
    vehicleInfo,
    financing,
    personal,
    enterprise,
    fileUpload,
    CreditInvestigation,
  },
  data () {
    return {
      leaseType: LEASETYPE,
      applyType: APPLYTYPE,
      carType: CARTYPE,
      itemId: null,
      identityType: null,
      activeName: '1',
      applyInfoActiveName: '1',
      clientHeight: 0,
      // 概要信息
      tableData: {
        applyNum: null,
        storeName: '',
        customerName: '',
        customerIdNo: '',
        phone: '',
        productName: '',
        term: null,
        applyType: null,
        amount: null,
        leaseType: null,
        gpsNum: null,
        carType: null,
        isInsurance: '',
        monthlyRent: '',
        isLoanFirst: '',
        downPaymentRatio: null,
        capital: '',
      },
      capitalDict: {
        '2345': '2345',
        'EX-XW': '新网银行',
        'EX-ZB': '众邦银行',
      },
      customerInfoData: {},
      outofDateInfoData: {},
      telVerifyData: [],
    }
  },
  computed: {
    ...mapGetters(['authority', 'provinceCityList']),
  },
  created () {
    const { itemId, identityType } = this.$route.params
    this.itemId = itemId ? +itemId : null
    this.identityType = identityType ? +identityType : null
    if (!this.provinceCityList.length) this.$store.dispatch('getAreaTree')
    if (this.itemId) this.getTableData()
    document.title = `${this.itemId}_申请进度详情`
  },
  mounted () {
    this.autoHeight()
    window.addEventListener('resize', this.autoHeight)
    this.getCustomerInfo()
    this.getOutofDateInfo()
    this.getTelVerifyData()
  },
  destroyed () {
    window.removeEventListener('resize', this.autoHeight)
  },
  methods: {
    // 概要信息
    getTableData () {
      getSummaryInfo({ applyId: this.itemId }).then((res) => {
        if (res.data.respCode === '1000') this.tableData = res.data.body
      }).catch((error) => { console.log(error) })
    },
    // 客户信息
    getCustomerInfo () {
      customerInfo(this.itemId).then((res) => {
        if (res.data.respCode === '1000') this.customerInfoData = res.data.body
      }).catch((err) => { console.log(err) })
    },
    // 逾期信息
    getOutofDateInfo () {
      outofDateInfo(this.itemId).then((res) => {
        if (res.data.respCode === '1000') this.outofDateInfoData = res.data.body
      }).catch((error) => { console.log(error) })
    },
    // 逾期信息刷新
    updateOutofDateData () {
      this.getOutofDateInfo()
    },
    // 电联记录
    getTelVerifyData () {
      telVerifyData(this.itemId).then((res) => {
        if (res.data.respCode === '1000') {
          let data = res.data.body
          data.forEach((item) => {
            item.phoneBelong = item.phone + '/' + item.belongPlace
          })
          this.telVerifyData = data
        }
      }).catch((err) => { console.log(err) })
    },
    autoHeight () {
      this.clientHeight = document.documentElement.clientHeight
      this.$refs['leftComponents'].style.height = (this.clientHeight - 55) + 'px'
    },
  },
}
</script>
<style lang="scss" scoped>
.leftWrap {
  margin: 0px 6px 0 5px;
  box-sizing: border-box;
  padding-right: 2px;
}
.left-components {
  overflow-y: auto;
}
.rightWrap {
  width: 100%;
  box-sizing: border-box;
  padding: 0 8px 0 0;
}
</style>
