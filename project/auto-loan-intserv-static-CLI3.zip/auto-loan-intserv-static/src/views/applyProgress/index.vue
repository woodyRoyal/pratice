<template>
  <div>
    <div ref="queryForm">
      <el-form size="mini" label-position="left" inline>
        <el-form-item label="申请编号">
          <el-input v-model="queryData.applyId" maxlength='8'></el-input>
        </el-form-item>
        <el-form-item label="申请编号(老)" label-width="100px">
              <el-input maxlength="7" v-model="queryData.oldApplyNo"></el-input>
            </el-form-item>
        <el-form-item label="客户名称">
          <el-input v-model="queryData.name" maxlength="20"></el-input>
        </el-form-item>
        <el-form-item label="提报人员">
          <el-input v-model="queryData.staffName"></el-input>
        </el-form-item>
        <el-form-item label="申请状态">
          <el-select v-model="queryData.applyStatus">
            <el-option v-for="item in applyStatusList" :key="item.dictValue" :label="item.dictName" :value="item.dictValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="当前节点">
          <el-select v-model="queryData.currentNode">
            <el-option v-for="item in currentNodeList" :key="item.code" :label="item.desc" :value="item.code"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="申请时间(起)">
          <el-date-picker type="datetime" v-model="queryData.applyStart" value-format="yyyy-MM-dd HH:mm:ss"></el-date-picker>
        </el-form-item>
        <el-form-item label="申请时间(止)">
          <el-date-picker type="datetime" v-model="queryData.applyEnd" value-format="yyyy-MM-dd HH:mm:ss"></el-date-picker>
        </el-form-item>
        <el-form-item label="产品方案">
          <el-input v-model="queryData.productName"></el-input>
        </el-form-item>
        <el-form-item label="申请人身份证号">
          <el-input v-model="queryData.certId"></el-input>
        </el-form-item>
        <el-form-item label="经销商名称">
          <el-input v-model="queryData.dealerName"></el-input>
        </el-form-item>
        <el-form-item label="合同状态">
          <el-select v-model="queryData.contractStatus">
            <el-option v-for="item in contractStatusOptions" :key="item.code" :label="item.desc" :value="item.code"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="自动审批结果">
          <el-select v-model="queryData.autoRiskResult">
            <el-option v-for="item in autoRiskResultOptions" :key="item.code" :label="item.desc" :value="item.code"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <div>
            <el-button size="mini" type="primary" @click="getApplyProgress">查询</el-button>
            <el-button size="mini" type="primary" @click="resetQuery">重置</el-button>
            <el-button size="mini" type="primary" @click="downloadHandle" :loading="applyProgressDownloadLoading">下载</el-button>
          </div>
        </el-form-item>
      </el-form>
    </div>
    <div class="dataTable">
      <el-table :data="dataTable" border style="width: 100%" class="spOnlineData" :max-height="maxHeight">
        <el-table-column label="序号" align="center" type="index" fixed="left"></el-table-column>
        <el-table-column label="申请编号" align="center" fixed="left">
          <template slot-scope="scope">
            {{scope.row.applyId || '/'}}
            <el-tag type="warning" size="mini" v-if="scope.row.specialPermit">特批</el-tag>
            <el-tag type="warning" size="mini" v-if="scope.row.reconsideration">复议</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="申请编号(老)" align="center" fixed="left">
          <template slot-scope="scope">
            <!--老系统显示 oldApplyNo，新系统显示 '/'-->
            {{scope.row.oldApplyNo || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="申请类型" align="center" fixed="left">
          <template slot-scope="scope">
            {{applyType[scope.row.applyType] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="客户名称" align="center" fixed="left">
          <template slot-scope="scope">
            {{scope.row.name || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="车辆类型" align="center" fixed="left">
          <template slot-scope="scope">
            {{carType[scope.row.carType] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="申请日期" align="center">
          <template slot-scope="scope">
            {{scope.row.applyTime || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="融资期限" align="center">
          <template slot-scope="scope">
            {{scope.row.loanPeriods || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="融资总额" align="center">
          <template slot-scope="scope">
            {{fMoney(scope.row.financingAmount / 100) || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="放款金额" align="center">
          <template slot-scope="scope">
            {{fMoney(scope.row.loanAmount / 100) || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="产品方案" align="center">
          <template slot-scope="scope">
            {{scope.row.productName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="合同状态" align="center">
          <template slot-scope="scope">
            {{scope.row.contractStatusDesc || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="申请状态" align="center">
          <template slot-scope="scope">
            {{scope.row.applyStatusDesc || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="当前节点" align="center">
          <template slot-scope="scope">
            {{scope.row.currentNodeDesc || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="提报人员" align="center">
          <template slot-scope="scope">
            {{scope.row.staffName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="自动审批结果" align="center">
          <template slot-scope="scope">
            {{scope.row.autoAuditResult || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="自动审批拒绝原因" align="center" min-width="130px">
          <template slot-scope="scope">
            {{scope.row.autoRiskRejectReason || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="经销商名称" align="center" min-width="130px">
          <template slot-scope="scope">
            {{scope.row.fullName || '/'}}
          </template>
        </el-table-column>
        <el-table-column prop="name" label="操作" align="center" min-width="70px" fixed="right">
          <template slot-scope="scope">
            <!--<el-popover v-if="scope.row.oldApplyFlag" placement="left">
              <p>老系统数据</p>
              <p>详情页面还在开发中</p>
              <el-button slot="reference" type="text" size="small">查看详情</el-button>
            </el-popover>-->
            <el-button @click="toDetail(scope.row)" type="text " size="small">查看详情</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页 -->
      <el-pagination
        class="listPagination"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="page.currentPage"
        :page-size="page.pageSize"
        :page-sizes="page.pageSizesArr"
        layout="total, sizes, prev, pager, next, jumper"
        :total="page.total">
      </el-pagination>
    </div>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import { LEASETYPE, APPLYTYPE, CARTYPE, fmoney } from '../../utils/constant.js'
  import { applyProgress, currentNodesList, applyProgressExport } from '../../api/applyProgress.js'
  import { dictionaryPost } from '../../api/commonApi.js'
  export default {
    data () {
      return {
        leaseType: LEASETYPE,
        applyType: APPLYTYPE,
        carType: CARTYPE,
        fMoney: fmoney,
        labelWidth: '70px',
        rowGutter: 10,
        colSpan: 6,
        page: {
          total: 0,
          currentPage: 1,
          pageSize: 10,
          pageSizesArr: [10, 20, 30, 40]
        },
        maxHeight: null,
        queryData: {
          oldApplyNo: '',
          applyId: '',
          name: '',
          staffName: '',
          applyStatus: null,
          currentNode: null,
          applyStart: '',
          applyEnd: '',
          productName: '',
          certId: '',
          dealerName: '',
          contractStatus: null,
          autoRiskResult: null
        },
        dataTable: [],
        applyStatusList: [],
        applyStatusDict: {},
        currentNodeList: [],
        currentNodeDict: {},
        autoRiskResultOptions: [
          {code: '0', desc: '初始化'},
          {code: '000', desc: '拒绝'},
          {code: '001', desc: '转人工'},
          {code: '002', desc: '通过'}
        ],
        contractStatusOptions: [
          {code: '0', desc: '初始状态'},
          {code: '1', desc: '合同生成已提交'},
          {code: '2', desc: '生效'},
          {code: '3', desc: '结清'},
          {code: '8', desc: '取消'},
          {code: '9', desc: '拒绝'}
        ]
      }
    },
    computed: {
      ...mapGetters(['applyProgressDownloadLoading'])
    },
    mounted () {
      this.getApplyStatus()
      this.getAllCurrentNodesList()
      this.getApplyProgress()
      // 调整高度
      this.autoMaxHeight()
      window.addEventListener('resize', this.autoMaxHeight)
    },
    destroyed () {
      window.removeEventListener('resize', this.autoMaxHeight)
    },
    methods: {
      checkApplyId (val) {
        if (val && (!/^\d{8}$/.test(val))) {
          this.$message.warning('输入有误')
          this.queryData.applyId = null
        }
      }, // applyId校验
      getApplyStatus () {
        dictionaryPost({category: ['apply_status']}).then(res => {
          if (res.data.respCode === '1000') this.applyStatusList = res.data.body.apply_status
        }).catch(error => { console.log(error) })
      }, // 申请状态
      getAllCurrentNodesList () {
        currentNodesList().then(res => {
          if (res.data.respCode === '1000') this.currentNodeList = res.data.body
        }).catch(error => { console.log(error) })
      }, // 当前所有节点
      getApplyProgress () {
        const {certId, applyId} = this.queryData
        if (certId !== '' && !/^[0-9A-Za-z]+$/.test(certId)) {
          this.queryData.certId = ''
          this.$message.warning('身份证号码输入有误')
          return false
        }
        if (applyId !== '' && (!/^\d{8}$/.test(applyId))) {
          this.queryData.applyId = ''
          this.$message.warning('输入有误')
          return false
        }
        return new Promise((resolve, reject) => {
          this.queryData.pageSize = this.page.pageSize
          this.queryData.pageNum = this.page.currentPage
          applyProgress(this.queryData).then(res => {
            const {respCode, body} = res.data
            if (respCode === '1000') {
              const {list, total} = body
              this.dataTable = list
              this.page.total = total
              resolve(total)
            }
          }).catch(error => {
            reject(error)
            console.error(error)
          })
        })
      }, // 列表数据
      toDetail (val) {
        window.open(`#/apply-progress-detail/${val.id}/${val.applyType}`)
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.getApplyProgress()
      },
      handleCurrentChange (val) {
        this.page.currentPage = val
        this.getApplyProgress()
      },
      resetQuery () {
        this.queryData = {
          oldApplyNo: '',
          applyId: '',
          name: '',
          staffName: '',
          applyStatus: null,
          currentNode: null,
          applyStart: '',
          applyEnd: '',
          productName: '',
          certId: '',
          dealerName: '',
          contractStatus: null,
          autoRiskResult: null
        }
        this.page.pageSize = 10
        this.page.currentPage = 1
        this.getApplyProgress()
      },
      autoMaxHeight () {
        this.$nextTick(() => {
          const h = document.documentElement.clientHeight
          const formHeight = this.$refs['queryForm'].offsetHeight
          this.maxHeight = h - (formHeight + 98)
        })
      }, // 表格高度
      // 下载
      applyProgressTableExport () {
        return new Promise((resolve, reject) => {
          applyProgressExport(this.queryData).then(res => {
            const {respCode, body} = res.data
            if (respCode === '1000') {
              const {serialNo} = body
              resolve(serialNo)
            }
          }).catch(err => {
            reject(err)
            console.error(err)
          })
        })
      },
      async downloadHandle () {
        try {
          const total = await this.getApplyProgress()
          if (total === 0) {
            this.$message.warning('该筛选条件下，无表格可下载')
            return false
          }
          const serialNo = await this.applyProgressTableExport()
          if (!serialNo) return false
          await this.$store.dispatch('downloadPollingApi', {
            serialNo,
            timer: 'applyProgressTimer',
            notification: 'applyProgressNotification',
            loading: 'applyProgressDownloadLoading'
          })
        } catch (e) {
          console.error(e)
        }
      }
    }
  }
</script>
<style lang="scss" scoped>
  .dataTable{
    padding: 0 8px;
    box-sizing: border-box;
  }
  .query-reset-apply-progress {
    margin-top:18px;
  }
  .listPagination{
    margin-top: 5px;
    float: right;
  }
</style>
