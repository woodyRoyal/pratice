<template>
  <div>
    <div class="tableTitle clearfix">
      <span class="table-title-word">客户信息</span>
    </div>
    <table class="self-table-comp">
      <tbody>
        <tr>
          <td>申请编号</td>
          <td>
            {{ customerInfoData.applyId || '/' }}
            <el-tag v-if="customerInfoData.specialPermit"
                    type="warning"
                    size="mini">
              特批
            </el-tag>
            <el-tag v-if="customerInfoData.reconsideration"
                    type="warning"
                    size="mini">
              复议
            </el-tag>
          </td>
          <td>客户姓名</td>
          <td>{{ customerInfoData.customName || '/' }}</td>
          <td>合同号码</td>
          <td>{{ customerInfoData.contractNo || '/' }}</td>
        </tr>
        <tr>
          <td>申请类型</td>
          <td>{{ customerInfoData.applyType || '/' }}</td>
          <td>产品方案名称</td>
          <td>{{ customerInfoData.productName || '/' }}</td>
          <td>租赁属性</td>
          <td>{{ customerInfoData.leaseType === 0 ? '回租' : '直租' || '/' }}</td>
        </tr>
        <tr>
          <td>合同生效日期</td>
          <td>{{ customerInfoData.controctSuccessDate || '/' }}</td>
          <td>合同放款日期</td>
          <td>{{ customerInfoData.contractLoanDate || '/' }}</td>
          <td>客户利率</td>
          <td>{{ customerInfoData.customRate || '/' }}</td>
        </tr>
        <tr>
          <td>期数</td>
          <td>{{ customerInfoData.term || '/' }}</td>
          <td>经销商名称</td>
          <td>{{ customerInfoData.dealerName || '/' }}</td>
          <td>放款主体</td>
          <td>{{ customerInfoData.loanSubject || '/' }}</td>
        </tr>
        <tr>
          <td>性别</td>
          <td>{{ customerInfoData.sex === 0 ? '男' : '女' || '/' }}</td>
          <td>证件类型</td>
          <td>{{ customerInfoData.cardType || '/' }}</td>
          <td>证件号码</td>
          <td>{{ customerInfoData.cardNum || '/' }}</td>
        </tr>
        <tr>
          <td>客户居住地省份</td>
          <td>{{ customerInfoData.province || '/' }}</td>
          <td>客户居住地城市</td>
          <td>{{ customerInfoData.city || '/' }}</td>
          <td>客户地址</td>
          <td>{{ customerInfoData.address || '/' }}</td>
        </tr>
        <tr>
          <td>婚姻状况</td>
          <td>{{ customerInfoData.married || '/' }}</td>
          <td>车牌号</td>
          <td>{{ customerInfoData.carLicencePlate || '/' }}</td>
          <td>车辆类型</td>
          <td>{{ customerInfoData.carType === 0 ? '新车' : '二手车' || '/' }}</td>
        </tr>
        <tr>
          <td>车型</td>
          <td>{{ customerInfoData.fldTrim || '/' }}</td>
          <td>发动机号</td>
          <td>{{ customerInfoData.carEngin || '/' }}</td>
          <td>车架号</td>
          <td>{{ customerInfoData.carVin || '/' }}</td>
        </tr>
        <tr>
          <td>颜色</td>
          <td>{{ customerInfoData.carColor || '/' }}</td>
          <td>每月租金</td>
          <td>{{ customerInfoData.monthRent || '/' }}</td>
          <td>每月扣款日期</td>
          <td>{{ customerInfoData.txnDate || '/' }}</td>
        </tr>
        <tr>
          <td>有线GPS设备号</td>
          <td>{{ customerInfoData.wiredDeviceNum || '/' }}</td>
          <td>无线GPS设备号</td>
          <td>{{ customerInfoData.wirelessDeviceNum || '/' }}</td>
          <td>GPS厂商</td>
          <td>
            {{ customerInfoData.gpsSupplier || '/' }}
            <el-button v-if="customerInfoData.gpsSupplier"
                       size="mini"
                       type="text"
                       @click="toGpsWeb(customerInfoData.gpsSupplier)">
              GPS定位查询
            </el-button>
          </td>
        </tr>
        <tr>
          <td>还款银行</td>
          <td>{{ customerInfoData.bank || '/' }}</td>
          <td>放款资方</td>
          <td>{{ customerInfoData.loanCapital || '/' }}</td>
          <td>当前资方</td>
          <td>{{ customerInfoData.currentCapital || '/' }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  props: {
    customerInfoData: {
      type: Object,
      default: function () {
        return {}
      },
    },
  },
  data () {
    return {}
  },
  methods: {
    toGpsWeb (val) {
      if (val === '中瑞') {
        window.open('http://lcrm.lunz.cn/')
      } else if (val === '赛格') {
        window.open('http://218.17.3.228:22803/')
      } else if (val === '天易') {
        window.open('http://www.tianyigps.cn/')
      } else if (val === '车晓') {
        window.open('http://fk.chexiao.co/')
      }
    },
  },
}
</script>

<style lang="scss" scoped>
</style>
