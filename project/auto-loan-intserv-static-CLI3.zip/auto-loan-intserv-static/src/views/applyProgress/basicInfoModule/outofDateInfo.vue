<!--申请进度查询表-申请进度详情-逾期信息模块-->
<template>
  <div>
    <div class="tableTitle clearfix">
      <span class="table-title-word">逾期信息</span>
      <div style="float: left">
        <el-button type="text"
                   @click="updateData">
          刷新
        </el-button>
        <el-button type="text"
                   @click="repayDetailFn">
          查看还款明细
        </el-button>
      </div>
    </div>
    <table class="self-table-comp">
      <tbody>
        <tr>
          <td>当前逾期天数</td>
          <td :class="outofDateData.overdueDays > 0 ? 'redSign' : ''">
            {{ outofDateData.overdueDays || '/' }}天
          </td>
          <td>当前应还金额</td>
          <td :class="+outofDateData.amount >= 0 ? 'redSign' : ''">
            {{ fmoney(outofDateData.amount / 100) || '/' }}
          </td>
          <td>当前逾期区间</td>
          <td>{{ outofDateData.overdueSection || '/' }}</td>
        </tr>
        <tr>
          <td>当前逾期期数</td>
          <td>{{ outofDateData.overdueTerm || '/' }}期</td>
          <td>融资期限</td>
          <td>{{ outofDateData.term || '/' }}期</td>
          <td>已还期数</td>
          <td>{{ outofDateData.repayTerm || '/' }}期</td>
        </tr>
        <tr>
          <td>逾期状态</td>
          <td :class="+outofDateData.overdueSta === 3 ? 'redSign' : ''">
            {{ overdueStaDict[outofDateData.overdueSta] || '/' }}
          </td>
          <td>实际剩余本金</td>
          <td>{{ fmoney(outofDateData.factRestMoney / 100) || '/' }}</td>
          <td>当前剩余本金</td>
          <td>{{ fmoney(outofDateData.termRestMoney / 100) || '/' }}</td>
        </tr>
        <tr>
          <td>五级分类</td>
          <td colspan="5">
            {{ outofDateData.fiveCategories || '/' }}
          </td>
        </tr>
      </tbody>
    </table>
    <el-dialog title="还款明细"
               :visible.sync="dialogVisible"
               width="100%">
      <!--新网：EX-XW， 众邦：EX-ZB ，2345自有：2345-->
      <!--billLoanType 借据类型 0-普通借据 1-联合贷借据-->
      <template v-if="billLoanType">
        <el-radio-group v-model="activeName"
                        size="mini"
                        style="margin-bottom: 10px;"
                        @change="activeChange">
          <el-radio-button label="all">
            整体
          </el-radio-button>
          <el-radio-button label="EX-ZB">
            众邦
          </el-radio-button>
          <el-radio-button label="2345">
            2345
          </el-radio-button>
        </el-radio-group>
        <i style="float: right;">当前资方：<el-tag type="danger"
                                              size="mini">{{ currentCapital }}</el-tag></i>
      </template>

      <el-table v-loading="isLoading"
                :data="repaymentList"
                max-height="600"
                border>
        <el-table-column label="期数"
                         min-width="40">
          <template slot-scope="scope">
            {{ scope.row.periodNo }}
          </template>
        </el-table-column>
        <el-table-column label="应还日期">
          <template slot-scope="scope">
            {{ scope.row.repayDate }}
          </template>
        </el-table-column>
        <el-table-column label="月租">
          <template slot-scope="scope">
            {{ fmoney(scope.row.monthlyRentAmount / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="本金">
          <template slot-scope="scope">
            {{ fmoney(scope.row.principal / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="利息">
          <template slot-scope="scope">
            {{ fmoney(scope.row.interest / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="费用">
          <template slot-scope="scope">
            {{ fmoney(scope.row.fee / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="剩余本金">
          <template slot-scope="scope">
            {{ fmoney(scope.row.leftPrincipalAfterThisPlan / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="当前应还总金额">
          <template slot-scope="scope">
            {{ fmoney(scope.row.currentPeriodNeedRepayAmount / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="当前应还本金">
          <template slot-scope="scope">
            {{ fmoney(scope.row.remainPrincipal / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="当前应还利息">
          <template slot-scope="scope">
            {{ fmoney(scope.row.remainInterest / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="当前应还费用">
          <template slot-scope="scope">
            {{ fmoney(scope.row.remainFee / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="当前应还逾期滞纳金">
          <template slot-scope="scope">
            {{ fmoney(scope.row.remainOverduePenalty / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="已还总金额">
          <template slot-scope="scope">
            {{ fmoney(scope.row.currentPeriodRepayAmount / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="已还本金"
                         width="50">
          <template slot-scope="scope">
            {{ fmoney(scope.row.repayPrincipal / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="已还利息"
                         width="50">
          <template slot-scope="scope">
            {{ fmoney(scope.row.repayInterest / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="已还费用"
                         width="50">
          <template slot-scope="scope">
            {{ fmoney(scope.row.repayFee / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="已还逾期滞纳金"
                         width="85">
          <template slot-scope="scope">
            {{ fmoney(scope.row.repayOverduePenalty / 100) }}
          </template>
        </el-table-column>
        <el-table-column label="当前资方"
                         width="80"
                         show-overflow-tooltip="true">
          <template slot-scope="scope">
            {{ scope.row.repPlanCapitalName }}
          </template>
        </el-table-column>
        <el-table-column label="还款状态"
                         width="50">
          <template slot-scope="scope">
            <div :class="+scope.row.overdueDays > 0 ? 'redSign' : ''">
              {{ dict.repayPlansStatus[scope.row.status] }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="逾期天数"
                         width="50">
          <template slot-scope="scope">
            <div :class="+scope.row.overdueDays > 0 ? 'redSign' : ''">
              {{ scope.row.overdueDays }}
            </div>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
import { queryRepaymentDetailInfo } from '../../../api/applyProgress'
import { dict } from '../../../api/financialManage'
import { fmoney } from '../../../utils/constant'
export default {
  name: 'OutofDateInfo',
  props: {
    outofDateData: {
      type: Object,
      default: function () {
        return {}
      },
    },
  },
  data () {
    return {
      fmoney,
      dict,
      tableData: {},
      dialogVisible: false,
      activeName: 'all', // 默认整体
      repaymentList: [],
      isLoading: false,
      billLoanType: null, // 借据类型 0-普通借据 1-联合贷借据
      currentCapital: '', // 当前资方
      applyId: null,
      overdueStaDict: {
        0: '作废',
        1: '正常',
        2: '结清',
        3: '逾期',
      },
    }
  },
  mounted () {
    this.applyId = this.$route.params.itemId ? +this.$route.params.itemId : null
  },
  methods: {
    repayDetailFn () {
      this.dialogVisible = true
      this.activeName = 'all'
      this.getRepaymentPlans()
    },
    // 当前明细更换
    activeChange (val) {
      this.getRepaymentPlans(val)
    },
    // 查询还款计划
    getRepaymentPlans () {
      let capitalList = Array.from(arguments)
      let length = Array.from(arguments).length
      // 新网：EX-XW， 众邦：EX-ZB ，2345自有：2345
      let query = {}
      if (!length || capitalList[0] === 'all') { // 查询整体
        query = {
          applyId: this.applyId,
        }
      } else {
        query = {
          applyId: this.applyId,
          capitalList,
        }
      }
      this.isLoading = true
      queryRepaymentDetailInfo(query).then((res) => {
        if (res.data.respCode === '1000') {
          let data = res.data.body
          data.repaymentPlanVOList.forEach((item) => {
            if (item.repayDate) item.repayDate = item.repayDate.substring(0, 10)
          })
          this.repaymentList = data.repaymentPlanVOList
          this.billLoanType = data.billLoanType
          this.currentCapital = data.currentCapital
          this.isLoading = false
        }
      }).catch((err) => {
        this.isLoading = false
        console.log(err)
      })
    },
    updateData () {
      this.$emit('updateData')
    },
  },
}
</script>

<style scoped lang="scss">
.redSign {
  color: red;
}
.table-title-word {
  height: 40px;
  line-height: 40px;
  margin-right: 5px;
}
</style>
