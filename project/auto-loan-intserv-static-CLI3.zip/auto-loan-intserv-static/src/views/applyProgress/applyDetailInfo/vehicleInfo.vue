<template>
  <div class="applyTbCarWrap">
    <div>
      <div class="formModuleTitle"><span>车辆信息</span></div>
      <el-form size="small" label-position="top" :model="carVo" ref="carVo1">
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="制造商" class="is-required">
              <el-input disabled v-model="carVo.fldMake"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-button type="primary" size="mini" class="queryCar" disabled>查找车辆</el-button>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="品牌" class="is-required">
              <el-input disabled v-model="carVo.fldModel"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="车系" class="is-required">
              <el-input disabled v-model="carVo.fldSerial"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="新车指导价" class="is-required">
              <el-input disabled v-model="carVo.fldPriceStr"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="车辆销售价" class="is-required">
              <el-input v-model="carVo.salePriceStr" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="购车目的" class="is-required">
              <el-select v-model="carVo.purpose" placeholder="请选择渠购车目的" disabled>
                <el-option v-for="item in purposeList" :key="item.id" :label="item.dictName"  :value="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="车辆颜色" class="is-required">
              <el-input v-model="carVo.carColor" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="上牌或抵押省份-城市" class="is-required">
              <el-cascader :options="provinceCityList" v-model="carVo.provinceCity" :props="props" disabled></el-cascader>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <!--车辆参数-->
    <div v-if="vehicleType === 1">
      <div class="formModuleTitle"><span>车辆参数</span></div>
      <el-form size="small" label-position="top" :model="carParamVo" ref="carParamVo">
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="订单编号" class="is-required">
              <el-input  v-model="carParamVo.orderId" maxlength="8" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-button type="primary" size="mini" class="queryOrder" disabled>获取订单信息</el-button>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="品牌车型" class="is-required">
              <el-input disabled v-model="carParamVo.modelBrand"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="车架号（VIN码）" class="is-required">
              <el-input disabled v-model="carParamVo.vin"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="二手车出厂日期" class="is-required">
              <el-date-picker placeholder="选择日期" type="datetime" v-model="carParamVo.factoryDate" value-format="yyyy-MM-dd HH:mm:ss" disabled></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="二手车初登日期" class="is-required">
              <el-date-picker placeholder="选择日期" type="datetime" v-model="carParamVo.initialDate" value-format="yyyy-MM-dd HH:mm:ss" disabled></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="二手车评估金额" class="is-required">
              <el-input disabled v-model="carParamVo.assessmentAmount"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="二手车公里数（万公里）" class="is-required">
              <el-input disabled v-model="carParamVo.kilometerNumber"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan"></el-col>
        </el-row>
      </el-form>
    </div>
    <!--交易信息-->
    <div v-if="vehicleType === 1">
      <div class="formModuleTitle"><span>交易信息</span></div>
      <el-form size="small" label-position="top" :model="carVo" ref="carVo2">
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="类型" class="is-required">
              <el-select v-model="carVo.tradeType" disabled>
                <el-option label="个人" :value="0"></el-option>
                <el-option label="企业" :value="1"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="卖方名称" class="is-required">
              <el-input v-model="carVo.salesName" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="卖方连系方式" class="is-required">
              <el-input v-model="carVo.slaesPhone" maxlength="11" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="上任车主姓名" class="is-required">
              <el-input v-model="carVo.carOwnerName" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="身份证号码" class="is-required">
              <el-input v-model="carVo.carOwnerId" maxlength="18" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan"></el-col>
        </el-row>
        <!--企业-->
        <el-row :gutter="rowGutter" v-if="carVo.tradeType === 1">
          <el-col :span="colSpan">
            <el-form-item label="证件类型" class="is-required">
              <el-select v-model="carVo.cardType" placeholder="请选择证件类型" disabled>
                <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in tradeCardTypeList" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="证件号码" class="is-required">
              <el-input v-model="carVo.cardNum" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan"></el-col>
        </el-row>
      </el-form>
    </div>
    <!--渠道信息-->
    <div>
      <div class="formModuleTitle"><span>渠道信息</span></div>
      <el-form size="small" label-position="top" :model="carVo" ref="carVo3">
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="是否外采" class="is-required">
              <el-select v-model="carVo.externalChannel" disabled>
                <el-option label="是" :value="0"></el-option>
                <el-option label="否" :value="1"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="渠道供应商" class="is-required">
              <el-select v-model="carVo.channelId" placeholder="请选择渠道供应商" filterable disabled>
                <el-option v-for="item in suppliers" :key="item.channelId"  :label="item.channelName" :value="item.channelId" :disabled="item.disabled == 2"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <!--挂靠信息-->
    <div v-if="+applyType !== 1">
      <div class="formModuleTitle"><span>挂靠信息</span></div>
      <el-form size="small" label-position="top" :model="attachedVo" ref="attachedVo">
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="是否挂靠" class="is-required">
              <el-select v-model="attachedVo.attached" disabled>
                <el-option label="是" :value="1"></el-option>
                <el-option label="否" :value="0"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <!--申请备注-->
    <div>
      <div class="formModuleTitle"><span>备注信息</span></div>
      <el-form label-position="top" size="small" :model="carVo" ref="carVo4">
        <el-row :gutter="rowGutter">
          <el-col :span="24">
            <el-form-item label="申请备注" class="is-required">
              <el-input v-model="carVo.remakr" auto-complete="off" type="textarea" :autosize="{minRows: 5}" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>
<script>
  import {getVehicleInfo, getSupplierList} from '../../../api/applyProgress.js'
  import {mapGetters} from 'vuex'
  import {fmoney, rmoney} from '../../../utils/constant.js'
  export default {
    props: ['outerActiveTableName', 'innerActiveTableName'],
    data () {
      return {
        fmoney,
        rmoney,
        rowGutter: 20,
        colSpan: 8,
        queryCarShow: false,
        carSeries_copy: null,
        itemId: null,
        applyType: null,
        carVo: {
          fldMake: null,
          fldModel: null,
          fldSerial: null,
          fldPriceStr: null,
          salePriceStr: '',
          purpose: null,
          externalChannel: null,
          channelId: null,
          provinceCity: null
        },
        carParamVo: {
          factoryDate: null
        },
        attachedVo: {
          attached: 0
        },
        channelDealerVo: {},
        preAuditId: null,
        vehicleType: null,
        suppliers: [], // 渠道供应商
        props: {
          value: 'key',
          label: 'name',
          children: 'list'
        }
      }
    },
    computed: {
      ...mapGetters(['purposeList', 'tradeCardTypeList', 'provinceCityList'])
    },
    mounted () {
      this.itemId = this.$route.params.itemId ? this.$route.params.itemId : null
      if (this.itemId) this.getCarInfo(this.itemId)
    },
    methods: {
      // 车辆信息
      getCarInfo (val) {
        getVehicleInfo({applyId: val}).then(res => {
          if (res.data.respCode === '1000') {
            // let data = res.data.body
            const {applyType, carVO, carParamVO, channelDealerVO, preAuditId, vehicleType, attached} = res.data.body
            this.applyType = applyType
            carVO.provinceCity = carVO.province && carVO.city ? [carVO.province, carVO.city] : []
            this.carVo = carVO
            this.carParamVo = carParamVO
            this.channelDealerVo = channelDealerVO
            this.preAuditId = preAuditId
            this.vehicleType = vehicleType
            this.attachedVo.attached = attached || 0 // 是否为挂靠
            if (this.carVo.channelId !== null && this.carVo.channelId !== '') this.getSuppliers()
          }
        }).catch(error => { console.log(error) })
      },
      // 获取渠道商
      getSuppliers () {
        getSupplierList({
          purchaseType: this.carVo.externalChannel,
          channelId: this.carVo.channelId
        }).then(res => {
          if (res.data.respCode === '1000') this.suppliers = res.data.body
        }).catch(error => { console.log(error) })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .queryCar, .queryOrder{
    margin-top: 26px;
  }
  .saveBtn{
    position: absolute;
    right: 15px;
    top: 5px;
  }
</style>
