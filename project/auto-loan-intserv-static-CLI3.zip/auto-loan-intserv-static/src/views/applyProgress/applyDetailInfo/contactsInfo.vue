<template>
  <div class="contactsInfo">
    <div class="tableTitle clearfix"><span class="table-title-word">联系人信息</span></div>
    <el-table :data="contactList" style="width: 100%">
      <el-table-column label="序号" type="index" align="center"></el-table-column>
      <el-table-column label="联系人姓名" prop="name" align="center">
        <template slot-scope="scope">
          <span>{{scope.row.name || ''}}</span>
        </template>
      </el-table-column>
      <el-table-column label="与申请人关系" align="center">
        <template slot-scope="scope">
          <span>{{suretyRelationDict[scope.row.relation]}}</span>
        </template>
      </el-table-column>
      <el-table-column label="手机号码" prop="phone" align="center">
        <template slot-scope="scope">
          <span>{{scope.row.phone || ''}}</span>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
import { getContactListInfo } from '../../../api/applyProgress.js'
import {mapGetters} from 'vuex'
export default {
  props: ['type'],
  data () {
    return {
      contactList: []
    }
  },
  computed: {
    ...mapGetters(['suretyRelationDict'])
  },
  mounted () {
    this.itemId = this.$route.params.itemId ? this.$route.params.itemId : null
    this.getInfo({
      applyId: this.itemId,
      type: this.type
    })
  },
  methods: {
    getInfo (val) {
      getContactListInfo(val).then(res => {
        if (res.data.respCode === '1000') this.contactList = res.data.body
      }).catch(error => { console.log(error) })
    }
  }
}
</script>
<style lang="scss" scoped>
.contactsInfo {
  position: relative;
}
.addContacts {
  position: absolute;
  right: 0;
  top: -5px;
}
.contactsInfo {
  margin-top: 20px;
}
</style>

