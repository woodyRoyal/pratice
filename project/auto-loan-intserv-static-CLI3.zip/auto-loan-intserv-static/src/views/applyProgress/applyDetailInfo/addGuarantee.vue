<template>
  <div class="addGuaranteeDialog">
    <el-dialog
      :title="guaranteeItemId ? '查看担保人' : '新增担保人'"
      :visible="dialogFormVisible"
      :show-close='false'
      :lock-scroll="true"
      width="80%"
      top="3vh">
      <el-button type="primary" size="mini" @click="closeDialogForm" class="closeBtn">关闭</el-button>
      <!-- 基本信息 -->
      <el-form :model="proposerSuretyInfoVO" label-position="top" :size="formSize" ref="proposerSuretyInfoVO">
        <div class="formModuleTitle"><span>与申请人关系</span></div>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlSpacing">
            <el-form-item label="与申请人关系" class="is-required">
              <el-select v-model="proposerSuretyInfoVO.relation" placeholder="请选择" disabled>
                <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in suretyRelationList" :key="item.dictValue" :disabled="item.disabled"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-form :model="proposerVO" label-position='top' :size="formSize" ref="proposerVO">
        <div>
          <div class="formModuleTitle"><span>基本信息</span></div>
          <el-row :gutter="controlSpacing">
            <el-col :span="controlPieces">
              <el-form-item label="姓名" class="is-required">
                <el-input v-model="proposerVO.nameStr" auto-complete="off" disabled maxlength="20" placeholder="请输入"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="controlPieces">
              <el-form-item label="证件类型" class="is-required">
                <el-select v-model="proposerVO.cardType" placeholder="请选择" disabled>
                  <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in cardTypeList" :key="item.dictValue"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="controlPieces">
              <el-form-item label="证件号码" class="is-required">
                <el-input v-model="proposerVO.cardIdStr" auto-complete="off" disabled maxlength="18" placeholder="请输入"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="controlSpacing">
            <el-col :span="controlPieces">
              <el-form-item label="性别" class="is-required">
                <el-select v-model="proposerVO.sex" disabled>
                  <el-option label="男" :value="0"></el-option>
                  <el-option label="女" :value="1"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="controlPieces">
              <el-form-item label="出生日期" class="is-required">
                <el-date-picker type="date" placeholder="选择日期" v-model="proposerVO.birth" value-format="yyyy-MM-dd" disabled></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="controlPieces">
              <el-form-item label="年龄" class="is-required">
                <el-input v-model="proposerVO.age" auto-complete="off" placeholder="请输入" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="controlSpacing">
            <el-col :span="controlPieces">
              <el-form-item label="签发机关" class="is-required">
                <el-input v-model="proposerVO.licenceIssuing" auto-complete="off" placeholder="请输入" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="controlPieces">
              <el-form-item label="证件有效期（起）" class="is-required">
                <el-date-picker v-model="proposerVO.expiryDateStart" type="date" placeholder="选择日期" value-format="yyyy-MM-dd" disabled></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="controlPieces">
              <el-form-item label="证件有效期（止）" class="is-required">
                <div class="expiryDateEndWrap">
                  <el-radio v-model="isExpiryDateEndLong" label="长期" disabled>长期</el-radio>
                  <el-radio v-model="isExpiryDateEndLong" label="非长期" disabled>非长期</el-radio>
                  <el-date-picker v-model="proposerVO.expiryDateEnd" type="date" placeholder="选择日期" value-format="yyyy-MM-dd" disabled></el-date-picker>
                </div>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="controlSpacing">
            <el-col :span="controlPieces">
              <el-form-item label="婚姻状况" class="is-required">
                <el-select v-model="proposerVO.married" placeholder="请选择" disabled>
                  <el-option :label="item.dictName" :value="item.dictValue" v-for="item in marriedList" :key="item.dictValue"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="controlPieces">
              <el-form-item label="手机号码" class="is-required">
                <el-input v-model="proposerVO.phoneStr" auto-complete="off" maxlength="11" disabled placeholder="请输入"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="controlPieces">
              <el-form-item label="民族" class="is-required">
                <el-input v-model="proposerVO.race" auto-complete="off" placeholder="请输入" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="controlSpacing" v-if="proposerVO.education !== null && proposerVO.academicDegree !== null">
            <el-col :span="controlPieces">
              <el-form-item label="承租人最高学历" class="is-required">
                <el-select v-model="proposerVO.education" placeholder="请选择" disabled>
                  <el-option :label="item.dictName" :value="item.dictValue" v-for="(item, index) in educationList" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="controlPieces">
              <el-form-item label="承租人最高学位" class="is-required">
                <el-select v-model="proposerVO.academicDegree" placeholder="请选择" disabled>
                  <el-option :label="item.desc" :value="item.code" v-for="(item, index) in academicDegreeDict" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
      </el-form>
      <!-- 职业信息 -->
      <el-form :model="occupationalInfoVO" label-position='top' ref="occupationalInfoVO" :size="formSize">
        <div>
          <div class="formModuleTitle"><span>职业信息</span></div>
          <el-row :gutter="controlSpacing">
            <el-col :span="occupationalInfoVO.industry !== null ? 8 : 12">
              <el-form-item label="单位名称" class="is-required">
                <el-input v-model="occupationalInfoVO.companyName" auto-complete="off" placeholder="请输入" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="occupationalInfoVO.industry !== null ? 8 : 12">
              <el-form-item label="单位电话" class="is-required">
                <el-input v-model="occupationalInfoVO.telStr" auto-complete="off" placeholder="请输入" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="controlPieces" v-if="occupationalInfoVO.industry !== null">
              <el-form-item label="企业从事行业" class="is-required">
                <el-select v-model="occupationalInfoVO.industry" placeholder="请选择" disabled>
                  <el-option v-for="item in industryList" :key="item.dictValue" :label="item.dictName"  :value="item.dictValue"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="controlSpacing">
            <el-col :span="controlPieces">
              <el-form-item label="单位所在地省份-城市" class="is-required">
                <el-cascader :options="provinceCityList" v-model="occupationalInfoVO.provinceCity" :props="props" disabled></el-cascader>
              </el-form-item>
            </el-col>
            <el-col :span="16">
              <el-form-item label="单位详细地址" class="is-required">
                <el-input v-model="occupationalInfoVO.address" auto-complete="off" placeholder="请输入" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
      </el-form>
      <!-- 居住信息 -->
      <el-form :model="resideVO" label-position='top' ref="resideVO" :size="formSize">
        <div>
          <div class="formModuleTitle"><span>居住信息</span></div>
          <el-row :gutter="controlSpacing">
            <el-col :span="controlPieces">
              <el-form-item label="现居所在地省份-城市" class="is-required">
                <el-cascader :options="provinceCityList" v-model="resideVO.provinceCity" :props="props" disabled></el-cascader>
              </el-form-item>
            </el-col>
            <el-col :span="16">
              <el-form-item label="居住详细地址" class="is-required">
                <el-input v-model="resideVO.address" auto-complete="off" placeholder="请输入" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="controlSpacing">
            <el-col :span="controlPieces">
              <el-form-item label="户籍所在地省份-城市" class="is-required">
                <el-cascader :options="provinceCityList" v-model="resideVO.familyProvinceCity" :props="props" disabled></el-cascader>
              </el-form-item>
            </el-col>
            <el-col :span="16">
              <el-form-item label="户籍详细地址" class="is-required">
                <el-input v-model="resideVO.familyAddress" auto-complete="off" placeholder="请输入" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
      </el-form>
      <!-- 直系亲属 -->
      <el-form :model="relativesVO" label-position='top' ref="relativesVO" :size="formSize" v-if="proposerVO.married === 1 || proposerVO.married === 5" key="relativesModule">
        <div class="formModuleTitle"><span>配偶或亲属</span></div>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="姓名" class="is-required">
              <el-input v-model="relativesVO.nameStr" auto-complete="off" maxlength="20" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="与担保人关系" class="is-required">
              <el-select v-model="relativesVO.relation" placeholder="请选择" disabled>
                <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in relativesRelationList" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="身份证号码" class="is-required">
              <el-input v-model="relativesVO.cardIdStr" auto-complete="off" maxlength="18" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="controlSpacing">
          <el-col :span="controlPieces">
            <el-form-item label="手机号码" class="is-required">
              <el-input v-model="relativesVO.phoneStr" auto-complete="off" maxlength="11" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="自查征信" class="is-required">
              <el-select v-model="relativesVO.selfCredit" placeholder="请选择" disabled>
                <el-option label="是" :value="0"></el-option>
                <el-option label="否" :value="1"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="controlPieces">
            <el-form-item label="单位名称">
              <el-input v-model="relativesVO.compaynName" auto-complete="off" placeholder="请输入" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <!-- 征信 -->
      <el-form :model="creditVO" label-position='top' ref="creditVO" :size="formSize">
        <div>
          <div class="formModuleTitle"><span>征信信息</span></div>
          <el-row :gutter="controlSpacing">
            <el-col :span="controlPieces">
              <el-form-item label="征信渠道" class="is-required">
                <el-select v-model="creditVO.creditChannel" placeholder="请选择" disabled>
                  <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in creditChannelList" :key="item.dictValue"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
  import {getGuranteeInfo, academicDegreeDict} from '../../../api/applyProgress.js'
  import {mapGetters} from 'vuex'
  // import {formatName, formatPhone, formatPapers} from '../../../filters'
  export default {
    props: ['guaranteeItemId'],
    data () {
      return {
        formSize: 'small',
        itemId: null,
        academicDegreeDict,
        dialogFormVisible: true,
        props: {
          value: 'key',
          label: 'name',
          children: 'list'
        },
        proposerSuretyInfoVO: {
          id: null,
          relation: null
        },
        // 基本信息
        proposerVO: {
          type: 2, // 申请人和担保人用的一张表，为了区分
          name: '',
          cardType: null,
          cardId: null,
          sex: null,
          birth: null,
          age: null,
          licenceIssuing: null,
          expiryDateStart: null,
          expiryDateEnd: null,
          married: null,
          phone: null,
          race: null,
          education: null,
          academicDegree: null
        },
        // 职业信息
        occupationalInfoVO: {
          companyName: '',
          provinceCity: null,
          address: '',
          tel: null,
          industry: null
        },
        // 居住信息
        resideVO: {
          provinceCity: null,
          address: '',
          familyProvinceCity: null,
          familyAddress: ''
        },
        // 亲属信息
        relativesVO: {
          name: '',
          relation: null,
          cardId: null,
          phone: null,
          selfCredit: null,
          compaynName: ''
        },
        creditVO: {
          creditChannel: null,
          id: null,
          type: 2 // 申请人和担保人用的一张表，为了区分
        },
        controlSpacing: 20,
        controlPieces: 8,
        isExpiryDateEndLong: '非长期'
      }
    },
    created () {
      this.getProvinceCityList()
      this.itemId = this.$route.params.itemId ? this.$route.params.itemId : null
      if (this.guaranteeItemId) this.getInfo(this.guaranteeItemId)
    },
    computed: {
      ...mapGetters([
        'cardTypeList',
        'marriedList',
        'educationList',
        'proposerTitleList',
        'industryList',
        'natureList',
        'resideNatureList',
        'relativesRelationList',
        'suretyRelationList',
        'bankNameList',
        'provinceCityList',
        'creditChannelList'
      ])
    },
    methods: {
      // 获取所有省市
      getProvinceCityList () {
        if (!this.provinceCityList.length) this.$store.dispatch('getAreaTree')
      },
      // 数据拉取
      getInfo (val) {
        getGuranteeInfo(val).then(res => {
          if (res.data.respCode === '1000') {
            const {proposerSuretyInfoVO, proposerVO, occupationalInfoVO, relativesVO, resideVO, creditVO} = res.data.body
            this.proposerSuretyInfoVO = proposerSuretyInfoVO // 与申请人关系
            if (proposerVO.expiryDateEnd === '长期') {
              proposerVO.expiryDateEnd = ''
              this.isExpiryDateEndLong = '长期'
            } else {
              this.isExpiryDateEndLong = '非长期'
            }
            proposerVO.nameStr = proposerVO.name
            proposerVO.cardIdStr = proposerVO.cardId
            proposerVO.phoneStr = proposerVO.phone
            this.proposerVO = proposerVO // 基本信息
            occupationalInfoVO.provinceCity = occupationalInfoVO.province && occupationalInfoVO.city ? [occupationalInfoVO.province, occupationalInfoVO.city] : null
            occupationalInfoVO.telStr = occupationalInfoVO.tel
            this.occupationalInfoVO = occupationalInfoVO // 职业信息
            relativesVO.nameStr = relativesVO.name
            relativesVO.cardIdStr = relativesVO.cardId
            relativesVO.phoneStr = relativesVO.phone
            this.relativesVO = relativesVO // 亲属信息
            resideVO.provinceCity = resideVO.province && resideVO.city ? [resideVO.province, resideVO.city] : null
            resideVO.familyProvinceCity = resideVO.familyProvince && resideVO.familyCity ? [resideVO.familyProvince, resideVO.familyCity] : null
            this.resideVO = resideVO // 居住信息
            this.creditVO = creditVO // 征信
          }
        }).catch(error => { console.log(error) })
      },
      // 关闭表单弹窗
      closeDialogForm () {
        this.$emit('closeDialogForm')
      }
    }
  }
</script>
<style lang="scss" scoped>
.closeBtn{
  position: absolute;
  right: 20px;
  top: 20px;
}
</style>
