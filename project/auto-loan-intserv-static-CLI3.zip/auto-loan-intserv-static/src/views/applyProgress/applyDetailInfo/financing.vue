<template>
  <div class="applyTbFinancialWrap">
    <el-form :model="financialData" ref="financialData" size="small" label-position="top">
      <div>
        <div class="formModuleTitle"><span>融资费用明细</span></div>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan" v-if="financingParams.car_price && financingParams.car_price.financing">
            <el-form-item label="车款" class="is-required">
              <el-input v-model="financialData.carPrice" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan" v-if="financingParams.purchase_tax && financingParams.purchase_tax.financing">
            <el-form-item label="购置税" class="is-required">
              <el-input v-model="financialData.purchaseTax" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan" v-if="financingParams.insurance && financingParams.insurance.financing">
            <el-form-item label="保险" class="is-required">
              <el-input v-model="financialData.insurance" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan" v-if="financingParams.gps && financingParams.gps.financing">
            <el-form-item label="GPS价格" class="is-required">
              <el-input v-model="financialData.gps" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan" v-if="financingParams.financing_fee && financingParams.financing_fee.financing">
            <el-form-item label="车融服务费" class="is-required">
              <el-input v-model="financialData.financingFee" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan" v-if="financingParams.theft_protection && financingParams.theft_protection.financing">
            <el-form-item label="盗抢服务" class="is-required">
              <el-input v-model="financialData.theftProtection" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </div>
      <div>
        <div class="formModuleTitle"><span>融资信息</span></div>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="GPS个数" class="is-required">
              <el-input v-model="financialData.gpsQuantity" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="还款频率" class="is-required">
              <el-select v-model="financialData.repaymentFrequency" placeholder="请选择还款频率" disabled>
                <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in repaymentFrequency" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="还款方式" class="is-required">
              <el-select v-model="financialData.repaymentMethod" placeholder="请选择还款方式" disabled>
                <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in repaymentMethods" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="利率类型" class="is-required">
              <el-select v-model="financialData.interestMethod" placeholder="请选择利率类型" disabled>
                <el-option :label="item.name"  :value="item.value" v-for="item in interest_rate_type" :key="item.value"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="融资期限" class="is-required">
              <el-select v-model="financialData.term" placeholder="请选择融资期限" disabled>
                <el-option :label="item.name"  :value="item.value" v-for="item in term" :key="item.value"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="操作类型" class="is-required">
              <el-select v-model="financialData.operationType" placeholder="请选择操作类型" disabled>
                <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in operateTypes" :key="item.dictValue"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <!-- 禁用就不校验 -->
            <el-form-item label="首付比例" v-if="financialData.operationType === 2" class="is-required">
              <el-input v-model="financialData.downPaymentRatio" auto-complete="off" :disabled="financialData.operationType === 2"></el-input>
            </el-form-item>
            <el-form-item label="首付比例" prop="downPaymentRatio" v-else>
              <el-input v-model="financialData.downPaymentRatio" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <!-- 禁用就不校验 -->
            <el-form-item label="首付金额" v-if="financialData.operationType === 1" class="is-required">
              <el-input v-model="financialData.downPaymentAmt" auto-complete="off" :disabled="financialData.operationType === 1"></el-input>
            </el-form-item>
            <el-form-item label="首付金额" prop="downPaymentAmt" v-else>
              <el-input v-model="financialData.downPaymentAmt" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="手续费率（%）" class="is-required">
              <el-input v-model="financialData.feeRatio" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="手续费" class="is-required">
              <el-input v-model="financialData.feeAmount" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="手续费扣款方式" class="is-required">
              <el-select v-model="financialData.feePaymentMethod" placeholder="请选择" disabled>
                <el-option :label="item.name"  :value="item.value" v-for="item in fee_payment_method" :key="item.value"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="保证金比例（%）" class="is-required">
              <el-input v-model="financialData.depositRatio" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="保证金金额" class="is-required">
              <el-input v-model="financialData.depositAmount" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="保证金是否冲抵" class="is-required">
              <el-select v-model="financialData.depositChargeAgainst" placeholder="请选择" disabled>
                <el-option :label="item.name"  :value="item.value" v-for="item in deposit_charge_against" :key="item.value"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="融资总额" class="is-required">
              <el-input v-model="financialData.amount" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="放款金额" class="is-required">
              <el-input v-model="financialData.makeloansAmount" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="月供租金" class="is-required">
              <el-input v-model="financialData.repaymentMonthy" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan">
            <el-form-item label="融资专员" class="is-required">
              <el-input v-model="financialData.staffName" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="rowGutter">
          <el-col :span="colSpan">
            <el-form-item label="融资专员手机号" class="is-required">
              <el-input v-model="financialData.dealerStaffPhone" auto-complete="off" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="colSpan"></el-col>
        </el-row>
      </div>
    </el-form>
  </div>
</template>
<script>
  import { getFinacialDictionary, getSalesManList, getFinancing } from '../../../api/applyProgress.js'
  export default {
    props: ['outerActiveTableName', 'innerActiveTableName'],
    data () {
      return {
        itemId: null,
        rowGutter: 20,
        colSpan: 8,
        financingParams: {}, // 融资费用明细配置
        repaymentFrequency: [], // 还款频率
        fee_payment_method: [], // 手续费扣款方式
        term: [], // 融资期限
        repaymentMethods: [], // 还款方式
        operateTypes: [], // 操作类型
        saleManList: [], // 融资专员
        interest_rate_type: [], // 利率类型
        ticket_opening: [], // 开票属性
        deposit_charge_against: [],
        financialData: {
          carPrice: null,
          purchaseTax: null,
          insurance: null,
          gps: null,
          financingFee: null,
          theftProtection: null,
          gpsQuantity: null,
          repaymentFrequency: null,
          repaymentMethod: null,
          interestMethod: null,
          term: null,
          operationType: null,
          downPaymentRatio: null,
          downPaymentAmt: null,
          feeRatio: null,
          feeAmount: null,
          feePaymentMethod: null,
          depositRatio: null,
          depositAmount: null,
          depositChargeAgainst: null,
          amount: null,
          makeloansAmount: null,
          repaymentMonthy: null,
          dealerStaffId: null,
          dealerStaffPhone: null
        }
      }
    },
    mounted () {
      this.itemId = this.$route.params.itemId ? +this.$route.params.itemId : null
      if (this.itemId) {
        this.getFinancingDict()
        this.getInfo(this.itemId)
      }
    },
    methods: {
      getFinancingDict () {
        // 融资字典信息
        getFinacialDictionary({
          applyId: this.itemId
        }).then(res => {
          if (res.data.respCode === '1000') {
            // let data = res.data.body
            const {financingParams, operateType, repaymentFrequency, productParams, repaymentMethod} = res.data.body
            this.financingParams = financingParams // 融资费用明细配置
            this.operateTypes = operateType
            this.repaymentFrequency = repaymentFrequency
            this.fee_payment_method = productParams.fee_payment_method
            this.term = productParams.term
            this.repaymentMethods = repaymentMethod
            this.interest_rate_type = productParams.interest_rate_type
            this.deposit_charge_against = productParams.deposit_charge_against
          }
        }).catch(error => { console.log(error) })
      },
      // 数据拉取
      getInfo (val) {
        getFinancing({ applyId: val }).then(res => {
          if (res.data.respCode === '1000') {
            this.financialData = {
              ...res.data.body,
              staffName: ''
            }
            if (this.financialData.dealerStaffId !== '' && this.financialData.dealerStaffId !== null) {
              getSalesManList({id: this.financialData.dealerStaffId}).then(res => {
                if (res.data.respCode === '1000') {
                  const {staffName} = res.data.body
                  this.financialData.staffName = staffName
                }
              }).catch(error => { console.log(error) })
            }
          }
        }).catch(error => { console.log(error) })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .calculate {
    width: 100px;
    display: block;
    margin: 0 auto;
  }
  .el-select{
    width: 100%;
  }
  .el-date-editor.el-input, .el-date-editor.el-input__inner {
    width: 100%;
  }
</style>

