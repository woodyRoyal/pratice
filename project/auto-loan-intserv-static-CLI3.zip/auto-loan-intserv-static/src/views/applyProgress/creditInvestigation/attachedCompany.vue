<template>
  <div v-if="attachedCompanyData.show">
    <div class="tableTitle clearfix"><span class="table-title-word">挂靠公司</span></div>
    <table class="self-table-comp" :model="attachedCompanyData">
      <tbody>
      <tr>
        <td>挂靠公司名称</td>
        <td>{{attachedCompanyData.companyName}}</td>
        <td>挂靠公司统一社会信用代码</td>
        <td>{{attachedCompanyData.unifiedSocialCreditCode}}</td>
      </tr>
      <tr>
        <td>准入结果</td>
        <td>{{attachedCompanyData.submitStatusDesc}}</td>
        <td>拒绝补件及原因描述</td>
        <td>{{attachedCompanyData.remark}}</td>
      </tr>
      <tr>
        <td>挂靠数量</td>
        <td>{{attachedCompanyData.attachedCount}}</td>
        <td>在贷金额</td>
        <td>{{attachedCompanyData.attachedAmount}}</td>
      </tr>
      <tr>
        <td>新网挂靠数量</td>
        <td>{{attachedCompanyData.xwAttachedCount}}</td>
        <td>新网在贷金额</td>
        <td>{{attachedCompanyData.xwAttachedAmount}}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>
<script>
  export default {
    props: ['attachedCompanyData']
  }
</script>
