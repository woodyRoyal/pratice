<template>
  <div v-if="pYTableData.show">
    <div class="tableTitle clearfix"><span class="table-title-word">鹏元驾照数据</span></div>
    <table class="self-table-comp" :model="pYTableData">
      <tbody>
      <tr>
        <td>准驾车型</td>
        <td>{{pYTableData.carClass}}</td>
        <td>有效期至</td>
        <td>{{pYTableData.expiryDate}}</td>
      </tr>
      <tr>
        <td>驾驶证状态</td>
        <td>{{pYTableData.licenseStatus}}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
  export default {
    props: ['pYTableData'],
    data () {
      return {}
    }
  }
</script>

<style scoped>

</style>
