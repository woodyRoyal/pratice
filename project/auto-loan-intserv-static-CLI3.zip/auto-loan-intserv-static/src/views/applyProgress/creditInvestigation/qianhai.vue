<template>
  <div v-if="qianHaiData.show">
    <div class="tableTitle clearfix"><span class="table-title-word">前海征信</span></div>
    <table class="self-table-comp" :model="qianHaiData">
      <tbody>
      <tr>
        <td>综合评分</td>
        <td>{{qianHaiData.credooScore}}</td>
        <td>查询时间</td>
        <td>{{qianHaiData.dataBuildTime}}</td>
        <td>失信分</td>
        <td>{{qianHaiData.defaultRiskScore}}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>
<script>
  export default {
    props: ['qianHaiData'],
    data () {
      return {}
    }
  }
</script>
<style lang="scss" scoped></style>
