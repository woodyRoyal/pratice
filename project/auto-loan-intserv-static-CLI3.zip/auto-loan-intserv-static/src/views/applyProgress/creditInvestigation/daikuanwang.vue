<template>
  <div v-if="dkwData.show">
    <div class="tableTitle clearfix"><span class="table-title-word">贷款王</span></div>
    <table class="self-table-comp" :model="dkwData">
      <tbody>
      <tr>
        <td>是否申请过</td>
        <td>{{dkwData.applied}}</td>
        <td>逾期次数</td>
        <td>{{dkwData.overdueCnt}}</td>
      </tr>
      <tr>
        <td>最大逾期天数</td>
        <td>{{dkwData.maxOverdueDays}}</td>
        <td>借款成功次数</td>
        <td>{{dkwData.borrowedCnt}}</td>
      </tr>
      <tr>
        <td>最后一次借款日期</td>
        <td>{{dkwData.lastBorrowedDate}}</td>
        <td>最后一次借款应还款日期</td>
        <td>{{dkwData.lastBorrowedShouldPayDate}}</td>
      </tr>
      <tr>
        <td>最后一次借款实际还款日期</td>
        <td>{{dkwData.lastBorrowedRealPayDate}}</td>
        <td>最后一次借款逾期天数</td>
        <td>{{dkwData.lastBorrowedOverdueDays}}</td>
      </tr>
      <tr>
        <td>最新的行为评分</td>
        <td>{{dkwData.latestBehaviorScore}}</td>
        <td>申请评分</td>
        <td>{{dkwData.applyScore}}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>
<script>
  export default {
    props: ['dkwData'],
    data () {
      return {}
    }
  }
</script>
<style lang="scss" scoped></style>
