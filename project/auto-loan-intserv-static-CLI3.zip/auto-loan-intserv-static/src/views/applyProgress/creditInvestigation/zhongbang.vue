<template>
  <div v-if="zhongBangData.show">
    <div class="tableTitle clearfix"><span class="table-title-word">众邦银行</span></div>
    <table class="self-table-comp" :model="zhongBangData">
      <tbody>
      <tr>
        <td>众邦准入结果</td>
        <td>
          {{auditStatus[zhongBangData.auditStatus]}}
          <!--<el-button size="mini" type="primary" @click="updateZBData">刷 新</el-button>-->
        </td>
        <td>授信时间</td>
        <td>{{zhongBangData.effectiveDate}}</td>
        <td>审批描述</td>
        <td>{{zhongBangData.resultMessage}}</td>
      </tr>
      <tr>
        <td>个人综合评分</td>
        <td>{{zhongBangData.generalScore}}</td>
        <td>个人负信评分</td>
        <td>{{zhongBangData.debtScore}}</td>
        <td>个人逾期评分</td>
        <td>{{zhongBangData.overdueScore}}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
  export default {
    props: ['zhongBangData'],
    data () {
      return {
        auditStatus: {
          '0': '拒绝',
          '1': '通过',
          '2': '处理中',
          '3': '异常',
          '4': '初始化'
        }
      }
    }
    /* methods: {
      updateZBData () {
        this.$emit('updateZBDataHandle')
      }
    } */
  }
</script>

<style scoped lang="scss"></style>
