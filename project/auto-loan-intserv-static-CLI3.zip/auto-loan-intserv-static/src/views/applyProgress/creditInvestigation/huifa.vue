<template>
  <div v-if="huiFaData.shixin.length || huiFaData.xianchu.length || huiFaData.qianshui.length || huiFaData.xiangao.length || huiFaData.zuifan.length || huiFaData.feizheng.length || huiFaData.zhixing.length || huiFaData.qiankuan.length || huiFaData.shenpan.length || huiFaData.caipan.length || huiFaData.weifa.length">
    <div class="tableTitle clearfix"><span class="table-title-word">汇法</span></div>
    <!--1.失信老赖名单-->
    <div v-if="huiFaData.shixin[0]">
      <h5>1.失信老赖名单</h5>
      <table class="self-table-comp" :model="item" v-for="(item, index) in huiFaData.shixin" :key="index">
        <tbody>
        <tr>
          <td>省份</td>
          <td>{{item.sxSf || '/'}}</td>
          <td>执行依据文号</td>
          <td>{{item.sxWh || '/'}}</td>
        </tr>
        <tr>
          <td>履行情况</td>
          <td>{{item.sxLx || '/'}}</td>
          <td>执行内容</td>
          <td>{{item.content || '/'}}</td>
        </tr>
        <tr>
          <td>被执行人姓名或名称</td>
          <td>{{item.name || '/'}}</td>
          <td>日期类别</td>
          <td>{{item.timetype || '/'}}</td>
        </tr>
        <tr>
          <td>执行依据单位</td>
          <td>{{item.sxDw || '/'}}</td>
          <td>具体情形</td>
          <td>{{item.sxJt || '/'}}</td>
        </tr>
        <tr>
          <td>标题</td>
          <td>{{item.title || '/'}}</td>
          <td>未履行金额</td>
          <td>{{item.wlmoney || '/'}}</td>
        </tr>
        <tr>
          <td>发布时间</td>
          <td>{{item.sxFb || '/'}}</td>
          <td>执行状态</td>
          <td>{{item.state || '/'}}</td>
        </tr>
        <tr>
          <td>执行案号</td>
          <td>{{item.casenum || '/'}}</td>
          <td>异议备注</td>
          <td>{{item.remark || '/'}}</td>
        </tr>
        <tr>
          <td>执行法院</td>
          <td>{{item.court || '/'}}</td>
          <td>立案时间</td>
          <td>{{item.sslong || '/'}}</td>
        </tr>
        <tr>
          <td>证件号码</td>
          <td>{{item.id || '/'}}</td>
          <td>数据类型</td>
          <td>{{item.typetname || '/'}}</td>
        </tr>
        </tbody>
      </table>
    </div>
    <!--2.限制出入境名单-->
    <div v-if="huiFaData.xianchu[0]">
      <h5>2.限制出入境名单</h5>
      <table class="self-table-comp" :model="item" v-for="(item, index) in huiFaData.xianchu" :key="index">
        <tbody>
        <tr>
          <td>执行案号</td>
          <td>{{item.casenum || '/'}}</td>
          <td>执行法院</td>
          <td>{{item.court || '/'}}</td>
        </tr>
        <tr>
          <td>被执行人姓名或名称</td>
          <td>{{item.name || '/'}}</td>
          <td>执行状态</td>
          <td>{{item.state || '/'}}</td>
        </tr>
        <tr>
          <td>异议备注</td>
          <td>{{item.remark || '/'}}</td>
          <td>执行内容</td>
          <td>{{item.content || '/'}}</td>
        </tr>
        <tr>
          <td>证件号码</td>
          <td>{{item.id || '/'}}</td>
          <td>数据类型</td>
          <td>{{item.typetname || '/'}}</td>
        </tr>
        <tr>
          <td>标题</td>
          <td>{{item.title || '/'}}</td>
          <td>立案时间</td>
          <td>{{item.sslong || '/'}}</td>
        </tr>
        <tr>
          <td>日期类别</td>
          <td>{{item.timetype || '/'}}</td>
        </tr>
        </tbody>
      </table>
    </div>
    <!--3.欠税名单-->
    <div v-if="huiFaData.qianshui[0]">
      <h5>3.欠税名单</h5>
      <table class="self-table-comp" :model="item" v-for="(item, index) in huiFaData.qianshui" :key="index">
        <tbody>
        <tr>
          <td>欠税金额</td>
          <td>{{item.money || '/'}}</td>
          <td>主管税务机关</td>
          <td>{{item.court || '/'}}</td>
        </tr>
        <tr>
          <td>证件号码</td>
          <td>{{item.id || '/'}}</td>
          <td>欠税属期</td>
          <td>{{item.taxperiod || '/'}}</td>
        </tr>
        <tr>
          <td>异议备注</td>
          <td>{{item.remark || '/'}}</td>
          <td>立案时间</td>
          <td>{{item.sslong || '/'}}</td>
        </tr>
        <tr>
          <td>数据类型</td>
          <td>{{item.typetname || '/'}}</td>
          <td>所欠税种</td>
          <td>{{item.taxtype || '/'}}</td>
        </tr>
        <tr>
          <td>标题</td>
          <td>{{item.title || '/'}}</td>
          <td>被执行人姓名或名称</td>
          <td>{{item.name || '/'}}</td>
        </tr>
        </tbody>
      </table>
    </div>
    <!--4.限制高消费名单-->
    <div v-if="huiFaData.xiangao[0]">
      <h5>4.限制高消费名单</h5>
      <table class="self-table-comp" :model="item" v-for="(item, index) in huiFaData.xiangao" :key="index">
        <tbody>
        <tr>
          <td>执行案号</td>
          <td>{{item.casenum || '/'}}</td>
          <td>执行内容</td>
          <td>{{item.content || '/'}}</td>
        </tr>
        <tr>
          <td>证件号码</td>
          <td>{{item.id || '/'}}</td>
          <td>日期类别</td>
          <td>{{item.timetype || '/'}}</td>
        </tr>
        <tr>
          <td>异议备注</td>
          <td>{{item.remark || '/'}}</td>
          <td>立案时间</td>
          <td>{{item.sslong || '/'}}</td>
        </tr>
        <tr>
          <td>执行法院</td>
          <td>{{item.court || '/'}}</td>
          <td>执行状态</td>
          <td>{{item.state || '/'}}</td>
        </tr>
        <tr>
          <td>标题</td>
          <td>{{item.title || '/'}}</td>
          <td>被执行人姓名或名称</td>
          <td>{{item.name || '/'}}</td>
        </tr>
        <tr>
          <td>数据类型</td>
          <td>{{item.typetname || '/'}}</td>
        </tr>
        </tbody>
      </table>
    </div>
    <!--5.罪犯及嫌疑人名单-->
    <div v-if="huiFaData.zuifan[0]">
      <h5>5.罪犯及嫌疑人名单</h5>
      <table class="self-table-comp" :model="item" v-for="(item, index) in huiFaData.zuifan" :key="index">
        <tbody>
        <tr>
          <td>案号</td>
          <td>{{item.casenum || '/'}}</td>
          <td>违法事由</td>
          <td>{{item.casetopic || '/'}}</td>
        </tr>
        <tr>
          <td>标题</td>
          <td>{{item.title || '/'}}</td>
          <td>数据类型</td>
          <td>{{item.typetname || '/'}}</td>
        </tr>
        <tr>
          <td>立案时间</td>
          <td>{{item.sslong || '/'}}</td>
          <td>异议备注</td>
          <td>{{item.remark || '/'}}</td>
        </tr>
        <tr>
          <td>侦查/批捕/审判机关</td>
          <td>{{item.court || '/'}}</td>
          <td>被执行人姓名或名称</td>
          <td>{{item.name || '/'}}</td>
        </tr>
        <tr>
          <td>证件号码</td>
          <td>{{item.id || '/'}}</td>
          <td>处理结果</td>
          <td><div style="overflow-y: auto; height: 200px;">{{item.content || '/'}}</div></td>
        </tr>
        </tbody>
      </table>
    </div>
    <!--6.纳税非正常户-->
    <div v-if="huiFaData.feizheng[0]">
      <h5>6.纳税非正常户</h5>
      <table class="self-table-comp" :model="item" v-for="(item, index) in huiFaData.feizheng" :key="index">
        <tbody>
        <tr>
          <td>认定日期</td>
          <td>{{item.sslong || '/'}}</td>
          <td>数据类型</td>
          <td>{{item.typetname || '/'}}</td>
        </tr>
        <tr>
          <td>纳税人名称</td>
          <td>{{item.name || '/'}}</td>
          <td>证件号码</td>
          <td>{{item.id || '/'}}</td>
        </tr>
        <tr>
          <td>异议备注</td>
          <td>{{item.remark || '/'}}</td>
          <td>主管税务机关</td>
          <td>{{item.court || '/'}}</td>
        </tr>
        </tbody>
      </table>
    </div>
    <!--7.执行公开信息-->
    <div v-if="huiFaData.zhixing[0]">
      <h5>7.执行公开信息</h5>
      <table class="self-table-comp" :model="item" v-for="(item, index) in huiFaData.zhixing" :key="index">
        <tbody>
        <tr>
          <td>终本日期</td>
          <td>{{item.zblong || '/'}}</td>
          <td>执行内容</td>
          <td>{{item.content || '/'}}</td>
        </tr>
        <tr>
          <td>执行状态</td>
          <td>{{item.state || '/'}}</td>
          <td>异议备注</td>
          <td>{{item.remark || '/'}}</td>
        </tr>
        <tr>
          <td>执行法院</td>
          <td>{{item.court || '/'}}</td>
          <td>执行案号</td>
          <td>{{item.casenum || '/'}}</td>
        </tr>
        <tr>
          <td>未履行金额</td>
          <td>{{item.wlmoney || '/'}}</td>
          <td>立案时间</td>
          <td>{{item.sslong || '/'}}</td>
        </tr>
        <tr>
          <td>证件号码</td>
          <td>{{item.id || '/'}}</td>
          <td>数据类型</td>
          <td>{{item.typetname || '/'}}</td>
        </tr>
        <tr>
          <td>申请执行人</td>
          <td>{{item.apply || '/'}}</td>
          <td>执行标的</td>
          <td>{{item.money || '/'}}</td>
        </tr>
        <tr>
          <td>被执行人姓名或名称</td>
          <td>{{item.name || '/'}}</td>
          <td>标题</td>
          <td>{{item.title || '/'}}</td>
        </tr>
        </tbody>
      </table>
    </div>
    <!--8.欠款欠费名单-->
    <div v-if="huiFaData.qiankuan[0]">
      <h5>8.欠款欠费名单</h5>
      <table class="self-table-comp" :model="item" v-for="(item, index) in huiFaData.qiankuan" :key="index">
        <tbody>
        <tr>
          <td>拖欠金额</td>
          <td>{{item.money || '/'}}</td>
          <td>欠款人姓名/名称</td>
          <td>{{item.name || '/'}}</td>
        </tr>
        <tr>
          <td>证件号码</td>
          <td>{{item.id || '/'}}</td>
          <td>身份</td>
          <td>{{item.pctype || '/'}}</td>
        </tr>
        <tr>
          <td>欠款原因</td>
          <td>{{item.casetopic || '/'}}</td>
          <td>标题</td>
          <td>{{item.title || '/'}}</td>
        </tr>
        <tr>
          <td>具体日期</td>
          <td>{{item.sslong || '/'}}</td>
          <td>异议备注</td>
          <td>{{item.remark || '/'}}</td>
        </tr>
        <tr>
          <td>数据类型</td>
          <td>{{item.typetname || '/'}}</td>
        </tr>
        </tbody>
      </table>
    </div>
    <!--9.民商事审判流程-->
    <div v-if="huiFaData.shenpan[0]">
      <h5>9.民商事审判流程</h5>
      <table class="self-table-comp" :model="item" v-for="(item, index) in huiFaData.shenpan" :key="index">
        <tbody>
        <tr>
          <td>执行案号</td>
          <td>{{item.casenum || '/'}}</td>
          <td>标题</td>
          <td>{{item.title || '/'}}</td>
        </tr>
        <tr>
          <td>立案时间</td>
          <td>{{item.sslong || '/'}}</td>
          <td>涉案事由</td>
          <td>{{item.casetopic || '/'}}</td>
        </tr>
        <tr>
          <td>所有当事人</td>
          <td>{{item.otherparty || '/'}}</td>
          <td>诉讼地位</td>
          <td>{{item.pctype || '/'}}</td>
        </tr>
        <tr>
          <td>审理机关</td>
          <td>{{item.court || '/'}}</td>
          <td>被执行人姓名或名称</td>
          <td>{{item.name || '/'}}</td>
        </tr>
        <tr>
          <td>证件号码</td>
          <td>{{item.id || '/'}}</td>
          <td>数据类型</td>
          <td>{{item.typetname || '/'}}</td>
        </tr>
        <tr>
          <td>异议备注</td>
          <td>{{item.remark || '/'}}</td>
          <td>公告内容</td>
          <td>{{item.content || '/'}}</td>
        </tr>
        <tr>
          <td>公告类型</td>
          <td>{{item.writtype || '/'}}</td>
          <td>日期类别</td>
          <td>{{item.timetype || '/'}}</td>
        </tr>
        </tbody>
      </table>
    </div>
    <!--10.民商事裁判文书-->
    <div v-if="huiFaData.caipan[0]">
      <h5>10.民商事裁判文书</h5>
      <table class="self-table-comp" :model="item" v-for="(item, index) in huiFaData.caipan" :key="index">
        <tbody>
        <tr>
          <td>原告当事人</td>
          <td>{{item.plaintiff || '/'}}</td>
          <td>异议备注</td>
          <td>{{item.remark || '/'}}</td>
        </tr>
        <tr>
          <td>审理人员</td>
          <td>{{item.tribunal || '/'}}</td>
          <td>被告当事人</td>
          <td>{{item.defendant || '/'}}</td>
        </tr>
        <tr>
          <td>被执行人姓名或名称</td>
          <td>{{item.name || '/'}}</td>
          <td>证件号码</td>
          <td>{{item.id || '/'}}</td>
        </tr>
        <tr>
          <td>完整内容查看地址</td>
          <td><a :href="item.furlCasecon ? item.furlCasecon : '#'">点击查看</a></td>
          <td>执行案号</td>
          <td>{{item.casenum || '/'}}</td>
        </tr>
        <tr>
          <td>标题</td>
          <td>{{item.title || '/'}}</td>
          <td>审理结果</td>
          <td><div style="overflow-y: auto; height: 200px;">{{item.content || '/'}}</div></td>
        </tr>
        <tr>
          <td>审理程序</td>
          <td>{{item.vprogram || '/'}}</td>
          <td>文书类型</td>
          <td>{{item.writtype || '/'}}</td>
        </tr>
        <tr>
          <td>其他当事人</td>
          <td>{{item.otherparty || '/'}}</td>
          <td>诉讼地位</td>
          <td>{{item.pctype || '/'}}</td>
        </tr>
        <tr>
          <td>审理机关</td>
          <td>{{item.court || '/'}}</td>
          <td>涉案金额</td>
          <td>{{item.money || '/'}}</td>
        </tr>
        <tr>
          <td>立案时间</td>
          <td>{{item.sslong || '/'}}</td>
          <td>涉案事由</td>
          <td>{{item.casetopic || '/'}}</td>
        </tr>
        <tr>
          <td>数据类型</td>
          <td>{{item.typetname || '/'}}</td>
        </tr>
        </tbody>
      </table>
    </div>
    <!--11.行政违法记录-->
    <div v-if="huiFaData.weifa[0]">
      <h5>11.行政违法记录</h5>
      <table class="self-table-comp" :model="item" v-for="(item, index) in huiFaData.weifa" :key="index">
        <tbody>
        <tr>
          <td>案号</td>
          <td>{{item.casenum || '/'}}</td>
          <td>执法/复议/审判机关</td>
          <td>{{item.court || '/'}}</td>
        </tr>
        <tr>
          <td>立案时间</td>
          <td>{{item.sslong || '/'}}</td>
          <td>证件号码</td>
          <td>{{item.id || '/'}}</td>
        </tr>
        <tr>
          <td>异议备注</td>
          <td>{{item.remark || '/'}}</td>
          <td>行政执法结果</td>
          <td>{{item.content || '/'}}</td>
        </tr>
        <tr>
          <td>被执行人姓名或名称</td>
          <td>{{item.name || '/'}}</td>
          <td>日期类别</td>
          <td>{{item.timetype || '/'}}</td>
        </tr>
        <tr>
          <td>标题</td>
          <td>{{item.title || '/'}}</td>
          <td>法院审理结果</td>
          <td>{{item.content2 || '/'}}</td>
        </tr>
        <tr>
          <td>违法事由</td>
          <td>{{item.casetopic || '/'}}</td>
          <td>数据类型</td>
          <td>{{item.typetname || '/'}}</td>
        </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script>
  export default {
    props: ['huiFaData'],
    data () {
      return {}
    }
  }
</script>
<style lang="scss" scoped>
  .formTitle{
    font-size: 20px;
    padding-bottom:6px;
    border-bottom: 2px solid #ccc;
    margin: 0;
    font-weight: bolder;
  }
</style>
