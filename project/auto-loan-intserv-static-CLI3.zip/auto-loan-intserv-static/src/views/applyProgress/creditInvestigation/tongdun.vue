<template>
  <div class="clearfix">
    <div class="tableTitle clearfix"><span class="table-title-word">同盾风险检查项</span></div>
    <table class="self-table-comp">
      <tbody>
      <tr>
        <td width="100">同盾总分</td>
        <td>{{tongdunData.finalScore}}</td>
      </tr>
      </tbody>
    </table>
    <el-table border stripe :data="tongdunData.riskItems" v-if="tongdunData.total">
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="风控风险描述">
        <template slot-scope="scope">
          {{scope.row.itemName}}
        </template>
      </el-table-column>
      <el-table-column label="是否命中黑名单">
        <template slot-scope="scope">
          {{'是'}}
        </template>
      </el-table-column>
      <el-table-column label="具体数值">
        <template slot-scope="scope">
          {{scope.row.riskLevel}}
        </template>
      </el-table-column>
    </el-table>
    <el-pagination v-if="tongdunData.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="tongdunPage.pageNum" :page-sizes="tongdunPage.pageSizes" :page-size="tongdunPage.pageSize"
                   layout="total, sizes, prev, pager, next, jumper" :total="tongdunPage.total" class="pagination">
    </el-pagination>
  </div>
</template>
<script>
  export default {
    props: ['tongdunData', 'tongdunPage'],
    data () {
      return {}
    },
    methods: {
      handleSizeChange (val) {
        this.$emit('updateData', {pageSize: val})
      },
      handleCurrentChange (val) {
        this.$emit('updateData', {pageNum: val})
      }
    }
  }
</script>
<style lang="scss" scoped>
  .pagination{
    margin: 5px 40px 0 0;
    float: right;
  }
</style>
