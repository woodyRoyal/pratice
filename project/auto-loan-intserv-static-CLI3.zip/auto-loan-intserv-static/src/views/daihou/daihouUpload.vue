<template>
  <div>
    <el-form size="small" label-position="left" :inline="true">
      <!-- <el-row :gutter="10"> -->
        <!-- <el-col :span="6"> -->
          <el-form-item label="申请编号" label-width="70px">
            <el-input maxlength="8" v-model="queryData.applyId" @blur="checkApplyId(queryData.applyId)" placeholder="输入申请编号" onkeypress='return(/^[0-9]*$/.test(String.fromCharCode(event.keyCode)))'></el-input>
          </el-form-item>
          <el-form-item label="申请编号(老)" :label-width="'100px'">
              <el-input maxlength="7" v-model="queryData.oldApplyNo" @blur="checkApplyId(queryData.oldApplyNo,'oldApplyNo',7)" placeholder="申请编号(老)" onkeypress='return(/^[0-9]*$/.test(String.fromCharCode(event.keyCode)))'></el-input>
            </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="6"> -->
          <el-form-item label="客户姓名" label-width="70px">
            <el-input maxlength="20" v-model="queryData.name" placeholder="输入客户姓名"></el-input>
          </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="6"> -->
          <el-form-item label="SP店面" label-width="70px">
            <el-input maxlength="30" v-model="queryData.dealer" placeholder="输入SP店面"></el-input>
          </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="6"> -->
          <el-form-item>
            <el-button type="primary" size="small" @click="resetQuery">重置</el-button>
            <el-button type="primary" size="small" @click="queryFn">查询</el-button>
          </el-form-item>
        <!-- </el-col> -->
      <!-- </el-row> -->
    </el-form>
    <el-table :data="tableData" border>
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="申请编号">
        <template slot-scope="scope">
          {{scope.row.applyId}}
          <el-tag type="warning" size="mini" v-if="tableData.specialPermit">特批</el-tag>
          <el-tag type="warning" size="mini" v-if="tableData.reconsideration">复议</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="申请编号(老)">
        <template slot-scope="scope">
          <!--老系统显示 oldApplyNo，新系统显示 '/'-->
          {{scope.row.oldApplyNo || '/'}}
        </template>
      </el-table-column>
      <el-table-column label="客户姓名">
        <template slot-scope="scope">
          {{scope.row.name}}
        </template>
      </el-table-column>
      <el-table-column label="车架号" prop="carVin"></el-table-column>
      <el-table-column label="发动机号" prop="carEngin"></el-table-column>
      <el-table-column label="sp店面" width="300%">
        <template slot-scope="scope">
          {{scope.row.dealer}}
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="text" @click="toFileuploadDetail(scope.row)">上传附件</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="clearfix">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="page.pageNum"
        :page-sizes="page.pageSizeArr"
        :page-size="page.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="page.total"
        class="page">
      </el-pagination>
    </div>
  </div>
</template>

<script>
  import {daihouUploadList} from '../../api/daihou'
  import {checkApplyId} from '../../utils/constant'
  export default {
    data () {
      return {
        checkApplyId,
        queryData: {
          oldApplyNo: null,
          applyId: null,
          name: null,
          dealer: null
        },
        page: {
          pageNum: 1,
          pageSizeArr: [10, 20, 30, 40],
          pageSize: 10,
          total: 0
        },
        tableData: []
      }
    },
    mounted () {
      this.getDaihouUploadList()
    },
    methods: {
      getDaihouUploadList () {
        this.queryData.pageNum = this.page.pageNum
        this.queryData.pageSize = this.page.pageSize
        daihouUploadList(this.queryData).then((res) => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            this.tableData = data.uploadList
            this.page.total = data.total
          }
        }).catch(error => { console.log(error) })
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.getDaihouUploadList()
      },
      handleCurrentChange (val) {
        this.page.pageNum = val
        this.getDaihouUploadList()
      },
      queryFn () {
        this.getDaihouUploadList()
      },
      resetQuery () {
        for (let k in this.queryData) {
          this.queryData[k] = null
        }
        this.getDaihouUploadList()
      },
      toFileuploadDetail (val) {
        window.open('#/daihouUploadDetail/' + val.id, '_blank')
      }
    }
  }
</script>

<style lang="scss" scoped>
  .page{
    float: right;
    margin-top: 5px;
  }
</style>
