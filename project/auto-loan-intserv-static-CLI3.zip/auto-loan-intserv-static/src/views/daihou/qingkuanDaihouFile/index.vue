<template>
  <!--贷后和请款-->
  <div ref="qingkuandaihouUploadWrap" class="qinkuan-daihou-upload-wrap">
    <!--贷后-->
    <FileUpload
      applyNode="post_loan_upload"
      :showSaveButton="true"
      :isSaveLoading="isSaveLoading"
      :hideSideTitle="false"
      :hideAllUploadSwitch="false"
      :hideTree="false"
      :hideDeleteBtn="false"
      :necessaryUploadData="postLoanUpRequiredFileList"
      :unNecessaryUploadData="postLoanUpNotRequiredFileLis"
      :optionalTreeData="postLoanUploadKinds"
      @changeUnNecessaryUploadData="changeUnNecessaryUploadDataHandle"
      @changeNecessaryUploadData="changeNecessaryUploadDataHandle"
      @showPicView="showPicViewHandle"
      @deleteFileItem='deleteFileItemHandle'
      @saveUploadFiles="saveUploadFilesHandle"
    ></FileUpload>
    <!--请款-->
    <FileUpload
      applyNode="request_loan_attachment"
      :showSaveButton="false"
      :hideSideTitle="false"
      :hideAllUploadSwitch="false"
      :hideTree="false"
      :hideDeleteBtn="false"
      :necessaryUploadData="requestLoanAttachmentRequiredFileList"
      :unNecessaryUploadData="requestLoanAttachmentNotRequiredFileList"
      :optionalTreeData="requestLoanAttachmentKinds"
      @changeUnNecessaryUploadData="changeUnNecessaryUploadDataHandle"
      @changeNecessaryUploadData="changeNecessaryUploadDataHandle"
      @deleteFileItem='deleteFileItemHandle'
      @showPicView="showPicViewHandle"
    ></FileUpload>
  </div>
</template>

<script>
  import {getFileMenuTree, filesListGet, saveUploadFilesList, deleteImgItem} from '../../../api/upload'
  import {mapGetters} from 'vuex'
  import FileUpload from '../../../components/fileUpload/index'
  import {deleteFileApiCallback} from '../../../utils/constant'
  export default {
    data () {
      return {
        viewer: null,
        requestLoanAttachmentKinds: [], // 请款树
        postLoanUploadKinds: [], // 贷后树
        requestLoanAttachmentRequiredFileList: [], // 请款必传
        requestLoanAttachmentNotRequiredFileList: [], // 请款非必传
        postLoanUpRequiredFileList: [], // 贷后必传
        postLoanUpNotRequiredFileLis: [], // 贷后非必传
        // 兼容静态方法所需数据
        requiredFilesList: [],
        notRequiredFilesList: [],
        defaultProps: {
          children: 'list',
          label: 'dictName'
        },
        fileLists: [],
        showPicView: false,
        isSaveLoading: false
      }
    },
    mounted () {
      this.fileMenuList()
      this.getFilesData()
      this.autoHeight()
      window.addEventListener('resize', this.autoHeight)
    },
    destroyed () {
      window.removeEventListener('resize', this.autoHeight)
    },
    components: { FileUpload },
    computed: {
      ...mapGetters(['applyId'])
    },
    methods: {
      // 选传文件树
      fileMenuList () {
        getFileMenuTree({applyId: this.applyId, categoryList: ['request_loan_attachment', 'post_loan_upload'], showFaultFile: false}).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            data.forEach(item => {
              if (item.dictKey === 'request_loan_attachment') this.requestLoanAttachmentKinds = item.list
              if (item.dictKey === 'post_loan_upload') this.postLoanUploadKinds = item.list
            })
          }
        }).catch(error => { console.log(error) })
      },
      // 文件获取
      getFilesData () {
        let data = {applyId: this.applyId, categoryList: ['request_loan_attachment', 'post_loan_upload'], showFaultFile: true}
        filesListGet(data).then(res => {
          if (res.data.respCode === '1000') {
            let applyMoneyData = res.data.body[0]
            let afterLendData = res.data.body[1]
            this.requestLoanAttachmentRequiredFileList = applyMoneyData.requiredFileCategoryListVos
            this.requestLoanAttachmentNotRequiredFileList = applyMoneyData.notRequiredFileCategoryListVos
            this.postLoanUpRequiredFileList = afterLendData.requiredFileCategoryListVos
            this.postLoanUpNotRequiredFileLis = afterLendData.notRequiredFileCategoryListVos
          }
        }).catch(error => { console.log(error) })
      },
      // 文件保存
      saveUploadFilesHandle () {
        this.isSaveLoading = true
        let apiParams = [
          {applyId: this.applyId, requiredFileCategoryListVos: this.requestLoanAttachmentRequiredFileList, notRequiredFileCategoryListVos: this.requestLoanAttachmentNotRequiredFileList},
          {applyId: this.applyId, requiredFileCategoryListVos: this.postLoanUpRequiredFileList, notRequiredFileCategoryListVos: this.postLoanUpNotRequiredFileLis}
        ]
        saveUploadFilesList(apiParams).then(res => {
          if (res.data.respCode === '1000') {
            this.isSaveLoading = false
            this.$message.success('保存成功')
            this.getFilesData()
          } else {
            this.isSaveLoading = false
          }
        }).catch(err => {
          this.isSaveLoading = false
          console.log(err)
        })
      },
      /* // 文件删除回调
      deleteFileApiCallback (data) {
        let copyImgItem = JSON.parse(JSON.stringify(data.imgItem))
        copyImgItem.relatedId = this.applyId
        copyImgItem.relatedGroup = data.applyNode
        copyImgItem.fileCategory = data.applyNode === 'post_loan_upload' ? 'fault_file_post_loan' : 'fault_file_request_loan'
        let notRequiredFilesList = []
        let requiredFilesList = []
        let faultFileExists = false
        if (data.applyNode === 'post_loan_upload') {
          notRequiredFilesList = this.postLoanUpNotRequiredFileLis
          requiredFilesList = this.postLoanUpRequiredFileList
        } else {
          notRequiredFilesList = this.requestLoanAttachmentNotRequiredFileList
          requiredFilesList = this.requestLoanAttachmentRequiredFileList
        }
        // 删除
        if (data.isRequired) {
          requiredFilesList.forEach(item => {
            item.pictureListVOList.forEach(item => {
              if (item.dictKey === data.imgItem.fileCategory) {
                item.fileRecordVOList.splice(data.index, 1)
              }
            })
          })
        } else {
          notRequiredFilesList.forEach(item => {
            item.pictureListVOList.forEach(item => {
              if (item.dictKey === data.imgItem.fileCategory) {
                item.fileRecordVOList.splice(data.index, 1)
              }
            })
          })
        }
        // 添加
        if (notRequiredFilesList.length) {
          notRequiredFilesList.forEach(item => {
            item.pictureListVOList.forEach(k => {
              if (k.dictKey === 'fault_file_request_loan' || k.dictKey === 'fault_file_post_loan') faultFileExists = !faultFileExists
            })
          })
          if (faultFileExists) { // 有
            notRequiredFilesList.forEach(item => {
              item.pictureListVOList.forEach(k => {
                if (k.dictKey === 'fault_file_request_loan' || k.dictKey === 'fault_file_post_loan') k.fileRecordVOList.push({...copyImgItem})
              })
            })
          } else { // 无
            notRequiredFilesList[0].pictureListVOList.push({
              dictKey: data.applyNode === 'post_loan_upload' ? 'fault_file_post_loan' : 'fault_file_request_loan',
              fileRecordVOList: [{...copyImgItem}],
              name: data.applyNode === 'post_loan_upload' ? '贷后误传文件' : '请款的误传文件'})
          }
        } else {
          this.notRequiredFilesList.push(
            {categoryDesc: data.applyNode === 'post_loan_upload' ? '贷后文件上传' : '请款附件',
              dictCategory: data.applyNode,
              pictureListVOList: [{
                dictKey: data.applyNode === 'post_loan_upload' ? 'fault_file_post_loan' : 'fault_file_request_loan',
                fileRecordVOList: [{...copyImgItem}],
                name: data.applyNode === 'post_loan_upload' ? '贷后误传文件' : '请款的误传文件'}]
            }
          )
        }
      }, */
      // 文件删除
      deleteFileItemHandle (data) {
        let apiData = JSON.parse(JSON.stringify(data.imgItem))
        console.log(data.applyNode)
        apiData.relatedId = this.applyId
        apiData.relatedGroup = data.applyNode
        apiData.fileCategory = data.applyNode === 'post_loan_upload' ? 'fault_file_post_loan' : 'fault_file_request_loan'
        // 静态方法只支持单一类型，此处是多个类型，因此需要兼容
        if (data.applyNode === 'post_loan_upload') {
          this.requiredFilesList = this.postLoanUpRequiredFileList
          this.notRequiredFilesList = this.postLoanUpNotRequiredFileLis
        } else {
          this.requiredFilesList = this.requestLoanAttachmentRequiredFileList
          this.notRequiredFilesList = this.requestLoanAttachmentNotRequiredFileList
        }
        deleteImgItem(apiData).then(res => {
          if (res.data.respCode === '1000') {
            const _vue = this
            const deleteCbParam = {
              _vue,
              relatedId: this.applyId,
              fileData: data,
              dictCategory: apiData.relatedGroup,
              dictKey: apiData.fileCategory
            }
            deleteFileApiCallback(deleteCbParam)
            this.$message.success('删除成功')
          }
        }).catch(err => { console.log(err) })
      },
      autoHeight () {
        let clientHeight = document.documentElement.clientHeight
        this.$refs['qingkuandaihouUploadWrap'].style.height = (clientHeight - 55) + 'px'
      },
      // 替换非必传文件
      changeUnNecessaryUploadDataHandle (data) {
        if (data.applyNode === 'request_loan_attachment') {
          this.requestLoanAttachmentNotRequiredFileList = data.notRequiredFilesList
        } else if (data.applyNode === 'post_loan_upload') {
          this.postLoanUpNotRequiredFileLis = data.notRequiredFilesList
        }
      },
      // 替换必传文件
      changeNecessaryUploadDataHandle (data) {
        if (data.applyNode === 'request_loan_attachment') {
          this.requestLoanAttachmentRequiredFileList = data.requiredFilesList
        } else if (data.applyNode === 'post_loan_upload') {
          this.postLoanUpRequiredFileList = data.requiredFilesList
        }
      },
      // 文件预览
      showPicViewHandle (data) {
        this.$emit('getPicViewData', data)
      },
      clearPicViewData () {}
    }
  }
</script>

<style lang="scss" scoped>
  @import "../../../styles/fileUpload";
  .qinkuan-daihou-upload-wrap{
    overflow-y: auto;
  }
</style>
