<template>
  <div class="fapiaoWrap">
    <div class="formModuleTitle"><span>快递信息</span></div>
    <el-form label-position="top" size="small">
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item :label-width="formLable" label="快递单号" class="is-required">
            <el-input disabled v-model="expressInfo.expressId"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item :label-width="formLable" label="寄出时间" class="is-required">
            <el-date-picker type="date" value-format="yyyy-MM-dd" disabled v-model="expressInfo.sendDate"></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item :label-width="formLable" label="快递公司名称" class="is-required">
            <el-input disabled v-model="expressInfo.company"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="24">
          <el-form-item :label-width="formLable" label="内容(描述)">
            <el-input disabled v-model="expressInfo.content" type="textarea"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="24">
          <el-form-item :label-width="formLable" label="备注">
            <el-input disabled v-model="expressInfo.remark" type="textarea"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
  export default {
    props: ['expressInfo'],
    data () {
      return {
        rowGutter: 10,
        colSpan: 8,
        formLable: '108px'
      }
    },
    mounted () {}
  }
</script>

<style lang="scss" scoped>
</style>
