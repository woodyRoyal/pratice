<template>
  <div class="huankuankaWrap">
    <div class="formModuleTitle"><span>车辆登记信息</span></div>
    <el-form label-position="top" size="small">
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="产证归档编号" :label-width="formLable" class="is-required">
            <el-input disabled v-model="carRegisterInfo.productionLicenseId"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="机动车登记证书编号" :label-width="formLable" class="is-required">
            <el-input disabled v-model="carRegisterInfo.registerLicenseId"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="抵押日期" :label-width="formLable" class="is-required">
            <el-date-picker type="date" disabled v-model="carRegisterInfo.mortgageDate" value-format="yyyy-MM-dd"></el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item label="出厂日期" :label-width="formLable" class="is-required">
            <el-date-picker type="date" disabled v-model="carRegisterInfo.manufactureDate" value-format="yyyy-MM-dd"></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item label="车牌号" :label-width="formLable">
            <el-input disabled v-model="carRegisterInfo.carLicencePlate"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan"></el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
  export default {
    props: ['carRegisterInfo'],
    data () {
      return {
        rowGutter: 10,
        colSpan: 8,
        formLable: '121px'
      }
    },
    mounted () {}
  }
</script>

<style lang="scss" scoped>
</style>
