<template>
  <div class="fapiaoWrap">
    <div class="formModuleTitle"><span>发票信息</span></div>
    <el-form label-position="top" size="small">
      <el-row :gutter="5">
        <el-col :span="12">
          <el-form-item :label-width="formLable" label="销货单位名称" class="is-required">
            <el-input disabled v-model="invoiceData.salesUnit"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item :label-width="formLable" label="车辆发票代码" class="is-required">
            <el-input disabled v-model="invoiceData.invoiceCode"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="5">
        <el-col :span="12">
          <el-form-item :label-width="formLable" label="车辆发票金额（不含税价）" class="is-required">
            <el-input disabled v-model="invoiceData.invoiceAmount"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item :label-width="formLable" label="车辆发票金额（含税价）" class="is-required">
            <el-input disabled v-model="invoiceData.invoiceAmountTax"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="rowGutter">
        <el-col :span="colSpan">
          <el-form-item :label-width="formLable" label="车辆发票号码" class="is-required">
            <el-input disabled v-model="invoiceData.invoiceNumber"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item :label-width="formLable" label="纳税人识别号" class="is-required">
            <el-input disabled v-model="invoiceData.taxpayerNumber"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="colSpan">
          <el-form-item :label-width="formLable" label="车辆开票日期" class="is-required">
            <el-date-picker type="date" value-format="yyyy-MM-dd" disabled v-model="invoiceData.billingDate"></el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
  export default {
    props: ['invoiceData'],
    data () {
      return {
        rowGutter: 10,
        colSpan: 8,
        formLable: '108px'
      }
    },
    mounted () {}
  }
</script>

<style lang="scss" scoped>
</style>
