<template>
  <div class="approveHandleWrap"
       v-loading="filePushLoading"
       element-loading-text="资料推送中，请耐心等待"
       element-loading-spinner="el-icon-loading"
       element-loading-background="rgba(255, 255, 255, 0.8)">
  <el-row v-if="applyId">
    <el-col :span="15">
      <div class="left" ref="left" id="left">
        <el-tabs :value="tabActiveName">
          <el-tab-pane label="审核首页" name="1">
            <daihouApprove></daihouApprove>
          </el-tab-pane>
          <el-tab-pane label="贷后、请款附件资料" name="2" :lazy="true">
            <qingkuanDaihouFile ref="postLoan_requestLoad" @getPicViewData="getPicViewDataHandle"></qingkuanDaihouFile>
          </el-tab-pane>
          <el-tab-pane label="车辆及融资" name="3" :lazy="true">
            <carFinancial></carFinancial>
          </el-tab-pane>
          <el-tab-pane label="申请人信息" name="4" :lazy="true">
            <applyerInfo></applyerInfo>
          </el-tab-pane>
          <el-tab-pane label="担保人信息" name="5" :lazy="true">
            <guaranteeInfo></guaranteeInfo>
          </el-tab-pane>
          <el-tab-pane label="提报附件资料" name="6" :lazy="true">
            <fileUpload ref="tbFile" @getPicViewData="getPicViewDataHandle"></fileUpload>
          </el-tab-pane>
          <el-tab-pane label="审批历史/历史关联" name="7" :lazy="true">
            <approveHistory></approveHistory>
          </el-tab-pane>
        </el-tabs>
      </div>
    </el-col>
    <el-col :span="9" class="colRight">
      <div class="rightColumn" ref="rightColumn">
        <summaryInfo @changeTabActiveName="changeTabActiveName"></summaryInfo>
        <approveHandle @updateFilePushLoading="updateFilePushLoadingHandle"></approveHandle>
      </div>
    </el-col>
  </el-row>
  <div class="pic-view-wrap" v-drag v-if="showPicView">
    <PicView v-if="showPicView" :imgItemList="imgItemList" :clickItem="clickItem" @closePicView="closePicViewHandle"></PicView>
  </div>
  </div>
</template>

<script>
  import summaryInfo from './summaryInfo'
  import daihouApprove from './daihouApprove/index'
  import qingkuanDaihouFile from './qingkuanDaihouFile/index'
  import carFinancial from './carFinancial/carFinancial.vue'
  import applyerInfo from '../components/applyerAndGuarantee/applyerInfo'
  import guaranteeInfo from '../components/applyerAndGuarantee/guaranteeInfo'
  import fileUpload from '../components/tbFile/index'
  import approveHistory from '../components/approveHistory.vue'
  import PicView from '../../components/PicView/index'
  import itemsList from './itemsList'
  import approveHandle from './approveHandle'
  import {mapGetters} from 'vuex'
  export default {
    data () {
      return {
        filePushLoading: false,
        showPicView: false,
        clickItem: null,
        imgItemList: null,
        tabActiveName: '1'
      }
    },
    created () {
      const {applyId, applyType} = this.$route.params
      if (this.provinceCityList.length === 0) this.$store.dispatch('getAreaTree')
      if (applyId && (applyType >= 0)) this.$store.dispatch('saveApplyIdApplyType', {applyId: +applyId, applyType: +applyType})
    },
    mounted () {
      this.rightAutoHeight()
      window.addEventListener('resize', this.rightAutoHeight)
    },
    computed: {
      ...mapGetters(['applyId', 'tabName', 'provinceCityList'])
    },
    components: {
      daihouApprove,
      qingkuanDaihouFile,
      carFinancial,
      applyerInfo,
      guaranteeInfo,
      fileUpload,
      approveHistory,
      PicView,
      summaryInfo,
      itemsList,
      approveHandle
    },
    methods: {
      rightAutoHeight () {
        let clientH = document.documentElement.clientHeight || document.body.clientHeight
        this.$refs['rightColumn'].style.height = clientH + 'px'
      },
      updateFilePushLoadingHandle (data) {
        this.filePushLoading = data.loading
      },
      changeTabActiveName (payload) {
        const {tabName} = payload
        this.tabActiveName = tabName
      },
      getPicViewDataHandle (data) {
        this.showPicView = true
        this.clickItem = data.clickItem
        this.imgItemList = data.imgItemList
      },
      closePicViewHandle () {
        this.showPicView = false
      }
    }
  }
</script>

<style lang="scss" scoped>
  .left{
    height: 100%;
  }
  .rightColumn{
    box-sizing: border-box;
    padding: 0 5px;
    overflow-y: auto;
  }
  .pic-view-wrap{
    position: absolute;
    top: 0;
    left: 50%;
    background: #fff;
    z-index: 1000;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.3);
  }
</style>
