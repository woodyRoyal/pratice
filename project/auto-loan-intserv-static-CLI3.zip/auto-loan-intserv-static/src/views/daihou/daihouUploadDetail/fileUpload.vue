<template>
  <div ref="applyTbUploadWrap"
       class="apply-tb-upload-wrap">
    <!--申请提报-->
    <FileUpload
      apply-node="identity_file"
      :show-save-button="true"
      :hide-side-title="false"
      :hide-all-upload-switch="false"
      :hide-tree="true"
      :hide-delete-btn="false"
      :necessary-upload-data="applyCollectRequiredFileList"
      :un-necessary-upload-data="applyCollectNotRequiredFileList"
      @changeUnNecessaryUploadData="changeUnNecessaryUploadDataHandle"
      @changeNecessaryUploadData="changeNecessaryUploadDataHandle"
      @deleteFileItem="deleteFileItemHandle"
      @showPicView="showPicViewHandle"
      @saveUploadFiles="saveUploadFilesHandle"
    ></FileUpload>
    <!-- 内部文件 -->
    <FileUpload
      apply-node="internal_audit_file"
      :show-save-button="false"
      :hide-side-title="false"
      :hide-all-upload-switch="false"
      :hide-tree="false"
      :hide-delete-btn="false"
      :necessary-upload-data="internalAuditRequiredFileList"
      :un-necessary-upload-data="[]"
      @changeUnNecessaryUploadData="changeUnNecessaryUploadDataHandle"
      @changeNecessaryUploadData="changeNecessaryUploadDataHandle"
      @deleteFileItem="deleteFileItemHandle"
      @showPicView="showPicViewHandle"
      @saveUploadFiles="saveUploadFilesHandle"
    ></FileUpload>
    <!--贷后-->
    <!--请款-->
    <FileUpload
      apply-node="request_loan_attachment"
      :show-save-button="false"
      :hide-side-title="false"
      :hide-all-upload-switch="false"
      :hide-tree="false"
      :hide-delete-btn="false"
      :necessary-upload-data="requestLoanAttachmentRequiredFileList"
      :un-necessary-upload-data="requestLoanAttachmentNotRequiredFileList"
      :optional-tree-data="requestLoanAttachmentKinds"
      @changeUnNecessaryUploadData="changeUnNecessaryUploadDataHandle"
      @changeNecessaryUploadData="changeNecessaryUploadDataHandle"
      @deleteFileItem="deleteFileItemHandle"
      @showPicView="showPicViewHandle"
      @saveUploadFiles="saveUploadFilesHandle"
    ></FileUpload>
    <!--贷后-->
    <FileUpload
      apply-node="post_loan_upload"
      :show-save-button="false"
      :is-save-loading="isSaveLoading"
      :hide-side-title="false"
      :hide-all-upload-switch="false"
      :hide-tree="false"
      :hide-delete-btn="false"
      :necessary-upload-data="postLoanUpRequiredFileList"
      :un-necessary-upload-data="postLoanUpNotRequiredFileLis"
      :optional-tree-data="postLoanUploadKinds"
      @changeUnNecessaryUploadData="changeUnNecessaryUploadDataHandle"
      @changeNecessaryUploadData="changeNecessaryUploadDataHandle"
      @showPicView="showPicViewHandle"
      @deleteFileItem="deleteFileItemHandle"
    ></FileUpload>
    <div v-if="showPicView"
         v-drag
         class="pic-view-wrap">
      <PicView v-if="showPicView"
               :img-item-list="imgItemList"
               :click-item="clickItem"
               @closePicView="closePicViewHandle"></PicView>
    </div>
  </div>
</template>

<script>
  import {getFileMenuTree, filesListGet, filesGet, saveUploadFilesList, deleteImgItem} from '../../../api/upload'
  import FileUpload from '../../../components/fileUpload/index'
  import PicView from '../../../components/PicView/index'
  import {deleteFileApiCallback} from '../../../utils/constant'
  export default {
    components: { FileUpload, PicView },
    data () {
      return {
        applyId: null,
        requestLoanAttachmentKinds: [], // 请款树
        postLoanUploadKinds: [], // 贷后树
        requestLoanAttachmentRequiredFileList: [], // 请款必传
        requestLoanAttachmentNotRequiredFileList: [], // 请款非必传
        postLoanUpRequiredFileList: [], // 贷后必传
        postLoanUpNotRequiredFileLis: [], // 贷后非必传
        applyCollectRequiredFileList: [], // 申请提报必传
        applyCollectNotRequiredFileList: [], // 申请提报非必传
        internalAuditRequiredFileList: [], // 内部上传文件必传
        // 兼容静态方法所需数据
        requiredFilesList: [],
        notRequiredFilesList: [],
        defaultProps: {
          children: 'list',
          label: 'dictName',
        },
        isSaveLoading: false,
        showPicView: false,
        imgItemList: [],
        clickItem: {},
      }
    },
    mounted () {
      this.applyId = this.$route.params.applyId ? +this.$route.params.applyId : null
      this.fileMenuList()
      this.getFilesData()
      this.autoHeight()
      this.getTbFiles()
      window.addEventListener('resize', this.autoHeight)
    },
    destroyed () {
      window.removeEventListener('resize', this.autoHeight)
    },
    methods: {
      // 选传文件树
      fileMenuList () {
        getFileMenuTree({applyId: this.applyId, categoryList: ['internal_request_loan_attachment', 'post_loan_upload'], showFaultFile: false}).then((res) => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            data.forEach((item) => {
              if (item.dictKey === 'internal_request_loan_attachment') this.requestLoanAttachmentKinds = item.list
              if (item.dictKey === 'post_loan_upload') this.postLoanUploadKinds = item.list
            })
          }
        }).catch((error) => { console.log(error) })
      },
      // 获取提报文件资料
      getTbFiles () {
        filesGet({applyId: this.applyId, showFaultFile: true}).then((res) => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            this.applyCollectRequiredFileList = data.requiredFileCategoryListVos
            this.applyCollectNotRequiredFileList = data.notRequiredFileCategoryListVos
          }
        }).catch((error) => { console.log(error) })
      },
      // 获取文件
      getFilesData () {
        let data = {applyId: this.applyId, categoryList: ['internal_request_loan_attachment', 'post_loan_upload', 'internal_audit_file'], showFaultFile: true}
        filesListGet(data).then((res) => {
          if (res.data.respCode === '1000') {
            let applyMoneyData = res.data.body[0]
            let afterLendData = res.data.body[1]
            let internalAuditData = res.data.body[2]
            this.requestLoanAttachmentRequiredFileList = applyMoneyData.requiredFileCategoryListVos
            this.requestLoanAttachmentNotRequiredFileList = applyMoneyData.notRequiredFileCategoryListVos
            this.postLoanUpRequiredFileList = afterLendData.requiredFileCategoryListVos
            this.postLoanUpNotRequiredFileLis = afterLendData.notRequiredFileCategoryListVos
            this.internalAuditRequiredFileList = internalAuditData.requiredFileCategoryListVos
          }
        }).catch((error) => { console.log(error) })
      },
      // 保存文件
      saveUploadFilesHandle () {
        this.isSaveLoading = true
        let apiParams = [
          {applyId: this.applyId, requiredFileCategoryListVos: this.requestLoanAttachmentRequiredFileList, notRequiredFileCategoryListVos: this.requestLoanAttachmentNotRequiredFileList},
          {applyId: this.applyId, requiredFileCategoryListVos: this.postLoanUpRequiredFileList, notRequiredFileCategoryListVos: this.postLoanUpNotRequiredFileLis},
          {applyId: this.applyId, requiredFileCategoryListVos: this.applyCollectRequiredFileList, notRequiredFileCategoryListVos: this.applyCollectNotRequiredFileList},
          {applyId: this.applyId, requiredFileCategoryListVos: this.internalAuditRequiredFileList, notRequiredFileCategoryListVos: []},
        ]
        saveUploadFilesList(apiParams).then((res) => {
          if (res.data.respCode === '1000') {
            this.isSaveLoading = false
            this.$message.success('保存成功')
            this.getFilesData()
          } else {
            this.isSaveLoading = false
          }
        }).catch((err) => {
          this.isSaveLoading = false
          console.log(err)
        })
      },
      /* // 删除回调
      deleteFileApiCallback (data) {
        let copyImgItem = JSON.parse(JSON.stringify(data.imgItem))
        copyImgItem.relatedId = this.applyId
        copyImgItem.relatedGroup = 'request_loan_attachment'
        copyImgItem.fileCategory = 'fault_file_request_loan'
        let forEachData = []
        let faultFileExists = false
        if (data.isRequired) {
          forEachData = this.requiredFilesList
        } else {
          forEachData = this.notRequiredFilesList
        }
        // 删除
        forEachData.forEach(item => {
          item.pictureListVOList.forEach(item => {
            if (item.dictKey === data.imgItem.fileCategory) {
              item.fileRecordVOList.splice(data.index, 1)
            }
          })
        })
        // 添加
        if (this.notRequiredFilesList.length) {
          this.notRequiredFilesList.forEach(item => {
            item.pictureListVOList.forEach(k => {
              if (k.dictKey === 'fault_file_request_loan') faultFileExists = !faultFileExists
            })
          })
          if (faultFileExists) {
            this.notRequiredFilesList.forEach(item => {
              item.pictureListVOList.forEach(k => {
                if (k.dictKey === 'fault_file_request_loan') k.fileRecordVOList.push({...copyImgItem})
              })
            })
          } else {
            this.notRequiredFilesList[0].pictureListVOList.push({
              dictKey: 'fault_file_request_loan',
              fileRecordVOList: [{...copyImgItem}],
              name: '请款的误传文件'
            })
          }
        } else {
          this.notRequiredFilesList.push(
            {categoryDesc: '请款附件',
              dictCategory: 'request_loan_attachment',
              pictureListVOList: [{
                dictKey: 'fault_file_request_loan',
                fileRecordVOList: [{...copyImgItem}],
                name: '请款的误传文件'}]
            }
          )
        }
      }, */
      // 删除文件
      deleteFileItemHandle (data) {
        let apiData = JSON.parse(JSON.stringify(data.imgItem))
        console.log(data.applyNode)
        apiData.relatedId = this.applyId
        apiData.relatedGroup = data.applyNode
        switch (data.applyNode) {
        case 'post_loan_upload':
          apiData.fileCategory = 'fault_file_post_loan'
          this.requiredFilesList = this.postLoanUpRequiredFileList
          this.notRequiredFilesList = this.postLoanUpNotRequiredFileLis
          break
        case 'request_loan_attachment':
          apiData.fileCategory = 'fault_file_request_loan'
          this.requiredFilesList = this.requestLoanAttachmentRequiredFileList
          this.notRequiredFilesList = this.requestLoanAttachmentNotRequiredFileList
          break
        case 'identity_file':
          apiData.fileCategory = 'identity_file'
          this.requiredFilesList = this.applyCollectRequiredFileList
          this.notRequiredFilesList = this.applyCollectNotRequiredFileList
          break
        case 'internal_audit_file':
          apiData.fileCategory = 'internal_audit_file'
          this.requiredFilesList = this.internalAuditRequiredFileList
          this.notRequiredFilesList = []
          break
        }

        deleteImgItem(apiData).then((res) => {
          if (res.data.respCode === '1000') {
            const _vue = this
            const deleteCbParam = {
              _vue,
              relatedId: this.applyId,
              fileData: data,
              dictCategory: apiData.relatedGroup,
              dictKey: apiData.fileCategory,
            }

            deleteFileApiCallback(deleteCbParam)
            this.$message.success('删除成功')
          }
        }).catch((err) => { console.log(err) })
      },
      // 文件预览
      showPicViewHandle (data) {
        this.showPicView = true
        this.imgItemList = data.imgItemList
        this.clickItem = data.clickItem
      },
      // 关闭文件预览
      closePicViewHandle () {
        this.showPicView = false
      },
      // 替换非必传文件
      changeUnNecessaryUploadDataHandle (data) {
        if (data.applyNode === 'request_loan_attachment') {
          this.requestLoanAttachmentNotRequiredFileList = data.notRequiredFilesList
        } else if (data.applyNode === 'post_loan_upload') {
          this.postLoanUpNotRequiredFileLis = data.notRequiredFilesList
        } else if (data.applyNode === 'identity_file') {
          this.applyCollectNotRequiredFileList = data.notRequiredFilesList
        }
      },
      // 替换必传文件
      changeNecessaryUploadDataHandle (data) {
        if (data.applyNode === 'request_loan_attachment') {
          this.requestLoanAttachmentRequiredFileList = data.requiredFilesList
        } else if (data.applyNode === 'post_loan_upload') {
          this.postLoanUpRequiredFileList = data.requiredFilesList
        } else if (data.applyNode === 'identity_file') {
          this.applyCollectRequiredFileList = data.requiredFilesList
        } else if (data.applyNode === 'internal_audit_file') {
          this.internalAuditRequiredFileList = data.requiredFilesList
        }
      },
      // 自适应高度
      autoHeight () {
        let clientHeight = document.documentElement.clientHeight
        this.$refs['applyTbUploadWrap'].style.height = (clientHeight - 55) + 'px'
      },
    },
  }
</script>

<style lang="scss" scoped>
  .apply-tb-upload-wrap{
    overflow-y: auto;
  }
  .pic-view-wrap{
    position: absolute;
    top: 0;
    left: 50%;
    background: #fff;
    z-index: 1000;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.3);
  }
</style>
