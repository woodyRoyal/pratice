<template>
  <div class="carFinancialWrap" ref="carFinancialWrap">
    <div>
      <!-- 融资费用及明细 -->
      <div>
        <div class="formModuleTitle"><span>融资费用及明细</span></div>
        <el-form size="mini" label-position="top" :model="financialData">
          <el-row :gutter="rowGutter">
            <el-col :span='colSpan' v-if="financingParams.car_price && financingParams.car_price.financing">
              <el-form-item label="车款">
                <el-input disabled v-model="financialData.carPrice"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='colSpan' v-if="financingParams.purchase_tax && financingParams.purchase_tax.financing">
              <el-form-item label="购置税">
                <el-input disabled v-model="financialData.purchaseTax"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='colSpan' v-if="financingParams.insurance && financingParams.insurance.financing">
              <el-form-item label="保险">
                <el-input disabled v-model="financialData.insurance"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter">
            <el-col :span='colSpan' v-if="financingParams.gps && financingParams.gps.financing">
              <el-form-item label="GPS价格">
                <el-input disabled v-model="financialData.gps"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='colSpan' v-if="financingParams.financing_fee && financingParams.financing_fee.financing">
              <el-form-item label="车融服务费">
                <el-input disabled v-model="financialData.financingFee"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='colSpan' v-if="financingParams.theft_protection && financingParams.theft_protection.financing">
              <el-form-item label="盗抢服务">
                <el-input disabled v-model="financialData.theftProtection"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <!-- 融资信息 -->
      <div class="financialInfo mt10">
        <div class="formModuleTitle"><span>融资信息</span></div>
        <el-form size="mini" label-position="top" :model="financialData">
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="GPS个数">
                <el-select v-model="financialData.gpsQuantity" disabled>
                  <el-option :label="0" :value="0" ></el-option>
                  <el-option :label="1" :value="1" ></el-option>
                  <el-option :label="2" :value="2" ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="融资期限">
                <el-select v-model="financialData.term" disabled>
                  <el-option v-for="item in termList" :key="item.term" :label="item.term" :value="item.term"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="还款频率">
                <el-select disabled v-model="financialData.repaymentFrequency">
                  <el-option v-for="item in repayment_frequencyList" :key="item.dictValue" :value="item.dictValue" :label="item.dictName"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="还款方式">
                <el-select disabled v-model="financialData.repaymentMethod">
                  <el-option v-for="item in repayment_methodList" :key="item.dictValue" :value="item.dictValue" :label="item.dictName"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="利率类型">
                <el-select disabled v-model="financialData.interestMethod">
                  <el-option v-for="item in interest_rate_typeList" :key="item.value" :value="item.value" :label="item.name"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="操作类型">
                <el-select disabled v-model="financialData.operationType">
                  <el-option v-for="item in operateTypeList" :key="item.dictValue" :value="item.dictValue" :label="item.dictName"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="首付比例（%）">
                <el-input v-model="financialData.downPaymentRatio" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="首付金额">
                <el-input disabled v-model="financialData.downPaymentAmt"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="手续费率（%）">
                <el-input disabled v-model="financialData.feeRatio"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="手续费">
                <el-input disabled v-model="financialData.feeAmount"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="保证金比例（%）">
                <el-input disabled v-model="financialData.depositRatio"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="保证金金额">
                <el-input disabled v-model="financialData.depositAmount"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="保证金是否冲抵">
                <el-select disabled v-model="financialData.depositChargeAgainst">
                  <el-option v-for="item in deposit_charge_againstList" :key="item.value" :value="item.value" :label="item.name"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="融资总额">
                <el-input disabled v-model="financialData.amount"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="放款金额">
                <el-input disabled v-model="financialData.makeloansAmount"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="月供租金">
                <el-input disabled v-model="financialData.repaymentMonthy"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <!-- 车辆信息 -->
      <div class="mt10">
        <div class="formModuleTitle"><span>车辆信息</span></div>
        <el-form size="mini" label-position="top" :model="vehicleData">
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="制造商">
                <el-input disabled v-model="vehicleData.fldMake"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="品牌">
                <el-input disabled v-model="vehicleData.fldModel"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="车系">
                <el-input disabled v-model="vehicleData.fldSerial"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="车型">
                <el-input disabled v-model="vehicleData.fldTrim"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="车辆颜色">
                <el-input disabled v-model="vehicleData.carColor"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="车辆销售价">
                <el-input disabled v-model="vehicleData.salePriceStr"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="新车指导价">
                <el-input disabled v-model="vehicleData.fldPriceStr"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="购车用途">
                <el-select disabled v-model="vehicleData.purpose">
                  <el-option v-for="item in purposeList" :key='item.dictValue' :value="item.dictValue" :label="item.dictName"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="达示指导价">
                <el-input disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="上牌或抵押省份-城市">
                <el-cascader disabled :options="provinceCityList" v-model="carProvinceCity" :props="props"></el-cascader>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan"></el-col>
            <el-col :span="colSpan"></el-col>
          </el-row>
        </el-form>
      </div>
      <!-- 车辆参数（二手车） -->
      <div v-if="vehicleType === 1" class="mt10">
        <div class="formModuleTitle"><span>车辆参数</span></div>
        <el-form size="mini" label-position="top" :model="oldVehicleData">
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="订单编号">
                <el-input disabled v-model="oldVehicleData.orderId"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="品牌车型">
                <el-input disabled v-model="oldVehicleData.modelBrand"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="车架号（VIN码）">
                <el-input disabled v-model="oldVehicleData.vin"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="二手车出厂日期">
                <el-date-picker v-model="oldVehicleData.factoryDate" type="date" placeholder="选择日期" value-format="yyyy-MM-dd HH:mm:ss" disabled></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="二手车初登日期">
                <el-date-picker v-model="oldVehicleData.initialDate" type="date" placeholder="选择日期" value-format="yyyy-MM-dd HH:mm:ss" disabled></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="二手车公里数">
                <el-input disabled v-model="oldVehicleData.kilometerNumber"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="二手车评估金额">
                <el-input disabled v-model="oldVehicleData.assessmentAmount"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="附件资料"></el-form-item>
            </el-col>
            <el-col :span="colSpan"></el-col>
          </el-row>
        </el-form>
      </div>
      <!-- 交易信息（二手车） -->
      <div v-if="vehicleType === 1" class="mt10">
        <div class="formModuleTitle"><span>交易信息</span></div>
        <el-form size="mini" label-position="top">
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="卖家类型">
                <el-select disabled v-model="vehicleData.tradeType">
                  <el-option label="个人" :value="0"></el-option>
                  <el-option label="企业" :value="1"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="卖方名称">
                <el-input disabled v-model="vehicleData.salesName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="卖方手机号码">
                <el-input disabled v-model="vehicleData.slaesPhone"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="上任车主姓名">
                <el-input disabled v-model="vehicleData.carOwnerName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="身份证号码">
                <el-input disabled v-model="vehicleData.carOwnerId"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter" v-if="vehicleData.tradeType === 1">
            <el-col :span="colSpan">
              <el-form-item label="证件类型">
                <el-select v-model="vehicleData.cardType" placeholder="请选择证件类型" >
                  <el-option :label="item.dictName"  :value="item.dictValue" v-for="item in tradeCardTypeList" :key="item.dictValue"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="证件号码">
                <el-input disabled v-model="vehicleData.cardNum"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <!-- 渠道信息 -->
      <div class="mt10">
        <div class="formModuleTitle"><span>渠道信息</span></div>
        <el-form size="mini" label-position="top">
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="是否外采">
                <el-select disabled v-model="vehicleData.externalChannel">
                  <el-option label="是" :value="0"></el-option>
                  <el-option label="否" :value="1"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="车辆渠道名称（供应商）">
                <el-select v-model="vehicleData.channelId" disabled>
                  <el-option v-for="item in supplies" :key="item.channelId" :label="item.channelName" :value="item.channelId"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="提报店名">
                <el-input disabled v-model="supplyData.fullName"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="销售经理">
                <el-input disabled v-model="supplyData.regionalManager"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="所属大区">
                <el-input disabled v-model="supplyData.largeArea"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="colSpan">
              <el-form-item label="所属区域">
                <el-input disabled v-model="supplyData.belongArea"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <!-- 挂靠信息 -->
      <div class="mt10" v-if="applyType !== 1">
        <div class="formModuleTitle"><span>挂靠信息</span></div>
        <el-form size="mini" label-position="top">
          <el-row :gutter="rowGutter">
            <el-col :span="colSpan">
              <el-form-item label="是否挂靠">
                <el-select disabled v-model="attachedVo.attached">
                  <el-option label="是" :value="1"></el-option>
                  <el-option label="否" :value="0"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
    </div>
    <approve></approve>
  </div>
</template>
<script>
  import {financialDict, financialInfo, vehicleInfo} from '../../../api/formInfo.js'
  import {mapGetters} from 'vuex'
  import {getSupplierList} from '../../../api/applyProgress.js'
  import approve from '../../components/frontApproveInfo'
  export default {
    data () {
      return {
        colSpan: 8,
        rowGutter: 10,
        // 省份城市配置
        props: {
          value: 'key',
          label: 'name',
          children: 'list'
        },
        proDate: null,
        registerDate: null,
        provinceCity: null,
        // 融资信息数据
        financialData: {
          carPrice: null,
          purchaseTax: null,
          insurance: null,
          gps: null,
          financingFee: null,
          theftProtection: null,
          gpsQuantity: null,
          term: null,
          repaymentFrequency: null,
          repaymentMethod: null,
          receiptType: null,
          interestMethod: null,
          operationType: null,
          downPaymentRatio: null,
          downPaymentAmt: null,
          feeRatio: null,
          feeAmount: null,
          depositRatio: null,
          depositAmount: null,
          depositChargeAgainst: null,
          amount: null,
          makeloansAmount: null,
          repaymentMonthy: null
        },
        vehicleType: null, // 车辆类型
        carProvinceCity: [], // 上牌或抵押城市
        vehicleData: {
          fldMake: null,
          fldModel: null,
          fldSerial: null,
          fldTrim: null,
          carColor: null,
          province: null,
          salePriceStr: null,
          fldPriceStr: null,
          purpose: null,
          city: null,
          tradeType: null,
          salesName: null,
          slaesPhone: null,
          carOwnerName: null,
          carOwnerId: null,
          cardType: null,
          cardNum: null,
          externalChannel: null,
          channelId: null
        }, // 车辆信息数据（新车）
        oldVehicleData: {
          orderId: null,
          modelBrand: null,
          vin: null,
          factoryDate: null,
          initialDate: null,
          kilometerNumber: null,
          assessmentAmount: null
        }, // 车辆信息旧车
        applyType: 1,
        attachedVo: {attached: 0}, // 挂靠信息
        supplyData: {
          fullName: null,
          regionalManager: null,
          largeArea: null,
          belongArea: null
        }, // 渠道信息
        termList: [], // 融资期限
        repayment_frequencyList: [], // 还款频率
        repayment_methodList: [], // 还款方式
        operateTypeList: [], // 操作类型
        deposit_charge_againstList: [], // 保证金是否冲抵
        interest_rate_typeList: [], // 利率类型
        financingParams: {}, // 融资明细
        aimOfVehicle: [], // 购车目的下拉
        supplies: [], // 渠道下拉
        clientHeight: null
      }
    },
    components: {
      approve
    },
    created () {
      this.$store.dispatch('getAreaTree')
    },
    mounted () {
      // 融资明细字典
      this.getDictionary(this.applyId)
      // 融资信息数据
      this.getFinancialInfo(this.applyId)
      // 车辆信息
      this.getVehicleInfo(this.applyId)
      this.autoHeight()
      window.addEventListener('resize', this.autoHeight)
    },
    destroyed () {
      window.removeEventListener('resize', this.autoHeight)
    },
    computed: {
      ...mapGetters(['applyId', 'provinceCityList', 'termDisabled', 'downPaymentRatioDisabled', 'purposeList', 'tradeCardTypeList'])
    },
    methods: {
      // 字典
      getDictionary (val) {
        financialDict({applyId: val}).then(res => {
          if (res.data.respCode === '1000') {
            const {apr, repaymentFrequency, repaymentMethod, operateType, productParams, financingParams} = res.data.body
            this.termList = apr // 融资期限
            this.repayment_frequencyList = repaymentFrequency // 还款频率
            this.repayment_methodList = repaymentMethod // 还款方式
            this.operateTypeList = operateType // 还款方式
            this.deposit_charge_againstList = productParams.deposit_charge_against // 保证金是否冲抵
            this.interest_rate_typeList = productParams.interest_rate_type // 利率类型
            this.financingParams = financingParams
          }
        }).catch(error => { console.log(error) })
      },
      // 融资信息数据获取
      getFinancialInfo (val) {
        financialInfo({applyId: val}).then(res => {
          if (res.data.respCode === '1000') this.financialData = res.data.body
        }).catch(error => { console.log(error) })
      },
      // 车辆信息数据获取
      getVehicleInfo (val) {
        vehicleInfo({applyId: val}).then(res => {
          if (res.data.respCode === '1000') {
            const {applyType, vehicleType, carVO, channelDealerVO, carParamVO, attached} = res.data.body
            this.vehicleType = vehicleType
            this.vehicleData = carVO
            this.supplyData = channelDealerVO
            if (carVO.province && carVO.city) this.carProvinceCity = [carVO.province, carVO.city]
            if (this.vehicleType === 1) this.oldVehicleData = carParamVO
            this.applyType = applyType
            this.attachedVo.attached = attached || 0
            getSupplierList({purchaseType: this.vehicleData.externalChannel, channelId: this.vehicleData.channelId}).then(res => {
              if (res.data.respCode === '1000') this.supplies = res.data.body
            }).catch(error => { console.log(error) })
          }
        }).catch(error => { console.log(error) })
      },
      autoHeight () {
        this.clientHeight = document.documentElement.clientHeight
        this.$refs['carFinancialWrap'].style.height = (this.clientHeight - 55) + 'px'
      }
    }
}
</script>
<style lang="scss" scoped>
  .carFinancialWrap{
    overflow-x: hidden;
    overflow-y: auto;
  }
</style>
