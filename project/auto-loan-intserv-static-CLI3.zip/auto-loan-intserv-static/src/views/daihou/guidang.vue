<template>
  <div class="guidangWrap">
    <div ref="guidangFormWrap"
         class="guidangFormWrap">
      <el-form size="small"
               label-position="left">
        <el-row :gutter="5">
          <el-col :span="8">
            <el-form-item label="申请编号"
                          :label-width="labelWidth">
              <el-input v-model="queryData.applyId"
                        maxlength="8"
                        placeholder="输入申请编号"
                        @blur="checkApplyId(queryData.applyId, 'applyId')"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="申请编号(老)"
                          label-width="110px">
              <el-input v-model="queryData.oldApplyNo"
                        maxlength="8"
                        placeholder="输入申请编号"
                        @blur="checkApplyId(queryData.oldApplyNo, 'oldApplyNo',7)"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="客户名称"
                          :label-width="labelWidth">
              <el-input v-model="queryData.name"
                        maxlength="20"
                        placeholder="输入客户姓名"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="5">
          <el-col :span="8">
            <el-form-item label="放款日期（起）"
                          label-width="110px">
              <el-date-picker v-model="queryData.loanDateStart"
                              type="datetime"
                              placeholder="选择日期"
                              value-format="yyyy-MM-dd HH:mm:ss"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="放款日期（终）"
                          label-width="110px">
              <el-date-picker v-model="queryData.loanDateEnd"
                              type="datetime"
                              placeholder="选择日期"
                              value-format="yyyy-MM-dd HH:mm:ss"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="SP店面"
                          :label-width="labelWidth">
              <el-input v-model="queryData.dealerName"
                        maxlength="30"
                        placeholder="输入SP店面"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="5">
          <el-col :span="8">
            <el-form-item label="是否归档"
                          :label-width="labelWidth">
              <el-select v-model="queryData.filed">
                <el-option v-for="item in isOkList"
                           :key="item.value"
                           :label="item.name"
                           :value="item.value"></el-option>
              </el-select>
            </el-form-item>
          </el-col>

          <el-col :span="8">
            <el-form-item label="资方信息"
                          :label-width="labelWidth">
              <el-select v-model="queryData.capital">
                <el-option v-for="item in capitalNameList"
                           :key="item.value"
                           :label="item.name"
                           :value="item.value"></el-option>
              </el-select>
            </el-form-item>
          </el-col>

          <el-col :span="8">
            <el-form-item label="是否结清"
                          :label-width="labelWidth">
              <el-select v-model="queryData.cleared">
                <el-option v-for="item in isOkList"
                           :key="item.value"
                           :label="item.name"
                           :value="item.value"></el-option>
              </el-select>
            </el-form-item>
          </el-col>

          <el-col :span="8">
            <el-form-item>
              <el-button type="primary"
                         size="mini"
                         @click="resetQuery">
                重置
              </el-button>
              <el-button type="primary"
                         size="mini"
                         @click="getGuidangList">
                查询
              </el-button>
              <el-button type="primary"
                         size="mini"
                         :loading="exportLoading"
                         @click="downLoadTable">
                {{ this.exportLoading ? '下载中' : '下载' }}
              </el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <!--<el-row :gutter="5">-->
        <!--<el-col :span="8">-->
        <!--<el-form-item label="资方信息">-->
        <!--<el-select>-->
        <!--<el-option value="1" label="新网银行"></el-option>-->
        <!--<el-option value="2" label="众邦银行"></el-option>-->
        <!--<el-option value="3" label="2345自有资金"></el-option>-->
        <!--</el-select>-->
        <!--</el-form-item>-->
        <!--</el-col>-->
        <!--<el-col :span="8">-->
        <!--<el-form-item label="资方贷1审核结果">-->
        <!--<el-select>-->
        <!--<el-option value="1" label="新网银行"></el-option>-->
        <!--<el-option value="2" label="众邦银行"></el-option>-->
        <!--<el-option value="3" label="2345自有资金"></el-option>-->
        <!--</el-select>-->
        <!--</el-form-item>-->
        <!--</el-col>-->
        <!--<el-col :span="8">-->
        <!--<el-form-item label="资方贷2审核结果">-->
        <!--<el-select>-->
        <!--<el-option value="1" label="新网银行"></el-option>-->
        <!--<el-option value="2" label="众邦银行"></el-option>-->
        <!--<el-option value="3" label="2345自有资金"></el-option>-->
        <!--</el-select>-->
        <!--</el-form-item>-->
        <!--</el-col>-->
        <!--</el-row>-->
      </el-form>
    </div>
    <el-table :data="tableData"
              border
              :max-height="tableMaxHeight">
      <el-table-column label="序号"
                       type="index"></el-table-column>
      <el-table-column label="申请编号(老)">
        <template slot-scope="scope">
          {{ scope.row.oldApplyNo || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="申请编号">
        <template slot-scope="scope">
          {{ scope.row.applyId || '/' }}
          <el-tag v-if="scope.row.specialPermit"
                  type="warning"
                  size="mini">
            特批
          </el-tag>
          <el-tag v-if="scope.row.reconsideration"
                  type="warning"
                  size="mini">
            复议
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="放款天数"
                       min-width="50px">
        <template slot-scope="scope">
          {{ scope.row.loanDays || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="放款日期"
                       min-width="77px">
        <template slot-scope="scope">
          {{ scope.row.loanDate || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="是否归档">
        <template slot-scope="scope">
          {{ scope.row.filed || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="区域">
        <template slot-scope="scope">
          {{ scope.row.regionName || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="客户姓名">
        <template slot-scope="scope">
          {{ scope.row.name || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="申请类型"
                       min-width="50px">
        <template slot-scope="scope">
          {{ APPLYTYPES[scope.row.applyType] || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="车牌号">
        <template slot-scope="scope">
          {{ scope.row.carLicencePlate || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="使用性质">
        <template slot-scope="scope">
          {{ scope.row.vehicleProperty || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="储存备注">
        <template slot-scope="scope">
          {{ scope.row.remark || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="是否被退回过">
        <template slot-scope="scope">
          {{ scope.row.sendBack || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="最近一次被退回的原因">
        <template slot-scope="scope">
          {{ scope.row.sendBackReason || '/' }}
        </template>
      </el-table-column>
      <el-table-column props="cleared"
                       label="是否结清">
        <template slot-scope="scope">
          {{ scope.row.cleared || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="SP店面">
        <template slot-scope="scope">
          {{ scope.row.dealerName || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="车架号">
        <template slot-scope="scope">
          {{ scope.row.carVin || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="资方信息">
        <template slot-scope="scope">
          {{ scope.row.capitalName || '/' }}
        </template>
      </el-table-column>
      <el-table-column label="资方贷后审核详情"
                       fixed="right">
        <template slot-scope="scope">
          <el-button v-if="scope.row.capitalName !== '2345自有资金' && scope.row.capitalName !== ''"
                     type="primary"
                     size="mini"
                     @click="capitalRiskDetailInfo(scope.row)">
            查看详情
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      :current-page="page.pageNo"
      :page-sizes="page.pageSizeArr"
      :page-size="page.pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="page.total"
      class="tablePage"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange">
    </el-pagination>
    <!--资方审核查看详情-->
    <el-dialog :visible.sync="capitalRiskResDialogVisible"
               width="600px">
      <div class="capital-res-module">
        <div v-if="isShowNewNetsModule && capital == 'ex-xw'">
          <!--新网-->
          <XwAfterLoanApproveRes
            :is-show-new-nets-module="isShowNewNetsModule"
            :new-nets-info="newNetsInfo"
            @filesToNewNetsHandle="filesToNewNets"
            @queryXWApprove="getNewNetsDaiHouApproveHandle"
            @backBuyHandle="backBuy"
          >
          </XwAfterLoanApproveRes>
        </div>

        <!--众邦-->
        <ul v-if="capital == 'ex-zb' && isShowZBModule">
          <li>
            <p>众邦请款资料审核结果：</p>
            <el-tag size="small">
              {{ zbInfo.auditStatus === 4 ? '' : zbAuditStatusDict[zbInfo.auditStatus] }}
            </el-tag>
          </li>
          <li>
            <p>拒绝/补件原因码及原因描述：</p>
            <p>{{ zbInfo.auditStatus === 4 ? '' : zbInfo.resultMessage }}</p>
          </li>
          <li class="nets-btns">
            <el-button type="primary"
                       size="mini"
                       @click="filesToZb">
              请款资料提交众邦
            </el-button>
            <el-button type="primary"
                       size="mini"
                       @click="getZbDaiHouApproveHandle">
              查询众邦审核接口
            </el-button>
          </li>
        </ul>
        <div v-if="!isShowNewNetsModule && !isShowZBModule"
             style="text-align: center; font-size: 16px">
          暂无信息
        </div>
      </div>
    </el-dialog>
    <!--回购dialog-->
    <el-dialog title="重要提示"
               :visible.sync="buyBackDialogVisible">
      <p style="text-align: center">
        请确认是否需要操作回购
      </p>
      <el-form ref="buyBackData"
               :model="buyBackData"
               :rules="buyBackDataRule">
        <el-form-item label="备注"
                      prop="buyBackReason">
          <el-input v-model="buyBackData.buyBackReason"
                    type="textarea"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button size="mini"
                   @click="buyBackDialogVisible = false">
          取 消
        </el-button>
        <el-button size="mini"
                   type="primary"
                   @click="confirmBuyBack">
          确 定
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import XwAfterLoanApproveRes from '../components/xwAfterLoanApproveStatus'
  import {APPLYTYPES, checkApplyId} from '../../utils/constant.js'
  // guidangList2
  import {areaNameList, clickDownLoad, reportDownloadPolling} from '../../api/daihou'
  import { guidangList2 } from '../../api/baobiao'
  import {newNetsDaiHouApproveHandle, zbDaiHouApproveHandle, filesUploadNewNets, filesUploadZb, buyBackFromNewNets} from '../../api/caseHandle.js'
  const qs = require('qs')
  export default {
    components: { XwAfterLoanApproveRes },
    data () {
      return {
        APPLYTYPES,
        checkApplyId,
        rowApplyId: null, // 点击项的id
        labelWidth: '70px',
        areaNames: [],
        queryData: {
          applyId: '',
          oldApplyNo: '',
          name: '',
          loanDateStart: '',
          loanDateEnd: '',
          dealerName: '',
          filed: '',
          capital: '',
          cleared: '',
        },
        capitalNameList: [{
          name: '新网银行',
          value: 'EX-XW',
        }, {
          name: '众邦银行',
          value: 'EX-ZB',
        }, {
          name: '2345自有资金',
          value: '2345',
        }],
        isOkList: [{
          name: '是',
          value: 1,
        }, {
          name: '否',
          value: 0,
        }],
        page: {
          pageNo: 1,
          pageSize: 10,
          pageSizeArr: [10, 20, 30, 40],
          total: 0,
        },
        tableData: [],
        exportTimer: null,
        exportLoading: false,
        tableMaxHeight: null,
        capital: '',
        isShowNewNetsModule: 0, // 是否显示新网审核结果展示组件
        newNetsInfo: {
          task1StatusDesc: '',
          task1ApprovalDesc: '',
          task1Code: '',
          task1Desc: '',
          task2StatusDesc: '',
          task2ApprovalDesc: '',
          task2Code: '',
          task2Desc: '',
        }, // 新网审核详情数据
        isShowZBModule: 0, // 是否显示众邦审核结果展示组件
        zbInfo: {
          auditStatus: null,
          resultMessage: '',
        }, // 众邦审核详情数据
        zbAuditStatusDict: {
          0: '拒绝',
          1: '通过',
          2: '处理中',
          3: '异常',
          // 4: '无',
          5: '退回',
        }, // 众邦状态翻译字典
        capitalRiskResDialogVisible: false, // 资方审核详情弹窗
        buyBackDialogVisible: false, // 回购弹窗
        buyBackData: {
          applyId: null,
          buyBackReason: '',
        }, // 回购数据
        buyBackDataRule: {
          buyBackReason: [{required: true, message: '内容不得为空', trigger: 'blur'}],
        },
      }
    },
    computed: {
      ...mapGetters(['vehiclePropertyDict']),
    },
    mounted () {
      this.getAreaNameList()
      this.getGuidangList()
      this.calculateTableMaxHeight()
      window.addEventListener('resize', this.calculateTableMaxHeight)
    },
    destroyed () {
      window.removeEventListener('resize', this.calculateTableMaxHeight)
    },
    methods: {
      // 区域名称
      getAreaNameList () {
        areaNameList().then((res) => {
          if (res.data.respCode === '1000') this.areaNames = res.data.body
        }).catch((error) => { console.log(error) })
      },
      // 列表数据
      getGuidangList () {
        this.queryData.pageNo = this.page.pageNo
        this.queryData.pageSize = this.page.pageSize
        return new Promise((resolve, reject) => {
          guidangList2(this.queryData).then((res) => {
            if (res.data.respCode === '1000') {
              const {list, total} = res.data.body
              this.tableData = list
              this.page.total = total
              resolve(1)
            } else {
              resolve(0)
            }
          }).catch((error) => {
            console.log(error)
            reject(error)
          })
        })
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.getGuidangList()
      },
      handleCurrentChange (val) {
        this.page.pageNo = val
        this.getGuidangList()
      },
      resetQuery () {
        this.queryData = {
          applyId: '',
          oldApplyNo: '',
          name: '',
          contractNo: '',
          loanDateStart: '',
          loanDateEnd: '',
          dealerName: '',
          areaNames: '',
          loanDays: '',
        }
        this.getGuidangList()
        this.exportLoading = false
      },
      // 文件导出
      downLoadTable () {
        if (this.exportLoading) {
          this.$message.warning('文件正在生成')
          return false
        } else {
          this.exportLoading = true // 开启loading
          this.getGuidangList().then((res) => {
            if (res && this.tableData.length !== 0) {
              // 点击导出
              clickDownLoad(this.queryData).then((res) => {
                if (res.data.respCode === '1000') {
                  let exportSerialNo = res.data.body.serialNo
                  clearInterval(this.exportTimer)
                  // 接口轮询
                  this.exportTimer = setInterval(() => {
                    reportDownloadPolling('report_postloan_file_info', exportSerialNo).then((res) => {
                      // 不管成功或失败，关闭loading
                      this.exportLoading = false
                      if (res.data.respCode === '1000') {
                        let data = res.data.body
                        if (data.status) {
                          // 生成成功
                          clearInterval(this.exportTimer)
                          // 导出
                          window.location.href = process.env.VUE_APP_BASE_API + '/download/export?' + qs.stringify({filename: data.filename, storePath: data.storePath})
                        }
                      } else {
                        clearInterval(this.exportTimer)
                        // 生成失败
                        this.$message.warning('文件生成失败')
                      }
                    }).catch((error) => { console.log(error) })
                  }, 1000)
                } else {
                  this.exportLoading = false // 关闭loading
                }
              }).catch((error) => {
                this.exportLoading = false // 关闭loading
                console.log(error)
              })
            } else {
              this.exportLoading = false // 关闭loading
              this.$message.warning('该筛选条件下无数据可下载')
            }
          }).catch((error) => {
            this.exportLoading = false // 关闭loading
            console.log(error)
          })
        }
      },
      calculateTableMaxHeight () {
        let clientH = document.documentElement.clientHeight || document.body.clientHeight
        let formHeight = this.$refs.guidangFormWrap.offsetHeight
        this.tableMaxHeight = (clientH - (formHeight + 40 + 36 + 22))
      },
      // 资方审核查看详情
      capitalRiskDetailInfo (row) {
        const {id, capitalName} = row
        this.capitalRiskResDialogVisible = true
        this.rowApplyId = id
        if (capitalName === '新网银行') {
          this.capital = 'ex-xw'
          this.getNewNetsDaiHouApproveHandle()
        } else {
          this.capital = 'ex-zb'
          this.getZbDaiHouApproveHandle(false) // 非强制刷新
        }
      },
      // 新网审批结果展示
      getNewNetsDaiHouApproveHandle () {
        newNetsDaiHouApproveHandle(this.rowApplyId).then((res) => {
          if (res.data.respCode === '1000') {
            this.zbInfo = {}
            this.newNetsInfo = res.data.body || {}
            this.isShowNewNetsModule = JSON.stringify(this.newNetsInfo) !== '{}' ? 1 : 0
          } else {
            this.newNetsInfo = {}
            this.isShowNewNetsModule = JSON.stringify(this.newNetsInfo) !== '{}' ? 1 : 0
          }
        })
      },
      // 众邦审批结果展示
      getZbDaiHouApproveHandle (forceUpdate) {
        const apiData = {applyId: this.rowApplyId}
        apiData.forceUpdate = typeof forceUpdate !== 'boolean'
        zbDaiHouApproveHandle(apiData).then((res) => {
          if (res.data.respCode === '1000') {
            this.newNetsInfo = {}
            this.zbInfo = res.data.body || {}
            this.isShowZBModule = JSON.stringify(this.zbInfo) !== '{}' ? 1 : 0
            // console.log(this.isShowZBModule, this.capital)
          } else {
            this.zbInfo = {}
            this.isShowZBModule = JSON.stringify(this.zbInfo) !== '{}' ? 1 : 0
          }
        }).catch((err) => { console.log(err) })
      },
      // 贷后资料提交新网
      filesToNewNets () {
        this.$confirm('<p style="color: red; text-align: left">请确认已按需求更新材料，为避免不合格被回购，请确认后操作</p>', '贷后资料推送', {
          cancelButtonText: '取消',
          confirmButtonText: '确认推送',
          dangerouslyUseHTMLString: true,
          center: true,
        }).then(() => {
          filesUploadNewNets(this.rowApplyId).then((res) => {
            if (res.data.respCode === '1000') this.$message.success('操作成功')
          })
        }).catch(() => {})
      },
      // 请款资料提交众邦
      filesToZb () {
        filesUploadZb(this.rowApplyId).then((res) => {
          if (res.data.respCode === '1000') {
            this.$message.success('操作成功')
            this.getZbDaiHouApproveHandle(false)
          }
        }).catch((err) => { console.log(err) })
      },
      // 回购
      backBuy () {
        this.buyBackDialogVisible = true
        this.$refs['buyBackData'] && this.$refs['buyBackData'].resetFields()
      },
      // 确认回购
      confirmBuyBack () {
        this.$refs['buyBackData'].validate((valid) => {
          if (valid) {
            this.buyBackData.applyId = this.rowApplyId
            buyBackFromNewNets(this.buyBackData).then((res) => {
              if (res.data.respCode === '1000') {
                this.$message.success('操作成功')
                this.buyBackDialogVisible = false
              } else {
                this.$message.warning('操作失败，不满足回购要求')
                this.buyBackDialogVisible = false
              }
            }).catch((err) => { console.log(err) })
          } else {
            this.$message.warning('请检查必填信息')
          }
        })
      },
      // 回购弹窗关闭回调
      backBuyClosed () {
        this.$refs['buyBackData'] && this.$refs['buyBackData'].resetFields()
        this.buyBackData = { buyBackReason: '' }
      },
    },
  }
</script>

<style scoped lang="scss">
  .capital-res-module{
    box-sizing: border-box;
    padding: 0 11px;
    margin: 5px 0 10px;
    ul {
      li{
        margin-bottom: 13px;
        display: flex;
        flex-direction: row;
        align-items: center;
        height: 25px;
        font-size: 14px;
        p:first-child{
          font-weight: 700;
        }

      }
    }
    .nets-btns{
      display: flex;
      justify-content: center;
    }
  }
  .el-message-box__message p{
    color: red !important;
  }
</style>
