<!--还款-还款勾稽审核-详情页-->
<template>
  <div class="write-off-check-detail-outerWrap">
    <!--新网：EX-XW， 众邦：EX-ZB ，2345自有：2345-->
    <!--billLoanType 借据类型 0-普通借据 1-联合贷借据-->
    <el-radio-group v-if="billLoanType"
                    v-model="activeName"
                    size="mini"
                    style="margin-bottom: 10px;"
                    @change="activeChange">
      <el-radio-button label="all">
        整体
      </el-radio-button>
      <el-radio-button label="EX-ZB">
        众邦
      </el-radio-button>
      <el-radio-button label="2345">
        2345
      </el-radio-button>
    </el-radio-group>
    <!--还款计划表-->
    <RepayPlanTable :repayment-list="repaymentList"
                    :current-capital-name="currentCapitalName"
                    @listenGetRepaymentPlans="listenGetRepaymentPlans"></RepayPlanTable>
    <div class="formModuleTitle">
      <span>客户还款信息</span>
      <i v-if="Number(bookType) === 3">（回购总金额仅包含资方非自有且所有未结清的期次）</i>
    </div>
    <div>
      <!--租金勾稽-->
      <el-form v-if="bookType === 1"
               ref="rentWriteOffData"
               key="writeOffCheck"
               size="small"
               label-position="left"
               :model="rentWriteOffData"
               :rules="rentWriteOffDataRule"
               class="write-off-check">
        <el-row :gutter="10">
          <el-col :span="6"
                  class="form-item-red">
            <el-form-item label="当前应还总金额"
                          label-width="114px">
              <el-col :span="17">
                <el-input v-model="rentWriteOffData.currentNeedRepay"
                          disabled
                          class="redSign"></el-input>
              </el-col>
              <el-col :span="7">
                <el-button type="primary"
                           size="mini"
                           @click="recountHandle">
                  重算
                </el-button>
              </el-col>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="实际应还款金额"
                          label-width="114px"
                          class="is-required">
              <el-input v-model="rentWriteOffData.adjustedNeedRepayAmount"
                        disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="勾稽余额"
                          label-width="72px"
                          class="is-required">
              <el-input v-model="writeOffAmount"
                        disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="放款主体"
                          label-width="72px"
                          class="is-required">
              <el-input v-model="rentWriteOffData.loanOrg"
                        disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="到账金额"
                          label-width="72px"
                          class="is-required"
                          prop="transferAmount">
              <el-input v-model="rentWriteOffData.transferAmount"
                        @blur="formatTransferAmount('rentWriteOffData')"
                        @focus="recoveryTransferAmount"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="减免金额"
                          label-width="72px">
              <el-input v-model="rentWriteOffData.otherExemption"
                        @blur="formatRentWriteOffOtherExemption('rentWriteOffData')"
                        @focus="recoveryRentWriteOffOtherExemption"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="勾稽金额"
                          label-width="72px"
                          class="is-required">
              <el-input v-model="rentWriteOffData.bookAmount"
                        disabled></el-input>
            </el-form-item>
          </el-col>
          <!-- <el-col :span="6">
            <el-form-item label="网银/流水编号"
                          label-width="96px">
              <el-input v-model="rentWriteOffData.externalRepayFlowNo"
                        maxlength="50"></el-input>
            </el-form-item>
          </el-col> -->
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="预计到账时间"
                          label-width="100px"
                          class="is-required"
                          prop="expectedTransferTime">
              <el-date-picker v-model="rentWriteOffData.expectedTransferTime"
                              type="date"
                              value-format="yyyy-MM-dd"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="到账银行"
                          label-width="72px"
                          class="is-required">
              <el-select v-model="rentWriteOffData.dueBank"
                         @change="dueBankChange">
                <el-option v-for="(item, index) in dueBankItemList"
                           :key="index"
                           :value="item.bankCode"
                           :label="item.bankName"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="到账账号"
                          label-width="72px"
                          class="is-required">
              <el-select v-model="rentWriteOffData.dueAccount">
                <el-option v-for="(item, index) in dueBankAccountList"
                           :key="index"
                           :value="item"
                           :label="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="勾稽余额使用"
                          label-width="90px"
                          prop="balanceUseMethod">
              <el-select v-model="rentWriteOffData.balanceUseMethod"
                         @change="changeRentWriteOffData('rentWriteOffData','change')">
                <el-option v-for="(item, index) in balanceUseMethodList"
                           :key="index"
                           :value="item.key"
                           :label="item.name"
                           :disabled="item.status"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="审核结果选择"
                          label-width="100px"
                          prop="auditResult">
              <el-select v-model="rentWriteOffData.auditResult">
                <el-option label="通过"
                           :value="1"></el-option>
                <el-option label="拒绝"
                           :value="0"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="勾稽资金来源"
                          label-width="100px"
                          prop="repaymentBookCapitalSource">
              <el-select v-model="rentWriteOffData.repaymentBookCapitalSource">
                <el-option v-for="(item, index) in sourceList"
                           :key="index"
                           :value="item.value"
                           :label="item.key"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="24">
            <el-form-item label="审核备注"
                          label-width="100px"
                          prop="auditRemark">
              <el-input v-model="rentWriteOffData.auditRemark"
                        type="textarea"
                        maxlength="500"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <!--提前结清租金勾稽-->
      <el-form v-if="bookType === 2"
               ref="beforeRentWriteOffData"
               key="beforeRentWriteOffCheck"
               size="small"
               label-position="left"
               :model="beforeRentWriteOffData"
               :rules="beforeRentWriteOffDataRule"
               class="write-off-check">
        <el-row :gutter="10">
          <el-col :span="15">
            <el-form-item label="条件"
                          label-width="33px">
              <el-checkbox-group v-model="beforeRentWriteOffData.conditionList"
                                 disabled>
                <el-checkbox :label="1">
                  满6个月
                </el-checkbox>
                <el-checkbox :label="2">
                  有欠款
                </el-checkbox>
                <el-checkbox :label="3">
                  下期还款日-当前日期 > 10天
                </el-checkbox>
              </el-checkbox-group>
            </el-form-item>
          </el-col>
          <el-col :span="9">
            <div class="redSign"
                 style="margin-top: 8px">
              特殊提前还款必须上传提前还款说明书
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="约定扣款日期"
                          label-width="100px"
                          prop="agreedTransferDate">
              <el-date-picker v-model="beforeRentWriteOffData.agreedTransferDate"
                              type="date"
                              value-format="yyyy-MM-dd"
                              @change="selectCondition(beforeRentWriteOffData.agreedTransferDate)"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="是否特殊还款"
                          label-width="104px"
                          prop="special">
              <el-select v-model="beforeRentWriteOffData.special"
                         @change="beforeRentWriteOffDataSpecialChange">
                <el-option :value="1"
                           label="是"></el-option>
                <el-option :value="0"
                           label="不是"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="提前结清类型"
                          label-width="104px"
                          prop="advanceType">
              <el-select v-model="beforeRentWriteOffData.advanceType">
                <el-option v-for="(val, key, index) in dict.advanceTypeDict"
                           :key="index"
                           :value="key"
                           :label="val"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="勾稽余额"
                          label-width="72px"
                          class="is-required">
              <el-input v-model="writeOffAmount"
                        disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="剩余本金"
                          label-width="72px"
                          class="is-required">
              <el-input v-model="beforeRentWriteOffData.totalRemainPrincipal"
                        disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="应还款总金额"
                          label-width="100px"
                          class="is-required">
              <el-col :span="17">
                <el-input v-model="beforeRentWriteOffData.currentNeedRepay"
                          disabled></el-input>
              </el-col>
              <el-col :span="7">
                <el-button type="primary"
                           size="mini"
                           @click="calculateHandle">
                  重算
                </el-button>
              </el-col>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="应还本金"
                          label-width="72px"
                          class="is-required">
              <el-input v-model="beforeRentWriteOffData.remainPrincipal"
                        disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="应还利息"
                          label-width="72px"
                          class="is-required">
              <el-input v-model="beforeRentWriteOffData.remainInterest"
                        disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="应还罚息"
                          label-width="72px"
                          class="is-required">
              <el-input v-model="beforeRentWriteOffData.remainOverduePenalty"
                        disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="提前还款违约金"
                          label-width="114px"
                          class="is-required">
              <el-input v-model="beforeRentWriteOffData.remainAdvancePenalty"
                        disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="应还费用"
                          label-width="72px"
                          class="is-required">
              <el-input v-model="beforeRentWriteOffData.remainFee"
                        disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="其他计收金额"
                          label-width="104px"
                          prop="otherCollection">
              <el-input v-model="beforeRentWriteOffData.otherCollection"
                        @blur="beforeRentWriteOffFormatMoney('otherCollection', beforeRentWriteOffData.otherCollection)"
                        @focus="beforeRentWriteOffRecoveryMoney('otherCollection', beforeRentWriteOffData.otherCollection)">
              </el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="其他免收金额"
                          label-width="100px"
                          prop="otherExemption">
              <el-input v-model="beforeRentWriteOffData.otherExemption"
                        :disabled="beforeRentWriteOffData.special === 0"
                        @blur="beforeRentWriteOffFormatMoney('otherExemption', beforeRentWriteOffData.otherExemption)"
                        @focus="beforeRentWriteOffRecoveryMoney('otherExemption', beforeRentWriteOffData.otherExemption)">
              </el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8"
                  class="form-item-red">
            <el-form-item label="实际应还款金额"
                          label-width="114px"
                          class="is-required">
              <el-input v-model="beforeRentWriteOffData.adjustedNeedRepayAmount"
                        disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="放款主体"
                          label-width="72px"
                          class="is-required">
              <el-input v-model="beforeRentWriteOffData.loanOrg"
                        disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="到账金额"
                          label-width="72px"
                          prop="transferAmount">
              <el-input v-model="beforeRentWriteOffData.transferAmount"
                        @blur="formatTransferAmount()"
                        @focus="recoveryTransferAmount"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="勾稽金额"
                          label-width="72px"
                          class="is-required">
              <el-input v-model="beforeRentWriteOffData.bookAmount"
                        disabled></el-input>
            </el-form-item>
          </el-col>
          <!-- <el-col :span="8">
            <el-form-item label="网银/流水编号"
                          label-width="103px">
              <el-input v-model="beforeRentWriteOffData.externalRepayFlowNo"></el-input>
            </el-form-item>
          </el-col> -->
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="预计到账时间"
                          label-width="100px"
                          prop="expectedTransferTime">
              <el-date-picker v-model="beforeRentWriteOffData.expectedTransferTime"
                              type="date"
                              value-format="yyyy-MM-dd"
                              class="w171px"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="到账银行"
                          label-width="72px"
                          prop="dueBank">
              <el-select v-model="beforeRentWriteOffData.dueBank"
                         @change="dueBankChange">
                <el-option v-for="(item, index) in dueBankItemList"
                           :key="index"
                           :value="item.bankCode"
                           :label="item.bankName"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="到账账号"
                          label-width="72px"
                          prop="dueAccount">
              <el-select v-model="beforeRentWriteOffData.dueAccount">
                <el-option v-for="(item, index) in dueBankAccountList"
                           :key="index"
                           :value="item"
                           :label="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <!-- <el-col :span="6">
              <el-form-item label="勾稽余额使用" label-width="90px" prop="balanceUseMethod">
                <el-select v-model="beforeRentWriteOffData.balanceUseMethod" >
                  <el-option v-for="(item, index) in balanceUseMethodList" :key="index" :value="item.key" :label="item.name"></el-option>
                </el-select>
              </el-form-item>
            </el-col> -->
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="审核结果选择"
                          label-width="100px"
                          prop="auditResult">
              <el-select v-model="beforeRentWriteOffData.auditResult">
                <el-option label="通过"
                           :value="1"></el-option>
                <el-option label="拒绝"
                           :value="0"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="勾稽资金来源"
                          label-width="100px"
                          prop="repaymentBookCapitalSource">
              <el-select v-model="beforeRentWriteOffData.repaymentBookCapitalSource">
                <el-option v-for="(item, index) in sourceList"
                           :key="index"
                           :value="item.value"
                           :label="item.key"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="24">
            <el-form-item label="审核备注"
                          label-width="100px"
                          prop="auditRemark">
              <el-input v-model="beforeRentWriteOffData.auditRemark"
                        type="textarea"
                        maxlength="500"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <!--回购-->
      <el-form v-if="Number(bookType) === 3"
               ref="buyBackRef"
               key="buyBackCheck"
               size="small"
               label-position="left"
               :model="buyBackData"
               :rules="buyBackFormRule"
               class="buy-back-form">
        <div class="buy-back-top">
          <el-row>
            <el-col :span="6">
              <el-form-item label="申请日回购总金额"
                            label-width="128px"
                            class="is-required">
                <el-input v-model="buyBackData.buybackAmount"
                          disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
        <div class="buy-back-middle">
          <el-row>
            <el-col :span="6"
                    class="form-item-red">
              <el-form-item label="当前回购总金额"
                            label-width="128px"
                            class="is-required">
                <el-input v-model="buyBackData.currentBuyBackAmt"
                          disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
        <div class="buy-back-bottom">
          <el-row :gutter="5">
            <el-col :span="24">
              <el-form-item label="审核结果选择"
                            label-width="100px"
                            prop="auditResult">
                <el-select v-model="buyBackData.auditResult">
                  <el-option label="通过"
                             :value="1"></el-option>
                  <el-option label="拒绝"
                             :value="0"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="5">
            <el-col :span="24">
              <el-form-item label="审核备注"
                            label-width="100px"
                            prop="auditRemark">
                <el-input v-model="buyBackData.auditRemark"
                          type="textarea"
                          maxlength="500"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
      </el-form>
    </div>
    <div class="write-off-dialog-btns">
      <el-button type="primary"
                 size="mini"
                 @click="showFileuploadDialog">
        查看凭证
      </el-button>
      <el-button type="primary"
                 size="mini"
                 :disabled="submitSuccess"
                 :loading="submitLoading"
                 @click="submit">
        提 交
      </el-button>
    </div>
    <!--审批历史-->
    <approveHistory :approve-history-data="approveHistoryData"></approveHistory>
    <!--文件上传弹窗-->
    <el-dialog title="请上传相关附件"
               :visible.sync="fileDialogVisible"
               :show-close="false">
      <p>温馨提示:系统支持上传的文件类型(*.pdf,*.docx,*.doc,*.jpg,*.jpeg,*.bmp,*.png,*.zip,*.rar,*.msg,*.eml,*.txt,*.wav</p>
      <p>单个word文件最大不能超过50.0MB;单个excel文件最大不能超过50.0MB;单个图片最大不能超过50.0MB;单个pdf文件最大不能超过50.0MB;单个压缩包文件最大不能超过20.0MB;</p>
      <FileUpload :picture-list="pictureList"
                  @savePicItem="savePicItemFn"></FileUpload>
      <div slot="footer"
           class="dialog-footer">
        <el-button size="mini"
                   @click="fileDialogVisible = false">
          关 闭
        </el-button>
        <el-button type="primary"
                   size="mini"
                   @click="saveAllPics">
          保 存
        </el-button>
      </div>
    </el-dialog>
    <!-- 应还金额已经变更 -->
    <el-dialog :visible.sync="currentPayDialogVisible"
               width="30%"
               center>
      <span slot="title"
            style="color: red;">注意</span>
      <span>当前应还总金额已变更，请确认是否继续提交</span>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="currentPayDialogVisible = false">取 消</el-button>
        <el-button type="primary"
                   @click="rentWriteOffSubmitAjax">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { checkApplyId, rmoney, fmoney, accMul } from '../../utils/constant'
import FileUpload from '../../components/DialoginnerFileupload/fileupload'
import RepayPlanTable from './repayPlanTable'
import { prepareTrialBalance, rentRepaymentInfo, dueBankList, queryRepaymentDetailInfo, dict, leaderAudit, approveHistoryList, searchBuyBackAmount, buyBackCheckSubmit, buyBackCheckResultPolling, calculate } from '../../api/financialManage'
import { financialGetFile, financialSaveFile } from '../../api/upload.js'
import approveHistory from './approveHistory'
export default {
  name: 'RepaymentWriteOffCheckDetail',
  components: { RepayPlanTable, FileUpload, approveHistory },
  data () {
    return {
      checkApplyId,
      fmoney,
      rmoney,
      dict,
      fileDialogVisible: false,
      currentPayDialogVisible: false,
      bookId: null,
      bookType: null, // 1: 租金勾稽  2：提前结清勾稽 3: 回购
      applyId: null,
      userId: null,
      billLoanNo: null,
      page: {
        pageNum: 1,
        pageSize: 5,
        pageSizeArr: [5, 10, 15, 20],
        total: 0,
      },
      balanceUseMethodList: [
        { key: 1, name: '保留余额', status: false },
        { key: 2, name: '冲抵租金(顺序冲抵应还期租金)', status: true },
      ],
      sourceList: [// 资金勾稽来源
        {
          key: '请选择',
          value: 0,
        },
        {
          key: 'SP打款',
          value: 1,
        }, {
          key: '本人打款',
          value: 2,
        }, {
          key: '他人打款',
          value: 3,
        }],
      submitLoading:false,
      currentCapitalName: '', // 还款计划右上角资方
      activeName: 'all', // 默认整体
      repaymentList: [], // 还款计划
      billLoanType: null, // 借据类型 0-普通借据 1-联合贷借据
      isRecountBtn: false, // 是否点击重算按钮
      currentNeedRepay: 0, // 当前应还总额
      oldCurrentNeedRepay: 0, // 旧的当前应还总额
      rentWriteOffData: {
        balanceUseMethod: 1,
        currentNeedRepay: null, // 当前应还金额
        adjustedNeedRepayAmount: '', // 调整后实际应还金额
        loanOrg: '', // 放款主体
        transferAmount: null, // 实际到账金额
        otherExemption: '0.00', // 减免金额
        bookAmount: null, // 勾稽金额
        externalRepayFlowNo: '', // 银行流水编号
        expectedTransferTime: '', // 预计到账时间
        dueBank: null, // 到账银行
        dueAccount: null, // 到账银行账户
        remark: '', // 备注
        addedBalance: 0, // 本次新增勾稽余额
        auditResult: null, // 审核结果
        auditRemark: '', // 申请备注
        repaymentBookCapitalSource: 0,// 资金来源
      }, // 租金勾稽
      beforeRentWriteOffData: {
        balanceUseMethod: 1,
        conditionList: [], // 条件 [满6个月, 有欠款 , 下期还款日-当前日期 > 10天]
        agreedTransferDate: '', // 约定扣款日
        special: 0, // 是否特殊还款
        advanceType: null, // 提前结清类型 1换车 2退车 3处置结清 4核销结清 5正常结清
        totalRemainPrincipal: '', // 剩余本金
        currentNeedRepay: null, // 当前应还总金额
        remainPrincipal: null, // 应还本金
        remainInterest: null, // 应还利息
        remainOverduePenalty: null, // 应还罚息
        remainAdvancePenalty: null, // 提前还款违约金
        remainFee: null, // 应还费用
        otherCollection: '0.00', // 其他计收金额
        otherExemption: '0.00', // 其他免除金额
        adjustedNeedRepayAmount: null, // 调整后实际应还金额
        loanOrg: '', // 放款主体
        transferAmount: null, // 实际到账金额
        bookAmount: null, // 勾稽金额
        externalRepayFlowNo: '', // 银行流水编号
        expectedTransferTime: '', // 预计到账时间
        dueBank: null,
        dueAccount: null,
        remark: '',
        addedBalance: 0, // 本次新增勾稽余额
        auditResult: null,
        auditRemark: '',
        repaymentBookCapitalSource: 0,// 资金来源
      }, // 提前结清勾稽
      buyBackData: {
        buybackAmount: '0.00',
        currentBuyBackAmt: '0.00',
        auditResult: null,
        auditRemark: '',
      }, // 回购
      rentWriteOffDataRule: {
        transferAmount: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        expectedTransferTime: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        auditResult: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        auditRemark: [{ required: true, message: '内容不可为空', trigger: 'blur' }],
      },
      beforeRentWriteOffDataRule: {
        agreedTransferDate: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        special: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        advanceType: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        otherCollection: [{ required: true, message: '内容不可为空', trigger: 'blur' }],
        otherExemption: [{ required: true, message: '内容不可为空', trigger: 'blur' }],
        transferAmount: [{ required: true, message: '内容不可为空', trigger: 'blur' }],
        expectedTransferTime: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        dueBank: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        dueAccount: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        remark: [{ required: true, message: '内容不可为空', trigger: 'blur' }],
        auditResult: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        auditRemark: [{ required: true, message: '内容不可为空', trigger: 'blur' }],
      },
      buyBackFormRule: {
        auditResult: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        auditRemark: [{ required: true, message: '内容不可为空', trigger: 'blur' }],
      },
      clickItem: {}, // 列表点击项
      dueBankItemList: [], // 到账银行
      dueBankAccountList: [], // 到账账号
      historyBookBalance: 0, // 历史勾稽余额
      writeOffAmount: 0, // 勾稽余额
      pictureList: [{
        dictKey: 'book_file',
        fileRecordVOList: [],
        name: '还款勾稽凭证',
      }],
      conditionSelectData: {}, // 条件勾选依赖
      // rentRepaymentInfoData: {},
      approveHistoryData: [],
      windowCloseTimer: null,
      submitSuccess: false,
      rollDuration: 0, // 定时器间隔毫秒
      buyBackPollTimer: null, // 回购轮询定时器
      buyBackPollLoading: null, // 回购轮询提示弹窗实例
    }
  },
  mounted () {
    const { bookId, bookType, applyId, userId, billLoanNo } = this.$route.params
    this.bookId = bookId ? +bookId : null
    this.bookType = bookType ? +bookType : null
    this.applyId = applyId ? +applyId : null
    this.userId = userId ? +userId : null
    this.billLoanNo = billLoanNo || null
    this.getRepaymentPlans() // 还款计划
    this.getFormValue() // 获取整个表单的信息（租金勾稽、提前结清勾稽、回购）
    this.fileGet() // 文件信息
    this.getApproveHistoryList() // 审批历史
  },
  methods: {
    // 改变勾稽余额使用方式
    changeRentWriteOffData (type, select) {
      if (this[type].transferAmount === '' || this[type].transferAmount === null || this[type].transferAmount === undefined) {
        if (select) {
          this[type].balanceUseMethod === 1 ? this[type].balanceUseMethod = 2 : this[type].balanceUseMethod = 1
        }
        return this.$message.warning('请先填写到账金额')
      }
      // 调接口查询
      this.fetchPrepareTrialBalance('rentWriteOffData')
    },
    async fetchPrepareTrialBalance (type) {
      let data = {
        applyId: this.applyId,
        balanceUseMethod: this[type].balanceUseMethod,
        transferAmount: accMul(rmoney(this[type].transferAmount), 100),
        otherExemption: accMul(rmoney(this[type].otherExemption), 100),
        billLoanNo: this.billLoanNo,
        userId: this.userId,
      }
      console.log(data)
      let res = await prepareTrialBalance(data)
      if (res.data.respCode === '1000') {
        this[type].addedBalance = res.data.body.addedBalance
        this.writeOffAmount = fmoney(res.data.body.addedBalance / 100)
        this[type].bookAmount = fmoney(res.data.body.bookAmount / 100)
      }
    },
    async getFormValue () {
      let flag = null
      let dueBank = null
      try {
        flag = await this.getRentRepaymentInfo()
      } catch (e) {
        return false
      }
      if (Number(this.bookType) !== 3) {
        if (flag) {
          try {
            dueBank = await this.getDueBankList() // 到账银行
          } catch (e) {
            return false
          }
          if (dueBank) this.dueBankChange() // 到账账号
        }
      } else {
        this.getBuyBackData() // 回购数据
      }
    },
    // 当前明细更换
    activeChange (val) {
      this.getRepaymentPlans(val)
    },
    listenGetRepaymentPlans () {
      this.getRepaymentPlans(this.activeName)
    },
    // 重算
    recountHandle () {
      this.getRepaymentPlans(this.activeName)
      this.isRecountBtn = true
    },
    // 提前结清重算
    calculateHandle () {
      calculate(this.billLoanNo, this.userId).then((rst) => {
        if (rst.data.respCode === '1000') {
          let { currentNeedRepay, remainAdvancePenalty, remainFee, remainInterest, remainOverduePenalty, remainPrincipal, totalRemainPrincipal } = rst.data.body
          this.beforeRentWriteOffData.currentNeedRepay = fmoney(currentNeedRepay / 100)
          this.beforeRentWriteOffData.remainAdvancePenalty = fmoney(remainAdvancePenalty / 100)
          this.beforeRentWriteOffData.remainFee = fmoney(remainFee / 100)
          this.beforeRentWriteOffData.remainInterest = fmoney(remainInterest / 100)
          this.beforeRentWriteOffData.remainOverduePenalty = fmoney(remainOverduePenalty / 100)
          this.beforeRentWriteOffData.remainPrincipal = fmoney(remainPrincipal / 100)
          this.beforeRentWriteOffData.totalRemainPrincipal = fmoney(totalRemainPrincipal / 100)
          this.formatTransferAmount()
          this.calculateAdjustedNeedRepayAmount()
        }
      })
    },
    // 查询还款计划
    getRepaymentPlans () {
      let capitalList = Array.from(arguments)
      let length = Array.from(arguments).length
      // 新网：EX-XW， 众邦：EX-ZB ，2345自有：2345
      let query = {}
      if (!length || capitalList[0] === 'all') { // 查询整体
        query = {
          userId: this.userId,
          billLoanNo: this.billLoanNo,
          applyId: this.applyId,
        }
      } else {
        query = {
          userId: this.userId,
          billLoanNo: this.billLoanNo,
          applyId: this.applyId,
          capitalList,
        }
      }
      queryRepaymentDetailInfo(query).then((res) => {
        if (res.data.respCode === '1000') {
          const { repaymentPlanVOList, currentCapital, billLoanType, currentNeedRepay } = res.data.body
          repaymentPlanVOList.forEach((item) => {
            if (item.repayDate) item.repayDate = item.repayDate.substring(0, 10)
          })
          this.currentCapitalName = currentCapital
          // if (currentCapital === '2345自有资金') {
          //   this.balanceUseMethodList = [
          //     { key: 1, name: '保留余额', status: false },
          //   ]
          // } else {
          //   this.balanceUseMethodList = [{ key: 1, name: '保留余额', status: false }]
          // }
          this.repaymentList = repaymentPlanVOList
          this.billLoanType = billLoanType
          this.currentNeedRepay = currentNeedRepay
          if (this.isRecountBtn) {
            if (Number(this.bookType) === 1) {
              this.rentWriteOffData.currentNeedRepay = fmoney(currentNeedRepay / 100)
              this.formatTransferAmount()
            }
          }
        }
      }).catch((err) => { console.log(err) })
    },
    // 租金勾稽、提前结清勾稽、回购（申请日总金额）的数据拉取
    getRentRepaymentInfo () {
      return new Promise((resolve, reject) => {
        rentRepaymentInfo(this.bookId).then((res) => {
          if (res.data.respCode === '1000') {
            const { buybackAmount, repaymentAdvanceSettleDetailVO, currentNeedRepayAmount } = res.data.body
            const calculateInfoData = repaymentAdvanceSettleDetailVO // 原本计算接口返回值
            this.oldCurrentNeedRepay = currentNeedRepayAmount
            // this.rentRepaymentInfoData = res.data.body
            if (Number(this.bookType) === 1) this.valToRentWriteOff(res.data.body)
            if (Number(this.bookType) === 2) this.valToBeforeRentWriteOff(res.data.body, calculateInfoData)
            if (Number(this.bookType) === 3) this.buyBackData.buybackAmount = fmoney(buybackAmount / 100) // 回购 申请日回购总金额
            resolve(1)
          }
        }).catch((err) => { reject(err) })
      })
    },
    // 回购数据
    getBuyBackData () {
      searchBuyBackAmount(this.applyId).then((res) => {
        if (res.data.respCode === '1000') {
          const { currentBuyBackAmt } = res.data.body
          this.buyBackData.currentBuyBackAmt = fmoney(currentBuyBackAmt / 100) // 回购 当前回购总金额
        }
      })
    },
    // 租金勾稽赋值操作
    valToRentWriteOff (res) {
      const { balanceUseMethod, expectedTransferTime, dueBank, dueAccount, loanOrg, externalRepayFlowNo, addedBalance, transferAmount, otherExemption, bookAmount, currentNeedRepayAmount, adjustedNeedRepayAmount, repaymentBookCapitalSource } = res
      this.rentWriteOffData.expectedTransferTime = expectedTransferTime.substring(0, 10)
      this.rentWriteOffData.dueBank = dueBank
      this.rentWriteOffData.dueAccount = dueAccount
      this.rentWriteOffData.loanOrg = loanOrg
      this.rentWriteOffData.balanceUseMethod = balanceUseMethod
      this.rentWriteOffData.externalRepayFlowNo = externalRepayFlowNo
      this.rentWriteOffData.addedBalance = addedBalance
      this.writeOffAmount = fmoney(addedBalance / 100) // 勾稽余额
      this.rentWriteOffData.transferAmount = fmoney(transferAmount / 100) // 到账金额
      this.rentWriteOffData.otherExemption = fmoney(otherExemption / 100) // 减免金额
      this.rentWriteOffData.bookAmount = fmoney(bookAmount / 100) // 元 // 勾稽金额
      this.rentWriteOffData.currentNeedRepay = fmoney(currentNeedRepayAmount / 100) // 元
      this.rentWriteOffData.adjustedNeedRepayAmount = fmoney(adjustedNeedRepayAmount / 100) // 元
      this.rentWriteOffData.repaymentBookCapitalSource = repaymentBookCapitalSource // 资金来源
    },
    // 提前结清勾稽赋值操作
    valToBeforeRentWriteOff (res, calculateInfoData) {
      const { expectedTransferTime, dueBank, dueAccount, agreedTransferDate, advanceType, special, loanOrg, externalRepayFlowNo, otherCollection, otherExemption, addedBalance, adjustedNeedRepayAmountCalculated, transferAmount, bookAmountCalculated, addedBalanceCalculated, repaymentBookCapitalSource } = res
      this.beforeRentWriteOffData.expectedTransferTime = expectedTransferTime.substring(0, 10)
      this.beforeRentWriteOffData.dueBank = dueBank
      this.beforeRentWriteOffData.dueAccount = dueAccount
      this.beforeRentWriteOffData.agreedTransferDate = agreedTransferDate.substring(0, 10)
      this.beforeRentWriteOffData.conditionList = calculateInfoData.conditionList
      this.beforeRentWriteOffData.advanceType = advanceType + ''
      this.beforeRentWriteOffData.special = special
      this.beforeRentWriteOffData.loanOrg = loanOrg
      this.beforeRentWriteOffData.externalRepayFlowNo = externalRepayFlowNo
      this.beforeRentWriteOffData.otherCollection = fmoney(otherCollection / 100) // 其他计收
      this.beforeRentWriteOffData.otherExemption = fmoney(otherExemption / 100) // 其他免收
      this.beforeRentWriteOffData.addedBalance = addedBalance
      this.writeOffAmount = fmoney(addedBalance / 100) // 勾稽余额
      this.beforeRentWriteOffData.totalRemainPrincipal = fmoney(calculateInfoData.totalRemainPrincipal / 100) // 剩余本金
      this.beforeRentWriteOffData.currentNeedRepay = fmoney(calculateInfoData.currentNeedRepay / 100)// 应还款总金额
      this.beforeRentWriteOffData.remainPrincipal = fmoney(calculateInfoData.remainPrincipal / 100)// 应还本金
      this.beforeRentWriteOffData.remainInterest = fmoney(calculateInfoData.remainInterest / 100)// 应还利息
      this.beforeRentWriteOffData.remainOverduePenalty = fmoney(calculateInfoData.remainOverduePenalty / 100)// 应还罚息
      this.beforeRentWriteOffData.remainAdvancePenalty = fmoney(calculateInfoData.remainAdvancePenalty / 100)// 提前还款违约金
      this.beforeRentWriteOffData.adjustedNeedRepayAmount = fmoney(adjustedNeedRepayAmountCalculated / 100) // 实际应还款金额
      this.beforeRentWriteOffData.transferAmount = fmoney(transferAmount / 100) // 到账金额
      this.beforeRentWriteOffData.remainFee = fmoney(calculateInfoData.remainFee / 100) // 应还费用
      this.beforeRentWriteOffData.bookAmount = fmoney(bookAmountCalculated / 100) // 元 // 勾稽金额
      this.beforeRentWriteOffData.addedBalance = addedBalanceCalculated // 分 // 本次新增的勾稽余额
      this.beforeRentWriteOffData.repaymentBookCapitalSource = repaymentBookCapitalSource // 资金来源
    },
    // 文件信息
    fileGet () {
      let data = { applyId: this.bookId, dictCategory: ['repayment_book_file'].join(',') }
      financialGetFile(data).then((res) => {
        if (res.data.respCode === '1000') {
          const { pictureListVOList } = res.data.body
          this.pictureList = pictureListVOList.length ? pictureListVOList : this.pictureList
        }
      }).catch((err) => { console.log(err) })
    },

    // 到账银行、账号
    getDueBankList () {
      return new Promise((resolve, reject) => {
        dueBankList(this.applyId).then((res) => {
          if (res.data.respCode === '1000') {
            const { bankAccounts } = res.data.body
            this.dueBankItemList = bankAccounts
            resolve(1)
          }
        }).catch((err) => { reject(err) })
      })
    },
    // 到账银行切换
    dueBankChange () {
      if (this.dueBankItemList.length > 0) {
        this.dueBankItemList.forEach((item) => {
          if (this.bookType === 1) {
            if (item.bankCode === this.rentWriteOffData.dueBank) {
              this.dueBankAccountList = item.dueAccounts
              this.rentWriteOffData.dueAccount = this.dueBankAccountList[0]
            }
          } else {
            if (item.bankCode === this.beforeRentWriteOffData.dueBank) {
              this.dueBankAccountList = item.dueAccounts
              this.beforeRentWriteOffData.dueAccount = this.dueBankAccountList[0]
            }
          }
        })
      }
    },

    // 到账金额格式化
    formatTransferAmount (type) {
      if (this.bookType === 1) {
        this.rentWriteOffCalculate()
      } else {
        // 到账金额
        this.beforeRentWriteOffData.transferAmount =
          (this.beforeRentWriteOffData.transferAmount !== '' && this.beforeRentWriteOffData.transferAmount !== null) ? fmoney(this.beforeRentWriteOffData.transferAmount) : ''
        this.beforeRentWriteOffComplexCompare()
      }
      if (type) {
        this.changeRentWriteOffData(type)
      }
    },
    // 恢复到账金额格式化
    recoveryTransferAmount () {
      if (this.bookType === 1) {
        this.rentWriteOffData.transferAmount = this.rentWriteOffData.transferAmount ? rmoney(this.rentWriteOffData.transferAmount) : ''
      } else {
        this.beforeRentWriteOffData.transferAmount = this.beforeRentWriteOffData.transferAmount ? rmoney(this.beforeRentWriteOffData.transferAmount) : ''
      }
    },

    // 租金勾稽的相关运算
    rentWriteOffCalculate () {
      // 到账金额
      this.rentWriteOffData.transferAmount =
        (this.rentWriteOffData.transferAmount !== '' && this.rentWriteOffData.transferAmount !== null) ? fmoney(this.rentWriteOffData.transferAmount) : ''
      /*
      * 到账金额小于当前应还款金额，取transferAmountCopy，如果有减免金额，就加上减免金额，没有的话就直接等于transferAmountCopy
      * 如果不小于，取currentNeedRepayCopy，如果有减免金额，就减去减免金额，没有的话就直接等于取currentNeedRepayCopy
      * */
      let currentNeedRepayCopy = accMul(rmoney(this.rentWriteOffData.currentNeedRepay), 100) // 分 // 当前应还总金额
      // let transferAmountCopy = accMul(rmoney(this.rentWriteOffData.transferAmount), 100) // 分 // 到账金额
      // let finalBookAmount = null
      let otherExemptionCopy = accMul(rmoney(this.rentWriteOffData.otherExemption), 100) // 分 // 减免金额
      let adjustedNeedRepayAmountCopy = currentNeedRepayCopy - otherExemptionCopy
      // 调整后实际应还款金额 = 当前应还总金额 - 减免金额
      this.rentWriteOffData.adjustedNeedRepayAmount = fmoney(adjustedNeedRepayAmountCopy / 100)
      // finalBookAmount = transferAmountCopy < adjustedNeedRepayAmountCopy ? transferAmountCopy : adjustedNeedRepayAmountCopy
      // this.rentWriteOffData.bookAmount = fmoney(finalBookAmount / 100) // 元 // 勾稽金额
      // 本次新增的勾稽余额 = 当到账金额<当前应还总金额时，取0，不小于时，到账金额 - 勾稽金额（实际应还款金额）
      // this.rentWriteOffData.addedBalance = transferAmountCopy < adjustedNeedRepayAmountCopy ? 0 : transferAmountCopy - accMul(rmoney(this.rentWriteOffData.bookAmount), 100)
      // 需要显示的勾稽余额 = 本次新增勾稽余额（前端计算得出） + 历史勾稽余额（后端给出）
      // this.writeOffAmount = fmoney((this.rentWriteOffData.addedBalance + this.historyBookBalance) / 100)
    },
    // 租金勾稽免收金额格式化 + 计算
    formatRentWriteOffOtherExemption (type) {
      this.rentWriteOffData.otherExemption = fmoney(this.rentWriteOffData.otherExemption)
      this.formatTransferAmount()
      if (type) {
        this.changeRentWriteOffData(type)
      }
    },
    // 租金勾稽免收金额恢复
    recoveryRentWriteOffOtherExemption () {
      this.rentWriteOffData.otherExemption = rmoney(this.rentWriteOffData.otherExemption)
    },

    // 计算提前租金勾稽实际应还款金额
    calculateAdjustedNeedRepayAmount () {
      // 应还款总金额 + 其他计收金额 - 其他免除金额
      this.beforeRentWriteOffData.adjustedNeedRepayAmount =
        (accMul(rmoney(this.beforeRentWriteOffData.currentNeedRepay), 100)) + (accMul(rmoney(this.beforeRentWriteOffData.otherCollection), 100)) - (accMul(rmoney(this.beforeRentWriteOffData.otherExemption), 100)) // 分
      this.beforeRentWriteOffData.adjustedNeedRepayAmount = fmoney(this.beforeRentWriteOffData.adjustedNeedRepayAmount / 100) // (元)
      this.beforeRentWriteOffComplexCompare()
    },
    // 提前结清勾稽的复杂运算逻辑
    beforeRentWriteOffComplexCompare () {
      // 比较实际应还款金额 和 到账金额
      let adjustedNeedRepayAmountCopy = accMul(rmoney(this.beforeRentWriteOffData.adjustedNeedRepayAmount), 100) // 分 // 实际应还款金额
      let transferAmountCopy = accMul(rmoney(this.beforeRentWriteOffData.transferAmount), 100) // 分 // 到账金额
      let tempVal = transferAmountCopy < adjustedNeedRepayAmountCopy ? transferAmountCopy : adjustedNeedRepayAmountCopy
      this.beforeRentWriteOffData.bookAmount = fmoney(tempVal / 100) // 元
      // 本次新增的勾稽余额 = 到账金额 - 勾稽金额
      this.beforeRentWriteOffData.addedBalance = transferAmountCopy - accMul(rmoney(this.beforeRentWriteOffData.bookAmount), 100)
      // 需要显示的勾稽余额 = 本次新增勾稽余额（前端计算得出） + 历史勾稽余额（后端给出）
      this.writeOffAmount = fmoney((this.beforeRentWriteOffData.addedBalance + this.historyBookBalance) / 100)
    },
    // 提前结清金钱通用格式化金额事件
    beforeRentWriteOffFormatMoney (target, val) {
      this.beforeRentWriteOffData[target] = fmoney(val)
      // 其他计收金额变化 和 其他免收金额变化 会导致实际应还款金额的变化
      if (this.beforeRentWriteOffData.currentNeedRepay !== '' && this.beforeRentWriteOffData.currentNeedRepay !== null) {
        if (target === 'otherCollection' && (this.beforeRentWriteOffData.otherCollection !== '')) this.calculateAdjustedNeedRepayAmount()
        if (target === 'otherExemption' && (this.beforeRentWriteOffData.otherExemption !== '')) this.calculateAdjustedNeedRepayAmount()
      }
    },
    // 提前结清金钱通用恢复格式化金额事件
    beforeRentWriteOffRecoveryMoney (target, val) {
      this.beforeRentWriteOffData[target] = rmoney(val)
    },
    // 约定扣款日期变化，导致提前结清勾稽的条件变化
    selectCondition (val) {
      this.beforeRentWriteOffData.conditionList = []
      let agreedTransferDate = new Date(val + ' 00:00:00').getTime()
      let tenDaysBeforeNextRepayDate = new Date(this.conditionSelectData.tenDaysBeforeNextRepayDate).getTime()
      let sixMonthAfterLoanTransfer = new Date(this.conditionSelectData.sixMonthAfterLoanTransfer).getTime()
      if (agreedTransferDate > sixMonthAfterLoanTransfer) this.beforeRentWriteOffData.conditionList.push(1)
      if (agreedTransferDate < tenDaysBeforeNextRepayDate) this.beforeRentWriteOffData.conditionList.push(3)
    },
    // 是否特殊还款值的改变
    beforeRentWriteOffDataSpecialChange () {
      // 当特殊还款为否时，清空其他免收金额的值
      if (+this.beforeRentWriteOffData.special === 0) this.beforeRentWriteOffData.otherExemption = '0.00'
    },

    // 查看凭证
    showFileuploadDialog () {
      this.fileDialogVisible = true
      this.fileGet()
    },
    // 保存图片
    savePicItemFn (val) {
      this.pictureList.forEach((item) => {
        if (item.dictKey === val.item.dictKey) {
          item.fileRecordVOList.push(val.data)
        }
      })
    },
    // 保存所有图片
    saveAllPics () {
      financialSaveFile({ relatedId: this.bookId, pictureListVOList: this.pictureList }).then((res) => {
        if (res.data.respCode === '1000') {
          this.$message.success('保存成功')
          this.fileDialogVisible = false
        }
      }).catch((err) => { console.log(err) })
    },
    // 审核提交
    submit () {
      this.submitLoading = true
      if (Number(this.bookType) === 1) this.rentWriteOffSubmit()
      if (Number(this.bookType) === 2) this.beforeRentWriteOffSubmit()
      if (Number(this.bookType) === 3) this.buyBackSubmit()
    },
    // 租金勾稽提交ajax
    rentWriteOffSubmit () {
      this.$refs['rentWriteOffData'].validate((valid) => {
        if (valid) {
          if (!this.isRecountBtn && this.oldCurrentNeedRepay !== this.currentNeedRepay) {
            this.currentPayDialogVisible = true
          } else {
            this.rentWriteOffSubmitAjax()
          }
        } else {
          this.submitLoading = false
          this.$message.warning('请检查必填字段')
        }
      })
    },
    rentWriteOffSubmitAjax () {
      let data = JSON.parse(JSON.stringify(this.rentWriteOffData)) // 深拷贝
      data.id = this.bookId
      data.auditResult = Boolean(data.auditResult)
      data.currentNeedRepay = accMul(rmoney(data.currentNeedRepay), 100) // 应还款总金额
      data.adjustedNeedRepayAmount = accMul(rmoney(data.adjustedNeedRepayAmount), 100)
      data.bookAmount = accMul(rmoney(data.bookAmount), 100)
      data.transferAmount = accMul(rmoney(data.transferAmount), 100)
      data.otherExemption = accMul(rmoney(data.otherExemption), 100)
      data.balanceUseMethod = data.balanceUseMethod ? Number(data.balanceUseMethod) : 1
      leaderAudit(data).then((res) => {
        this.submitLoading = false
        this.currentPayDialogVisible = false
        if (res.data.respCode === '1000') this.closeCurrentWindow('success', '操作成功，页面即将关闭！')
      }).catch((err) => {
        console.log(err)
        this.submitLoading = false
        this.currentPayDialogVisible = false
      })
    },
    // 提前结清勾稽提交ajax
    beforeRentWriteOffSubmit () {
      this.$refs['beforeRentWriteOffData'].validate((valid) => {
        if (valid) {
          let data = JSON.parse(JSON.stringify(this.beforeRentWriteOffData))
          data.adjustedNeedRepayAmount = accMul(rmoney(data.adjustedNeedRepayAmount), 100) // 实际应还款金额
          data.bookAmount = accMul(rmoney(data.bookAmount), 100) // 勾稽金额
          data.currentNeedRepay = accMul(rmoney(data.currentNeedRepay), 100) // 应还款总金额
          data.otherCollection = accMul(rmoney(data.otherCollection), 100)
          data.otherExemption = accMul(rmoney(data.otherExemption), 100)
          data.remainAdvancePenalty = accMul(rmoney(data.remainAdvancePenalty), 100)
          data.remainInterest = accMul(rmoney(data.remainInterest), 100)
          data.remainOverduePenalty = accMul(rmoney(data.remainOverduePenalty), 100)
          data.remainPrincipal = accMul(rmoney(data.remainPrincipal), 100)
          data.totalRemainPrincipal = accMul(rmoney(data.totalRemainPrincipal), 100)
          data.transferAmount = accMul(rmoney(data.transferAmount), 100) // 到账金额
          data.remainFee = accMul(rmoney(data.remainFee), 100)
          data.applyId = this.applyId
          data.dueBank = data.dueBank
          data.dueAccount = data.dueAccount
          data.fileListVo = { pictureListVOList: this.pictureList }
          data.id = this.bookId
          data.balanceUseMethod = data.balanceUseMethod ? Number(data.balanceUseMethod) : 1
          // if (data.transferAmount < data.adjustedNeedRepayAmount && this.rentWriteOffData.auditResult) {
          //   this.$message.warning('到账金额必须大于等于实际应还款总金额')
          //   return false
          // }
          leaderAudit(data).then((res) => {
            this.submitLoading = false
            if (res.data.respCode === '1000') this.closeCurrentWindow('success', '操作成功，页面即将关闭！')
          }).catch((err) => { console.log(err) })
        } else {
          this.submitLoading = false
          this.$message.warning('请检查必填项')
        }
      })
    },
    // 回购提交ajax
    buyBackSubmit () {
      this.$refs['buyBackRef'].validate((valid) => {
        if (valid) {
          const { auditResult, auditRemark } = this.buyBackData
          const apiData = { auditRemark, auditResult: Boolean(auditResult), id: this.bookId }
          buyBackCheckSubmit(apiData).then((res) => {
            this.submitLoading = false
            if (res.data.respCode === '1000') {
              // 新网银行+通过 才要轮询
              if (this.currentCapitalName === '新网银行' && auditResult) {
                this.initBuyBackPoll()
              } else {
                this.closeCurrentWindow('success', '操作成功，页面即将关闭！')
              }
            } else if (res.data.respCode === 'buyback_in_process') {
              this.initBuyBackPoll()
            }
          }).catch(() => {
            this.submitLoading = false
        })
        }
      })
    },
    // 回购审核结果查询初始化调用
    initBuyBackPoll () {
      this.buyBackPollLoading = this.$message({
        message: '审核结果查询中，请耐心等待',
        duration: 0,
      })
      let rollCount = 1 // 轮询次数
      buyBackCheckResultPolling(this.bookId, rollCount).then((res) => {
        if (res.data.respCode === '1000') {
          const { auditResult, rollDuration } = res.data.body
          if (auditResult === 'PROC') {
            this.rollDuration = rollDuration // 定时器毫秒
            this.buyBackPoll(this.bookId, rollCount)
          } else if (auditResult === 'SUCC') {
            this.closeCurrentWindow('success', '审核成功，页面即将关闭！')
          } else if (auditResult === 'FAIL') {
            this.$message.error('审核失败')
          }
        } else {
          if (this.buyBackPollLoading) this.buyBackPollLoading.close() // 关闭loading
        }
      })
    },
    buyBackPoll (bookId, rollCount) {
      rollCount += 1
      clearTimeout(this.buyBackPollTimer)
      this.buyBackPollTimer = null
      this.buyBackPollTimer = setTimeout(() => {
        buyBackCheckResultPolling(bookId, rollCount).then((res) => {
          if (res.data.respCode === '1000') {
            const { auditResult, rollDuration } = res.data.body
            if (auditResult !== 'PROC') {
              clearTimeout(this.buyBackPollTimer)
              this.buyBackPollTimer = null
              if (this.buyBackPollLoading) this.buyBackPollLoading.close() // 关闭loading
            } else {
              this.rollDuration = rollDuration // 定时器毫秒
              this.buyBackPoll(this.bookId, rollCount)
            }
            if (auditResult === 'SUCC') {
              this.closeCurrentWindow('success', '审核成功，页面即将关闭！')
            } else if (auditResult === 'FAIL') {
              this.$message.error('审核失败')
            }
          } else {
            if (this.buyBackPollLoading) this.buyBackPollLoading.close()
          }
        }).catch(() => {
          clearTimeout(this.buyBackPollTimer)
          this.buyBackPollTimer = null
          if (this.buyBackPollLoading) this.buyBackPollLoading.close()
        })
      }, this.rollDuration)
    },

    // 审批历史
    getApproveHistoryList () {
      approveHistoryList(this.bookId).then((res) => {
        if (res.data.respCode === '1000') this.approveHistoryData = res.data.body
      }).catch((err) => { console.log(err) })
    },

    // 提交成功关闭当前页面
    closeCurrentWindow (type, msg) {
      this.submitSuccess = true
      this.$message[type](msg)
      clearTimeout(this.windowCloseTimer)
      this.windowCloseTimer = setTimeout(() => {
        window.close()
      }, 3000)
    },
  },
}
</script>

<style scoped lang="scss">
.redSign {
  color: red;
}
.write-off-dialog-btns {
  display: flex;
  flex-direction: row;
  justify-content: center;
}
.write-off-check-detail-outerWrap {
  box-sizing: border-box;
  padding: 5px 10px;
}
.buy-back-form {
  > div {
    & + div {
      padding-top: 18px;
      border-top: 1px solid #ccc;
    }
  }
}
.formModuleTitle {
  > i {
    font-style: normal;
    font-size: 12px;
    color: #333;
    margin-left: 8px;
    height: 30px;
    line-height: 30px;
  }
}
</style>
