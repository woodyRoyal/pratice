<template>
  <div>
    <div class="financial-query-wrap">
      <el-form size="mini"
               label-position="left"
               :inline="true">
        <!-- <el-row :gutter="10"> -->
        <!-- <el-col :span="colSpan"> -->
        <el-form-item label="申请编号"
                      :label-width="labelWidth">
          <el-input v-model="queryData.applyDisplayId"
                    maxlength="8"
                    @blur="checkApplyId(queryData.applyDisplayId)"></el-input>
        </el-form-item>
        <el-form-item label="申请编号(老)"
                      label-width="100px">
          <el-input v-model="queryData.oldApplyNo"
                    maxlength="7"
                    placeholder="申请编号(老)"
                    onkeypress="return(/^[0-9]*$/.test(String.fromCharCode(event.keyCode)))"
                    @blur="checkApplyId(queryData.oldApplyNo,'oldApplyNo',7)"></el-input>
        </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="colSpan"> -->
        <el-form-item label="客户姓名"
                      :label-width="labelWidth">
          <el-input v-model="queryData.customerName"
                    maxlength="30"></el-input>
        </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="colSpan"> -->
        <el-form-item label="放款银行"
                      :label-width="labelWidth">
          <el-select v-model="queryData.channelBank"
                     style="width:163px">
            <el-option v-for="item in payBankList"
                       :key="item.bank"
                       :value="item.bank"
                       :label="item.bank"></el-option>
          </el-select>
        </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="colSpan"> -->
        <el-form-item label="小贷标识"
                      :label-width="labelWidth">
          <el-select v-model="queryData.isMicro"
                     style="width:163px">
            <el-option label="是"
                       :value="true"></el-option>
            <el-option label="否"
                       :value="false"></el-option>
          </el-select>
        </el-form-item>
        <!-- </el-col> -->
        <!-- </el-row> -->
        <!-- <el-row :gutter="10"> -->
        <!-- <el-col :span="colSpan"> -->
        <el-form-item label="放款时间(起)"
                      :label-width="labelWidth">
          <el-date-picker v-model="queryData.transferDateBegin"
                          style="width:163px"
                          type="datetime"
                          value-format="yyyy-MM-dd HH:mm:ss"></el-date-picker>
        </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="colSpan"> -->
        <el-form-item label="放款时间(止)"
                      :label-width="labelWidth">
          <el-date-picker v-model="queryData.transferDateEnd"
                          style="width:163px"
                          type="datetime"
                          value-format="yyyy-MM-dd HH:mm:ss"></el-date-picker>
        </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="colSpan"> -->
        <el-form-item label="付款状态"
                      :label-width="labelWidth">
          <el-select v-model="queryData.transferResult"
                     style="width:163px">
            <el-option :value="90"
                       label="放款失败"></el-option>
            <el-option :value="99"
                       label="放款成功"></el-option>
            <el-option :value="0"
                       label="待放款"></el-option>
          </el-select>
        </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="colSpan"> -->
        <el-form-item label="付款方式"
                      :label-width="labelWidth">
          <el-select v-model="queryData.channelWay"
                     style="width:163px">
            <el-option value="manual"
                       label="手动放款"></el-option>
            <el-option value="auto"
                       label="自动放款"></el-option>
          </el-select>
        </el-form-item>
        <!-- </el-col> -->
        <!-- </el-row> -->
        <div class="clearfix">
          <div style="float: right">
            <el-button type="primary"
                       size="mini"
                       @click="resetQuery">
              重置
            </el-button>
            <el-button type="primary"
                       size="mini"
                       @click="getTableData">
              查询
            </el-button>
            <el-button type="primary"
                       size="mini"
                       :loading="exportLoading"
                       @click="tableDownload">
              {{ this.exportLoading ? '下载中' : '表格下载' }}
            </el-button>
            <el-button type="primary"
                       size="mini"
                       @click="getTableData">
              刷新
            </el-button>
          </div>
        </div>
      </el-form>
    </div>
    <div class="data-table">
      <el-table border
                :data="tableData"
                :max-height="maxHeight">
        <el-table-column label="序号"
                         type="index"></el-table-column>
        <el-table-column label="申请编号"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.applyDisplayId }}
            <el-tag v-if="scope.row.specialPermit"
                    type="warning"
                    size="mini">
              特批
            </el-tag>
            <el-tag v-if="scope.row.reconsideration"
                    type="warning"
                    size="mini">
              复议
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="申请编号(老)"
                         align="center">
          <template slot-scope="scope">
            <!--老系统显示 oldApplyNo，新系统显示 '/'-->
            {{ scope.row.oldApplyNo || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="合同编号"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.contractNo }}
          </template>
        </el-table-column>
        <el-table-column label="客户名称"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.customerName }}
          </template>
        </el-table-column>
        <el-table-column label="融资总额"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.financingAmount }}
          </template>
        </el-table-column>
        <el-table-column label="计息金额"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.principal }}
          </template>
        </el-table-column>
        <el-table-column label="期数"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.term }}
          </template>
        </el-table-column>
        <el-table-column label="其他放款资方"
                         align="center">
          <template slot-scope="scope">
            {{ capitalDict[scope.row.capital] }}
          </template>
        </el-table-column>
        <el-table-column label="资方放款结果"
                         align="center">
          <template slot-scope="scope">
            {{ capitalLoanStatusDict[scope.row.capitalLoanStatus] }}
          </template>
        </el-table-column>
        <el-table-column label="资方放款金额"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.capitalLoanAmount }}
          </template>
        </el-table-column>
        <el-table-column label="付款金额"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.transferAmt }}
          </template>
        </el-table-column>
        <el-table-column label="车款付款额"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.carPriceAmt }}
          </template>
        </el-table-column>
        <el-table-column label="购置税付款额"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.purchaseTaxAmt }}
          </template>
        </el-table-column>
        <el-table-column label="保险款付款额"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.insuranceAmt }}
          </template>
        </el-table-column>
        <el-table-column label="GPS付款额"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.gpsAmt }}
          </template>
        </el-table-column>
        <el-table-column label="盗抢险付款额"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.theftProtectionAmt }}
          </template>
        </el-table-column>
        <el-table-column label="车融服务费付款额"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.financingFeeAmt }}
          </template>
        </el-table-column>
        <el-table-column label="收款账户名"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.accountName }}
          </template>
        </el-table-column>
        <el-table-column label="收款银行"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.bankName }}
          </template>
        </el-table-column>
        <el-table-column label="收款账号"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.account }}
          </template>
        </el-table-column>
        <el-table-column label="店面代码"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.dealerId }}
          </template>
        </el-table-column>
        <el-table-column label="店面名称"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.dealerName }}
          </template>
        </el-table-column>
        <el-table-column label="付款银行"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.channelBank }}
          </template>
        </el-table-column>
        <el-table-column label="付款账号"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.channelAccount }}
          </template>
        </el-table-column>
        <el-table-column label="小贷标识"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.isMicro ? '是' : '否' }}
          </template>
        </el-table-column>
        <el-table-column label="放款时间"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.transferDate }}
          </template>
        </el-table-column>
        <el-table-column label="付款状态"
                         align="center">
          <template slot-scope="scope">
            {{ transferResultDict[scope.row.transferResult] }}
          </template>
        </el-table-column>
        <el-table-column label="付款方式"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.channelWay }}
          </template>
        </el-table-column>
        <el-table-column label="操作人员"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.operateUsername }}
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        class="listPagination"
        :current-page="page.pageNum"
        :page-size="page.pageSize"
        :page-sizes="page.pageSizeArr"
        layout="total, sizes, prev, pager, next, jumper"
        :total="page.total"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange">
      </el-pagination>
    </div>
  </div>
</template>
<script>
  import {payHistory, payBank, historyPayGet} from '../../api/financialManage.js'
  import {checkApplyId} from '../../utils/constant'
  import {downLoadPolling} from '../../api/daihou' // 轮询接口通用
  const qs = require('qs')
  export default {
    data () {
      return {
        checkApplyId,
        colSpan: 6,
        labelWidth: '100px',
        tableData: [],
        maxHeight: 100,
        page: {
          pageNum: 1,
          pageSize: 10,
          pageSizeArr: [10, 20, 30, 40],
          total: 0,
        },
        queryData: {
          oldApplyNo: null,
          applyDisplayId: null,
          customerName: '',
          channelBank: null,
          isMicro: null,
          transferDateBegin: '',
          transferDateEnd: '',
          transferResult: null,
          channelWay: null,
        },
        payBankList: [],
        exportLoading: false,
        exportTimer: null,
        capitalLoanStatusDict: {
          0: '待放款',
          100: '失败',
          200: '成功',
          300: '处理中',
        },
        capitalDict: {
          '2345': '2345',
          'EX-ZB': '众邦银行',
          'EX-XW': '新网银行',
        },
        transferResultDict: {
          90: '放款失败',
          99: '放款成功',
          0: '待放款',
        },
      }
    },
    mounted () {
      this.getTableData()
      this.getPayBank()
      // 调整高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    destroyed () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // 表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let h = document.documentElement.clientHeight
          this.maxHeight = h - 250
        })
      },
      getPayBank () {
        payBank().then((res) => {
          if (res.data.respCode === '1000') this.payBankList = res.data.body
        }).catch((error) => { console.log(error) })
      },
      getTableData () {
        this.exportLoading = false
        const {pageNum, pageSize} = this.page
        this.queryData.pageNum = pageNum
        this.queryData.pageSize = pageSize
        return new Promise((resolve) => {
          payHistory(this.queryData).then((res) => {
            if (res.data.respCode === '1000') {
              const {list, total} = res.data.body
              this.tableData = list
              this.page.total = total
              resolve(1)
            } else {
              resolve(0)
            }
          }).catch((error) => {
            console.log(error)
          })
        })
      },
      resetQuery () {
        this.queryData = {
          applyDisplayId: null,
          customerName: '',
          channelBank: null,
          isMicro: null,
          transferDateBegin: '',
          transferDateEnd: '',
          transferResult: null,
          channelWay: null,
        }
        this.getTableData()
        this.exportLoading = false
      },
      tableDownload () {
        if (this.exportLoading) {
          this.$message.warning('文件正在生成')
          return false
        } else {
          this.getTableData().then((data) => {
            if (data && this.tableData.length !== 0) {
              historyPayGet(this.queryData).then((res) => {
                this.exportLoading = true // 开启loading
                if (res.data.respCode === '1000') {
                  let exportSerialNo = res.data.body.serialNo
                  clearInterval(this.exportTimer)
                  this.exportTimer = setInterval(() => {
                    downLoadPolling(exportSerialNo).then((res) => {
                      this.exportLoading = false
                      if (res.data.respCode === '1000') {
                        let data = res.data.body
                        if (data.status) {
                          clearInterval(this.exportTimer)
                          // 导出
                          window.location.href = process.env.VUE_APP_BASE_API + '/download/export?' + qs.stringify({filename: data.filename, storePath: data.storePath})
                        }
                      } else {
                        clearInterval(this.exportTimer)
                      }
                    }).catch((error) => { console.log(error) })
                  }, 1000)
                }
              }).catch((error) => { console.log(error) })
            } else {
              this.$message.warning('该筛选条件下无表格可下载')
            }
          })
        }
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.getTableData()
      },
      handleCurrentChange (val) {
        this.page.pageNum = val
        this.getTableData()
      },
    },
  }
</script>
<style lang="scss" scoped>
  .data-table{
    margin-top: 10px;
  }
  .listPagination{
    float: right;
    margin-top: 10px;
  }
</style>
