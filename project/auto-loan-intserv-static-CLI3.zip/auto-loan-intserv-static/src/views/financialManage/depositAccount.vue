<!--回款记录查询-->
<template>
  <div>
    <el-form size="small"
             label-position="left"
             :inline="true"
             class="sp-query-form">
      <el-form-item label="SP名称">
        <el-input v-model="queryData.dealerName"></el-input>
      </el-form-item>
      <el-form-item label="打款时间起">
        <el-date-picker v-model="queryData.payDateStart"
                        type="date"
                        value-format="yyyy-MM-dd"></el-date-picker>
      </el-form-item>
      <el-form-item label="打款时间止">
        <el-date-picker v-model="queryData.payDateEnd"
                        type="date"
                        value-format="yyyy-MM-dd"></el-date-picker>
      </el-form-item>
      <el-form-item>
        <div class="customer-query-reset">
          <el-button type="primary"
                     size="mini"
                     @click="getCustomerRepayList">
            查询
          </el-button>
          <el-button size="mini"
                     @click="resetQuery">
            重置
          </el-button>
          <el-button type="primary"
                     size="mini"
                     @click="templateDownload">
            模板下载
          </el-button>
          <el-upload
            class="import-file"
            accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel,text/plain"
            :data="importData"
            action=""
            :with-credentials="true"
            :http-request="importExeHandle"
            :show-file-list="false">
            <el-button size="small"
                       type="primary">
              导入
            </el-button>
          </el-upload>
          <el-button
            type="primary"
            size="mini"
            :loading="depositDownloadLoading"
            @click="tableDownload"
          >
            {{ depositDownloadLoading ? '导出中' : '导出' }}
          </el-button>
        </div>
      </el-form-item>
    </el-form>
    <div class="dataTableWrap">
      <el-table border
                :data="tableData">
        <el-table-column label="序号"
                         type="index"
                         align="center"></el-table-column>
        <el-table-column label="SP名称"
                         align="center"
                         prop="dealerName"></el-table-column>
        <el-table-column label="打款日期"
                         align="center"
                         prop="payDate">
          <template slot-scope="scope">
            {{ scope.row.payDate | parseTime("YYYY-MM-DD") }}
          </template>
        </el-table-column>
        <el-table-column label="对公打款金额"
                         align="center"
                         prop="corporatePayment">
          <template slot-scope="scope">
            <a href="javascript:;"
               @click="editSpHandle(scope.row, '对公打款金额', 'corporatePayment')">{{ scope.row.corporatePayment | twoFloat }}</a>
          </template>
        </el-table-column>
        <el-table-column label="收款银行"
                         align="center"
                         prop="receivingBank"></el-table-column>
        <el-table-column label="SP服务费抵充保证金"
                         align="center"
                         prop="spServiceFeeOffsetDeposit">
          <template slot-scope="scope">
            <a href="javascript:;"
               @click="editSpHandle(scope.row, 'SP服务费抵充保证金', 'spServiceFeeOffsetDeposit')">{{ scope.row.spServiceFeeOffsetDeposit | twoFloat }}</a>
          </template>
        </el-table-column>
        <el-table-column label="抵扣月租"
                         align="center"
                         prop="deductionMonthlyRent">
          <template slot-scope="scope">
            <a href="javascript:;"
               @click="editSpHandle(scope.row, '抵扣月租', 'deductionMonthlyRent')">{{ scope.row.deductionMonthlyRent | twoFloat }}</a>
          </template>
        </el-table-column>
        <el-table-column label="已退保证金"
                         align="center"
                         prop="refundedDeposit">
          <template slot-scope="scope">
            <a href="javascript:;"
               @click="editSpHandle(scope.row, '已退保证金', 'refundedDeposit')">{{ scope.row.refundedDeposit | twoFloat }}</a>
          </template>
        </el-table-column>
        <el-table-column label="待退回保证金"
                         align="center"
                         prop="readyRefundDeposit">
          <template slot-scope="scope">
            {{ scope.row.readyRefundDeposit | twoFloat }}
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <el-pagination
      class="listPagination"
      :current-page="page.currentPage"
      :page-size="page.pageSize"
      :page-sizes="page.pageSizesArr"
      layout="total, sizes, prev, pager, next, jumper"
      :total="page.total"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    ></el-pagination>

    <!-- 编辑 -->
    <el-dialog :title="dialogTile"
               :visible.sync="dialogFormVisible">
      <el-form ref="editForm"
               :model="editForm"
               :rules="rules">
        <el-form-item label=""
                      label-width="100"
                      prop="money">
          <el-input v-model="editForm.money"
                    autocomplete="off"
                    placeholder="请填写阿拉伯数字"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="dialogFormVisible = false">
          取 消
        </el-button>
        <el-button type="primary"
                   @click="dialogSubmitHandle">
          提交
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import {mapGetters} from 'vuex'
import { getDepositList, exportDepositList, importSPList, editDepositList } from '../../api/financialManage'
import {twoFloat} from '../../filters/index'
// const qs = require('qs')
export default {
  data () {
    let numReg = /^\d+(\.\d+)?$/
    let numValidator = (rule, value, callback) => {
      if (value.trim() === '' || !numReg.test(value)) {
        callback(new Error('录入框不能为空且必须为阿拉伯数字'))
      } else {
        callback()
      }
    }
    return {
      queryData: {
        dealerName: '',
        payDateEnd: '',
        payDateStart: '',
      },
      tableData: [],
      page: {
        currentPage: 1,
        pageSize: 10,
        pageSizesArr: [10, 20, 30, 40],
        total: 0,
      },
      importData: {},
      exportTimer: null,
      dialogTile: '',
      dialogFormVisible: false,
      editForm: {
        money: '',
        row: {},
        key: '',
      },
      rules: {
        money: [{required: true, validator: numValidator, trigger: 'blur'}],
      },
    }
  },
  computed: {
    ...mapGetters(['depositDownloadLoading']),
  },
  mounted () {
    this.getCustomerRepayList()
  },
  methods: {
    getCustomerRepayList () {
      if (this.queryData.payDateEnd && this.queryData.payDateStart) {
        if (
          new Date(this.queryData.payDateStart).getTime() >
          new Date(this.queryData.payDateEnd).getTime()
        ) {
          this.queryData.payDateEnd = ''
          this.queryData.payDateStart = ''
          this.$message.warning('放款月份起不得大于放款月份止')
        }
      }
      this.queryData.pageNum = this.page.currentPage
      this.queryData.pageSize = this.page.pageSize
      return new Promise((resolve, reject) => {
        getDepositList(this.queryData)
          .then((res) => {
            if (res.data.respCode === '1000') {
              let data = res.data.body
              this.tableData = data.list
              this.page.total = data.total
              resolve(1)
            } else {
              resolve(0)
            }
          })
          .catch((err) => {
            console.log(err)
            resolve(0)
          })
      })
    },
    resetQuery () {
      for (let k in this.queryData) {
        this.queryData[k] = null
      }
      this.getCustomerRepayList()
    },
    handleSizeChange (val) {
      this.page.pageSize = val
      this.getCustomerRepayList()
    },
    handleCurrentChange (val) {
      this.page.currentPage = val
      this.getCustomerRepayList()
    },
    // 编辑
    editSpHandle (row, title = '', key) {
      this.dialogTile = title
      this.dialogFormVisible = true
      this.editForm.money = ''
      this.editForm.key = key
      this.editForm.row = row
    },
    // 编辑提交
    dialogSubmitHandle () {
      this.$refs['editForm'].validate((valid) => {
        if (valid) {
          let {row, key, money: value} = this.editForm
          let data = Object.assign({}, row)
          data[key] = twoFloat(value)
          editDepositList(data).then((rst) => {
            this.dialogFormVisible = false
            let res = rst.data
            if (res.respCode === '1000') {
              this.$message.success('修改成功！')
              // row[key] = twoFloat(value)
              // row.readyRefundDeposit = Number(row.corporatePayment) + Number(row.spServiceFeeOffsetDeposit) - Number(row.deductionMonthlyRent)
              this.getCustomerRepayList()
            } else {
              this.$message.warning(res.respMsg)
            }
          })
        } else {
          return false
        }
      })
    },
    // 导入
    importExeHandle (item) {
      // FormData 对象
      const form = new window.FormData()
      // 文件对象
      form.append('billType', 'depositBill')
      form.append('inputStream', item.file)
      importSPList(form).then((rst) => {
        if (rst.data.respCode === '1000') {
          this.$message.success('导入数据成功！')
          this.getCustomerRepayList()
        } else {
          this.$message.warning(rst.data.respMsg)
        }
      })
    },
    async tableDownload () {
      if (this.depositDownloadLoading) {
        this.$message.warning('文件正在生成')
        return false
      }
      let lists = await this.getCustomerRepayList()
      if (lists && this.tableData.length > 0) {
        exportDepositList(this.queryData)
          .then((res) => {
            if (res.data.respCode === '1000') {
              let exportSerialNo = res.data.body.serialNo
              if (!exportSerialNo) return false
              this.$store.dispatch('downloadPollingApi', {
                serialNo: exportSerialNo,
                timer: 'exportTimer',
                notification: 'spReportNotification',
                loading: 'depositDownloadLoading',
              })
            }
          })
          .catch((err) => {
            console.log(err)
          })
      } else {
        this.$message.warning('该筛选条件下无表格可下载')
      }
    },
    // 模板下载
    templateDownload () {
      window.location.href = process.env.VUE_APP_BASE_API + '/finance/excel/download/depositBillTemplate'
    },
  },
}
</script>
<style lang="scss" scoped>
.listPagination {
  float: right;
  margin-top: 5px;
}
.import-file{
  display:inline-block;
  .el-button--small{
    padding: 7px 15px;
  }
}
.dataTableWrap{
  a{
    color: #627cf1;
  }
}
</style>
<style lang="scss">
.sp-query-form {
  .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 140px;
  }
}
</style>

