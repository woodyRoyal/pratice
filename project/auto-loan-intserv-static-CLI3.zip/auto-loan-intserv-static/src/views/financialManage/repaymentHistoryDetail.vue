<template>
  <div class="write-off-check-detail-outerWrap">
    <h3 class="detail-wrap-title">
      <span v-if="bookType === 1">租金勾稽</span>
      <span v-if="bookType === 2">提前结清勾稽</span>
      <span v-if="bookType === 3">回购</span>
      <i>当前资方：<el-tag type="danger" size="mini">{{currentCapitalName}}</el-tag></i>
    </h3>
    <div class="formModuleTitle">
      <span>客户还款信息</span>
      <i v-if="bookType === 3">（回购总金额仅包含资方非自有且所有未结清的期次）</i>
    </div>
    <div>
      <!--租金勾稽-->
      <el-form size="small" label-position="left" :model='rentWriteOffData' ref='rentWriteOffData' v-if="bookType === 1" key="rentWriteOff">
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="当前应还总金额" label-width="114px" class="is-required">
              <el-input disabled v-model="rentWriteOffData.currentNeedRepay"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="实际应还款金额" label-width="114px" class="is-required">
              <el-input disabled v-model="rentWriteOffData.adjustedNeedRepayAmount"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="勾稽余额" label-width="72px" class="is-required">
              <el-input disabled v-model="writeOffAmount"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="放款主体" label-width="72px" class="is-required">
              <el-input disabled v-model="rentWriteOffData.loanOrg"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="到账金额" label-width="72px" class="is-required">
              <el-input v-model="rentWriteOffData.transferAmount" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="减免金额" label-width="72px">
              <el-input v-model="rentWriteOffData.otherExemption" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="勾稽金额" label-width="72px" class="is-required">
              <el-input disabled v-model="rentWriteOffData.bookAmount"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="网银/流水编号" label-width="96px">
              <el-input maxlength="50" v-model="rentWriteOffData.externalRepayFlowNo" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="预计到账时间" label-width="100px" class="is-required">
              <el-date-picker type="date" v-model="rentWriteOffData.expectedTransferTime" value-format="yyyy-MM-dd" disabled></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="到账银行" label-width="72px" class="is-required">
              <el-select v-model="rentWriteOffData.dueBank" disabled>
                <el-option v-for="(item, index) in dueBankItemList" :key="index" :value="item.bankCode" :label="item.bankName"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="到账账号" label-width="72px" class="is-required">
              <el-select v-model="rentWriteOffData.dueAccount" disabled>
                <el-option v-for="(item, index) in dueBankAccountList" :key="index" :value="item" :label="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <!--提前结清租金勾稽-->
      <el-form size="small" label-position="left" :model='beforeRentWriteOffData' ref="beforeRentWriteOffData" v-if="bookType === 2" key="beforeRentWriteOff">
        <el-row :gutter="10">
          <el-col :span="15">
            <el-form-item label="条件" label-width="33px">
              <el-checkbox-group disabled v-model="beforeRentWriteOffData.conditionList">
                <el-checkbox :label="1">满6个月</el-checkbox>
                <el-checkbox :label="2">有欠款</el-checkbox>
                <el-checkbox :label="3">下期还款日-当前日期 > 10天</el-checkbox>
              </el-checkbox-group>
            </el-form-item>
          </el-col>
          <el-col :span="9">
            <div class="redSign" style="margin-top: 8px">特殊提前还款必须上传提前还款说明书</div>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="约定扣款日期" label-width="100px" prop="agreedTransferDate">
              <el-date-picker type="date" value-format="yyyy-MM-dd" v-model="beforeRentWriteOffData.agreedTransferDate" disabled></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="是否特殊还款" label-width="104px" prop="special">
              <el-select v-model="beforeRentWriteOffData.special" disabled>
                <el-option :value="1" label="是"></el-option>
                <el-option :value="0" label="不是"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="提前结清类型" label-width="104px" prop="advanceType">
              <el-select v-model="beforeRentWriteOffData.advanceType" disabled>
                <el-option v-for="(val, key, index) in dict.advanceTypeDict" :key="index" :value="key" :label="val"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="勾稽余额" label-width="72px" class="is-required">
              <el-input disabled v-model="writeOffAmount"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="剩余本金" label-width="72px" class="is-required">
              <el-input disabled v-model="beforeRentWriteOffData.totalRemainPrincipal"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="应还款总金额" label-width="100px" class="is-required">
              <el-input disabled v-model="beforeRentWriteOffData.currentNeedRepay"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="应还本金" label-width="72px" class="is-required">
              <el-input disabled v-model="beforeRentWriteOffData.remainPrincipal"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="应还利息" label-width="72px" class="is-required">
              <el-input disabled v-model="beforeRentWriteOffData.remainInterest"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="应还罚息" label-width="72px" class="is-required">
              <el-input disabled v-model="beforeRentWriteOffData.remainOverduePenalty"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="提前还款违约金" label-width="114px" class="is-required">
              <el-input disabled v-model="beforeRentWriteOffData.remainAdvancePenalty"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="应还费用" label-width="72px" class="is-required">
              <el-input disabled v-model="beforeRentWriteOffData.remainFee"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="其他计收金额" label-width="104px" prop="otherCollection">
              <el-input v-model="beforeRentWriteOffData.otherCollection" disabled>
              </el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="其他免收金额" label-width="100px" prop="otherExemption">
              <el-input v-model="beforeRentWriteOffData.otherExemption" disabled>
              </el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8" class="form-item-red">
            <el-form-item label="实际应还款金额" label-width="114px" class="is-required">
              <el-input disabled v-model="beforeRentWriteOffData.adjustedNeedRepayAmount"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="放款主体" label-width="72px" class="is-required">
              <el-input disabled v-model="beforeRentWriteOffData.loanOrg"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="到账金额" label-width="72px" prop="transferAmount">
              <el-input v-model="beforeRentWriteOffData.transferAmount" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="勾稽金额" label-width="72px" class="is-required">
              <el-input disabled v-model="beforeRentWriteOffData.bookAmount"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="网银/流水编号" label-width="103px">
              <el-input v-model="beforeRentWriteOffData.externalRepayFlowNo" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="预计到账时间" label-width="100px" prop="expectedTransferTime">
              <el-date-picker type="date" value-format="yyyy-MM-dd" class="w171px" v-model="beforeRentWriteOffData.expectedTransferTime" disabled></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="到账银行" label-width="72px" prop="dueBank">
              <el-select v-model="beforeRentWriteOffData.dueBank" disabled>
                <el-option v-for="(item, index) in dueBankItemList" :key="index" :value="item.bankCode" :label="item.bankName"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="到账账号" label-width="72px" prop="dueAccount">
              <el-select v-model="beforeRentWriteOffData.dueAccount" disabled>
                <el-option v-for="(item, index) in dueBankAccountList" :key="index" :value="item" :label="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <!--回购-->
      <el-form size="small" label-position="left" :model="buyBackData" ref="buyBackRef" class="buy-back-form" v-if="bookType === 3" key="buyBack">
        <el-row>
          <el-col :span="6">
            <el-form-item label="回购总金额" label-width="128px" class="is-required">
              <el-input v-model="buyBackData.buybackAmount" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="repayment-confirm-detail-formWrap">
      <template v-if="repayBankInfos.length > 0">
        <div v-for="(repayBankInfo, idx) in repayBankInfos" :key="idx">
          <el-form size="small" label-position="left" :model="repayBankInfo" ref="buyBackRef" class="buy-back-form" key="repayBankInfos">
            <el-row :gutter="10">
              <el-col :span="6">
                <el-form-item label="付款日期" label-width="80px" class="is-required">
                  <el-date-picker type="date" disabled value-format="yyyy-MM-dd" v-model="repayBankInfo.repayDate"></el-date-picker>
                </el-form-item>
              </el-col>
              <el-col :span="6">
                <el-form-item label="付款人" label-width="66px" class="is-required">
                  <el-input disabled v-model="repayBankInfo.repayName"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="6">
                <el-form-item label="付款流水号" label-width="88px" prop="repaySerialNo">
                  <el-input v-model="repayBankInfo.repaySerialNo" disabled></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="6">
                <el-form-item label="付款金额" label-width="80px" class="is-required">
                  <el-input v-model="repayBankInfo.repayAmt" disabled></el-input>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>    
      </template> 
    </div>  

    <div class="write-off-dialog-btns">
      <el-button type="primary" size="mini" @click="showFileuploadDialog">查看凭证</el-button>
    </div>
    <approveHistory :approveHistoryData="approveHistoryData"></approveHistory>
    <!--文件上传弹窗-->
    <el-dialog title="凭证" :visible.sync="fileDialogVisible" :show-close="false">
      <FileUpload :pictureList="pictureList" :history="1"></FileUpload>
      <div slot="footer" class="dialog-footer">
        <el-button @click="fileDialogVisible = false" size="mini">关 闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import {checkApplyId, fmoney} from '../../utils/constant'
  import FileUpload from '../../components/DialoginnerFileupload/fileupload'
  import RepayPlanTable from './repayPlanTable'
  import {rentRepaymentInfo, dueBankList, dict, approveHistoryList, repaymentPlans} from '../../api/financialManage'
  import {financialGetFile} from '../../api/upload.js'
  import approveHistory from './approveHistory'
  export default {
    data () {
      return {
        checkApplyId,
        fmoney,
        dict,
        fileDialogVisible: false,
        page: {
          pageNum: 1,
          pageSize: 5,
          pageSizeArr: [5, 10, 15, 20],
          total: 0
        },
        bookId: null,
        bookType: null,
        applyId: null,
        userId: null,
        billLoanNo: null,
        currentCapitalName: '',
        repayBankInfos: [],
        rentWriteOffData: {
          currentNeedRepay: null,
          adjustedNeedRepayAmount: '', // 调整后实际应还金额
          loanOrg: '',
          transferAmount: null,
          otherExemption: '0.00', // 减免金额
          bookAmount: null,
          externalRepayFlowNo: '',
          expectedTransferTime: '',
          dueBank: null,
          dueAccount: null,
          addedBalance: null // 本次新增勾稽余额
        }, // 租金勾稽
        beforeRentWriteOffData: {
          conditionList: [],
          agreedTransferDate: '',
          special: 0,
          advanceType: null,
          totalRemainPrincipal: '',
          currentNeedRepay: null,
          remainPrincipal: null,
          remainInterest: null,
          remainOverduePenalty: null,
          remainAdvancePenalty: null,
          remainFee: null,
          otherCollection: '0.00', // 其他计收金额
          otherExemption: '0.00', // 其他免除金额
          adjustedNeedRepayAmount: null,
          loanOrg: '',
          transferAmount: null,
          bookAmount: null,
          externalRepayFlowNo: '',
          expectedTransferTime: '',
          dueBank: null,
          dueAccount: null,
          addedBalance: null // 本次新增勾稽余额
        }, // 提前结清勾稽
        buyBackData: {
          buybackAmount: '0.00'
        }, // 回购
        dueBankItemList: [], // 到账银行
        dueBankAccountList: [], // 到账账号
        writeOffAmount: null, // 勾稽余额
        pictureList: [{
          dictKey: 'book_file',
          fileRecordVOList: [],
          name: '还款勾稽凭证'
        }],
        // rentRepaymentInfoData: {},
        approveHistoryData: []
      }
    },
    mounted () {
      const {bookId, bookType, applyId, userId, billLoanNo} = this.$route.params
      this.bookId = bookId ? +bookId : null
      this.bookType = bookType ? +bookType : null
      this.applyId = applyId ? +applyId : null
      this.userId = userId ? +userId : null
      this.billLoanNo = billLoanNo || null
      this.getRepaymentPlans()
      this.getFormValue() // 获取整个表单的信息
      this.fileGet() // 文件信息
      this.getApproveHistoryList()
    },
    components: {RepayPlanTable, FileUpload, approveHistory},
    methods: {
      async getFormValue () {
        let flag = null
        let dueBank = null
        try {
          flag = await this.getRentRepaymentInfo()
        } catch (e) {
          return false
        }
        if (flag && (this.bookType !== 3)) {
          try {
            dueBank = await this.getDueBankList()
          } catch (e) {
            return false
          }
          if (dueBank) this.dueBankChange()
        }
      },
      // 查询还款计划
      getRepaymentPlans () {
        repaymentPlans(this.userId, this.billLoanNo, this.applyId).then(res => {
          if (res.data.respCode === '1000') {
            const {applyCapitalName} = res.data.body
            this.currentCapitalName = applyCapitalName
          }
        }).catch(err => { console.log(err) })
      },
      // 数据拉取
      getRentRepaymentInfo () {
        return new Promise((resolve, reject) => {
          rentRepaymentInfo(this.bookId).then(res => {
            if (res.data.respCode === '1000') {
              let data = res.data.body
              const {buybackAmount, repaymentAdvanceSettleDetailVO, repayBankInfo} = data
              let calculateInfoData = repaymentAdvanceSettleDetailVO // 原本计算接口返回值
              // 到账银行信息
              this.getRepayBanksHandle(repayBankInfo)
              if (this.bookType === 1) this.valToRentWriteOff(data)
              if (this.bookType === 2) this.valToBeforeRentWriteOff(data, calculateInfoData)
              if (this.bookType === 3) this.buyBackData.buybackAmount = fmoney(buybackAmount / 100) // 回购 回购总金额
              resolve(1)
            }
          }).catch(err => { reject(err) })
        })
      },
      // 到账银行信息
      getRepayBanksHandle (arr) {
        this.repayBankInfos = arr
        this.repayBankInfos.map(item => {
          this.fmoneyHandle(item, item.repayAmt / 100)
        })
      },
      // 格式化金额
      fmoneyHandle (item, v) {
        let m = fmoney(v, 2)
        item.repayAmt = m
      },
      // 租金勾稽赋值操作
      valToRentWriteOff (res) {
        const {expectedTransferTime, dueBank, dueAccount, loanOrg, externalRepayFlowNo, addedBalance, transferAmount, otherExemption, bookAmount, currentNeedRepayAmount, adjustedNeedRepayAmount} = res
        this.rentWriteOffData.expectedTransferTime = expectedTransferTime.substring(0, 10)
        this.rentWriteOffData.dueBank = dueBank
        this.rentWriteOffData.dueAccount = dueAccount
        this.rentWriteOffData.loanOrg = loanOrg
        this.rentWriteOffData.externalRepayFlowNo = externalRepayFlowNo
        this.writeOffAmount = fmoney(addedBalance / 100) // 勾稽余额
        this.rentWriteOffData.transferAmount = fmoney(transferAmount / 100) // 到账金额
        this.rentWriteOffData.otherExemption = fmoney(otherExemption / 100) // 减免金额
        this.rentWriteOffData.bookAmount = fmoney(bookAmount / 100) // 元 // 勾稽金额
        this.rentWriteOffData.currentNeedRepay = fmoney(currentNeedRepayAmount / 100) // 元
        this.rentWriteOffData.adjustedNeedRepayAmount = fmoney(adjustedNeedRepayAmount / 100) // 元
      },
      // 提前结清勾稽赋值操作
      valToBeforeRentWriteOff (res, calculateInfoData) {
        const {expectedTransferTime, dueBank, dueAccount, agreedTransferDate, advanceType, special, loanOrg, externalRepayFlowNo, otherCollection, otherExemption, addedBalance, adjustedNeedRepayAmountCalculated, transferAmount, bookAmountCalculated, addedBalanceCalculated} = res
        this.beforeRentWriteOffData.expectedTransferTime = expectedTransferTime.substring(0, 10)
        this.beforeRentWriteOffData.dueBank = dueBank
        this.beforeRentWriteOffData.dueAccount = dueAccount
        this.beforeRentWriteOffData.agreedTransferDate = agreedTransferDate.substring(0, 10)
        this.beforeRentWriteOffData.conditionList = calculateInfoData.conditionList
        this.beforeRentWriteOffData.advanceType = advanceType + ''
        this.beforeRentWriteOffData.special = special
        this.beforeRentWriteOffData.loanOrg = loanOrg
        this.beforeRentWriteOffData.externalRepayFlowNo = externalRepayFlowNo
        this.beforeRentWriteOffData.otherCollection = fmoney(otherCollection / 100) // 其他计收
        this.beforeRentWriteOffData.otherExemption = fmoney(otherExemption / 100) // 其他免收
        this.writeOffAmount = fmoney(addedBalance / 100) // 勾稽余额
        this.beforeRentWriteOffData.totalRemainPrincipal = fmoney(calculateInfoData.totalRemainPrincipal / 100) // 剩余本金
        this.beforeRentWriteOffData.currentNeedRepay = fmoney(calculateInfoData.currentNeedRepay / 100)// 应还款总金额
        this.beforeRentWriteOffData.remainPrincipal = fmoney(calculateInfoData.remainPrincipal / 100)// 应还本金
        this.beforeRentWriteOffData.remainInterest = fmoney(calculateInfoData.remainInterest / 100)// 应还利息
        this.beforeRentWriteOffData.remainOverduePenalty = fmoney(calculateInfoData.remainOverduePenalty / 100)// 应还罚息
        this.beforeRentWriteOffData.remainAdvancePenalty = fmoney(calculateInfoData.remainAdvancePenalty / 100)// 提前还款违约金
        this.beforeRentWriteOffData.adjustedNeedRepayAmount = fmoney(adjustedNeedRepayAmountCalculated / 100) // 实际应还款金额
        this.beforeRentWriteOffData.transferAmount = fmoney(transferAmount / 100) // 到账金额
        this.beforeRentWriteOffData.remainFee = fmoney(calculateInfoData.remainFee / 100) // 应还费用
        this.beforeRentWriteOffData.bookAmount = fmoney(bookAmountCalculated / 100) // 元 // 勾稽金额
        this.beforeRentWriteOffData.addedBalance = addedBalanceCalculated // 分 // 本次新增的勾稽余额
      },
      // 凭证查看
      fileGet () {
        let data = {applyId: this.bookId, dictCategory: ['repayment_book_file'].join(',')}
        financialGetFile(data).then(res => {
          if (res.data.respCode === '1000') {
            const {pictureListVOList} = res.data.body
            this.pictureList = pictureListVOList
          }
        })
      },
      // 到账银行、账号
      getDueBankList () {
        return new Promise((resolve, reject) => {
          dueBankList(this.applyId).then(res => {
            if (res.data.respCode === '1000') {
              const {bankAccounts} = res.data.body
              this.dueBankItemList = bankAccounts
              resolve(1)
            }
          }).catch(err => { reject(err) })
        })
      },
      // 到账银行切换
      dueBankChange () {
        if (this.dueBankItemList.length > 0) {
          this.dueBankItemList.forEach(item => {
            if (this.bookType === 1) {
              if (item.bankCode === this.rentWriteOffData.dueBank) this.dueBankAccountList = item.dueAccounts
            } else {
              if (item.bankCode === this.beforeRentWriteOffData.dueBank) this.dueBankAccountList = item.dueAccounts
            }
          })
        }
      },
      // 查看凭证
      showFileuploadDialog () {
        this.fileDialogVisible = true
        this.fileGet()
      },
      // 审批历史
      getApproveHistoryList () {
        approveHistoryList(this.bookId).then(res => {
          if (res.data.respCode === '1000') this.approveHistoryData = res.data.body
        }).catch(err => { console.log(err) })
      }
    }
  }
</script>

<style scoped lang="scss">
  .write-off-check-detail-outerWrap{
    box-sizing: border-box;
    padding: 5px 10px;
  }

  .detail-wrap-title{
    margin: 0;
    font-weight: 700;
    height: 30px;
    line-height: 30px;
    color: #fff;
    background: #409eff;
    padding: 5px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    > i {
      font-style: normal;
      font-size: 12px;
      color: #fff;
      margin-left: 8px;
    }
  }

  .formModuleTitle {
    > i {
      font-style: normal;
      font-size: 12px;
      color: #333;
      margin-left: 8px;
      height: 30px;
      line-height: 30px;
    }
  }

  .write-off-dialog-btns{
    display: flex;
    flex-direction: row;
    justify-content: center;
  }

  .buy-back-form{
    > div {
      & + div {
        padding-top: 18px;
        border-top: 1px solid #ccc;
      }
    }
  }
</style>
