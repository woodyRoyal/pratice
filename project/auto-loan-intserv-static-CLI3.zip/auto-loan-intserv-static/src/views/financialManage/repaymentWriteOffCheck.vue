<template>
  <div>
    <el-form size="small" label-position="left" :inline="true">
      <!-- <el-row :gutter="10"> -->
        <!-- <el-col :span="6"> -->
          <el-form-item label="申请编号" label-width="68px">
            <el-input v-model="queryData.applyDisplayId" @blur="checkApplyId(queryData.applyDisplayId)" maxlength="8"></el-input>
          </el-form-item>
          <el-form-item label="申请编号(老)" :label-width="'100px'">
              <el-input maxlength="7" v-model="queryData.oldApplyNo" @blur="checkApplyId(queryData.oldApplyNo,'oldApplyNo',7)" placeholder="申请编号(老)" onkeypress='return(/^[0-9]*$/.test(String.fromCharCode(event.keyCode)))'></el-input>
            </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="6"> -->
          <el-form-item label="客户名称" label-width="68px">
            <el-input v-model="queryData.customerName" @blur="emptyNameCheck(queryData.customerName)"></el-input>
          </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="6"> -->
          <el-form-item label="勾稽类型" label-width="68px">
            <el-select v-model="queryData.bookType">
              <el-option v-for="(key, value, index) in dict.bookTypeDict" :key="index" :value="value" :label="key"></el-option>
            </el-select>
          </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="6"> -->
          <el-button type="primary" size="mini" @click="resetQuery">重置</el-button>
          <el-button type="primary" size="mini" @click="getRepayWriteOffCheckList">查询</el-button>
        <!-- </el-col> -->
      <!-- </el-row> -->
    </el-form>
    <div class="dataTable">
      <el-table :data="tableData" border>
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="申请编号">
          <template slot-scope="scope">
            {{scope.row.applyDisplayId || '/'}}
            <el-tag type="warning" size="mini" v-if="scope.row.specialPermit">特批</el-tag>
            <el-tag type="warning" size="mini" v-if="scope.row.reconsideration">复议</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="申请编号(老)">
          <template slot-scope="scope">
            <!--老系统显示 oldApplyNo，新系统显示 '/'-->
            {{scope.row.oldApplyNo || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="客户名称">
          <template slot-scope="scope">
            {{scope.row.customerName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="企业/挂靠名称">
          <template slot-scope="scope">
            {{scope.row.companyName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="勾稽类型">
          <template slot-scope="scope">
            {{dict.bookTypeDict[scope.row.bookType] || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="预计到账时间">
          <template slot-scope="scope">
            {{scope.row.expectedTransferTime || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="收款银行">
          <template slot-scope="scope">
            {{scope.row.dueBankName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="勾稽申请时间">
          <template slot-scope="scope">
            {{scope.row.createAt || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="勾稽申请操作员">
          <template slot-scope="scope">
            {{scope.row.operatorName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="text" size="mini" @click="toDetail(scope.row)">查看详情</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="page.pageNum" :page-sizes="page.pageSizes"
                     :page-size="page.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="page.total">
      </el-pagination>
    </div>
  </div>
</template>

<script>
  import {checkApplyId} from '../../utils/constant'
  import {dict, repayWriteOffCheckList} from '../../api/financialManage'
  export default {
    data () {
      return {
        dict,
        checkApplyId,
        // todo 和server端沟通入参默认值
        queryData: {
          oldApplyNo: null,
          applyDisplayId: null,
          customerName: null,
          bookType: null
        },
        tableData: [],
        page: {
          pageNum: 1,
          pageSize: 10,
          pageSizes: [10, 20, 30, 40],
          total: 0
        }
      }
    },
    mounted () {
      this.getRepayWriteOffCheckList()
    },
    methods: {
      getRepayWriteOffCheckList () {
        this.queryData.pageNum = this.page.pageNum
        this.queryData.pageSize = this.page.pageSize
        repayWriteOffCheckList(this.queryData).then(res => {
          if (res.data.respCode === '1000') {
            const {list, total} = res.data.body
            this.tableData = list
            this.page.total = total
          }
        }).catch(err => { console.log(err) })
      },
      resetQuery () {
        for (let k in this.queryData) {
          this.queryData[k] = null
        }
        this.getRepayWriteOffCheckList()
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.getRepayWriteOffCheckList()
      },
      handleCurrentChange (val) {
        this.page.pageNum = val
        this.getRepayWriteOffCheckList()
      },
      toDetail (row) {
        window.open(`#/repayment-write-off-check-detail/${row.bookType}/${row.bookId}/${row.applyId}/${row.userId}/${row.billLoanNo}`)
      },
      emptyNameCheck (val) {
        if (val !== null && val.trim() === '') {
          this.queryData.customerName = null
        }
      }
    }
  }
</script>

<style scoped>

</style>
