<!--还款-还款勾稽页-->
<template>
  <div class="write-off-outerWrap">
    <el-form size="small"
             label-position="left"
             :inline="true">
      <!-- <el-row :gutter="10"> -->
      <!-- <el-col :span="8"> -->
      <el-form-item label="申请编号"
                    label-width="68px">
        <el-input v-model="queryData.applyDisplayId"
                  maxlength="8"
                  @blur="checkApplyId(queryData.applyDisplayId)"></el-input>
      </el-form-item>
      <el-form-item label="申请编号(老)"
                    label-width="100px">
        <el-input v-model="queryData.oldApplyNo"
                  maxlength="7"
                  placeholder="申请编号(老)"
                  onkeypress="return(/^[0-9]*$/.test(String.fromCharCode(event.keyCode)))"
                  @blur="checkApplyId(queryData.oldApplyNo,'oldApplyNo',7)"></el-input>
      </el-form-item>
      <!-- </el-col> -->
      <!-- <el-col :span="8"> -->
      <el-form-item label="客户名称"
                    label-width="68px">
        <el-input v-model="queryData.customerName"
                  maxlength="20"></el-input>
      </el-form-item>
      <!-- </el-col> -->
      <!-- <el-col :span="8"> -->
      <el-button type="primary"
                 size="mini"
                 @click="resetRepaymentWriteOffListQuery">
        重置
      </el-button>
      <el-button type="primary"
                 size="mini"
                 @click="getRepaymentWriteOffList">
        查询
      </el-button>
      <!-- </el-col> -->
      <!-- </el-row> -->
    </el-form>
    <div class="dataTable">
      <el-table :data="tableData"
                border>
        <el-table-column label="申请编号">
          <template slot-scope="scope">
            {{ scope.row.applyDisplayId || '/' }}
            <el-tag v-if="scope.row.specialPermit"
                    type="warning"
                    size="mini">
              特批
            </el-tag>
            <el-tag v-if="scope.row.reconsideration"
                    type="warning"
                    size="mini">
              复议
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="申请编号(老)">
          <template slot-scope="scope">
            <!--老系统显示 oldApplyNo，新系统显示 '/'-->
            {{ scope.row.oldApplyNo || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="客户名称">
          <template slot-scope="scope">
            {{ scope.row.customerName || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="申请类型">
          <template slot-scope="scope">
            {{ applyType[scope.row.applyType] || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="企业/挂靠名称">
          <template slot-scope="scope">
            {{ scope.row.companyName || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="text"
                       size="mini"
                       :disabled="!scope.row.buyBackValid"
                       @click="dialogShowHandle(scope.row, 2)">
              回 购
            </el-button>
            <el-button type="text"
                       size="mini"
                       @click="dialogShowHandle(scope.row, 0)">
              租金勾稽
            </el-button>
            <el-button type="text"
                       size="mini"
                       @click="dialogShowHandle(scope.row, 1)">
              提前结清勾稽
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!--租金勾稽/提前结清勾稽/回购 弹窗-->
    <el-dialog :title="dialogTitleDict[dialogStatus]"
               :visible.sync="dialogVisible"
               :close-on-click-modal="false"
               width="75%"
               class="write-off-dialog"
               @close="rentWriteOffClosed">
      <div v-if="tableData.length>0">
        <span class="font-bold">申请编号：</span>{{ tableData[0].applyDisplayId || '/' }}
        <span class="font-bold">申请编号(老)：</span>{{ tableData[0].oldApplyNo || '/' }}
        <span class="font-bold">客户名称：</span>{{ tableData[0].customerName || '/' }}
        <span class="font-bold">申请类型：</span>{{ applyType[tableData[0].applyType] || '/' }}
        <span class="font-bold">企业/挂靠名称：</span>{{ tableData[0].companyName || '/' }}
      </div>
      <!--新网：EX-XW， 众邦：EX-ZB ，2345自有：2345-->
      <!--billLoanType 借据类型 0-普通借据 1-联合贷借据-->
      <el-radio-group v-if="billLoanType"
                      v-model="activeName"
                      size="mini"
                      style="margin-bottom: 10px;"
                      @change="activeChange">
        <el-radio-button label="all">
          整体
        </el-radio-button>
        <el-radio-button label="EX-ZB">
          众邦
        </el-radio-button>
        <el-radio-button label="2345">
          2345
        </el-radio-button>
      </el-radio-group>
      <!--还款计划表-->
      <RepayPlanTable :repayment-list="repaymentList"
                      :current-capital-name="currentCapitalName"
                      @listenGetRepaymentPlans="listenGetRepaymentPlans"></RepayPlanTable>
      <div class="formModuleTitle">
        <span>客户还款信息</span>
        <i v-if="Number(dialogStatus) === 2">（回购总金额仅包含资方非自有且所有未结清的期次）</i>
      </div>
      <div>
        <!--租金勾稽-->
        <el-form v-if="dialogStatus === 0"
                 ref="rentWriteOffData"
                 key="rentWriteOff"
                 size="small"
                 label-position="left"
                 :model="rentWriteOffData"
                 :rules="rentWriteOffDataRule">
          <el-row :gutter="10">
            <el-col :span="6">
              <el-form-item label="当前应还总金额"
                            label-width="114px"
                            class="is-required">
                <el-input v-model="rentWriteOffData.currentNeedRepay"
                          disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="实际应还款金额"
                            label-width="114px"
                            class="is-required">
                <el-input v-model="rentWriteOffData.adjustedNeedRepayAmount"
                          disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="勾稽余额"
                            label-width="72px"
                            class="is-required">
                <el-input v-model="writeOffAmount"
                          disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="放款主体"
                            label-width="72px"
                            class="is-required">
                <el-input v-model="rentWriteOffData.loanOrg"
                          disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="6">
              <el-form-item label="到账金额"
                            label-width="72px"
                            prop="transferAmount">
                <el-input v-model="rentWriteOffData.transferAmount"
                          @blur="formatTransferAmount('rentWriteOffData')"
                          @focus="recoveryTransferAmount"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="减免金额"
                            label-width="72px">
                <el-input v-model="rentWriteOffData.otherExemption"
                          @blur="formatRentWriteOffOtherExemption('rentWriteOffData')"
                          @focus="recoveryRentWriteOffOtherExemption"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="勾稽金额"
                            label-width="72px"
                            class="is-required">
                <el-input v-model="rentWriteOffData.bookAmount"
                          disabled></el-input>
              </el-form-item>
            </el-col>
            <!-- <el-col :span="6">
              <el-form-item label="网银/流水编号"
                            label-width="96px">
                <el-input v-model="rentWriteOffData.externalRepayFlowNo"
                          maxlength="50"></el-input>
              </el-form-item>
            </el-col> -->
          </el-row>
          <el-row :gutter="10">
            <el-col :span="6">
              <el-form-item label="预计到账时间"
                            label-width="100px"
                            prop="expectedTransferTime">
                <el-date-picker v-model="rentWriteOffData.expectedTransferTime"
                                type="date"
                                value-format="yyyy-MM-dd"></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="到账银行"
                            label-width="72px"
                            prop="dueBank">
                <el-select v-model="rentWriteOffData.dueBank"
                           @change="dueBankChange">
                  <el-option v-for="(item, index) in dueBankItemList"
                             :key="index"
                             :value="item.bankCode"
                             :label="item.bankName"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="到账账号"
                            label-width="72px"
                            prop="dueAccount">
                <el-select v-model="rentWriteOffData.dueAccount">
                  <el-option v-for="(item, index) in dueBankAccountList"
                             :key="index"
                             :value="item"
                             :label="item"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="勾稽余额使用"
                            label-width="90px"
                            prop="balanceUseMethod">
                <el-select v-model="rentWriteOffData.balanceUseMethod"
                           @change="changeRentWriteOffData('rentWriteOffData','change')">
                  <el-option v-for="(item, index) in balanceUseMethodList"
                             :key="index"
                             :value="item.key"
                             :label="item.name"
                             :disabled="item.status"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="勾稽资金来源"
                            label-width="100px"
                            prop="repaymentBookCapitalSource">
                <el-select v-model="rentWriteOffData.repaymentBookCapitalSource">
                  <el-option v-for="(item, index) in sourceList"
                             :key="index"
                             :value="item.value"
                             :label="item.key"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="24">
              <el-form-item label="备注信息"
                            label-width="72px"
                            prop="remark">
                <el-input v-model="rentWriteOffData.remark"
                          type="textarea"
                          maxlength="500"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <!--提前结清租金勾稽-->
        <el-form v-if="dialogStatus === 1"
                 ref="beforeRentWriteOffData"
                 key="beforeRentWriteOff"
                 size="small"
                 label-position="left"
                 :model="beforeRentWriteOffData"
                 :rules="beforeRentWriteOffDataRule">
          <el-row :gutter="10">
            <el-col :span="15">
              <el-form-item label="条件"
                            label-width="33px">
                <el-checkbox-group v-model="beforeRentWriteOffData.conditionList"
                                   disabled>
                  <el-checkbox :label="1">
                    满6个月
                  </el-checkbox>
                  <el-checkbox :label="2">
                    有欠款
                  </el-checkbox>
                  <el-checkbox :label="3">
                    下期还款日-当前日期 > 10天
                  </el-checkbox>
                </el-checkbox-group>
              </el-form-item>
            </el-col>
            <el-col :span="9">
              <div class="redSign"
                   style="margin-top: 8px">
                特殊提前还款必须上传提前还款说明书
              </div>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="8">
              <el-form-item label="约定扣款日期"
                            label-width="100px"
                            prop="agreedTransferDate">
                <el-date-picker v-model="beforeRentWriteOffData.agreedTransferDate"
                                type="date"
                                value-format="yyyy-MM-dd"
                                @change="selectCondition(beforeRentWriteOffData.agreedTransferDate)"></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="是否特殊还款"
                            label-width="104px"
                            prop="special">
                <el-select v-model="beforeRentWriteOffData.special"
                           @change="beforeRentWriteOffDataSpecialChange">
                  <el-option :value="1"
                             label="是"></el-option>
                  <el-option :value="0"
                             label="不是"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="提前结清类型"
                            label-width="104px"
                            prop="advanceType">
                <el-select v-model="beforeRentWriteOffData.advanceType">
                  <el-option v-for="(val, key, index) in dict.advanceTypeDict"
                             :key="index"
                             :value="key"
                             :label="val"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="8">
              <el-form-item label="勾稽余额"
                            label-width="72px"
                            class="is-required">
                <el-input v-model="writeOffAmount"
                          disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="剩余本金"
                            label-width="72px"
                            class="is-required">
                <el-input v-model="beforeRentWriteOffData.totalRemainPrincipal"
                          disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="应还款总金额"
                            label-width="100px"
                            class="is-required">
                <el-input v-model="beforeRentWriteOffData.currentNeedRepay"
                          disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="8">
              <el-form-item label="应还本金"
                            label-width="72px"
                            class="is-required">
                <el-input v-model="beforeRentWriteOffData.remainPrincipal"
                          disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="应还利息"
                            label-width="72px"
                            class="is-required">
                <el-input v-model="beforeRentWriteOffData.remainInterest"
                          disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="应还罚息"
                            label-width="72px"
                            class="is-required">
                <el-input v-model="beforeRentWriteOffData.remainOverduePenalty"
                          disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="8">
              <el-form-item label="提前还款违约金"
                            label-width="114px"
                            class="is-required">
                <el-input v-model="beforeRentWriteOffData.remainAdvancePenalty"
                          disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="应还费用"
                            label-width="72px"
                            class="is-required">
                <el-input v-model="beforeRentWriteOffData.remainFee"
                          disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="其他计收金额"
                            label-width="104px"
                            prop="otherCollection">
                <el-input v-model="beforeRentWriteOffData.otherCollection"
                          @blur="beforeRentWriteOffFormatMoney('otherCollection', beforeRentWriteOffData.otherCollection)"
                          @focus="beforeRentWriteOffRecoveryMoney('otherCollection', beforeRentWriteOffData.otherCollection)">
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="8">
              <el-form-item label="其他免收金额"
                            label-width="100px"
                            prop="otherExemption">
                <el-input v-model="beforeRentWriteOffData.otherExemption"
                          :disabled="beforeRentWriteOffData.special === 0"
                          @blur="beforeRentWriteOffFormatMoney('otherExemption', beforeRentWriteOffData.otherExemption)"
                          @focus="beforeRentWriteOffRecoveryMoney('otherExemption', beforeRentWriteOffData.otherExemption)">
                </el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8"
                    class="form-item-red">
              <el-form-item label="实际应还款金额"
                            label-width="114px"
                            class="is-required">
                <el-input v-model="beforeRentWriteOffData.adjustedNeedRepayAmount"
                          disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="放款主体"
                            label-width="72px"
                            class="is-required">
                <el-input v-model="beforeRentWriteOffData.loanOrg"
                          disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="8">
              <el-form-item label="到账金额"
                            label-width="72px"
                            prop="transferAmount">
                <el-input v-model="beforeRentWriteOffData.transferAmount"
                          @blur="formatTransferAmount()"
                          @focus="recoveryTransferAmount"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="勾稽金额"
                            label-width="72px"
                            class="is-required">
                <el-input v-model="beforeRentWriteOffData.bookAmount"
                          disabled></el-input>
              </el-form-item>
            </el-col>
            <!-- <el-col :span="8">
              <el-form-item label="网银/流水编号"
                            label-width="103px">
                <el-input v-model="beforeRentWriteOffData.externalRepayFlowNo"></el-input>
              </el-form-item>
            </el-col> -->
          </el-row>
          <el-row :gutter="10">
            <el-col :span="6">
              <el-form-item label="预计到账时间"
                            label-width="100px"
                            prop="expectedTransferTime">
                <el-date-picker v-model="beforeRentWriteOffData.expectedTransferTime"
                                type="date"
                                value-format="yyyy-MM-dd"
                                class="w171px"></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="到账银行"
                            label-width="72px"
                            prop="dueBank">
                <el-select v-model="beforeRentWriteOffData.dueBank"
                           @change="dueBankChange">
                  <el-option v-for="(item, index) in dueBankItemList"
                             :key="index"
                             :value="item.bankCode"
                             :label="item.bankName"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="到账账号"
                            label-width="72px"
                            prop="dueAccount">
                <el-select v-model="beforeRentWriteOffData.dueAccount">
                  <el-option v-for="(item, index) in dueBankAccountList"
                             :key="index"
                             :value="item"
                             :label="item"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <!-- <el-col :span="6">
              <el-form-item label="勾稽余额使用" label-width="90px" prop="balanceUseMethod">
                <el-select v-model="beforeRentWriteOffData.balanceUseMethod">
                  <el-option v-for="(item, index) in balanceUseMethodList" :key="index" :value="item.key" :label="item.name"></el-option>
                </el-select>
              </el-form-item>
            </el-col> -->
            <el-col :span="6">
              <el-form-item label="勾稽资金来源"
                            label-width="100px"
                            prop="repaymentBookCapitalSource">
                <el-select v-model="beforeRentWriteOffData.repaymentBookCapitalSource">
                  <el-option v-for="(item, index) in sourceList"
                             :key="index"
                             :value="item.value"
                             :label="item.key"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="24">
              <el-form-item label="备注信息"
                            label-width="72px"
                            prop="remark">
                <el-input v-model="beforeRentWriteOffData.remark"
                          type="textarea"
                          maxlength="500"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <!--回购-->
        <el-form v-if="dialogStatus === 2"
                 ref="buyBackForm"
                 key="buyBack"
                 size="small"
                 label-position="left"
                 :model="buyBackData"
                 :rules="buyBackFormRule">
          <el-row>
            <el-col :span="6">
              <el-form-item label="回购总金额"
                            label-width="86px"
                            class="is-required">
                <el-input v-model="buyBackData.currentBuyBackAmt"
                          disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item label="备注信息"
                        prop="remark"
                        label-width="72px">
            <el-input v-model="buyBackData.remark"
                      type="textarea"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div class="write-off-dialog-btns">
        <el-button type="primary"
                   size="mini"
                   @click="fileDialogVisible = true">
          上传凭证
        </el-button>
        <el-button type="primary"
                   size="mini"
                   @click="submit">
          提交申请
        </el-button>
      </div>
    </el-dialog>
    <!--文件上传弹窗-->
    <el-dialog title="请上传相关附件"
               :visible.sync="fileDialogVisible"
               class="write-off-dialog"
               :show-close="false">
      <p>温馨提示:系统支持上传的文件类型(*.pdf,*.docx,*.doc,*.jpg,*.jpeg,*.bmp,*.png,*.zip,*.rar,*.msg,*.eml,*.txt,*.wav</p>
      <p>单个word文件最大不能超过50.0MB;单个excel文件最大不能超过50.0MB;单个图片最大不能超过50.0MB;单个pdf文件最大不能超过50.0MB;单个压缩包文件最大不能超过20.0MB;</p>
      <FileUpload :picture-list="pictureList"
                  @savePicItem="savePicItemFn"></FileUpload>
      <div slot="footer"
           class="dialog-footer">
        <el-button size="mini"
                   @click="closeFileDialog">
          关 闭
        </el-button>
        <el-button type="primary"
                   size="mini"
                   @click="fileDialogVisible = false">
          保 存
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { checkApplyId, APPLYTYPE, rmoney, fmoney, accMul } from '../../utils/constant'
import FileUpload from '../../components/DialoginnerFileupload/fileupload'
import RepayPlanTable from './repayPlanTable'
import { prepareTrialBalance, repaymentWriteOffList, rentRepaymentBook, dueBankList, queryRepaymentDetailInfo, calculate, beforeRentRepaymentBook, dict, searchBuyBackAmount, buyBackSubmit } from '../../api/financialManage'
export default {
  name: 'RepaymentWriteOff',
  components: { FileUpload, RepayPlanTable },
  data () {
    return {
      checkApplyId,
      applyType: APPLYTYPE,
      fmoney,
      rmoney,
      dict,
      queryData: {
        oldApplyNo: '',
        applyDisplayId: '',
        customerName: '',
      }, // 还款勾稽查询数据
      tableData: [], // 还款勾稽列表数据
      dialogVisible: false,
      fileDialogVisible: false,
      dialogStatus: 0, // 租金勾稽、提前结清勾稽、回购标志
      dialogTitleDict: {
        0: '租金勾稽',
        1: '提前结清勾稽',
        2: '回购',
      },
      balanceUseMethodList: [
        { key: 1, name: '保留余额', status: false },
        { key: 2, name: '冲抵租金(顺序冲抵应还期租金)', status: true },
      ],
      currentCapitalName: '', // 还款计划表右上角当前资方
      activeName: 'all', // 默认整体
      repaymentList: [], // 还款计划
      billLoanType: null, // 借据类型 0-普通借据 1-联合贷借据
      sourceList: [// 资金勾稽来源
        {
          key: 'SP打款',
          value: 1,
        }, {
          key: '本人打款',
          value: 2,
        }, {
          key: '他人打款',
          value: 3,
        }],
      rentWriteOffData: {
        balanceUseMethod: 1,
        currentNeedRepay: null,
        adjustedNeedRepayAmount: '', // 调整后实际应还金额
        loanOrg: '',
        transferAmount: null,
        otherExemption: '0.00', // 减免金额
        bookAmount: null,
        externalRepayFlowNo: '',
        expectedTransferTime: '',
        dueBank: null,
        dueAccount: null,
        remark: '',
        addedBalance: null, // 本次新增勾稽余额
        repaymentBookCapitalSource: '',// 资金来源
      }, // 租金勾稽
      beforeRentWriteOffData: {
        balanceUseMethod: 1,
        conditionList: [],
        agreedTransferDate: '',
        special: 0,
        advanceType: null,
        totalRemainPrincipal: '',
        currentNeedRepay: null,
        remainPrincipal: null,
        remainInterest: null,
        remainOverduePenalty: null,
        remainAdvancePenalty: null,
        remainFee: null,
        otherCollection: '0.00', // 其他计收金额
        otherExemption: '0.00', // 其他免除金额
        adjustedNeedRepayAmount: null,
        loanOrg: '',
        transferAmount: null,
        bookAmount: null,
        externalRepayFlowNo: '',
        expectedTransferTime: '',
        dueBank: null,
        dueAccount: null,
        remark: '',
        addedBalance: null, // 本次新增勾稽余额
        repaymentBookCapitalSource: '',// 资金来源
      }, // 提前结清勾稽
      buyBackData: {
        currentBuyBackAmt: '0.00',
        remark: '',
      }, // 回购
      rentWriteOffDataRule: {
        repaymentBookCapitalSource: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        transferAmount: [{ required: true, message: '内容不可为空', trigger: 'blur' }],
        expectedTransferTime: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        dueBank: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        dueAccount: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        remark: [{ required: true, message: '内容不可为空', trigger: 'blur' }],
      },
      beforeRentWriteOffDataRule: {
        repaymentBookCapitalSource: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        agreedTransferDate: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        special: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        advanceType: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        otherCollection: [{ required: true, message: '内容不可为空', trigger: 'blur' }],
        otherExemption: [{ required: true, message: '内容不可为空', trigger: 'blur' }],
        transferAmount: [{ required: true, message: '内容不可为空', trigger: 'blur' }],
        expectedTransferTime: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        dueBank: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        dueAccount: [{ required: true, message: '内容不可为空', trigger: 'change' }],
        remark: [{ required: true, message: '内容不可为空', trigger: 'blur' }],
      },
      buyBackFormRule: {
        remark: [{ required: true, message: '备注信息不可为空', trigger: 'blur' }],
      },
      clickItem: {}, // 列表点击项
      dueBankItemList: [], // 到账银行
      dueBankAccountList: [], // 到账账号
      historyBookBalance: null, // 历史勾稽余额
      writeOffAmount: null, // 勾稽余额
      pictureList: [{
        dictKey: 'book_file',
        fileRecordVOList: [],
        name: '还款勾稽凭证',
      }], // 租金勾稽或提前结清勾稽凭证
      conditionSelectData: {}, // 条件勾选依赖
    }
  },
  mounted () {
    // this.getRepaymentWriteOffList()
  },
  methods: {
    // 改变勾稽余额使用方式
    changeRentWriteOffData (type, select) {
      if (this[type].transferAmount === '' || this[type].transferAmount === null || this[type].transferAmount === undefined) {
        if (select) {
          this[type].balanceUseMethod === 1 ? this[type].balanceUseMethod = 2 : this[type].balanceUseMethod = 1
        }
        return this.$message.warning('请先填写到账金额')
      }
      // 调接口查询
      this.fetchPrepareTrialBalance(type)
    },
    async fetchPrepareTrialBalance (type) {
      let data = {
        applyId: this.clickItem.applyId,
        balanceUseMethod: this[type].balanceUseMethod,
        transferAmount: accMul(rmoney(this[type].transferAmount), 100),
        otherExemption: accMul(rmoney(this[type].otherExemption), 100),
        billLoanNo: this.clickItem.billLoanNo,
        userId: this.clickItem.userIdStr,
      }
      let res = await prepareTrialBalance(data)
      if (res.data.respCode === '1000') {
        this[type].addedBalance = res.data.body.addedBalance
        this.writeOffAmount = fmoney(res.data.body.addedBalance / 100)
        this[type].bookAmount = fmoney(res.data.body.bookAmount / 100)
      }
    },
    getRepaymentWriteOffList () {
      repaymentWriteOffList(this.queryData).then((res) => {
        if (res.data.respCode === '1000') this.tableData = res.data.body
      })
    },
    resetRepaymentWriteOffListQuery () {
      this.queryData.applyDisplayId = null
      this.queryData.customerName = ''
      this.queryData.oldApplyNo = ''
    },
    // 到账银行、账号
    getDueBankList () {
      return new Promise((resolve, reject) => {
        dueBankList(this.clickItem.applyId).then((res) => {
          if (res.data.respCode === '1000') {
            const { bankAccounts, loanOrg, historyBookBalance } = res.data.body
            this.dueBankItemList = bankAccounts
            if (this.dialogStatus === 0) {
              this.rentWriteOffData.loanOrg = loanOrg
            } else {
              this.beforeRentWriteOffData.loanOrg = loanOrg
            }
            this.historyBookBalance = historyBookBalance // 历史勾稽余额
            resolve(1)
          }
        }).catch((err) => { reject(err) })
      })
    },
    // 当前明细更换
    activeChange (val) {
      this.getRepaymentPlans(val)
    },
    listenGetRepaymentPlans () {
      this.getRepaymentPlans(this.activeName)
    },
    // 查询还款计划
    getRepaymentPlans () {
      const { userId, billLoanNo, applyId } = this.clickItem
      let capitalList = Array.from(arguments)
      let length = Array.from(arguments).length
      // 新网：EX-XW， 众邦：EX-ZB ，2345自有：2345
      let query = {}
      if (!length || capitalList[0] === 'all') { // 查询整体
        query = {
          userId,
          billLoanNo,
          applyId,
        }
      } else {
        query = {
          userId,
          billLoanNo,
          applyId,
          capitalList,
        }
      }
      queryRepaymentDetailInfo(query).then((res) => {
        if (res.data.respCode === '1000') {
          const { repaymentPlanVOList, currentNeedRepay, currentCapital, billLoanType } = res.data.body
          repaymentPlanVOList.forEach((item) => {
            if (item.repayDate) item.repayDate = item.repayDate.substring(0, 10)
          })
          this.currentCapitalName = currentCapital
          // if (currentCapital === '2345自有资金') {
          //   this.balanceUseMethodList = [
          //     { key: 1, name: '保留余额', status: false },
          //   ]
          // } else {
          //   this.balanceUseMethodList = [{ key: 1, name: '保留余额', status: false }]
          // }
          this.repaymentList = repaymentPlanVOList
          this.billLoanType = billLoanType
          if (this.dialogStatus === 0) this.rentWriteOffData.currentNeedRepay = fmoney(currentNeedRepay / 100) // 元 租金勾稽当前应还总金额
        }
      }).catch((err) => { console.log(err) })
    },
    // 点击列表项
    async dialogShowHandle (row, dialogStatus) {
      this.dialogStatus = dialogStatus
      this.clickItem = row
      if (dialogStatus !== 2) { // 租金勾稽/提前结清勾稽
        let dueBank = null
        try {
          dueBank = await this.getDueBankList()
        } catch (e) {
          return false
        }
        if (dueBank) {
          this.dialogVisible = true
          this.activeName = 'all'
          this.getRepaymentPlans()
          if (dialogStatus === 1) this.calculateBeforeRent()
        }
      } else { // 回购
        this.dialogVisible = true
        this.activeName = 'all'
        this.getRepaymentPlans()
        this.getBuyBackData()
      }
    },
    // 勾稽申请弹窗关闭
    rentWriteOffClosed () {
      this.dueBankItemList = [] // 清空到账银行
      // 清空图片列表
      this.pictureList.forEach((item) => {
        item.fileRecordVOList = []
      })
      // 清空还款明细
      this.repaymentList = []
      // 清空显示的勾稽余额
      this.writeOffAmount = null
      // 清空没进校验规则的两个值
      this.rentWriteOffData.otherExemption = '0.00'
      this.rentWriteOffData.externalRepayFlowNo = ''
      // 清空校验和绑定的值
      this.$refs['rentWriteOffData'] && this.$refs['rentWriteOffData'].resetFields()
      this.$refs['beforeRentWriteOffData'] && this.$refs['beforeRentWriteOffData'].resetFields()
      this.$refs['buyBackForm'] && this.$refs['buyBackForm'].resetFields()
    },
    // 到账银行切换
    dueBankChange () {
      this.dueBankItemList.filter((item) => {
        if (this.dialogStatus === 0) {
          if (item.bankCode === this.rentWriteOffData.dueBank) {
            this.dueBankAccountList = item.dueAccounts
            this.rentWriteOffData.dueAccount = this.dueBankAccountList[0]
          }
        } else {
          if (item.bankCode === this.beforeRentWriteOffData.dueBank) {
            this.dueBankAccountList = item.dueAccounts
            this.beforeRentWriteOffData.dueAccount = this.dueBankAccountList[0]
          }
        }
      })
    },

    // 到账金额格式化
    formatTransferAmount (type) {
      if (this.dialogStatus === 0) {
        this.rentWriteOffCalculate()
      } else {
        // 到账金额
        this.beforeRentWriteOffData.transferAmount =
          (this.beforeRentWriteOffData.transferAmount !== '' && this.beforeRentWriteOffData.transferAmount !== null) ? fmoney(this.beforeRentWriteOffData.transferAmount) : ''
        this.beforeRentWriteOffComplexCompare()
      }
      if (type) {
        this.changeRentWriteOffData(type)
      }
    },
    // 恢复到账金额格式化
    recoveryTransferAmount () {
      if (this.dialogStatus === 0) {
        this.rentWriteOffData.transferAmount = this.rentWriteOffData.transferAmount ? rmoney(this.rentWriteOffData.transferAmount) : ''
      } else {
        this.beforeRentWriteOffData.transferAmount = this.beforeRentWriteOffData.transferAmount ? rmoney(this.beforeRentWriteOffData.transferAmount) : ''
      }
    },

    // 租金勾稽计算
    rentWriteOffCalculate () {
      // 到账金额
      this.rentWriteOffData.transferAmount = (this.rentWriteOffData.transferAmount !== '' && this.rentWriteOffData.transferAmount !== null) ? fmoney(this.rentWriteOffData.transferAmount) : ''
      /*
      * 到账金额小于当前应还款金额，取transferAmountCopy，如果有减免金额，就加上减免金额，没有的话就直接等于transferAmountCopy
      * 如果不小于，取currentNeedRepayCopy，如果有减免金额，就减去减免金额，没有的话就直接等于取currentNeedRepayCopy
      * */
      let currentNeedRepayCopy = accMul(rmoney(this.rentWriteOffData.currentNeedRepay), 100) // 分 // 当前应还总金额
      // let transferAmountCopy = accMul(rmoney(this.rentWriteOffData.transferAmount), 100) // 分 // 到账金额
      // let finalBookAmount = null
      let otherExemptionCopy = accMul(rmoney(this.rentWriteOffData.otherExemption), 100) // 分 // 减免金额
      let adjustedNeedRepayAmountCopy = currentNeedRepayCopy - otherExemptionCopy
      // 调整后实际应还款金额 = 当前应还总金额 - 减免金额
      this.rentWriteOffData.adjustedNeedRepayAmount = fmoney(adjustedNeedRepayAmountCopy / 100)
      // finalBookAmount = transferAmountCopy < adjustedNeedRepayAmountCopy ? transferAmountCopy : adjustedNeedRepayAmountCopy
      // this.rentWriteOffData.bookAmount = fmoney(finalBookAmount / 100) // 元 // 勾稽金额
      // 本次新增的勾稽余额 = 当到账金额<当前应还总金额时，取0，不小于时，到账金额 - 勾稽金额（实际应还款金额）
      // this.rentWriteOffData.addedBalance = transferAmountCopy < adjustedNeedRepayAmountCopy ? 0 : transferAmountCopy - accMul(rmoney(this.rentWriteOffData.bookAmount), 100)
      // 需要显示的勾稽余额 = 本次新增勾稽余额（前端计算得出） + 历史勾稽余额（后端给出）
      // this.writeOffAmount = fmoney((this.rentWriteOffData.addedBalance + this.historyBookBalance) / 100)
    },
    // 租金勾稽免收金额格式化 + 计算
    formatRentWriteOffOtherExemption (type) {
      this.rentWriteOffData.otherExemption = fmoney(this.rentWriteOffData.otherExemption)
      this.formatTransferAmount()
      if (type) {
        this.changeRentWriteOffData(type)
      }
    },
    // 租金勾稽免收金额恢复
    recoveryRentWriteOffOtherExemption () {
      this.rentWriteOffData.otherExemption = rmoney(this.rentWriteOffData.otherExemption)
    },

    // 提前结清勾稽计算
    calculateBeforeRent () {
      calculate(this.clickItem.billLoanNo, this.clickItem.userId).then((res) => {
        if (res.data.respCode === '1000') {
          let data = res.data.body
          this.beforeRentWriteOffData.conditionList = data.conditionList
          this.beforeRentWriteOffData.currentNeedRepay = fmoney(data.currentNeedRepay / 100) // 当前应还款金额（元）
          this.beforeRentWriteOffData.remainAdvancePenalty = fmoney(data.remainAdvancePenalty / 100) // 提前还款违约金（元）
          this.beforeRentWriteOffData.remainInterest = fmoney(data.remainInterest / 100) // 应还利息（元）
          this.beforeRentWriteOffData.remainOverduePenalty = fmoney(data.remainOverduePenalty / 100) // 应还罚息（元）
          this.beforeRentWriteOffData.remainPrincipal = fmoney(data.remainPrincipal / 100) // 应还本金（元）
          this.beforeRentWriteOffData.totalRemainPrincipal = fmoney(data.totalRemainPrincipal / 100) // 应还本金（元）
          this.beforeRentWriteOffData.remainFee = fmoney(data.remainFee / 100) // 应还费用（元）
          this.conditionSelectData.tenDaysBeforeNextRepayDate = data.tenDaysBeforeNextRepayDate
          this.conditionSelectData.sixMonthAfterLoanTransfer = data.sixMonthAfterLoanTransfer
          this.calculateAdjustedNeedRepayAmount()
        }
      }).catch((err) => { console.log(err) })
    },
    // 计算实际应还款金额（提前结清勾稽）
    calculateAdjustedNeedRepayAmount () {
      // 应还款总金额 + 其他计收金额 - 其他免除金额
      this.beforeRentWriteOffData.adjustedNeedRepayAmount = (accMul(rmoney(this.beforeRentWriteOffData.currentNeedRepay), 100)) + (accMul(rmoney(this.beforeRentWriteOffData.otherCollection), 100)) - (accMul(rmoney(this.beforeRentWriteOffData.otherExemption), 100)) // 分
      this.beforeRentWriteOffData.adjustedNeedRepayAmount = fmoney(this.beforeRentWriteOffData.adjustedNeedRepayAmount / 100) // (元)
      this.beforeRentWriteOffComplexCompare()
    },
    // 提前结清勾稽的复杂运算逻辑
    beforeRentWriteOffComplexCompare () {
      // 比较实际应还款金额 和 到账金额
      let adjustedNeedRepayAmountCopy = accMul(rmoney(this.beforeRentWriteOffData.adjustedNeedRepayAmount), 100) // 分 // 实际应还款金额
      let transferAmountCopy = accMul(rmoney(this.beforeRentWriteOffData.transferAmount), 100) // 分 // 到账金额
      let tempVal = transferAmountCopy < adjustedNeedRepayAmountCopy ? transferAmountCopy : adjustedNeedRepayAmountCopy
      this.beforeRentWriteOffData.bookAmount = fmoney(tempVal / 100) // 元 // 勾稽金额 实际应还款金额 和 到账金额取小的
      // 本次新增的勾稽余额 = 到账金额 - 勾稽金额
      this.beforeRentWriteOffData.addedBalance = transferAmountCopy - accMul(rmoney(this.beforeRentWriteOffData.bookAmount), 100)
      // 需要显示的勾稽余额 = 本次新增勾稽余额（前端计算得出） + 历史勾稽余额（后端给出）
      this.writeOffAmount = fmoney((this.beforeRentWriteOffData.addedBalance + this.historyBookBalance) / 100)
    },
    // 提前结清金钱通用格式化金额事件
    beforeRentWriteOffFormatMoney (target, val) {
      this.beforeRentWriteOffData[target] = fmoney(val)
      // 其他计收金额变化 和 其他免收金额变化 会导致实际应还款金额的变化
      if (this.beforeRentWriteOffData.currentNeedRepay !== '' && this.beforeRentWriteOffData.currentNeedRepay !== null) {
        if (target === 'otherCollection' && (this.beforeRentWriteOffData.otherCollection !== '')) this.calculateAdjustedNeedRepayAmount()
        if (target === 'otherExemption' && (this.beforeRentWriteOffData.otherExemption !== '')) this.calculateAdjustedNeedRepayAmount()
      }
    },
    // 提前结清金钱通用恢复格式化金额事件
    beforeRentWriteOffRecoveryMoney (target, val) {
      this.beforeRentWriteOffData[target] = rmoney(val)
    },
    // 约定扣款日期变化，导致提前结清勾稽的条件变化
    selectCondition (val) {
      this.beforeRentWriteOffData.conditionList = []
      let agreedTransferDate = new Date(val + ' 00:00:00').getTime()
      let tenDaysBeforeNextRepayDate = new Date(this.conditionSelectData.tenDaysBeforeNextRepayDate).getTime()
      let sixMonthAfterLoanTransfer = new Date(this.conditionSelectData.sixMonthAfterLoanTransfer).getTime()
      if (agreedTransferDate > sixMonthAfterLoanTransfer) this.beforeRentWriteOffData.conditionList.push(1)
      if (agreedTransferDate < tenDaysBeforeNextRepayDate) this.beforeRentWriteOffData.conditionList.push(3)
    },
    // 是否特殊还款值的改变
    beforeRentWriteOffDataSpecialChange () {
      // 当特殊还款为否时，清空其他免收金额的值
      if (+this.beforeRentWriteOffData.special === 0) this.beforeRentWriteOffData.otherExemption = '0.00'
    },

    // 回购数据获取
    getBuyBackData () {
      searchBuyBackAmount(this.clickItem.applyId).then((res) => {
        if (res.data.respCode === '1000') {
          const { currentBuyBackAmt } = res.data.body
          this.buyBackData.currentBuyBackAmt = fmoney(currentBuyBackAmt / 100)
        }
      })
    },

    // 保存图片
    savePicItemFn (val) {
      this.pictureList.forEach((item) => {
        if (item.dictKey === val.item.dictKey) {
          item.fileRecordVOList.push(val.data)
        }
      })
    },
    // 关闭
    closeFileDialog () {
      this.fileDialogVisible = false
      this.pictureList.forEach((item) => {
        item.fileRecordVOList = []
      })
    },

    submit () {
      // 校验表单和图片
      let picListSign = false
      this.pictureList.forEach((item) => {
        if (item.fileRecordVOList.length > 0) picListSign = true
      })
      if (this.dialogStatus === 0) {
        this.$refs['rentWriteOffData'].validate((valid) => {
          if (valid && picListSign) {
            let data = JSON.parse(JSON.stringify(this.rentWriteOffData))
            data.applyId = this.clickItem.applyId
            data.fileListVo = { pictureListVOList: this.pictureList }
            data.bookAmount = accMul(this.rmoney(data.bookAmount), 100) // 勾稽金额
            data.transferAmount = accMul(this.rmoney(data.transferAmount), 100) // 到账金额
            data.otherExemption = accMul(this.rmoney(data.otherExemption), 100) // 减免金额
            data.currentNeedRepay = accMul(this.rmoney(data.currentNeedRepay), 100)
            data.adjustedNeedRepayAmount = accMul(this.rmoney(data.adjustedNeedRepayAmount), 100) // 调整后实际应还金额
            data.balanceUseMethod = data.balanceUseMethod ? Number(data.balanceUseMethod) : 1
            rentRepaymentBook(data).then((res) => {
              if (res.data.respCode === '1000') {
                this.dialogVisible = false
                this.$message.success('提交成功')
              }
            }).catch((err) => { console.log(err) })
          }
          if (!picListSign) this.$message.warning('请上传凭证')
          if (!valid) this.$message.warning('请检查必填项')
        })
      } else if (this.dialogStatus === 1) {
        this.$refs['beforeRentWriteOffData'].validate((valid) => {
          if (valid && picListSign) {
            let data = JSON.parse(JSON.stringify(this.beforeRentWriteOffData))
            data.balanceUseMethod = data.balanceUseMethod ? Number(data.balanceUseMethod) : 1
            data.adjustedNeedRepayAmount = accMul(rmoney(data.adjustedNeedRepayAmount), 100)
            data.bookAmount = accMul(rmoney(data.bookAmount), 100)
            data.currentNeedRepay = accMul(rmoney(data.currentNeedRepay), 100)
            data.otherCollection = accMul(rmoney(data.otherCollection), 100)
            data.otherExemption = accMul(rmoney(data.otherExemption), 100)
            data.remainAdvancePenalty = accMul(rmoney(data.remainAdvancePenalty), 100)
            data.remainInterest = accMul(rmoney(data.remainInterest), 100)
            data.remainOverduePenalty = accMul(rmoney(data.remainOverduePenalty), 100)
            data.remainPrincipal = accMul(rmoney(data.remainPrincipal), 100)
            data.totalRemainPrincipal = accMul(rmoney(data.totalRemainPrincipal), 100)
            data.transferAmount = accMul(rmoney(data.transferAmount), 100)
            data.remainFee = accMul(rmoney(data.remainFee), 100)
            data.applyId = this.clickItem.applyId
            data.fileListVo = { pictureListVOList: this.pictureList }
            if (data.transferAmount < data.adjustedNeedRepayAmount) {
              this.$message.warning('到账金额必须大于等于实际应还款总金额')
              return false
            }
            beforeRentRepaymentBook(data).then((res) => {
              if (res.data.respCode === '1000') {
                this.dialogVisible = false
                this.$message.success('提交成功')
              }
            }).catch((err) => { console.log(err) })
          }
          if (!picListSign) this.$message.warning('请上传凭证')
          if (!valid) this.$message.warning('请检查必填项')
        })
      } else if (this.dialogStatus === 2) {
        this.$refs['buyBackForm'].validate((valid) => {
          if (valid) {
            const { currentBuyBackAmt, remark } = this.buyBackData
            const { applyId, customerName } = this.clickItem
            const applyRepurchaseAmount = accMul(rmoney(currentBuyBackAmt), 100)
            const apiData = { applyId, customerName, applyRepurchaseAmount, remark, fileListVo: { pictureListVOList: this.pictureList } }
            buyBackSubmit(apiData).then((res) => {
              if (res.data.respCode === '1000') {
                this.$message.success('提交成功')
                this.dialogVisible = false
              }
            })
          } else {
            this.$message.warning('请检查必填项')
          }
        })
      }
    },
  },
}
</script>

<style scoped lang="scss">
.redSign {
  color: red;
}
.font-bold {
  font-weight: bold;
}
.write-off-dialog {
  .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 170px;
  }
  .w171px.el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 171px;
  }
}
.write-off-dialog-btns {
  display: flex;
  flex-direction: row;
  justify-content: center;
}
.formModuleTitle {
  > i {
    font-style: normal;
    font-size: 12px;
    color: #333;
    margin-left: 8px;
    height: 30px;
    line-height: 30px;
  }
}
</style>
