<template>
  <div>
    <div class="payCheck-query-wrap">
      <el-form size="mini"
               label-position="left"
               :inline="true">
        <!-- <el-row :gutter="10"> -->
        <!-- <el-col :span="colSpan"> -->
        <el-form-item label="申请编号"
                      :label-width="labelWidth">
          <el-input v-model="queryData.applyId"
                    maxlength="8"
                    @blur="checkApplyId(queryData.applyId)"></el-input>
        </el-form-item>
        <el-form-item label="申请编号(老)"
                      :label-width="labelWidth">
          <el-input v-model="queryData.oldApplyNo"
                    maxlength="7"
                    placeholder="申请编号(老)"
                    onkeypress="return(/^[0-9]*$/.test(String.fromCharCode(event.keyCode)))"
                    @blur="checkApplyId(queryData.oldApplyNo,'oldApplyNo',7)"></el-input>
        </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="colSpan"> -->
        <el-form-item label="客户姓名"
                      :label-width="labelWidth">
          <el-input v-model="queryData.customerName"
                    maxlength="30"></el-input>
        </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="colSpan"> -->
        <el-form-item label="合同编号"
                      :label-width="labelWidth">
          <el-input v-model="queryData.contractNo"></el-input>
        </el-form-item>
        <!-- </el-col> -->
        <!-- <el-col :span="colSpan"> -->
        <el-form-item label="小贷标识"
                      :label-width="labelWidth">
          <el-select v-model="queryData.isMicro">
            <el-option label="是"
                       :value="true"></el-option>
            <el-option label="否"
                       :value="false"></el-option>
          </el-select>
        </el-form-item>
        <!-- </el-col> -->
        <!-- </el-row> -->
        <el-form-item>
          <el-button size="mini"
                     type="primary"
                     @click="resetQuery">
            重置
          </el-button>
          <el-button size="mini"
                     type="primary"
                     @click="getPayCheckList">
            查询
          </el-button>
          <el-button size="mini"
                     type="primary"
                     :loading="exportLoading"
                     @click="tableDownload">
            表格下载
          </el-button>
          <el-button size="mini"
                     type="primary"
                     @click="getPayCheckList">
            刷新
          </el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="data-table">
      <el-table border
                :data="tableData">
        <el-table-column width="30">
          <template slot-scope="scope">
            <el-checkbox v-model="scope.row.checked"></el-checkbox>
          </template>
        </el-table-column>
        <el-table-column label="序号"
                         type="index"></el-table-column>
        <el-table-column label="申请编号"
                         align="center"
                         width="70">
          <template slot-scope="scope">
            {{ scope.row.applyDisplayId }}
            <el-tag v-if="scope.row.specialPermit"
                    type="warning"
                    size="mini">
              特批
            </el-tag>
            <el-tag v-if="scope.row.reconsideration"
                    type="warning"
                    size="mini">
              复议
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="申请编号(老)"
                         align="center">
          <template slot-scope="scope">
            <!--老系统显示 oldApplyNo，新系统显示 '/'-->
            {{ scope.row.oldApplyNo || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="合同编号"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.contractNo }}
          </template>
        </el-table-column>
        <el-table-column label="客户名称"
                         align="center"
                         width="70">
          <template slot-scope="scope">
            {{ scope.row.customerName }}
          </template>
        </el-table-column>
        <el-table-column label="付款金额"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.transferAmt }}
          </template>
        </el-table-column>
        <el-table-column label="收款账户名"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.accountName }}
          </template>
        </el-table-column>
        <el-table-column label="收款银行"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.bankName }}
          </template>
        </el-table-column>
        <el-table-column label="收款账号"
                         align="center"
                         width="150">
          <template slot-scope="scope">
            {{ scope.row.account }}
          </template>
        </el-table-column>
        <el-table-column label="店面名称"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.dealerName }}
          </template>
        </el-table-column>
        <el-table-column label="任务创建时间"
                         align="center"
                         width="75">
          <template slot-scope="scope">
            {{ scope.row.created }}
          </template>
        </el-table-column>
        <el-table-column label="小贷标识"
                         align="center"
                         width="60">
          <template slot-scope="scope">
            {{ scope.row.isMicro === true ? '是' : '否' }}
          </template>
        </el-table-column>
      </el-table>
      <el-button type="text"
                 @click="checkAll">
        批量确认
      </el-button>
      <el-pagination
        class="listPagination"
        :current-page="page.pageNum"
        :page-size="page.pageSize"
        :page-sizes="page.pageSizeArr"
        layout="total, sizes, prev, pager, next, jumper"
        :total="page.total"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange">
      </el-pagination>
    </div>
    <!--批量确认弹窗-->
    <el-dialog title="批量确认"
               :visible.sync="dialogFormVisible"
               @closed="checkAllDataClosed">
      <el-form ref="checkAllData"
               :model="checkAllData"
               :rules="checkAllDataRule"
               size="small"
               class="checkPayForm">
        <el-row :gutter="10">
          <el-col :span="12">
            <el-form-item label="付款银行"
                          label-width="80px"
                          prop="bank">
              <el-select v-model="checkAllData.bank"
                         @change="bankChange">
                <el-option v-for="item in banksList"
                           :key="item.dictKey"
                           :value="item.dictKey"
                           :label="item.dictKey"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="付款账号"
                          label-width="80px"
                          prop="account">
              <el-input v-model="checkAllData.account"
                        auto-complete="off"
                        disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="12">
            <el-form-item label="放款日期"
                          label-width="80px"
                          prop="transferDate">
              <el-date-picker v-model="checkAllData.transferDate"
                              auto-complete="off"
                              value-format="yyyy-MM-dd"></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button size="mini"
                   @click="dialogFormVisible = false">
          关闭
        </el-button>
        <el-button type="primary"
                   size="mini"
                   @click="surePay">
          确认付款
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import {payCheckList, confirmPay, payCheckGet} from '../../api/financialManage.js'
  import {checkApplyId} from '../../utils/constant'
  import {dictionaryPost} from '../../api/commonApi.js'
  import {downLoadPolling} from '../../api/daihou' // 轮询接口通用
  const qs = require('qs')
  export default {
    data () {
      return {
        checkApplyId,
        colSpan: 6,
        labelWidth: '95px',
        page: {
          total: 0,
          pageSize: 10,
          pageNum: 1,
          pageSizeArr: [10, 20, 30, 40],
        },
        queryData: {
          transferResult: 90,
        },
        tableData: [],
        checkAllData: {
          bank: null,
          account: null,
          transferDate: null,
        }, // 批量确认数据
        dialogFormVisible: false,
        banksList: [],
        checkAllDataRule: {
          bank: [{required: true, trigger: 'change', message: '内容不可为空'}],
          account: [{required: true, trigger: 'blur', message: '内容不可为空'}],
          transferDate: [{required: true, trigger: 'change', message: '内容不可为空'}],
        },
        exportTimer: null,
        exportLoading: false,
      }
    },
    mounted () {
      this.getPayCheckList()
    },
    methods: {
      // 列表数据
      getPayCheckList () {
        this.exportLoading = false
        return new Promise((resolve) => {
          this.queryData.pageNum = this.page.pageNum
          this.queryData.pageSize = this.page.pageSize
          payCheckList(this.queryData).then((res) => {
            if (res.data.respCode === '1000') {
              let data = res.data.body
              data.list.forEach((item) => {
                item.checked = false
              })
              this.page.total = data.total
              this.tableData = data.list
              // 供是否可下载表格判断
              if (this.tableData.length > 0) {
                resolve(1)
              } else {
                resolve(0)
              }
            }
          })
        })
      },
      // 查询重置
      resetQuery () {
        for (let k in this.queryData) {
          if (k !== 'transferResult') {
            this.queryData[k] = null
          }
        }
        this.getPayCheckList()
        this.exportLoading = false
      },
      // 表格下载
      tableDownload () {
        if (this.exportLoading) {
          this.$message.warning('文件正在生成')
          return false
        } else {}
        this.getPayCheckList().then((data) => {
          if (data && this.tableData.length !== 0) {
            payCheckGet(this.queryData).then((res) => {
              this.exportLoading = true // 开启loading
              if (res.data.respCode === '1000') {
                let exportSerialNo = res.data.body.serialNo
                clearInterval(this.exportTimer)
                this.exportTimer = setInterval(() => {
                  downLoadPolling(exportSerialNo).then((res) => {
                    this.exportLoading = false
                    if (res.data.respCode === '1000') {
                      let data = res.data.body
                      if (data.status) {
                        clearInterval(this.exportTimer)
                        // 导出
                        window.location.href = process.env.VUE_APP_BASE_API + '/download/export?' + qs.stringify({filename: data.filename, storePath: data.storePath})
                      }
                    } else {
                      clearInterval(this.exportTimer)
                    }
                  })
                }, 1000)
              }
            })
          } else {
            this.$message.warning('该筛选条件下无表格可下载')
          }
        })
      },
      // 付款银行
      getBanks (val) {
        dictionaryPost({category: [val]}).then((res) => {
          if (res.data.respCode === '1000') this.banksList = res.data.body[val]
        })
      },
      handleSizeChange () {},
      handleCurrentChange () {},
      /* checkContractNo () {
        if (this.queryData.contractNo && !(contractNoReg.test(this.queryData.contractNo))) {
          this.queryData.contractNo = null
          this.$message.warning('输入有误')
        }
      }, */
      // 批量确认校验
      checkAll () {
        let temp = this.tableData.filter((item) => {
          if (item.checked === true) return item
        })
        if (temp.length > 0) {
          /*eslint-disable*/
          let trueFlag = 1
          let falseFlag = 2
          temp.forEach(item => {
            // 假设全是是的情况，如果有一个不是
            if (item.isMicro !== true) {
              trueFlag = 0
            }
            // 假设全是不是的情况，如果有一个是
            if (item.isMicro !== false) {
              falseFlag = 3
            }
          })
          if (trueFlag === 1 || falseFlag === 2) {
            this.dialogFormVisible = true
            if (temp[0].isMicro === true) {
              // 是小贷
              this.getBanks('transfer_cdw_xd')
            } else if (temp[0].isMicro === false) {
              // 不是小贷
              this.getBanks('transfer_cdw')
            }
          } else {
            this.$message.warning('不可同时选择“小贷标识”为“是”、“否”的记录，请检查所选记录')
          }
        } else {
          this.$message.warning('请至少选择一条记录')
        }
      },
      // 付款银行
      bankChange () {
        if (this.checkAllData.bank) {
          let selectItem = this.banksList.filter(item => {
            if (item.dictKey === this.checkAllData.bank) return item
          })
          this.checkAllData.account = selectItem[0].dictName
        }
      },
      // 批量确认弹窗
      checkAllDataClosed () {
        this.$refs['checkAllData'].resetFields()
      },
      // 确认批量确认付款
      surePay () {
        this.$refs['checkAllData'].validate(valid => {
          if (valid) {
            let applyIds = []
            this.tableData.filter(item => {
              if (item.checked === true) {
                applyIds.push(item.applyId)
              }
            })
            this.checkAllData.applyIds = applyIds
            this.banksList.forEach(item => {
              if (this.checkAllData.bank === item.dictKey) {
                this.checkAllData.bankAccount = item.dictName
              }
            })
            confirmPay(this.checkAllData).then(res => {
              if (res.data.respCode === '1000') {
                this.dialogFormVisible = false
                this.getPayCheckList()
              }
            })
          } else {
            this.$message.warning('请检查必填字段')
          }
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .data-table{
    margin-top: 10px;
  }
  .listPagination{
    margin-top: 10px;
    float: right;
  }
</style>
