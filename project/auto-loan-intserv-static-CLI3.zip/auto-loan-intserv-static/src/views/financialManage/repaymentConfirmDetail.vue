<!--还款-还款确认-详情页-->
<template>
  <div class="repayment-confirm-detail-wrap">
    <!--新网：EX-XW， 众邦：EX-ZB ，2345自有：2345-->
    <!--billLoanType 借据类型 0-普通借据 1-联合贷借据-->
    <el-radio-group v-if="billLoanType" v-model="activeName" size="mini" @change="activeChange" style="margin-bottom: 10px;">
      <el-radio-button label="all">整体</el-radio-button>
      <el-radio-button label="EX-ZB">众邦</el-radio-button>
      <el-radio-button label="2345">2345</el-radio-button>
    </el-radio-group>
    <!--还款计划表-->
    <RepayPlanTable :repaymentList="repaymentList" :currentCapitalName="currentCapitalName" @listenGetRepaymentPlans="listenGetRepaymentPlans"></RepayPlanTable>
    <div class="formModuleTitle">
      <span>客户还款信息</span>
    </div>
    <el-form size="small" label-position="left" :model='infoData' ref='infoData' :rules='infoDataRule'>
      <div class="repayment-confirm-detail-formWrap">
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="申请编号" label-width="79px" class="is-required">
              <el-input disabled v-model="infoData.applyDisplayId"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="客户名称" label-width="79px" class="is-required">
              <el-input disabled v-model="infoData.customerName"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="放款主体" label-width="79px" class="is-required">
              <el-input disabled v-model="infoData.loanOrg"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="网银/流水编号" label-width="114px">
              <el-input disabled v-model="infoData.externalRepayFlowNo"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="到账金额" label-width="79px" class="is-required">
              <el-input disabled v-model="infoData.transferAmount"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="预计到账时间" label-width="111px" class="is-required">
              <el-date-picker type="date" value-format="yyyy-MM-dd" disabled v-model="infoData.expectedTransferTime"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="到账银行" label-width="79px" class="is-required">
              <el-select v-model="infoData.dueBank" @change="dueBankChange">
                <el-option v-for="(item, index) in dueBankItemList" :key="index" :value="item.bankCode" :label="item.bankName"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="到账账号" label-width="79px" class="is-required">
              <el-select v-model="infoData.dueAccount">
                <el-option v-for="(item, index) in dueBankAccountList" :key="index" :value="item" :label="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </div>
      <div class="formModuleTitle">
        <span style="margin-right:10px;">银行到账信息</span> <el-button type="primary" size="mini" @click="addBankHandle">添加</el-button>
      </div>
      <div class="repayment-confirm-detail-formWrap">
        <template v-if="infoData.repayBankInfo.length > 0">
          <el-row :gutter="10" v-for="(repayBankInfo, idx) in infoData.repayBankInfo" :key="idx">
            <el-col :span="5">
              <el-form-item label="付款日期" label-width="80px" class="is-required"
              :prop="'repayBankInfo.' + idx + '.repayDate'"
              :rules="{required: true, message: '不能为空', trigger: 'blur'}">
                <el-date-picker type="date" value-format="yyyy-MM-dd" v-model="repayBankInfo.repayDate"></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="5">
              <el-form-item label="付款人" label-width="66px" class="is-required"
              :prop="'repayBankInfo.' + idx + '.repayName'"
              :rules="{required: true, message: '不能为空', trigger: 'blur'}">
                <el-input v-model="repayBankInfo.repayName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="付款流水号" label-width="88px" prop="repaySerialNo">
                <el-input v-model="repayBankInfo.repaySerialNo" @blur="repaySerialNoValidateHandle(repayBankInfo.repaySerialNo)"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="付款金额" label-width="80px" class="is-required"
              :prop="'repayBankInfo.' + idx + '.repayAmt'"
              :rules="{required: true, message: '不能为空', trigger: 'blur'}">
                <el-input v-model="repayBankInfo.repayAmt" @blur="fmoneyHandle(repayBankInfo, repayBankInfo.repayAmt)" @focus="fmoneyFocusHandle(repayBankInfo, repayBankInfo.repayAmt)"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="2">
              <el-button size="mini" @click="deleteBankHandle(idx)">删除</el-button>
            </el-col>
          </el-row>
        </template>

        <el-row :gutter="10">
          <el-col :span="24">
            <el-form-item label="审核结果选择" label-width="107px" prop="auditResultNum">
              <el-select v-model="infoData.auditResultNum">
                <el-option label="通过" :value="1"></el-option>
                <el-option label="拒绝" :value="2"></el-option>
                <el-option label="退回" :value="3"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="24">
            <el-form-item label="审核备注" label-width="100px" prop="auditRemark">
              <el-input type="textarea" v-model="infoData.auditRemark" maxlength="500"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </div>
    </el-form>
    <div class="repayment-confirm-detail-btns">
      <el-button type="primary" size="mini" @click="showFileuploadDialog">查看凭证</el-button>
      <el-button type="primary" size="mini" @click="submit" :disabled="submitSuccess">提交</el-button>
    </div>
    <approveHistory :approveHistoryData="approveHistoryData"></approveHistory>
    <!--文件上传弹窗-->
    <el-dialog title="请上传相关附件" :visible.sync="fileDialogVisible" :show-close="false">
      <p>温馨提示:系统支持上传的文件类型(*.pdf,*.docx,*.doc,*.jpg,*.jpeg,*.bmp,*.png,*.zip,*.rar,*.msg,*.eml,*.txt,*.wav</p>
      <p>单个word文件最大不能超过50.0MB;单个excel文件最大不能超过50.0MB;单个图片最大不能超过50.0MB;单个pdf文件最大不能超过50.0MB;单个压缩包文件最大不能超过20.0MB;</p>
      <FileUpload :pictureList="pictureList" @savePicItem="savePicItemFn"></FileUpload>
      <div slot="footer" class="dialog-footer">
        <el-button @click="fileDialogVisible = false" size="mini">关 闭</el-button>
        <el-button type="primary" @click="saveAllPics" size="mini">保 存</el-button>
      </div>
    </el-dialog>
    <!-- 应还金额已经变更 -->
    <el-dialog
      :visible.sync="currentPayDialogVisible"
      width="30%"
      center>
      <span slot="title" style="color: red;">注意</span>
      <span>当前应还总金额已变更，请确认是否继续提交</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="currentPayDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="submitAjax">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
  import approveHistory from './approveHistory'
  import {rentRepaymentInfo, dueBankList, approveHistoryList, cashierAudit, queryRepaymentDetailInfo, financialCheckResultPolling, repaySerialNoApi, calculate} from '../../api/financialManage'
  import {fmoney, rmoney, accMul} from '../../utils/constant'
  import {financialGetFile, financialSaveFile} from '../../api/upload.js'
  import FileUpload from '../../components/DialoginnerFileupload/fileupload'
  import RepayPlanTable from './repayPlanTable'
  export default {
    name: 'RepaymentConfirmDetail',
    data () {
      return {
        bookId: null,
        bookType: null,
        applyId: null,
        userId: null,
        billLoanNo: null,
        currentPayDialogVisible: false,
        currentNeedRepay: 0,
        oldCurrentNeedRepay: 0,
        currentCapitalName: '', // 还款计划右上角资方
        activeName: 'all', // 默认整体
        repaymentList: [], // 还款计划
        billLoanType: null, // 借据类型 0-普通借据 1-联合贷借据
        infoData: {
          auditResultNum: null,
          auditRemark: '',
          repayBankInfo: []
        },
        dueBankItemList: [], // 到账银行
        dueBankAccountList: [], // 到账账号
        approveHistoryData: [],
        pictureList: [{
          dictKey: 'book_file',
          fileRecordVOList: [],
          name: '还款勾稽凭证'
        }],
        fileDialogVisible: false,
        infoDataRule: {
          auditResultNum: [{required: true, message: '内容不可为空', trigger: 'change'}],
          auditRemark: [{required: true, message: '内容不可为空', trigger: 'blur'}]
        },
        windowCloseTimer: null,
        submitSuccess: false,
        rollDuration: 0, // 定时器间隔毫秒数
        financialCheckTimer: null, // 提前结清勾稽轮询定时器
        beforeRentXwPollLoading: null // 提前结清勾稽轮询提示弹窗实例
      }
    },
    components: {
      RepayPlanTable,
      approveHistory,
      FileUpload
    },
    mounted () {
      const {bookId, bookType, applyId, userId, billLoanNo} = this.$route.params
      this.bookId = bookId ? +bookId : null
      this.bookType = bookType ? +bookType : null
      this.applyId = applyId ? +applyId : null
      this.userId = userId ? +userId : null
      this.billLoanNo = billLoanNo || null
      if (this.bookType === 2) this.calculateHandle()
      this.getRepaymentPlans()
      this.getFormValue()
      this.getApproveHistoryList()
    },
    methods: {
      async getFormValue () {
        let dueBank = null
        try {
          dueBank = await this.getDueBankList()
        } catch (e) {
          return false
        }
        if (dueBank) {
          this.getRentRepaymentInfo()
        }
      },
      // 添加银行到账信息
      addBankHandle () {
        this.infoData.repayBankInfo.push({
          repayAmt: '',
          repayDate: '',
          repayName: '',
          repaySerialNo: ''
        })
      },
      // 删除
      deleteBankHandle (i) {
        this.infoData.repayBankInfo.splice(i, 1)
      },
      // 金额格式化
      fmoneyHandle (item, v) {
        let m = fmoney(v, 2)
        item.repayAmt = m
      },
      fmoneyFocusHandle (item, v, n = 1) {
        item.repayAmt = accMul(rmoney(v), n)
      },
      // 初始化金额格式化
      fMoneyEachHandle (arr) {
        arr.map(item => {
          this.fmoneyHandle(item, item.repayAmt / 100)
        })
      },
      // 当前明细更换
      activeChange (val) {
        this.getRepaymentPlans(val)
      },
      listenGetRepaymentPlans () {
        this.getRepaymentPlans(this.activeName)
      },
      // 到账银行
      dueBankChange () {
        this.dueBankItemList.filter(item => {
          if (item.bankCode === this.infoData.dueBank) {
            this.dueBankAccountList = item.dueAccounts
            this.infoData.dueAccount = this.dueBankAccountList[0]
          }
        })
      },
      // 还款计划
      getRepaymentPlans () {
        let capitalList = Array.from(arguments)
        let length = Array.from(arguments).length
        // 新网：EX-XW， 众邦：EX-ZB ，2345自有：2345
        let query = {}
        if (!length || capitalList[0] === 'all') { // 查询整体
          query = {
            userId: this.userId,
            billLoanNo: this.billLoanNo,
            applyId: this.applyId
          }
        } else {
          query = {
            userId: this.userId,
            billLoanNo: this.billLoanNo,
            applyId: this.applyId,
            capitalList
          }
        }
        queryRepaymentDetailInfo(query).then(res => {
          if (res.data.respCode === '1000') {
            const {repaymentPlanVOList, currentCapital, billLoanType, currentNeedRepay} = res.data.body
            repaymentPlanVOList.forEach(item => {
              if (item.repayDate) item.repayDate = item.repayDate.substring(0, 10)
            })
            this.currentCapitalName = currentCapital
            this.repaymentList = repaymentPlanVOList
            this.billLoanType = billLoanType
            if (this.bookType === 1) this.currentNeedRepay = currentNeedRepay
          }
        }).catch(err => { console.log(err) })
      },
      // 提前结清
      calculateHandle () {
        calculate(this.billLoanNo, this.userId).then(rst => {
          if (rst.data.respCode === '1000') {
            let {currentNeedRepay} = rst.data.body
            this.currentNeedRepay = currentNeedRepay
          }
        })
      },
      // 数据拉取
      getRentRepaymentInfo () {
        return new Promise((resolve, reject) => {
          rentRepaymentInfo(this.bookId).then(res => {
            if (res.data.respCode === '1000') {
              let data = res.data.body
              data.expectedTransferTime = data.expectedTransferTime.substring(0, 10)
              data.transferAmount = fmoney(data.transferAmount / 100)
              data.auditResultNum = null
              this.oldCurrentNeedRepay = data.currentNeedRepayAmount
              this.infoData = data
              this.infoData.repayBankInfo = data.repayBankInfo ? data.repayBankInfo : new Array(0)
              this.infoData.repayBankInfo.length > 0 && this.fMoneyEachHandle(this.infoData.repayBankInfo)
              this.dueBankChange() // 到账账号
              this.currentCapital = data.currentCapital
              resolve(1)
            }
          }).catch(err => { reject(err) })
        })
      },
      // 到账流水号校验
      repaySerialNoValidateHandle (val) {
        if (val.trim() === '') return false
        repaySerialNoApi({repaySerialNo: val}).then(rst => {
          if (rst.data.respCode === '1000' && rst.data.body.displayApplyIdList.length > 0) {
            this.$alert(`付款流水号已被申请件${rst.data.body.displayApplyIdList + ''} 使用，请确认是否继续使用此流水号！`, '注意', {center: true, customClass: 'warnTip'})
          }
        })
      },
      // 到账银行、账号
      getDueBankList () {
        return new Promise((resolve, reject) => {
          dueBankList(this.applyId).then(res => {
            if (res.data.respCode === '1000') {
              const {bankAccounts} = res.data.body
              this.dueBankItemList = bankAccounts
              resolve(1)
            }
          }).catch(err => { reject(err) })
        })
      },
      // 审批历史
      getApproveHistoryList () {
        approveHistoryList(this.bookId).then(res => {
          if (res.data.respCode === '1000') this.approveHistoryData = res.data.body
        }).catch(err => { console.log(err) })
      },
      // 凭证查看
      fileGet () {
        let data = {applyId: this.bookId, dictCategory: ['repayment_book_file'].join(',')}
        financialGetFile(data).then(res => {
          if (res.data.respCode === '1000') {
            const {pictureListVOList} = res.data.body
            this.pictureList = pictureListVOList
          }
        }).catch(err => { console.log(err) })
      },
      // 查看凭证
      showFileuploadDialog () {
        this.fileDialogVisible = true
        this.fileGet()
      },
      // 保存图片
      savePicItemFn (val) {
        this.pictureList.forEach(item => {
          if (item.dictKey === val.item.dictKey) {
            item.fileRecordVOList.push(val.data)
          }
        })
      },
      // 保存所有图片
      saveAllPics () {
        financialSaveFile({relatedId: this.bookId, pictureListVOList: this.pictureList}).then(res => {
          if (res.data.respCode === '1000') {
            this.$message.success('保存成功')
            this.fileDialogVisible = false
          }
        }).catch(err => { console.log(err) })
      },
      // 提交
      submit () {
        this.$refs['infoData'].validate(valid => {
          if (valid) {
            if (this.bookType !== 3 && this.oldCurrentNeedRepay !== this.currentNeedRepay) {
              this.currentPayDialogVisible = true
            } else {
              this.submitAjax()
            }
          }
        })
      },
      submitAjax () {
        let arr = JSON.parse(JSON.stringify(this.infoData.repayBankInfo))
        arr.map(item => {
          this.fmoneyFocusHandle(item, item.repayAmt, 100)
        })
        let apiParam = {
          id: this.bookId,
          auditResultNum: this.infoData.auditResultNum,
          auditRemark: this.infoData.auditRemark,
          dueAccount: this.infoData.dueAccount,
          dueBank: this.infoData.dueBank,
          repayBankInfo: arr
        }
        cashierAudit(apiParam).then(res => {
          if (res.data.respCode === '1000') {
            // 新网+提前结清+通过
            if (this.bookType === 2 && this.currentCapitalName === '新网银行' && apiParam.auditResult) {
              this.initBeforeRentXwPoll()
            } else {
              this.closeCurrentWindow('success', '操作成功，页面即将关闭！')
            }
          } else if (res.data.respCode === 'advance_settle_in_progress') {
            this.initBeforeRentXwPoll()
          }
          if (this.currentPayDialogVisible) this.currentPayDialogVisible = false
        }).catch(err => { console.log(err) })
      },
      // 新网 提前结清勾稽
      initBeforeRentXwPoll () {
        this.beforeRentXwPollLoading = this.$message({
          message: '审核结果查询中，请耐心等待',
          duration: 0
        })
        let rollCount = 1
        financialCheckResultPolling(this.bookId, rollCount).then(res => {
          if (res.data.respCode === '1000') {
            const {auditResult, rollDuration} = res.data.body
            if (auditResult === 'PROC') {
              this.rollDuration = rollDuration // 定时器毫秒
              this.beforeRentXwPoll(this.bookId, rollCount)
            }
            if (auditResult === 'SUCC') {
              this.closeCurrentWindow('success', '审核成功，页面即将关闭！')
            } else if (auditResult === 'FAIL') {
              this.$message.error('审核失败')
            }
          } else {
            if (this.beforeRentXwPollLoading) this.beforeRentXwPollLoading.close() // 关闭loading
          }
        })
      },
      beforeRentXwPoll (bookId, rollCount) {
        rollCount += 1
        clearTimeout(this.financialCheckTimer)
        this.financialCheckTimer = null
        this.financialCheckTimer = setTimeout(() => {
          console.log(rollCount)
          financialCheckResultPolling(bookId, rollCount).then(res => {
            if (res.data.respCode === '1000') {
              const {auditResult, rollDuration} = res.data.body
              if (auditResult !== 'PROC') {
                clearTimeout(this.financialCheckTimer)
                this.financialCheckTimer = null
                if (this.beforeRentXwPollLoading) this.beforeRentXwPollLoading.close() // 关闭loading
              } else {
                this.rollDuration = rollDuration // 定时器毫秒
                this.beforeRentXwPoll(this.bookId, rollCount)
              }
              if (auditResult === 'SUCC') {
                this.closeCurrentWindow('success', '审核成功，页面即将关闭！')
              } else if (auditResult === 'FAIL') {
                this.$message.error('审核失败')
              }
            } else {
              if (this.beforeRentXwPollLoading) this.beforeRentXwPollLoading.close() // 关闭loading
            }
          }).catch(() => {
            clearTimeout(this.financialCheckTimer)
            this.financialCheckTimer = null
            if (this.beforeRentXwPollLoading) this.beforeRentXwPollLoading.close() // 关闭loading
          })
        }, this.rollDuration)
      },

      // 提交成功关闭当前页面
      closeCurrentWindow (type, msg) {
        this.submitSuccess = true
        this.$message[type](msg)
        clearTimeout(this.windowCloseTimer)
        this.windowCloseTimer = setTimeout(() => {
          window.close()
        }, 3000)
      }
    }
  }
</script>
<style lang="scss" scoped>
  .repayment-confirm-detail-wrap{
    margin: 0 5px;
    padding-top: 2px;
  }
  .repayment-confirm-detail-formWrap{
    width: 95%;
    margin: 0 auto;
  }
  .approveHistoryData{
    margin-top: 10px;
  }
  .listPagination{
    float: right;
    margin-top: 5px;
  }
  .repayment-confirm-detail-btns{
    display: flex;
    flex-direction: row;
    justify-content: center;
  }
</style>
<style lang="scss">
.warnTip {
  .el-message-box__title span {
    color: red;
  }
  .el-message-box__message {
    text-align: left;
  }
}
</style>
