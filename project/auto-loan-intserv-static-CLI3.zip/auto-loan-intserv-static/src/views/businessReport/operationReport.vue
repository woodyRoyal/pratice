<!--运营信息表-->
<template>
  <div>
    <div ref="form"
         class="operation-report-query-form">
      <el-form size="mini"
               :inline="true">
        <el-form-item label="申请编号:">
          <el-input v-model="queryData.applyId"
                    class="w-100"
                    maxlength="8"
                    @change="checkApplyId(queryData.applyId, 'applyId')"></el-input>
        </el-form-item>
        <el-form-item label="申请编号(老)">
          <el-input v-model="queryData.oldApplyId"
                    class="w-100"
                    maxlength="7"
                    @change="checkApplyId(queryData.oldApplyId, 'oldApplyId',7)"></el-input>
        </el-form-item>
        <el-form-item label="客户姓名:">
          <el-input v-model="queryData.proposerName"
                    class="w-100"
                    maxlength="20"></el-input>
        </el-form-item>
        <!--<el-form-item label="客户联系方式:">
          <el-input v-model="queryData.phone" maxlength="11" @blur="checkQueryPhone(queryData.phone)"></el-input>
        </el-form-item>-->
        <el-form-item label="经销商名称:">
          <el-input v-model="queryData.dealerFullName"
                    maxlength="30"></el-input>
        </el-form-item>
        <el-form-item label="合同号:">
          <el-input v-model="queryData.contractNo"
                    maxlength="21"></el-input>
        </el-form-item>
        <el-form-item label="合同状态:">
          <el-select v-model="queryData.contractStatus"
                     multiple
                     collapse-tags
                     class="w-200">
            <el-option v-for="item in contractStatusOptions"
                       :key="item.code"
                       :value="item.code"
                       :label="item.desc"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="产品方案名称:">
          <el-input v-model="queryData.productName"
                    maxlength="30"></el-input>
        </el-form-item>

        <el-form-item label="放款日期:">
          <el-date-picker
            v-model="makeLoansDate"
            class="w-230"
            type="daterange"
            value-format="yyyy-MM-dd"
            range-separator="-"
            start-placeholder="开始日期"
            end-placeholder="结束日期">
          </el-date-picker>
        </el-form-item>

        <el-form-item label="有线GPS供应商:">
          <el-select v-model="queryData.wiredSupplier"
                     multiple
                     collapse-tags>
            <el-option v-for="item in gpsSuppliers"
                       :key="item.code"
                       :value="item.code"
                       :label="item.desc"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="无线GPS供应商:">
          <el-select v-model="queryData.wirelessSupplier"
                     multiple
                     collapse-tags>
            <el-option v-for="item in gpsSuppliers"
                       :key="item.code"
                       :value="item.code"
                       :label="item.desc"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="车架号:">
          <el-input v-model="queryData.carVin"
                    maxlength="17"></el-input>
        </el-form-item>
        <el-form-item label="车牌号:">
          <el-input v-model="queryData.carPlate"
                    maxlength="20"
                    class="w-100"></el-input>
        </el-form-item>
        <el-form-item label="放款资方:">
          <el-select v-model="queryData.makeLoansCompany"
                     multiple
                     collapse-tags>
            <el-option v-for="item in capitalOptions"
                       :key="item.code"
                       :value="item.code"
                       :label="item.desc"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="放款主体:">
          <el-select v-model="queryData.loanOrg"
                     class="w-100">
            <el-option v-for="item in loanOrgs"
                       :key="item.code"
                       :value="item.code"
                       :label="item.desc"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="是否逾期:">
          <el-select v-model="queryData.isOverDue"
                     class="w-100">
            <el-option value="否"
                       label="否"></el-option>
            <el-option value="是"
                       label="是"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="gps个数:">
          <el-select v-model="queryData.gpsCount"
                     multiple
                     collapse-tags
                     class="w-130">
            <el-option :value="0"
                       label="0"></el-option>
            <el-option :value="1"
                       label="1"></el-option>
            <el-option :value="2"
                       label="2"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="success"
                     size="mini"
                     :loading="isLoading"
                     @click="getOperationReport">
            查询
          </el-button>
          <el-button type="info"
                     size="mini"
                     :loading="isLoading"
                     @click="resetQuery">
            重置
          </el-button>
          <el-button type="primary"
                     size="mini"
                     :loading="operationDownloadLoading"
                     @click="tableDownload">
            下载
          </el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="table-Data">
      <el-table v-loading="isLoading"
                border
                :data="tableData"
                :max-height="tableMaxHeight">
        <el-table-column label="申请编号"
                         fixed="left">
          <template slot-scope="scope">
            {{ scope.row.applyId || '/' }}
            <el-tag v-if="scope.row.specialPermit"
                    type="warning"
                    size="mini">
              特批
            </el-tag>
            <el-tag v-if="scope.row.reconsideration"
                    type="warning"
                    size="mini">
              复议
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="申请编号(老)"
                         fixed="left">
          <template slot-scope="scope">
            <!--老系统显示 oldApplyId，新系统显示 '/'-->
            {{ scope.row.oldApplyId || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="申请类型"
                         fixed="left">
          <template slot-scope="scope">
            {{ scope.row.applyType || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="客户姓名"
                         fixed="left">
          <template slot-scope="scope">
            {{ scope.row.proposerName || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="客户联系方式"
                         fixed="left">
          <template slot-scope="scope">
            {{ scope.row.phone || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="经销商名称"
                         fixed="left">
          <template slot-scope="scope">
            {{ scope.row.dealerFullName || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="经销商简称">
          <template slot-scope="scope">
            {{ scope.row.dealerShortName || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="申请日期">
          <template slot-scope="scope">
            {{ scope.row.applyDate || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="放款日期">
          <template slot-scope="scope">
            {{ scope.row.makeLoansDate || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="产品方案名称">
          <template slot-scope="scope">
            {{ scope.row.productName || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="融资期限">
          <template slot-scope="scope">
            {{ scope.row.financingTerm || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="已还期数">
          <template slot-scope="scope">
            {{ scope.row.settleTrem || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="剩余本金">
          <template slot-scope="scope">
            {{ scope.row.surplusAmount || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="逾期期数">
          <template slot-scope="scope">
            {{ scope.row.overDueTerm || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="逾期天数">
          <template slot-scope="scope">
            {{ scope.row.overDueDays || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="合同状态">
          <template slot-scope="scope">
            {{ scope.row.contractStatus || '/' }}
          </template>
        </el-table-column>
        <!--todo 有线GPS供应商-->
        <el-table-column label="有线GPS供应商"
                         min-width="100">
          <template slot-scope="scope">
            {{ scope.row.wiredSupplier || '/' }}
          </template>
        </el-table-column>
        <!--todo 无线GPS供应商-->
        <el-table-column label="无线GPS供应商"
                         min-width="100">
          <template slot-scope="scope">
            {{ scope.row.wirelessSupplier || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="GPS个数">
          <template slot-scope="scope">
            {{ scope.row.gpsCount === null ? '/' : scope.row.gpsCount }}
          </template>
        </el-table-column>
        <el-table-column label="车架号">
          <template slot-scope="scope">
            {{ scope.row.carVin || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="车型">
          <template slot-scope="scope">
            {{ scope.row.carType || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="车牌号">
          <template slot-scope="scope">
            {{ scope.row.carPlate || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="发动机号">
          <template slot-scope="scope">
            {{ scope.row.carEngin || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="放款资方">
          <template slot-scope="scope">
            {{ scope.row.makeLoansCompany || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="资方放款金额">
          <template slot-scope="scope">
            {{ scope.row.pricinpalAmt || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="2345放款金额">
          <template slot-scope="scope">
            {{ scope.row.transferAmt || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="融资总额">
          <template slot-scope="scope">
            {{ scope.row.financingAmount || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="GPS价格">
          <template slot-scope="scope">
            {{ scope.row.gpsPrice || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="是否盗抢险">
          <template slot-scope="scope">
            {{ scope.row.isTheftPro || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="盗抢险金额">
          <template slot-scope="scope">
            {{ scope.row.theftProAmt || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="小贷标识">
          <template slot-scope="scope">
            {{ scope.row.loanTag || '/' }}
          </template>
        </el-table-column>
        <!--todo 服务费基数-->
        <el-table-column label="服务费基数">
          <template slot-scope="scope">
            {{ scope.row.servicePotency || '/' }}
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination
          :current-page.sync="pagination.pageNo"
          :page-sizes="pageSizes"
          :page-size="pagination.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="pagination.totalRecord"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        >
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import {checkApplyId, checkQueryPhone} from '../../utils/constant'
  import {operateInfoReportExport,queryOperateInfoAsync,queryReportResult} from '../../api/businessReport.js'
  export default {
    data () {
      return {
        checkApplyId,
        checkQueryPhone,
        contractStatusOptions: [
          {code: '0', desc: '初始状态'},
          {code: '1', desc: '合同生成已提交'},
          {code: '2', desc: '生效'},
          {code: '3', desc: '结清'},
          {code: '8', desc: '取消'},
          {code: '9', desc: '拒绝'},
        ],
        gpsSuppliers: [{code: '0', desc: '中瑞'}],
        // capitalOptions: [{code: '0', desc: '2345'}, {code: '1', desc: '新网银行'}, {code: '2', desc: '众邦银行'}],
        capitalOptions: [
          {code: '2345', desc: '2345自有资金'},
          {code: 'chouyin', desc: '稠银'},
          {code: 'EX-XW', desc: '新网银行'},
          {code: 'EX-ZB', desc: '众邦银行'},
        ],
        loanOrgs: [{code: '0', desc: '广州小贷'}, {code: '1', desc: '融资租赁'}],
        makeLoansDate: [],
        queryData: {
          oldApplyId: null,
          applyId: null,
          proposerName: '',
          dealerFullName: '',
          contractNo: '',
          contractStatus: [],
          productName: '',
          makeLoansDateFrom: '',
          makeLoansDateTo: '',
          wiredSupplier: [],
          wirelessSupplier: [],
          carVin: '',
          carPlate: '',
          makeLoansCompany: [],
          loanOrg: null,
          isOverDue: '',
          gpsCount: [],
        },
        tableData: [],
        tableMaxHeight: null,
        isLoading: false,
        pagination: {
          pageNo: 1,
          pageSize: 10,
          totalRecord: 0, // 总记录数
        },
        pageSizes: [10, 20, 30, 40],
        timer:null,
        intervalObj:{
          times:null,
          intervalTime:null,
          merchantCode:null,
        },
      }
    },
    computed: {
      ...mapGetters(['operationDownloadLoading']),
    },
    created () {
      document.title = '运营信息表'
    },
    mounted () {
      // this.getOperationReport()
      this.autoTableHeight()
      window.addEventListener('resize', this.autoTableHeight)
    },
    destroyed () {
      window.removeEventListener('resize', this.autoTableHeight)
    },
    methods: {
      getOperationReport () {
        const makeLoansDate = this.makeLoansDate
        const {
          applyId,
          oldApplyId,
          proposerName,
          dealerFullName,
          contractNo,
          contractStatus,
          productName,
          // makeLoansDateFrom,
          // makeLoansDateTo,
          wiredSupplier,
          wirelessSupplier,
          carVin,
          carPlate,
          makeLoansCompany,
          loanOrg,
          isOverDue,
          gpsCount,
        } = this.queryData
        if (!applyId && !oldApplyId && !proposerName && !dealerFullName && !contractNo && !(contractStatus && contractStatus.length) &&
          !productName && !(makeLoansDate && makeLoansDate.length) && !(wiredSupplier && wiredSupplier.length) &&
          !(wirelessSupplier && wirelessSupplier.length) && !carVin && !carPlate && !(makeLoansCompany && makeLoansCompany.length) &&
          !loanOrg && !isOverDue && !(gpsCount && gpsCount.length)) {
          this.$message.warning('请至少输入一项查询条件')
          return false
        }
        return new Promise(() => {
          this.queryData.makeLoansDateFrom = this.makeLoansDate && this.makeLoansDate.length ? this.makeLoansDate[0] : ''
          this.queryData.makeLoansDateTo = this.makeLoansDate && this.makeLoansDate.length ? this.makeLoansDate[1] : ''
          this.queryData.pageNo = this.pagination.pageNo
          this.queryData.pageSize = this.pagination.pageSize
          this.isLoading = true
          queryOperateInfoAsync(this.queryData).then((res) => {
            const {respCode, body} = res.data
            if (respCode === '1000') {
              this.intervalObj = {
                times:body.times,
                intervalTime:body.intervalTime,
                merchantCode:body.merchantCode,
              }
              this.startInterval()
              // this.timer = setInterval(this.startInterval(), intervalTime);
            } else  {
              this.isLoading = false
              this.intervalObj = {
                times:null,
                intervalTime:null,
                merchantCode:null,
              }
              if(this.timer) {
                window.clearInterval(this.timer)
              }
            }
          }).catch((err) => {
            this.isLoading = false
            console.error(err)
          })
        })
      },
      startInterval () {
        let interval = 3000
        if(this.intervalObj.intervalTime) {
            interval = this.intervalObj.intervalTime * 1000
          }
       this.timer = setInterval(this.fetchResult, interval);
      },
      fetchResult () {
        queryReportResult(this.intervalObj).then((res) => {
            const {respCode, body,respMsg} = res.data
            if (respCode !== 'QUERY_TIME_OUT' &&body.pageInfo) {
                this.isLoading = false
                this.tableData = body.pageInfo.list
                this.pagination.totalRecord = body.pageInfo.total
                if(this.timer) {
                clearInterval(this.timer)
              }
            } else if(respCode !== 'QUERY_TIME_OUT'&&!body.pageInfo&&body.intervalTime && body.times) {
              this.intervalObj.times = body.times
              this.intervalObj.intervalTime = body.intervalTime
            } else {
              this.isLoading = false
              this.$message.error(respMsg)
              if(this.timer) {
                clearInterval(this.timer)
              }
            } 
          }).catch((err) => {
            this.isLoading = false
            console.error(err)
          })
      },
      resetQuery () {
        this.makeLoansDate = []
        this.queryData = {
          oldApplyId: null,
          applyId: null,
          proposerName: '',
          dealerFullName: '',
          contractNo: '',
          contractStatus: [],
          productName: '',
          makeLoansDateFrom: '',
          makeLoansDateTo: '',
          wiredSupplier: [],
          wirelessSupplier: [],
          carVin: '',
          carPlate: '',
          makeLoansCompany: [],
          loanOrg: null,
          isOverDue: '',
          gpsCount: [],
        }
        this.pagination.pageNo = 1
        this.pagination.pageSize = 10
        // this.getOperationReport()
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagination.pageSize = val
        this.getOperationReport()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagination.pageNo = val
        this.getOperationReport()
      },
      // table最大高度
      autoTableHeight () {
        const clientHeight = document.documentElement.clientHeight || document.body.clientHeight
        // const formHeight = this.$refs['form'].offsetHeight
        this.tableMaxHeight = clientHeight - 105
      },
      // 直接下载提示
      messageBoxShow () {
        return new Promise((resolve) => {
          this.$confirm('请确保通过筛选条件将下载的数据控制在最小数量以内（建议500条以内），以避免下载失败。如下载量过大，请使用邮箱接收下载', '提示', {
            cancelButtonText: '取消下载',
            confirmButtonText: '确定下载',
          }).then(() => {
            resolve(1)
            // 空函数
          }).catch(() => {
            //空函数
          })
        })
      },
      // 文件导出
      operationReportExportHandle () {
        return new Promise((resolve, reject) => {
          this.queryData.makeLoansDateFrom = this.makeLoansDate && this.makeLoansDate.length ? this.makeLoansDate[0] : ''
          this.queryData.makeLoansDateTo = this.makeLoansDate && this.makeLoansDate.length ? this.makeLoansDate[1] : ''
          operateInfoReportExport(this.queryData).then((res) => {
            const {respCode, body} = res.data
            if (respCode === '1000') {
              const {serialNo} = body
              resolve(serialNo)
            }
          }).catch((err) => {
            reject(err)
            console.error(err)
          })
        })
      },
      // 直接下载
      async tableDownload () {
        const okDownload = await this.messageBoxShow()
        if (!okDownload) return false
        try {
          // const total = await this.getOperationReport()
          // if (total === 0) {
          //   this.$message.warning('该筛选条件下无表格可下载')
          //   return false
          // }
          const serialNo = await this.operationReportExportHandle()
          if (!serialNo) return false
          await this.$store.dispatch('reportDownloadPollingApi', {
            serialNo,
            reportKey: 'report_operate_info', // 运营信息查询表 key
            timer: 'operationReportTimer',
            notification: 'operationReportNotification',
            loading: 'operationDownloadLoading',
          })
        } catch (e) {
          console.error(e)
        }
      },
    },
  }
</script>
<style lang="scss" scoped>
  .w-100 {
    width: 100px;
  }
  .w-130 {
    width: 130px;
  }
  .w-140 {
    width: 140px;
  }
  .w-200 {
    width: 200px;
  }
  .w-230 {
    width: 230px;
  }
  .listPagination{
    float: right;
  }
  .el-form-item{
    margin-bottom: 10px;
  }
</style>
