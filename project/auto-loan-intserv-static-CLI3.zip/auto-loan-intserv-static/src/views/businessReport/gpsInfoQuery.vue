<template>
  <div>
    <div class="operation-report-query-form">
      <el-form size="mini"
               :inline="true">
        <el-form-item label="申请编号:">
          <el-input v-model="queryData.applyId"
                    maxlength="8"
                    @blur="checkApplyId(queryData.applyId)"></el-input>
        </el-form-item>
        <el-form-item label="申请编号(老)"
                      label-width="100px">
          <el-input v-model="queryData.oldApplyNo"
                    maxlength="7"
                    placeholder="申请编号(老)"
                    onkeypress="return(/^[0-9]*$/.test(String.fromCharCode(event.keyCode)))"
                    @blur="checkApplyId(queryData.oldApplyNo,'oldApplyNo',7)"></el-input>
        </el-form-item>
        <el-form-item label="车架号:">
          <el-input v-model="queryData.carVin"
                    maxlength="17"></el-input>
        </el-form-item>
        <el-form-item label="经销商名称:">
          <el-input v-model="queryData.dealerName"
                    maxlength="30"></el-input>
        </el-form-item>
        <el-form-item label="供应商:">
          <el-input v-model="queryData.gpsSupplier"
                    maxlength="30"></el-input>
        </el-form-item>
        <el-form-item label="产品方案名称:">
          <el-input v-model="queryData.productName"
                    maxlength="20"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary"
                     size="mini"
                     @click="getGpsReport">
            查询
          </el-button>
          <el-button type="primary"
                     size="mini"
                     @click="resetQuery">
            重置
          </el-button>
          <el-button type="primary"
                     size="mini"
                     :loading="exportLoading"
                     @click="tableDownload">
            下载
          </el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="table-Data">
      <el-table border
                :data="tableData">
        <el-table-column label="序号"
                         type="index"></el-table-column>
        <el-table-column label="申请编号">
          <template slot-scope="scope">
            {{ scope.row.applyId || '/' }}
            <el-tag v-if="scope.row.specialPermit"
                    type="warning"
                    size="mini">
              特批
            </el-tag>
            <el-tag v-if="scope.row.reconsideration"
                    type="warning"
                    size="mini">
              复议
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="申请编号(老)"
                         align="center">
          <template slot-scope="scope">
            <!--老系统显示 oldApplyNo，新系统显示 '/'-->
            {{ scope.row.oldApplyNo || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="期数">
          <template slot-scope="scope">
            {{ scope.row.term || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="产品方案">
          <template slot-scope="scope">
            {{ scope.row.productName || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="经销商全称">
          <template slot-scope="scope">
            {{ scope.row.dealerName || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="客户名称">
          <template slot-scope="scope">
            {{ scope.row.customName || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="车架号">
          <template slot-scope="scope">
            {{ scope.row.carVin || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="放款日期">
          <template slot-scope="scope">
            {{ scope.row.loanDate || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="GPS个数">
          <template slot-scope="scope">
            {{ scope.row.gpsAccount === null ? '/' : scope.row.gpsAccount }}
          </template>
        </el-table-column>
        <el-table-column label="有线设备">
          <template slot-scope="scope">
            {{ scope.row.wiredDeviceNum || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="无线设备">
          <template slot-scope="scope">
            {{ scope.row.wirelessDeviceNum || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="供应商">
          <template slot-scope="scope">
            {{ scope.row.gpsSupplier || '/' }}
          </template>
        </el-table-column>
        <el-table-column label="是否融盗抢险">
          <template slot-scope="scope">
            {{ scope.row.isInsurance || '/' }}
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-container">
        <el-pagination :current-page.sync="pagination.pageNo"
                       :page-sizes="pageSizes"
                       :page-size="pagination.pageSize"
                       layout="total, sizes, prev, pager, next, jumper"
                       :total="pagination.totalRecord"
                       @size-change="handleSizeChange"
                       @current-change="handleCurrentChange">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
  import { checkApplyId } from '../../utils/constant'
  import { gpsReport, gpsReportExport } from '../../api/businessReport.js'
  import {downLoadPolling} from '../../api/daihou' // 轮询接口通用
  const qs = require('qs')
  export default {
    data () {
      return {
        checkApplyId,
        queryData: {},
        pagination: {
          pageNo: 1,
          pageSize: 10,
          totalRecord: null, // 总记录数
        },
        maxHeight: 100,
        pageSizes: [10, 20, 30, 40],
        tableData: [],
        exportLoading: false,
        exportTimer: null,
      }
    },
    mounted () {
      this.getGpsReport()
    },
    methods: {
      getGpsReport () {
        this.queryData.pageNum = this.pagination.pageNo
        this.queryData.pageSize = this.pagination.pageSize
        return new Promise((resolve, reject) => {
          gpsReport(this.queryData).then((res) => {
            if (res.data.respCode === '1000') {
              let data = res.data.body
              this.tableData = data.list
              this.pagination.totalRecord = data.total
              resolve(1)
            } else {
              resolve(0)
            }
          }).catch((err) => { console.log(err) })
        })
      },
      resetQuery () {
        for (let k in this.queryData) {
          this.queryData[k] = null
        }
        this.getGpsReport()
        this.exportLoading = false
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagination.pageSize = val
        this.getGpsReport()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagination.pageNo = val
        this.getGpsReport()
      },
      tableDownload () {
        if (this.exportLoading) {
          this.$message.warning('文件正在生成')
          return false
        } else {
          this.exportLoading = true // 开启loading
          this.getGpsReport().then((data) => {
            if (data && this.tableData.length > 0) {
              gpsReportExport(this.queryData).then((res) => {
                if (res.data.respCode === '1000') {
                  let exportSerialNo = res.data.body.serialNo
                  clearInterval(this.exportTimer)
                  this.exportTimer = setInterval(() => {
                    downLoadPolling(exportSerialNo).then((res) => {
                      this.exportLoading = false // 关闭loading
                      if (res.data.respCode === '1000') {
                        let data = res.data.body
                        if (data.status) {
                          clearInterval(this.exportTimer)
                          // 导出
                          window.location.href = process.env.VUE_APP_BASE_API + '/download/export?' + qs.stringify({filename: data.filename, storePath: data.storePath})
                        }
                      } else {
                        clearInterval(this.exportTimer)
                      }
                    }).catch((error) => { console.log(error) })
                  }, 1000)
                } else {
                  this.exportLoading = false
                }
              }).catch((err) => { console.log(err) })
            } else {
              this.exportLoading = false // 关闭loading
              this.$message.warning('该筛选条件下无表格可下载')
            }
          })
        }
      },
    },
  }
</script>
<style lang="scss" scoped>
  .listPagination{
    float: right;
  }
  .el-form-item{
    margin-bottom: 10px;
  }
</style>
