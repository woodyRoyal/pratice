<template>
  <div class="station-wrapper">
    <el-form :inline="true" :model="queryForm">
      <el-form-item label="岗位名称:">
        <el-select size="small" v-model="queryForm.id">
          <el-option v-for="item in allPostList" :key="item.id" :value="item.id" :label="item.name"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="状态:">
        <el-select size="small" v-model="queryForm.status">
          <el-option v-for="item in isWorkList" :value="item.dictValue" :label="item.dictName" :key="item.dictValue"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="primary" @click="handleSearch">查询</el-button>
        <el-button size="mini" type="primary" @click="handleReset">重置</el-button>
      </el-form-item>
    </el-form>
    <!-- 查询数据 -->
    <!--<span class="font" @click="handleAdd">+新增岗位</span>-->
    <el-table style="margin-top: 5px;" border :data="tableData" :max-height="maxHeight">
      <el-table-column align="center" label="序号">
        <template slot-scope="scope">
          <span>{{ scope.$index + 1 }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="岗位代码" prop="id"></el-table-column>
      <el-table-column align="center" label="岗位名称" prop="name"></el-table-column>
      <el-table-column align="center" label="创建时间" prop="created"></el-table-column>
      <el-table-column align="center" label="状态">
        <template slot-scope="scope">
          <span>{{ scope.row.enable ? '有效' : '无效' }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="操作" width="300">
        <template slot-scope="scope">
          <el-button size="mini" type="primary" @click="handleEdit(scope.row)">编辑岗位功能</el-button>
          <el-button size="mini" type="primary" @click="handleWatchUser" disabled>查看岗位用户</el-button>
          <el-button size="mini" type="danger" @click="deleteStation(scope.row)" disabled>删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页对象 -->
    <div class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagable.pageNo" :page-sizes="pageSizes"
                     :page-size="pagable.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagable.totalRecord">
      </el-pagination>
    </div>
    <!-- 新增岗位dialog -->
    <el-dialog :title= "isAddOrEdit ? '岗位信息-新增' : '岗位信息-编辑'" :visible.sync="dialogVisible" width="50%" @close="handleDialogClose('addOrEditForm')">
      <el-form :inline="true" :model="addOrEditForm" :rules="rules" ref="addOrEditForm">
        <el-form-item label="岗位编号:">
          <el-input size="small" v-model="addOrEditForm.id" disabled></el-input>
        </el-form-item>
        <el-form-item label="岗位名称:" prop="name">
          <el-input size="small" v-model="addOrEditForm.name" disabled></el-input>
        </el-form-item>
        <div>
        <el-form-item>
          <!--<el-button size="small" type="primary" @click="expandOrShrink">{{isExpandOrNot ? '闭合' : '展开'}}</el-button>
          <el-button size="small" type="primary" @click="chooseAllTree">选定全部</el-button>
          <el-button size="small" type="primary" @click="cancelAllTree">取消选定</el-button>-->
        </el-form-item>
        </div>
        <el-form-item prop="resourceIds">
          <el-tree :default-expand-all="isExpandOrNot" node-key="id" ref="tree" :data="sourceTree" show-checkbox :props="defaultProps" class="tree-height" @check="handleNodeClick"></el-tree>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="handleAddOrEditForm">确 定</el-button>
  </span>
    </el-dialog>
  </div>
</template>

<script>
 import userApi from '../../api/user'
 import { mapGetters } from 'vuex'
 export default {
   computed: {
     ...mapGetters([
       'sourceTree',
       'allPostList'
     ])
   },
   data () {
     return {
       queryForm: {
         id: '',
         status: null
       },
       treeData: [], // 树数据
       defaultProps: {
         children: 'children',
         label: 'name'
       },
       isExpandOrNot: false, // 展开或者闭合
       isWorkList: [
         {dictValue: true, dictName: '有效'},
         {dictValue: false, dictName: '无效'}
       ],
       isAddOrEdit: false,
       addOrEditForm: { // 新增或编辑表单
         id: null,
         name: '',
         resourceIds: []
       },
       rules: { // 表单验证规则
         name: [
           { required: true, message: '请输入岗位名称', trigger: 'blur' },
           { max: 50, message: '长度限制在50个字符', trigger: 'blur' }
         ],
         resourceIds: [
           { required: true, message: '请选择权限', trigger: 'change' }
         ]
       },
       dialogVisible: false, // 新增岗位或编辑岗位dialog
       tableData: [],
       pagable: {
         pageNo: 1,
         pageSize: 10,
         totalRecord: null // 总记录数
       },
       maxHeight: 100,
       pageSizes: [10, 20, 30, 40]
     }
   },
   mounted () {
     this.getTableData()
     // 获取资源树
     this.getSourceTree()
     // 获取所有岗位
     this.getAllPost()
     // 调整高度
     this.handleResize()
     window.addEventListener('resize', this.handleResize)
   },
   destroyed () {
     window.removeEventListener('resize', this.handleResize)
   },
   methods: {
     // 表格高度
     handleResize (event) {
       this.$nextTick(() => {
         let h = document.documentElement.clientHeight
         this.maxHeight = h - 250
       })
     },
     // 获取表格数据
     getTableData () {
       let data = {
         id: this.queryForm.id || null,
         enable: this.queryForm.status,
         pageNum: this.pagable.pageNo,
         pageSize: this.pagable.pageSize
       }
       userApi.fetchStation(data)
         .then(response => {
           let res = response.data
           if (res.respCode === '1000') {
             this.tableData = res.body.list
             this.pagable.totalRecord = res.body.total
           }
         })
         .catch(error => {
           console.log(error)
         })
     },
     // 处理分页每页显示数改变事件
     handleSizeChange (val) {
       this.pagable.pageSize = val
       this.getTableData()
     },
     // 处理页码改变事件
     handleCurrentChange (val) {
       this.pagable.pageNo = val
       this.getTableData()
     },
     // 查询表格数据
     handleSearch () {
       this.getTableData()
     },
     // 搜索条件重置
     handleReset () {
       this.queryForm = {
         status: null,
         id: ''
       }
       this.pagable = {
         pageNo: 1,
         pageSize: 10,
         totalRecord: null // 总记录数
       }
       this.getTableData()
     },
     // 删除岗位
     deleteStation (val) {
       let flag = true
       if (flag) {
         this.$confirm('当前该岗位有关联用户,不可直接删除,请先将用户移除该岗位?', '警告', {
           confirmButtonText: '查看岗位用户',
           cancelButtonText: '取消',
           type: 'warning'
         }).then(() => {
           // todo 跳转岗位用户
         }).catch(() => {
         })
       } else {
         this.$confirm('请确认是否删除该岗位?', '提示', {
           confirmButtonText: '确定',
           cancelButtonText: '取消',
           type: 'warning'
         }).then(() => {
           this.deleteStationAgain(val)
         }).catch(() => {
           this.$message({
             type: 'info',
             message: '已取消删除'
           })
         })
       }
     },
     // 删除岗位
     deleteStationAgain (val) {
       // todo 请求删除岗位接口
     },
     // 新增岗位
     handleAdd () {
       this.dialogVisible = true
       this.isAddOrEdit = true
     },
     // 编辑岗位
     handleEdit (val) {
       userApi.fetchFindPostById(val.id)
         .then(response => {
           let res = response.data
           if (res.respCode === '1000') {
             this.addOrEditForm = Object.assign({}, res.body)
             this.dialogVisible = true
             this.$nextTick(() => {
               this.$refs.tree.setCheckedKeys(this.addOrEditForm.resourceIds)
             })
             this.isAddOrEdit = false
           } else {
             this.$message.warning(res.respMsg)
           }
         })
         .catch(error => {
           console.log(error)
         })
     },
     // 树形展开或者闭合
     expandOrShrink () {
       this.isExpandOrNot = !this.isExpandOrNot
       this.$refs.tree.store._getAllNodes().forEach((item, index) => {
         this.$refs.tree.store._getAllNodes()[index].expanded = this.isExpandOrNot
       })
     },
     // 树选中全部
     chooseAllTree () {
     },
     // 取消选择
     cancelAllTree () {
       this.$refs.tree.setCheckedKeys([])
     },
     // 弹框关闭
     handleDialogClose (formName) {
       this.$refs[formName].resetFields()
       this.addOrEditForm = {
         id: null,
         name: '',
         resourceIds: []
       }
       this.$refs.tree.setCheckedKeys([])
     },
     // 弹框确认
     handleAddOrEditForm () {
       this.submitForm('addOrEditForm')
     },
     submitForm (formName) {
       this.$refs[formName].validate((valid) => {
         if (valid) {
           this.submitFormConfirm()
         } else {
           console.log('error submit!!')
           return false
         }
       })
     },
     // 确认更新
     submitFormConfirm () {
       userApi.fetchUpdatePost(this.addOrEditForm)
         .then(response => {
           let res = response.data
           if (res.respCode === '1000') {
             this.$message.success('更新成功')
             this.dialogVisible = false
             this.getTableData()
           } else {
             this.$message.warning(res.respMsg)
           }
         })
         .catch(error => {
           console.log(error)
         })
     },
     // 查看岗位用户
     handleWatchUser () {
       window.open('#/all-station')
     },
     // 获取资源树
     getSourceTree () {
       if (!this.sourceTree.length) {
         this.$store.dispatch('getSourceTree')
       }
     },
     // 所有岗位信息
     getAllPost () {
       if (!this.allPostList.length) {
         this.$store.dispatch('getAllPost')
       }
     },
     // 树节点
     handleNodeClick (data) {
       let arr = this.$refs.tree.getCheckedNodes()
       let brr = []
       arr.forEach(item => {
         brr.push(item.id)
       })
       this.addOrEditForm.resourceIds = brr
     }
   }
 }
</script>

<style lang="scss" scoped>
  .station-wrapper {
    .font{
      color:blue;
      cursor: pointer;
      font-size:14px;
    }
    .tree-height{
      max-height: 300px;
      overflow: auto;
      width: 300px;
    }
    .el-form-item {
      margin-bottom: 10px;
    }
  }
</style>