<template>
  <div class="dealer-info-wrapper">
    <el-button type="primary" size="small" class="position" @click="saveAndNext">保存并进入下一步</el-button>
    <el-button size="small" class="position position1" @click="handleSubmitApplication">提交申请</el-button>
    <el-tabs v-model="status" @tab-click="handleTabClick">
      <el-tab-pane label="基本信息" name="0">
        <dealerBaseInfo ref="baseInfoPart" @skipPage="skipPage" @submitCheck="submitCheck"></dealerBaseInfo>
      </el-tab-pane>
      <el-tab-pane label="系统用户信息" name="1" :disabled="isShow">
        <systemUserInfo></systemUserInfo>
      </el-tab-pane>
      <el-tab-pane label="附件" name="2" :disabled="isShow">
        <attachment ref="attachment" @skipPage="skipPage"></attachment>
      </el-tab-pane>
      <!--<el-tab-pane label="操作日志" name="3" :disabled="isShow"></el-tab-pane>-->
    </el-tabs>
  </div>
</template>

<script>
 // import {getImgMenuByArr} from 'api/upload.js'
 import dealerBaseInfo from './dealerBaseInfo'
 import systemUserInfo from './systemUserInfo.vue'
 import attachment from './attachment.vue'
 import dealerApi from '../../api/dealer'
 export default {
   components: {
     dealerBaseInfo, systemUserInfo, attachment
   },
   data () {
     return {
       isShow: true,
       status: '0',
       selectData: [], // 所有字典数据
       bizLinesData: [], // 业务种类
       systemUserInfoData: [], // 系统用户数据
       dealerInfoForm: {} // 基板信息
     }
   },
   mounted () {
     if (this.$route.params.id !== 'null') {
       this.isShow = false
     } else {
       this.isShow = true
     }
   },
   watch: {
     $route: {
       handler: function (val, oldVal) {
         if (val.params.id !== 'null') {
           this.isShow = false
         } else {
           this.isShow = true
         }
       }
     }
   },
   methods: {
     // 页数跳转
     skipPage () {
       if (this.status === '2') {
         this.status = '0'
         return false
       }
       this.status = parseInt(this.status) + 1 + ''
     },
     // 表头点击事件
     handleTabClick () {
     },
     saveAndNext () {
       if (this.status === '0') {
         this.$refs.baseInfoPart.saveData()
       } else if (this.status === '2') {
         this.$refs.attachment.saveData()
       } else if (this.status === '1') {
         this.status = parseInt(this.status) + 1 + ''
       }
     },
     // 子组件校验
     submitCheck (value) {
       if (value) {
         if (this.$route.params.id === 'null') {
           this.$message.warning('请先保存基本信息')
         } else {
           this.handleSubmitApplicationAgain()
         }
       } else {
         this.$message.warning('请检查基本信息是否填写完整或是否存在格式错误')
       }
     },
     handleSubmitApplicationAgain () {
       dealerApi.fetchSubmitDealerApplication(parseInt(this.$route.params.id))
         .then(response => {
           let res = response.data
           if (res.respCode === '1000') {
             this.$message.success('申请提交成功')
           }
         })
         .catch(error => {
           console.log(error)
         })
     },
     // 提交申请
     handleSubmitApplication () {
       this.$refs.baseInfoPart.submitFormParent('dealerInfoForm')
     }
   }
 }
</script>

<style lang="scss" scoped>
  .dealer-info-wrapper{
   .position{
     position: absolute;
     right: 110px;
     top: 5px;
     z-index: 20;
   }
    .position1 {
      right:20px;
    }
  }
</style>