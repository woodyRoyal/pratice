<template>
  <div>
    <el-form size="small" label-position="left" inline>
      <el-form-item label="申请编号">
        <el-input v-model="queryParam.applyId" maxlength="8"></el-input>
      </el-form-item>
      <el-form-item label="客户姓名">
        <el-input v-model="queryParam.name" maxlength="20"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button size="small" type="primary" @click="getTableList">查 询</el-button>
        <el-button size="small" type="primary" @click="resetQuery">重 置</el-button>
      </el-form-item>
    </el-form>
    <el-table border :data="dataTable">
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="申请编号" align="center">
        <template slot-scope="scope">
          {{scope.row.applyId}}
          <el-tag type="warning" size="mini" v-if="scope.row.specialPermit">特批</el-tag>
          <el-tag type="warning" size="mini" v-if="scope.row.reconsideration">复议</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="客户名称" align="center" property="name"></el-table-column>
      <el-table-column label="当前资方" align="center" property="capitalDesc"></el-table-column>
      <el-table-column label="申请状态" align="center" property="applyStatusDesc"></el-table-column>
      <el-table-column label="当前节点" align="center" property="currentNodeDesc"></el-table-column>
      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="changeCapital(scope.row)">切换资方</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
  import { applyProgress, changeCapitalApi } from '../../api/applyProgress.js'
  export default {
    data () {
      return {
        queryParam: {
          applyId: '',
          name: ''
        },
        dataTable: []
      }
    },
    mounted () {
      // this.getTableList()
    },
    methods: {
      getTableList () {
        const {applyId, name} = this.queryParam
        if ((applyId !== '' && (/^\d{8}$/.test(applyId))) || name !== '') {
          applyProgress(this.queryParam).then(res => {
            if (res.data.respCode === '1000') {
              const {list} = res.data.body
              this.dataTable = list
            }
          }).catch(err => { console.log(err) })
        } else if (applyId !== '' && !(/^\d{8}$/.test(applyId))) {
          this.queryParam.applyId = ''
          this.$message.warning('申请编号输入有误')
        } else if (applyId === '' || name === '') {
          this.$message.warning('请输入申请编号或姓名')
        }
      },
      resetQuery () {
        this.queryParam.applyId = ''
        this.queryParam.name = ''
        this.dataTable = []
      },
      changeCapital (row) {
        this.$confirm('确定将当前资方切换为<strong style="color: red; font-weight: bold">自有资金</strong>吗？操作后不可恢复，请谨慎操作', '提示', {
          dangerouslyUseHTMLString: true,
          confirmButtonText: '确认切换',
          cancelButtonText: '取消'
        })
          .then(() => {
            changeCapitalApi(row.id).then(res => {
              if (res.data.respCode === '1000') {
                this.$message.success('资方已切换成功')
                this.getTableList()
              }
            }).catch(err => { console.log(err) })
          })
          .catch(action => {})
      }
    }
  }
</script>
