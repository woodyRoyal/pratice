<template>
  <main class="content-container"
        :class="{'left-collapsed' :!sidebar.opened, 'left-expanded':sidebar.opened}">
    <transition name="fade" mode="out-in">
      <router-view :key="key"></router-view>
    </transition>
  </main>
</template>

<script>
  import { mapGetters } from 'vuex'

  export default {
    name: 'AppMain',
    computed: {
      ...mapGetters([
        'sidebar'
        // 'isFullscreen'
      ]),
      key () {
        return this.$route.name !== undefined
          ? this.$route.name + +new Date()
          : this.$route + +new Date()
      }
    }
  }
</script>

<style lang="scss">
  .content-container {
    position: absolute;
    height: calc(100% - 40px);
    overflow: auto;
    background: #fff;
    flex: 1;
    padding: 10px;
  }

  .left-collapsed {
    left: 40px;
    width: calc(100% - 40px);
  }

  .left-expanded {
    left: 180px;
    width: calc(100% - 180px);
  }

  .is-fullscreen {
    height: 100%;
    width: 100%;
    left: 0;
  }
</style>
