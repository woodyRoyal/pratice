<template>
  <div class="container">
    <navbar></navbar>
    <sidebar></sidebar>
    <app-main></app-main>
  </div>
</template>

<script>
  import { Navbar, AppMain } from 'views/layout'
  import Sidebar from './components/Sidebar/index'

  export default {
    name: 'layout',
    components: {
      Navbar,
      Sidebar,
      AppMain
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
  .container {
    position: absolute;
    top: 0;
    bottom: 0;
    width: 100%;
  }
</style>
