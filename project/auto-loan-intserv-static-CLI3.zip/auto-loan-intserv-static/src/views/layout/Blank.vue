/**
* 多级菜单时使用的空白组件
* Created by zuo
*/

<template>
  <transition name="fade" mode="out-in">
    <router-view></router-view>
  </transition>
</template>

<script>
  export default {
    name: 'Blank',
    computed: {}
  }
</script>
