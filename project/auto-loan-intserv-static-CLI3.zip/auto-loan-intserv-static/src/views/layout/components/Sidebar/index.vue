<template>
  <aside class="sidebar-container" :class="!sidebar.opened ? 'menu-collapsed' : 'menu-expanded'">
    <el-menu mode="vertical" :default-active="$route.path" :collapse="isCollapse" background-color="#eef1f6"
             :class="!sidebar.opened ? 'collapsed-menu' : 'expanded-menu'">
      <sidebar-item :routes="permissionRouters"></sidebar-item>
    </el-menu>

    <div class="toggle-menu-collapsed" :title="sidebar.opened ? '收起':'展开'">
      <a @click="toggleSideBar" :class="[sidebar.opened ? 'menu-expanded':'menu-collapsed']">
        <i class="iconfont" :class="[sidebar.opened ? 'icon-arrow-left':'icon-arrow-right']"></i>
      </a>
    </div>
  </aside>
</template>

<script>
  import { mapGetters } from 'vuex'
  import SidebarItem from './SidebarItem'

  export default {
    components: {SidebarItem},
    computed: {
      ...mapGetters([
        'permissionRouters',
        'sidebar'
      ]),
      isCollapse () {
        return !this.sidebar.opened
      }
    },
    methods: {
      toggleSideBar () {
        this.$store.dispatch('ToggleSideBar')
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
  .sidebar-container {
    position: absolute;
    transition-duration: .3s;
    width: 180px;
    height: calc(100% - 40px);
    .iconfont {
      margin-right: 10px;
      font-size: 18px;
    }
    .el-menu {
      height: calc(100% - 40px);
      border-radius: 0;
      background-color: #eef1f6;
      .el-submenu .el-menu-item {
        min-width: 0;
      }
      .el-menu-item, .el-submenu__title {
        height: 50px;
        line-height: 50px;
      }
      .el-menu-item:focus {
        background-color: #e4e8f1;
      }
      .el-menu-item:hover {
        background-color: #d1dbe5;
      }
    }
    .collapsed {
      transition-duration: .5s;
      width: 40px;
      .item {
        position: relative;
      }
      .submenu {
        position: absolute;
        top: 0;
        left: 50px;
        z-index: 99999;
        height: auto;
        display: none;
      }
    }
    .el-menu-item, .el-submenu__title {
      padding: 0 16px;
    }
    .el-submenu {
      background: none;
    }
    .submenu-user-defined {
      padding-left: 35px !important;
    }
  }

  .menu-collapsed {
    transition-duration: .5s;
    width: 40px;
  }

  .menu-expanded {
    transition-duration: .3s;
    width: 180px;
  }

  .toggle-menu-collapsed a {
    position: fixed;
    bottom: 0;
    left: 0;
    font-size: 13px;
    height: 40px;
    text-align: center;
    line-height: 40px;
    transition-duration: .3s;
    outline: none;
    color: #48576a;
    background: #e4e8f1;
    .iconfont {
      margin: 0;
    }
  }

  /*滚动条整体部分 定义滚动条高宽及背景*/
  ::-webkit-scrollbar {
    width: 6px;
    height: 8px;
    background: none;
  }

  /*!*滚动条的轨道 内阴影+圆角*!*/
  ::-webkit-scrollbar-track-piece {
    background: none;
  }

  /*!*滚动条里面的滑块 内阴影+圆角*!*/
  ::-webkit-scrollbar-thumb {
    background-color: #8492A6;
    border-radius: 1px;
  }
</style>