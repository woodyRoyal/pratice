<template>
  <div class="station-wrapper">
    <el-row>
      <el-form :inline="true" :model="queryForm">
        <el-col :span="5">
          <el-form-item align="center" label="机构:">
          </el-form-item>
          <div>
            <el-cascader size="small" @change="handleChangeCheck" :options="treeData" v-model="orgId" :props="defaultProps" :show-all-levels="false"></el-cascader>
          </div>
        </el-col>
        <el-col :span="19">
          <!-- 查询条件 -->
          <el-form-item label="操作账号:">
            <el-input size="small" v-model="queryForm.loginName"></el-input>
          </el-form-item>
          <el-form-item label="姓名:">
            <el-input size="small" v-model="queryForm.name"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button size="small" type="primary" @click="handleSearch">查询</el-button>
            <el-button size="small" type="primary" @click="handleReset">重置</el-button>
          </el-form-item>
          <!-- 数据 -->
          <el-table style="margin-top:5px;"  border :data="tableData" :max-height="maxHeight">
            <el-table-column label="序号">
              <template slot-scope="scope">
                <span>{{scope.$index + 1}}</span>
              </template>
            </el-table-column>
            <el-table-column label="操作账号" prop="loginName"></el-table-column>
            <el-table-column label="姓名" prop="name"></el-table-column>
            <el-table-column label="状态">
              <template slot-scope="scope">
                <span>{{ scope.row.isValid ? '无效' : '有效' }}</span>
              </template>
            </el-table-column>
            <!--<el-table-column label="登录状态" prop=""></el-table-column>-->
            <el-table-column label="锁定状态">
              <template slot-scope="scope">
                <span>{{ scope.row.isLock ? '锁定' : '未锁定' }}</span>
              </template>
            </el-table-column>
            <el-table-column label="岗位名称" prop="postName"></el-table-column>
            <!--<el-table-column label="用户最近登录时间" prop=""></el-table-column>-->
            <!--<el-table-column label="最近签退时间" prop=""></el-table-column>-->
            <el-table-column align="center" label="操作" width="250">
              <template slot-scope="scope">
                <el-button type="primary" size="mini" disabled @click="handleEdit(scope.row)">编辑</el-button>
                <el-button type="primary" size="mini" disabled>解锁</el-button>
                <el-button type="primary" size="mini" @click="handleResetPass(scope.row)">重置密码</el-button>
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页 -->
          <div class="pagination-container">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                           :current-page.sync="pagable.pageNo" :page-sizes="pageSizes"
                           :page-size="pagable.pageSize" layout="total, sizes, prev, pager, next, jumper"
                           :total="pagable.totalRecord">
            </el-pagination>
          </div>
        </el-col>
      </el-form>
    </el-row>
  </div>
</template>

<script>
  import userApi from '../../api/user'
  import { mapGetters } from 'vuex'
  export default {
    computed: {
      ...mapGetters([
        'displayName'
      ])
    },
    data () {
      return {
        orgId: [],
        queryForm: {
          loginName: '',
          name: ''
        }, // 查询表单
        treeData: [], // 树数据
        defaultProps: {
          children: 'children',
          label: 'orgName',
          value: 'orgId'
        },
        pagable: {
          pageNo: 1,
          pageSize: 10,
          totalRecord: null // 总记录数
        },
        maxHeight: 100,
        pageSizes: [10, 20, 30, 40],
        tableData: []
      }
    },
    mounted () {
      this.queryOrgList()
      // 获取数据
      this.getTableData()
      // 调整高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    destroyed () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // 表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let h = document.documentElement.clientHeight
          this.maxHeight = h - 250
        })
      },
      // 获取机构数
      queryOrgList () {
        let data = {
          orgId: 0,
          subQueryFlag: true,
          subQueryLev: 0
        }
        userApi.fetchQueryOrgList(data)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.treeData = JSON.parse(res.body)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagable.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagable.pageNo = val
        this.getTableData()()
      },
      // 搜索按钮
      handleSearch () {
        this.getTableData()
      },
      // 重置搜索条件
      handleReset () {
        this.orgId = []
        this.queryForm = {
          loginName: '',
          name: ''
        } // 查询表单
        this.pagable = {
          pageNo: 1,
          pageSize: 10,
          totalRecord: null // 总记录数
        }
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        let data = {
          name: this.queryForm.name || null,
          loginName: this.queryForm.loginName || null,
          orgId: this.orgId.length ? this.orgId[this.orgId.length - 1] : null,
          pageNum: this.pagable.pageNo,
          pageSize: this.pagable.pageSize
        }
        userApi.fetchBUserData(data)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.tableData = res.body.list
              this.pagable.totalRecord = res.body.total
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 重置密码
      handleResetPass (val) {
        this.$confirm('是否确定重置密码?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.handleResetPassAgain(val)
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消操作'
          })
        })
      },
      // 确认重置密码
      handleResetPassAgain (val) {
        let data = {
          userId: val.userId,
          operator: this.displayName
        }
        userApi.fetchResetBPassword(data)
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.$message.success('密码重置成功')
              this.getTableData()
            } else {
              this.$message.warning(res.respMsg)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 树节点选择
      handleChangeCheck () {
        this.getTableData() // 获取数据
      }
    }
  }
</script>

<style lang="scss" scoped>
  .tree-height{
    max-height: 300px;
    overflow: auto;
    width: 100%;
  }
  .el-form-item {
    margin-bottom: 10px;
  }
</style>