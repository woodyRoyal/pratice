<template>
  <div class="station-wrapper">
    <el-row>
      <el-form :inline="true" :model="queryForm">
        <el-col :span="5">
          <el-form-item align="center" label="机构:">
          </el-form-item>
          <div>
             <el-tree check-strictly node-key="key" ref="tree" :data="treeData" show-checkbox :props="defaultProps" class="tree-height"></el-tree>
          </div>
        </el-col>
        <el-col :span="19">
          <!-- 查询条件 -->
            <el-form-item align="center" label="机构代码:">
              <el-input size="small"></el-input>
            </el-form-item>
            <el-form-item align="center" label="机构名称:">
              <el-input size="small"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button size="small" type="primary" @click="handleSearch">查询</el-button>
              <el-button size="small" type="primary" @click="handleReset">重置</el-button>
            </el-form-item>
          <div>
            <span style="color:blue;cursor: pointer;font-size: 14px;" @click="handleAdd">+新增</span>
          </div>
          <!-- 数据 -->
          <el-table style="margin-top:5px;"  border :data="tableData">
            <el-table-column align="center" label="序号"></el-table-column>
            <el-table-column align="center" label="机构代码"></el-table-column>
            <el-table-column align="center" label="机构名称"></el-table-column>
            <el-table-column align="center" label="有效标志"></el-table-column>
            <el-table-column align="center" label="操作">
              <template slot-scope="scope">
                <el-button size="mini" type="primary">编辑</el-button>
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页 -->
          <div class="pagination-container">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                           :current-page.sync="pagable.pageNo" :page-sizes="pageSizes"
                           :page-size="pagable.pageSize" layout="total, sizes, prev, pager, next, jumper"
                           :total="pagable.totalRecord">
            </el-pagination>
          </div>
        </el-col>
      </el-form>
    </el-row>
    <!-- 新增机构dialog -->
    <el-dialog title="机构信息" :visible.sync="dialogVisible">
      <el-form :inline="true">
        <el-form-item label="机构名称:">
          <el-input size="small"></el-input>
        </el-form-item>
        <el-form-item label="上级机构:">
          <el-input size="small"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogVisible = false">保 存</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  import userApi from '../../api/user'
  export default {
    data () {
      return {
        queryForm: {
        },
        treeData: [{
          label: '一级 1',
          key: 1,
          children: [{
            label: '二级 1-1',
            key: 2,
            children: [{
              label: '三级 1-1-1',
              key: 3
            }]
          }]
        }], // 树数据
        defaultProps: {
          children: 'children',
          label: 'label'
        },
        dialogVisible: false, // 新增dialog弹框
        pagable: {
          pageNo: 1,
          pageSize: 100,
          totalRecord: null // 总记录数
        },
        maxHeight: 750,
        pageSizes: [50, 100, 200, 500],
        tableData: [{}]
      }
    },
    methods: {
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagable.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagable.pageNo = val
        this.getTableData()()
      },
      // 搜索按钮
      handleSearch () {
        this.getTableData()
      },
      // 重置搜索条件
      handleReset () {
        this.queryForm = {
        }
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        userApi.fetchMechanismData()
          .then(response => {
            let res = response.data
            if (res.respCode === '1000') {
              this.tableData = res.body.list
              this.pagable.totalRecord = res.body.total
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 新增
      handleAdd () {
        this.dialogVisible = true
      }
    }
  }
</script>

<style lang="scss" scoped>
  .tree-height{
    max-height: 300px;
    overflow: auto;
    width: 100%;
  }
  .el-form-item {
    margin-bottom: 10px;
  }
</style>