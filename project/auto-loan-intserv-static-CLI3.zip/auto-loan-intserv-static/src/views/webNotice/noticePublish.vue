<template>
  <div>
    <div class="query-form">
      <el-form :inline="true" size="small">
        <el-form-item label="发布日期（起）">
          <el-date-picker type="date" value-format="yyyy-MM-dd" v-model="queryData.startTime"></el-date-picker>
        </el-form-item>
        <el-form-item label="发布日期（止）">
          <el-date-picker type="date" value-format="yyyy-MM-dd" v-model="queryData.endTime"></el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button size="mini" type="primary" @click="noticeQuery">查询</el-button>
          <el-button size="mini" type="primary" @click="noticeResetQuery">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <el-button type="text" @click="addNotice">新增公告</el-button>
    <div class="dataTable">
      <el-table :data="dataTable" border>
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="标题" prop="title"></el-table-column>
        <el-table-column label="发布人" prop="operator"></el-table-column>
        <el-table-column label="发布时间" prop="publishTime"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="text" size="mini" @click="checkNoticeItem(scope.row)">查看</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                       :current-page.sync="page.pageNum" :page-sizes="page.pageSizes"
                       :page-size="page.pageSize" layout="total, sizes, prev, pager, next, jumper"
                       :total="page.total">
        </el-pagination>
      </div>
    </div>
    <el-dialog title="公告详情" :visible.sync="dialogFormVisible" @closed="closeAddNotice">
      <el-form :model="noticeAddData" size="small" label-position="left" :rules="noticeAddDataRule" ref="noticeAddData">
        <el-form-item label="标题" label-width="55px" prop="title">
          <el-input v-model="noticeAddData.title" placeholder="请输入标题，字数限制50" maxlength="50" :disabled="Boolean(addOrCheck)"></el-input>
        </el-form-item>
        <el-form-item label="内容" label-width="55px" prop="content">
          <!--<el-input v-model="noticeAddData.content" type="textarea" placeholder="请输入内容，字数限2000" maxlength="2000"></el-input>-->
          <quill-editor
            v-model="noticeAddData.content"
            ref="myQuillEditor"
            :options="editorOption"
            @blur="onEditorBlur($event)"
            @focus="onEditorFocus($event)"
            @ready="onEditorReady($event)"
            v-if="!addOrCheck">
          </quill-editor>
          <div v-html="noticeAddData.content" v-else class="notice-content"></div>
        </el-form-item>
        <el-form-item label="附件资料" label-width="80px" v-if="!addOrCheck">
          <el-button @click="trigger" type="primary" size="mini">+附件</el-button>
          <span>支持批量添加，限50M</span>
          <input type="file" @change="fileUpload($event)" ref="fileUploadSwitch" name="upload"  multiple='multiple' style="visibility: hidden; width: 0px">
        </el-form-item>
        <el-table :data="fileListData" border>
          <el-table-column label="文件名" prop="name"></el-table-column>
          <el-table-column label="操作" v-if="!addOrCheck">
            <template slot-scope="scope">
              <el-button size="mini" type="text" @click="deletePic(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false" size="mini">关 闭</el-button>
        <el-button type="primary" @click="saveNotice" size="mini" v-if="!addOrCheck">提 交</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import {noticeList, UPLOAD_URL, noticeSave} from '../../api/commonApi.js'
  import 'quill/dist/quill.core.css'
  import 'quill/dist/quill.snow.css'
  import 'quill/dist/quill.bubble.css'
  import { quillEditor } from 'vue-quill-editor'
  export default {
    name: 'index',
    data () {
      return {
        queryData: {
          startTime: '',
          endTime: ''
        },
        dataTable: [],
        page: {
          pageNum: 1,
          pageSize: 10,
          total: 0,
          pageSizes: [10, 20, 30, 40]
        },
        addOrCheck: 0,
        dialogFormVisible: false,
        noticeAddData: {
          title: '',
          content: ''
        },
        noticeAddDataRule: {
          title: [{required: true, trigger: 'blur', message: '内容不可为空'}],
          content: [{required: true, trigger: 'blur', message: '内容不可为空'}]
        },
        fileListData: [],
        editorOption: {
          placeholder: '请输入内容，字数限制2000',
          modules: {
            toolbar: [
              [{ 'size': ['small', false, 'large'] }],
              ['bold', 'italic'],
              [{'list': 'ordered'}, { 'list': 'bullet' }]
            ]
          }
        }
      }
    },
    components: {quillEditor},
    mounted () {
      this.noticeQuery()
    },
    methods: {
      noticeQuery () {
        if (this.queryData.startTime && this.queryData.endTime) {
          if (new Date(this.queryData.startTime).getTime() > new Date(this.queryData.endTime).getTime()) {
            this.queryData.startTime = ''
            this.queryData.endTime = ''
            this.$message.warning('发布起始日期不得大于发布终止日期')
          }
        }
        this.queryData.pageSize = this.page.pageSize
        this.queryData.pageNum = this.page.pageNum
        noticeList(this.queryData).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            this.dataTable = data.list
            this.page.total = data.total
          }
        }).catch(err => { console.log(err) })
      },
      noticeResetQuery () {
        for (let k in this.queryData) {
          this.queryData[k] = null
        }
        this.noticeQuery()
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.noticeQuery()
      },
      handleCurrentChange (val) {
        this.page.pageNum = val
        this.noticeQuery()
      },
      addNotice () {
        this.dialogFormVisible = true
        this.addOrCheck = 0
        this.noticeAddData.title = null
        this.noticeAddData.content = null
        this.fileListData = []
      },
      trigger () {
        this.$refs['fileUploadSwitch'].click()
      },
      fileUpload (e) {
        // 点击上传和拖拽上传获取文件的方式不一样
        let fileList = e.target.files || e.dataTransfer.files
        // FileList 数据类型
        Array.prototype.forEach.call(fileList, file => {
          /* eslint-disable */
          let fd = new FormData()
          fd.append('inputStream', file)
          fd.append('fileCategory', 'notice')
          let xhr = new XMLHttpRequest()
          xhr.onreadystatechange = () => {
            if(xhr.status === 200 && xhr.readyState === 4) {
              if (JSON.parse(xhr.response).respCode === '1000') {
                let data = JSON.parse(xhr.response).body
                data._id = this.fileListData.length
                this.fileListData.push(data)
              } else {
                this.$message.warning(JSON.parse(xhr.response).respMsg)
              }
            } else if (xhr.status !== 200 && xhr.readyState === 4){
              this.$message.warning('上传失败')
            }
          }
          xhr.open('post', UPLOAD_URL, true)
          xhr.send(fd)
          /* eslint-disable */
        })
      },
      deletePic (row) {
        this.fileListData.forEach((item, index) => {
          if (row._id === item._id) {
            this.fileListData.splice(index, 1)
          }
        })
      },
      saveNotice () {
        this.$refs['noticeAddData'].validate(valid => {
          if (valid) {
            let fileData = JSON.parse(JSON.stringify(this.fileListData)).map(item => {return {fileName: item.name, filePath:item.filePathname}})
            this.noticeAddData.list = fileData
            noticeSave(this.noticeAddData).then(res => {
              if (res.data.respCode === '1000') {
                this.dialogFormVisible = false
                this.noticeQuery()
              }
            }).catch(err => { console.log(err) })
          }
        })
      },
      closeAddNotice () {
        this.addOrCheck = 0
        this.fileListData = []
        this.noticeAddData.title = ''
        this.noticeAddData.content = ''
        this.$refs['noticeAddData'].resetFields()
      },
      checkNoticeItem (row) {
        this.dialogFormVisible = true
        this.addOrCheck = 1
        this.noticeAddData.title = row.title
        this.noticeAddData.content = row.content
        this.fileListData = JSON.parse(JSON.stringify(row.list)).map(item => { return {name: item.fileName} })
      },
      onEditorBlur (e) {
        if ((this.addOrCheck !== 0) && (this.noticeAddData.content === '' || this.noticeAddData.content === null)) {
          this.$message.warning('请输入必填内容')
        } else {
          this.$refs['noticeAddData'].clearValidate('content')
        }
      },
      onEditorFocus () {},
      onEditorReady () {}
    }
  }
</script>

<style scoped lang="scss">
</style>
