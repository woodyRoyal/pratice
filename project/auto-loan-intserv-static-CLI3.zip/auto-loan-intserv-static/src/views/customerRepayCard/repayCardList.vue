<template>
  <div>
    <div class="applyprogressQuery">
      <el-form size="small" label-position="top">
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="申请编号">
              <el-input v-model="queryData.applyId" maxlength='8' @blur="checkApplyId(queryData.applyId)"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="客户姓名">
              <el-input v-model="queryData.name" maxlength="20"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item>
              <div class="query-reset-repayCard">
                <el-button size="mini" type="primary" @click="getRepayCardList">查询</el-button>
                <el-button size="mini" type="primary" @click="resetQuery">重置</el-button>
              </div>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="dataTableWrap">
      <el-table border :data="tableData">
        <el-table-column label="序号" type="index" align="center"></el-table-column>
        <el-table-column label="申请编号" align="center">
          <template slot-scope="scope">
            {{scope.row.applyDisplayId}}
            <el-tag type="warning" size="mini" v-if="scope.row.specialPermit">特批</el-tag>
            <el-tag type="warning" size="mini" v-if="scope.row.reconsideration">复议</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="数据来源" align="center">
          <template slot-scope="scope">
            <!--老系统显示 oldApplyNo，新系统显示 '/'-->
            {{scope.row.oldApplyNo || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="客户姓名" align="center">
          <template slot-scope="scope">
            {{scope.row.name}}
          </template>
        </el-table-column>
        <el-table-column label="还款卡开户行" align="center">
          <template slot-scope="scope">
            {{bankCardDict[scope.row.bankCode]}}
          </template>
        </el-table-column>
        <el-table-column label="还款卡号" align="center">
          <template slot-scope="scope">
            {{scope.row.bankCardNo}}
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center">
          <template slot-scope="scope">
            <!--<el-popover v-if="scope.row.oldApplyFlag" placement="left">-->
              <!--<p>老系统数据</p>-->
              <!--<p>功能开发中，请先至老系统处理</p>-->
              <!--<el-button slot="reference" type="text">还款卡变更</el-button>-->
            <!--</el-popover>-->
            <el-button type="text" @click="repayCardChange(scope.row)">还款卡变更</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <el-pagination
      class="listPagination"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="page.currentPage"
      :page-size="page.pageSize"
      :page-sizes="page.pageSizesArr"
      layout="total, sizes, prev, pager, next, jumper"
      :total="page.total">
    </el-pagination>
    <!--还款卡信息变更-->
    <el-dialog title="还款卡信息变更" :visible.sync="dialogFormVisible" width="70%" @closed="repayCardFormClosed">
      <el-form label-position="left" size="small">
        <div class="dialog-module-title">基本信息</div>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="申请编号" label-width="68px">
              <el-input disabled v-model="oldCheckData.applyId"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="客户姓名" label-width="68px">
              <el-input disabled v-model="oldCheckData.name"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <div class="dialog-module-title">银行卡信息</div>
        <!--旧信息-->
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="开户行" label-width="68px">
              <el-select disabled v-model="oldCheckData.bankCode">
                <el-option v-for="item in bankNameList" :key="item.dictValue" :label="item.dictName" :value="item.dictKey"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="银行卡号" label-width="68px">
              <el-input disabled v-model="oldCheckData.bankCardNo"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="银行卡预留手机号" label-width="130px">
              <el-input disabled v-model="oldCheckData.reservePhone"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-form label-position="left" size="small" :model="newCheckData" :rules="newCheckDataRule" ref="newCheckData">
        <!--输入信息（新信息）-->
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="" label-width="68px" prop="newBankCardCode">
              <el-select v-model="newCheckData.newBankCardCode">
                <el-option v-for="item in bankNameList" :key="item.dictValue" :label="item.dictName" :value="item.dictKey"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="" label-width="68px" prop="newBankCardNum">
              <el-input maxlength="19" v-model="newCheckData.newBankCardNum"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="" label-width="130px" prop="newPhoneNum">
              <el-input maxlength="11" v-model="newCheckData.newPhoneNum"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false" size="mini">取 消</el-button>
        <el-button type="primary" @click="applyCheckRight" size="mini" :disabled="applyCheckRightBtnDisabled">确 定</el-button>
      </div>
    </el-dialog>
    <!--2345银行卡鉴权dialog-->
    <el-dialog title="提示" :visible.sync="tipDialogVisible" width="30%" @closed="msgCodeDialogClose">
      <div>
        <p class="dialogtips">变更还款卡需要鉴权，请向<span>{{secretPhone}}</span>发送短信验证码，短信验证通过后，变更完成</p>
        <div class="msgCode-ipt">
          <el-input size="small" v-model="messageCode" @blur="checkMsgCode" maxlength="6"></el-input>
          <el-button type="primary" @click="sendMsgCode" size="mini">{{timeCounter}}</el-button>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="confirmMsgCode('2345')" :loading="isConfirmMsgCodeLoading">确 定</el-button>
      </span>
    </el-dialog>
    <!--非自有资方的银行卡鉴权dialog-->
    <el-dialog title="提示" :visible.sync="notSelfTipDialogVisible" width="30%" @closed="msgCodeDialogClose">
      <div>
        <p class="dialogtips">银行卡鉴权验证码已发送至用户，请尽快联系用户获取并在下方填入</p>
        <div class="msgCode-ipt">
          <span style="display:inline-block; width: 90px; height: 32px; line-height: 32px; margin-right: 10px">短信验证码</span>
          <el-input size="small" v-model="notSelfMessageCode" @blur="checkNewNetsMsgCode" maxlength="6"></el-input>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="confirmMsgCode('EX-XW')" :loading="isConfirmMsgCodeLoading">确 定</el-button>
        <el-button size="mini" @click="notSelfTipDialogVisible = false">取 消</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
  import {checkCustomerApplyId, phoneRegxp} from '../../utils/constant'
  import {mapGetters} from 'vuex'
  import { signQueryPages, queryRepayCardChangeStatus, zBCardCheck } from '../../api/pageApi.js'
  import { checkBankCard, checkNeedCheck, msgCodeConfirm } from '../../api/compactApi.js'
  export default {
    data () {
      let checkPhone = (rule, value, callback) => {
        if (value !== '' && value !== null) {
          if (this.phoneRegxp.test(value)) {
            callback()
          } else {
            callback(new Error('内容输入有误'))
          }
        } else {
          callback(new Error('内容不得为空'))
        }
      }
      let checkBankCardNum = (rule, value, callback) => {
        if (value !== '' && value !== null) {
          if (/^\d{19}$/.test(value)) {
            callback()
          } else {
            callback(new Error('内容输入有误'))
          }
        } else {
          callback(new Error('内容不得为空'))
        }
      }
      let checkBandCode = (rule, value, callback) => {
        if (value) {
          callback()
        } else {
          callback(new Error('内容不得为空'))
        }
      }
      return {
        checkApplyId: checkCustomerApplyId,
        phoneRegxp,
        queryData: {},
        tableData: [],
        page: {
          currentPage: 1,
          pageSize: 10,
          pageSizesArr: [10, 20, 30, 40],
          total: 0
        },
        repayCardData: {}, // 还款卡填写信息
        dialogFormVisible: false, // 还款卡变更
        notSelfTipDialogVisible: false, // 非自有资方还款卡鉴权弹窗
        tipDialogVisible: false, // 2345还款卡鉴权弹窗
        messageCode: null, // 2345短信验证码
        notSelfMessageCode: null, // 非自有资方短信验证码
        timeCounter: '发送验证码',
        timer: null, // 计时器
        bankCardDict: {},
        secretPhone: null,
        oldCheckData: {},
        newCheckData: {
          newBankCardCode: '',
          newBankCardNum: null,
          newPhoneNum: null
        },
        newCheckDataRule: {
          newBankCardCode: [{validator: checkBandCode, trigger: 'change'}],
          newBankCardNum: [{validator: checkBankCardNum, trigger: 'blur'}],
          newPhoneNum: [{validator: checkPhone, trigger: 'blur'}]
        },
        businessOrderNo: null, // 2345流水编号
        notSelfBusinessOrderNo: null, // 非自有资方流水编号
        isConfirmMsgCodeLoading: false,
        $messageId: null,
        applyCheckRightBtnDisabled: false
      }
    },
    computed: {
      ...mapGetters(['bankNameList'])
    },
    created () {
      document.title = '客户还款卡变更'
    },
    mounted () {
      this.getRepayCardList()
    },
    methods: {
      getRepayCardList () {
        this.queryData.pageSize = this.page.pageSize
        this.queryData.pageNum = this.page.currentPage
        if (JSON.stringify(this.bankCardDict) === '{}') {
          this.bankNameList.forEach(item => {
            this.bankCardDict[item.dictKey] = item.dictName
          })
        }
        signQueryPages(this.queryData).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            this.tableData = data.list
            this.page.total = data.total
          }
        }).catch(error => { console.log(error) })
      },
      resetQuery () {
        for (let k in this.queryData) {
          this.queryData[k] = null
        }
        this.getRepayCardList()
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.getRepayCardList()
      },
      handleCurrentChange (val) {
        this.page.currentPage = val
        this.getRepayCardList()
      },
      // 点击还款卡变更
      repayCardChange (row) {
        this.oldCheckData = row
        queryRepayCardChangeStatus(row.applyId).then(res => {
          if (res.data.respCode === '1000') {
            const data = res.data.body
            if ((data.billStatus === 1 || data.billStatus === 3) && data.loanStatus === 99) {
              this.dialogFormVisible = true
              this.$refs['newCheckData'] && this.$refs['newCheckData'].resetFields()
            }
          }
        }).catch(err => { console.log(err) })
      },
      // 还款卡变更提交
      applyCheckRight () {
        // 判断输入
        this.$refs['newCheckData'].validate(valid => {
          if (valid) {
            let data = {
              applyId: this.oldCheckData.applyId,
              bankCode: this.newCheckData.newBankCardCode,
              bankCardNo: this.newCheckData.newBankCardNum,
              reservePhone: this.newCheckData.newPhoneNum
            }
            if (this.oldCheckData.capital === '2345' || this.oldCheckData.capital === 'EX-ZB') {
              this.selfCheckPayCard(data) // 自有鉴权
            } else {
              this.notSelfCheckPayCard(data) // 新网鉴权
            }
          } else {
            this.$message.warning('请检查输入内容')
          }
        })
      },
      // 自有鉴权
      selfCheckPayCard (value) {
        let tempPhoneArr = this.newCheckData.newPhoneNum.split('')
        tempPhoneArr.splice(3, 4, '****')
        this.secretPhone = tempPhoneArr.join('')
        value.capital = '2345'
        value.interfaceType = 'repayCardModify'
        // 是否需要鉴权
        checkNeedCheck(value).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            if (data.need) {
              this.tipDialogVisible = true
            } else {
              this.$message.success(this.oldCheckData.capital === 'EX-ZB' ? '二三四五鉴权成功，目前正在进行众邦鉴权，请耐心等待' : '二三四五鉴权成功') // 不需要鉴权（鉴权成功）
              this.tipDialogVisible = false
              this.applyCheckRightBtnDisabled = true
              const zbRepayCardChangeApiData = {
                applyId: this.oldCheckData.applyId,
                bankCode: this.newCheckData.newBankCardCode,
                bankCardNo: this.newCheckData.newBankCardNum,
                reservePhone: this.newCheckData.newPhoneNum,
                capital: 'EX-ZB'
              }
              if (this.oldCheckData.capital === 'EX-ZB') this.zBRepayCardCheck(zbRepayCardChangeApiData)
            }
          }
        }).catch(err => { console.log(err) })
      },
      // 自有资方点击发送短信验证码
      sendMsgCode () {
        this.messageCode = null
        this.$messageId = null
        this.$messageId = this.$message({
          type: 'success',
          duration: 0,
          dangerouslyUseHTMLString: true,
          message: '<strong style="font-size: 16px"><i class="el-icon-loading" style="font-size: 16px"></i>&nbsp;&nbsp;消息正在发送，请耐心等待</strong>'
        })
        if (!isNaN(+this.timeCounter)) {
          return false
        } else {
          this.timeCounter = 60 // 倒计时
          clearInterval(this.timer)
          this.timer = setInterval(() => {
            this.timeCounter -= 1
            if (this.timeCounter <= 0) {
              clearInterval(this.timer)
              this.timeCounter = '重新发送验证码'
            }
          }, 1000)
          let data = {
            applyId: this.oldCheckData.applyId,
            bankCode: this.newCheckData.newBankCardCode,
            bankCardNo: this.newCheckData.newBankCardNum,
            reservePhone: this.newCheckData.newPhoneNum,
            capital: '2345'
          }
          // 发送短信验证码
          checkBankCard(data).then(res => {
            if (res) {
              this.$messageId.close()
              this.$messageId = null
            }
            if (res.data.respCode === '1000') {
              let data = res.data.body
              this.businessOrderNo = data.businessOrderNo
            }
          }).catch(err => { console.log(err) })
        }
      },
      // 新网鉴权
      notSelfCheckPayCard (value) {
        value.capital = this.oldCheckData.capital
        value.interfaceType = 'repayCardModify'
        // 是否需要鉴权
        checkNeedCheck(value).then(res => {
          if (res.data.respCode === '1000') {
            let data = res.data.body
            if (data.need) {
              this.notSelfSendMsgCode(value) // 发送短信验证码
            } else {
              this.$message.warning('新网鉴权成功') // 不需要鉴权（鉴权成功）
              delete value.capital
              this.selfCheckPayCard(value) // 自有鉴权
            }
          }
        }).catch(err => { console.log(err) })
      },
      // 新网短信验证
      notSelfSendMsgCode (value) {
        this.notSelfMessageCode = null
        this.$messageId = null
        this.$messageId = this.$message({
          type: 'success',
          duration: 0,
          dangerouslyUseHTMLString: true,
          message: '<strong style="font-size: 16px"><i class="el-icon-loading" style="font-size: 16px"></i>&nbsp;&nbsp;消息正在发送，请耐心等待</strong>'
        })
        delete value.interfaceType
        checkBankCard(value).then(res => {
          if (res) {
            this.$messageId.close()
            this.$messageId = null
          }
          if (res.data.respCode === '1000') {
            let data = res.data.body
            this.notSelfBusinessOrderNo = data.businessOrderNo
            this.notSelfTipDialogVisible = true // 发送成功显示弹窗
          }
        }).catch(err => { console.log(err) })
      },
      // 短信验证码确认
      confirmMsgCode (type) {
        this.isConfirmMsgCodeLoading = true
        let data = {
          applyId: this.oldCheckData.applyId,
          bankCode: this.newCheckData.newBankCardCode,
          bankCardNo: this.newCheckData.newBankCardNum,
          reservePhone: this.newCheckData.newPhoneNum,
          interfaceType: 'repayCardModify'
        }
        if (type === '2345') {
          if (this.messageCode !== '' && this.messageCode !== null && this.businessOrderNo) {
            data.authCode = this.messageCode
            data.bizOrderNo = this.businessOrderNo
            data.capital = '2345'
          } else {
            this.$message.warning('请确保已获取验证码短信并填入')
            this.isConfirmMsgCodeLoading = false
            return false
          }
        } else {
          if (this.notSelfMessageCode !== '' && this.notSelfMessageCode !== null && this.notSelfBusinessOrderNo) {
            data.authCode = this.notSelfMessageCode
            data.bizOrderNo = this.notSelfBusinessOrderNo
            data.capital = 'EX-XW'
          } else {
            this.$message.warning('请确保已获取验证码短信并填入')
            this.isConfirmMsgCodeLoading = false
            return false
          }
        }
        msgCodeConfirm(data).then(res => {
          let response = res.data
          this.isConfirmMsgCodeLoading = false
          if (response.respCode === '1000') {
            if (type === '2345') {
              if (this.oldCheckData.capital === '2345' || this.oldCheckData.capital === 'EX-XW') {
                this.$message.success('二三四五鉴权成功')
                this.tipDialogVisible = false
                this.dialogFormVisible = false
                this.getRepayCardList()
              } else if (this.oldCheckData.capital === 'EX-ZB') {
                this.tipDialogVisible = false
                this.applyCheckRightBtnDisabled = true
                this.$message.success('二三四五鉴权成功，目前正在进行众邦鉴权，请耐心等待')
                this.zBRepayCardCheck(data)
              }
            } else {
              this.$message.success('新网鉴权成功')
              this.notSelfTipDialogVisible = false // 提示弹窗
              this.selfCheckPayCard(data)// 自有鉴权
            }
          }
        }).catch(error => {
          this.isConfirmMsgCodeLoading = false
          console.log(error)
        })
      },
      // 众邦鉴权
      zBRepayCardCheck (data) {
        data.capital = 'EX-ZB'
        zBCardCheck(data).then(res => {
          this.applyCheckRightBtnDisabled = false
          if (res.data.respCode === '1000') {
            this.$message.success('众邦鉴权成功')
            this.dialogFormVisible = false
            this.getRepayCardList()
          }
        }).catch(err => { console.log(err) })
      },
      // 自有鉴权输入校验
      checkMsgCode () {
        if (this.messageCode && !/^\d{6}$/.test(this.messageCode)) {
          this.$message.warning('输入有误')
          this.messageCode = null
        }
      },
      // 新网鉴权输入
      checkNewNetsMsgCode () {
        if (this.notSelfMessageCode && !/^\d*$/.test(this.notSelfMessageCode)) {
          this.$message.warning('输入有误')
          this.notSelfMessageCode = null
        }
      },
      // 提交弹窗关闭回调
      repayCardFormClosed () {
        this.newCheckData = {
          newBankCardCode: '',
          newBankCardNum: null,
          newPhoneNum: null
        }
        this.$refs['newCheckData'] && this.$refs['newCheckData'].resetFields()
      },
      // 短信验证码弹窗关闭回调
      msgCodeDialogClose () {
        this.messageCode = null
        this.businessOrderNo = null
        this.notSelfMessageCode = null
        this.notSelfBusinessOrderNo = null
        clearInterval(this.timer)
        this.timeCounter = '发送验证码'
      }
    }
  }
</script>
<style lang="scss" scoped>
  .query-reset-repayCard{
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    margin-top: 21px;
  }
  .dialog-module-title{
    margin: 10px 0;
    font-size: 16px;
    text-decoration: underline;
  }
  .msgCode-ipt{
    display: flex;
    margin-top: 10px;
    .el-button{
      width: 118px;
      margin-left: 20px;
    }
  }
</style>
