import fetch from '../utils/fetch'

// 贷后资料列表
export function listInfo (data) {
  return fetch({
    method: 'post',
    url: 'postLoanHome/queryPostLoanHomeList',
    data
  })
}

// 检验是否可以办理
export function checkToDetail (applyId) {
  return fetch({
    method: 'get',
    url: '/intserv/manage/bindingTask',
    params: {applyId}
  })
}

// 车辆登记等信息
export function getDaihouApproveFormInfo (applyId) {
  return fetch({
    method: 'get',
    url: '/postLoan/queryPostLoanInfoByApplyId',
    params: {applyId}
  })
}

// 贷后资料上传列表
export function daihouUploadList (data) {
  return fetch({
    method: 'post',
    url: '/operator/material/postLoanUploadList',
    data
  })
}

// 归档明细表区域下拉
export function areaNameList () {
  return fetch({
    method: 'get',
    url: '/intserv/corpmember/queryOrgByLevel',
    params: {orgLevel: 3}
  })
}

// 归档明细表
export function guidangList (data) {
  return fetch({
    method: 'post',
    url: '/postLoan/file/list',
    data
  })
}

// 点击导出
export function clickDownLoad (data) {
  return fetch({
    method: 'post',
    url: '/report/download/loadAfterLoanArchiveDetail',
    data
  })
}

// 导出轮询
export function downLoadPolling (serialNo) {
  return fetch({
    method: 'get',
    url: '/download/polling',
    params: {serialNo}
  })
}

// 导出轮询
export function reportDownloadPolling (reportKey, serialNo) {
  return fetch({
    method: 'get',
    url: '/report/download/polling/' + reportKey + '/' + serialNo
  })
}
