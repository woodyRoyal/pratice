import fetch from '../utils/fetch'

export const academicDegreeDict = [
  {code: 1, desc: '名誉博士'},
  {code: 2, desc: '博士'},
  {code: 3, desc: '硕士'},
  {code: 4, desc: '学士'},
  {code: 9, desc: '未知'},
  {code: 0, desc: '其他'}
]

// 申请进度——当前节点
export function currentNodesList (params) {
  return fetch({
    method: 'get',
    url: '/apply/getNodeList',
    params
  })
}

// 申请进度查询
export function applyProgress (data) {
  return fetch({
    method: 'post',
    url: '/risk/progress/applyList',
    data
  })
}

// 拉取担保人详细信息
export function getGuranteeInfo (id) {
  return fetch({
    method: 'get',
    url: '/proposerSurety/queryProposerById',
    params: {id}
  })
}

// 查询联系人信息
export function getContactListInfo (data) {
  return fetch({
    method: 'post',
    url: '/proposer/queryContactsByBO',
    data
  })
}

// 客户-企业拉取
export function getEnterpriseInfo (params) {
  return fetch({
    method: 'get',
    url: '/proposer/queryCompanyByApplyIdWithDefaultData',
    params
  })
}

// 获取文件分类
export function getImgMenu (params) {
  return fetch({
    method: 'get',
    url: '/proposerImage/getProductImageMenu',
    params
  })
}

// 文件拉取
export function fileGet (applyId) {
  return fetch({
    method: 'get',
    url: '/proposerImage/getImageDataNew',
    params: {applyId}
  })
}

// 融资信息字典接口
export function getFinacialDictionary (params) {
  return fetch({
    method: 'get',
    url: '/applyFinancing/getApplyFinancingDict',
    params
  })
}

// 融资专员
export function getSalesManList (params) {
  return fetch({
    method: 'get',
    url: '/dealerStaff/queryDealerStaff',
    params
  })
}

// 融资信息获取
export function getFinancing (params) {
  return fetch({
    method: 'get',
    url: '/applyFinancing/getApplyFinancing',
    params
  })
}

// 查询担保人列表
export function getGuaranteeListInfo (data) {
  return fetch({
    method: 'post',
    url: '/proposerSurety/queryByApplyId?applyId=' + data
  })
}

// 客户-个人 拉取
export function getPersonalInfo (applyId) {
  return fetch({
    method: 'post',
    url: '/proposer/getProposerWithDefaultData?applyId=' + applyId
  })
}

// 车辆信息拉取
export function getVehicleInfo (params) {
  return fetch({
    method: 'get',
    url: '/car/queryCarInfoByApplyId',
    params
  })
}

// 渠道下拉
export function getSupplierList (data) {
  return fetch({
    method: 'post',
    url: '/dealerChannel/queryChannelById',
    data
  })
}

// 概要信息
export function getSummaryInfo (params) {
  return fetch({
    method: 'get',
    url: '/approve/querySummaryInfo',
    params
  })
}

// 经销商提醒
export function getRemindList (data) {
  return fetch({
    method: 'post',
    url: '/approve/queryApproveRemind',
    data
  })
}

// 审批历史
export function getApproveList (data) {
  return fetch({
    method: 'post',
    url: '/approve/queryApproveRecordInfo',
    data
  })
}

// 获取tabs个数
export function tabList (params) {
  return fetch({
    method: 'get',
    url: 'apply/queryCreditPersonInfo',
    params
  })
}

// 贷款王和前海数据信息获取
export function DkwQhInfo (data) {
  return fetch({
    method: 'post',
    url: '/credit/queryDkwAndQianHaiInfo',
    data
  })
}

// 集奥
export function JaInfo (data) {
  return fetch({
    method: 'post',
    url: '/credit/geoInfo',
    data
  })
}

// 同盾
export function tdInfo (data) {
  return fetch({
    method: 'post',
    url: '/credit/tongdunInfo',
    data
  })
}

// 聚信立
export function jxlInfo (data) {
  return fetch({
    method: 'post',
    url: '/credit/juxinliInfo',
    data
  })
}

// 汇法
export function hfInfo (data) {
  return fetch({
    method: 'post',
    url: '/credit/huifaInfo',
    data
  })
}

// 稠州银行征信
export function chouzhouDataInfo (id, type) {
  return fetch({
    method: 'post',
    url: '/credit/getChouYinCredit',
    data: {id, type}
  })
}

// 新网征信
export function newNetsDataInfo (id, type) {
  return fetch({
    method: 'post',
    url: '/risk/progress/queryXwRiskResult',
    data: {id, type}
  })
}

// 众邦
export function zhongBangDataInfo (id, type) {
  return fetch({
    method: 'post',
    url: '/credit/getZBCredit',
    data: {id, type}
  })
}

// 鹏元驾照
export function pyDataInfo (applyId) {
  return fetch({
    method: 'get',
    url: '/credit/getPyDrivingLicenseInfo',
    params: {applyId}
  })
}

// 挂靠公司
export function getAttachedCompanyInfo (applyId) {
  return fetch({
    method: 'get',
    url: '/attached/query/riskAudit',
    params: {applyId}
  })
}

// 电核文件
export function telVerifyData (applyId) {
  return fetch({
    method: 'get',
    url: '/call/queryCallList',
    params: {applyId}
  })
}

// 客户信息
export function customerInfo (applyId) {
  return fetch({
    method: 'get',
    url: '/applyTransfer/queryCustomInfoByApplyId',
    params: {applyId}
  })
}

// 逾期信息
export function outofDateInfo (applyId) {
  return fetch({
    method: 'get',
    url: '/repayment/book/queryOverDueInfo',
    params: {applyId}
  })
}

// 交易记录
export function tradeHistory (data) {
  return fetch({
    method: 'post',
    url: '/repayment/page',
    data
  })
}

// 查询还款计算计划（弃用)
export function repaymentPlans (applyId) {
  return fetch({
    method: 'post',
    url: '/repayment/book/repaymentPlans',
    data: {applyId}
  })
}

// 查询还款计算计划（新)
export function queryRepaymentDetailInfo (data) {
  return fetch({
    method: 'post',
    url: '/repayment/book/queryRepaymentDetailInfo',
    data
  })
}

// 资方切换
export function changeCapitalApi (applyId) {
  return fetch({
    method: 'get',
    url: '/changeCapital/manual',
    params: {applyId}
  })
}

// 申请进度查询下载
export function applyProgressExport (data) {
  return fetch({
    method: 'post',
    url: '/progress/file/createRiskFile',
    data
  })
}

// 运营商认证列表
export function getmMobileAuthList (data) {
  return fetch({
    method: 'post',
    url: '/credit/mobileAuthResult',
    data
  })
}
