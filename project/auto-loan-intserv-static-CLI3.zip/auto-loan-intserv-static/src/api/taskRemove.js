import fetch from '../utils/fetch'

// 获取放款人员列表
export function approvers (data) {
  return fetch({
    method: 'post',
    url: '/operator/taskTransfer/taskTransferLoanUser',
    data: {}
  })
}
// 任务列表
export function taskList (data) {
  return fetch({
    method: 'post',
    url: '/operator/taskTransfer/queryLoanTaskTransfer',
    data
  })
}
// 批量转件人员列表
export function taskListRemove (data) {
  return fetch({
    method: 'post',
    url: '/operator/taskTransfer/batchTransferLoanUser',
    data
  })
}

// 确认转件
export function confirmRemove (data) {
  return fetch({
    method: 'post',
    url: '/operator/taskTransfer/batchTransfer',
    data
  })
}
