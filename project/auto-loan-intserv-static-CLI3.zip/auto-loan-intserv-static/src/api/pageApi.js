import fetch from '../utils/fetch'

// 还款卡列表
export function signQueryPages (data) {
  return fetch({
    method: 'post',
    url: '/bankcard/repaymentCardPages',
    data
  })
}

// 点击还款卡变更，查询是否可变更
export function queryRepayCardChangeStatus (applyId) {
  return fetch({
    method: 'get',
    url: '/bankcard/queryLoanStatus',
    params: {applyId}
  })
}

// 众邦鉴权
export function zBCardCheck (data) {
  return fetch({
    method: 'post',
    url: '/bankcard/modifyCapitalBankCard',
    data
  })
}
