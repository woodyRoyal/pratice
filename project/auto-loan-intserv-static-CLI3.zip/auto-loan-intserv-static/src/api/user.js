import fetch from '../utils/fetch'

export default {
  // 修改密码
  fetchUpdateUserPassword (data) {
    return fetch({
      url: 'intserv/manage/updateUserPassword',
      method: 'post',
      data
    })
  },
  /* 内部用户管理 */
  /* 岗位管理 */
  // 分页查询岗位信息
  fetchStation (data) {
    return fetch({
      url: 'intserv/manage/findPostByPage',
      method: 'post',
      data
    })
  },
  // 单个岗位查询
  fetchFindPostById (id) {
    return fetch({
      url: 'intserv/manage/findPostById',
      method: 'get',
      params: { id }
    })
  },
  // 更新岗位信息
  fetchUpdatePost (data) {
    return fetch({
      url: 'intserv/manage/updatePost',
      method: 'post',
      data
    })
  },
  /* 用户管理 */
  // 获取单个用户信息
  fetchFindUserById (id) {
    return fetch({
      url: 'intserv/manage/findUserById',
      method: 'get',
      params: {id}
    })
  },
  // 获取用户数据
  fetchUser (data) {
    return fetch({
      url: 'intserv/manage/findUserByPage',
      method: 'post',
      data
    })
  },
  // 重置密码
  fetchResetPassword (data) {
    return fetch({
      url: 'intserv/manage/resetUserPassword',
      method: 'post',
      data
    })
  },
  // 编辑接口
  fetchEditForm (data) {
    return fetch({
      url: 'intserv/manage/updateUser',
      method: 'post',
      data
    })
  },
  /* B端用户管理 */
  /* 机构管理 */
  fetchMechanismData (data) {
    return fetch({
      url: '',
      method: 'post',
      data
    })
  },
  /* 用户管理 */
  // 分页查询b端用户信息列表
  fetchBUserData (data) {
    return fetch({
      url: 'intserv/corpmember/findUserByPage',
      method: 'post',
      data
    })
  },
  // 获取机构数
  fetchQueryOrgList (data) {
    return fetch({
      url: 'intserv/corpmember/queryOrg',
      method: 'post',
      data
    })
  },
  // 重置B端用户中心的密码
  fetchResetBPassword (data) {
    return fetch({
      url: 'intserv/corpmember/resetLoginPwd',
      method: 'post',
      data
    })
  }
}
