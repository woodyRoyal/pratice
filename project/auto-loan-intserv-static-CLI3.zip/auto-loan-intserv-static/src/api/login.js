import fetch from '../utils/fetch'
import fetchUcenter from '../utils/fetchUcenter'

// 获取验证码
export function getCaptchaCode () {
  return fetchUcenter({
    url: '/getCaptchaCode',
    method: 'post',
  })
}

// 作为单独系统进入（不从互金后台走）
export function loginByUsername (username, password, captchaKey, systemCode, captchaCode) {
  const data = {
    username,
    password,
    captchaKey,
    systemCode,
    captchaCode,
  }
  return fetchUcenter({
    url: 'pLogin',
    method: 'post',
    data,
  })
}

// 从互金后台进入，以用户名和token登陆
export function loginByUsernameAndToken (username, token, systemCode = 'auto_loan_operate') {
  return fetch({
    url: '/ucenter/login',
    method: 'post',
    data: {username, token, systemCode},
  })
}

// 获取登陆用户信息
export function getUserInfo () {
  let systemCode = 'auto_loan_operate'
  return fetch({
    url: 'intserv/manage/loginUserInfo',
    method: 'get',
    params: {systemCode},
  })
}

// 退出
export function logout () {
  return fetch({
    url: 'logout',
    method: 'get',
  })
}

export const UCENTER_LOGIN_URL = process.env.VUE_APP_UCENTER_API + '#/login'
