import fetch from '../utils/fetch'

export function getAttachedCompanyList (data) {
  return fetch({
    method: 'post',
    url: '/attached/query/intsrvPage',
    data
  })
}

export function getAttachedCompanyDetail (attachedId) {
  return fetch({
    method: 'get',
    url: '/attached/query/detail',
    params: {attachedId}
  })
}
