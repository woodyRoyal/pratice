import fetch from '../utils/fetch'
// 新贷后归档查询
export function guidangList2 (data) {
  return fetch({
    method: 'post',
    url: '/report/manage/queryAfterLoanArchiveDetail',
    data
  })
}
// 汇款记录查询
export function customerRepayList2 (data) {
  return fetch({
    method: 'post',
    url: '/report/manage/queryRepaymentWriteOffReport',
    data
  })
}
