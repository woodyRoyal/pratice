import fetch from '../utils/fetch'

// 获取Freeswitch所有外呼IP对应的域名
export function fetchFreeSwitchDomains () {
  return fetch({
    url: '/call/getFreeSwitchIp',
    method: 'get'
  })
}

// 内部审批备注
export function insideApproveRemark (data) {
  return fetch({
    method: 'post',
    url: '/risk/approvalNote',
    data
  })
}

// 查询已读状态
export function haveRead (data) {
  return fetch({
    method: 'post',
    url: '/risk/queryReadStatus',
    data
  })
}

// 标记已读
export function read (data) {
  return fetch({
    method: 'post',
    url: '/risk/toRead',
    data
  })
}

// 预审批
export function approveList (params) {
  return fetch({
    method: 'get',
    url: '/risk/preAudit',
    params
  })
}

// 概要信息
export function summuryInfo (params) {
  return fetch({
    method: 'get',
    url: '/approve/querySummaryInfo',
    params
  })
}

// 审核操作列表（放款）
export function approveHandleList (params) {
  return fetch({
    method: 'get',
    url: '/intserv/manage/getLoanOperateResultList',
    params
  })
}

// 审核操作列表 贷后
export function daihouApproveHandleList (params) {
  return fetch({
    method: 'get',
    url: '/intserv/manage/getDataOperateResultList',
    params
  })
}

// 审核提交
export function approveSubmit (data) {
  return fetch({
    method: 'post',
    url: '/intserv/manage/submitAudit',
    data
  })
}

// 查询实物资料列表
export function getItemLists (applyId) {
  return fetch({
    method: 'get',
    url: '/operator/material/queryMaterialList',
    params: {applyId}
  })
}

// 保存实物资料列表
export function materialSave (data) {
  return fetch({
    method: 'post',
    url: '/operator/material/saveMaterial',
    data
  })
}

// 查询产证档案信息
export function getCardRecordInfo (applyId) {
  return fetch({
    method: 'get',
    url: '/operator/material/queryProLic',
    params: {applyId}
  })
}

// 保存产证档案信息
export function cardRecordSave (data) {
  return fetch({
    method: 'post',
    url: '/operator/material/saveProLic',
    data
  })
}

// 查询资方风控等审批结果（放款）
export function queryCapitalRiskStatus (applyId) {
  return fetch({
    method: 'post',
    url: '/loanHome/queryCapitalRiskStatus?applyId=' + applyId
  })
}

// 新网字段返显（贷后）
export function newNetsDaiHouApproveHandle (applyId) {
  return fetch({
    method: 'post',
    url: '/postLoan/queryPostLoanInfoStatusByApplyId?applyId=' + applyId
  })
}

// 众邦字段返显（贷后）
export function zbDaiHouApproveHandle (params) {
  return fetch({
    method: 'get',
    url: '/postLoan/queryZbCreditApprovalResult',
    params
  })
}

// 贷后资料提交新网
export function filesUploadNewNets (applyId) {
  return fetch({
    method: 'post',
    url: '/postLoan/submitPostLoanInfoByApplyId?applyId=' + applyId
  })
}

// 贷后资料提交众邦
export function filesUploadZb (applyId) {
  return fetch({
    method: 'post',
    url: '/postLoan/submitPostLoanInfoToZb?applyId=' + applyId
  })
}

// 贷后新网回购
export function buyBackFromNewNets (data) {
  return fetch({
    method: 'post',
    url: '/buyback/confirmBuyback',
    data
  })
}
