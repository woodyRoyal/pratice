# 车贷王资产管理系统
## 项目代号(等同于二级目录文件夹): auto-loan-asset-web

### 项目安装
```
yarn install
```

### 开发模式
```
yarn [run] serve
```
or
```
yarn [run] dev
```

### 构建模式
```
yarn run build[env]
```

### 用户配置文档
See [Configuration Reference](https://cli.vuejs.org/config/).

### env

在安装node-sass时，有的电脑需要Python环境，Python版本：python 2.7

# 开发指引

项目基于vue-cli3搭建

## 本地开发模式登陆

启动本地开发服务，登陆到对应，在vue.config.js文件，查看本地代理指向的环境，登陆对应环境的互金后台，在互金后台跳转到车贷资产管理系统，跳转登陆后打开控制台查看输出日志

```javascript
if (env === 'uat') { // 在测试环境输出路径及登陆信息
  console.log('登陆信息', this.$route.fullPath)
}
```
在控制台复制登陆数据，然后在开发服务的地址栏修改hash值即可
example
```javascript
http://172.17.92.71:8081/#/login?username=朱其龙&token=cd0fabac-ac5d-4e69-b901-0529d92da127
```


## vuex使用指南
```javascript
building
```

## request api 设置指南
```javascript
building
```

## 。。。
