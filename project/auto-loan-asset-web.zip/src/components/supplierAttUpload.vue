<template>
  <el-upload
    class="file-uploader"
    drag
    name="fileName"
    :data="attach.data"
    v-loading="loading"
    :action="uploadUrl"
    :on-error="handleUploadError"
    :on-success="handleUploadSuccess"
    :before-upload="beforeUpload"
  >
<!--        :disabled="!!attach.url"
-->
    <i v-if="!attach.loading && !attach.url" class="el-icon-plus avatar-uploader-icon"></i>
    <div class="pdf" v-else-if="(/([^\.\/\\]+)\.pdf$/i).test(attach.url)">
      <i v-if="editable" @click.stop="del" class="del el-icon-delete"></i>
      <a class="pdf-inner" :href="attach.url" target="_blank">{{attach.url}}</a>
    </div>
    <div v-else class="pic" @click.stop="handlePictureCardPreview(attach)"
         :style="{backgroundImage: `url(${attach.url})`}">
      <i v-if="editable" @click.stop="del" class="del el-icon-delete"></i>
    </div>
  </el-upload>
</template>

<script>
import apiHost from '../config/apiHost'

export default {
  name: 'ala-upload',
  props: {
    editable: {
      type: Boolean,
      default: true
    },
    attach: {
      typoe: Object,
      default () {
        return {}
      }
    }
  },
  mounted () {
    console.log(this.editable)
  },
  data () {
    return {
      imgTypes: ['image/png', 'image/jpeg', 'image/gif'], // 支持的文件列表
      fileTypes: ['application/pdf'],
      uploadUrl: `${apiHost.basePath}/file/upload`,
      loading: false
    }
  },
  methods: {
    del () {
      this.$alert(`你确定删除${this.attach.name}附件吗？`, '提示', {
        confirmButtonText: '确定',
        showCancelButton: true,
        callback: action => {
          if (action === 'confirm') {
            this.attach.url = ''
          }
        }
      })
    },
    handlePictureCardPreview (attach) {
      this.$emit('preView', attach)
    },
    beforeUpload (file) {
      const isAllowType = this.imgTypes.includes(file.type) || this.fileTypes.includes(file.type)
      const isLt10M = file.size / 1024 / 1024 < 10

      if (!isAllowType) {
        this.$message.error('仅支持上传图片或PDF文件！')
      }
      if (!isLt10M) {
        this.$message.error('图片或文件大小不能超过 10MB!')
      }
      isAllowType && isLt10M && (this.loading = true)
      return isAllowType && isLt10M
    },
    handleUploadSuccess (res, file) {
      setTimeout(() => {
        this.loading = false
        this.attach.url = res.result
        this.attach.type = this.fileTypes.includes(file.type) ? 2 : 1 // 文件类型1.图片2.文件
      }, 500)
    },
    handleUploadError () {
      this.loading = false
      this.$message.error('文件上传失败！')
    }
  }
}
</script>

<style scoped lang="sass">
  .file-uploader
    width: 300px
    height: 200px
    border: 1px dashed #3428d9
    border-radius: 6px
    cursor: pointer
    position: relative
    overflow: hidden

    /deep/ .el-upload-dragger
      width: 200px
      height: 100px

    .pdf
      position: relative
      width: 300px
      height: 200px
      background: url("../assets/images/pdf-icon.jpg") no-repeat center center / 100px 100px
      &:hover
        .del
          display: block

      .pdf-inner
        width: 300px
        height: 200px
        display: flex
        justify-content: center
        align-items: center
        font-size: 20px
        color: transparent

        &:hover
          background-color: rgba(0, 0, 0, .7)
          color: #fff

    .pic
      position: relative
      display: block
      width: 300px
      height: 200px
      background-repeat: no-repeat
      background-position: center center
      background-size: contain
      &:hover
        .del
          display: block

    /deep/ .el-upload-dragger
      border: none
      width: 300px
      height: 200px

    .file-uploader:hover
      border-color: #409EFF

    .avatar-uploader-icon
      font-size: 28px
      color: #8c939d
      width: 178px
      height: 178px
      line-height: 178px
      text-align: center

    .avatar
      width: 178px
      height: 178px
      display: block

    .del
      display: none
      width: 50px
      height: 50px
      font-size: 30px
      position: absolute
      top: 10px
      right: 10px
</style>
