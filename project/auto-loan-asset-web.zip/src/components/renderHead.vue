/**
* 创建chekcbox表头实现全选
*/

<template>
  <!-- <i class="el-icon-info" @click.capture.stop></i> .capture.-->
  <div @click.capture.prevent="clickCheck">
    <el-checkbox v-model="childChecked"
                 :indeterminate="isIndeterminate"></el-checkbox>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  props: {
    checked: {
      type: Boolean,
      default: false
    },
    isDisable: {
      type: Boolean,
      default: false
    },
    isIndeterminate: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      childChecked: false,
      myDisable: false
    }
  },
  watch: {
    'checked': function () {
      this.childChecked = this.checked
    },
    // 'isDisable': function() {

    // },
    'childChecked': function () {
      this.$emit('changeCheck', this.childChecked)
    }
  },
  methods: {
    changeCheck (val) {
      console.log(val)
    },
    clickCheck () {
      this.childChecked = !this.childChecked
      this.$emit('clickCheck', this.childChecked)
    },
    created () {
      this.childChecked = this.checked
    }
  }
}
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
// 增加icon
.el-table__footer-wrapper thead div,
.el-table__header-wrapper thead div {
  display: inline;
}
</style>
