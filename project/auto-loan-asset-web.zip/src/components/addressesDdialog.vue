<template>
<div>
  <el-dialog title="上门地址数量" v-if="addressesDialog" :visible.sync="getDialogFlag" @close="closeDiloagFun()" :modal-append-to-body="false">
    <table class="tableMod">
      <tr v-for="item in addressesList" :key="item.key">
        <td class="bg-td">地址类型</td>
        <td>{{addressType[item.type]}}</td>
        <td class="bg-td">省/城市</td>
        <td>{{ item.provinceAndCity }}</td>
        <td class="bg-td">详细地址</td>
        <td>{{ item.address }}</td>
      </tr>
    </table>
  </el-dialog>
</div>
</template>

<script>
export default {
  props: ['addressesDialog', 'addressesList'],
  data () {
    return {
      // 地址类型字典
      addressType: {
        0: '户籍地址',
        1: '居住地址',
        2: '工作地址'
      },
      getDialogFlag: false
    }
  },
  watch: {
    addressesDialog (val) {
      this.getDialogFlag = val
    }
  },
  methods: {
    closeDiloagFun () {
      this.$emit('listenDialogFun')
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
