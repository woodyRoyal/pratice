<template>
  <div v-loading="loading"
       element-loading-text="加载中请稍后..."
       element-loading-background="rgba(255, 255, 255, .5)">
    <el-table ref="refTable"
              :data="tableData"
              :border="border"
              :style="{width:elTableWidth}"
              :span-method="mergeTable">
      <el-table-column v-if="isTableIndex"
                       label="序号"
                       :align='align'
                       :width="indexWidth">
        <template slot-scope="scope">
          <span>{{ scope.$index + 1 }}</span>
        </template>
      </el-table-column>
      <el-table-column v-for="item in tableColumns"
                       :key='item.key'
                       :label="item.name"
                       :align='align'
                       :show-overflow-tooltip="item.tip">
        <template slot="header"
                  v-if="item.hasSlotheader">
          <div @click="handleTableSlot(item)"
               class="tableheader">
            <i class="el-icon-d-caret"></i>
            <div class="grid-content">{{item.name}}</div>
          </div>
        </template>

        <template slot-scope="scope">
          <slot :name="item.key"
                :row="scope.row">
            <span style="margin-left: 10px;color:#409EFF;cursor:pointer"
                  @click="handleTable(item.event,scope.row)"
                  v-if="item.event">{{ item.hasOperateType? getOperationName(scope.row[item.key]) : scope.row[item.key] }}</span>
            <span style="margin-left: 10px"
                  v-else>{{ item.hasOperateType? getOperationName(scope.row[item.key]) : scope.row[item.key] }}</span>
          </slot>
        </template>
      </el-table-column>
      <slot name="operate">
        <el-table-column v-if="tableOperate.length!==0"
                         label="操作"
                         :align='align'
                         :width="operateWidth">
          <template slot-scope="scope">
            <el-button size="mini"
                       v-for="item in tableOperate"
                       :type="item.color"
                       :icon="item.icon"
                       :key="item.type"
                       @click="handleOperate(item,scope.row)">{{item.name}}</el-button>
          </template>
        </el-table-column>
      </slot>
      <slot name="operateLog"></slot>
    </el-table>
    <div class="pagination"
         v-if="isPagination">
      <el-pagination @size-change="handleSizeChange"
                     @current-change="handleCurrentChange"
                     :current-page="pagination.pageNum"
                     :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="tableTotal">
      </el-pagination>
    </div>
  </div>
</template>
<script>
export default {
  name: 'tableCom',
  props: {
    loading: {
      type: Boolean,
      default: false
    },
    align: { // 表格对齐
      type: String,
      default: 'center'
    },
    border: { // 是否带有纵向边框
      type: Boolean,
      default: true
    },
    elTableWidth: { // 表格宽
      type: String,
      default: '100%'
    },
    operateWidth: { // 表格操作项宽
      type: Number,
      default: 120
    },
    tableColumns: {// 表格标题
      type: Array,
      required: true
    },
    tableData: {// 数据源
      type: Array,
      required: true
    },
    tableTotal: { // 总条数
      type: Number,
      default: 0
    },
    isPagination: { // 是否有分页
      type: Boolean,
      default: true
    },
    pagination: { // 分页器信息
      type: Object,
      default () {
        return {
          pageNum: 1,
          pageSizes: [30, 60, 100],
          pageSize: 30
        }
      }
    },
    tableOperate: { // 操作项
      type: Array,
      default () {
        return []
      }
    },
    isTableIndex: { // 是否有序号
      type: Boolean,
      default: true
    },
    indexWidth: { // 序号宽度
      type: Number,
      default: 50
    },
    isMergeTable: { // 是否有合并
      type: Boolean,
      default: false
    }
  },
  methods: {
    handleSizeChange (val) {
      this.pagination.pageSize = val
      const { pageNum, pageSize } = this.pagination
      this.$emit('fetchData', { pageNum, pageSize })
    },
    handleCurrentChange (val) {
      this.pagination.pageNum = val
      const { pageNum, pageSize } = this.pagination
      this.$emit('fetchData', { pageNum, pageSize })
    },
    // 重置当前页
    resetCurrentChange (pagination) {
      this.pagination.pageNum = pagination.pageNum
      this.pagination.pageSize = pagination.pageSize
    },
    // 操作项
    handleOperate (operateItem, data) {
      this.$emit('handleOperate', operateItem, data, this.$refs.refTable)
    },
    // table操作
    handleTable (event, data) {
      this.$emit('handleTable', event, data)
    },
    // 合并的操作
    mergeTable ({ row, column, rowIndex, columnIndex }) {
      if (this.isMergeTable) {
        return this.$parent.mergeTable({ row, column, rowIndex, columnIndex })
      }
    },
    // 表头点击操作
    handleTableSlot (event) {
      this.$emit('handleTableSlot', event)
    },
    // 操作日志专用
    getOperationName (type) {
      switch (Number(type)) {
        case 0:
          return '新增'
        case 1:
          return '修改'
        case 2:
          return '删除'
        case 3:
          return '调整顺序'
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.pagination {
  display: flex;
  justify-content: flex-end;
}
.tableheader {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  cursor: pointer;
}
</style>
