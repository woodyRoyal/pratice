<template>
  <div class="supplierManage">
    <el-tabs v-model="activeName" :before-leave="chooseUserTab" v-loading="auditLoading">
      <el-tab-pane label="基本信息" name="0">
        <el-row v-if="editable" style="margin: 20px 0; padding-right: 100px" type="flex" class="row-bg" justify="end">
          <el-button type="primary" @click="saveBasicInfo">保存并进入下一步</el-button>
          <el-button @click="applyAudit">提交审核</el-button>
        </el-row>
        <el-form :label-position="'top'" :disabled="!editable" ref="basicForm" :model="supplierBasicInfo"
                 :rules="supplierBasicInfoRule">
          <el-row>
            <el-col :span="24">
              <div class="grid-content bg-purple-dark row-title">基本信息</div>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="6">
              <el-form-item label="供应商名称" prop="supplierName" :required="true">
                <el-input v-model="supplierBasicInfo.supplierName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8" :offset="2">
              <el-form-item label="统一社会信用代码" prop="unifiedSocialCreditCode" :required="true">
                <el-input v-model="supplierBasicInfo.unifiedSocialCreditCode" maxlength="18"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="4" :offset="2">
              <el-form-item label="法人姓名" prop="supplierLegalPerson" :required="true">
                <el-input v-model="supplierBasicInfo.supplierLegalPerson"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="供应商电话" prop="supplierTel" :required="true">
                <el-input v-model="supplierBasicInfo.supplierTel"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8" :offset="2">
              <el-form-item label="注册地址" prop="supplierRegAddress" :required="true">
                <el-input v-model="supplierBasicInfo.supplierRegAddress"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="4" :offset="2">
              <el-form-item label="服务类型" prop="serviceType" :required="true">
                <el-select v-model="supplierBasicInfo.serviceType" multiple  clearable placeholder="请选择">
                  <el-option label="家访" value="0"></el-option>
                  <el-option label="资产保全" value="1"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="供应商邮箱" prop="supplierEmail" :required="true">
                <el-input v-model="supplierBasicInfo.supplierEmail"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <div class="grid-content bg-purple-dark row-title">开票信息</div>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="6">
              <el-form-item label="单位名称" prop="companyName" :required="true">
                <el-input v-model="supplierBasicInfo.companyName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="5" :offset="2">
              <el-form-item label="纳税人识别号" prop="companyTaxesId" :required="true">
                <!-- 15、18、20位 -->
                <el-input v-model="supplierBasicInfo.companyTaxesId" maxlength="20"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8" :offset="2">
              <el-form-item label="单位通讯地址" prop="companyAddress" :required="true">
                <el-input v-model="supplierBasicInfo.companyAddress"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="开户银行" prop="companyOpeningBankId" :required="true">
                <el-select v-model="supplierBasicInfo.companyOpeningBankId" clearable placeholder="请选择">
                  <el-option v-for="item in bankList" :label="item.bankName" :key="item.id"
                             :value="item.id"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="5" :offset="2">
              <el-form-item label="银行账户" prop="companyOpeningBankAccount" :required="true">
                <el-input v-model="supplierBasicInfo.companyOpeningBankAccount" maxlength="19"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8" :offset="2">
              <el-form-item label="单位电话" prop="companyTel" :required="true">
                <el-input v-model="supplierBasicInfo.companyTel"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="税率" prop="taxRate" :required="true">
                <el-select v-model="supplierBasicInfo.taxRate" clearable placeholder="请选择税率">
                  <el-option v-for="item in taxRateTypes" :label="item.label" :key="item.value"
                             :value="item.value"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <div class="grid-content bg-purple-dark row-title">收款账号信息</div>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="6">
              <el-form-item label="收款方账户名" prop="beneficiaryAccountName" :required="true">
                <el-input v-model="supplierBasicInfo.beneficiaryAccountName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8" :offset="2">
              <el-form-item label="账号类型" prop="beneficiaryAccountType" :required="true">
                <el-select v-model="supplierBasicInfo.beneficiaryAccountType" clearable placeholder="请选择">
                  <el-option v-for="item in beneficiaryAccountTypes" :label="item.label" :key="item.value"
                             :value="item.value"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="4" :offset="2">
              <el-form-item label="收款方银行" prop="beneficiaryBankId" :required="true">
                <el-select v-model="supplierBasicInfo.beneficiaryBankId" clearable placeholder="请选择">
                  <el-option v-for="item in bankList" :label="item.bankName" :key="item.id"
                             :value="item.id"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="收款方支行" prop="beneficiarySubBank" :required="true">
                <el-input v-model="supplierBasicInfo.beneficiarySubBank"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8" :offset="2">
              <el-form-item label="收款账号" prop="beneficiaryBeneficiaryCode" :required="true">
                <el-input v-model="supplierBasicInfo.beneficiaryBeneficiaryCode" :maxlength="19"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="4" :offset="2">
              <el-form-item label="收款方移动电话" prop="beneficiaryBankPhone" :required="true">
                <el-input maxlength="11" minlength="11" validate-event
                          v-model="supplierBasicInfo.beneficiaryBankPhone"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="开户行省份-城市" prop="beneficiaryCities" :required="true"
                            v-if="cityTree && cityTree.length">
                <el-cascader
                  expand-trigger="hover"
                  clearable
                  :props="bankCityProps"
                  :options="cityTree[0].cityList"
                  v-model="supplierBasicInfo.beneficiaryCities"
                  @change="bankCityChange">
                </el-cascader>
              </el-form-item>
            </el-col>
            <el-col :span="6" :offset="2">
              <el-form-item label="备注" prop="beneficiaryRemark">
                <el-input v-model="supplierBasicInfo.beneficiaryRemark"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <div class="grid-content bg-purple-dark row-title">授权区域</div>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="6">
              <el-form-item label="授权区域选择" prop="cityIds" class="is-required">
                <el-tree v-if="cityTree && cityTree.length"
                         style="height: 300px;overflow: auto;width: 100%"
                         :data="cityTree"
                         :props="cityProps"
                         :validate-event="true"
                         node-key="currentKey"
                         :default-checked-keys="supplierBasicInfo.cityIds"
                         :default-expanded-keys="[cityTree[0].currentKey, cityTree[0].cityList[0].currentKey]"
                         show-checkbox
                         @check="treeChange">
                </el-tree>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <div class="grid-content bg-purple-dark row-title">信息备注</div>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="备注" prop="remark">
                <el-input
                  type="textarea"
                  :rows="5"
                  placeholder="请输入备注内容"
                  v-model="supplierBasicInfo.remark">
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="系统用户信息" name="1">
        <el-row v-if="editable" style="margin: 20px 0; padding-right: 100px" type="flex" class="row-bg" justify="end">
          <el-button type="primary" @click="activeName = '2'">下一步</el-button>
          <el-button @click="applyAudit">提交审核</el-button>
        </el-row>
        <el-row>
          <el-col :span="24">
            <div class="grid-content bg-purple-dark row-title">系统用户信息</div>
          </el-col>
        </el-row>
        <!-- 创建用户的弹窗 -->
        <el-dialog title="新增系统用户" :visible.sync="dialogFormVisible" :modal="true" :modal-append-to-body="false">
          <el-form v-loading="saveSysUserInfoLoading" :rules="sysUserInfoRule" ref="sysUserForm" :model="sysUserInfo">
            <el-row>
              <el-col :span="10">
                <el-form-item label="手机号" :label-width="'120px'" prop="systemUserPhone" required>
                  <el-input v-model="sysUserInfo.systemUserPhone" maxlength="11"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="10">
                <el-form-item label="账号姓名" :label-width="'120px'" prop="systemUserName" required>
                  <el-input v-model="sysUserInfo.systemUserName"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="10">
                <el-form-item label="邮箱地址" :label-width="'120px'" prop="systemUserEmail" required>
                  <el-input v-model="sysUserInfo.systemUserEmail"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="10">
                <el-form-item label="账号ID" :label-width="'120px'" prop="systemUserId" required>
                  <el-input v-model="sysUserInfo.systemUserId"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="resetSysUserDialog">取 消</el-button>
            <el-button type="primary" @click="createSysUser">确 定</el-button>
          </div>
        </el-dialog>
        <el-row class="btn-plus" style="margin: 30px 0px" v-if="editable">
          <el-button type="primary" icon="el-icon-plus" @click="openSysUserDialog">新增</el-button>
        </el-row>
        <el-table
          :data="sysUserInfoList"
          stripe
          v-loading="getSysUserInfoListLoading"
          :max-height="maxTableHeight"
          style="width: 100%">
          <el-table-column
            type="index"
            label="序号"
            align="center">
          </el-table-column>
          <el-table-column
            prop="systemUserId"
            label="操作账号">
          </el-table-column>
          <el-table-column
            prop="systemUserName"
            label="账号姓名">
          </el-table-column>
          <el-table-column
            prop="systemUserPhone"
            label="手机号"
            maxlength="11">
          </el-table-column>
          <el-table-column
            prop="systemUserEmail"
            label="邮箱地址">
          </el-table-column>
          <el-table-column
            v-if="editable"
            prop="action"
            align="center"
            width="180"
            label="操作">
            <template slot-scope="scope">
              <el-button type="primary" size="mini" @click="editOperator(scope.row)">编辑</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="附件信息" name="2">
        <el-row v-if="editable" style="margin: 20px 0; padding-right: 100px" type="flex" class="row-bg" justify="end">
          <el-button type="primary" @click="saveFiles">保存</el-button>
          <el-button @click="applyAudit">提交审核</el-button>
        </el-row>
        <el-row>
          <el-col :span="24">
            <div class="grid-content bg-purple-dark row-title">供应商附件信息</div>
          </el-col>
        </el-row>
        <el-form :disabled="!editable" label-position="top" ref="fileForm" :model="supplierBasicInfo"
                 :rules="supplierBasicInfoRule">
          <el-row :gutter="20">
            <el-col style="margin-top: 40px" v-for="(attach, index) in attachInfo" :span="6" :offset="index % 3 ? 2 : 0"
                    :key="index">
              <el-form-item :label="attach.name" :required="attach.required">
                <supplierAttUpload :attach="attach" :editable="editable" @preView="handlePictureCardPreview"/>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-dialog :visible.sync="showPreview" size="tiny" :modal-append-to-body="false">
          <img width="100%" :src="dialogImageUrl" alt="">
        </el-dialog>
        <template v-if="showAuditForm">
          <el-col :span="24" style="margin-bottom: 30px">
            <div class="grid-content bg-purple-dark row-title">审核信息</div>
          </el-col>
          <el-form :model="supplierAuditInfo" ref="supplierAuditForm" label-width="80px">
            <el-form-item label="审核结果" prop="supplierAuditStatus" required>
              <el-select v-model="supplierAuditInfo.supplierAuditStatus" clearable placeholder="请选择">
                <el-option v-for="item in auditSelectOptions" :label="item.name" :key="item.value"
                           :value="item.value"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="审核备注">
              <el-input v-model="supplierAuditInfo.auditRemark" type="textarea" :rows="2"
                        placeholder="请输入备注内容"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button :span="4" @click="auditSupplier">提交</el-button>
              <el-button @click="goBack">返回</el-button>
            </el-form-item>
          </el-form>
        </template>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import cityTreeMixin from '../mixins/cityTreeMixin'
import bankListMixin from '../mixins/bankListMixin'
import { mapState } from 'vuex'
import supplierAttUpload from './supplierAttUpload'
import {
  // checkSocialCreditCode,
  checkTel, checkMobile
} from '../utils/vali.js'

// 验证规则
const validMobile = (rule, value, callback) => {
  if (!checkMobile(value)) { callback(new Error('请输入正确的手机号')) } else {
    callback()
  }
}

const validPhone = (rule, value, callback) => {
  if (checkTel(value) || checkMobile(value)) {
    callback()
  } else {
    callback(new Error('请输入正确的电话号码'))
  }
}

// const validSocialCreditCode = (rule, value, callback) => {
//   console.log(value)
//   if (value && checkSocialCreditCode(value)) {
//     console.log('信用码正确')
//     callback()
//   } else {
//     callback(new Error('请输入正确的统一社会信用编码'))
//   }
// }

export default {
  name: 'supplierInfo',
  mixins: [cityTreeMixin, bankListMixin],
  props: {
    isCreate: { // 是否是新建供应商
      type: Boolean,
      default: false
    },
    formType: {
      type: Number,
      default: 0 // 1新增，2浏览，3修改 4审核 ，通过四种状态判断按钮的展示
    },
    supplierDetail: {
      type: Object,
      default () {
        return {
          beneficiaryAccountName: '', // 收款方账户名, string
          beneficiaryAccountType: 1, // 账号类型1.企业, number
          beneficiaryBankId: '', // 收款方银行id,number
          beneficiaryBankPhone: '', // 收款方移动电话,string
          beneficiaryBeneficiaryCode: '', // 收款账号,string
          beneficiaryCity: '', // 开户行省份-城市,string
          beneficiaryCities: [],
          id: '', // 供应商ID
          beneficiaryRemark: '', // 收款方备注,string
          beneficiarySubBank: '', // 收款方支行,string
          cityIds: [], // 授权城市array<number>@mock=$order(31000,52200)
          companyAddress: '', // 单位通讯地址string@mock=华佗路288号
          companyName: '', // 单位名称string@mock=熊米科技有限公司
          companyOpeningBankAccount: '', // 开户行账户string@mock=23355415699522
          companyOpeningBankId: '', // 开户行id,number@mock=0
          companyTaxesId: '', // 纳税人识别号,string,@mock=2342342
          companyTel: '', // 单位电话,string,@mock=021-5458844
          remark: '', //  收款方备注,string,@mock=备注
          serviceType: [], // 服务类型 1.家纺2拖车,number@mock=0
          supplierEmail: '', // 供应商邮箱string@mock=xiaominig@163.com
          supplierLegalPerson: '', // 法人姓名,string@mock=李锡铭
          supplierName: '', // 供应商名称string@mock=供应商名称1
          supplierRegAddress: '', // 注册地址string@mock=延安西路88号
          supplierTel: '', // 供应商电话string@mock=0215488455
          taxRate: '', // 税率:%3和6%,number@mock=0
          unifiedSocialCreditCode: '' // 一社会信用代码string@mock=Fsfsffsfsfw
        }
      }
    }
  },
  computed: {
    ...mapState(['maxTableHeight']),
    editable: function () {
      return (this.formType === 1) || (this.formType === 3)
      // return true
    },
    showAuditForm: function () {
      return this.formType === 4
    }
  },
  data () {
    let checkCities = (rule, value, callback) => {
      let v = this.supplierBasicInfo.cityIds
      console.log(v)
      if (v && v.length > 0) {
        console.log('通过')
        // this.$refs.basicForm.validateField('cityIds')
        callback()
      } else {
        callback(new Error('请选择授权区域'))
      }
    }
    return {
      auditLoading: false, // 审核中的loading
      supplierAuditInfo: { // 审核信息
        supplierAuditStatus: '',
        auditRemark: ''
      },
      sysUserInfoList: [], // 供应商用户列表
      getSysUserInfoListLoading: false, // 供应商用户列表查询loading
      saveSysUserInfoLoading: false, // 保存用户信息的loading
      sysUserInfo: {
        systemUserEmail: '', // 邮箱
        systemUserId: '', //  操作账号ID
        systemUserName: '', // 姓名
        systemUserPhone: '' // 手机号
      },
      sysUserInfoRule: { // 供应商用户表单验证
        systemUserEmail: [
          { type: 'email', required: true, message: '请输入正确的邮箱地址', trigger: 'blur' },
          { type: 'email', required: true, message: '请输入正确的邮箱地址', trigger: 'change' }
        ],
        systemUserId: [
          { required: true, message: '请输入用户账号ID', trigger: 'blur' },
          { required: true, message: '请输入用户账号ID', trigger: 'change' }
        ], //  操作账号ID
        systemUserName: [
          { type: 'string', required: true, message: '请输入用户姓名', trigger: 'blur' },
          { type: 'string', required: true, message: '请输入用户姓名', trigger: 'change' }
        ], // 姓名
        systemUserPhone: [
          { validator: validMobile, message: '请输入用户手机号', trigger: 'blur' },
          { validator: validMobile, message: '请输入用户手机号', trigger: 'change' }
        ] // 手机号
      },
      dialogImageUrl: '', // 预览的图片地址
      showPreview: false, // 图片预览
      supplierBasicInfo: { // 供应商基本信息
        beneficiaryAccountName: '', // 收款方账户名, string
        beneficiaryAccountType: 1, // 账号类型1.企业, number
        beneficiaryBankId: '', // 收款方银行id,number
        beneficiaryBankPhone: '', // 收款方移动电话,string
        beneficiaryBeneficiaryCode: '', // 收款账号,string
        beneficiaryCity: '', // 开户行省份-城市,string
        beneficiaryCities: [],
        id: '', // 供应商ID
        beneficiaryRemark: '', // 收款方备注,string
        beneficiarySubBank: '', // 收款方支行,string
        cityIds: [], // 授权城市array<number>@mock=$order(31000,52200)
        companyAddress: '', // 单位通讯地址string@mock=华佗路288号
        companyName: '', // 单位名称string@mock=熊米科技有限公司
        companyOpeningBankAccount: '', // 开户行账户string@mock=23355415699522
        companyOpeningBankId: '', // 开户行id,number@mock=0
        companyTaxesId: '', // 纳税人识别号,string,@mock=2342342
        companyTel: '', // 单位电话,string,@mock=021-5458844
        remark: '', //  收款方备注,string,@mock=备注
        serviceType: [], // 服务类型 1.家纺2拖车,number@mock=0
        supplierEmail: '', // 供应商邮箱string@mock=xiaominig@163.com
        supplierLegalPerson: '', // 法人姓名,string@mock=李锡铭
        supplierName: '', // 供应商名称string@mock=供应商名称1
        supplierRegAddress: '', // 注册地址string@mock=延安西路88号
        supplierTel: '', // 供应商电话string@mock=0215488455
        taxRate: '', // 税率:%3和6%,number@mock=0
        unifiedSocialCreditCode: '', // 一社会信用代码string@mock=Fsfsffsfsfw
        supportService: ''
      },
      beneficiaryAccountTypes: [ // 收款方账号类型
        {
          label: '企业',
          value: 1
        }
      ],
      dialogFormVisible: false, // 新建对话框
      form: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: ''
      },
      auditSelectOptions: [ // 1.待审核2.审核已通过3.审核拒绝
        {
          name: '通过',
          value: 2
        },
        {
          name: '拒绝',
          value: 3
        }
      ],
      taxRateTypes: [
        {
          label: '3%',
          value: 1
        },
        {
          label: '6%',
          value: 2
        }
      ],
      currentPage: 1, // 系统用户页码
      activeName: '0', // 当前激活的选项卡
      bankCityProps: {
        value: 'currentKey',
        label: 'cityName',
        children: 'cityList'
      },
      cityProps: { // 属性菜单参数
        value: 'cityName',
        label: 'cityName',
        children: 'cityList'
      },
      attachInfo: [
        {
          node: 0,
          name: '三证合一营业执照',
          required: true,
          url: ''
        },
        {
          node: 1,
          name: '公司章程',
          required: true,
          url: ''
        },
        {
          node: 2,
          name: '实际控制人及法人代表身份证',
          required: true,
          url: ''
        },
        {
          node: 3,
          name: '主营地点租赁合同或房产证明',
          required: true,
          url: ''
        },
        {
          node: 4,
          name: '团队信息',
          required: true,
          url: ''
        },
        {
          node: 5,
          name: '账户信息',
          required: true,
          url: ''
        },
        {
          node: 6,
          name: '其他文件',
          required: false,
          url: ''
        }
      ], // 附件信息
      supplierBasicInfoRule: { // 验证规则
        beneficiaryAccountName: [
          { min: 2, max: 40, required: true, message: '请输入正确的账户名', trigger: 'blur' },
          { min: 2, max: 40, required: true, message: '请输入正确的账户名', trigger: 'change' }
        ],
        beneficiaryAccountType: [
          { required: true, message: '请选择账号类型', trigger: 'blur' },
          { required: true, message: '请选择账号类型', trigger: 'change' }
        ],
        beneficiaryBankId: [
          { required: true, message: '请选择开户银行', trigger: 'blur' },
          { required: true, message: '请选择开户银行', trigger: 'change' }
        ],
        beneficiaryBankPhone: [
          { validator: validMobile, required: true, message: '请输入正确的移动电话', trigger: 'blur' },
          { validator: validMobile, required: true, message: '请输入正确的移动电话', trigger: 'change' }
        ],
        beneficiaryBeneficiaryCode: [
          { min: 15, max: 19, required: true, message: '请输入正确的银行账号', trigger: 'blur' },
          { min: 15, max: 19, required: true, message: '请输入正确的银行账号', trigger: 'change' }
        ],
        beneficiaryCity: [
          { required: true, message: '请选择开户行省份及城市', trigger: 'blur' }
        ],
        beneficiaryCities: [
          { type: 'array', required: true, message: '请选择开户行省份及城市', trigger: 'change' }
        ],
        beneficiarySubBank: [
          // { required: true, message: '请输入开户行支行信息', trigger: 'blur' },
          { min: 2, max: 25, required: true, message: '请输入正确的开户行支行信息', trigger: 'blur' },
          { min: 2, max: 25, required: true, message: '请输入正确的开户行支行信息', trigger: 'change' }
        ],
        cityIds: [
          { type: 'array', message: '请选择授权区域', trigger: 'change' },
          { validator: checkCities, trigger: 'change', message: '请选择授权区域' }
        ],
        companyAddress: [
          { min: 2, max: 40, required: true, message: '请输入正确的单位通讯地址', trigger: 'blur' },
          { min: 2, max: 40, required: true, message: '请输入正确的单位通讯地址', trigger: 'change' }
        ],
        companyName: [
          { required: true, message: '请输入单位名称', trigger: 'blur' },
          { required: true, message: '请输入单位名称', trigger: 'change' }
        ],
        companyOpeningBankAccount: [
          { min: 15, max: 19, required: true, message: '请输入正确的银行账号', trigger: 'blur' },
          { min: 15, max: 19, required: true, message: '请输入正确的银行账号', trigger: 'change' }
        ],
        companyOpeningBankId: [
          { required: true, message: '请选择开户银行', trigger: 'blur' },
          { required: true, message: '请选择开户银行', trigger: 'change' }
        ],
        companyTaxesId: [
          { min: 15, max: 20, required: true, message: '请输入15、18或20位纳税人识别号', trigger: 'blur' },
          { min: 15, max: 20, required: true, message: '请输入15、18或20位纳税人识别号', trigger: 'change' }
        ],
        companyTel: [
          { required: true, message: '请输入正确的电话号码', trigger: 'blur' },
          { validator: validPhone, message: '请输入正确的电话号码', trigger: 'change' }
        ],
        serviceType: [
          {
            required: true,
            validator: (rule, value, callback) => {
              if (!value.length) {
                callback(new Error('请选择'))
              } else {
                callback()
              }
            }
          }
        ],
        supplierEmail: [
          { type: 'email', required: true, message: '请输入供应商邮箱', trigger: 'blur' },
          { type: 'email', required: true, message: '请输入供应商邮箱', trigger: 'change' }
        ],
        supplierLegalPerson: [
          { required: true, message: '请输入法人姓名', trigger: 'blur' },
          { required: true, message: '请输入法人姓名', trigger: 'change' }
        ],
        supplierName: [
          { required: true, message: '请输入供应商名称', trigger: 'blur' },
          { required: true, message: '请输入供应商名称', trigger: 'change' }
        ],
        supplierRegAddress: [
          { required: true, message: '请输入供应商注册地址', trigger: 'blur' },
          { required: true, message: '请输入供应商注册地址', trigger: 'change' }
        ],
        supplierTel: [
          { validator: validPhone, message: '请输入正确的电话号码', trigger: 'blur' },
          { validator: validPhone, message: '请输入正确的电话号码', trigger: 'change' }
        ],
        taxRate: [
          { required: true, message: '请选择开票税率', trigger: 'blur' },
          { required: true, message: '请选择开票税率', trigger: 'change' }
        ],
        unifiedSocialCreditCode: [
          { min: 18, max: 18, type: 'string', required: true, trigger: 'blur', message: '请输入正确的18位统一社会信用代码' },
          { min: 18, max: 18, type: 'string', required: true, trigger: 'change', message: '请输入正确的18位统一社会信用代码' }
          // { validator: validSocialCreditCode, trigger: 'change', message: '请输入正确的18位统一社会信用代码' }
        ]
      }
    }
  },
  async created () {
    if (this.formType === 0) {
      throw new Error('表单类型不可以为0')
    }
    this.supplierBasicInfo = {
      ...this.supplierDetail,
      serviceType: this.supplierDetail.supportService ? this.supplierDetail.supportService.split(',') : []
    }
  },
  methods: {
    async applyAudit () {
      if (this.supplierBasicInfo.supplierAuditStatus === 1) {
        this.$message({
          message: '当前供应商已提交审核，无需重新提交！！',
          type: 'warning'
        })
        return
      }
      if (this.supplierBasicInfo.supplierAuditStatus === 2) {
        this.$message({
          message: '当前供应商已审核通过，无需重新提交！！',
          type: 'warning'
        })
        return
      }
      if (!this.supplierBasicInfo.id) {
        this.$message({
          message: '当前供应商基础信息不存在或未保存！',
          type: 'warning'
        })
        return
      }
      try {
        await this.$api.submitStatus({
          supplierId: this.supplierBasicInfo.id,
          supplierAuditStatus: 1 // 设置为待审核
        })
        this.$message.success('供应商提交审核操作成功,页面返回中...')
        this.supplierBasicInfo.supplierStatus = 1
        setTimeout(() => {
          this.$router.go(-1)
        }, 500)
      } finally {

      }
    },
    async auditSupplier () {
      if (!this.supplierAuditInfo.supplierAuditStatus) {
        this.$message.error('请选则审核结果！')
        return
      }
      try {
        this.auditLoading = true
        await this.$api.audit({
          ...this.supplierAuditInfo,
          supplierId: this.supplierBasicInfo.id
        })
        this.$message.success('供应商审核操作成功,页面返回中...')
        setTimeout(() => {
          this.$router.go(-1)
        }, 1500)
      } finally {
        this.auditLoading = false
      }
    },

    async saveFiles () { // 保存文件
      console.log(this.attachInfo)
      for (let i = 0; i < this.attachInfo.length; i++) {
        let item = this.attachInfo[i]
        if (item.required && !item.url) {
          return this.$message.error(`请上传${item.name}`)
        }
      }
      try {
        await this.$api.saveSupplierFile({
          fileType: 0,
          outId: this.supplierBasicInfo.id,
          saveFileRequestDtoList: this.attachInfo
        })
        this.$message.success('供应商数据保存成功!')
        // setTimeout(() => {
        //   try {
        //     this.$router.go(-1)
        //   } catch {
        //     this.$router.push('./home/supplierManage')
        //   }
        // }, 1500)
      } finally {
      }
    },
    goBack () {
      try {
        this.$router.go(-1)
      } catch {
        this.$router.push('./supplierAudit')
      }
    },
    // 切换tab时的操作
    chooseUserTab (newTab, oldTab) {
      // 如果Id不存在则不允许跳转
      if (!this.supplierBasicInfo.id && (oldTab === '0')) {
        this.$message({
          message: '当前供应商基础信息不存在或未保存！',
          type: 'warning'
        })
        return false
      }
      if (newTab === '1' && this.sysUserInfoList.length === 0) {
        if (!this.isCreate) {
          this.getSupplierSystemUserList()
        }
      }
      if (newTab === '2') {
        // 不是新建，切当前无附件才获取附件
        if (!this.isCreate && !this.checkHasAttach()) {
          this.getSupplierFileList()
        }
      }
    },
    async getSupplierSystemUserList () {
      try {
        this.getSysUserInfoListLoading = true
        this.sysUserInfoList = await this.$api.findSupplierSystemUserList({
          supplierId: this.supplierBasicInfo.id
        })
      } finally {
        setTimeout(() => {
          this.getSysUserInfoListLoading = false
        }, 500)
      }
    },
    // 检测是否包含附件
    checkHasAttach () {
      return this.attachInfo.some(attach => attach.url)
    },
    async getSupplierFileList () {
      try {
        let fileList = await this.$api.getSupplierFileList({
          fileType: 0,
          outId: this.supplierBasicInfo.id
        })
        let fileDict = {}
        fileList.forEach(item => {
          fileDict[item.node] = item.url
        })
        this.attachInfo.forEach(item => {
          item.url = fileDict[item.node]
        })
        // this.attachInfo = fileList
        console.log(fileList)
      } finally {}
    },
    // 新增系统用户
    async createSysUser () {
      this.$refs['sysUserForm'].validate(async (valid) => {
        if (valid) {
          try {
            this.saveSysUserInfoLoading = true
            let data = {
              supplierId: this.supplierBasicInfo.id,
              ...this.sysUserInfo
            }
            if (this.sysUserInfo.id) {
              await this.$api.updateSupplierSystemUser(data)
            } else {
              await this.$api.saveSupplierSystemUser(data)
            }
            // 重置并关闭弹框
            this.resetSysUserDialog()
            this.$message({
              message: '保存供应商系统用户成功！',
              type: 'success'
            })
            this.getSupplierSystemUserList()
          } finally {
            setTimeout(() => {
              this.saveSysUserInfoLoading = false
            }, 500)
          }
        } else {
          this.$message.error('请完善表单内容！')
          return false
        }
      })
    },
    // 重置新建系统用户探矿内容并关闭弹框
    resetSysUserDialog () {
      this.dialogFormVisible = false
      this.sysUserInfo = {}
    },
    // 打开新增系统用户对话框
    openSysUserDialog () {
      console.log(this.supplierBasicInfo.id)
      if (!this.supplierBasicInfo.id) { // 如果供应商id不存在，阻止
        return this.$notify.error({
          title: '错误',
          message: '当前供应商基础信息不存在或未保存！'
        })
      }
      // 打开输入弹窗
      this.dialogFormVisible = true
    },
    saveBasicInfo () {
      this.$refs['basicForm'].validate((valid) => {
        if (valid) {
          this.$emit('savesupplierBasicInfo', this.supplierBasicInfo, () => {
            this.activeName = '1'
            console.log(this.activeName)
          })
        } else {
          this.$message.error('请填写所有必填项')
          return false
        }
      })
    },
    bankCityChange (val) { //  银行城市发生改变
      console.log(val[1])
      console.log(this.supplierBasicInfo.beneficiaryCities)
      this.supplierBasicInfo.beneficiaryCity = val[1]
    },
    editOperator (item) {
      this.sysUserInfo = {
        ...item
      }
      this.dialogFormVisible = true
    },
    handlePictureCardPreview (file) {
      this.dialogImageUrl = file.url
      this.showPreview = true
    },
    treeChange (data, status) {
      let ids = status.checkedKeys
      ids = ids.filter(item => item.length > 4)
      this.supplierBasicInfo.cityIds = ids
      this.$refs.basicForm.validateField('cityIds')
    }
  },
  components: {
    supplierAttUpload
  }
}
</script>

<style lang="sass" scoped>
  .supplierManage
    background: #fff
    box-shadow: 0 0 8px 0 rgba(232, 237, 250, .6), 0 2px 4px 0 rgba(232, 237, 250, .5)
    padding: 20px 20px 50px

    .row-title
      font-size: 18px
      height: 40px
      border-bottom: 1px solid #909399
</style>
