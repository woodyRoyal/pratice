<template>
  <div class="supplierManage">
    <el-row class="top-row">
      <span class="">供应商名称</span>
      <el-input class="input" v-model="supplierName" max="10" placeholder="请输入内容"
                @keyup.enter.native="getSupplierList(1)"></el-input>
      <span class="">审核状态</span>
      <el-select class="input" v-model="statusFilter" @clear="statusFilterClear" clearable placeholder="全部状态">
        <template v-if="listType === 1">
          <el-option
            v-for="item in optionsType1"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </template>
        <template v-else>
          <el-option
            v-for="item in optionsType2"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </template>
      </el-select>
      <el-button type="primary" @click="getSupplierList(1)">查询</el-button>
      <el-button @click="reset">重置</el-button>
    </el-row>
    <el-row class="btn-plus" v-if="listType === 1">
      <el-button type="primary" icon="el-icon-plus" @click="goCreateSuplier">新增</el-button>
    </el-row>
    <el-table
      :data="supplierList"
      v-loading="loading"
      :max-height="maxTableHeight"
      stripe
      style="width: 100%;margin-top: 10px">
      <el-table-column
        type="index"
        label="序号"
        align="center"
        width="50">
      </el-table-column>
      <el-table-column
        prop="supplierName"
        label="供应商名称">
      </el-table-column>
      <el-table-column
        prop="createAt"
        label="申请时间"
        width="180">
        <template slot-scope="scope">
          {{scope.row.createAt | formatDate}}
        </template>
      </el-table-column>
      <el-table-column
        prop="supplierLegalPerson"
        label="法人姓名"
        width="150">
      </el-table-column>
      <el-table-column
        prop="supplierTel"
        label="电话"
        width="150">
      </el-table-column>
      <el-table-column
        prop="unifiedSocialCreditCode"
        label="统一社会信用代码">
      </el-table-column>
      <el-table-column
        label="审核状态"
        width="80">
        <template slot-scope="scope">
          <el-tag :type="statusEnum[scope.row.supplierAuditStatus]">
            {{scope.row.supplierAuditStatus | auditStatus}}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column
        v-if="listType === 1"
        align="center"
        label="供应商状态"
        width="100">
        <template slot-scope="scope">
          <!--     仅当供应商状态为通过，才显示有效或无效，否则展示'/'     -->
<!--          <el-tag v-if="(scope.row.supplierAuditStatus === 2) && ((scope.row.supplierStatus === 2) || (scope.row.supplierStatus === 3))" :type="scope.row.supplierStatus === 2 ? 'success' : 'warning'">-->
          <el-tag v-if="scope.row.supplierAuditStatus === 2" :type="scope.row.supplierStatus === 2 ? 'success' : 'warning'">
            {{scope.row.supplierStatus | applierStatus}}
          </el-tag>
          <span v-else>/</span>
        </template>
      </el-table-column>
      <el-table-column
        v-if="listType === 1"
        prop="action"
        align="left"
        width="180"
        label="操作">
        <template slot-scope="scope">
          <!--     仅当供应商状态为通过且有效时禁止编辑    -->
          <el-button :disabled="scope.row.supplierAuditStatus === 2 && scope.row.supplierStatus === 2" type="primary" style="margin-right: 10px" size="mini" @click="goMaintainSupplier(scope.row)">编辑
          </el-button>
          <el-popover
            v-if="scope.row.supplierAuditStatus === 2"
            placement="top"
            width="160"
            v-model="scope.row.visible">
            <p v-if="scope.row.supplierStatus === 2">确定将此供应商置为无效吗？</p>
            <p v-else-if="scope.row.supplierStatus === 3">确定将此供应商置为有效吗？</p>
            <div style="text-align: right; margin: 0">
              <el-button size="mini" type="text" @click="scope.row.visible = false">取消</el-button>
              <el-button type="primary" size="mini" @click="toggleEfficacy(scope.row)">确定</el-button>
            </div>
            <el-button v-if="scope.row.supplierStatus === 2" :disabled="scope.row.supplierStatus !== 2 || scope.row.supplierAuditStatus !== 2" type="danger" size="mini" slot="reference">置为无效</el-button>
            <el-button v-else :disabled="scope.row.supplierStatus !== 3 || scope.row.supplierAuditStatus !== 2" type="warning" size="mini" slot="reference">置为有效
            </el-button>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column
        v-if="listType === 2"
        prop="action"
        align="center"
        width="180"
        label="操作">
        <template slot-scope="scope">
          <el-button v-if="scope.row.supplierAuditStatus === 1" type="primary" size="mini"
                     @click="auditSupplier(scope.row.id)">办理
          </el-button>
          <el-button v-else type="primary" size="mini" @click="viewSupplier(scope.row.id)">查看</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      v-if="pageConfig.tatalCount"
      style="margin-top: 30px"
      @size-change="pageSizeChange"
      @prev-click="handleCurrentChange"
      @next-click="handleCurrentChange"
      @current-change="handleCurrentChange"
      :current-page="pageConfig.currentIndex"
      :page-sizes="[10, 20, 30, 40]"
      :page-size="pageConfig.pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="pageConfig.tatalCount">
    </el-pagination>
  </div>
</template>

<script>
import { mapState } from 'vuex'

// 定义状态枚举，给供应商状态增加tag标签
const statusEnum = (function () {
  let statusEnum = {}
  statusEnum[statusEnum['warning'] = 1] = 'warning'
  statusEnum[statusEnum['success'] = 2] = 'success'
  statusEnum[statusEnum['danger'] = 3] = 'danger'
  return statusEnum
})()

export default {
  name: 'supplierList',
  props: [
    'listType' // 表示查询的列表类型，1 为供应商管理列表， 2 为供应商审核列表
  ],
  data () {
    return {
      statusEnum, // 定义状态枚举
      pageConfig: { // 页码相关
        pageSize: 20,
        currentIndex: 0,
        tatalCount: 0
      },
      loading: false, // 表格loading状态
      supplierName: '', // 供应商名称
      optionsType1: [ // 筛选配置
        {
          value: -1,
          label: '全部状态'
        },
        {
          value: 0,
          label: '未提交'
        }, {
          value: 1,
          label: '待审核'
        }, {
          value: 2,
          label: '通过'
        }, {
          value: 3,
          label: '拒绝'
        }
      ],
      optionsType2: [ // 筛选配置
        {
          value: -1,
          label: '全部状态'
        }, {
          value: 1,
          label: '待审核'
        }, {
          value: 2,
          label: '通过'
        }
      ],
      statusFilter: -1, // 当前选中的筛选供应商状态
      supplierList: []
    }
  },
  computed: {
    ...mapState(['maxTableHeight'])
  },
  created () {
    this.getSupplierList()
  },
  filters: {
    auditStatus (val) {
      switch (val) {
        case 0:
          return '未提交'
        case 1:
          return '待审核'
        case 2:
          return '通过'
        case 3:
          return '拒绝'
        case 4:
          return '退回'
        default:
          return '-'
      }
    },
    applierStatus (val) {
      switch (val) {
        case 2:
          return '有效'
        case 3:
          return '无效'
        default:
          return '/'
      }
    }
  },
  methods: {
    // 跳转至审核页面
    auditSupplier (id) {
      this.$router.push({ path: '/home/supplierAuditDetail', query: { id } })
    },
    // 跳转查看页面
    viewSupplier (id) {
      this.$router.push({ path: '/home/viewSupplier', query: { id } })
    },
    // 切换分页后，重新获取数据
    handleCurrentChange (pageIndex) {
      this.getSupplierList(pageIndex)
    },
    // 重置数据
    reset () {
      this.supplierName = ''
      this.statusFilter = -1
      this.getSupplierList()
    },
    // 页大小改变后，重新请求数据
    pageSizeChange (val) {
      // 计算当前第一页是第几条
      let nextIndex = parseInt((this.pageConfig.pageSize * this.pageConfig.currentIndex) / val)
      this.pageConfig.pageSize = val
      this.getSupplierList(nextIndex)
    },
    // 清除筛选状态
    statusFilterClear () {
      this.statusFilter = -1
    },
    // 去维护供应商
    goMaintainSupplier (item) {
      this.$router.push({ path: '/home/maintainSupplier', query: { id: item.id } })
    },
    // 去新建供应商
    goCreateSuplier () {
      this.$router.push('/home/createSupplier')
    },
    // 获取供应商列表
    async getSupplierList (pageIndex) {
      try {
        let data = {
          auditFlag: this.listType, // 查询类型，1、供应商列表页面，2审核列表页面
          pageNo: pageIndex || 1,
          pageSize: this.pageConfig.pageSize,
          supplierAuditStatus: this.statusFilter,
          supplierName: this.supplierName
        }
        if (this.statusFilter === -1) {
          delete data.supplierAuditStatus
        }
        this.loading = true
        let res = await this.$api.findSupplierList(data)
        setTimeout(() => {
          this.loading = false
          this.supplierList = res.list
          this.pageConfig.currentIndex = res.pageNum
          this.pageConfig.tatalCount = res.total
        }, 500)
      } catch {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 供应商生效/无效操作,item，反向修改
    async toggleEfficacy (item) {
      console.log(!item.efficacy)
      item.visible = false
      this.loading = true
      try {
        await this.$api.settingSupplierStatus({
          supplierId: item.id,
          supplierStatus: item.supplierStatus === 2 ? 3 : 2
        })
        setTimeout(() => {
          this.loading = false
          item.supplierStatus = item.supplierStatus === 2 ? 3 : 2
        }, 500)
      } catch (e) {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    }
  }
}
</script>

<style scoped lang="sass">
  .supplierManage
    background: #fff
    box-shadow: 0 0 8px 0 rgba(232, 237, 250, .6), 0 2px 4px 0 rgba(232, 237, 250, .5)
    padding: 20px

    .top-row
      font-size: 16px

      .input
        margin: 0 50px 0 20px
        width: 300px

    .btn-plus
      margin: 30px 0
</style>
