<template>
  <!-- 基本信息 begin -->
  <div class="modular-box">
    <div class="modular-box-th">
      <span class="modular-box-th-title">基本信息</span>
    </div>

    <div class="modular-box-tb scroll-box">
      <table v-loading="loading"
             class="tableMod">
        <tr>
          <td class="bg-td">UID</td>
          <td>{{basicInfo.uid}}</td>
          <td class="bg-td">客户姓名</td>
          <td>{{basicInfo.customerName}}</td>
          <td class="bg-td">性别</td>
          <td>{{basicInfo.sex}}</td>
          <td class="bg-td">手机号码</td>
          <td>{{basicInfo.phone}}</td>
          <td class="bg-td">申请类型</td>
          <td>{{basicInfo.applyType}}</td>
        </tr>
        <tr>
          <td class="bg-td">现居所在地省份-城市</td>
          <td>{{basicInfo.residenceProvinceAndCity}}</td>
          <td class="bg-td">居住详细地址</td>
          <td>{{basicInfo.residenceAddress}}</td>
          <td class="bg-td">户籍所在地省份-城市</td>
          <td>{{basicInfo. domicileProvinceAndCity}}</td>
          <td class="bg-td">户籍详细地址</td>
          <td>{{basicInfo.domicileAddress}}</td>
          <td class="bg-td">经销商名称</td>
          <td>{{basicInfo.agencyName}}</td>
        </tr>
        <tr>
          <td class="bg-td">单位所在地省份-城市</td>
          <td>{{basicInfo.companyProvinceAndCity}}</td>
          <td class="bg-td">单位详细地址</td>
          <td>{{basicInfo.companyAddress}}</td>
          <td class="bg-td">婚姻状况</td>
          <td>{{basicInfo.marryType}}</td>
          <td class="bg-td"></td>
          <td></td>
          <td class="bg-td"></td>
          <td></td>
        </tr>
        <tr>
          <td class="bg-td">车牌号</td>
          <td>{{basicInfo.carNo}}</td>
          <td class="bg-td">车型</td>
          <td>{{basicInfo.carModel}}</td>
          <td class="bg-td">车架号</td>
          <td>{{basicInfo.carChassisNo}}</td>
          <td class="bg-td">颜色</td>
          <td>{{basicInfo.carColor}}</td>
          <td class="bg-td">车辆类型</td>
          <td>{{basicInfo.carType}}</td>
        </tr>
        <tr>
          <td class="bg-td">融资总额(元)</td>
          <td>{{basicInfo.loanAmount | amount}}</td>
          <td class="bg-td">放款时间</td>
          <td>{{basicInfo.finishedTime | formatDate('yyyy-MM-dd')}}</td>
          <td class="bg-td">月租(元)</td>
          <td>{{basicInfo.monthlyRent | amount}}</td>
          <td class="bg-td">融资期限(月)</td>
          <td>{{basicInfo.totalPeriod}}</td>
          <td class="bg-td">租赁类型</td>
          <td>{{basicInfo.rentType}}</td>
        </tr>
        <tr>
          <td class="bg-td">逾期期数</td>
          <td>{{basicInfo.overduePeriod}}</td>
          <td class="bg-td">逾期金额(元)</td>
          <td>{{basicInfo.overdueAmount | amount}}</td>
          <td class="bg-td">已还期数</td>
          <td>{{basicInfo.finishedPeriod}}</td>
          <td class="bg-td">实际剩余本金(元)</td>
          <td>{{basicInfo.leftPrinciple | amount}}</td>
          <td class="bg-td">逾期天数(天)</td>
          <td>{{basicInfo.overdueDay}}</td>
        </tr>
        <tr>
          <td class="bg-td">申请编号</td>
          <td width='80'>{{basicInfo.applyId }}</td>
          <td class="bg-td">处理方式</td>
          <td width='80'>{{basicInfo.processModeDesc}}</td>
          <td class="bg-td">车辆抵押日期</td>
          <td width='80'>{{basicInfo.mortgageDate | formatDate('yyyy-MM-dd')}}</td>
          <td class="bg-td"></td>
          <td width='80'></td>
          <td class="bg-td"></td>
          <td width='80'></td>
        </tr>
        <tr v-if="isProperty">
          <td class="bg-td">产品名</td>
          <td width='80'>{{basicInfo.productName }}</td>
          <td class="bg-td">放款金额</td>
          <td width='80'>{{basicInfo.transferAmount | amount}}</td>
        </tr>
      </table>
    </div>
  </div>
  <!-- 基本信息 end -->
</template>

<script>
export default {
  props: {
    basicInfo: {
      type: Object
    },
    loading: {
      type: Boolean
    },
    isProperty: { // 资产保全管理入口
      type: Boolean,
      default: false
    }
  }
}
</script>

<style lang="sass" scoped>

</style>
