<template>
  <div class="main-con">
    <!-- 基本信息 begin -->
    <baseInfo :basicInfo='basicInfo'
              :loading='loading'
              :isProperty="true"></baseInfo>
    <!-- 基本信息 end -->

    <!-- 客户电话信息 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">客户电话信息</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading"
                    :data="contacts"
                    border
                    style="width: 100%">
            <el-table-column label="序号"
                             type="index"
                             align="center"
                             width="100"></el-table-column>
            <el-table-column prop="typeDesc"
                             label="电话类型"
                             align="center"></el-table-column>
            <el-table-column prop="customerName"
                             label="客户名称"
                             align="center"></el-table-column>
            <el-table-column prop="phone"
                             label="电话号码"
                             align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <!-- 客户电话信息 end -->
    <!-- 报告下载 -->
    <div style="display:inline-block;padding-bottom:20px;min-width:800px">
      <el-button type="primary"
                 size="mini"><a href="javascript:;"
           class="white"
           @click="down('carCollectReportFile')">《车辆回收报告》下载</a></el-button>
      <el-button type="primary"
                 size="mini"><a href="javascript:;"
           class="white"
           @click="down('carBasicDescFile')">《车辆基本情况描述》下载</a></el-button>
      <el-button type="primary"
                 size="mini"><a href="javascript:;"
           class="white"
           @click="down('carFinanceReportFile')">《车辆入库及财务交接清单》下载</a></el-button>
      <el-button type="primary"
                 size="mini"><a href="javascript:;"
           class="white"
           @click="down('carGiveUpFile')">《自弃声明》下载</a></el-button>
      <!-- <el-button type="primary"
                 size="mini"><a href="javascript:;"
           class="white"
           @click="down('carAuthorizeFile')">《授权委托书》下载
          带电子章</a></el-button> -->
      <el-button type="primary"
                 size="mini"
                 @click="downFileList()">《资料清单》下载</el-button>

    </div>
    <!-- form -->
    <el-card class="box-card">
      <el-form size="mini"
               :model="ruleForm"
               :inline="true"
               :rules="rules"
               ref="ruleForm"
               label-width="100px">
        <el-form-item label="是否自弃">
          <el-select v-model="ruleForm.hasAbandon"
                     style="width:178px"
                     :disabled="!detailFlag">
            <el-option label="否"
                       :value="false"></el-option>
            <el-option label="是"
                       :value="true"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="是否有钥匙">
          <el-select v-model="ruleForm.hasKey"
                     :disabled="!detailFlag">
            <el-option label="否"
                       :value="false"></el-option>
            <el-option label="是"
                       :value="true"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="预计上门时间">
          <el-date-picker size="mini"
                          style="width:178px"
                          :disabled="!detailFlag"
                          v-model="ruleForm.estimateArriveDateStr"
                          range-separator="至"
                          start-placeholder="开始日期"
                          value-format="yyyy-MM-dd"
                          end-placeholder="结束日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="收车人员">
          <el-input v-model="ruleForm.collectUser"
                    style="width:178px"
                    :disabled="!detailFlag"></el-input>
        </el-form-item>
        <el-form-item label="收车人电话">
          <el-input v-model="ruleForm.collectUserPhone"
                    style="width:178px"
                    :disabled="!detailFlag"></el-input>
        </el-form-item>
        <el-form-item label="预计收车时间">
          <el-date-picker size="mini"
                          style="width:178px"
                          :disabled="!detailFlag"
                          v-model="ruleForm.estimateCollectDate"
                          range-separator="至"
                          start-placeholder="开始日期"
                          value-format="yyyy-MM-dd"
                          end-placeholder="结束日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="出发省份">
          <el-select v-model="ruleForm.fromProvinceId"
                     clearable
                     :disabled="!detailFlag"
                     placeholder="请选择"
                     v-if="cityTree && cityTree[0].cityList">
            <el-option v-for="(item) in cityTree[0].cityList"
                       :key="item.currentKey"
                       :label="item.cityName"
                       :value="item.currentKey"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="出发城市">
          <el-select v-model="ruleForm.fromCityId"
                     clearable
                     :disabled="!detailFlag"
                     placeholder="请选择"
                     v-if="allcity">
            <el-option v-for="(item) in allcity"
                       :key="item.currentKey"
                       :label="item.cityName"
                       :value="item.currentKey"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="资产保全省份"
                      prop="protectProvinceId">
          <el-select v-model="ruleForm.protectProvinceId"
                     :disabled="!detailFlag"
                     clearable
                     placeholder="请选择"
                     v-if="cityTree && cityTree[0].cityList">
            <el-option v-for="(item) in cityTree[0].cityList"
                       :key="item.currentKey"
                       :label="item.cityName"
                       :value="item.currentKey"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="资产保全城市"
                      prop="protectCityId">
          <el-select v-model="ruleForm.protectCityId"
                     :disabled="!detailFlag"
                     clearable
                     placeholder="请选择"
                     v-if="allcity">
            <el-option v-for="(item) in allcity"
                       :key="item.currentKey"
                       :label="item.cityName"
                       :value="item.currentKey"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="预计里程">
          <el-input v-model="ruleForm.estimateDistance"
                    style="width:178px"
                    :disabled="!detailFlag"></el-input>
        </el-form-item>
        <el-form-item label="车辆停放地"
                      prop="carStopPlace">
          <el-input v-model="ruleForm.carStopPlace"
                    style="width:178px"
                    :disabled="!detailFlag"></el-input>
        </el-form-item>
        <el-form-item label="入库时间"
                      prop="storageDateStr">
          <el-date-picker size="mini"
                          :disabled="!detailFlag"
                          style="width:178px"
                          v-model="ruleForm.storageDateStr"
                          range-separator="至"
                          start-placeholder="开始日期"
                          value-format="yyyy-MM-dd"
                          end-placeholder="结束日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="上牌时间">
          <el-date-picker size="mini"
                          :disabled="!detailFlag"
                          style="width:178px"
                          v-model="ruleForm.carNoDate"
                          range-separator="至"
                          start-placeholder="开始日期"
                          value-format="yyyy-MM-dd"
                          end-placeholder="结束日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="停放SP处">
          <el-select v-model="ruleForm.carStopDealer"
                     :disabled="!detailFlag"
                     filterable
                     placeholder="请选择">
            <el-option v-for="(item, index) in spNameList"
                       :key="index"
                       :label="item"
                       :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="提车电话"
                      prop="buyCarPhone">
          <el-input v-model="ruleForm.buyCarPhone"
                    style="width:178px"
                    :disabled="!detailFlag"></el-input>
        </el-form-item>
        <el-form-item label="回款类型">
          <el-select v-model="ruleForm.returnMoneyType"
                     style="width:178px"
                     :disabled="!detailFlag">
            <el-option label="未回款"
                       :value="0"></el-option>
            <el-option label="回款逾期金额"
                       :value="1"></el-option>
            <el-option label="回款结清金额"
                       :value="2"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="其他费用">
          <el-input v-model="ruleForm.otherFee"
                    style="width:178px"
                    :disabled="!detailFlag"></el-input>
        </el-form-item>
        <el-form-item label="实际费用">
          <el-input v-model="ruleForm.actualFee"
                    style="width:178px"
                    :disabled="!detailFlag"></el-input>
        </el-form-item>
        <el-form-item label="交接日期">
          <el-date-picker size="mini"
                          style="width:178px"
                          :disabled="!detailFlag"
                          v-model="ruleForm.changeDate"
                          range-separator="至"
                          start-placeholder="开始日期"
                          value-format="yyyy-MM-dd"
                          end-placeholder="结束日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="实际里程">
          <el-input v-model="ruleForm.actualDistance"
                    style="width:178px"
                    :disabled="!detailFlag"></el-input>
        </el-form-item>
      </el-form>
      <!-- 图片上传区 -->
      <div>
        <h2>上传附件</h2>
        <CommonUpload :disabled="false"
                      accept="*/*"
                      :file-list="fileList"
                      @fileUpload="upload"></CommonUpload>
      </div>
      <div class="buts">
        <el-button type="primary"
                   @click="onSubmit"
                   v-if="detailFlag"
                   class="margin-10"
                   :loading="submitLoading">提交</el-button>
        <router-link to="/home/surrenderCarManage">
          <el-button>返回</el-button>
        </router-link>
      </div>
    </el-card>
  </div>
</template>
<script>
import api from '@/api2.0/surrenderCar/index'
import apiHost from '@/config/apiHost'
import baseInfo from '@/components/baseInfo2.0'
import CommonUpload from '@/components/CommonUpload'
import { amount, amountOfpoints } from '@/filters/index.js'
import cityTreeMixin from '@/mixins/cityTreeMixin'
export default {
  mixins: [cityTreeMixin],
  components: {
    baseInfo,
    CommonUpload
  },
  data () {
    return {
      loading: true,
      submitLoading: false,
      fileList: [], // 文件列表
      spNameList: [], // SP名称列表
      allcity: [], // 所有的市区
      detailFlag: false, // 是否可编辑Flag
      contacts: [], // 客户电话信息
      basicInfo: {}, // 基本信息
      contractTemplate: {}, // 合同模板下载
      ruleForm: {
        id: '',
        applyId: '',
        uid: '',
        extraFile: '', // 附件
        customerName: '', // 客户姓名
        hasAbandon: false, // 是否自弃
        hasKey: false, // 是否有钥匙
        estimateArriveDateStr: '', // 预计上门时间
        collectUser: '', // 收车人员
        collectUserPhone: '', // 收车人电话
        estimateCollectDate: '', // 预计收车时间
        fromProvinceId: '', // 出发省份
        fromCityId: '', // 出发市
        protectProvinceId: '', // 资产保全省份
        protectCityId: '', // 资产保全城市
        estimateDistance: '', // 预计里程
        carStopPlace: '', // 车辆停放地
        storageDateStr: '', // 入库时间
        carNoDate: '', // 上牌时间
        carStopDealer: '', // 停放SP处
        buyCarPhone: '', // 提车电话
        returnMoneyType: '', // 回款类型
        otherFee: '', // 其他费用
        actualFee: '', // 实际费用
        changeDate: '', // 交接日期
        actualDistance: '' // 实际里程
      },
      rules: {
        carStopPlace: [
          { required: true, message: '请输入车辆停放地', trigger: 'blur' }
        ],
        protectProvinceId: [
          { required: true, message: '请选择', trigger: 'blur' }
        ],
        protectCityId: [
          { required: true, message: '请选择', trigger: 'blur' }
        ],
        storageDateStr: [
          { required: true, message: '请选择入库时间', trigger: 'blur' }
        ],
        buyCarPhone: [
          { required: true, message: '请输入提车电话', trigger: 'blur' }
        ]
      }
    }
  },
  mounted () {
    if (this.$route.query.detailFlag.toString() === 'true') {
      this.detailFlag = true
    }
    this.getSpnameList()
    this.getDetailFun()
    this.getAllcity()
  },
  methods: {
    getAllcity () {
      let allcity = []
      this.cityTree[0].cityList.forEach(city => {
        allcity.push(...city.cityList)
      })
      this.allcity = allcity
    },
    // SP名称列表
    async getSpnameList () {
      this.loading = true
      let res = await this.$api.getSpnameList()
      this.spNameList = res
    },
    // 获取详情信息
    async getDetailFun () {
      try {
        let { type, id } = this.$route.query
        let apis = await [api.getInfoId, api.getInfoApplyId]
        // let key = Number(type) === 0 ? 'acceptId' : 'applyId'
        let res = await apis[type](
          id
        )
        this.basicInfo = res.basicInfo
        this.contacts = res.contacts
        this.contractTemplate = res.contractTemplate
        // 用户提交过
        if (Number(type) === 0) {
          this.ruleForm = res.abandonOrderInfo
          this.fileList = res.abandonOrderInfo.extraFile.split(',')
          this.ruleForm.actualFee = amount(this.ruleForm.actualFee)
          this.ruleForm.otherFee = amount(this.ruleForm.otherFee)
        } else {
          this.ruleForm.applyId = res.basicInfo.applyId
          this.ruleForm.uid = res.basicInfo.uid
          this.ruleForm.customerName = res.basicInfo.customerName
        }
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    async downFileList () {
      if (!this.contractTemplate.carDetailedFileList) {
        this.$message.error('下载文件为空')
      } else {
        window.location.href = apiHost.basePath + '/file/batchZipDownload' + '?urls=' + this.contractTemplate.carDetailedFileList + '&downloadZipFileName=' + '资料清单'
      }
    },
    down (item) {
      if (!this.contractTemplate[item]) return this.$message.error('该文件不存在')
      window.location.href = apiHost.basePath + '/file/singleDownload' + '?url=' + this.contractTemplate[item]
    },
    // 文件提交
    upload (file) {
      let formData = new FormData()
      formData.append('fileName', file)
      this.$api.uploadV2(formData)
        .then((res) => {
          this.fileList.push(res)
        })
    },
    pageBack () {
      window.history.back('-1')
    },
    // 提交
    onSubmit () {
      this.$refs.ruleForm.validate(async (valid) => {
        if (valid) {
          this.submitLoading = true
          try {
            let parame = { ...this.ruleForm }
            parame.extraFile = this.fileList.join(',')
            parame.otherFee = amountOfpoints(parame.otherFee)
            parame.actualFee = amountOfpoints(parame.actualFee)
            await api.updateInfo({ ...parame })
            this.$message.success('操作成功')
            this.submitLoading = false
            this.pageBack()
          } catch (error) {
            this.submitLoading = false
          }
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.white {
  color: #ffffff;
}
.buts {
  position: relative;
  z-index: 100;
  margin-top: 10px;
  display: flex;
  justify-content: center;
}
.margin-10 {
  margin: 0 10px;
}
</style>
