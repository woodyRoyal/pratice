<template>
  <div>
    <el-form :inline="true"
             size="small">
      <!-- 搜索区 -->
      <header class="header">
        <div>
          <el-form-item label="UID:">
            <el-input @input="limitNumberIn('uid',$event)"
                      v-model.trim="queryForm.uid"
                      placeholder="请输入UID"></el-input>
          </el-form-item>
          <el-form-item label="客户姓名:">
            <el-input v-model.trim="queryForm.customerName"
                      placeholder="请输入客户姓名"></el-input>
          </el-form-item>
          <el-form-item label="申请编号:">
            <el-input @input="limitNumberIn('applyId',$event)"
                      v-model.trim="queryForm.applyId"
                      placeholder="请输入申请编号"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary"
                       icon="el-icon-search"
                       :loading="loading"
                       @click="onQuery">
              {{ loading?'查询中...':'查询' }}
            </el-button>
            <el-button type="info"
                       @click="queryResetForm">
              重置
            </el-button>
          </el-form-item>
        </div>
        <div>
          <el-button @click="openDialog"
                     size="small"
                     type="primary"
                     icon="el-icon-edit">
            信息录入
          </el-button>
        </div>
      </header>
    </el-form>
    <!-- 表格区 -->
    <TableCom ref="tableCom"
              :operateWidth='200'
              :table-columns="tableColumns"
              :loading="loading"
              :table-data="tableData"
              :table-total="tableTotal"
              :table-operate="tableOperate"
              @handleOperate="handleOperate"
              @fetchData="fetchData">
      <el-table-column slot="operate"
                       label="操作"
                       align="center">
        <template slot-scope="scope">
          <span style="margin-left: 10px;"
                v-for="item in tableOperate"
                :key="item.type">
            <el-button size="mini"
                       v-if="item.type == 0 || (item.type == 1 && scope.row.editable)"
                       :type="item.color"
                       :icon="item.icon"
                       @click="handleOperate(item,scope.row)">{{item.name}}</el-button>
          </span>

        </template>
      </el-table-column>
    </TableCom>
    <!-- 信息录入 -->
    <el-dialog title="信息录入"
               :modal='false'
               :visible.sync="enteringDialog">
      <el-form>
        <el-form-item label="输入申请编号:">
          <el-input v-model.trim="applyId"
                    @input="(value)=>applyId=value.replace(/[^\d]/g, '')"
                    placeholder="请输入申请编号"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="enteringDialog = false">取消</el-button>
        <el-button type="primary"
                   @click="enteringHandler"
                   :disabled="applyId==''"
                   :loading="enteringLoading">开始录入</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import api from '@/api2.0/surrenderCar/index.js'
export default {
  /* eslint-disable no-undef */
  mixins: [privateMixin],
  data () {
    return {
      applyId: '', // 申请编号
      enteringDialog: false, // 信息录入弹框
      enteringLoading: false, // 加载
      queryForm: {
        uid: '', // uid
        customerName: '', // 客户姓名
        applyId: '' // 申请编号
      },
      tableColumns: [ // 表头
        { name: 'UID', key: 'uid' },
        { name: '客户姓名', key: 'customerName' },
        { name: '申请人员', key: 'applyUserName' },
        { name: '处理申请日期', key: 'createAt' },
        { name: '车牌号', key: 'carNo' },
        { name: '车架号', key: 'carChassisNo' },
        { name: '逾期天数（天）', key: 'overdueDay' }
      ],
      tableOperate: [ // 操作
        { name: '查看', type: 0, color: 'primary', icon: 'el-icon-view' },
        { name: '编辑', type: 1, color: 'warning', icon: 'el-icon-edit' }
      ]
    }
  },
  methods: {
    // 只能输入数字
    limitNumberIn (key, value) {
      this.queryForm[key] = value.replace(/[^\d]/g, '')
    },
    // 获取表格数据
    fetchData (pagination) {
      this.loading = true
      api.getCarList({ ...this.queryForm, ...pagination }).then((res) => {
        if (pagination.pageNo === 1) {
          this.$refs.tableCom.resetCurrentChange(pagination)
        }
        this.loading = false
        this.tableTotal = res.total
        this.tableData = res.list
      }).catch(() => {
        this.loading = false
      })
    },
    // 查询
    onQuery () {
      this.fetchData({
        pageNum: 1,
        pageSize: 20
      })
    },
    // 操作项
    handleOperate (operateItem, row) {
      this.$router.push({
        path: '/home/abandonCardetail', query: { type: 0, id: row.id, detailFlag: operateItem.type !== 0 }
      })
    },
    // 信息录入弹框
    openDialog () {
      this.applyId = ''
      this.enteringDialog = true
    },
    // 信息录入
    enteringHandler () {
      this.enteringLoading = true
      api.checkApplyId(this.applyId).then((res) => {
        this.$router.push({
          path: '/home/abandonCardetail', query: { type: 1, id: this.applyId, detailFlag: true }
        })
        this.enteringLoading = false
      }).catch(() => {
        this.enteringLoading = false
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.header {
  display: flex;
  justify-content: space-between;
}
</style>
