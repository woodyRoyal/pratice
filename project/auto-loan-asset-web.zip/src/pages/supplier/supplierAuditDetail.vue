<template>
  <supplierInfo v-if="supplierBasicInfo" :formType="4" :supplierDetail="supplierBasicInfo"></supplierInfo>
</template>

<script>
import supplierInfo from '../../components/supplierInfo'

export default {
  name: 'viewSupplier',
  components: {
    supplierInfo
  },
  data () {
    return {
      id: '', /// 供应商Id
      supplierBasicInfo: null // 供应商基础信息
    }
  },
  created () {
    this.id = this.getSupplierIdFromRouter()
    this.getSupplierDetailById(this.id)
  },
  methods: {
    getSupplierIdFromRouter () {
      return this.$route.query.id
    },
    async getSupplierDetailById (id) {
      this.supplierBasicInfo = await this.$api.getSupplierDetailById({ id })
    }
  }
}
</script>

<style scoped>

</style>
