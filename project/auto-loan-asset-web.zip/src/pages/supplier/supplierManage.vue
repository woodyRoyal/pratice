<template>
  <supplierList :listType="1"></supplierList>
</template>

<script>
import supplierList from '../../components/supplierList'
export default {
  name: 'supplierManage',
  components: {
    supplierList
  }
}
</script>
