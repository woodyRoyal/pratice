<template>
  <supplierInfo v-if="supplierBasicInfo" :formType="3" :supplierDetail="supplierBasicInfo" @savesupplierBasicInfo="updatesupplierBasicInfo"></supplierInfo>
</template>

<script>
import supplierInfo from '../../components/supplierInfo'

export default {
  name: 'maintainSupplier',
  components: {
    supplierInfo
  },
  data () {
    return {
      id: '', /// 供应商Id
      supplierBasicInfo: null // 供应商基础信息
    }
  },
  created () {
    this.id = this.getSupplierIdFromRouter()
    this.getSupplierDetailById(this.id)
  },
  methods: {
    async updatesupplierBasicInfo (data, fn) {
      let pra = {
        ...data,
        supportService: data.serviceType.join(',')
      }
      delete pra.serviceType
      let res = await this.$api.updateSupplier(pra)
      this.$message.success('保存成功！')
      console.log(res)
      fn && fn()
    },
    getSupplierIdFromRouter () {
      return this.$route.query.id
    },
    async getSupplierDetailById (id) {
      let res = await this.$api.getSupplierDetailById({ id })
      res.beneficiaryCities = [res.beneficiaryCity.substr(0, 3), res.beneficiaryCity]
      this.supplierBasicInfo = res
    }
  }
}
</script>

<style scoped>

</style>
