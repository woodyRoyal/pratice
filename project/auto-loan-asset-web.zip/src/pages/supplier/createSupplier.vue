<template>
  <supplierInfo :formType="1" :isCreate="true" @savesupplierBasicInfo="saveSupplierBasicInfo"></supplierInfo>
</template>

<script>
import supplierInfo from '../../components/supplierInfo'
export default {
  name: 'maintainSupplier',
  methods: {
    async saveSupplierBasicInfo (data, fn) {
      try {
        let res
        let pra = {
          ...data,
          supportService: data.serviceType.join(',')
        }
        delete pra.serviceType
        console.log(pra, res)
        if (data.id) {
          res = await this.$api.updateSupplier(pra)
        } else {
          res = await this.$api.saveSupplier(pra)
        }
        if (!data.id) data.id = res.supplierId
        this.$message.success('保存成功！')
        fn && fn(res.supplierId)
      } finally {
      }
    }
  },
  components: {
    supplierInfo
  }
}
</script>

<style scoped>

</style>
