<template>
  <div>
    <!-- 基本信息 begin -->
    <EssentialInfor :basicInfo='basicInfo' :loading='loading'></EssentialInfor>
    <!-- 基本信息 end -->

    <div class="modular-box">
      <div class="modular-box-form">
        <el-form :inline="true" size="small" label-position="top">
          <el-form-item label="家访日期">
            <el-date-picker disabled v-model="businessInfo.timeRange" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>

          <el-form-item label="家访要求">
            <el-input disabled v-model="businessInfo.visitRequirements" type="textarea"></el-input>
          </el-form-item>

          <el-form-item label="预计费用(元)">
            <el-input disabled v-model="businessInfo.expectFee" placeholder=""></el-input>
          </el-form-item>

          <el-form-item label="家访佣金(元)">
            <el-input disabled v-model="businessInfo.visitCommissionAmount" placeholder=""></el-input>
          </el-form-item>

          <el-form-item label="回款金额(元)">
            <el-input disabled v-model="businessInfo.receivableAmount" placeholder=""></el-input>
          </el-form-item>

          <el-form-item label="回款佣金(元)">
            <el-input disabled v-model="businessInfo.receivableCommissionAmount" placeholder=""></el-input>
          </el-form-item>

          <el-form-item label="申请佣金(元)">
            <el-input disabled v-model="businessInfo.applyCommissionAmount" placeholder=""></el-input>
          </el-form-item>
        </el-form>

        <a class="homeFileLink" :href="businessInfo.reportUrl" style="margin-bottom:10px">《家访报告》下载</a>
      </div>
    </div>

    <!-- 实际家访地址 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">实际家访地址</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table :show-header=false v-loading="loading" :data="addresses" border style="width: 100%">
            <el-table-column width="55">
              <template slot-scope="scope">
                <el-checkbox disabled v-model="scope.row.choose" :true-label="1" :false-label="0"></el-checkbox>
              </template>
            </el-table-column>
            <el-table-column label="序号" type="index" width="80" align="center"></el-table-column>
            <el-table-column prop="provinceAndCity" label="省/城市" align="center"></el-table-column>
            <el-table-column prop="address" label="详细地址" align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <!-- 实际家访地址 end -->

    <!-- 客户电话信息 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">客户电话信息</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading" :data="contacts" border style="width: 100%">
            <el-table-column label="序号" align="center" type="index" width="80"></el-table-column>
            <el-table-column prop="typeDesc" label="电话类型" align="center"></el-table-column>
            <el-table-column prop="customerName" label="客户名称" align="center">
              <template slot-scope="scope">
              {{scope.row.customerName | formatName}}
           </template>
            </el-table-column>
            <el-table-column prop="phone" label="电话号码" align="center"></el-table-column>
          </el-table>
        </div>
      </div>

    </div>
    <!-- 客户电话信息 end -->

    <!-- 家访受理信息 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">家访受理信息</span>
      </div>

      <div class="modular-box-form">
        <el-form :model="businessInfo" :inline="true" size="small" label-position="top">
          <el-form-item label="预计上门时间">
            <el-date-picker disabled v-model="businessInfo.estimateArriveDate" type="date" placeholder="选择日期"></el-date-picker>
          </el-form-item>

          <el-form-item label="家访人员">
            <el-input disabled v-model="businessInfo.visitUser" placeholder=""></el-input>
          </el-form-item>

          <el-form-item label="家访人电话">
            <el-input disabled v-model="businessInfo.visitUserPhone" placeholder=""></el-input>
          </el-form-item>

          <el-form-item label="上门时间">
            <el-date-picker disabled v-model="businessInfo.arriveDate" type="date" placeholder="选择日期"></el-date-picker>
          </el-form-item>

          <el-form-item label="出发省份">
            <el-select disabled v-model="businessInfo.fromProvinceId" placeholder="请选择">
              <el-option label="区域一" value="shanghai"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="出发城市">
            <el-select disabled v-model="businessInfo.fromCityId" placeholder="请选择">
              <el-option label="区域一" value="shanghai"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="预计登记时间">
            <el-date-picker disabled v-model="businessInfo.estimateRegisterDate" type="date" placeholder="选择日期"></el-date-picker>
          </el-form-item>

          <el-form-item label="家访省份">
            <el-select disabled v-model="businessInfo.visitProvinceId" placeholder="请选择">
              <el-option label="区域一" value="shanghai"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="预计里程(km)">
            <el-input disabled v-model="businessInfo.estimateDistance" placeholder=""></el-input>
          </el-form-item>

          <el-form-item label="登记时间">
            <el-date-picker disabled v-model="businessInfo.registerDate" type="date" placeholder="选择日期"></el-date-picker>
          </el-form-item>

          <el-form-item label="家访城市">
            <el-select disabled v-model="businessInfo.visitCityId" placeholder="请选择">
              <el-option label="区域一" value="shanghai"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="实际里程(km)">
            <el-input disabled v-model="businessInfo.distance" placeholder=""></el-input>
          </el-form-item>

        </el-form>
      </div>
    </div>
    <!-- 家访受理信息 end -->

    <!-- 处理记录 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">处理记录</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading" :data="processRecords" border style="width: 100%">
            <el-table-column label="序号" type="index" align="center" width="80"></el-table-column>
            <el-table-column prop="operator" label="审核人员" align="center"></el-table-column>
            <el-table-column label="审核日期" align="center">
              <template slot-scope="scope">
                {{scope.row.auditDate | formatDate('yyyy-MM-dd')}}
              </template>
            </el-table-column>
            <el-table-column prop="supplierName" label="派单供应商" align="center"></el-table-column>
            <el-table-column prop="auditStatusDesc" label="家访费用确认结果" align="center"></el-table-column>
            <el-table-column prop="reason" label="备注" align="center"></el-table-column>
          </el-table>
        </div>
      </div>

      <div class="modular-box-form">
        <el-form :model="audit" :rules="rules" ref="audit" :inline="true" size="small" label-position="top">
          <el-form-item prop="auditStatus" label="审核结果选择">
            <el-select :disabled="!detailFlag" v-model="audit.auditStatus" placeholder="请选择">
              <el-option label="审核通过" value="1"></el-option>
              <el-option label="审核退回" value="2"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item prop="reason" label="审核备注">
            <el-input :disabled="!detailFlag" v-model.trim="audit.reason" maxlength=100 type="textarea"></el-input>
          </el-form-item>

          <el-form-item prop="visitFeeAffirm" v-if="audit.auditStatus === '1'" label="确认家访费用">
            <el-input :disabled="!detailFlag" v-model.trim="audit.visitFeeAffirm" placeholder=""></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 处理记录 end -->

    <div class="submit-btn">
      <el-button v-if="detailFlag" :plain="true" @click="submitValidateFun()" type="primary">提 交</el-button>
      <el-button @click="pageBack()">返 回</el-button>
    </div>
  </div>
</template>

<script>
import EssentialInfor from '../../../components/essentialInfor'
import { amount, amountOfpoints } from '../../../filters/index.js'

export default {
  components: {
    EssentialInfor
  },
  data () {
    // 金额校验规则
    const temp = /^\d+\.?\d{0,3}$/
    const validAmount = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('费用不能为空'))
      } else if (Number(value) === 0) {
        callback(new Error('费用信息不能为0'))
      } else if (!temp.test(value)) {
        callback(new Error('请填写正确费用信息'))
      } else {
        callback()
      }
    }
    return {
      auditStatusMap: {
        1: '审核通过',
        2: '审核退回'
      },
      loading: true,
      detailFlag: false, // 是否可编辑Flag
      basicInfo: {}, // 基本信息
      processRecords: [], // 处理记录
      contacts: [], // 客户电话信息
      getDict: [], // 家访公司选择下拉菜单
      businessInfo: {}, // 家访派单详情
      addresses: [], // 家访地址要求
      // registerOrderBusinessInfo: [], // 派单信息
      // 提交审核
      audit: {
        auditStatus: '',
        reason: '',
        id: '',
        visitFeeAffirm: ''
      },
      rules: {
        auditStatus: [{ required: true, trigger: 'change', message: '请选择审核结果' }],
        reason: [{ required: true, trigger: 'blur', message: '请填写审核备注' }],
        visitFeeAffirm: [{ required: true, validator: validAmount, trigger: 'blur' }]
      }
    }
  },
  mounted () {
    if (this.$route.query.detailFlag.toString() === 'true') {
      this.detailFlag = true
    }
    this.audit.id = Number(this.$route.query.id)
    this.getDetailFun()
  },
  methods: {
    // 获取详情信息
    async getDetailFun () {
      try {
        let res = await this.$api.feeAffirmInfo({
          feeAffirmId: this.audit.id
        })
        this.basicInfo = res.homeVisitDetailInfo
        this.processRecords = res.processRecords
        this.contacts = res.contacts
        this.addresses = this.detailFlag ? res.addresses : res.addresses.filter(item => item.choose === 1)
        const businessInfo = res.registerOrderBusinessInfo
        const { visitStartTime, visitEndTime, expectFee, visitCommissionAmount, receivableAmount, receivableCommissionAmount, applyCommissionAmount } = businessInfo
        this.businessInfo = {
          ...businessInfo,
          timeRange: [visitStartTime || null, visitEndTime || null],
          expectFee: amount(expectFee),
          visitCommissionAmount: amount(visitCommissionAmount),
          receivableAmount: amount(receivableAmount),
          receivableCommissionAmount: amount(receivableCommissionAmount),
          applyCommissionAmount: amount(applyCommissionAmount)
        }
        const feeAffirmBussinessInfo = res.feeAffirmBussinessInfo
        const { auditStatus, visitFeeAffirm } = feeAffirmBussinessInfo
        this.audit = {
          ...feeAffirmBussinessInfo,
          visitFeeAffirm: amount(visitFeeAffirm),
          auditStatus: auditStatus !== 0 ? auditStatus.toString() : null
        }
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 提交校验
    submitValidateFun () {
      this.$refs['audit'].validate(async (valid) => {
        if (valid) {
          try {
            let str = '确认' + this.auditStatusMap[this.audit.auditStatus] + '+' + this.audit.reason + '?'
            let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '确定' })
            if (confirm) {
              this.submitFun()
            }
          } catch (error) {

          }
        }
      })
    },
    // 提交
    async submitFun () {
      const audit = this.audit
      const { visitFeeAffirm } = audit
      const dataForm = {
        ...audit,
        visitFeeAffirm: amountOfpoints(visitFeeAffirm)
      }
      let res = await this.$api.feeAffirmSubmit(dataForm)
      if (res) {
        this.$message.success('提交成功')
        this.pageBack()
      } else {
        this.$message.error('提交失败')
      }
    },
    // checkboxInit () {
    //   if (this.disabledFlag !== 0) {
    //     return true
    //   } else {
    //     return false
    //   }
    // },
    // 返回上一页
    pageBack () {
      window.history.back('-1')
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
