<template>
  <div>
    <!-- 筛选 begin -->
    <div class="query-box">
      <el-form :inline="true" class="demo-form-inline" size="small">
        <el-form-item label="申请编号">
          <el-input v-model.trim="queryform.applyId" placeholder=""></el-input>
        </el-form-item>

        <el-form-item label="客户姓名">
          <el-input v-model.trim="queryform.customerName" placeholder=""></el-input>
        </el-form-item>

        <el-form-item label="派单人员">
          <el-input v-model.trim="queryform.sendOrderUsername" placeholder=""></el-input>
        </el-form-item>

        <el-form-item label="确认状态">
          <el-select v-model="queryform.auditStatus" placeholder="请选择">
            <el-option v-for="(item, index) in stateDictionary" :key="index" :label="item" :value="index"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button @click="getListFun()" type="primary">查询</el-button>
          <el-button @click="queryResetFun()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 筛选 end -->

    <!-- 数据表格 begin -->
    <div class="tableMod">
      <el-table v-loading="loading" :data="dataTable" border style="width: 100%" :max-height="maxTableHeight">
        <el-table-column label="序号" type="index" width="80" align="center"></el-table-column>
        <el-table-column prop="applyId" label="申请编号" align="center"></el-table-column>
        <el-table-column prop="customerName" label="客户姓名" align="center">
          <template slot-scope="scope">
              {{scope.row.customerName | formatName}}
           </template>
        </el-table-column>
        <el-table-column prop="sendOrderUsername" label="派单人员" align="center"></el-table-column>
        <el-table-column label="受理日期" align="center">
           <template slot-scope="scope">
            {{scope.row.acceptDate | formatDate('yyyy-MM-dd')}}
          </template>
        </el-table-column>
        <el-table-column prop="visitRequirements" label="家访要求" align="center" width="200"></el-table-column>
        <el-table-column label="供应商" align="center">
          <template slot-scope="scope">
            {{scope.row.supplierName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="预计费用(元)" align="center">
          <template slot-scope="scope">
            {{scope.row.expectFee | amount}}
          </template>
        </el-table-column>
        <el-table-column label="申请费用(元)" align="center">
          <template slot-scope="scope">
            {{scope.row.applyCommissionAmount | amount}}
          </template>
        </el-table-column>
        <el-table-column label="欠款金额(元)" align="center">
          <template slot-scope="scope">
            {{scope.row.overdueAmount | amount}}
          </template>
        </el-table-column>
        <el-table-column label="登记日期" align="center">
          <template slot-scope="scope">
            {{scope.row.registerDate | formatDate('yyyy-MM-dd')}}
          </template>
        </el-table-column>
        <el-table-column label="是否改派" align="center">
          <template slot-scope="scope">
            {{scope.row.isExchange === 0 ? '否' : '是'}}
          </template>
        </el-table-column>
        <el-table-column prop="auditStatus" label="确认状态" align="center">
          <template slot-scope="scope">
            {{stateDictionary[scope.row.auditStatus]}}
          </template>
        </el-table-column>
        <el-table-column prop="businessType" label="任务类型" align="center"></el-table-column>
        <el-table-column label="任务到达时间" align="center">
          <template slot-scope="scope">
            {{scope.row.createAt | formatDate('yyyy-MM-dd hh:mm:ss')}}
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" fixed="right" width="70">
          <template slot-scope="scope">
            <a class="btn-blue" v-if="scope.row.editable" @click="toCompactFun(scope.row)">办理</a>
            <a class="btn-blue" v-else @click="toCompactFun(scope.row)">查看</a>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 数据表格 end -->

    <!-- 分页 begin -->
    <el-pagination
    @size-change="handleSizeChange"
    @current-change="handleCurrentChange"
    :current-page="page.currentPage"
    :page-sizes="page.pageSizesArr"
    :page-size="page.pageSize"
    :total="page.total"
    layout="total, sizes, prev, pager, next, jumper" >
    </el-pagination>
    <!-- 分页 end -->
  </div>
</template>

<!--
  注：表格操作栏状态判断如下
  1.办理：如果editable字段为true，并且角色是资产总监，
  2.查看：角色是资产专员
-->
<script>
import { mapState } from 'vuex'
export default {
  data () {
    return {
      loading: true,
      dataTable: [], // 列表Table数据
      // 筛选条件
      queryform: {
        applyId: null, // 申请编号
        auditStatus: null, // 费用确认审核状态(0:待审核,1:通过,2:拒绝)
        customerName: null, // 客户姓名
        pageNum: 1, // 页码
        pageSize: 20, // 每页大小
        sendOrderUsername: null // 派单人员
      },
      stateDictionary: {
        0: '待审核',
        1: '确认通过',
        2: '确认退回'
      },
      // 分页
      page: {
        total: 0,
        pageSizesArr: [10, 20, 30, 40],
        currentPage: 1, // 当前页
        pageSize: 20 // 每页条数
      }
    }
  },
  computed: {
    ...mapState(['maxTableHeight', 'userInfoName'])
  },
  created () {
    let history = window.sessionStorage
    this.queryform.pageNum = this.page.currentPage = parseInt(history.getItem('pageIndex')) || 1
  },
  mounted () {
    this.getListFun()
  },
  methods: {
    // 重置
    queryResetFun () {
      this.queryform = {
        applyId: null,
        auditStatus: null,
        customerName: null,
        pageNum: 1,
        pageSize: 20,
        sendOrderUsername: null
      }
      this.page.currentPage = 1
      this.page.pageSize = 20
      this.getListFun()
    },
    // 获取列表Table数据
    async getListFun () {
      try {
        this.loading = true
        let res = await this.$api.feeAffirm(this.queryform)
        this.dataTable = res.list
        this.page.total = res.total
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 查看或办理跳转
    toCompactFun (row) {
      const { id } = row
      let detailFlag = !!row.editable
      this.$router.push({
        path: '/home/homeCostDetail', query: { id, detailFlag }
      })
    },
    // 分页操作
    handleSizeChange (val) {
      this.page.pageSize = val
      this.queryform.pageSize = val
      this.getListFun()
    },
    handleCurrentChange (val) {
      this.queryform.pageNum = val
      this.page.currentPage = val
      window.sessionStorage.setItem('pageIndex', val)
      this.getListFun()
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
