<template>
  <div>
    <!-- 基本信息 begin -->
    <EssentialInfor :basicInfo='basicInfo' :loading='loading'></EssentialInfor>
    <!-- 基本信息 end -->

    <div class="modular-box">
      <div class="modular-box-form">
        <el-form :model="submissionData" :rules="rules" ref="submissionData" :inline="true" size="small" label-position="top">
          <el-form-item label="家访日期">
            <el-date-picker disabled v-model="submissionData.timeRange" type="daterange" value-format="yyyy-MM-dd" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>

          <el-form-item label="家访要求">
            <el-input disabled v-model.trim="submissionData.visitRequirements" type="textarea"></el-input>
          </el-form-item>

          <el-form-item label="预计费用(元)">
            <el-input disabled v-model.trim="submissionData.expectFee" placeholder=""></el-input>
          </el-form-item>

          <el-form-item prop="visitCommissionAmount" label="家访佣金(元)">
            <el-input v-model.trim="submissionData.visitCommissionAmount" placeholder=""></el-input>
          </el-form-item>

          <el-form-item label="回款金额(元)">
            <el-input v-model.trim="submissionData.receivableAmount" placeholder=""></el-input>
          </el-form-item>
          <el-form-item label="回款佣金(元)">
            <el-input v-model.trim="submissionData.receivableCommissionAmount" placeholder=""></el-input>
          </el-form-item>
          <el-form-item prop="applyCommissionAmount" required="" label="申请佣金(元)">
            <el-input v-model.trim="submissionData.applyCommissionAmount" placeholder=""></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>

    <!-- 实际家访地址 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">实际家访地址</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table :show-header=false v-loading="loading" :data="addressData" border style="width: 100%">
            <el-table-column width="55" >
              <template slot-scope="scope">
                <el-checkbox v-model="scope.row.choose" :true-label="1" :false-label="0"></el-checkbox>
              </template>
            </el-table-column>
            <el-table-column label="序号" type="index" width="80" align="center"></el-table-column>
            <el-table-column  prop="provinceAndCity" label="省/城市" align="center"></el-table-column>
            <el-table-column  prop="address" label="详细地址" align="center"></el-table-column>
          </el-table>
        </div>
      </div>

      <el-upload class="upload-comp" style="margin:10px;"
        :action="uploadUrl"
        name="fileName"
        :limit=1
        :file-list="fileList"
        :on-exceed="handleExceed"
        :on-error="handleUploadError"
        :on-success="handleUploadSuccess"
        :before-upload="handbeforeUpload">
        <el-button size="small" type="primary">《家访报告》上传</el-button>
        <div slot="tip" class="el-upload__tip">只能上传pdf、word文件，且不超过10M</div>
      </el-upload>
    </div>
    <!-- 实际家访地址 end -->

    <!-- 客户电话信息 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">客户电话信息</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading" :data="contacts" border style="width: 100%">
            <el-table-column label="序号" type="index" align="center" width="100"></el-table-column>
            <el-table-column prop="typeDesc" label="电话类型" align="center"></el-table-column>
            <el-table-column prop="customerName" label="客户名称" align="center">
              <template slot-scope="scope">
              {{scope.row.customerName | formatName}}
           </template>
            </el-table-column>
            <el-table-column prop="phone" label="电话号码" align="center"></el-table-column>
          </el-table>
        </div>
      </div>

    </div>
    <!-- 客户电话信息 end -->

    <!-- 家访受理信息 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">家访受理信息</span>
      </div>

      <div class="modular-box-form">
        <el-form :model="submissionData" :rules="rules" ref="submissionData2" :inline="true" size="small" label-position="top">
          <el-form-item label="预计上门时间">
            <el-date-picker v-model="submissionData.estimateArriveDate" disabled type="date" placeholder="选择日期"></el-date-picker>
          </el-form-item>

          <el-form-item label="家访人员">
            <el-input disabled v-model="submissionData.visitUser" placeholder=""></el-input>
          </el-form-item>

          <el-form-item label="家访人电话">
            <el-input disabled v-model="submissionData.visitUserPhone" placeholder=""></el-input>
          </el-form-item>

          <el-form-item prop="arriveDate" label="上门时间">
            <el-date-picker v-model="submissionData.arriveDate" type="date" value-format="yyyy-MM-dd" placeholder="选择日期"></el-date-picker>
          </el-form-item>

          <el-form-item label="出发省份">
            <el-select disabled v-model="submissionData.fromProvinceId" placeholder="请选择">
              <el-option v-for="item in provinces" :key="item.currentKey" :label="item.cityName" :value="item.currentKey"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="出发城市">
            <el-select disabled v-model="submissionData.fromCityId" placeholder="请选择">
              <el-option label="区域一" value="shanghai"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="预计登记时间">
            <el-date-picker disabled v-model="submissionData.estimateRegisterDate" type="date" placeholder="选择日期" value-format="yyyy-MM-dd"></el-date-picker>
          </el-form-item>

          <el-form-item label="家访省份">
            <el-select disabled v-model="submissionData.visitProvinceId" placeholder="请选择">
              <el-option v-for="item in provinces" :key="item.currentKey" :label="item.cityName" :value="item.currentKey"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="预计里程">
            <el-input disabled v-model="submissionData.estimateDistance" placeholder=""></el-input>
          </el-form-item>

          <el-form-item prop="registerDate" label="登记时间">
            <el-date-picker v-model="submissionData.registerDate" value-format="yyyy-MM-dd" type="date" placeholder="选择日期"></el-date-picker>
          </el-form-item>

          <el-form-item label="家访城市">
            <el-select disabled v-model="submissionData.visitCityId" placeholder="请选择">
              <el-option label="区域一" value="shanghai"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item prop="distance" label="实际里程(km)">
            <el-input v-model="submissionData.distance" placeholder=""></el-input>
          </el-form-item>

        </el-form>
      </div>
    </div>
    <!-- 家访受理信息 end -->

    <!-- 处理记录 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">处理记录</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading" :data="processRecords" border style="width: 100%">
            <el-table-column label="序号" align="center" type="index" width="100"></el-table-column>
            <el-table-column label="派单日期" align="center">
              <template slot-scope="scope">
                {{Number(scope.row.sendOrderDate) | formatDate('yyyy-MM-dd')}}
              </template>
            </el-table-column>
            <el-table-column prop="visitRequirements" label="家访要求" align="center"></el-table-column>
            <el-table-column label="家访登记审核结果" align="center">
              <template slot-scope="scope">
                {{auditStatusDictionary[scope.row.auditStatus]}}
              </template>
              auditStatusDictionary
            </el-table-column>
            <el-table-column prop="reason" label="备注" align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <!-- 处理记录 end -->

    <div class="submit-btn">
      <el-button @click="submitValidateFun()" type="primary">提 交</el-button>
      <el-button @click="pageBack()">返 回</el-button>
    </div>
  </div>
</template>

<script>
import apiHost from '../../../config/apiHost'
import EssentialInfor from '../../../components/essentialInfor'
import { amount, amountOfpoints, formatDate } from '../../../filters/index.js'

export default {
  components: {
    EssentialInfor
  },
  data () {
    // 金额校验规则
    const temp = /^\d+\.?\d{0,3}$/
    const validAmount = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请填写佣金'))
      } else if (Number(value) === 0) {
        callback(new Error('佣金不能为0'))
      } else if (!temp.test(value)) {
        console.log(value)
        callback(new Error('请输入正确的佣金'))
      } else {
        callback()
      }
    }
    return {
      loading: true,
      detailFlag: false, // 是否可编辑Flag; 0:可编辑
      provinces: [], // 城市/省份列表
      basicInfo: {}, // 基本信息
      processRecords: [], // 处理记录
      contacts: [], // 客户电话信息
      addressData: [], // 实际家访地址
      fileList: [], // 文件数组
      fileListData: {// 文件对象
        name: '',
        url: ''
      },
      submissionData: {
        addressIds: [] // 家访地址ids
      },
      // 家访登记审核结果字典
      auditStatusDictionary: {
        0: '待审核',
        1: '通过',
        2: '退回'
      },
      rules: {
        visitCommissionAmount: [{ validator: validAmount, required: true, trigger: 'blur' }],
        applyCommissionAmount: [{ validator: validAmount, required: true, trigger: 'blur' }],
        registerDate: [{ required: true, trigger: 'change', message: '请选择登记时间' }],
        arriveDate: [{ required: true, trigger: 'change', message: '请选择上门时间' }],
        distance: [{ required: true, trigger: 'change', message: '请填写实际里程' }]
      },
      fileType: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
      uploadUrl: `${apiHost.basePath}/file/upload`,
      attach: {
        typoe: Object,
        default () {
          return {}
        }
      },
      upLoadFile: {
        fileName: null
      }
    }
  },
  mounted () {
    if (this.$route.query.detailFlag.toString() === 'true') {
      this.detailFlag = true
    }
    this.getCityFun()
    this.getDetailFun()
  },
  methods: {
    // 获取城市列表
    async getCityFun () {
      let res = await this.$api.getCityList()
      this.provinces = res.provinces
    },
    // 获取详情信息
    async getDetailFun () {
      try {
        let res = await this.$api.registerOrderGetInfo({
          registerOrderId: this.$route.query.id
        })
        this.basicInfo = res.basicInfo
        this.processRecords = res.processRecords
        this.contacts = res.contacts
        // 判断查看还是办理，如果是查看，只显示勾选的地址
        this.addressData = this.detailFlag ? res.addresses : res.addresses.filter(item => item.choose === 1)
        const businessInfo = res.businessInfo
        const { visitStartTime, visitEndTime, expectFee, visitCommissionAmount, receivableAmount, receivableCommissionAmount, registerDate, applyCommissionAmount } = businessInfo
        this.submissionData = {
          ...businessInfo,
          addressIds: [],
          timeRange: visitStartTime && visitEndTime ? [visitStartTime, visitEndTime] : [],
          expectFee: amount(expectFee),
          visitCommissionAmount: amount(visitCommissionAmount),
          receivableAmount: amount(receivableAmount),
          receivableCommissionAmount: amount(receivableCommissionAmount),
          applyCommissionAmount: amount(applyCommissionAmount),
          expectFee1: amountOfpoints(expectFee),
          registerDate: registerDate ? formatDate(registerDate).split(' ')[0] : ''
        }
        this.fileListData.name = businessInfo.reportName
        this.fileListData.url = businessInfo.reportUrl
        if (this.fileListData.name !== '' && this.fileListData.url !== '') {
          this.fileList.push(this.fileListData)
        }
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 提交校验
    submitValidateFun () {
      let form1 = false
      let form2 = false
      let form3 = false
      this.$refs['submissionData'].validate((valid) => {
        if (valid) {
          form1 = true
        }
      })
      this.$refs['submissionData2'].validate((valid) => {
        if (valid) {
          form2 = true
        }
      })

      form3 = this.addressData.some(item => {
        return item.choose === 1
      })

      if (!form3) {
        this.$message.error('请选择实际家访地址')
      }

      if (form1 && form2 && form3) {
        this.submitFun()
      }
    },
    // 提交
    async submitFun () {
      let submitData = {
        addressIds: [],
        applyCommissionAmount: amountOfpoints(this.submissionData.applyCommissionAmount),
        arriveDate: this.submissionData.arriveDate,
        distance: this.submissionData.distance,
        id: this.$route.query.id,
        receivableAmount: amountOfpoints(this.submissionData.receivableAmount),
        receivableCommissionAmount: amountOfpoints(this.submissionData.receivableCommissionAmount),
        registerDate: this.submissionData.registerDate,
        reportUrl: this.submissionData.reportUrl,
        reportName: this.submissionData.reportName,
        visitCommissionAmount: amountOfpoints(this.submissionData.visitCommissionAmount)
      }
      this.addressData.forEach(element => {
        if (element.choose === 1) {
          submitData.addressIds.push(element.id)
        }
      })

      let res = await this.$api.registerOrderSubmit(submitData)

      if (res) {
        this.$message.success('提交成功')
        this.pageBack()
      } else {
        this.$message.error('提交失败')
      }
    },
    // 上传部分
    handbeforeUpload (file) {
      if (!this.fileType.includes(file.type)) {
        this.$message.error('目前只支持pdf、word格式的文件')
        return false
      }
    },
    // 当文件数量超出限定时
    handleExceed (files, fileList) {
      this.$message.warning(`当前限制选择 1 个文件`)
    },
    handleUploadSuccess (res, file) {
      this.submissionData.reportUrl = res.result
      this.submissionData.reportName = file.name
      this.$message.success('文件上传成功')
    },
    handleUploadError () {
      this.$message.error('文件上传失败！')
    },
    async upLoadFileFun () {
      let res = await this.$api.upLoadFile(this.upLoadFile)
      console.log(res)
    },
    // 返回上一页
    pageBack () {
      window.history.back('-1')
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
