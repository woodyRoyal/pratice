<template>
  <div class="main-con">
    <!-- 筛选 begin -->
    <div class="query-box">
      <el-form :inline="true" class="demo-form-inline" size="small">
        <el-form-item label="申请编号">
          <el-input v-model.trim="queryform.applyId" placeholder=""></el-input>
        </el-form-item>
        <el-form-item label="客户姓名">
          <el-input v-model.trim="queryform.customerName" placeholder=""></el-input>
        </el-form-item>
        <el-form-item label="是否受理">
          <el-select v-model="queryform.acceptStatus" placeholder="请选择">
            <el-option v-for="(item, index) in trueFalseDictionary" :key="index" :label="item" :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="getListFun()">查询</el-button>
          <el-button @click="queryResetFun()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 筛选 end -->

    <!-- 数据表格 begin -->
    <div class="tableMod">
      <el-table v-loading="loading" :data="dataTable" border style="width: 100%" :max-height="maxTableHeight">
        <el-table-column label="序号" type="index" width="80" align="center"></el-table-column>
        <el-table-column prop="applyId" label="申请编号" align="center"></el-table-column>
        <el-table-column prop="customerName" label="客户姓名" align="center">
          <template slot-scope="scope">
              {{scope.row.customerName | formatName}}
           </template>
        </el-table-column>
        <el-table-column label="派单日期" align="center">
          <template slot-scope="scope">
            {{scope.row.sendOrderDate | formatDate('yyyy-MM-dd')}}
          </template>
        </el-table-column>
        <el-table-column prop="visitRequirements" label="家访要求" align="center" width="200"></el-table-column>
        <el-table-column label="上门地址数量" align="center">
          <template slot-scope="scope">
            <a v-if="scope.row.addressCount" href="javascript:" class="btn-blue" @click="DialogDataFun(scope.row.addresses)">{{scope.row.addressCount}}</a>
            <span v-else>/</span>
          </template>
        </el-table-column>
        <el-table-column prop="overdueDay" label="逾期天数(天)" align="center"></el-table-column>
        <el-table-column label="预计家访费用(元)" align="center">
          <template slot-scope="scope">
            {{scope.row.expectFee | amount}}
          </template>
        </el-table-column>
        <el-table-column label="欠款金额(元)" align="center">
          <template slot-scope="scope">
            {{scope.row.overdueAmount | amount}}
          </template>
        </el-table-column>
        <el-table-column label="受理日期" align="center">
          <template slot-scope="scope">
            {{scope.row.acceptDate | formatDate('yyyy-MM-dd')}}
          </template>
        </el-table-column>
        <el-table-column label="是否受理" align="center">
          <template slot-scope="scope">
            {{scope.row.acceptStatus || '/'}}
          </template>
        </el-table-column>
        <el-table-column prop="businessType" label="任务类型" align="center"></el-table-column>
        <el-table-column label="任务到达时间" align="center">
          <template slot-scope="scope">
            {{scope.row.createAt | formatDate('yyyy-MM-dd hh:mm:ss')}}
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" fixed="right">
          <template slot-scope="scope">
            <a class="btn-blue" v-if="scope.row.editable && permission.homeVisits_edit" @click="toCompactFun(scope.row)">办理</a>
            <a class="btn-blue" v-else @click="toCompactFun(scope.row)">查看</a>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 数据表格 end -->

    <!-- 分页 begin -->
    <el-pagination
    @size-change="handleSizeChange"
    @current-change="handleCurrentChange"
    :current-page="page.currentPage"
    :page-sizes="page.pageSizesArr"
    :page-size="page.pageSize"
    :total="page.total"
    layout="total, sizes, prev, pager, next, jumper" >
    </el-pagination>
    <!-- 分页 end -->

    <!-- 上门地址数量弹框 begin -->
    <AddressesDdialog :addressesDialog='dialogFlag' :addressesList='dialogData' @listenDialogFun='listenDialogFun'></AddressesDdialog>
    <!-- 上门地址数量弹框 end -->
  </div>
</template>

<!--
  注：表格操作栏状态判断如下
 资产专员和资产总监无法看到这这个页面，管理员只能查看，供应商再根据接口返回的字段结合进行判断是查看还是办理
-->
<script>
import { mapState } from 'vuex'
import AddressesDdialog from '../../../components/addressesDdialog'
export default {
  components: {
    AddressesDdialog
  },
  data () {
    return {
      loading: true,
      dialogFlag: false, // 上门地址数量弹框
      dataTable: [], // 列表Table数据
      dialogData: [], // 弹框数据
      // 筛选条件
      queryform: {
        acceptStatus: null, // 是否受理,1：是，2：否
        applyId: null, // 申请编号
        customerName: null, // 客户姓名
        pageNum: 1, // 页码
        pageSize: 20 // 每页大小
      },
      // 分页
      page: {
        total: 0,
        pageSizesArr: [10, 20, 30, 40],
        currentPage: 1, // 当前页
        pageSize: 20 // 每页条数
      },
      // 是否已派单、是否改派、是否撤销、是否受理等字典
      trueFalseDictionary: {
        0: '否',
        1: '是'
      }
    }
  },
  computed: {
    ...mapState(['maxTableHeight', 'permission'])
  },
  created () {
    let history = window.sessionStorage
    this.queryform.pageNum = this.page.currentPage = parseInt(history.getItem('pageIndex')) || 1
  },
  mounted () {
    this.getListFun()
  },
  methods: {
    // 监听弹框显示和隐藏
    listenDialogFun () {
      this.dialogFlag = false
    },
    // 重置
    queryResetFun () {
      this.queryform = {
        acceptStatus: null,
        applyId: null,
        customerName: null,
        pageNum: 1,
        pageSize: 20
      }
      this.page.currentPage = 1
      this.page.pageSize = 20
      this.getListFun()
    },
    // 获取列表Table数据
    async getListFun () {
      try {
        this.loading = true
        let res = await this.$api.acceptOrderList(this.queryform)
        this.dataTable = res.list
        this.page.total = res.total
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 查看或办理跳转
    toCompactFun (row) {
      let detailFlag = !!(row.editable && this.permission.homeVisits_edit)
      const { id } = row
      this.$router.push({
        path: '/home/homeVisitsDetail', query: { id, detailFlag }
      })
    },
    // 弹框里的数据
    DialogDataFun (data) {
      this.dialogFlag = true
      this.dialogData = data
    },
    // 分页操作
    handleSizeChange (val) {
      this.page.pageSize = val
      this.queryform.pageSize = val
      this.getListFun()
    },
    handleCurrentChange (val) {
      this.queryform.pageNum = val
      this.page.currentPage = val
      window.sessionStorage.setItem('pageIndex', val)
      this.getListFun()
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
