<template>
  <div class="main-con">

    <!-- 基本信息 begin -->
    <EssentialInfor :basicInfo='basicInfo' :loading='loading'></EssentialInfor>
    <!-- 基本信息 end -->

    <div class="modular-box">
      <div class="modular-box-form">
        <el-form :model="businessInfo" :inline="true" size="small" label-position="top">
          <el-form-item label="家访日期">
            <el-date-picker disabled v-model="businessInfo.timeRange" type="daterange" value-format="yyyy-MM-dd" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>

          <el-form-item label="家访要求">
            <el-input disabled v-model.trim="businessInfo.visitRequirements" type="textarea"></el-input>
          </el-form-item>

          <el-form-item label="其他要求">
            <el-input disabled v-model.trim="businessInfo.otherRequirements" type="textarea"></el-input>
          </el-form-item>

          <el-form-item label="预计费用(元)">
            <el-input disabled v-model.trim="businessInfo.expectFee" placeholder=""></el-input>
          </el-form-item>

        </el-form>
      </div>
    </div>

    <!-- 家访地址要求 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">家访地址要求</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table :show-header=false v-loading="loading" :data="addresses" border style="width: 100%">
            <el-table-column label="序号" type="index" width="80" align="center"></el-table-column>
            <el-table-column prop="provinceAndCity" label="省/城市" align="center"></el-table-column>
            <el-table-column prop="address" label="详细地址" align="center"></el-table-column>
          </el-table>
        </div>
      </div>

      <a class="homeFileLink" :href="downLoadurl" style="margin-bottom:10px; margin-left:10px">《家访报告》下载</a>
    </div>
    <!-- 家访地址要求 end -->

    <!-- 客户电话信息 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">客户电话信息</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading" :data="contacts" border style="width: 100%">
            <el-table-column label="序号" type="index" align="center" width="100"></el-table-column>
            <el-table-column prop="typeDesc" label="电话类型" align="center"></el-table-column>
            <el-table-column prop="customerName" label="客户名称" align="center">
              <template slot-scope="scope">
              {{scope.row.customerName | formatName}}
           </template>
            </el-table-column>
            <el-table-column prop="phone" label="电话号码" align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <!-- 客户电话信息 end -->

    <!-- 家访受理信息 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">家访受理信息</span>
      </div>

      <div class="modular-box-form">
        <el-form :inline="true" size="small" label-position="top">
          <el-form-item label="预计上门时间">
            <el-date-picker v-model="visitsDetail.estimateArriveDate" value-format="yyyy-MM-dd" type="date" placeholder="选择日期"></el-date-picker>
          </el-form-item>

          <el-form-item label="家访人员">
            <el-input v-model.trim="visitsDetail.visitUser" placeholder=""></el-input>
          </el-form-item>

          <el-form-item label="家访人电话">
            <el-input maxlength="11" v-model.trim="visitsDetail.visitUserPhone" placeholder=""></el-input>
          </el-form-item>

          <el-form-item label="预计登记时间">
            <el-date-picker v-model="visitsDetail.estimateRegisterDate" value-format="yyyy-MM-dd" type="date" placeholder="选择日期"></el-date-picker>
          </el-form-item>

          <el-form-item label="出发省份">
            <el-select v-model="visitsDetail.fromProvinceId" @change="forDeparture" placeholder="请选择">
              <el-option v-for="item in provinces" :key="item.currentKey" :label="item.cityName" :value="item.currentKey"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="出发城市">
            <el-select v-model="visitsDetail.fromCityId" placeholder="请选择">
              <el-option v-for="item in departureCity" :key="item.currentKey" :label="item.cityName" :value="item.cityName"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="家访省份">
            <el-select v-model="visitsDetail.visitProvinceId"  @change="visitsDeparture" placeholder="请选择">
              <el-option v-for="item in provinces" :key="item.currentKey" :label="item.cityName" :value="item.currentKey"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="家访城市">
            <el-select v-model="visitsDetail.visitCityId" placeholder="请选择">
              <el-option v-for="item in visitingCity" :key="item.currentKey" :label="item.cityName" :value="item.cityName"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="预计里程(km)">
            <el-input v-model="visitsDetail.estimateDistance" placeholder=""></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 家访受理信息 end -->

    <div class="submit-btn">
      <el-button v-if="detailFlag" @click="acceptanceFun()" type="primary">受 理</el-button>
      <el-button v-if="detailFlag" @click="acceptanceRefuseFun()">拒 绝</el-button>
      <el-button @click="pageBack()">返 回</el-button>
    </div>

  </div>
</template>

<script>
import apiHost from '../../../config/apiHost'
import EssentialInfor from '../../../components/essentialInfor'
import { amount } from '../../../filters/index.js'

export default {
  components: {
    EssentialInfor
  },
  data () {
    return {
      downLoadurl: null, // 下载地址
      loading: true,
      detailFlag: false, // 是否可编辑Flag
      basicInfo: {}, // 基本信息
      processRecords: [], // 处理记录
      contacts: [], // 客户电话信息
      getDict: [], // 家访公司选择下拉菜单
      addresses: [], // 家访地址要求
      businessInfo: {}, // 家访派单详情
      provinces: [], // 城市/省份列表
      departureCity: [], // 出发城市
      visitingCity: [], // 家访城市
      // 家访受理信息
      visitsDetail: {
        estimateArriveDate: null, // 预计上门时间
        estimateDistance: null, // 预计里程
        estimateRegisterDate: null, // 预计登记时间
        fromCityId: null, // 出发城市
        fromProvinceId: null, // 出发省份
        id: null, // 记录ID
        visitCityId: null, // 家访城市
        visitProvinceId: null, // 家访省份
        visitUser: null, // 家访人员
        visitUserPhone: null // 家访人电话
      }
    }
  },
  mounted () {
    if (this.$route.query.detailFlag.toString() === 'true') {
      this.detailFlag = true
    }
    this.downLoadurl = `${apiHost.basePath}/file/downloadRegisterFile`
    this.visitsDetail.id = this.$route.query.id
    this.getCityFun()
    this.getDetailFun()
  },
  methods: {
    // 获取详情信息
    async getDetailFun () {
      try {
        let res = await this.$api.acceptOrderGetInfo({
          acceptOrderId: this.$route.query.id
        })
        this.basicInfo = res.basicInfo
        this.processRecords = res.processRecords
        this.contacts = res.contacts
        this.addresses = res.addresses
        const businessInfo = res.businessInfo
        const { visitStartTime, visitEndTime, expectFee } = businessInfo
        this.businessInfo = {
          ...businessInfo,
          timeRange: visitStartTime && visitEndTime ? [visitStartTime, visitEndTime] : [],
          expectFee: amount(expectFee)
        }
        this.visitsDetail = {
          ...businessInfo
        }
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 获取城市列表
    async getCityFun () {
      let res = await this.$api.getCityList()
      this.provinces = res.provinces
    },
    // 出发城市
    forDeparture (value) {
      this.provinces.forEach(element => {
        if (element.currentKey === value) {
          this.departureCity = element.cityList
        }
      })
    },
    // 家访城市
    visitsDeparture (value) {
      this.provinces.forEach(element => {
        if (element.currentKey === value) {
          this.visitingCity = element.cityList
        }
      })
    },
    // 受理
    async acceptanceFun () {
      let res = await this.$api.acceptance(this.visitsDetail)
      this.pageBack()
      console.log(res)
    },
    // 拒绝
    async acceptanceRefuseFun () {
      let res = await this.$api.acceptanceRefuse({
        acceptOrderId: this.$route.query.id
      })
      this.pageBack()
      console.log(res)
    },
    // 返回上一页
    pageBack () {
      window.history.back('-1')
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
