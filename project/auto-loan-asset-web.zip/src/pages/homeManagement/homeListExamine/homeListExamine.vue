<template>
  <div class="main-con">
    <!-- 筛选 begin -->
    <div class="query-box">
      <el-form :inline="true" class="demo-form-inline" size="small">
        <el-form-item label="申请编号">
          <el-input v-model.trim="queryform.applyId" placeholder=""></el-input>
        </el-form-item>
        <el-form-item label="客户姓名">
          <el-input v-model.trim="queryform.customerName" placeholder=""></el-input>
        </el-form-item>
        <el-form-item label="派单人员">
          <el-input v-model.trim="queryform.sendOrderUsername" placeholder=""></el-input>
        </el-form-item>
        <el-form-item label="审核状态">
          <el-select v-model="queryform.auditStatus" placeholder="请选择">
            <el-option v-for="(item, index) in auditStatusDictionary" :key="index" :label="item" :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="是否改派">
          <el-select v-model="queryform.exchange" placeholder="请选择">
            <el-option v-for="(item, index) in trueFalseDictionary" :key="index" :label="item" :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="getListFun()">查询</el-button>
          <el-button @click="queryResetFun()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 筛选 end -->

    <!-- 数据表格 begin -->
    <div class="tableMod">
      <el-button v-if="permission.homeListExamine_edit" @click="batchAuditFun()" style="margin-bottom:10px" type="primary" size="small">批量审核</el-button>
      <el-table v-loading="loading" @selection-change="handleSelectionChange" :data="dataTable" border style="width: 100%" :max-height="maxTableHeight">
        <el-table-column v-if="permission.homeListExamine_edit" type="selection" width="55"></el-table-column>
        <el-table-column label="序号" type="index" width="80" align="center"></el-table-column>
        <el-table-column prop="uid" label="UID" align="center"></el-table-column>
        <el-table-column prop="customerName" label="客户姓名" align="center">
          <template slot-scope="scope">
              {{scope.row.customerName | formatName}}
           </template>
        </el-table-column>
        <el-table-column prop="sendOrderUsername" label="派单人员" align="center"></el-table-column>
        <el-table-column label="处理申请日期" align="center">
          <template slot-scope="scope">
            {{scope.row.overdueInfoCreateTime | formatDate('yyyy-MM-dd')}}
          </template>
        </el-table-column>
        <el-table-column label="家访要求" align="center"  width="200">
          <template slot-scope="scope">
            {{scope.row.visitRequirements || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="上门地址数量" align="center">
          <template slot-scope="scope">
            <a v-if="scope.row.addressCount" href="javascript:" class="btn-blue" @click="DialogDataFun(scope.row.addresses)">{{scope.row.addressCount}}</a>
            <span v-else>/</span>
          </template>
        </el-table-column>
        <el-table-column label="供应商" align="center">
          <template slot-scope="scope">
            {{scope.row.supplierName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="欠款金额(元)" align="center">
          <template slot-scope="scope">
            {{scope.row.overdueAmount | amount}}
          </template>
        </el-table-column>
        <el-table-column prop="overdueDay" label="逾期天数(天)" align="center"></el-table-column>
        <el-table-column label="派单日期" align="center">
          <template slot-scope="scope">
            {{scope.row.sendOrderDate | formatDate('yyyy-MM-dd')}}
          </template>
        </el-table-column>
        <el-table-column label="是否改派" align="center">
          <template slot-scope="scope">
            {{scope.row.exchange || '/'}}
          </template>
        </el-table-column>
        <el-table-column prop="sendOrderAuditResult" label="派单审核状态" align="center"></el-table-column>
        <el-table-column prop="businessType" label="任务类型" align="center"></el-table-column>
        <el-table-column label="任务到达时间" align="center">
          <template slot-scope="scope">
            {{scope.row.createAt | formatDate('yyyy-MM-dd hh:mm:ss')}}
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" fixed="right" width="70">
          <template slot-scope="scope">
             <a class="btn-blue" v-if="scope.row.sendOrderAuditResult !== '通过' && permission.homeListExamine_edit" @click="toCompactFun(scope.row)">办理</a>
             <a class="btn-blue"  v-else @click="toCompactFun(scope.row)">查看</a>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 数据表格 end -->

    <!-- 分页 begin -->
    <el-pagination
    @size-change="handleSizeChange"
    @current-change="handleCurrentChange"
    :current-page="page.currentPage"
    :page-sizes="page.pageSizesArr"
    :page-size="page.pageSize"
    :total="page.total"
    layout="total, sizes, prev, pager, next, jumper" >
    </el-pagination>
    <!-- 分页 end -->

    <!-- 上门地址数量弹框 begin -->
    <AddressesDdialog :addressesDialog='dialogFlag' :addressesList='dialogData' @listenDialogFun='listenDialogFun'></AddressesDdialog>
    <!-- 上门地址数量弹框 end -->

    <!-- 批量审核弹框 begin -->
    <el-dialog title="批量审核" :visible.sync="batchAuditDialogFlag" @closed="closeDiloagFun()" :modal-append-to-body="false">
      <div class="modular-box-form" style="margin-top:0;">
        <el-form :model="batchAudit" :rules="rules" ref="batchAudit" :inline="true" size="small" label-position="top">
          <el-form-item prop="auditStatus" label="审核结果选择">
            <el-select v-model="batchAudit.auditStatus" placeholder="请选择">
              <el-option label="审核通过" value="1"></el-option>
              <el-option label="审核退回" value="2"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item prop="reason" label="审核备注">
            <el-input v-model.trim="batchAudit.reason" type="textarea"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="batchAuditDialogFlag = false">取 消</el-button>
        <el-button type="primary" @click="batchAuditValidateFun()">提 交</el-button>
      </div>
    </el-dialog>
    <!-- 批量审核弹框 end -->
  </div>
</template>

<!--
  注：表格操作栏状态判断如下
  1.办理：如果editable字段为true，并且角色是资产总监，
  2.查看：角色是资产专员
-->
<script>
import { mapState } from 'vuex'
import AddressesDdialog from '../../../components/addressesDdialog'
export default {
  components: {
    AddressesDdialog
  },
  data () {
    return {
      auditStatusMap: {
        1: '审核通过',
        2: '审核退回'
      },
      loading: true,
      batchAuditDialogFlag: false, // 批量审核弹框
      dialogFlag: false, // 上门地址数量弹框
      dataTable: [], // 列表数据
      dialogData: [], // 弹框数据
      selectBatchData: [],
      // 批量审核数据
      batchAudit: {
        auditStatus: null,
        ids: [],
        reason: null
      },
      // 筛选条件
      queryform: {
        applyId: '', // 申请编号
        auditStatus: '', // 审核状态
        customerName: '', // 客户姓名
        exchange: '', // 是否改派
        pageNum: 1, // 页码
        pageSize: 20, // 每页大小
        sendOrderUsername: '' // 派单人员
      },
      // 分页
      page: {
        total: 0,
        pageSizesArr: [10, 20, 30, 40],
        currentPage: 1, // 当前页
        pageSize: 20 // 每页条数
      },
      rules: {
        auditStatus: [{ required: true, trigger: 'change', message: '请选择审核结果' }],
        reason: [{ required: true, trigger: 'blur', message: '请填写审核备注' }]
      },
      // 是否已派单、是否改派、是否撤销、是否受理等字典
      trueFalseDictionary: {
        0: '否',
        1: '是'
      },
      // 派单审核结果字典
      auditStatusDictionary: {
        0: '待审核',
        1: '审核通过',
        2: '审核退回'
      }
    }
  },
  computed: {
    ...mapState(['maxTableHeight', 'permission'])
  },
  created () {
    let history = window.sessionStorage
    this.queryform.pageNum = this.page.currentPage = parseInt(history.getItem('pageIndex')) || 1
  },
  mounted () {
    this.getUrlQuery()
    this.getListFun()
  },
  methods: {
    // 获取url上的参数
    getUrlQuery () {
      this.queryform.auditStatus = this.$route.query.auditStatus || null
      this.queryform.sendOrderUsername = this.$route.query.sendOrderUsername || null
    },
    // 监听弹框显示和隐藏
    listenDialogFun () {
      this.dialogFlag = false
    },
    // 批量审核
    batchAuditFun () {
      if (this.selectBatchData.length) {
        this.selectBatchData.forEach(element => {
          this.batchAudit.ids.push(element.id)
          this.batchAuditDialogFlag = true
        })
      }
    },
    handleSelectionChange (val) {
      this.selectBatchData = []
      this.selectBatchData = val
    },
    // 批量审核提交校验
    batchAuditValidateFun () {
      this.$refs['batchAudit'].validate((valid) => {
        if (valid) {
          console.log(this.batchAudit)
          // this.batchAuditSubmitFun()
        }
      })
    },
    // 批量审核提交
    async batchAuditSubmitFun () {
      let res = await this.$api.batchAudit(this.batchAudit)
      if (res) {
        this.$message.success('提交成功')
        this.pageBack()
      } else {
        this.$message.error('提交失败')
      }
    },
    // 重置
    queryResetFun () {
      this.queryform = {
        applyId: '',
        auditStatus: '',
        customerName: '',
        exchange: '',
        pageNum: 1,
        pageSize: 20,
        sendOrderUsername: ''
      }
      this.page.currentPage = 1
      this.page.pageSize = 20
      this.getListFun()
    },
    // 获取列表Table数据
    async getListFun () {
      try {
        this.loading = true
        let res = await this.$api.getListExamine(this.queryform)
        // res.list = [
        //   { 'addressCount': 3, 'addresses': [{ 'address': '西藏自治区华市华龙沈路s座', 'choose': 1, 'id': 1120, 'provinceAndCity': '上海市/上海辖区', 'type': 1 }, { 'address': '西藏自治区华市华龙沈路s座', 'choose': 1, 'id': 1121, 'provinceAndCity': '上海市/上海辖区', 'type': 0 }, { 'address': '环科路555弄', 'choose': 1, 'id': 1122, 'provinceAndCity': '上海市/上海辖区', 'type': 2 }], 'businessType': '家访派单审核', 'createAt': 1563271115000, 'customerName': '卢玉兰', 'editable': false, 'exchange': '否', 'id': 368, 'overdueAmount': '0.0000', 'overdueDay': '0', 'overdueInfoCreateTime': 1563271034000, 'sendOrderAuditResult': '通过', 'sendOrderDate': '2019-07-16', 'sendOrderUsername': 'panzm-zczy', 'supplierName': '2345测试', 'uid': '100026043', 'visitRequirements': '1、核实地址信息、欠款人信息\n2、了解逾期原因\n3、核实车辆近况\n4、更新并验证主贷人或直系亲属联系方式\n5、递送或粘贴律师函\n6、每地址拍摄不少于7张照片\n7、索要村委电话' },
        //   { 'addressCount': 3, 'addresses': [{ 'address': '西藏自治区华市华龙沈路s座', 'choose': 1, 'id': 1120, 'provinceAndCity': '上海市/上海辖区', 'type': 1 }, { 'address': '西藏自治区华市华龙沈路s座', 'choose': 1, 'id': 1121, 'provinceAndCity': '上海市/上海辖区', 'type': 0 }, { 'address': '环科路555弄', 'choose': 1, 'id': 1122, 'provinceAndCity': '上海市/上海辖区', 'type': 2 }], 'businessType': '家访派单审核', 'createAt': 1563271115000, 'customerName': '卢玉兰', 'editable': false, 'exchange': '否', 'id': 368, 'overdueAmount': '0.0000', 'overdueDay': '0', 'overdueInfoCreateTime': 1563271034000, 'sendOrderAuditResult': '通过', 'sendOrderDate': '2019-07-16', 'sendOrderUsername': 'panzm-zczy', 'supplierName': '2345测试', 'uid': '100026043', 'visitRequirements': '1、核实地址信息、欠款人信息\n2、了解逾期原因\n3、核实车辆近况\n4、更新并验证主贷人或直系亲属联系方式\n5、递送或粘贴律师函\n6、每地址拍摄不少于7张照片\n7、索要村委电话' },
        //   { 'addressCount': 3, 'addresses': [{ 'address': '西藏自治区华市华龙沈路s座', 'choose': 1, 'id': 1120, 'provinceAndCity': '上海市/上海辖区', 'type': 1 }, { 'address': '西藏自治区华市华龙沈路s座', 'choose': 1, 'id': 1121, 'provinceAndCity': '上海市/上海辖区', 'type': 0 }, { 'address': '环科路555弄', 'choose': 1, 'id': 1122, 'provinceAndCity': '上海市/上海辖区', 'type': 2 }], 'businessType': '家访派单审核', 'createAt': 1563271115000, 'customerName': '卢玉兰', 'editable': false, 'exchange': '否', 'id': 368, 'overdueAmount': '0.0000', 'overdueDay': '0', 'overdueInfoCreateTime': 1563271034000, 'sendOrderAuditResult': '通过', 'sendOrderDate': '2019-07-16', 'sendOrderUsername': 'panzm-zczy', 'supplierName': '2345测试', 'uid': '100026043', 'visitRequirements': '1、核实地址信息、欠款人信息\n2、了解逾期原因\n3、核实车辆近况\n4、更新并验证主贷人或直系亲属联系方式\n5、递送或粘贴律师函\n6、每地址拍摄不少于7张照片\n7、索要村委电话' },
        //   { 'addressCount': 3, 'addresses': [{ 'address': '西藏自治区华市华龙沈路s座', 'choose': 1, 'id': 1120, 'provinceAndCity': '上海市/上海辖区', 'type': 1 }, { 'address': '西藏自治区华市华龙沈路s座', 'choose': 1, 'id': 1121, 'provinceAndCity': '上海市/上海辖区', 'type': 0 }, { 'address': '环科路555弄', 'choose': 1, 'id': 1122, 'provinceAndCity': '上海市/上海辖区', 'type': 2 }], 'businessType': '家访派单审核', 'createAt': 1563271115000, 'customerName': '卢玉兰', 'editable': false, 'exchange': '否', 'id': 368, 'overdueAmount': '0.0000', 'overdueDay': '0', 'overdueInfoCreateTime': 1563271034000, 'sendOrderAuditResult': '通过', 'sendOrderDate': '2019-07-16', 'sendOrderUsername': 'panzm-zczy', 'supplierName': '2345测试', 'uid': '100026043', 'visitRequirements': '1、核实地址信息、欠款人信息\n2、了解逾期原因\n3、核实车辆近况\n4、更新并验证主贷人或直系亲属联系方式\n5、递送或粘贴律师函\n6、每地址拍摄不少于7张照片\n7、索要村委电话' },
        //   { 'addressCount': 3, 'addresses': [{ 'address': '西藏自治区华市华龙沈路s座', 'choose': 1, 'id': 1120, 'provinceAndCity': '上海市/上海辖区', 'type': 1 }, { 'address': '西藏自治区华市华龙沈路s座', 'choose': 1, 'id': 1121, 'provinceAndCity': '上海市/上海辖区', 'type': 0 }, { 'address': '环科路555弄', 'choose': 1, 'id': 1122, 'provinceAndCity': '上海市/上海辖区', 'type': 2 }], 'businessType': '家访派单审核', 'createAt': 1563271115000, 'customerName': '卢玉兰', 'editable': false, 'exchange': '否', 'id': 368, 'overdueAmount': '0.0000', 'overdueDay': '0', 'overdueInfoCreateTime': 1563271034000, 'sendOrderAuditResult': '通过', 'sendOrderDate': '2019-07-16', 'sendOrderUsername': 'panzm-zczy', 'supplierName': '2345测试', 'uid': '100026043', 'visitRequirements': '1、核实地址信息、欠款人信息\n2、了解逾期原因\n3、核实车辆近况\n4、更新并验证主贷人或直系亲属联系方式\n5、递送或粘贴律师函\n6、每地址拍摄不少于7张照片\n7、索要村委电话' },
        //   { 'addressCount': 3, 'addresses': [{ 'address': '西藏自治区华市华龙沈路s座', 'choose': 1, 'id': 1120, 'provinceAndCity': '上海市/上海辖区', 'type': 1 }, { 'address': '西藏自治区华市华龙沈路s座', 'choose': 1, 'id': 1121, 'provinceAndCity': '上海市/上海辖区', 'type': 0 }, { 'address': '环科路555弄', 'choose': 1, 'id': 1122, 'provinceAndCity': '上海市/上海辖区', 'type': 2 }], 'businessType': '家访派单审核', 'createAt': 1563271115000, 'customerName': '卢玉兰', 'editable': false, 'exchange': '否', 'id': 368, 'overdueAmount': '0.0000', 'overdueDay': '0', 'overdueInfoCreateTime': 1563271034000, 'sendOrderAuditResult': '通过', 'sendOrderDate': '2019-07-16', 'sendOrderUsername': 'panzm-zczy', 'supplierName': '2345测试', 'uid': '100026043', 'visitRequirements': '1、核实地址信息、欠款人信息\n2、了解逾期原因\n3、核实车辆近况\n4、更新并验证主贷人或直系亲属联系方式\n5、递送或粘贴律师函\n6、每地址拍摄不少于7张照片\n7、索要村委电话' }
        // ]
        this.dataTable = res.list
        this.page.total = res.total
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 查看或办理跳转
    toCompactFun (row) {
      const { id } = row
      let detailFlag = !!(row.editable && this.permission.homeListExamine_edit)
      this.$router.push({
        path: '/home/homeListExamineDetail', query: { id, detailFlag }
      })
    },
    // 弹框里的数据
    DialogDataFun (data) {
      this.dialogFlag = true
      this.dialogData = data
    },
    // 关闭批量审核弹框
    closeDiloagFun () {
      this.batchAudit.auditStatus = null
      this.batchAudit.ids = []
      this.batchAudit.reason = null
    },
    // 分页操作
    handleSizeChange (val) {
      this.page.pageSize = val
      this.queryform.pageSize = val
      this.getListFun()
    },
    handleCurrentChange (val) {
      this.queryform.pageNum = val
      this.page.currentPage = val
      window.sessionStorage.setItem('pageIndex', val)
      this.getListFun()
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
