<template>
  <div class="main-con">

    <!-- 基本信息 begin -->
    <EssentialInfor :basicInfo='basicInfo' :loading='loading'></EssentialInfor>
    <!-- 基本信息 end -->

    <div class="modular-box">
      <div class="modular-box-form">
        <el-form :model="businessInfo" :inline="true" size="small" label-position="top">
          <el-form-item prop="supplierId" label="家访公司选择">
            <el-select disabled v-model="businessInfo.supplierId" placeholder="请选择">
              <el-option v-for="item in getDict" :key="item.key" :label="item.value" :value="item.key"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item prop="timeRange" label="家访日期">
            <el-date-picker disabled v-model="businessInfo.timeRange" type="daterange" value-format="yyyy-MM-dd" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>

          <el-form-item prop="expectFee" label="预计费用(元)">
            <el-input disabled v-model.trim="businessInfo.expectFee" placeholder=""></el-input>
          </el-form-item>

          <el-form-item prop="visitRequirements" label="家访要求">
            <el-input disabled v-model.trim="businessInfo.visitRequirements" type="textarea"></el-input>
          </el-form-item>

          <el-form-item label="是否改派">
            <el-select disabled v-model="businessInfo.isExchange" placeholder="请选择">
              <el-option label="否" value="0"></el-option>
              <el-option label="是" value="1"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="改派原因">
            <el-input disabled v-model.trim="businessInfo.exchangeReason" type="textarea"></el-input>
          </el-form-item>

          <el-form-item label="是否撤销">
            <el-select disabled v-model="businessInfo.isBack" placeholder="请选择">
              <el-option label="否" value="0"></el-option>
              <el-option label="是" value="1"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="撤销原因">
            <el-input disabled v-model.trim="businessInfo.backReason" type="textarea"></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>

    <!-- 家访地址要求 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">家访地址要求</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table :show-header=false v-loading="loading" :data="addresses" border style="width: 100%">
            <el-table-column label="序号" type="index" width="80" align="center"></el-table-column>
            <el-table-column prop="provinceAndCity" label="省/城市" align="center"></el-table-column>
            <el-table-column prop="address" label="详细地址" align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <!-- 家访地址要求 end -->

    <!-- 处理记录 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">处理记录</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading" :data="processRecords" border style="width: 100%">
            <el-table-column type="index" width="60" label="序号" align="center"></el-table-column>
            <el-table-column prop="sendOrderUsername" label="派单人员" align="center"></el-table-column>
            <el-table-column prop="sendOrderDate" label="派单日期" align="center"></el-table-column>
            <el-table-column prop="visitRequirements" label="处理要求" align="center"></el-table-column>
            <el-table-column prop="supplierName" label="派单供应商" align="center"></el-table-column>
            <el-table-column prop="auditResult" label="派单审核结果" align="center"></el-table-column>
            <el-table-column prop="reason" label="备注" align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <!-- 处理记录 end -->

    <!-- 客户电话信息 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">客户电话信息</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading" :data="contacts" border style="width: 100%">
            <el-table-column label="序号" type="index" width="60" align="center"></el-table-column>
            <el-table-column prop="typeDesc" label="电话类型" align="center"></el-table-column>
            <el-table-column prop="customerName" label="客户名称" align="center">
              <template slot-scope="scope">
              {{scope.row.customerName | formatName}}
           </template>
            </el-table-column>
            <el-table-column prop="phone" label="电话号码" align="center"></el-table-column>
          </el-table>
        </div>
      </div>

      <div v-if="detailFlag" class="modular-box-form">
        <el-form :model="audit" :rules="rules" ref="audit" :inline="true" size="small" label-position="top">
          <el-form-item prop="auditStatus" label="审核结果选择">
            <el-select v-model="audit.auditStatus" placeholder="请选择">
              <el-option label="审核通过" value="1"></el-option>
              <el-option label="审核退回" value="2"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item prop="reason" label="审核备注">
            <el-input v-model.trim="audit.reason" maxlength=100 type="textarea"></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 客户电话信息 end -->

    <div class="submit-btn">
      <el-button v-if="detailFlag" :plain="true" @click="submitValidateFun()" type="primary">提 交</el-button>
      <el-button @click="pageBack()">返 回</el-button>
    </div>

  </div>
</template>

<script>
import EssentialInfor from '../../../components/essentialInfor'
import { amount } from '../../../filters/index.js'

export default {
  components: {
    EssentialInfor
  },
  data () {
    return {
      auditStatusMap: {
        1: '审核通过',
        2: '审核退回'
      },
      loading: true,
      detailFlag: false, // 是否可编辑Flag
      basicInfo: {}, // 基本信息
      processRecords: [], // 处理记录
      contacts: [], // 客户电话信息
      getDict: [], // 家访公司选择下拉菜单
      businessInfo: {}, // 家访派单详情
      addresses: [], // 家访地址要求
      // 提交审核
      audit: {
        auditStatus: '',
        reason: '',
        id: ''
      },
      rules: {
        auditStatus: [{ required: true, trigger: 'change', message: '请选择审核结果' }],
        reason: [{ required: true, trigger: 'blur', message: '请填写审核备注' }]
      }
    }
  },
  mounted () {
    if (this.$route.query.detailFlag.toString() === 'true') {
      this.detailFlag = true
    }
    this.audit.id = this.$route.query.id
    this.getDictFun()
    this.getDetailFun()
  },
  methods: {
    // 获取详情信息
    async getDetailFun () {
      try {
        let res = await this.$api.getInfo({
          sendOrderId: this.$route.query.id
        })
        this.basicInfo = res.basicInfo
        this.processRecords = res.processRecords
        this.contacts = res.contacts
        this.addresses = res.addresses
        const businessInfo = res.businessInfo
        const { visitStartTime, visitEndTime, isExchange, isBack, expectFee, supplierId } = businessInfo
        this.businessInfo = {
          ...businessInfo,
          timeRange: visitStartTime && visitEndTime ? [visitStartTime, visitEndTime] : [],
          isExchange: isExchange.toString(),
          isBack: isBack.toString(),
          supplierId: supplierId === 0 ? null : supplierId.toString(),
          expectFee: amount(expectFee)
        }
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 提交校验
    submitValidateFun () {
      this.$refs['audit'].validate(async (valid) => {
        if (valid) {
          try {
            let str = '确认' + this.auditStatusMap[this.audit.auditStatus] + '+' + this.audit.reason + '?'
            let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '确定' })
            if (confirm) {
              this.submitFun()
            }
          } catch (error) {

          }
        }
      })
    },
    // 提交
    async submitFun () {
      let res = await this.$api.sendOrderAudit(this.audit)
      if (res) {
        this.$message.success('提交成功')
        this.pageBack()
      } else {
        this.$message.error('提交失败')
      }
    },
    // 获取家访公司列表
    async getDictFun () {
      let res = await this.$api.getSendOrderAuditDict()
      this.getDict = res.supplierList
    },
    // 返回上一页
    pageBack () {
      window.history.back('-1')
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
