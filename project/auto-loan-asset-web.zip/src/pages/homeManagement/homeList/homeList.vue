<template>
  <div class="main-con">
    <!-- 筛选 begin -->
    <div class="query-box">
      <el-form :inline="true" class="demo-form-inline" size="small">
        <el-form-item label="UID">
          <el-input v-model.trim="queryform.uid" placeholder=""></el-input>
        </el-form-item>
        <el-form-item label="客户姓名">
          <el-input v-model.trim="queryform.customerName" placeholder=""></el-input>
        </el-form-item>
        <el-form-item label="派单人员">
          <el-input v-model.trim="queryform.sendOrderUsername" placeholder=""></el-input>
        </el-form-item>
        <el-form-item label="是否已派单">
          <el-select v-model="queryform.sendOrder" placeholder="请选择">
            <el-option v-for="(item, index) in trueFalseDictionary" :key="index" :label="item" :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="派单审核结果">
          <el-select v-model="queryform.auditStatus" placeholder="请选择">
            <el-option v-for="(item, index) in auditStatusDictionary" :key="index" :label="item" :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="是否改派">
          <el-select v-model="queryform.exchange" placeholder="请选择">
            <el-option v-for="(item, index) in trueFalseDictionary" :key="index" :label="item" :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="是否撤销">
          <el-select v-model="queryform.revoke" placeholder="请选择">
            <el-option v-for="(item, index) in trueFalseDictionary" :key="index" :label="item" :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="是否受理">
          <el-select v-model="queryform.accept" placeholder="请选择">
            <el-option v-for="(item, index) in trueFalseDictionary" :key="index" :label="item" :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="getListFun()">查询</el-button>
          <el-button @click="queryResetFun()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 筛选 end -->

    <!-- 数据表格 begin -->
    <div class="modular-box">
      <el-table v-loading="loading" :data="dataTable" border style="width: 100%" :max-height="maxTableHeight">
        <el-table-column label="序号" type="index" width="80" align="center"></el-table-column>
        <el-table-column prop="uid" label="UID" align="center"></el-table-column>
        <el-table-column prop="customerName" label="客户姓名" align="center">
          <template slot-scope="scope">
              {{scope.row.customerName | formatName}}
           </template>
        </el-table-column>
        <el-table-column prop="sendOrderUsername" label="派单人员" align="center"></el-table-column>
        <el-table-column label="处理申请日期" align="center" width="100">
           <template slot-scope="scope">
            {{scope.row.overdueInfoCreateTime | formatDate('yyyy-MM-dd')}}
          </template>
        </el-table-column>
        <el-table-column label="家访要求" align="center"  width="200">
          <template slot-scope="scope">
            {{scope.row.visitRequirements || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="上门地址数量" align="center">
          <template slot-scope="scope">
            <a v-if="scope.row.addressCount" href="javascript:" class="btn-blue" @click="DialogDataFun(scope.row.addresses)">{{scope.row.addressCount}}</a>
            <span v-else>/</span>
          </template>
        </el-table-column>
        <el-table-column label="供应商" align="center">
          <template slot-scope="scope">
            {{scope.row.supplierName || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="欠款金额(元)" align="center">
          <template slot-scope="scope">
            {{scope.row.overdueAmount | amount}}
          </template>
        </el-table-column>
        <el-table-column prop="overdueDay" label="逾期天数(天)" align="center"></el-table-column>
        <el-table-column prop="sendOrder" label="是否派单" align="center"></el-table-column>
        <el-table-column label="派单审核结果" align="center">
          <template slot-scope="scope">
            {{scope.row.sendOrderAuditResult || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="派单日期" align="center">
          <template slot-scope="scope">
            {{scope.row.overdueInfoCreateTime | formatDate('yyyy-MM-dd')}}
          </template>
        </el-table-column>
        <el-table-column label="是否改派" align="center">
          <template slot-scope="scope">
            {{scope.row.exchange || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="是否撤销" align="center">
          <template slot-scope="scope">
            {{scope.row.back || '/'}}
          </template>
        </el-table-column>
        <el-table-column label="是否受理" align="center">
          <template slot-scope="scope">
            {{scope.row.accept || '/'}}
          </template>
        </el-table-column>
        <el-table-column prop="businessType" label="任务类型" align="center"></el-table-column>
        <el-table-column label="任务到达时间" align="center">
          <template slot-scope="scope">
            {{scope.row.createAt | formatDate('yyyy-MM-dd hh:mm:ss')}}
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" fixed="right" width="70">
          <template slot-scope="scope">
            <a class="btn-blue" v-if="permission.homeList_edit && scope.row.editable" @click="toCompactFun(scope.row)">办理</a>
            <a class="btn-blue" v-else @click="toCompactFun(scope.row)">查看</a>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 数据表格 end -->

    <!-- 分页 begin -->
    <el-pagination
    @size-change="handleSizeChange"
    @current-change="handleCurrentChange"
    :current-page="page.currentPage"
    :page-sizes="page.pageSizesArr"
    :page-size="page.pageSize"
    :total="page.total"
    layout="total, sizes, prev, pager, next, jumper">
    </el-pagination>
    <!-- 分页 end -->

    <!-- 上门地址数量弹框 begin -->
    <AddressesDdialog :addressesDialog='dialogFlag' :addressesList='dialogData' @listenDialogFun='listenDialogFun'></AddressesDdialog>
    <!-- 上门地址数量弹框 end -->
  </div>
</template>

<!--
  注：表格操作栏状态判断如下
  1.办理：如果editable字段为true，并且角色是资产专员，
  2.查看：角色是资产总监
-->
<script>
import { mapState } from 'vuex'
import AddressesDdialog from '../../../components/addressesDdialog'
export default {
  components: {
    AddressesDdialog
  },
  data () {
    return {
      loading: true,
      dialogFlag: false, // 上门地址数量弹框
      dataTable: [], // 列表Table数据
      dialogData: [], // 弹框数据
      // 筛选条件
      queryform: {
        accept: null, // 是否受理
        applyId: null, // 申请编号
        auditStatus: null, // 审核状态
        customerName: null, // 客户姓名
        exchange: null, // 是否改派
        pageNum: 1, // 页码
        pageSize: 20, // 每页大小
        revoke: null, // 是否撤销
        sendOrder: null, // 是否已派单
        sendOrderUsername: null, // 派单人员
        uid: null
      },
      // 分页
      page: {
        total: 0,
        pageSizesArr: [10, 20, 30, 40],
        currentPage: 1, // 当前页
        pageSize: 20 // 每页条数
      },
      // 是否已派单、是否改派、是否撤销、是否受理等字典
      trueFalseDictionary: {
        0: '否',
        1: '是'
      },
      // 派单审核结果字典
      auditStatusDictionary: {
        0: '待审核',
        1: '审核通过',
        2: '审核退回'
      }
    }
  },
  computed: {
    ...mapState(['maxTableHeight', 'permission'])
  },
  created () {
    let history = window.sessionStorage
    this.queryform.pageNum = this.page.currentPage = parseInt(history.getItem('pageIndex')) || 1
  },
  mounted () {
    this.getUrlQuery()
    this.getListFun()
  },
  methods: {
    // 监听弹框显示和隐藏
    listenDialogFun () {
      this.dialogFlag = false
    },
    // 重置
    queryResetFun () {
      this.queryform = {
        accept: null,
        applyId: null,
        auditStatus: null,
        customerName: null,
        exchange: null,
        pageNum: 1,
        pageSize: 20,
        revoke: null,
        sendOrder: null,
        sendOrderUsername: null,
        uid: null
      }
      this.page.currentPage = 1
      this.page.pageSize = 20
      this.getListFun()
    },
    // 获取列表Table数据
    async getListFun () {
      try {
        this.loading = true
        let res = await this.$api.getList(this.queryform)
        this.dataTable = res.list
        this.page.total = res.total
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 获取url上的参数
    getUrlQuery () {
      this.queryform.sendOrder = this.$route.query.sendOrderStatus || null
      this.queryform.auditStatus = this.$route.query.auditStatus || null
      this.queryform.uid = this.$route.query.userId || null
      this.queryform.sendOrderUsername = this.$route.query.userName || null
      this.queryform.revoke = this.$route.query.isBack || null
    },
    // 查看或办理跳转
    toCompactFun (row) {
      const { id } = row
      let detailFlag = !!((row.editable && this.permission.homeList_edit))
      this.$router.push({
        path: '/home/homeListDetail', query: { id, detailFlag }
      })
    },
    // 弹框里的数据
    DialogDataFun (data) {
      this.dialogFlag = true
      this.dialogData = data
    },
    // 分页操作
    handleSizeChange (val) {
      this.page.pageSize = val
      this.queryform.pageSize = val
      this.getListFun()
    },
    handleCurrentChange (val) {
      this.queryform.pageNum = val
      this.page.currentPage = val
      window.sessionStorage.setItem('pageIndex', val)
      this.getListFun()
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
