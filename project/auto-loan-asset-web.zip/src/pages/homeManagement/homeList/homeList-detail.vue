<template>
  <div class="main-con">
    <!-- 基本信息 begin -->
    <EssentialInfor :basicInfo='basicInfo' :loading='loading'></EssentialInfor>
    <!-- 基本信息 end -->

    <div class="modular-box">
      <div class="modular-box-form">
        <el-form :model="result" :rules="rules" ref="audit" :inline="true" size="small" label-position="top">
          <el-form-item prop="supplierId" label="家访公司选择">
            <el-select :disabled="!detailFlag" v-model="result.supplierId" placeholder="请选择">
              <el-option v-for="item in getDict" :key="item.key" :label="item.value" :value="item.key"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item prop="timeRange" label="家访日期">
            <el-date-picker :disabled="!detailFlag" @change="getTimeFun" v-model="result.timeRange" type="daterange" value-format="yyyy-MM-dd" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>

          <el-form-item prop="expectFee" label="预计费用(元)">
            <el-input :disabled="!detailFlag" v-model.trim="result.expectFee" placeholder=""></el-input>
          </el-form-item>

          <el-form-item prop="visitRequirements" label="家访要求">
            <el-input :disabled="!detailFlag" v-model.trim="result.visitRequirements" maxlength=100 type="textarea"></el-input>
          </el-form-item>

          <el-form-item label="是否改派">
            <el-select :disabled="!detailFlag" v-model="result.isExchange" placeholder="请选择">
              <el-option label="否" value="0"></el-option>
              <el-option label="是" value="1"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="改派原因">
            <el-input :disabled="!detailFlag" v-model.trim="result.exchangeReason" maxlength=100 type="textarea"></el-input>
          </el-form-item>

          <el-form-item label="其他要求">
            <el-input :disabled="!detailFlag" v-model.trim="result.otherRequirements" maxlength=100 type="textarea"></el-input>
          </el-form-item>

          <el-form-item label="是否撤销">
            <el-select :disabled="!detailFlag" v-model="result.isBack" placeholder="请选择">
              <el-option label="否" value="0"></el-option>
              <el-option label="是" value="1"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="撤销原因">
            <el-input :disabled="!detailFlag" v-model.trim="result.backReason" maxlength=100 type="textarea"></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>

    <!-- 家访地址要求 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">家访地址要求</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table :show-header="false" v-loading="loading" :data="result.addresses" border style="width: 100%">
            <el-table-column width="55">
              <template slot-scope="scope">
                <el-checkbox :disabled="!detailFlag" v-model="scope.row.choose" :true-label="1" :false-label="0"></el-checkbox>
              </template>
            </el-table-column>
            <el-table-column label="序号" type="index" width="80" align="center"></el-table-column>
            <el-table-column prop="provinceAndCity" label="省/城市" align="center"></el-table-column>
            <el-table-column prop="address" label="详细地址" align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <!-- 家访地址要求 end -->

    <!-- 处理记录 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">处理记录</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading" :data="processRecords" border style="width: 100%">
            <el-table-column label="序号" align="center" type="index" width="50"></el-table-column>
            <el-table-column prop="sendOrderUsername" label="派单人员" align="center"></el-table-column>
            <el-table-column label="派单日期" align="center">
              <template slot-scope="scope">
                {{scope.row.sendOrderDate | formatDate('yyyy-MM-dd')}}
              </template>
            </el-table-column>
            <el-table-column label="处理日期" align="center">
              <template slot-scope="scope">
                {{scope.row.processDate | formatDate('yyyy-MM-dd')}}
              </template>
            </el-table-column>
            <el-table-column prop="visitRequirements" label="处理要求" align="center"></el-table-column>
            <el-table-column prop="supplierName" label="供应商" align="center"></el-table-column>
            <el-table-column prop="auditResult" label="派单审核结果" align="center"></el-table-column>
            <el-table-column prop="reason" label="派单审核备注" align="center"></el-table-column>
            <el-table-column prop="acceptDesc" label="是否受理" align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <!-- 处理记录 end -->

    <!-- 客户电话信息 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">客户电话信息</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading" :data="contacts" border style="width: 100%">
            <el-table-column label="序号" type="index" align="center" width="100"></el-table-column>
            <el-table-column prop="typeDesc" label="电话类型" align="center"></el-table-column>
            <el-table-column prop="customerName" label="客户名称" align="center">
              <template slot-scope="scope">
              {{scope.row.customerName | formatName}}
           </template>
            </el-table-column>
            <el-table-column prop="phone" label="电话号码" align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <!-- 客户电话信息 end -->

    <div class="submit-btn">
      <el-button v-if="detailFlag" @click="submitValidateFun()" type="primary">提 交</el-button>
      <el-button @click="pageBack()">返回</el-button>
    </div>

  </div>
</template>

<script>
import EssentialInfor from '../../../components/essentialInfor'
import { amount, amountOfpoints } from '../../../filters/index.js'

export default {
  components: {
    EssentialInfor
  },
  data () {
    // 金额校验规则
    const temp = /^\d+\.?\d{0,3}$/
    const validAmount = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请填写预计费用'))
      } else if (Number(value) === 0) {
        callback(new Error('预计费用不能为0'))
      } else if (!temp.test(value)) {
        callback(new Error('请输入正确的费用'))
      } else {
        callback()
      }
    }
    return {
      loading: true,
      detailFlag: false, // 是否可编辑Flag
      basicInfo: {}, // 基本信息
      processRecords: [], // 处理记录
      contacts: [], // 客户电话信息
      getDict: [], // 家访公司选择下拉菜单
      // 提交信息
      result: {
        addresses: []
      },
      rules: {
        supplierId: [{ required: true, trigger: 'change', message: '请选择家访公司' }],
        timeRange: [{ required: true, trigger: 'change', message: '请选择家访日期' }],
        expectFee: [
          { required: true, validator: validAmount, trigger: 'blur' }
        ],
        visitRequirements: [{ required: true, trigger: 'blur', message: '请填写家访要求' }]
      }
    }
  },
  mounted () {
    if (this.$route.query.detailFlag.toString() === 'true') {
      this.detailFlag = true
    }
    this.getDictFun()
    this.getDetailFun()
  },
  methods: {
    // 获取详情信息
    async getDetailFun () {
      try {
        let res = await this.$api.getInfo({
          sendOrderId: this.$route.query.id
        })
        this.basicInfo = res.basicInfo
        this.processRecords = res.processRecords
        this.contacts = res.contacts
        const businessInfo = res.businessInfo
        const { visitStartTime, visitEndTime, isExchange, isBack, supplierId, expectFee, visitRequirements } = businessInfo
        this.result = {
          ...businessInfo,
          addresses: this.detailFlag ? res.addresses : res.addresses.filter(item => item.choose === 1),
          timeRange: visitStartTime && visitEndTime ? [visitStartTime, visitEndTime] : [],
          isBack: isBack.toString(),
          isExchange: isExchange.toString(),
          supplierId: supplierId === 0 ? null : supplierId.toString(),
          expectFee: amount(expectFee),
          visitRequirements: visitRequirements !== '' ? visitRequirements : '1、核实地址信息、欠款人信息\n2、了解逾期原因\n3、核实车辆近况\n4、更新并验证主贷人或直系亲属联系方式\n5、递送或粘贴律师函\n6、每地址拍摄不少于7张照片\n7、索要村委电话'
        }
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 获取时间
    getTimeFun (value) {
      this.result.visitStartTime = value[0]
      this.result.visitEndTime = value[1]
    },
    // 提交校验
    submitValidateFun () {
      this.$refs['audit'].validate((valid) => {
        if (valid) {
          this.submitFun()
        }
      })
    },
    // 提交
    async submitFun () {
      this.result.expectFee = amountOfpoints(this.result.expectFee)
      let res = await this.$api.sendOrderSubmit(this.result)
      if (res) {
        this.$message.success('提交成功')
        this.pageBack()
      } else {
        this.$message.error('提交失败')
      }
    },
    // 获取家访公司列表
    async getDictFun () {
      let res = await this.$api.getDict()
      this.getDict = res.supplierList
    },
    // 返回上一页
    pageBack () {
      window.history.back('-1')
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
