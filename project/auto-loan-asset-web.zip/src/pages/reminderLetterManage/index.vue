<template>
  <div>
    <el-form :inline="true"
             size="small">
      <!-- 搜索区 -->
      <header class="header">
        <div>
          <el-form-item label="当前逾期天数≥:">
            <el-input @input="limitNumberIn('overdueDay',$event)"
                      v-model.trim="queryForm.overdueDay"
                      placeholder="请输入当前逾期天数"></el-input>
          </el-form-item>
          <el-form-item label="逾期金额≥:">
            <el-input @input="limitNumberIn('overdueAmount',$event)"
                      v-model.trim="queryForm.overdueAmount"
                      placeholder="请输入逾期金额"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary"
                       icon="el-icon-search"
                       :loading="loading"
                       @click="onQuery">
              {{ loading?'查询中...':'查询' }}
            </el-button>
            <el-button type="info"
                       @click="queryResetForm">
              重置
            </el-button>
          </el-form-item>
        </div>
        <div class="header-r">
          <el-button @click="templetDownload"
                     class="header-r-but"
                     size="small"
                     type="success"
                     icon="el-icon-download">
            模板下载
          </el-button>
          <el-upload action="#"
                     accept=".csv, application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                     :http-request="uploadFile"
                     :show-file-list="false">
            <el-button size="small"
                       type="danger"
                       icon="el-icon-upload2">
              批量导入查询
            </el-button>
          </el-upload>
          <el-button @click="exportFile"
                     class="header-r-but"
                     size="small"
                     type="warning"
                     icon="el-icon-download">
            全部导出
          </el-button>
        </div>
      </header>
    </el-form>
    <!-- 表格区 -->
    <TableCom ref="tableCom"
              :table-columns="tableColumns"
              :loading="loading"
              :table-data="tableData"
              :table-total="tableTotal"
              :table-operate="tableOperate"
              @handleOperate="handleOperate"
              @fetchData="fetchData">
      <template slot="overdueAmount"
                slot-scope="scope">
        {{(scope.row['overdueAmount']) | amount}}
      </template>
    </TableCom>
  </div>
</template>
<script>
export default {
  /* eslint-disable no-undef */
  mixins: [privateMixin],
  data () {
    return {
      queryForm: {
        overdueDay: '', // 逾期天数
        overdueAmount: '' // 逾期金额
      },
      tableColumns: [ // 表头
        { name: '申请编号', key: 'applyId' },
        { name: '姓名', key: 'name' },
        { name: '当前逾期天数', key: 'overdueDay' },
        { name: '逾期金额', key: 'overdueAmount' },
        { name: '户籍地址', key: 'addressHousehold' },
        { name: '居住地址', key: 'residenceAddress' },
        { name: '挂靠公司地址', key: 'companyAddress' },
        { name: '电话号码', key: 'phone' }
      ],
      tableOperate: [ // 操作
        { name: '导出', type: 0, color: 'warning', icon: 'el-icon-download' }
      ]
    }
  },
  methods: {
    // 只能输入数字
    limitNumberIn (key, value) {
      this.queryForm[key] = value.replace(/[^\d]/g, '')
    },
    // 获取表格数据
    fetchData (pagination) {
      this.loading = true
      console.log({ ...pagination, ...this.queryForm })
      this.loading = false
      this.tableTotal = 30
      this.tableData = [{
        applyId: '0000232',
        name: 'hl',
        overdueDay: '10',
        overdueAmount: '20000.346',
        addressHousehold: '北京',
        residenceAddress: '北京',
        companyAddress: '北京',
        phone: '16875478474'
      }]
    },
    // 查询
    onQuery () {
      this.fetchData({
        pageNum: 1,
        pageSize: 30
      })
    },
    // 操作项
    handleOperate (operateItem, row) {
      console.log(operateItem, row)
    },
    // 文件上传
    uploadFile (e) {
      console.log('uploadFile', e)
    },
    // 模板下载
    templetDownload () {
      console.log('templetDownload')
    },
    // 文件导出
    exportFile () {
      console.log('exportFile')
    }
  }
}
</script>
<style lang="scss" scoped>
.header {
  display: flex;
  justify-content: space-between;
}
.header-r {
  display: flex;
}
.header-r-but {
  height: 33px;
  margin: 0 10px;
}
</style>
