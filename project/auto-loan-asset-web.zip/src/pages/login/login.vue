<template>
  <div class="login">
    <div class="login-wrapper">
      <div class="logo">
        <img width="200" height="200" class="logo-img animated bounce" src="../../assets/logo/octopus.png" alt="">
        <div class="shadow bounceIn"></div>
      </div>
      <div class="login-txt"><i>Loading...</i></div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import env from '../../config/env'
import getPermission from '../../config/permission'
export default {
  name: 'login',
  created () {
    this.login()
  },
  computed: {
    ...mapState(['userInfoName'])
  },
  methods: {
    async login () {
      try {
        let query = this.$route.query
        if (env === 'uat') { // 在测试环境输出路径及登陆信息
          let log = console.info || console.log
          log('登录信息:', this.$route.fullPath)
          log('此信息仅测试环境可见，您可复制上面的参数至开发服务的地址栏使用，从而获取登陆授权')
        }
        let loginInfo = await this.$api.login(query)
        console.log(loginInfo)
        this.$store.commit('userInfo', loginInfo.userInfo)
        let userNameInfo = []
        loginInfo.userInfo.roleInfo.forEach(element => {
          userNameInfo.push(element.roleName)
          if (element.roleName === '资产专员') {
            this.$store.commit('userInfoName', element.roleName)
          } else if (element.roleName === '资产总监') {
            this.$store.commit('userInfoName', element.roleName)
          } else if (element.roleName === '管理员') {
            this.$store.commit('userInfoName', element.roleName)
          } else if (element.roleName === '供应商') {
            this.$store.commit('userInfoName', element.roleName)
          }
        })
        // loginInfo.permission = [
        //   { 'children': [], 'id': 54, 'name': '首页', 'parentId': 50, 'path': '/home/homepage', 'icon': 'el-icon-menu', 'key': '/home/homepage' },
        //   { 'children': [], 'id': 55, 'name': '逾期车辆处理待审核', 'parentId': 52, 'path': '/home/overdueAwait', 'icon': 'el-icon-news', 'key': '/home/overdueAwait' },
        //   { 'children': [], 'id': 53, 'name': '逾期车辆审核', 'parentId': 50, 'path': '/home/beOverDue', 'icon': 'el-icon-news', 'key': '/home/beOverDue' },
        //   { 'children': [
        //     { 'children': [], 'id': 63, 'name': '家访派单', 'parentId': 52, 'path': '/home/homeList', 'key': '/home/homeList' },
        //     { 'children': [], 'id': 62, 'name': '家访派单审核', 'parentId': 52, 'path': '/home/homeListExamine', 'key': '/home/homeListExamine' },
        //     { 'children': [], 'id': 61, 'name': '家访受理', 'parentId': 52, 'path': '/home/homeVisits', 'key': '/home/homeVisits' },
        //     { 'children': [], 'id': 60, 'name': '家访登记', 'parentId': 52, 'path': '/home/homeRegister', 'key': '/home/homeRegister' },
        //     { 'children': [], 'id': 58, 'name': '家访费用', 'parentId': 52, 'path': '/home/homeCost', 'key': '/home/homeCost' }
        //   ],
        //   'id': 52,
        //   'name': '家访管理',
        //   'parentId': 50,
        //   'path': '',
        //   'icon': 'el-icon-view',
        //   'key': '52' },
        //   { 'children': [
        //     { 'children': [], 'id': 61, 'name': '资产保全派单', 'parentId': 60, 'path': '/home/sendOrders', 'key': '/home/sendOrders' },
        //     { 'children': [], 'id': 62, 'name': '资产保全派单审核', 'parentId': 60, 'path': '/home/sendOrdersAudit', 'key': '/home/sendOrdersAudit' },
        //     { 'children': [], 'id': 63, 'name': '资产保全受理', 'parentId': 60, 'path': '/home/acceptance', 'key': '/home/acceptance' },
        //     { 'children': [], 'id': 64, 'name': '资产保全交接', 'parentId': 60, 'path': '/home/inherit', 'key': '/home/inherit' },
        //     { 'children': [], 'id': 65, 'name': '资产保全交接审核', 'parentId': 60, 'path': '/home/inheritAudit', 'key': '/home/inheritAudit' },
        //     { 'children': [], 'id': 67, 'name': '资产保全费用确认', 'parentId': 60, 'path': '/home/assetsCost', 'key': '/home/assetsCost' }],
        //   'id': 60,
        //   'name': '资产保全管理',
        //   'parentId': 60,
        //   'path': '',
        //   'icon': 'el-icon-goods',
        //   'key': '51'
        //   },
        //   { 'children': [
        //     { 'children': [], 'id': 71, 'name': '库存车辆处置申请', 'parentId': 70, 'path': '/home/InventoryApply', 'key': '/home/InventoryApply' },
        //     { 'children': [], 'id': 73, 'name': '库存车辆处置审核', 'parentId': 70, 'path': '/home/InventoryExamine', 'key': '/home/InventoryExamine' }],
        //   'id': 70,
        //   'name': '库存车辆',
        //   'parentId': 70,
        //   'path': '',
        //   'icon': 'el-icon-goods',
        //   'key': '51'
        //   },
        //   { 'children': [{ 'children': [], 'id': 57, 'name': '供应商管理', 'parentId': 51, 'path': '/home/supplierManage', 'key': '/home/supplierManage' }, { 'children': [], 'id': 56, 'name': '新增供应商', 'parentId': 51, 'path': '/home/createSupplier', 'key': '/home/createSupplier' }, { 'children': [], 'id': 55, 'name': '新增供应商审核', 'parentId': 51, 'path': '/home/supplierAudit', 'key': '/home/supplierAudit' }],
        //     'id': 51,
        //     'name': '供应商',
        //     'parentId': 50,
        //     'path': '',
        //     'icon': 'el-icon-goods',
        //     'key': '51' }
        // ]
        this.$store.commit('loginStatus', 1)
        this.$store.commit('routerLink', this.parseRouterLink(loginInfo.permission))
        this.$store.commit('permission', getPermission(userNameInfo))
        this.$router.replace('/')
        if (this.userInfoName === '供应商') {
          this.$router.push({ path: '/home/homeVisits' })
        }
      } catch (e) {
        this.$notify.error({
          title: '错误',
          message: '登陆接口调用失败！'
        })
      }
    },

    parseRouterLink (links) {
      const iconDict = { // 制定路由对应的icon
        '首页': 'el-icon-menu',
        '逾期': 'el-icon-time',
        '家访管理': 'el-icon-view',
        '供应商': 'el-icon-goods',
        '资产保全管理': 'el-icon-goods'
      }
      links.forEach(item => {
        item.path = item.path.trim()
        item.icon = iconDict[item.name] || 'el-icon-news'
        item.key = (item.path || item.id).toString()
        item.children.forEach(child => {
          child.path = child.path.trim()
          child.key = (child.path || child.id).toString()
        })
      })
      return links
    }
  }
}
</script>

<style scoped lang="sass">
  .login
    position: relative
    width: 100%
    height: 100%
    min-height: 700px

    .login-wrapper
      position: absolute
      top: 50%
      left: 50%
      margin-left: -100px
      margin-top: -200px
      width: 200px
      height: 400px

      .logo
        .logo-img
          width: 200px
          height: 200px

        .shadow
          width: 200px
          height: 60px
          background: #909399
          border-radius: 50%

      .login-txt
        font-size: 44px
</style>
<style>
  @keyframes bounce {
    from,
    20%,
    53%,
    80%,
    to {
      animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
      transform: translate3d(0, 0, 0);
    }

    40%,
    43% {
      animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
      transform: translate3d(0, -30px, 0);
    }

    70% {
      animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
      transform: translate3d(0, -15px, 0);
    }

    90% {
      transform: translate3d(0, -4px, 0);
    }
  }

  .bounce {
    animation: bounce 1s infinite;
    transform-origin: center bottom;
  }

  @keyframes bounceIn {
    from,
    20%,
    40%,
    60%,
    80%,
    to {
      animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
    }

    0% {
      opacity: 1;
      transform: scale3d(1, 1, 1);
    }

    20% {
      transform: scale3d(1.1, 1.1, 1.1);
    }

    40% {
      transform: scale3d(0.9, 0.9, 0.9);
    }

    60% {
      opacity: 1;
      transform: scale3d(1.03, 1.03, 1.03);
    }

    80% {
      transform: scale3d(0.97, 0.97, 0.97);
    }

    to {
      opacity: 1;
      transform: scale3d(1, 1, 1);
    }
  }

  .bounceIn {
    animation: bounceIn 1s infinite;
    transform-origin: center bottom;
  }
</style>
