<template>
  <div class="main-con">
    <!-- 基本信息 begin -->
    <baseInfo :basicInfo='basicInfo'
              :loading='loading'></baseInfo>
    <!-- 基本信息 end -->

    <div class="modular-box">
      <div class="modular-box-form">
        <el-form :model="result"
                 :rules="rules"
                 ref="result"
                 :inline="true"
                 size="mini"
                 label-position="top">
          <el-form-item prop="time"
                        label="资产保全委托期限">
            <el-date-picker disabled
                            size="mini"
                            v-model="result.time"
                            type="daterange"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <!-- <el-form-item prop="carStopCityId" label="车辆停放城市">
            <el-input :disabled="true" v-model.trim="result.carStopCityId" ></el-input>
          </el-form-item> -->
          <el-form-item label="车辆停放城市"
                        prop="carStopCityId"
                        v-if="cityTree && cityTree.length">
            <el-cascader filterable
                         :disabled="!detailFlag"
                         expand-trigger="hover"
                         clearable
                         :props="bankCityProps"
                         :options="cityTree[0].cityList"
                         v-model="result.carStopCityId">
            </el-cascader>
          </el-form-item>
          <el-form-item prop="gpsLocation"
                        label="最后定位地址">
            <el-input :disabled="true"
                      v-model.trim="result.gpsLocation"></el-input>
          </el-form-item>

          <el-form-item label="是否有钥匙"
                        prop="hasKey">
            <el-select :disabled="true"
                       v-model="result.hasKey"
                       placeholder="请选择">
              <el-option label="否"
                         :value="0"></el-option>
              <el-option label="是"
                         :value="1"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="回款类型"
                        prop="receivableStatus">
            <el-select :disabled="!detailFlag"
                       v-model="result.receivableStatus"
                       placeholder="请选择">
              <el-option label="无回款"
                         :value="0"></el-option>
              <el-option label="回款结清金额"
                         :value="1"></el-option>
              <el-option label="回款逾期金额"
                         :value="2"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="资产保全要求"
                        prop="protectRequirements">
            <el-input :disabled="true"
                      v-model.trim="result.protectRequirements"
                      maxlength=100
                      type="textarea"></el-input>
          </el-form-item>

          <el-form-item label=" ">
            <el-upload :loading="uploading"
                       class="upload-demo"
                       :action="upLoadUrl"
                       :show-file-list="false"
                       name="fileName"
                       :on-success="carGiveupFile"
                       :on-error="handleUploadError"
                       :before-upload="beforeUpload">
              <el-button size="small"
                         type="primary">《车辆资源放弃声明》上传</el-button>
            </el-upload>
            <div v-for="(item,index) in fileList.carGiveupFile"
                 :key="index">
              <span>{{item.fileName}}</span>
              <el-button type="text"
                         @click="down(item,'carGiveupFile')">下载</el-button>
              <el-button type="text"
                         @click="del(index,'carGiveupFile')">删除</el-button>
            </div>
          </el-form-item>

          <el-form-item label=" ">
            <el-upload :loading="uploading"
                       class="upload-demo"
                       :action="upLoadUrl"
                       :show-file-list="false"
                       name="fileName"
                       :on-success="carFinanceRegisterFile"
                       :on-error="handleUploadError"
                       :before-upload="beforeUpload">
              <el-button size="small"
                         type="primary">《车辆入库及财务交接清单》上传</el-button>
            </el-upload>
            <div v-for="(item,index) in fileList.carFinanceRegisterFile"
                 :key="index">
              <span>{{item.fileName}}</span>
              <el-button type="text"
                         @click="down(item,'carFinanceRegisterFile')">下载</el-button>
              <el-button type="text"
                         @click="del(index,'carFinanceRegisterFile')">删除</el-button>
            </div>
          </el-form-item>
          <el-form-item label=" ">
            <el-upload :loading="uploading"
                       class="upload-demo"
                       :action="upLoadUrl"
                       :show-file-list="false"
                       name="fileName"
                       :on-success="carCollectFile"
                       :on-error="handleUploadError"
                       :before-upload="beforeUpload">
              <el-button size="small"
                         type="primary">《车辆回收报告》上传</el-button>
            </el-upload>
            <div v-for="(item,index) in fileList.carCollectFile"
                 :key="index">
              <span>{{item.fileName}}</span>
              <el-button type="text"
                         @click="down(item,'carCollectFile')">下载</el-button>
              <el-button type="text"
                         @click="del(index,'carCollectFile')">删除</el-button>
            </div>
          </el-form-item>
          <el-form-item label=" ">
            <el-upload :loading="uploading"
                       class="upload-demo"
                       :action="upLoadUrl"
                       :show-file-list="false"
                       name="fileName"
                       :on-success="carBasicFile"
                       :on-error="handleUploadError"
                       :before-upload="beforeUpload">
              <el-button size="small"
                         type="primary">《车辆基本情况描述》上传</el-button>
            </el-upload>
            <div v-for="(item,index) in fileList.carBasicFile"
                 :key="index">
              <span>{{item.fileName}}</span>
              <el-button type="text"
                         @click="down(item,'carBasicFile')">下载</el-button>
              <el-button type="text"
                         @click="del(index,'carBasicFile')">删除</el-button>
            </div>
          </el-form-item>

        </el-form>
        <!-- <div style="display:inline-block;padding-bottom:20px;min-width:800px">
           <el-button type="primary" size="mini">《车辆回收报告》下载</el-button>
            <el-button type="primary" size="mini">《车辆基本情况描述》下载</el-button>
            <el-button type="primary" size="mini">《车辆入库及财务交接清单》下载</el-button>
            <el-button type="primary" size="mini">《车辆自愿放弃声明》下载</el-button>
            <el-button type="primary" size="mini">《授权委托书下载》下载</el-button>
            <el-button type="primary" size="mini">《资料清单》下载</el-button>
        </div>
        <p style="color:red">授权委托书要带电子章</p> -->
      </div>
    </div>

    <!-- 车辆图片上传 -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">车辆图片上传</span>
      </div>

      <div class="modular-box-tb">
        <el-form :disabled="false"
                 label-position="top"
                 ref="fileForm"
                 :inline="true">
          <el-form-item v-for="(attach, index) in attachInfo"
                        :key="index"
                        class="img-box">
            <!-- <div> -->
            <picUpload :attach="attach"
                       :editable="detailFlag"
                       @preView="handlePictureCardPreview" />
            <div class="label-text"
                 style="width:300px;"><i v-if="attach.required"
                 class="required-icon">*</i>{{attach.name}}</div>
            <!-- </div> -->
          </el-form-item>
        </el-form>
      </div>
    </div>
    <el-dialog :visible.sync="showPreview"
               size="tiny"
               :modal-append-to-body="false">
      <img width="100%"
           :src="dialogImageUrl"
           alt="">
    </el-dialog>
    <!-- 客户电话信息 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">客户电话信息</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading"
                    :data="contacts"
                    border
                    style="width: 100%">
            <el-table-column label="序号"
                             type="index"
                             align="center"
                             width="100"></el-table-column>
            <el-table-column prop="typeDesc"
                             label="电话类型"
                             align="center"></el-table-column>
            <el-table-column prop="customerName"
                             label="客户名称"
                             align="center"></el-table-column>
            <el-table-column prop="phone"
                             label="电话号码"
                             align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">资产保全受理信息</span>
      </div>
      <div class="modular-box-form">
        <el-form :model="audit"
                 :rules="auditRules"
                 ref="audit"
                 :inline="true"
                 size="mini"
                 label-position="top">
          <el-form-item prop="estimateArriveDate"
                        label="预计上门时间">
            <el-date-picker size="mini"
                            :disabled="true"
                            v-model="audit.estimateArriveDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item prop="collectUser"
                        label="资产保全人员">
            <el-input :disabled="true"
                      v-model.trim="audit.collectUser"></el-input>

          </el-form-item>
          <!-- <el-form-item prop="collectUser" label="收车人员">
            <el-input :disabled="true" v-model.trim="audit.collectUser" ></el-input>

          </el-form-item> -->

          <!-- <el-form-item prop="collectUserPhone" label="收车人电话">
            <el-input :disabled="true" v-model.trim="audit.collectUserPhone" ></el-input>
          </el-form-item> -->
          <el-form-item prop="collectUserPhone"
                        label="资产保全人电话">
            <el-input :disabled="true"
                      v-model.trim="audit.collectUserPhone"></el-input>
          </el-form-item>
          <!-- <el-form-item prop="estimateCollectDate" label="预计收车时间">
              <el-date-picker
                size="mini"
                v-model="audit.estimateCollectDate"
                range-separator="至"
                start-placeholder="开始日期"
                value-format="yyyy-MM-dd"
                end-placeholder="结束日期">
              </el-date-picker>
          </el-form-item> -->
          <el-form-item prop="visitTime"
                        label="上门时间">
            <el-date-picker size="mini"
                            :disabled="!detailFlag"
                            v-model="audit.visitTime"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="出发省份-城市"
                        prop="fromCities"
                        v-if="cityTree && cityTree.length">
            <el-cascader :disabled="true"
                         expand-trigger="hover"
                         filterable
                         :props="bankCityProps"
                         :options="cityTree[0].cityList"
                         v-model="audit.fromCities">
            </el-cascader>
          </el-form-item>
          <el-form-item label=" "
                        prop="">
            <!-- <el-select :disabled="!detailFlag" v-model="result.fromCityId" placeholder="请选择">
              <el-option label="否" value="0"></el-option>
              <el-option label="是" value="1"></el-option>
            </el-select> -->
          </el-form-item>
          <el-form-item prop="estimateCollectDate"
                        label="预计资产保全时间">
            <el-date-picker size="mini"
                            :disabled="true"
                            v-model="audit.estimateCollectDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="资产保全省份-城市"
                        prop="protectCities"
                        v-if="cityTree && cityTree.length">
            <el-cascader :disabled="true"
                         expand-trigger="hover"
                         filterable
                         :props="bankCityProps"
                         :options="cityTree[0].cityList"
                         v-model="audit.protectCities">
            </el-cascader>
          </el-form-item>

          <el-form-item label="预计里程"
                        prop="estimateDistance">
            <el-input :disabled="true"
                      v-model.trim="audit.estimateDistance"></el-input>
          </el-form-item>

          <el-form-item prop="registerDate"
                        label="交接时间">
            <el-date-picker size="mini"
                            :disabled="true"
                            v-model="audit.registerDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>

          <el-form-item label="实际里程"
                        prop="distance">
            <el-input :disabled="!detailFlag"
                      v-model.trim="audit.distance"></el-input>
          </el-form-item>
          <el-form-item label="车辆停放地"
                        prop="carStopPlace">
            <el-input v-model.trim="audit.carStopPlace"
                      :disabled="!detailFlag"></el-input>
          </el-form-item>
          <el-form-item label="入库时间"
                        prop="storageDate">
            <el-date-picker size="mini"
                            :disabled="!detailFlag"
                            v-model.trim="audit.storageDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="上牌时间">
            <el-date-picker size="mini"
                            :disabled="!detailFlag"
                            v-model.trim="audit.carNoDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="停放SP处">
            <el-select v-model.trim="audit.carStopDealer"
                       :disabled="!detailFlag"
                       filterable
                       placeholder="请选择">
              <el-option v-for="(item, index) in spNameList"
                         :key="index"
                         :label="item"
                         :value="item"></el-option>
            </el-select>

          </el-form-item>
          <el-form-item label="提车电话"
                        prop="buyCarPhone">
            <el-input v-model.trim="audit.buyCarPhone"
                      :disabled="!detailFlag"></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 处理记录 end -->
    <div class="submit-btn">
      <el-button v-if="detailFlag"
                 :plain="true"
                 @click="submitValidateFun()"
                 type="primary">提 交</el-button>
      <el-button @click="pageBack()">返 回</el-button>
    </div>

  </div>

</template>

<script>
// import { amount } from '../../../filters/index.js'
import { formatDate } from '../../../filters/index.js'
import baseInfo from '../../../components/baseInfo2.0'
import apiHost from '../../../config/apiHost'
import api from '../../../api2.0/assets/inherit/index'
import picUpload from '../../../components/upload2.0/picUpload'
import cityTreeMixin from '../../../mixins/cityTreeMixin'
export default {
  components: {
    baseInfo,
    picUpload
  },
  mixins: [cityTreeMixin],
  data () {
    // 金额校验规则
    // const temp = /^\d+\.?\d{0,3}$/
    // const validAmount = (rule, value, callback) => {
    //   if (value === '') {
    //     callback(new Error('请填写预计费用'))
    //   } else if (Number(value) === 0) {
    //     callback(new Error('预计费用不能为0'))
    //   } else if (!temp.test(value)) {
    //     callback(new Error('请输入正确的费用'))
    //   } else {
    //     callback()
    //   }
    // }
    return {
      spNameList: [], // SP名称列表
      fileList: {
        // 车辆自愿放弃申明文件
        carGiveupFile: [],
        // 车辆入库及财务交接清单
        carFinanceRegisterFile: [],
        // 车辆回收报告
        carCollectFile: [],
        // 车辆基本情况描述
        carBasicFile: []

      },
      attachInfo: [
        {
          node: 'carFrontierFile',
          name: '车头照片',
          required: true,
          url: ''
        },
        {
          node: 'carEndFile',
          name: '车尾照片',
          required: true,
          url: ''
        },
        {
          node: 'carLeftBodyFile',
          name: '车身照片(左侧)',
          required: true,
          url: ''
        },
        {
          node: 'carRightBodyFile',
          name: '车身照片(右侧)',
          required: true,
          url: ''
        },
        {
          node: 'carInnerFile',
          name: '车厢',
          required: true,
          url: ''
        },
        {
          node: 'carOdometerFile',
          name: '里程表照片',
          required: true,
          url: ''
        },
        {
          node: 'carChairFile',
          name: '座椅',
          required: true,
          url: ''
        },
        {
          node: 'carDriveLicenseKeyFile',
          name: '行驶证原件+车钥匙拍照1份',
          required: true,
          url: ''
        },
        {
          node: 'carGiveupIdcardFile',
          name: '客户手持自弃协议+身份证与车辆合影(照片清晰，并显示拍照日期)',
          required: true,
          url: ''
        },
        {
          node: 'carAroundFile',
          name: '自弃车辆绕车视频(视频需见车辆行驶里程数、车钥匙插孔开门、车辆前后左右整体照片)',
          required: true,
          url: ''
        },
        {
          node: 'carOtherFile',
          name: '其他',
          required: false,
          url: ''
        }
      ], // 附件信息
      bankCityProps: {
        value: 'currentKey',
        label: 'cityName',
        children: 'cityList'
      },
      dialogImageUrl: '',
      showPreview: false,
      upLoadUrl: `${apiHost.basePath}/file/uploadV2`,
      loading: true,
      uploading: false,
      detailFlag: false, // 是否可编辑Flag
      basicInfo: {}, // 基本信息
      processRecords: [], // 处理记录
      contacts: [], // 客户电话信息
      getDict: [], // 家访公司选择下拉菜单
      // 提交信息
      result: {
        id: '',
        receivableStatus: null,
        carStopCityId: [],
        backReason: '',
        carDetailedFileList: '',
        exchangeReason: '',
        expectFee: '',
        gpsLocation: '',
        gpsStatus: 0,
        hasKey: '',
        isBack: '',
        isExchange: '',
        otherRequirements: '',
        protectRequirements: '',
        supplierId: '',
        time: [],
        entrustStartTime: '',
        entrustEndTime: '',
        carStopPlace: '', // 车辆停放地
        storageDate: '', // 入库时间
        carNoDate: '', // 上牌时间
        carStopDealer: '', // 停放SP处
        buyCarPhone: '' // 提车电话
      },
      rules: {
        carStopCityId: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value.length) {
                callback(new Error('请选择车辆投放城市'))
              } else {
                callback()
              }
            }
          }
        ],
        supplierId: [{ required: true, trigger: 'change', message: '请选择资产保全委托期限' }],
        hasKey: [{ required: true, trigger: 'change', message: '请选择是否有钥匙' }],
        protectRequirements: [{ required: true, trigger: 'blur', message: '请填写资产保全要求' }]
      },
      // 提交审核
      audit: {
        collectUser: '',
        collectUserPhone: '',
        estimateArriveDate: '',
        estimateCollectDate: '',
        estimateDistance: '',
        fromCityId: '',
        fromProvinceId: '',
        protectCityId: '',
        protectProvinceId: '',
        fromCities: [],
        protectCities: []
      },
      auditStatusMap: {
        1: '审核通过',
        2: '审核退回'
      },
      auditRules: {
        carStopPlace: [
          { required: true, message: '请输入车辆停放地', trigger: 'blur' }
        ],
        storageDate: [
          { required: true, message: '请选择入库时间', trigger: 'blur' }
        ],
        buyCarPhone: [
          { required: true, message: '请输入提车电话', trigger: 'blur' }
        ],
        collectUser: [{ required: true, trigger: 'change', message: '请填收车人员' }],
        collectUserPhone: [{ required: true, trigger: 'blur', message: '请填收车人电话' }],
        estimateArriveDate: [{ required: true, trigger: 'blur', message: '请填预计上门时间' }],
        estimateCollectDate: [{ required: true, trigger: 'blur', message: '请填预计收车时间' }],
        estimateDistance: [{ required: true, trigger: 'blur', message: '请填预计里程' }],
        fromCityId: [{ required: true, trigger: 'blur', message: '请填出发城市' }],
        fromProvinceId: [{ required: true, trigger: 'blur', message: '请填出发省份' }],
        protectCityId: [{ required: true, trigger: 'blur', message: '请填资产保全城市' }],
        protectProvinceId: [{ required: true, trigger: 'blur', message: '请填资产保全省份' }],
        visitTime: [{ required: true, trigger: 'blur', message: '请选择上门时间' }],
        fromCities: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value.length) {
                callback(new Error('请选择出发省份-城市'))
              } else {
                callback()
              }
            }
          }
        ],
        protectCities: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value.length) {
                callback(new Error('请选择资产保全省份-城市'))
              } else {
                callback()
              }
            }
          }
        ],
        distance: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value || !/^[0-9]*$/.test(value)) {
                callback(new Error('请填写正确的里程数'))
              } else {
                callback()
              }
            }
          }
        ]
      }
    }
  },
  mounted () {
    if (this.$route.query.detailFlag.toString() === 'true') {
      this.detailFlag = true
    }
    this.getDictFun()
    this.getDetailFun()
    this.getSpnameList()
  },
  methods: {
    // SP名称列表
    async getSpnameList () {
      try {
        this.loading = true
        let res = await this.$api.getSpnameList()
        this.spNameList = res
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 获取定位
    async fetchGps () {
      const data = {
        applyId: this.$route.query.id
      }
      let res = this.$api.gpsInfo(data)
      if (res) {
        this.result.gpsLocation = res
      }
    },
    down (item, type) {
      window.location.href = apiHost.basePath + '/file/singleDownload' + '?url=' + item.url
      // window.location.href = `http://d1-managerdaikuan.2345.com/asset-service` + '/file/singleDownload' + '?url=' + item.url
    },
    del (index, type) {
      console.log(index)
      this.fileList[type].splice(index, 1)
    },
    beforeUpload (file) {
      this.uploading = true
      // const isLt10M = file.size / 1024 / 1024 < 10

      // if (!isLt10M) {
      //   this.$message.error('图片或文件大小不能超过 10MB!')
      // }
    },
    handleUploadError () {
      this.uploading = false
    },
    // 上传文件的成功回调不能覆盖默认参数，只有拆开四个了
    carGiveupFile (res, file) {
      let fileName = res.result.match(/@(\S*)/)[1]
      this.fileList.carGiveupFile = [{
        url: res.result,
        fileName: fileName
      }]
    },
    carFinanceRegisterFile (res, file) {
      let fileName = res.result.match(/@(\S*)/)[1]
      this.fileList.carFinanceRegisterFile = [{
        url: res.result,
        fileName: fileName
      }]
    },
    carCollectFile (res, file) {
      let fileName = res.result.match(/@(\S*)/)[1]
      this.fileList.carCollectFile = [{
        url: res.result,
        fileName: fileName
      }]
    },
    carBasicFile (res, file) {
      let fileName = res.result.match(/@(\S*)/)[1]
      this.fileList.carBasicFile = [{
        url: res.result,
        fileName: fileName
      }]
    },
    handlePictureCardPreview (file) {
      this.dialogImageUrl = file.url
      this.showPreview = true
    },
    // 获取详情信息
    async getDetailFun () {
      try {
        let res = await api.detail({
          registerOrderId: this.$route.query.id
        })
        this.basicInfo = res.basicInfo
        this.processRecords = res.processRecords
        this.contacts = res.contacts
        const businessInfo = res.protectRegisterBusinessInfo
        for (let key in this.fileList) {
          if (businessInfo[key]) {
            let tempArr = businessInfo[key].split(',')
            tempArr.forEach(t => {
              let fileName = t.match(/@(\S*)/)[1]
              this.fileList[key].push({
                url: t,
                fileName: fileName
              })
            })
          }
        }

        // carGiveupFile
        // carFinanceRegisterFile
        // carCollectFile
        // carBasicFile
        // const { visitStartTime, visitEndTime, isExchange, isBack, supplierId, expectFee, visitRequirements } = businessInfo
        this.result = {
          ...businessInfo,
          carStopCityId: businessInfo.carStopCityId ? businessInfo.carStopCityId.split(',') : [],
          time: businessInfo.entrustStartTime ? [businessInfo.entrustStartTime, businessInfo.entrustEndTime] : []
        }
        this.attachInfo.forEach(t => {
          for (var key in businessInfo) {
            if (key === t.node) {
              t.url = businessInfo[key]
            }
          }
        })
        let time = formatDate(new Date(), 'yyyy-MM-dd')
        this.audit = {
          collectUser: res.protectAcceptBusinessInfo.collectUser,
          collectUserPhone: res.protectAcceptBusinessInfo.collectUserPhone,
          estimateArriveDate: res.protectAcceptBusinessInfo.estimateArriveDate,
          estimateCollectDate: res.protectAcceptBusinessInfo.estimateCollectDate,
          estimateDistance: res.protectAcceptBusinessInfo.estimateDistance,
          fromCityId: res.protectAcceptBusinessInfo.fromCityId,
          fromProvinceId: res.protectAcceptBusinessInfo.fromProvinceId,
          protectCityId: res.protectAcceptBusinessInfo.protectCityId,
          protectProvinceId: res.protectAcceptBusinessInfo.protectProvinceId,
          fromCities: [res.protectAcceptBusinessInfo.fromProvinceId, res.protectAcceptBusinessInfo.fromCityId],
          protectCities: [res.protectAcceptBusinessInfo.protectProvinceId, res.protectAcceptBusinessInfo.protectCityId],
          visitTime: res.protectRegisterBusinessInfo.visitTime,
          registerDate: res.protectRegisterBusinessInfo.registerDate || time,
          distance: res.protectRegisterBusinessInfo.distance
        }
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 获取时间
    getTimeFun (value) {
      this.result.visitStartTime = value[0]
      this.result.visitEndTime = value[1]
    },
    // 提交校验
    async submitValidateFun () {
      let flag = true
      // if (!this.fileList.carGiveupFile.length || this.fileList.carFinanceRegisterFile.length || this.fileList.carCollectFile.length || this.fileList.carBasicFile.length) {
      //   return this.$message.error('请先将文件上传完整！')
      // }
      if (this.result.receivableStatus === 0) {
        this.attachInfo.forEach(t => {
          if (t.required && !t.url) {
            flag = false
          }
        })
      }
      if (!flag) {
        this.$message.error('请先将附件上传完整！')
      }
      this.$refs['result'].validate(async (valid) => {
        if (valid) {

        } else {
          flag = false
        }
      })
      this.$refs['audit'].validate(async (valid) => {
        if (valid) {

        } else {
          flag = false
        }
      })
      if (flag) {
        try {
          let str = ''
          if (this.result.receivableStatus === 2) {
            str = '回款类型选择“回款逾期金额”后续不能修改交接内容，流程将结束，是否继续？'
          } else {
            str = '请确认是否提交？'
          }

          let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '确定' })
          if (confirm) {
            this.submitFun()
          }
        } catch (error) {

        }
      }
    },
    // 提交
    async submitFun () {
      let arrObj = {
        // 车辆自愿放弃申明文件
        carGiveupFile: [],
        // 车辆入库及财务交接清单
        carFinanceRegisterFile: [],
        // 车辆回收报告
        carCollectFile: [],
        // 车辆基本情况描述
        carBasicFile: []

      }
      for (var key in this.fileList) {
        if (this.fileList[key].length) {
          this.fileList[key].forEach(t => {
            arrObj[key].push(t.url)
          })
        }
      }
      let data = {
        // 四个文件列表
        id: this.$route.query.id,
        carGiveupFile: arrObj.carGiveupFile.length ? arrObj.carGiveupFile.join(',') : '',
        carFinanceRegisterFile: arrObj.carFinanceRegisterFile.length ? arrObj.carFinanceRegisterFile.join(',') : '',
        carCollectFile: arrObj.carCollectFile.length ? arrObj.carCollectFile.join(',') : '',
        carBasicFile: arrObj.carBasicFile.length ? arrObj.carBasicFile.join(',') : '',
        // 文件大图
        carFrontierFile: this.attachInfo[0].url,
        carEndFile: this.attachInfo[1].url,
        carLeftBodyFile: this.attachInfo[2].url,
        carRightBodyFile: this.attachInfo[3].url,
        carInnerFile: this.attachInfo[4].url,
        carOdometerFile: this.attachInfo[5].url,
        carChairFile: this.attachInfo[6].url,
        carDriveLicenseKeyFile: this.attachInfo[7].url,
        carGiveupIdcardFile: this.attachInfo[8].url,
        carAroundFile: this.attachInfo[9].url,
        carOtherFile: this.attachInfo[10].url,
        carStopCityId: this.result.carStopCityId.join(','),
        receivableStatus: this.result.receivableStatus,
        visitTime: this.audit.visitTime,
        distance: this.audit.distance
      }
      let res = await api.submit(data)
      console.log(res)
      if (res) {
        this.$message.success('提交成功')
        this.pageBack()
      } else {
        this.$message.error('提交失败')
      }
    },
    // 获取家访公司列表
    async getDictFun () {
      let res = await this.$api.getDict()
      this.getDict = res.supplierList
    },
    // 返回上一页
    pageBack () {
      window.history.back('-1')
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
