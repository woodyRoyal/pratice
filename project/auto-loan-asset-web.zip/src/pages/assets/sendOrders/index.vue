<template>
  <div class="main-con">
    <!-- 筛选 begin -->
    <div class="query-box">
      <el-form :inline="true"
               class="demo-form-inline"
               label-width="100px"
               size="mini">
        <el-form-item label="UID">
          <el-input v-model.trim="queryform.uid"
                    placeholder=""
                    style="width:120px"></el-input>
        </el-form-item>
        <el-form-item label="客户姓名">
          <el-input v-model.trim="queryform.customerName"
                    placeholder=""
                    style="width:120px"></el-input>
        </el-form-item>
        <el-form-item label="派单人员">
          <el-input v-model.trim="queryform.sendOrderUsername"
                    placeholder=""
                    style="width:120px"></el-input>
        </el-form-item>
        <el-form-item label="是否受理超期">
          <el-select v-model="queryform.acceptOverdue"
                     placeholder="请选择"
                     style="width:120px">
            <el-option v-for="(item, index) in trueFalseDictionary"
                       :key="index"
                       :label="item"
                       :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="派单审核结果">
          <el-select v-model="queryform.auditStatus"
                     placeholder="请选择"
                     style="width:120px">
            <el-option v-for="(item, index) in auditStatusDictionary"
                       :key="index"
                       :label="item"
                       :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="是否派单">
          <el-select v-model="queryform.sendOrder"
                     placeholder="请选择"
                     style="width:120px">
            <el-option v-for="(item, index) in trueFalseDictionary"
                       :key="index"
                       :label="item"
                       :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="是否改派">
          <el-select v-model="queryform.exchange"
                     placeholder="请选择"
                     style="width:120px">
            <el-option v-for="(item, index) in trueFalseDictionary"
                       :key="index"
                       :label="item"
                       :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="是否撤销">
          <el-select v-model="queryform.revoke"
                     placeholder="请选择"
                     style="width:120px">
            <el-option v-for="(item, index) in trueFalseDictionary"
                       :key="index"
                       :label="item"
                       :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="是否受理">
          <el-select v-model="queryform.accept"
                     placeholder="请选择"
                     style="width:120px">
            <el-option v-for="(item, index) in trueFalseDictionary"
                       :key="index"
                       :label="item"
                       :value="index"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="挂靠公司">
          <!-- <el-select v-model="queryform.attachedCompanyName" filterable style="width:120px" placeholder="请选择">
            <el-option v-for="(item, index) in companyList" :key="index" :label="item" :value="item"></el-option>
          </el-select> -->
          <el-input v-model="queryform.attachedCompanyName"
                    style="width:120px"> </el-input>
        </el-form-item>
        <el-form-item label="SP名称">
          <!-- <el-select v-model="queryform.spName" filterable style="width:120px" placeholder="请选择">
            <el-option v-for="(item, index) in spNameList" :key="index" :label="item" :value="item"></el-option>
          </el-select> -->
          <el-input v-model="queryform.spName"
                    style="width:120px"> </el-input>
        </el-form-item>
        <el-form-item label="SP归属地省份">
          <el-select v-model="queryform.spLocationProvinceKey"
                     placeholder="请选择"
                     style="width:120px"
                     v-if="cityTree && cityTree[0].cityList">
            <el-option v-for="item in cityTree[0].cityList"
                       :key="item.currentKey"
                       :label="item.cityName"
                       :value="item.currentKey"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="客户户籍省份">
          <el-select v-model="queryform.clientCensusProvinceKey"
                     placeholder="请选择"
                     style="width:120px"
                     v-if="cityTree && cityTree[0].cityList">
            <el-option v-for="item in cityTree[0].cityList"
                       :key="item.currentKey"
                       :label="item.cityName"
                       :value="item.currentKey"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label=" ">
          <el-button type="primary"
                     @click="getListFun()">查询</el-button>
          <el-button @click="queryResetFun()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 筛选 end -->
    <el-button type="primary"
               class="batch"
               @click="openBatchDialog"
               size="small">批量派单</el-button>
    <!-- 数据表格 begin -->
    <div class="modular-box">
      <el-table v-loading="loading"
                :data="dataTable"
                border
                style="width: 100%"
                :max-height="maxTableHeight"
                @selection-change="handleSelectionChange">
        <el-table-column type="selection"
                         width="55"></el-table-column>
        <el-table-column label="序号"
                         type="index"
                         width="80"
                         align="center"></el-table-column>
        <el-table-column prop="uid"
                         label="UID"
                         align="center"></el-table-column>
        <el-table-column prop="customerName"
                         label="客户姓名"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.customerName | formatName }}
          </template>
        </el-table-column>
        <el-table-column prop="sendOrderUsername"
                         label="派单人员"
                         align="center"></el-table-column>
        <el-table-column label="处理申请日期"
                         align="center"
                         width="100">
          <template slot-scope="scope">
            {{ scope.row.overdueInfoCreateTime | formatDate("yyyy-MM-dd") }}
          </template>
        </el-table-column>
        <el-table-column label="处理要求"
                         align="center"
                         width="200">
          <template slot-scope="scope">
            {{ scope.row.protectRequirements || "/" }}
          </template>
        </el-table-column>
        <el-table-column label="供应商"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.supplierName || "/" }}
          </template>
        </el-table-column>
        <el-table-column label="剩余本金(元)"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.leftPrinciple | amount }}
          </template>
        </el-table-column>
        <el-table-column prop="overdueDay"
                         label="逾期天数(天)"
                         align="center"></el-table-column>
        <el-table-column prop="gpsStatus"
                         label="gps状态"
                         align="center"></el-table-column>
        <el-table-column prop="sendOrder"
                         label="是否派单"
                         align="center"></el-table-column>
        <el-table-column label="派单审核结果"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.sendOrderAuditResult || "/" }}
          </template>
        </el-table-column>
        <el-table-column label="派单日期"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.sendOrderDate | formatDate("yyyy-MM-dd") }}
          </template>
        </el-table-column>
        <el-table-column label="是否改派"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.exchange || "/" }}
          </template>
        </el-table-column>
        <el-table-column label="是否受理超期"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.acceptOverdue || "/" }}
          </template>
        </el-table-column>
        <el-table-column label="是否撤销"
                         align="center">
          <template slot-scope="scope">
            {{ scope.row.back || "/" }}
          </template>
        </el-table-column>
        <el-table-column prop="businessType"
                         label="任务类型"
                         align="center"></el-table-column>

        <el-table-column prop="attachedCompanyName"
                         label="挂靠公司"
                         align="center"></el-table-column>
        <el-table-column prop="spName"
                         label="SP名称"
                         align="center"></el-table-column>
        <el-table-column prop="spLocationProvinceName"
                         label="sp归属地省份"
                         align="center"></el-table-column>
        <el-table-column prop="clientCensusProvinceName"
                         label="客户户籍省份"
                         align="center"></el-table-column>
        <el-table-column label="操作"
                         align="center"
                         fixed="right"
                         width="70">
          <template slot-scope="scope">
            <a class="btn-blue"
               v-if="scope.row.editable"
               @click="toCompactFun(scope.row)">办理</a>
            <a class="btn-blue"
               v-else
               @click="toCompactFun(scope.row)">查看</a>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 数据表格 end -->

    <!-- 分页 begin -->
    <el-pagination @size-change="handleSizeChange"
                   @current-change="handleCurrentChange"
                   :current-page="page.currentPage"
                   :page-sizes="page.pageSizesArr"
                   :page-size="page.pageSize"
                   :total="page.total"
                   layout="total, sizes, prev, pager, next, jumper">
    </el-pagination>
    <!-- 分页 end -->

    <!-- 上门地址数量弹框 begin -->
    <!-- <AddressesDdialog :addressesDialog='dialogFlag' :addressesList='dialogData' @listenDialogFun='listenDialogFun'></AddressesDdialog> -->
    <!-- 上门地址数量弹框 end -->
    <el-dialog title="批量派单"
               :modal="false"
               :visible.sync="dialogFormVisible"
               @close="closeBatch()"
               width="500px">
      <el-form>
        <el-form-item label="指派给:">
          <el-select v-model="supplierId"
                     placeholder="请选择"
                     style="width:80%">
            <el-option v-for="(item, index) in supplierList"
                       :key="index"
                       :label="item.value"
                       :value="item.key"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary"
                   @click="batchDispatch"
                   :disabled="supplierId == ''"
                   :loading="batchLoading">提交</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<!--
  注：表格操作栏状态判断如下
  1.办理：如果editable字段为true，并且角色是资产专员，
  2.查看：角色是资产总监editable
-->
<script>
/* eslint-disable */
import { mapState } from "vuex";
import cityTreeMixin from "../../../mixins/cityTreeMixin";
import api from "../../../api2.0/assets/sendOrders/index.js";
import { Notification } from "element-ui";
// import AddressesDdialog from '../../../components/addressesDdialog'
export default {
  mixins: [cityTreeMixin],
  components: {
    // AddressesDdialog
  },
  data () {
    return {
      loading: true,
      dialogFlag: false, // 上门地址数量弹框
      dataTable: [], // 列表Table数据
      dialogData: [], // 弹框数据
      // 筛选条件
      queryform: {
        accept: null, // 是否受理
        acceptOverdue: null,
        applyId: null, // 申请编号
        auditStatus: null, // 审核状态
        customerName: null, // 客户姓名
        exchange: null, // 是否改派
        pageNum: 1, // 页码
        pageSize: 20, // 每页大小
        revoke: null, // 是否撤销
        sendOrder: null, // 是否已派单
        sendOrderUsername: null, // 派单人员
        attachedCompanyName: null, // 挂靠公司名称
        spName: null, // sp名称
        spLocationProvinceKey: null, // sp归属地省份
        clientCensusProvinceKey: null, // 客户户籍省份
        uid: null
      },
      // 分页
      page: {
        total: 0,
        pageSizesArr: [10, 20, 30, 40],
        currentPage: 1, // 当前页
        pageSize: 20 // 每页条数
      },
      // 是否已派单、是否改派、是否撤销、是否受理等字典
      trueFalseDictionary: {
        0: "否",
        1: "是"
      },
      // 派单审核结果字典
      auditStatusDictionary: {
        0: "待审核",
        1: "审核通过",
        2: "审核退回"
      },
      ids: [], // 批量派单
      supplierId: "", // 供应商id
      supplierList: [], // 供应商列表
      dialogFormVisible: false, // 批量派单弹窗
      batchLoading: false,
      spNameList: [], // SP名称列表
      companyList: [] // 挂靠公司列表
    };
  },
  computed: {
    ...mapState(["maxTableHeight", "permission"])
  },
  created () {
    let history = window.sessionStorage;
    this.queryform.pageNum = this.page.currentPage = parseInt(history.getItem("pageIndex")) || 1;
    this.getSupplier();
    this.getSpnameList();
    this.getcompanyList();
  },
  mounted () {
    this.getUrlQuery();
    this.getListFun();
  },
  methods: {
    //
    closeBatch () {
      this.supplierId = "";
    },
    // 监听弹框显示和隐藏
    listenDialogFun () {
      this.dialogFlag = false;
    },
    // 获取url上的参数
    getUrlQuery () {
      this.queryform.accept = this.$route.query.accept || null;
      this.queryform.acceptOverdue = this.$route.query.acceptOverdue || null;
      this.queryform.applyId = this.$route.query.applyId || null;
      this.queryform.auditStatus = this.$route.query.auditStatus || null;
      this.queryform.customerName = this.$route.query.customerName || null;

      this.queryform.exchange = this.$route.query.exchange || null;
      this.queryform.revoke = this.$route.query.revoke || null;
      this.queryform.sendOrder = this.$route.query.sendOrder || null;
      this.queryform.uid = this.$route.query.uid || null;
      this.queryform.sendOrderUsername = this.$route.query.sendOrderUsername || null;

      this.queryform.attachedCompanyName = this.$route.query.attachedCompanyName || null;
      this.queryform.spName = this.$route.query.spName || null;
      this.queryform.spLocationProvinceKey = this.$route.query.spLocationProvinceKey || null;
      this.queryform.clientCensusProvinceKey = this.$route.query.clientCensusProvinceKey || null;
    },
    // 重置
    queryResetFun () {
      this.queryform = {
        accept: null, // 是否受理
        acceptOverdue: null,
        applyId: null, // 申请编号
        auditStatus: null, // 审核状态
        customerName: null, // 客户姓名
        exchange: null, // 是否改派
        pageNum: 1, // 页码
        pageSize: 20, // 每页大小
        revoke: null, // 是否撤销
        sendOrder: null, // 是否已派单
        sendOrderUsername: null, // 派单人员
        attachedCompanyName: null, // 挂靠公司名称
        spName: null, // sp名称
        spLocationProvinceKey: null, // sp归属地省份
        clientCensusProvinceKey: null, // 客户户籍省份
        uid: null
      };
      this.page.currentPage = 1;
      this.page.pageSize = 20;
      this.getListFun();
    },
    // 获取列表Table数据
    async getListFun () {
      try {
        this.loading = true;
        let res = await api.getTableList(this.queryform);
        this.dataTable = res.list;
        this.page.total = res.total;
      } finally {
        setTimeout(() => {
          this.loading = false;
        }, 500);
      }
    },
    // SP名称列表
    async getSpnameList () {
      try {
        this.loading = true;
        let res = await this.$api.getSpnameList();
        this.spNameList = res;
      } finally {
        setTimeout(() => {
          this.loading = false;
        }, 500);
      }
    },
    // 挂靠公司列表
    async getcompanyList () {
      try {
        this.loading = true;
        let res = await api.getcompanyList();
        this.companyList = res.list;
      } finally {
        setTimeout(() => {
          this.loading = false;
        }, 500);
      }
    },
    // 查看或办理跳转
    toCompactFun (row) {
      const { id } = row;
      let detailFlag = row.editable;
      this.$router.push({
        path: "/home/sendOrders-detail",
        query: { id, detailFlag }
      });
    },
    // 弹框里的数据
    DialogDataFun (data) {
      this.dialogFlag = true;
      this.dialogData = data;
    },
    // 分页操作
    handleSizeChange (val) {
      this.page.pageSize = val;
      this.queryform.pageSize = val;
      this.getListFun();
    },
    handleCurrentChange (val) {
      this.queryform.pageNum = val;
      this.page.currentPage = val;
      window.sessionStorage.setItem("pageIndex", val);
      this.getListFun();
    },
    // 批量派单列表
    async getSupplier () {
      let res = await this.$api.getSupplier();
      this.supplierList = res.supplierList;
    },
    // 批量派单提交
    async batchDispatch () {
      try {
        this.batchLoading = true;
        let result = await api.batchDispatch({ ids: this.ids, supplierId: this.supplierId });
        Notification.success({
          title: "提示",
          duration: 0,
          message: result
        });
        this.dialogFormVisible = false;
        this.batchLoading = false;
        this.getListFun();
      } catch (error) {
        this.batchLoading = false;
      }
    },
    // 全选
    handleSelectionChange (val) {
      this.ids = val.map(v => v.id);
    },
    // 批量弹框
    openBatchDialog () {
      if (this.ids.length === 0) {
        Notification.warning({
          title: "请选择",
          message: "请选择需要派单的id"
        });
      } else {
        this.dialogFormVisible = true;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.batch {
  margin: 20px 0;
}
</style>
