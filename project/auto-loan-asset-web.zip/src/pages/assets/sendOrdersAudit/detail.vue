<template>
  <div class="main-con">
    <!-- 基本信息 begin -->
    <baseInfo :basicInfo='basicInfo'
              :loading='loading'></baseInfo>
    <!-- 基本信息 end -->

    <div class="modular-box">
      <div class="modular-box-form">
        <el-form :model="result"
                 :rules="rules"
                 ref="audit"
                 :inline="true"
                 size="mini"
                 label-position="top">
          <el-form-item prop="time"
                        label="资产保全委托期限">
            <el-date-picker disabled
                            size="mini"
                            v-model="result.time"
                            type="daterange"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>

          <el-form-item prop=""
                        label=" ">
            <el-button type="primary"
                       :disabled="true"
                       @click="fetchGps">定位</el-button>

          </el-form-item>

          <el-form-item prop="gpsLocation"
                        label="最后定位地址">
            <el-input :disabled="true"
                      v-model.trim="result.gpsLocation"></el-input>
          </el-form-item>
          <el-form-item label="是否改派"
                        v-if="result.isFirstOrder === 0">
            <el-select :disabled="true"
                       v-model="result.isExchange"
                       placeholder="请选择">
              <el-option label="否"
                         value="0"></el-option>
              <el-option label="是"
                         value="1"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="改派原因"
                        v-if="result.isFirstOrder === 0">
            <el-input :disabled="true"
                      v-model.trim="result.exchangeReason"
                      maxlength=100
                      type="textarea"></el-input>
          </el-form-item>
          <el-form-item label="是否撤销"
                        v-if="result.isFirstOrder === 0">
            <el-select :disabled="true"
                       v-model="result.isBack"
                       placeholder="请选择">
              <el-option label="否"
                         :value="0"></el-option>
              <el-option label="是"
                         :value="1"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="撤销原因"
                        v-if="result.isFirstOrder === 0">
            <el-input :disabled="true"
                      v-model.trim="result.backReason"
                      maxlength=100
                      type="textarea"></el-input>
          </el-form-item>
          <el-form-item label="是否有钥匙"
                        prop="hasKey">
            <el-select :disabled="true"
                       v-model="result.hasKey"
                       placeholder="请选择">
              <el-option label="否"
                         value="0"></el-option>
              <el-option label="是"
                         value="1"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="供应商"
                        prop="supplierId">
            <el-select :disabled="true"
                       v-model="result.supplierId"
                       placeholder="请选择">
              <el-option v-for="(item,index) in supplierIdList"
                         :key="index"
                         :label="item.value"
                         :value="item.key">

              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="资产保全要求"
                        prop="protectRequirements">
            <el-input :disabled="true"
                      v-model.trim="result.protectRequirements"
                      maxlength=100
                      type="textarea"></el-input>
          </el-form-item>
          <el-form-item label="车辆停放地"
                        prop="carStopPlace">
            <el-input v-model="result.carStopPlace"
                      disabled></el-input>
          </el-form-item>
          <el-form-item label="入库时间"
                        prop="storageDate">
            <el-date-picker size="mini"
                            disabled
                            v-model="result.storageDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="上牌时间">
            <el-date-picker size="mini"
                            disabled
                            v-model="result.carNoDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="停放SP处">
            <el-input v-model="result.carStopDealer"
                      disabled></el-input>
          </el-form-item>
          <el-form-item label="提车电话"
                        prop="buyCarPhone">
            <el-input v-model="result.buyCarPhone"
                      disabled></el-input>
          </el-form-item>
          <el-form-item label="回款类型">
            <el-select v-model="result.receivableStatus"
                       disabled>
              <el-option label="未回款"
                         :value="0"></el-option>
              <el-option label="回款逾期金额"
                         :value="1"></el-option>
              <el-option label="回款结清金额"
                         :value="2"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="文件列表：">
            <!-- v-for 返回的下载列表 -->
            <div v-for="(item,index) in fileList"
                 :key="index">
              <span>{{item.fileName}}</span>
              <el-button type="text"
                         @click="down(item)">下载</el-button>
              <!-- <el-button type="text" @click="del(index)">删除</el-button> -->
            </div>
          </el-form-item>
          <!-- <el-form-item label="是否撤销">
            <el-select :disabled="!detailFlag" v-model="result.isBack" placeholder="请选择">
              <el-option label="否" value="0"></el-option>
              <el-option label="是" value="1"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="撤销原因">
            <el-input :disabled="!detailFlag" v-model.trim="result.backReason" maxlength=100 type="textarea"></el-input>
          </el-form-item> -->
        </el-form>
      </div>
    </div>

    <!-- 处理记录 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">处理记录</span>
      </div>
      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading"
                    :data="processRecords"
                    border
                    style="width: 100%">
            <el-table-column label="序号"
                             align="center"
                             type="index"
                             width="50"></el-table-column>
            <el-table-column prop="processUsername"
                             label="处理人员"
                             align="center"></el-table-column>
            <el-table-column label="处理日期"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.processDate | formatDate('yyyy-MM-dd hh:mm:ss')}}
              </template>
            </el-table-column>
            <el-table-column prop="processWay"
                             label="处理方式"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.processWay || '/'}}
              </template>
            </el-table-column>
            <el-table-column prop="processRequirements"
                             label="处理要求"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.processRequirements || '/'}}
              </template>
            </el-table-column>
            <el-table-column prop="acceptStatus"
                             label="是否受理"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.acceptStatus || '/'}}
              </template>
            </el-table-column>
            <el-table-column prop="supplierName"
                             label="受理供应商"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.supplierName || '/'}}
              </template>
            </el-table-column>
            <el-table-column prop="processNode"
                             label="处理节点"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.processNode || '/'}}
              </template>
            </el-table-column>
            <el-table-column prop="processResult"
                             label="处理结果"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.processResult || '/'}}
              </template>
            </el-table-column>
            <el-table-column prop="reason"
                             label="备注"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.reason || '/'}}
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <!-- 处理记录 end -->

    <!-- 客户电话信息 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">客户电话信息</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading"
                    :data="contacts"
                    border
                    style="width: 100%">
            <el-table-column label="序号"
                             type="index"
                             align="center"
                             width="100"></el-table-column>
            <el-table-column prop="typeDesc"
                             label="电话类型"
                             align="center"></el-table-column>
            <el-table-column prop="customerName"
                             label="客户名称"
                             align="center"></el-table-column>
            <el-table-column prop="phone"
                             label="电话号码"
                             align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <div class="modular-box">
      <div v-if='detailFlag'
           class="modular-box-form">
        <el-form :model="audit"
                 :rules="auditRules"
                 ref="audit"
                 :inline="true"
                 size="small"
                 label-position="top">
          <el-form-item prop="auditStatus"
                        label="审核结果选择">
            <el-select v-model="audit.auditStatus"
                       placeholder="请选择">
              <el-option label="审核通过"
                         value="1"></el-option>
              <el-option label="审核退回"
                         value="2"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item prop="reason"
                        label="审核备注">
            <el-input v-model.trim="audit.reason"
                      type="textarea"
                      maxlength=100></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 处理记录 end -->

    <div class="submit-btn">
      <el-button v-if="detailFlag"
                 :plain="true"
                 @click="submitValidateFun()"
                 type="primary">提 交</el-button>
      <el-button @click="pageBack()">返 回</el-button>
    </div>

  </div>

</template>

<script>
import baseInfo from '../../../components/baseInfo2.0'
import apiHost from '../../../config/apiHost'
import api from '../../../api2.0/assets/sendOrdersAudit/index'
export default {
  components: {
    baseInfo
  },
  data () {
    // 金额校验规则
    // const temp = /^\d+\.?\d{0,3}$/
    // const validAmount = (rule, value, callback) => {
    //   if (value === '') {
    //     callback(new Error('请填写预计费用'))
    //   } else if (Number(value) === 0) {
    //     callback(new Error('预计费用不能为0'))
    //   } else if (!temp.test(value)) {
    //     callback(new Error('请输入正确的费用'))
    //   } else {
    //     callback()
    //   }
    // }
    return {
      supplierIdList: [],
      fileList: [], // 下载文件列表
      upLoadUrl: `${apiHost.basePath}/file/upload`,
      loading: true,
      uploading: false,
      detailFlag: false, // 是否可编辑Flag
      basicInfo: {}, // 基本信息
      processRecords: [], // 处理记录
      contacts: [], // 客户电话信息
      getDict: [], // 家访公司选择下拉菜单
      // 提交信息
      result: {
        id: '',
        backReason: '',
        carDetailedFileList: '',
        exchangeReason: '',
        expectFee: '',
        gpsLocation: '',
        gpsStatus: 0,
        hasKey: '',
        isBack: '',
        isExchange: '',
        otherRequirements: '',
        protectRequirements: '',
        supplierId: '',
        time: [],
        entrustStartTime: '',
        entrustEndTime: '',
        carStopPlace: '', // 车辆停放地
        storageDate: '', // 入库时间
        carNoDate: '', // 上牌时间
        carStopDealer: '', // 停放SP处
        buyCarPhone: '', // 提车电话
        receivableStatus: '' // 回款类型
      },
      rules: {
        supplierId: [{ required: true, trigger: 'change', message: '请选择资产保全委托期限' }],
        hasKey: [{ required: true, trigger: 'change', message: '请选择是否有钥匙' }],
        visitRequirements: [{ required: true, trigger: 'blur', message: '请填写资产保全要求' }]
      },
      // 提交审核
      audit: {
        code: '',
        desc: '',
        auditStatus: '',
        reason: '',
        id: ''
      },
      auditStatusMap: {
        1: '审核通过',
        2: '审核退回'
      },
      auditRules: {
        auditStatus: [{ required: true, trigger: 'change', message: '请选择审核结果' }],
        reason: [{ required: true, trigger: 'blur', message: '请填写审核备注' }]
      }
    }
  },
  created () {
    this.getSupplier()
  },
  mounted () {
    if (this.$route.query.detailFlag.toString() === 'true') {
      this.detailFlag = true
    }
    this.getDetailFun()
  },
  methods: {
    down (item) {
      window.location.href = apiHost.basePath + '/file/singleDownload' + '?url=' + item.url
      // window.location.href = `http://d1-managerdaikuan.2345.com/asset-service` + '/file/singleDownload' + '?url=' + item.url
    },
    del (index) {
      console.log(index)
      this.fileList.splice(index, 1)
    },
    // 获取定位
    async fetchGps () {
      const data = {
        applyId: this.$route.query.id
      }
      let res = this.$api.gpsInfo(data)
      if (res) {
        this.result.gpsLocation = res
      }
    },
    // 获取详情信息
    async getDetailFun () {
      try {
        let res = await api.detail({
          sendOrderId: this.$route.query.id
        })
        this.basicInfo = res.basicInfo
        this.processRecords = res.processRecords
        this.contacts = res.contacts
        const businessInfo = res.businessInfo
        const { entrustStartTime, entrustEndTime, isExchange, hasKey, supplierId, carDetailedFileList } = businessInfo
        if (carDetailedFileList) {
          let carDetailedFileListARR = carDetailedFileList.split(',')
          carDetailedFileListARR.forEach(t => {
            let fileName = t.match(/@(\S*)/)[1]
            this.fileList.push({
              url: t,
              fileName: fileName
            })
          })
        }
        this.result = {
          ...businessInfo,
          time: entrustStartTime && entrustEndTime ? [entrustStartTime, entrustEndTime] : [],
          hasKey: hasKey.toString(),
          isExchange: isExchange.toString(),
          supplierId: supplierId ? supplierId.toString() : null
        }
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 获取时间
    getTimeFun (value) {
      this.result.visitStartTime = value[0]
      this.result.visitEndTime = value[1]
    },
    // 提交校验
    submitValidateFun () {
      this.$refs['audit'].validate(async (valid) => {
        if (valid) {
          try {
            let str = '确认' + this.auditStatusMap[this.audit.auditStatus] + '+' + this.audit.reason + '?'
            let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '确定' })
            if (confirm) {
              this.submitFun()
            }
          } catch (error) {

          }
        }
      })
    },
    // 提交
    async submitFun () {
      let data = {
        ...this.audit,
        id: this.$route.query.id
      }
      let res = await api.submit(data)
      console.log(res)
      if (res) {
        this.$message.success('提交成功')
        this.pageBack()
      } else {
        this.$message.error('提交失败')
      }
    },
    // 获取家访公司列表
    async getDictFun () {
      let res = await this.$api.getDict()
      this.getDict = res.supplierList
    },
    async getSupplier () {
      let res = await this.$api.getSupplier()
      this.supplierIdList = res.supplierList
    },
    // 返回上一页
    pageBack () {
      window.history.back('-1')
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
