<template>
  <div class="main-con">
    <!-- 基本信息 begin -->
    <baseInfo :basicInfo='basicInfo'
              :loading='loading'></baseInfo>
    <!-- 基本信息 end -->

    <div class="modular-box">
      <div class="modular-box-form">
        <el-form :model="result"
                 :rules="rules"
                 ref="audit"
                 :inline="true"
                 size="mini"
                 label-position="top">
          <el-form-item prop="time"
                        label="资产保全委托期限">
            <el-date-picker disabled
                            size="mini"
                            v-model="result.time"
                            type="daterange"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>

          <el-form-item prop=""
                        label=" ">
            <el-button type="primary"
                       :disabled="!detailFlag"
                       @click="fetchGps">定位</el-button>

          </el-form-item>

          <el-form-item prop="gpsLocation"
                        label="最后定位地址">
            <el-input :disabled="true"
                      v-model.trim="result.gpsLocation"></el-input>
          </el-form-item>
          <el-form-item label="是否有钥匙"
                        prop="hasKey">
            <el-select :disabled="true"
                       v-model="result.hasKey"
                       placeholder="请选择">
              <el-option label="否"
                         value="0"></el-option>
              <el-option label="是"
                         value="1"></el-option>
            </el-select>
          </el-form-item>
          <!-- <el-form-item label="供应商" prop="supplierId">
            <el-select :disabled="!detailFlag" v-model="result.supplierId" placeholder="请选择">
              <el-option
              v-for="(item,index) in supplierIdList"
              :key="index"
              :label="item.value"
              :value="item.key"
              >

              </el-option>
            </el-select>
          </el-form-item> -->
          <el-form-item label="资产保全要求"
                        prop="protectRequirements">
            <el-input :disabled="true"
                      v-model.trim="result.protectRequirements"
                      maxlength=100
                      type="textarea"></el-input>
          </el-form-item>
          <el-form-item label="车辆停放地"
                        prop="carStopPlace">
            <el-input v-model="result.carStopPlace"
                      disabled></el-input>
          </el-form-item>
          <el-form-item label="入库时间"
                        prop="storageDate">
            <el-date-picker size="mini"
                            disabled
                            v-model="result.storageDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="上牌时间">
            <el-date-picker size="mini"
                            disabled
                            v-model="result.carNoDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="停放SP处">
            <el-input v-model="result.carStopDealer"
                      disabled></el-input>
          </el-form-item>
          <el-form-item label="提车电话"
                        prop="buyCarPhone">
            <el-input v-model="result.buyCarPhone"
                      disabled></el-input>
          </el-form-item>
          <el-form-item label="回款类型">
            <el-select v-model="result.receivableStatus"
                       disabled>
              <el-option label="未回款"
                         :value="0"></el-option>
              <el-option label="回款逾期金额"
                         :value="1"></el-option>
              <el-option label="回款结清金额"
                         :value="2"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div style="display:inline-block;padding-bottom:20px;min-width:800px">
          <el-button type="primary"
                     size="mini"><a href="javascript:;"
               @click="down('carCollectReportFile')">《车辆回收报告》下载</a></el-button>
          <el-button type="primary"
                     size="mini"><a href="javascript:;"
               @click="down('carBasicDescFile')">《车辆基本情况描述》下载</a></el-button>
          <el-button type="primary"
                     size="mini"><a href="javascript:;"
               @click="down('carFinanceReportFile')">《车辆入库及财务交接清单》下载</a></el-button>
          <el-button type="primary"
                     size="mini"><a href="javascript:;"
               @click="down('carGiveUpFile')">车辆自愿放弃声明》下载</a></el-button>
          <el-button type="primary"
                     size="mini"
                     @click="downFileList()">《资料清单》下载</el-button>

          <!-- <a href="../../../../public/template/">《资料清单》下载</a> -->
        </div>
        <!-- <p style="color:red">授权委托书要带电子章</p> -->
      </div>
    </div>
    <!-- 客户电话信息 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">客户电话信息</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading"
                    :data="contacts"
                    border
                    style="width: 100%">
            <el-table-column label="序号"
                             type="index"
                             align="center"
                             width="100"></el-table-column>
            <el-table-column prop="typeDesc"
                             label="电话类型"
                             align="center"></el-table-column>
            <el-table-column prop="customerName"
                             label="客户名称"
                             align="center"></el-table-column>
            <el-table-column prop="phone"
                             label="电话号码"
                             align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">资产保全受理信息</span>
      </div>
      <div class="modular-box-form">
        <el-form :model="audit"
                 :rules="auditRules"
                 ref="audit"
                 :inline="true"
                 size="mini"
                 label-position="top">
          <el-form-item prop="estimateArriveDate"
                        label="预计上门时间">
            <el-date-picker :disabled="!detailFlag"
                            size="mini"
                            v-model="audit.estimateArriveDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>

          <el-form-item prop="collectUser"
                        label="收车人员">
            <el-input :disabled="!detailFlag"
                      v-model.trim="audit.collectUser"></el-input>

          </el-form-item>

          <el-form-item prop="collectUserPhone"
                        label="收车人电话">
            <el-input :disabled="!detailFlag"
                      v-model.trim="audit.collectUserPhone"></el-input>
          </el-form-item>
          <el-form-item prop="estimateCollectDate"
                        label="预计收车时间">
            <el-date-picker :disabled="!detailFlag"
                            size="mini"
                            v-model="audit.estimateCollectDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>

          <!-- <el-form-item label="出发省份" prop="fromProvinceId">
            <el-select :disabled="!detailFlag" v-model="result.fromProvinceId" placeholder="请选择">
              <el-option label="否" value="0"></el-option>
              <el-option label="是" value="1"></el-option>
            </el-select>
          </el-form-item> -->
          <el-form-item label="出发省份-城市"
                        prop="fromCities"
                        v-if="cityTree && cityTree.length">
            <el-cascader :disabled="!detailFlag"
                         filterable
                         expand-trigger="hover"
                         clearable
                         :props="bankCityProps"
                         :options="cityTree[0].cityList"
                         v-model="audit.fromCities"
                         @change="bankCityChange">
            </el-cascader>
          </el-form-item>
          <el-form-item label=" "
                        prop="">
            <!-- <el-select :disabled="!detailFlag" v-model="result.fromCityId" placeholder="请选择">
              <el-option label="否" value="0"></el-option>
              <el-option label="是" value="1"></el-option>
            </el-select> -->
          </el-form-item>
          <el-form-item label="资产保全省份-城市"
                        prop="protectCities"
                        v-if="cityTree && cityTree.length">
            <el-cascader filterable
                         :disabled="!detailFlag"
                         expand-trigger="hover"
                         clearable
                         :props="bankCityProps"
                         :options="cityTree[0].cityList"
                         v-model="audit.protectCities">
            </el-cascader>
          </el-form-item>
          <!-- <el-form-item label="资产保全省份" prop="protectProvinceId">
            <el-select :disabled="!detailFlag" v-model="audit.protectProvinceId" placeholder="请选择">
              <el-option label="否" value="0"></el-option>
              <el-option label="是" value="1"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="资产保全城市" prop="protectCityId">
            <el-select :disabled="!detailFlag" v-model="audit.protectCityId" placeholder="请选择">
              <el-option label="否" value="0"></el-option>
              <el-option label="是" value="1"></el-option>
            </el-select>
          </el-form-item> -->

          <el-form-item label="预计里程"
                        prop="estimateDistance">
            <el-input :disabled="!detailFlag"
                      v-model.trim="audit.estimateDistance"></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 处理记录 end -->
    <div class="submit-btn">
      <el-button v-if="detailFlag"
                 :plain="true"
                 @click="submitValidateFun()"
                 type="primary">受理</el-button>
      <el-button v-if="detailFlag"
                 :plain="true"
                 @click="reuse()"
                 type="primary">拒绝</el-button>
      <el-button @click="pageBack()">返 回</el-button>
    </div>

  </div>

</template>

<script>
// import { amount } from '../../../filters/index.js'
import baseInfo from '../../../components/baseInfo2.0'
import apiHost from '../../../config/apiHost'
import api from '../../../api2.0/assets/acceptance/index'
import cityTreeMixin from '../../../mixins/cityTreeMixin'
export default {
  components: {
    baseInfo
  },
  mixins: [cityTreeMixin],
  data () {
    // 金额校验规则
    // const temp = /^\d+\.?\d{0,3}$/
    // const validAmount = (rule, value, callback) => {
    //   if (value === '') {
    //     callback(new Error('请填写预计费用'))
    //   } else if (Number(value) === 0) {
    //     callback(new Error('预计费用不能为0'))
    //   } else if (!temp.test(value)) {
    //     callback(new Error('请输入正确的费用'))
    //   } else {
    //     callback()
    //   }
    // }
    return {
      bankCityProps: {
        value: 'currentKey',
        label: 'cityName',
        children: 'cityList'
      },
      loading: true,
      detailFlag: false, // 是否可编辑Flag
      basicInfo: {}, // 基本信息
      processRecords: [], // 处理记录
      contacts: [], // 客户电话信息
      getDict: [], // 家访公司选择下拉菜单
      // 提交信息
      result: {
        id: '',
        backReason: '',
        carDetailedFileList: '',
        exchangeReason: '',
        expectFee: '',
        gpsLocation: '',
        gpsStatus: 0,
        hasKey: '',
        isBack: '',
        isExchange: '',
        otherRequirements: '',
        protectRequirements: '',
        supplierId: '',
        time: [],
        entrustStartTime: '',
        entrustEndTime: '',
        carStopPlace: '', // 车辆停放地
        storageDate: '', // 入库时间
        carNoDate: '', // 上牌时间
        carStopDealer: '', // 停放SP处
        buyCarPhone: '', // 提车电话
        receivableStatus: '' // 回款类型
      },
      rules: {
        // supplierId: [{ required: true, trigger: 'change', message: '请选择资产保全委托期限' }],
        hasKey: [{ required: true, trigger: 'none', message: '请选择是否有钥匙' }],
        protectRequirements: [{ required: true, trigger: 'blur', message: '请填写资产保全要求' }],
        time: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value || !value.length) {
                callback(new Error('请选择'))
              } else {
                callback()
              }
            }
          }
        ]
      },
      // 提交审核
      audit: {
        collectUser: '',
        collectUserPhone: '',
        estimateArriveDate: '',
        estimateCollectDate: '',
        estimateDistance: '',
        fromCityId: '',
        fromProvinceId: '',
        protectCityId: '',
        protectProvinceId: '',
        fromCities: [],
        protectCities: []
      },
      auditStatusMap: {
        1: '审核通过',
        2: '审核退回'
      },
      auditRules: {
        collectUser: [{ required: true, trigger: 'change', message: '请填收车人员' }],
        collectUserPhone: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value || !/^[0-9]*$/.test(value)) {
                callback(new Error('请填写正确格式的收车人电话'))
              } else {
                callback()
              }
            }
          }
        ],
        estimateArriveDate: [{ required: true, trigger: 'blur', message: '请填预计上门时间' }],
        estimateCollectDate: [{ required: true, trigger: 'blur', message: '请填预计收车时间' }],
        estimateDistance: [{ required: true, trigger: 'blur', message: '请填预计里程' }],
        fromCityId: [{ required: true, trigger: 'blur', message: '请填出发城市' }],
        fromProvinceId: [{ required: true, trigger: 'blur', message: '请填出发省份' }],
        protectCityId: [{ required: true, trigger: 'blur', message: '请填资产保全城市' }],
        protectProvinceId: [{ required: true, trigger: 'blur', message: '请填资产保全省份' }],
        fromCities: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value.length) {
                callback(new Error('请选择出发省份-城市'))
              } else {
                callback()
              }
            }
          }
        ],
        protectCities: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value.length) {
                callback(new Error('请选择资产保全省份-城市'))
              } else {
                callback()
              }
            }
          }
        ]
      }
    }
  },
  mounted () {
    if (this.$route.query.detailFlag.toString() === 'true') {
      this.detailFlag = true
    }
    this.getDictFun()
    this.getDetailFun()
  },
  methods: {
    async downFileList () {
      if (!this.result.carDetailedFileList) {
        this.$message.error('下载文件为空')
      } else {
        window.location.href = apiHost.basePath + '/file/batchZipDownload' + '?urls=' + this.result.carDetailedFileList + '&downloadZipFileName=' + '资料清单'
      }
    },
    down (item) {
      window.location.href = apiHost.basePath + '/file/singleDownload' + '?url=' + this.result[item]
    },
    // 获取定位
    async fetchGps () {
      try {
        this.uploading = true
        const data = {
          applyId: this.basicInfo.applyId
          // applyId: '197911'
        }
        let res = await this.$api.gpsInfo(data)
        this.result.gpsLocation = res.locationAdd
        this.result.gpsStatus = res.activationStatus
      } finally {
        setTimeout(() => {
          this.uploading = false
        }, 500)
      }
    },
    // 获取详情信息
    async getDetailFun () {
      try {
        let res = await api.detail({
          acceptOrderId: this.$route.query.id
        })
        this.basicInfo = res.basicInfo
        this.processRecords = res.processRecords
        this.contacts = res.contacts
        const businessInfo = res.businessInfo
        const { entrustStartTime, entrustEndTime, hasKey, supplierId } = businessInfo

        this.result = {
          ...businessInfo,
          time: entrustStartTime && entrustEndTime ? [entrustStartTime, entrustEndTime] : [],
          hasKey: hasKey.toString(),
          // isBack: isBack.toString(),
          // isExchange: isExchange.toString(),
          supplierId: supplierId ? supplierId.toString() : null

        }
        this.audit = {
          collectUser: businessInfo.collectUser,
          collectUserPhone: businessInfo.collectUserPhone,
          estimateArriveDate: businessInfo.estimateArriveDate,
          estimateCollectDate: businessInfo.estimateCollectDate,
          estimateDistance: businessInfo.estimateDistance,
          fromCityId: businessInfo.fromCityId,
          fromProvinceId: businessInfo.fromProvinceId,
          protectCityId: businessInfo.protectCityId,
          protectProvinceId: businessInfo.protectProvinceId,
          fromCities: [businessInfo.fromProvinceId, businessInfo.fromCityId],
          protectCities: [businessInfo.protectProvinceId, businessInfo.protectCityId]
        }
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    bankCityChange (val) { //  城市发生改变
      console.log(val[1])
      console.log(this.audit.fromCities)
    },
    // 获取时间
    getTimeFun (value) {
      this.result.visitStartTime = value[0]
      this.result.visitEndTime = value[1]
    },
    async  reuse () {
      try {
        let str = '确认拒绝吗？'
        let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '确定' })
        if (confirm) {
          let data = {
            acceptOrderId: this.$route.query.id
          }
          let res = api.refuse(data)
          if (res) {
            this.$message.success('拒绝成功')
            this.pageBack()
          } else {
            this.$message.error('拒绝失败')
          }
        }
      } catch (error) {

      }
    },
    // 提交校验
    submitValidateFun () {
      this.$refs['audit'].validate(async (valid) => {
        if (valid) {
          try {
            let str = '确认提交吗？'
            let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '确定' })
            if (confirm) {
              this.submitFun()
            }
          } catch (error) {

          }
        }
      })
    },
    // 提交
    async submitFun () {
      this.audit.id = this.$route.query.id
      let data = {
        ...this.audit,
        fromProvinceId: this.audit.fromCities[0],
        fromCityId: this.audit.fromCities[1],
        protectProvinceId: this.audit.protectCities[0],
        protectCityId: this.audit.protectCities[1],
        gpsLocation: this.result.gpsLocation,
        gpsStatus: this.result.gpsStatus
      }
      console.log(this.audit, data)
      let res = await api.submit(data)
      if (res) {
        this.$message.success('提交成功')
        this.pageBack()
      } else {
        this.$message.error('提交失败')
      }
    },
    // 获取家访公司列表
    async getDictFun () {
      let res = await this.$api.getDict()
      this.getDict = res.supplierList
    },
    async getSupplier () {
      let res = await this.$api.getSupplier()
      this.supplierIdList = res.supplierList
    },
    // 返回上一页
    pageBack () {
      window.history.back('-1')
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
