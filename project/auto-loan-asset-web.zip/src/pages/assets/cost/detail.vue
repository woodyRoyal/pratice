<template>
  <div class="main-con">
    <!-- 基本信息 begin -->
    <baseInfo :basicInfo='basicInfo'
              :loading='loading'></baseInfo>
    <!-- 基本信息 end -->

    <div class="modular-box">
      <div class="modular-box-form">
        <el-form :model="result"
                 :rules="rules"
                 ref="result"
                 :inline="true"
                 size="mini"
                 label-position="top">
          <el-form-item prop="time"
                        label="资产保全委托期限">
            <el-date-picker disabled
                            size="mini"
                            v-model="result.time"
                            type="daterange"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <!-- <el-form-item prop="carStopCityId" label="车辆停放城市">
            <el-input :disabled="true" v-model.trim="result.carStopCityId" ></el-input>
          </el-form-item> -->
          <el-form-item label="车辆停放城市"
                        prop="carStopCityId"
                        v-if="cityTree && cityTree.length">
            <el-cascader filterable
                         :disabled="true"
                         expand-trigger="hover"
                         clearable
                         :props="bankCityProps"
                         :options="cityTree[0].cityList"
                         v-model="result.carStopCityId">
            </el-cascader>
          </el-form-item>
          <el-form-item prop="gpsLocation"
                        label="最后定位地址">
            <el-input :disabled="true"
                      v-model.trim="result.gpsLocation"></el-input>
          </el-form-item>

          <el-form-item label="是否有钥匙"
                        prop="hasKey">
            <el-select :disabled="true"
                       v-model="result.hasKey"
                       placeholder="请选择">
              <el-option label="否"
                         :value="0"></el-option>
              <el-option label="是"
                         :value="1"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="回款类型"
                        prop="receivableStatus">
            <el-select :disabled="true"
                       v-model="result.receivableStatus"
                       placeholder="请选择">
              <el-option label="无回款"
                         :value="0"></el-option>
              <el-option label="回款结清金额"
                         :value="1"></el-option>
              <el-option label="回款逾期金额"
                         :value="2"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="是否改派">
            <el-select :disabled="true"
                       v-model="result.isExchange"
                       placeholder="请选择">
              <el-option label="否"
                         :value="0"></el-option>
              <el-option label="是"
                         :value="1"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="改派原因">
            <el-input :disabled="true"
                      v-model.trim="result.exchangeReason"
                      maxlength=100
                      type="textarea"></el-input>
          </el-form-item>

          <el-form-item label="其他费用"
                        prop="otherCost">
            <el-input :disabled="true"
                      v-model.trim="result.otherCost"
                      maxlength=100></el-input>
          </el-form-item>

          <el-form-item label="实际费用"
                        prop="actualCost">
            <el-input :disabled="true"
                      v-model.trim="result.actualCost"
                      maxlength=100></el-input>
          </el-form-item>
          <el-form-item label="资产保全要求"
                        prop="protectRequirements">
            <el-input :disabled="true"
                      v-model.trim="result.protectRequirements"
                      maxlength=100
                      type="textarea"></el-input>
          </el-form-item>

          <el-form-item label="资产保全供应商"
                        prop="supplierName">
            <el-input :disabled="true"
                      v-model.trim="result.supplierName"
                      maxlength=100></el-input>
          </el-form-item>

          <el-form-item label="车辆停放地"
                        prop="carStopPlace">
            <el-input v-model="result.carStopPlace"
                      disabled></el-input>
          </el-form-item>
          <el-form-item label="入库时间"
                        prop="storageDate">
            <el-date-picker size="mini"
                            disabled
                            v-model="result.storageDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="上牌时间">
            <el-date-picker size="mini"
                            disabled
                            v-model="result.carNoDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="停放SP处">
            <el-input v-model="result.carStopDealer"
                      disabled></el-input>
          </el-form-item>
          <el-form-item label="提车电话"
                        prop="buyCarPhone">
            <el-input v-model="result.buyCarPhone"
                      disabled></el-input>
          </el-form-item>

          <el-form-item label=" ">
            <el-upload :loading="uploading"
                       class="upload-demo"
                       :action="upLoadUrl"
                       :show-file-list="false"
                       name="fileName"
                       :disabled="true"
                       :on-success="carGiveupFile"
                       :on-error="handleUploadError"
                       :before-upload="beforeUpload">
              <el-button size="small"
                         type="primary">《车辆自愿放弃声明》下载</el-button>
            </el-upload>
            <div v-for="(item,index) in fileList.carGiveupFile"
                 :key="index">
              <span>{{item.fileName}}</span>
              <el-button type="text"
                         @click="down(item,'carGiveupFile')">下载</el-button>
              <!-- <el-button type="text" @click="del(index,'carGiveupFile')">删除</el-button> -->
            </div>
          </el-form-item>

          <el-form-item label=" ">
            <el-upload :loading="uploading"
                       class="upload-demo"
                       :action="upLoadUrl"
                       :show-file-list="false"
                       name="fileName"
                       :disabled="true"
                       :on-success="carFinanceRegisterFile"
                       :on-error="handleUploadError"
                       :before-upload="beforeUpload">
              <el-button size="small"
                         type="primary">《车辆入库及财务交接清单》下载</el-button>
            </el-upload>
            <div v-for="(item,index) in fileList.carFinanceRegisterFile"
                 :key="index">
              <span>{{item.fileName}}</span>
              <el-button type="text"
                         @click="down(item,'carFinanceRegisterFile')">下载</el-button>
              <!-- <el-button type="text" @click="del(index,'carFinanceRegisterFile')">删除</el-button> -->
            </div>
          </el-form-item>
          <el-form-item label=" ">
            <el-upload :loading="uploading"
                       class="upload-demo"
                       :action="upLoadUrl"
                       :show-file-list="false"
                       name="fileName"
                       disabled
                       :on-success="carCollectFile"
                       :on-error="handleUploadError"
                       :before-upload="beforeUpload">
              <el-button size="small"
                         type="primary">《车辆回收报告》下载</el-button>
            </el-upload>
            <div v-for="(item,index) in fileList.carCollectFile"
                 :key="index">
              <span>{{item.fileName}}</span>
              <el-button type="text"
                         @click="down(item,'carCollectFile')">下载</el-button>
              <!-- <el-button type="text" @click="del(index,'carCollectFile')">删除</el-button> -->
            </div>
          </el-form-item>
          <el-form-item label=" ">
            <el-upload :loading="uploading"
                       class="upload-demo"
                       :action="upLoadUrl"
                       :show-file-list="false"
                       name="fileName"
                       :disabled="true"
                       :on-success="carBasicFile"
                       :on-error="handleUploadError"
                       :before-upload="beforeUpload">
              <el-button size="small"
                         type="primary">《车辆基本情况描述》下载</el-button>
            </el-upload>
            <div v-for="(item,index) in fileList.carBasicFile"
                 :key="index">
              <span>{{item.fileName}}</span>
              <el-button type="text"
                         @click="down(item,'carBasicFile')">下载</el-button>
              <!-- <el-button type="text" @click="del(index,'carBasicFile')">删除</el-button> -->
            </div>
          </el-form-item>

        </el-form>
        <!-- <div style="display:inline-block;padding-bottom:20px;min-width:800px">
           <el-button type="primary" size="mini">《车辆回收报告》下载</el-button>
            <el-button type="primary" size="mini">《车辆基本情况描述》下载</el-button>
            <el-button type="primary" size="mini">《车辆入库及财务交接清单》下载</el-button>
            <el-button type="primary" size="mini">《车辆自愿放弃声明》下载</el-button>
            <el-button type="primary" size="mini">《授权委托书下载》下载</el-button>
            <el-button type="primary" size="mini">《资料清单》下载</el-button>
        </div>
        <p style="color:red">授权委托书要带电子章</p> -->
      </div>
    </div>

    <!-- 车辆图片上传 -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">车辆图片查看</span>
      </div>

      <div class="modular-box-tb">
        <el-form :disabled="false"
                 label-position="top"
                 ref="fileForm"
                 :inline="true">
          <el-form-item v-for="(attach, index) in attachInfo"
                        :key="index"
                        class="img-box">
            <!-- <div> -->
            <picUpload :attach="attach"
                       :editable="false"
                       @preView="handlePictureCardPreview" />
            <div class="label-text"
                 style="width:300px;"><i v-if="attach.required"
                 class="required-icon">*</i>{{attach.name}}</div>
            <!-- </div> -->
          </el-form-item>
        </el-form>
      </div>
    </div>
    <el-dialog :visible.sync="showPreview"
               size="tiny"
               :modal-append-to-body="false">
      <img width="100%"
           :src="dialogImageUrl"
           alt="">
    </el-dialog>

    <!-- 车辆图片上传 -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">车辆图片下载</span>
      </div>

      <div class="modular-box-tb">
        <el-form :disabled="false"
                 label-position="top"
                 ref="fileForm"
                 :inline="true">
          <el-checkbox-group v-model="checkList"
                             style="margin-top:30px;margin-left:10px;">
            <el-checkbox v-for="(item,index) in attachInfoFilter"
                         :key="index"
                         :label="item.name"></el-checkbox>
          </el-checkbox-group>
        </el-form>
        <div class="submit-btn"
             style="margin-top:30px;">
          <el-button @click="dowmPic()"
                     type="success"
                     style="margin-bottom:30px;">点击下载</el-button>
        </div>
      </div>
    </div>
    <!-- 客户电话信息 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">客户电话信息</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading"
                    :data="contacts"
                    border
                    style="width: 100%">
            <el-table-column label="序号"
                             type="index"
                             align="center"
                             width="100"></el-table-column>
            <el-table-column prop="typeDesc"
                             label="电话类型"
                             align="center"></el-table-column>
            <el-table-column prop="customerName"
                             label="客户名称"
                             align="center"></el-table-column>
            <el-table-column prop="phone"
                             label="电话号码"
                             align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">资产保全受理信息</span>
      </div>
      <div class="modular-box-form">
        <el-form :model="audit"
                 :rules="auditRules"
                 ref="audit"
                 :inline="true"
                 size="mini"
                 label-position="top">
          <el-form-item prop="estimateArriveDate"
                        label="预计上门时间">
            <el-date-picker size="mini"
                            :disabled="true"
                            v-model="audit.estimateArriveDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item prop="collectUser"
                        label="资产保全人员">
            <el-input :disabled="true"
                      v-model.trim="audit.collectUser"></el-input>

          </el-form-item>
          <!-- <el-form-item prop="collectUser" label="收车人员">
            <el-input :disabled="true" v-model.trim="audit.collectUser" ></el-input>

          </el-form-item> -->

          <!-- <el-form-item prop="collectUserPhone" label="收车人电话">
            <el-input :disabled="true" v-model.trim="audit.collectUserPhone" ></el-input>
          </el-form-item> -->
          <el-form-item prop="collectUserPhone"
                        label="资产保全人电话">
            <el-input :disabled="true"
                      v-model.trim="audit.collectUserPhone"></el-input>
          </el-form-item>
          <!-- <el-form-item prop="estimateCollectDate" label="预计收车时间">
              <el-date-picker
                size="mini"
                v-model="audit.estimateCollectDate"
                range-separator="至"
                start-placeholder="开始日期"
                value-format="yyyy-MM-dd"
                end-placeholder="结束日期">
              </el-date-picker>
          </el-form-item> -->
          <el-form-item prop="visitTime"
                        label="上门时间">
            <el-date-picker size="mini"
                            :disabled="true"
                            v-model="audit.visitTime"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="出发省份-城市"
                        prop="fromCities"
                        v-if="cityTree && cityTree.length">
            <el-cascader :disabled="true"
                         expand-trigger="hover"
                         filterable
                         :props="bankCityProps"
                         :options="cityTree[0].cityList"
                         v-model="audit.fromCities">
            </el-cascader>
          </el-form-item>
          <el-form-item label=" "
                        prop="">
            <!-- <el-select :disabled="!detailFlag" v-model="result.fromCityId" placeholder="请选择">
              <el-option label="否" value="0"></el-option>
              <el-option label="是" value="1"></el-option>
            </el-select> -->
          </el-form-item>
          <el-form-item prop="estimateCollectDate"
                        label="预计资产保全时间">
            <el-date-picker size="mini"
                            :disabled="true"
                            v-model="audit.estimateCollectDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="资产保全省份-城市"
                        prop="protectCities"
                        v-if="cityTree && cityTree.length">
            <el-cascader :disabled="true"
                         expand-trigger="hover"
                         filterable
                         :props="bankCityProps"
                         :options="cityTree[0].cityList"
                         v-model="audit.protectCities">
            </el-cascader>
          </el-form-item>

          <el-form-item label="预计里程"
                        prop="estimateDistance">
            <el-input :disabled="true"
                      v-model.trim="audit.estimateDistance"></el-input>
          </el-form-item>

          <el-form-item prop="estimateCollectDate"
                        label="交接时间">
            <el-date-picker size="mini"
                            :disabled="true"
                            v-model="audit.estimateCollectDate"
                            range-separator="至"
                            start-placeholder="开始日期"
                            value-format="yyyy-MM-dd"
                            end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>

          <el-form-item label="实际里程"
                        prop="distance">
            <el-input :disabled="true"
                      v-model.trim="audit.distance"></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 处理记录 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">处理记录</span>
      </div>
      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading"
                    :data="processRecords"
                    border
                    style="width: 100%">
            <el-table-column label="序号"
                             align="center"
                             type="index"
                             width="50"></el-table-column>
            <el-table-column prop="processUsername"
                             label="处理人员"
                             align="center"></el-table-column>
            <el-table-column label="处理日期"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.processDate | formatDate('yyyy-MM-dd hh:mm:ss')}}
              </template>
            </el-table-column>
            <el-table-column prop="processWay"
                             label="处理方式"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.processWay || '/'}}
              </template>
            </el-table-column>
            <el-table-column prop="processRequirements"
                             label="处理要求"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.processRequirements || '/'}}
              </template>
            </el-table-column>
            <el-table-column prop="acceptStatus"
                             label="是否受理"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.acceptStatus || '/'}}
              </template>
            </el-table-column>
            <el-table-column prop="supplierName"
                             label="受理供应商"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.supplierName || '/'}}
              </template>
            </el-table-column>
            <el-table-column prop="processNode"
                             label="处理节点"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.processNode || '/'}}
              </template>
            </el-table-column>
            <el-table-column prop="processResult"
                             label="处理结果"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.processResult || '/'}}
              </template>
            </el-table-column>
            <el-table-column prop="reason"
                             label="备注"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.reason || '/'}}
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>

    <div class="modular-box">
      <div v-if='detailFlag'
           class="modular-box-form">
        <el-form :model="auditStatusForm"
                 :rules="auditStatusRule"
                 ref="auditStatusForm"
                 :inline="true"
                 size="small"
                 label-position="top">
          <el-form-item prop="auditStatus"
                        label="审核结果选择">
            <el-select v-model="auditStatusForm.auditStatus"
                       placeholder="请选择">
              <el-option label="审核通过"
                         value="1"></el-option>
              <el-option label="审核退回"
                         value="2"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item prop="reason"
                        label="审核备注">
            <el-input v-model.trim="auditStatusForm.reason"
                      type="textarea"
                      maxlength=100></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 处理记录 end -->

    <div class="submit-btn">
      <el-button v-if="detailFlag"
                 :plain="true"
                 @click="submitValidateFun()"
                 type="primary">提 交</el-button>
      <el-button @click="pageBack()">返 回</el-button>
    </div>

  </div>

</template>

<script>
import { amount, formatDate } from '../../../filters/index.js'
import baseInfo from '../../../components/baseInfo2.0'
import apiHost from '../../../config/apiHost'
import api from '../../../api2.0/assets/cost/index'
import picUpload from '../../../components/upload2.0/picUpload'
import cityTreeMixin from '../../../mixins/cityTreeMixin'
export default {
  components: {
    baseInfo,
    picUpload
  },
  mixins: [cityTreeMixin],
  data () {
    // 金额校验规则
    // const temp = /^\d+\.?\d{0,3}$/
    // const validAmount = (rule, value, callback) => {
    //   if (value === '') {
    //     callback(new Error('请填写预计费用'))
    //   } else if (Number(value) === 0) {
    //     callback(new Error('预计费用不能为0'))
    //   } else if (!temp.test(value)) {
    //     callback(new Error('请输入正确的费用'))
    //   } else {
    //     callback()
    //   }
    // }
    return {
      checkList: [], // 下载文件列表
      fileList: {
        // 车辆自愿放弃申明文件
        carGiveupFile: [],
        // 车辆入库及财务交接清单
        carFinanceRegisterFile: [],
        // 车辆回收报告
        carCollectFile: [],
        // 车辆基本情况描述
        carBasicFile: []

      },
      attachInfo: [
        {
          node: 'carFrontierFile',
          name: '车头照片',
          required: true,
          url: ''
        },
        {
          node: 'carEndFile',
          name: '车尾照片',
          required: true,
          url: ''
        },
        {
          node: 'carLeftBodyFile',
          name: '车身照片(左侧)',
          required: true,
          url: ''
        },
        {
          node: 'carRightBodyFile',
          name: '车身照片(右侧)',
          required: true,
          url: ''
        },
        {
          node: 'carInnerFile',
          name: '车厢',
          required: true,
          url: ''
        },
        {
          node: 'carOdometerFile',
          name: '里程表照片',
          required: true,
          url: ''
        },
        {
          node: 'carChairFile',
          name: '座椅',
          required: true,
          url: ''
        },
        {
          node: 'carDriveLicenseKeyFile',
          name: '行驶证原件+车钥匙拍照1份',
          required: true,
          url: ''
        },
        {
          node: 'carGiveupIdcardFile',
          name: '客户手持自弃协议+身份证与车辆合影(照片清晰，并显示拍照日期)',
          required: true,
          url: ''
        },
        {
          node: 'carAroundFile',
          name: '自弃车辆绕车视频(视频需见车辆行驶里程数、车钥匙插孔开门、车辆前后左右整体照片)',
          required: true,
          url: ''
        },
        {
          node: 'carOtherFile',
          name: '其他',
          required: false,
          url: ''
        }
      ], // 附件信息
      bankCityProps: {
        value: 'currentKey',
        label: 'cityName',
        children: 'cityList'
      },
      dialogImageUrl: '',
      showPreview: false,
      upLoadUrl: `${apiHost.basePath}/file/uploadV2`,
      loading: true,
      uploading: false,
      detailFlag: false, // 是否可编辑Flag
      basicInfo: {}, // 基本信息
      processRecords: [], // 处理记录
      contacts: [], // 客户电话信息
      getDict: [], // 家访公司选择下拉菜单
      auditStatusForm: {
        auditStatus: '',
        reason: ''
      },
      auditStatusRule: {
        auditStatus: [{ required: true, trigger: 'change', message: '请选择审核结果' }],
        reason: [{ required: true, trigger: 'blur', message: '请填写审核备注' }]
      },
      // 提交信息
      result: {
        id: '',
        receivableStatus: null,
        carStopCityId: [],
        backReason: '',
        carDetailedFileList: '',
        exchangeReason: '',
        expectFee: '',
        gpsLocation: '',
        gpsStatus: 0,
        hasKey: '',
        isBack: '',
        isExchange: '',
        otherRequirements: '',
        protectRequirements: '',
        supplierId: '',
        time: [],
        entrustStartTime: '',
        entrustEndTime: '',
        carStopPlace: '', // 车辆停放地
        storageDate: '', // 入库时间
        carNoDate: '', // 上牌时间
        carStopDealer: '', // 停放SP处
        buyCarPhone: '' // 提车电话
      },
      rules: {
        actualCost: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if ((!value && value !== 0) || !/^[0-9.]*$/.test(value)) {
                callback(new Error('请填写正确格式的费用'))
              } else {
                callback()
              }
            }
          }
        ],
        otherCost: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (value !== '' && value !== null && !/^[0-9.]*$/.test(value)) {
                callback(new Error('请填写正确格式的费用'))
              } else {
                callback()
              }
            }
          }
        ],
        carStopCityId: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value.length) {
                callback(new Error('请选择车辆投放城市'))
              } else {
                callback()
              }
            }
          }
        ],
        supplierId: [{ required: true, trigger: 'change', message: '请选择资产保全委托期限' }],
        hasKey: [{ required: true, trigger: 'change', message: '请选择是否有钥匙' }],
        protectRequirements: [{ required: true, trigger: 'blur', message: '请填写资产保全要求' }]
      },
      // 提交审核
      audit: {
        collectUser: '',
        collectUserPhone: '',
        estimateArriveDate: '',
        estimateCollectDate: '',
        estimateDistance: '',
        fromCityId: '',
        fromProvinceId: '',
        protectCityId: '',
        protectProvinceId: '',
        fromCities: [],
        protectCities: []
      },
      auditStatusMap: {
        1: '审核通过',
        2: '审核退回'
      },
      auditRules: {
        collectUser: [{ required: true, trigger: 'change', message: '请填收车人员' }],
        collectUserPhone: [{ required: true, trigger: 'blur', message: '请填收车人电话' }],
        estimateArriveDate: [{ required: true, trigger: 'blur', message: '请填预计上门时间' }],
        estimateCollectDate: [{ required: true, trigger: 'blur', message: '请填预计收车时间' }],
        estimateDistance: [{ required: true, trigger: 'blur', message: '请填预计里程' }],
        fromCityId: [{ required: true, trigger: 'blur', message: '请填出发城市' }],
        fromProvinceId: [{ required: true, trigger: 'blur', message: '请填出发省份' }],
        protectCityId: [{ required: true, trigger: 'blur', message: '请填资产保全城市' }],
        protectProvinceId: [{ required: true, trigger: 'blur', message: '请填资产保全省份' }],
        visitTime: [{ required: true, trigger: 'blur', message: '请选择上门时间' }],
        fromCities: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value.length) {
                callback(new Error('请选择出发省份-城市'))
              } else {
                callback()
              }
            }
          }
        ],
        protectCities: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value.length) {
                callback(new Error('请选择资产保全省份-城市'))
              } else {
                callback()
              }
            }
          }
        ],
        distance: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value || !/^[0-9]*$/.test(value)) {
                callback(new Error('请填写正确的里程数'))
              } else {
                callback()
              }
            }
          }
        ]
      }
    }
  },
  mounted () {
    console.log(formatDate(new Date()))
    if (this.$route.query.detailFlag.toString() === 'true') {
      this.detailFlag = true
    }
    this.getDictFun()
    this.getDetailFun()
  },
  computed: {
    attachInfoFilter () {
      // carAroundFile
      // carOtherFile
      // && t.node !== 'carAroundFile' && t.node !== 'carOtherFile'
      return this.attachInfo.filter(t => {
        return t.url
      })
    }
  },
  methods: {
    dowmPic () {
      if (!this.checkList.length) return this.$message.warning('没有选中的下载项')

      if (this.checkList.length === 1) {
        let url = ''
        this.checkList.forEach(t => {
          this.attachInfo.forEach(j => {
            if (t === j.name) {
              url = j.url
            }
          })
        })
        window.location.href = apiHost.basePath + '/file/singleDownload' + '?url=' + url
        this.checkList = []
      }

      if (this.checkList.length > 1) {
        let url = []
        this.checkList.forEach(t => {
          this.attachInfo.forEach(j => {
            if (t === j.name) {
              url.push(j.url)
            }
          })
        })
        let time = formatDate(new Date(), 'yyyyMMdd')
        window.location.href = apiHost.basePath + '/file/batchZipDownload' + '?urls=' + url.join(',') + '&downloadZipFileName=' + this.result.supplierName + time
        this.checkList = []
      }
    },
    // 获取定位
    async fetchGps () {
      const data = {
        applyId: this.$route.query.id
      }
      let res = this.$api.gpsInfo(data)
      if (res) {
        this.result.gpsLocation = res
      }
    },
    down (item, type) {
      window.location.href = apiHost.basePath + '/file/singleDownload' + '?url=' + item.url
      // window.location.href = `http://d1-managerdaikuan.2345.com/asset-service` + '/file/singleDownload' + '?url=' + item.url
    },
    del (index, type) {
      console.log(index)
      this.fileList[type].splice(index, 1)
    },
    beforeUpload (file) {
      this.uploading = true
      // const isLt10M = file.size / 1024 / 1024 < 10

      // if (!isLt10M) {
      //   this.$message.error('图片或文件大小不能超过 10MB!')
      // }
    },
    handleUploadError () {
      this.uploading = false
    },
    // 上传文件的成功回调不能覆盖默认参数，只有拆开四个了
    carGiveupFile (res, file) {
      let fileName = res.result.match(/@(\S*)/)[1]
      this.fileList.carGiveupFile.push({
        url: res.result,
        fileName: fileName
      })
    },
    carFinanceRegisterFile (res, file) {
      let fileName = res.result.match(/@(\S*)/)[1]
      this.fileList.carFinanceRegisterFile.push({
        url: res.result,
        fileName: fileName
      })
    },
    carCollectFile (res, file) {
      let fileName = res.result.match(/@(\S*)/)[1]
      this.fileList.carCollectFile.push({
        url: res.result,
        fileName: fileName
      })
    },
    carBasicFile (res, file) {
      let fileName = res.result.match(/@(\S*)/)[1]
      this.fileList.carBasicFile.push({
        url: res.result,
        fileName: fileName
      })
    },
    handlePictureCardPreview (file) {
      this.dialogImageUrl = file.url
      this.showPreview = true
    },
    // 获取详情信息
    async getDetailFun () {
      try {
        let res = await api.detail({
          feeAffirmId: this.$route.query.id
        })
        this.basicInfo = res.basicInfo
        this.processRecords = res.processRecords
        this.contacts = res.contacts
        const businessInfo = res.protectRegisterBusinessInfo
        for (let key in this.fileList) {
          if (businessInfo[key]) {
            let tempArr = businessInfo[key].split(',')
            tempArr.forEach(t => {
              let fileName = t.match(/@(\S*)/)[1]
              this.fileList[key].push({
                url: t,
                fileName: fileName
              })
            })
          }
        }

        // carGiveupFile
        // carFinanceRegisterFile
        // carCollectFile
        // carBasicFile
        // const { visitStartTime, visitEndTime, isExchange, isBack, supplierId, expectFee, visitRequirements } = businessInfo
        this.result = {
          ...businessInfo,
          carStopCityId: businessInfo.carStopCityId ? businessInfo.carStopCityId.split(',') : [],
          time: businessInfo.entrustStartTime ? [businessInfo.entrustStartTime, businessInfo.entrustEndTime] : [],
          otherCost: amount(businessInfo.otherCost),
          actualCost: amount(businessInfo.actualCost),
          supplierName: res.supplierName
        }
        this.attachInfo.forEach(t => {
          for (var key in businessInfo) {
            if (key === t.node) {
              t.url = businessInfo[key]
            }
          }
        })

        this.audit = {
          collectUser: res.protectAcceptBusinessInfo.collectUser,
          collectUserPhone: res.protectAcceptBusinessInfo.collectUserPhone,
          estimateArriveDate: res.protectAcceptBusinessInfo.estimateArriveDate,
          estimateCollectDate: res.protectAcceptBusinessInfo.estimateCollectDate,
          estimateDistance: res.protectAcceptBusinessInfo.estimateDistance,
          fromCityId: res.protectAcceptBusinessInfo.fromCityId,
          fromProvinceId: res.protectAcceptBusinessInfo.fromProvinceId,
          protectCityId: res.protectAcceptBusinessInfo.protectCityId,
          protectProvinceId: res.protectAcceptBusinessInfo.protectProvinceId,
          fromCities: [res.protectAcceptBusinessInfo.fromProvinceId, res.protectAcceptBusinessInfo.fromCityId],
          protectCities: [res.protectAcceptBusinessInfo.protectProvinceId, res.protectAcceptBusinessInfo.protectCityId],
          visitTime: res.protectRegisterBusinessInfo.visitTime,
          registerDate: res.protectRegisterBusinessInfo.registerDate,
          distance: res.protectRegisterBusinessInfo.distance
        }
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 获取时间
    getTimeFun (value) {
      this.result.visitStartTime = value[0]
      this.result.visitEndTime = value[1]
    },
    // 提交校验
    async submitValidateFun () {
      this.$refs['auditStatusForm'].validate(async (valid) => {
        if (valid) {
          try {
            let str = '确认' + this.auditStatusMap[this.auditStatusForm.auditStatus] + '+' + this.auditStatusForm.reason + '?'
            let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '确定' })
            if (confirm) {
              this.submitFun()
            }
          } catch (error) {

          }
        }
      })
    },
    // 提交
    async submitFun () {
      let data = {
        ...this.auditStatusForm,
        id: this.$route.query.id
      }
      let res = await api.submit(data)
      console.log(res)
      if (res) {
        this.$message.success('提交成功')
        this.pageBack()
      } else {
        this.$message.error('提交失败')
      }
    },
    // 获取家访公司列表
    async getDictFun () {
      let res = await this.$api.getDict()
      this.getDict = res.supplierList
    },
    // 返回上一页
    pageBack () {
      window.history.back('-1')
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
