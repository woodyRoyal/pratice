<template>
  <div class="main-con">

    <!-- 基本信息 begin -->
    <EssentialInfor :basicInfo='basicInfo' :loading='loading'></EssentialInfor>
    <!-- 基本信息 end -->

    <!-- 催收记录 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">催收记录</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading" :data="collectionInfoList" border style="width: 100%">
            <el-table-column label="序号" type="index" width="80" align="center"></el-table-column>
            <el-table-column prop="userName" label="姓名" align="center"></el-table-column>
            <el-table-column prop="phone" label="手机" align="center"></el-table-column>
            <el-table-column label="接通次数/拨打次数" align="center">
              <template slot-scope="scope">
                {{scope.row.connectedCount + '/' + scope.row.calledCount || '/'}}
              </template>
            </el-table-column>
            <el-table-column prop="result" label="电话结果" align="center"></el-table-column>
            <el-table-column prop="memo" label="备注" align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <!-- 催收记录 end -->

    <!-- 处理记录 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">处理记录</span>
      </div>

      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading" :data="processRecordList" border style="width: 100%">
            <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
            <el-table-column prop="processUsername" label="处理发起人" align="center"></el-table-column>
            <el-table-column label="发起日期" align="center">
              <template slot-scope="scope">
                {{scope.row.processDate | formatDate('yyyy-MM-dd')}}
              </template>
            </el-table-column>
            <el-table-column prop="processModeDesc" label="处理方式" align="center"></el-table-column>
            <el-table-column prop="auditResult" label="审核结果" align="center"></el-table-column>
            <el-table-column prop="reason" label="备注" align="center"></el-table-column>
          </el-table>
        </div>
      </div>

      <div v-if='detailFlag' class="modular-box-form">
        <el-form :model="audit" :rules="rules" ref="audit" :inline="true" size="small" label-position="top">
          <el-form-item prop="auditStatus" label="审核结果选择">
            <el-select v-model="audit.auditStatus" placeholder="请选择">
              <el-option label="审核通过" value="1"></el-option>
              <el-option label="审核退回" value="2"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item prop="reason" label="审核备注">
            <el-input v-model.trim="audit.reason" type="textarea" maxlength=100></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 处理记录 end -->

    <div class="submit-btn">
      <el-button v-if="detailFlag" :plain="true" @click="submitValidateFun()" type="primary">提 交</el-button>
      <el-button @click="pageBack()">返 回</el-button>
    </div>

  </div>
</template>

<script>
import { mapState } from 'vuex'
import EssentialInfor from '../../components/essentialInfor'

export default {
  components: {
    EssentialInfor
  },
  data () {
    return {
      loading: true,
      detailFlag: false, // 是否可编辑Flag
      basicInfo: {}, // 基本信息
      collectionInfoList: [], // 催收记录
      processRecordList: [], // 处理记录
      // 提交审核
      audit: {
        auditStatus: '',
        reason: '',
        id: ''
      },
      auditStatusMap: {
        1: '审核通过',
        2: '审核退回'
      },
      rules: {
        auditStatus: [{ required: true, trigger: 'change', message: '请选择审核结果' }],
        reason: [{ required: true, trigger: 'blur', message: '请填写审核备注' }]
      }
    }
  },
  computed: {
    ...mapState(['permission'])
  },
  mounted () {
    if (this.$route.query.detailFlag.toString() === 'true') {
      this.detailFlag = true
    }
    this.audit.id = this.$route.query.id
    this.getDetailFun()
  },
  methods: {
    // 获取详情信息
    async getDetailFun () {
      try {
        let res = await this.$api.getAuditDetailById({
          id: this.audit.id
        })
        this.basicInfo = res.basicInfo
        this.collectionInfoList = res.collectionInfoList
        this.processRecordList = res.processRecordList
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 提交校验
    submitValidateFun () {
      this.$refs['audit'].validate(async (valid) => {
        if (valid) {
          try {
            let str = '确认' + this.auditStatusMap[this.audit.auditStatus] + '+' + this.audit.reason + '?'
            let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '确定' })
            if (confirm) {
              this.submitFun()
            }
          } catch (error) {

          }
        }
      })
    },
    // 提交
    async submitFun () {
      let res = await this.$api.submitAudit(this.audit)
      console.log(res)
      if (res) {
        this.$message.success('提交成功')
        this.pageBack()
      } else {
        this.$message.error('提交失败')
      }
    },
    // 返回上一页
    pageBack () {
      window.history.back('-1')
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
