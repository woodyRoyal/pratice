<template>
  <div class="main-con">
    <!-- 筛选 begin -->
    <div class="query-box">
      <el-form :inline="true" class="demo-form-inline" size="small">
        <el-form-item label="UID">
          <el-input v-model.trim="queryform.uid" placeholder=""></el-input>
        </el-form-item>

        <el-form-item label="客户姓名">
          <el-input v-model.trim="queryform.customerName" placeholder=""></el-input>
        </el-form-item>

        <el-form-item label="催收员">
          <el-input v-model.trim="queryform.collectionUserName" placeholder=""></el-input>
        </el-form-item>

        <el-form-item label="处理方式">
          <el-select v-model="queryform.processMode" placeholder="请选择">
            <el-option v-for="(item, index) in processModeDictionary" :key="index" :label="item" :value="index"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="审核状态">
          <el-select v-model="queryform.auditStatus" placeholder="请选择">
            <el-option v-for="(item, index) in auditStatusDictionary" :key="index" :label="item" :value="index"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="getListFun()">查询</el-button>
          <el-button @click="queryResetFun()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 筛选 end -->

    <!-- 数据表格 begin -->
    <div class="modular-box">
      <el-table v-loading="loading" :data="dataTable" border style="width: 100%" :max-height="maxTableHeight">
        <el-table-column label="序号" type="index" width="80" align="center"></el-table-column>
        <el-table-column prop="uid" label="UID" align="center"></el-table-column>
        <el-table-column prop="customerName" label="客户姓名" align="center">
          <template slot-scope="scope">
              {{scope.row.customerName | formatName}}
           </template>
        </el-table-column>
        <el-table-column prop="collectionUserName" label="催收员" align="center"></el-table-column>
        <el-table-column label="上次催收时间" align="center" width="162">
          <template slot-scope="scope">
            {{scope.row.latestCollectAt | formatDate('yyyy-MM-dd hh:mm:ss')}}
          </template>
        </el-table-column>
        <el-table-column prop="collectTimes" label="催收总次数" align="center"></el-table-column>
        <el-table-column prop="overdueLevel" label="逾期阶段" align="center"></el-table-column>
        <el-table-column prop="overdueDay" label="逾期天数(天)" align="center"></el-table-column>
        <el-table-column label="欠款金额(元)" align="center">
          <template slot-scope="scope">
            {{scope.row.overdueAmount | amount}}
          </template>
        </el-table-column>
        <el-table-column label="已还金额(元)" align="center">
          <template slot-scope="scope">
            {{scope.row.repaymentAmount | amount}}
          </template>
        </el-table-column>
        <el-table-column prop="collectMemo" label="催收备注" align="center"></el-table-column>
        <el-table-column label="处理方式" align="center">
          <template slot-scope="scope">
            {{scope.row.processMode === 0 ? '家访' : '资产保全'}}
          </template>
        </el-table-column>
        <el-table-column label="审核状态" align="center">
          <template slot-scope="scope">
            {{auditStatusDictionary[scope.row.auditStatus]}}
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" fixed="right" width="70">
          <template slot-scope="scope">
            <a class="btn-blue" v-if="scope.row.auditStatus === 0 && permission.overdue_list_edit" @click="toCompactFun(scope.row)">办理</a>
            <a class="btn-blue" v-else @click="toCompactFun(scope.row)">查看</a>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 数据表格 end -->

    <!-- 分页 begin -->
    <el-pagination
    @size-change="handleSizeChange"
    @current-change="handleCurrentChange"
    :current-page="page.currentPage"
    :page-sizes="page.pageSizesArr"
    :page-size="page.pageSize"
    :total="page.total"
    layout="total, sizes, prev, pager, next, jumper" >
    </el-pagination>
    <!-- 分页 end -->
  </div>
</template>

<!--
  注：表格操作栏状态判断如下
  1.办理：如果auditStatus字段为0，并且角色是资产总监，
  2.查看：角色是资产专员
-->
<script>
import { mapState } from 'vuex'

export default {
  data () {
    return {
      loading: true,
      dataTable: [], // 列表Table数据
      // 筛选条件
      queryform: {
        applyId: null, // 申请编号
        auditStatus: null, // 审核状态; 0:待审核，1:通过，2:退回
        caseId: null, // 案件ID
        collectionUserName: null, // 催收员
        customerName: null, // 客户姓名
        pageNum: 1, // 页码
        pageSize: 20, // 每页大小
        phone: null, // 手机号
        processMode: null, // 处理方式; 0:家访，1:拖车
        uid: null
      },
      // 分页
      page: {
        total: 0,
        pageSizesArr: [10, 20, 30, 40],
        currentPage: 1, // 当前页
        pageSize: 20 // 每页条数
      },
      // 审核状态字典
      auditStatusDictionary: {
        0: '待审核',
        1: '通过',
        2: '退回'
      },
      // 处理方式字典
      processModeDictionary: {
        0: '家访',
        1: '资产保全'
      }
    }
  },
  computed: {
    ...mapState(['maxTableHeight', 'permission'])
  },
  created () {
    let history = window.sessionStorage
    this.queryform.pageNum = this.page.currentPage = parseInt(history.getItem('pageIndex')) || 1
  },
  mounted () {
    this.getUrlQuery()
    this.getListFun()
  },
  methods: {
    // 重置
    queryResetFun () {
      this.queryform = {
        applyId: null,
        auditStatus: null,
        caseId: null,
        collectionUserName: null,
        customerName: null,
        pageNum: 1,
        pageSize: 20,
        phone: null,
        processMode: null,
        uid: null
      }
      this.page.currentPage = 1
      this.page.pageSize = 20
      this.getListFun()
    },
    // 获取url上的参数
    getUrlQuery () {
      this.queryform.auditStatus = this.$route.query.auditStatus || null
      this.queryform.processMode = this.$route.query.processMode || null
    },
    // 获取列表Table数据
    async getListFun () {
      try {
        this.loading = true
        let res = await this.$api.getAuditList(this.queryform)
        this.dataTable = res.list
        this.page.total = res.total
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 查看或办理跳转
    toCompactFun (row) {
      let detailFlag = !!((!row.auditStatus && this.permission.overdue_list_edit))
      const { id } = row
      this.$router.push({
        path: '/home/beOverdueDetail', query: { id, detailFlag }
      })
    },
    // 分页操作
    handleSizeChange (val) {
      this.page.pageSize = val
      this.queryform.pageSize = val
      this.getListFun()
    },
    handleCurrentChange (val) {
      this.queryform.pageNum = val
      this.page.currentPage = val
      window.sessionStorage.setItem('pageIndex', val)
      this.getListFun()
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
