<template>
  <div class="main-con">
    <div class="home-left">
      <ul v-loading='loading' class="data-list">
        <li>
          <h3>当前累计处置车辆</h3>
          <p>{{ totalProcessCars }} 辆</p>
        </li>
        <li>
          <h3>本月处置数量</h3>
          <p>{{ currentMonthCars }} 辆</p>
        </li>
      </ul>

      <!-- 功能快捷入口 begin -->
      <div class="modular-box">
        <div class="modular-box-th">
          <span class="modular-box-th-title">功能快捷入口</span>
        </div>

        <div v-loading='loading' class="modular-box-tb">
          <ul class="home-list">
            <li v-for="item in quickEntryList" :key="item.key"><a :href="item.link"><el-button type="primary">{{item.name}}</el-button></a></li>
          </ul>
        </div>
      </div>
      <!-- 功能快捷入口 end -->

      <!-- 工作台内容 begin -->
      <div class="modular-box">
        <div class="modular-box-th">
          <span class="modular-box-th-title">工作台内容</span>
        </div>

        <div v-loading='loading' class="modular-box-tb">
          <ul class="car-home-list">
            <li v-for="item in workbenchList" :key="item.key">
              <a :href="item.link">
                <span><img :src="workbenchImgUrl[item.key] || workbenchImgUrl['overdueCaseWaitingAuditNum']" /></span>
                <p>{{item.name}}</p>
                <p>{{item.count}}</p>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <!-- 工作台内容 end -->
    </div>

    <div class="home-right">
      <dl v-loading='loading' class="task-list">
        <dt>待办任务</dt>
        <dd v-for="item in todoList" :key="item.key"><a :href="item.link"><span>{{item.name}}</span><i>{{ item.count}}</i></a></dd>
      </dl>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      loading: true,
      totalProcessCars: '', // 累计处置车辆
      currentMonthCars: '', // 本月处置车辆
      todoList: [], // 待办任务
      quickEntryList: [], // 功能快捷入口
      workbenchList: [], // 工作台内容
      workbenchImgUrl: {
        overdueCaseWaitingAuditNum: require('../../assets/images/icon1.png'),
        sendOrderWaitingAuditNum: require('../../assets/images/icon6.png'),
        oendOrderBackAuditNum: require('../../assets/images/icon4.png'),
        visitRegisterBackNum: require('../../assets/images/icon2.png')

      }
    }
  },
  mounted () {
    console.log(this.$store.state.userInfoName)
    this.getCountInfoFun()
  },
  methods: {
    // 获取首页统计信息
    async getCountInfoFun () {
      let res = await this.$api.getCountInfo()
      this.totalProcessCars = res.totalProcessCars
      this.currentMonthCars = res.currentMonthCars
      res.todoList.forEach(t => {
        if (t.key === 'jobProtectWaitingSendNum') {
          t.link = '/auto-loan-asset-web/#/home/sendOrders?status=0&sendOrder=0&date=1565839312403'
        }
      })
      this.todoList = res.todoList
      this.quickEntryList = res.quickEntryList
      res.workbenchList.forEach(t => {
        if (t.name === '家访派单待审核' && this.$store.state.userInfoName === '资产总监') {
          t.link = '/auto-loan-asset-web/#/home/homeListExamine?sendOrderStatus=1&auditStatus=0&isBack=0&date=1565883361506'
        }
        if (t.name === '资产保全派单待审核' && this.$store.state.userInfoName === '资产总监') {
          t.link = '/auto-loan-asset-web/#/home/sendOrdersAudit?auditStatus=0&date=1565883361512'
        }
        if (t.name === '资产保全派单已退回' && this.$store.state.userInfoName === '资产总监') {
          t.link = '/auto-loan-asset-web/#/home/sendOrders?auditStatus=2&date=1565883361510'
        }
      })
      this.workbenchList = res.workbenchList
      this.loading = false
    }
  }
}
</script>

<style lang="scss" scoped>
.main-con{
  display: flex;
}

.home-left{
  flex: 1;
}

.data-list{
  $margin: 20px;
  display: flex;
  margin-left: -$margin;
  margin-top: -20px;
  flex-wrap: wrap;
  margin-bottom: 20px;
  li{
    margin-left: $margin;
    width: calc(100% / 2 - 20px);
    box-shadow: 0 2px 6px 0 rgba(0,0,0,.1);
    background-color: #fff;
    box-sizing: border-box;
    margin-top: 20px;
    h3{
      font-size: 16px;
      font-weight: bold;
      line-height: 40px;
      padding: 0 10px;
      border-bottom: 1px solid #e8e8e8;
    }
    p{
      padding: 10px;
      color: #F56C6C;
      font-size: 40px;
    }
  }
}

.home-list{
  overflow: hidden;
  padding-bottom: 20px;
  li{
    float: left;
    margin-left: 20px;
    margin-top: 20px;
    line-height: 40px;
    font-size: 14px;
    a{
      display: block;
    }
  }
}

.car-home-list{
  overflow: hidden;
  margin-top: 20px;
  margin-left: -20px;
  overflow: hidden;
  display: flex;
  flex-wrap: wrap;
  li{
    margin-left: 20px;
    margin-bottom: 20px;
    width: calc(100% / 6 - 20px);
    text-align: center;
    font-size: 14px;
    span{
      width: 44px;
      height: 44px;
      display: block;
      margin: 0 auto;
      overflow: hidden;
      img{
        width: 100%;
        display: block;
      }
    }
    p{
      margin-top: 5px;
    }
    a{
      display: block;
    }
  }
}

.home-right{
  width: 300px;
  margin-left: 20px;
}

.task-list{
  font-size: 14px;
  box-shadow: 0 2px 6px 0 rgba(0,0,0,.1);
  background-color: #fff;
  dt{
    font-size:16px;
    font-weight: bold;
    line-height: 40px;
    padding: 0 10px;
  }
  dd{
    border-top: 1px solid #e8e8e8;
    padding: 0 10px;
    a{
      display: flex;
      justify-content: space-between;
      align-content: center;
      padding: 10px 0;
      &:hover{
        color: #409eff;
      }
      i{
        padding: 2px 10px;
        background: #F56C6C;
        border-radius: 50px;
        text-align: center;
        color: #fff;
      }
    }
  }
}
</style>
