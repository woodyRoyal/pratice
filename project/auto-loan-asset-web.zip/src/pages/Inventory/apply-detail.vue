<template>
  <div class="main-con">

    <!-- 基本信息 begin -->
    <baseInfo :basicInfo='basicInfo'
              :loading='loading'></baseInfo>
    <!-- 基本信息 end -->

    <!-- 審批记录 begin -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">审批记录</span>
      </div>
      <div class="modular-box-tb">
        <div class="tableMod">
          <el-table v-loading="loading"
                    :data="auditLogInfo"
                    border
                    style="width: 100%">
            <el-table-column label="序号"
                             type="index"
                             width="80"
                             align="center"></el-table-column>
            <el-table-column prop="applyUserName"
                             label="申请人员"
                             align="center"></el-table-column>
            <el-table-column prop="applyDate"
                             label="申请日期"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.applyDate | formatDate('yyyy-MM-dd')}}
              </template>
            </el-table-column>
            <el-table-column prop="auditDate"
                             label="审核日期"
                             align="center">
              <template slot-scope="scope">
                {{scope.row.auditDate | formatDate('yyyy-MM-dd')}}
              </template>
            </el-table-column>
            <!-- <el-table-column label="接通次数/拨打次数" align="center">
              <template slot-scope="scope">
                {{scope.row.connectedCount + '/' + scope.row.calledCount || '/'}}
              </template>
            </el-table-column> -->
            <el-table-column prop="dealMethod"
                             label="处置方式"
                             align="center"></el-table-column>
            <el-table-column prop="auditResult"
                             label="审核结果"
                             align="center"></el-table-column>
            <el-table-column prop="reason"
                             label="备注"
                             align="center"></el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <!-- 催收记录 end -->
    <!-- 车辆图片上传 -->
    <div class="modular-box">
      <div class="modular-box-th">
        <span class="modular-box-th-title">车辆图片上传</span>
      </div>

      <div class="modular-box-tb">
        <el-form :disabled="false"
                 label-position="top"
                 ref="fileForm"
                 :inline="true">
          <el-form-item v-for="(attach, index) in attachInfo"
                        :key="index"
                        class="img-box">
            <!-- <div> -->
            <picUpload :attach="attach"
                       :editable="false"
                       @preView="handlePictureCardPreview" />
            <div class="label-text"
                 style="width:300px;"><i v-if="attach.required"
                 class="required-icon">*</i>{{attach.name}}</div>
            <!-- </div> -->
          </el-form-item>

          <el-form-item v-for="(attach) in carOtherFileList"
                        :key="attach.url"
                        class="img-box">
            <!-- <div> -->
            <picUpload :attach="attach"
                       :editable="false" />
            <div class="label-text"
                 style="width:300px;"><i v-if="attach.required"
                 class="required-icon">*</i>{{attach.name}}</div>
            <!-- </div> -->
          </el-form-item>
        </el-form>
      </div>
    </div>
    <el-dialog :visible.sync="showPreview"
               size="tiny"
               :modal-append-to-body="false">
      <img width="100%"
           :src="dialogImageUrl"
           alt="">
    </el-dialog>
    <!-- 处理记录 begin -->
    <div class="modular-box">
      <div v-if='detailFlag'
           class="modular-box-form">
        <el-form :model="audit"
                 :rules="rules"
                 ref="audit"
                 :inline="true"
                 size="small"
                 label-position="top">
          <el-form-item prop="auditStatus"
                        label="审核结果选择">
            <el-select v-model="audit.dealMethod"
                       placeholder="请选择">
              <el-option label="拍卖"
                         :value="0"></el-option>
              <el-option label="保证金驳回"
                         :value="1"></el-option>
              <el-option label="结清赎回"
                         :value="2"></el-option>
              <el-option label="转租"
                         :value="3"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item prop="dealRemark"
                        label="备注">
            <el-input v-model.trim="audit.dealRemark"
                      type="textarea"
                      maxlength=100></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 处理记录 end -->

    <div class="submit-btn">
      <el-button v-if="detailFlag"
                 :plain="true"
                 @click="submitValidateFun()"
                 type="primary">提 交</el-button>
      <el-button @click="pageBack()">返 回</el-button>
    </div>

  </div>
</template>

<script>
import { mapState } from 'vuex'
import EssentialInfor from '../../components/essentialInfor'
import baseInfo from '../../components/baseInfo2.0'
import picUpload from '../../components/upload2.0/picUpload'
import api from '../../api2.0/Inventory/apply'

export default {
  components: {
    EssentialInfor,
    baseInfo,
    picUpload
  },
  data () {
    return {
      attachInfo: [
        {
          node: 'carFrontierFile',
          name: '车头照片',
          required: true,
          url: ''
        },
        {
          node: 'carEndFile',
          name: '车尾照片',
          required: true,
          url: ''
        },
        {
          node: 'carLeftBodyFile',
          name: '车身照片(左侧)',
          required: true,
          url: ''
        },
        {
          node: 'carRightBodyFile',
          name: '车身照片(右侧)',
          required: true,
          url: ''
        },
        {
          node: 'carInnerFile',
          name: '车厢',
          required: true,
          url: ''
        },
        {
          node: 'carOdometerFile',
          name: '里程表照片',
          required: true,
          url: ''
        },
        {
          node: 'carChairFile',
          name: '座椅',
          required: true,
          url: ''
        },
        {
          node: 'carDriveLicenseKeyFile',
          name: '行驶证原件+车钥匙拍照1份',
          required: true,
          url: ''
        },
        {
          node: 'carGiveupIdcardFile',
          name: '客户手持自弃协议+身份证与车辆合影(照片清晰，并显示拍照日期)',
          required: true,
          url: ''
        },
        {
          node: 'carAroundFile',
          name: '自弃车辆绕车视频(视频需见车辆行驶里程数、车钥匙插孔开门、车辆前后左右整体照片)',
          required: true,
          url: ''
        }
      ], // 附件信息
      carOtherFileList: [
        {
          node: 'carOtherFile',
          name: '其他',
          required: false,
          url: ''
        }
      ],
      loading: true,
      dialogImageUrl: null,
      showPreview: false,
      detailFlag: false, // 是否可编辑Flag
      basicInfo: {}, // 基本信息
      auditLogInfo: [], // 审批记录
      businessInfo: [], // 详情业务信息
      // 提交审核
      audit: {
        dealMethod: '',
        dealRemark: '',
        id: ''
      },
      auditStatusMap: {
        0: '拍卖',
        1: '保证金驳回',
        2: '结清赎回',
        3: '转租'
      },
      rules: {
        dealMethod: [{ required: true, trigger: 'change', message: '请选择处理方式' }],
        dealRemark: [{ required: true, trigger: 'blur', message: '请填写备注' }]
      }
    }
  },
  computed: {
    ...mapState(['permission'])
  },
  mounted () {
    if (this.$route.query.detailFlag.toString() === 'true') {
      this.detailFlag = true
    }
    this.audit.id = this.$route.query.id
    this.getDetailFun()
  },
  methods: {
    handlePictureCardPreview (file) {
      this.dialogImageUrl = file.url
      this.showPreview = true
    },
    // 获取详情信息
    async getDetailFun () {
      try {
        let res = await api.detail({
          stockVehicleId: this.audit.id
        })
        this.basicInfo = res.basicInfo
        this.auditLogInfo = res.stockVehicleAuditLogInfos
        this.businessInfo = res.stockVehicleBusinessInfo
        this.attachInfo.forEach(item => {
          item.url = this.businessInfo[item.node]
        })
        let carOtherFileList = []

        carOtherFileList = this.businessInfo.carOtherFile.split(',')
        if (carOtherFileList.length) {
          this.carOtherFileList = []
          carOtherFileList.forEach(t => {
            this.carOtherFileList.push(
              {
                node: 'carOtherFile',
                name: '其他',
                required: false,
                url: t
              }
            )
          })
        }
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 提交校验
    submitValidateFun () {
      this.$refs['audit'].validate(async (valid) => {
        if (valid) {
          try {
            let str = '确认' + this.auditStatusMap[this.audit.dealMethod] + '+' + this.audit.dealRemark + '?'
            let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '确定' })
            if (confirm) {
              this.submitFun()
            }
          } catch (error) {

          }
        }
      })
    },
    // 提交
    async submitFun () {
      let res = await api.submit(this.audit)
      console.log(res)
      if (res) {
        this.$message.success('提交成功')
        this.pageBack()
      } else {
        this.$message.error('提交失败')
      }
    },
    // 返回上一页
    pageBack () {
      window.history.back('-1')
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
