<template>
  <div>
    <!-- 筛选 begin -->
    <div class="query-box">
      <el-form :inline="true"
               class="demo-form-inline"
               size="mini">
        <el-form-item label="UID">
          <el-input v-model.trim="queryform.uid"
                    placeholder=""
                    style="width:120px"></el-input>
        </el-form-item>

        <el-form-item label="申请编号">
          <el-input v-model.trim="queryform.applyId"
                    placeholder=""
                    style="width:120px"></el-input>
        </el-form-item>

        <el-form-item label="客户姓名">
          <el-input v-model.trim="queryform.customerName"
                    placeholder=""
                    style="width:120px"></el-input>
        </el-form-item>
        <!-- <el-form-item label="处理方式">
          <el-select v-model="queryform.processMode" placeholder="请选择" style="width:120px">
            <el-option v-for="(item, index) in processModeDictionary" :key="index" :label="item" :value="index"></el-option>
          </el-select>
        </el-form-item> -->
        <el-form-item label="审核结果">
          <el-select v-model="queryform.auditStatus"
                     placeholder="请选择"
                     style="width:120px">
            <el-option v-for="(item, index) in auditStatusDictionary"
                       :key="index"
                       :label="item"
                       :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="处置方式">
          <el-select v-model="queryform.dealMethod"
                     placeholder="请选择"
                     style="width:120px">
            <el-option v-for="(item, index) in dealMethodList"
                       :key="index"
                       :label="item"
                       :value="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="是否自弃">
          <el-select v-model="queryform.hasAbandon"
                     placeholder="请选择"
                     style="width:120px">
            <el-option label="是"
                       :value="true"></el-option>
            <el-option label="否"
                       :value="false"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary"
                     @click="exportFile()"
                     :loading="exportLoading">导出</el-button>
          <el-button type="primary"
                     @click="getListFun()">查询</el-button>
          <el-button @click="queryResetFun()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 筛选 end -->

    <!-- 数据表格 begin -->
    <div class="tableMod">
      <!-- <el-button v-if="permission.homeListExamine_edit" @click="batchAuditFun()" style="margin-bottom:10px" type="primary" size="mini">批量审核</el-button> -->
      <el-table v-loading="loading"
                :data="dataTable"
                border
                :max-height="maxTableHeight">
        <!-- <el-table-column width="55" align="center" :render-header="renderCheck">
           <template  slot-scope="scope">
              <el-checkbox v-model="scope.row.checked"  @change="changeCheck" v-if="scope.row.auditStatus"></el-checkbox>
           </template>
        </el-table-column> -->
        <el-table-column label="序号"
                         type="index"
                         width="80"
                         align="center"></el-table-column>
        <el-table-column prop="uid"
                         label="UID"
                         align="center"></el-table-column>
        <el-table-column prop="customerName"
                         label="客户姓名"
                         align="center">
          <template slot-scope="scope">
            {{scope.row.customerName | formatName}}
          </template>
        </el-table-column>
        <el-table-column prop="applyUserName"
                         label="申请人员"
                         align="center"></el-table-column>
        <el-table-column label="处理申请日期"
                         align="center"
                         width="162">
          <template slot-scope="scope">
            {{scope.row.applyDate | formatDate('yyyy-MM-dd')}}
          </template>
        </el-table-column>
        <el-table-column prop="carNo"
                         label="车牌号"
                         align="center"></el-table-column>
        <el-table-column prop="carChassisNo"
                         label="车架号"
                         align="center"></el-table-column>
        <el-table-column prop="overdueDay"
                         label="逾期天数(天)"
                         align="center"></el-table-column>
        <el-table-column label="剩余本金(元)"
                         align="center">
          <template slot-scope="scope">
            {{scope.row.leftPrinciple | amount}}
          </template>
        </el-table-column>
        <!-- <el-table-column label="已还金额(元)" align="center">
          <template slot-scope="scope">
            {{scope.row.repaymentAmount | amount}}
          </template>
        </el-table-column> -->
        <el-table-column label="处理方式"
                         align="center">
          <template slot-scope="scope">
            {{scope.row.dealMethod | dealMethodFilter}}
          </template>
        </el-table-column>
        <el-table-column label="审核结果"
                         align="center">
          <template slot-scope="scope">
            {{scope.row.auditStatus | auditStatusFilter}}
          </template>
        </el-table-column>
        <el-table-column prop="carStopPlace"
                         label="车辆停放地"
                         align="center"></el-table-column>
        <el-table-column label="入库时间"
                         align="center">
          <template slot-scope="scope">
            {{scope.row.storageDate | formatDate('yyyy-MM-dd')}}
          </template>
        </el-table-column>
        <el-table-column label="上牌时间"
                         align="center">
          <template slot-scope="scope">
            {{scope.row.carNoDate | formatDate('yyyy-MM-dd')}}
          </template>
        </el-table-column>
        <el-table-column prop="buyCarPhone"
                         label="提车电话"
                         align="center"></el-table-column>
        <el-table-column prop="distance"
                         label="实际里程"
                         align="center"></el-table-column>
        <el-table-column prop="carStopDealer"
                         label="停放SP处"
                         align="center"></el-table-column>
        <el-table-column label="操作"
                         align="center"
                         fixed="right"
                         width="70">
          <template slot-scope="scope">
            <a class="btn-blue"
               v-if="scope.row.editable"
               @click="toCompactFun(scope.row)">办理</a>
            <a class="btn-blue"
               v-else
               @click="toCompactFun(scope.row)">查看</a>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 数据表格 end -->

    <!-- 分页 begin -->
    <el-pagination @size-change="handleSizeChange"
                   @current-change="handleCurrentChange"
                   :current-page="page.currentPage"
                   :page-sizes="page.pageSizesArr"
                   :page-size="page.pageSize"
                   :total="page.total"
                   layout="total, sizes, prev, pager, next, jumper">
    </el-pagination>
    <!-- 分页 end -->
    <!-- 批量审核弹框 begin -->
    <el-dialog title="批量审核"
               :visible.sync="batchAuditDialogFlag"
               @closed="closeDiloagFun()"
               :modal-append-to-body="false">
      <div class="modular-box-form"
           style="margin-top:0;">
        <el-form :model="batchAudit"
                 :rules="rules"
                 ref="batchAudit"
                 :inline="true"
                 size="small"
                 label-position="top">
          <el-form-item prop="auditStatus"
                        label="审核结果选择">
            <el-select v-model="batchAudit.auditStatus"
                       placeholder="请选择">
              <el-option label="审核通过"
                         value="1"></el-option>
              <el-option label="审核退回"
                         value="2"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item prop="reason"
                        label="审核备注">
            <el-input v-model.trim="batchAudit.reason"
                      type="textarea"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="batchAuditDialogFlag = false">取 消</el-button>
        <el-button type="primary"
                   @click="batchAuditValidateFun()">提 交</el-button>
      </div>
    </el-dialog>
    <!-- 批量审核弹框 end -->
  </div>
</template>

<!--
  注：表格操作栏状态判断如下
  1.办理：如果editable字段为true，并且角色是资产总监，
  2.查看：角色是资产专员
-->
<script>
import { mapState } from 'vuex'
import renderHead from '../../components/renderHead.vue'
import api from '../../api2.0/Inventory/apply'
import { downloadPolling } from '@/utils/comm'
export default {
  components: {
    renderHead
  },
  data () {
    return {
      parentCheck: false,
      isIndeterminate: false,
      auditStatusMap: {
        1: '审核通过',
        2: '审核退回'
      },
      loading: true,
      exportLoading: false,
      batchAuditDialogFlag: false, // 批量审核弹框
      dialogFlag: false, // 上门地址数量弹框
      dataTable: [], // 列表数据
      dialogData: [], // 弹框数据
      selectBatchData: [],
      // 批量审核数据
      batchAudit: {
        auditStatus: null,
        ids: [],
        reason: null
      },
      // 筛选条件
      queryform: {
        uid: '',
        hasAbandon: '', // 是否自弃
        applyId: '', // 申请编号
        auditStatus: '', // 审核状态
        customerName: '', // 客户姓名
        dealMethod: '',
        pageNum: 1, // 页码
        pageSize: 20 // 每页大小
      },
      // 分页
      page: {
        total: 0,
        pageSizesArr: [10, 20, 30, 40],
        currentPage: 1, // 当前页
        pageSize: 20 // 每页条数
      },
      rules: {
        auditStatus: [{ required: true, trigger: 'change', message: '请选择审核结果' }],
        reason: [{ required: true, trigger: 'blur', message: '请填写审核备注' }]
      },
      // 是否已派单、是否改派、是否撤销、是否受理等字典
      trueFalseDictionary: {
        0: '否',
        1: '是'
      },
      dealMethodList: {
        0: '拍卖',
        1: '保证金驳回',
        2: '结清赎回',
        3: '转租'
      },
      // 派单审核结果字典
      auditStatusDictionary: {
        0: '待审核',
        1: '通过',
        2: '拒绝'
      }
    }
  },
  computed: {
    ...mapState(['maxTableHeight', 'permission'])
  },
  created () {
    let history = window.sessionStorage
    this.queryform.pageNum = this.page.currentPage = parseInt(history.getItem('pageIndex')) || 1
  },
  mounted () {
    this.getListFun()
  },
  methods: {
    // 监听弹框显示和隐藏
    listenDialogFun () {
      this.dialogFlag = false
    },
    renderCheck (createElement) {
      return createElement(renderHead, {
        props: {
          checked: this.parentCheck
          // content: 'TABLE_TITLE_TIP[column.property]'
        },
        on: {
          'clickCheck': (a) => {
            this.parentCheck = a
            let filterArr = this.dataTable.filter(item => {
              return item.auditStatus === 1
            })
            if (this.parentCheck) {
              filterArr.forEach(t => {
                t.checked = true
              })
            }
            if (!this.parentCheck) {
              filterArr.forEach(t => {
                t.checked = false
              })
            }
          }
        }
      })
    },
    changeCheck () {
      let filterArr = this.dataTable.filter(item => {
        return item.auditStatus === 1
      })
      let isAll = true
      filterArr.forEach(t => {
        if (t.checked === false) {
          isAll = false
        }
      })
      this.parentCheck = isAll
    },
    // 批量审核
    batchAuditFun () {
      let filterArr = this.dataTable.filter(item => {
        return item.auditStatus === 1
      })
      let ids = []
      filterArr.forEach(t => {
        if (t.checked) {
          ids.push(t.id)
        }
      })
      if (ids.length) {
        this.batchAudit.ids = ids
        this.batchAuditDialogFlag = true
      } else {
        this.$message.warning('没有被选中的条目')
      }
    },
    handleSelectionChange (val) {
      this.selectBatchData = []
      this.selectBatchData = val
    },
    // 批量审核提交校验
    batchAuditValidateFun () {
      this.$refs['batchAudit'].validate((valid) => {
        if (valid) {
          console.log(this.batchAudit)
          // this.batchAuditSubmitFun()
        }
      })
    },
    // 批量审核提交
    async batchAuditSubmitFun () {
      let res = await this.$api.batchAudit(this.batchAudit)
      if (res) {
        this.$message.success('提交成功')
        this.pageBack()
      } else {
        this.$message.error('提交失败')
      }
    },
    // 重置
    queryResetFun () {
      this.queryform = {
        uid: '',
        auditStatus: '', // 审核状态
        customerName: '', // 客户姓名
        dealMethod: '',
        pageNum: 1, // 页码
        pageSize: 20 // 每页大小
      }
      this.page.currentPage = 1
      this.page.pageSize = 20
      this.getListFun()
    },
    // 获取列表Table数据
    async getListFun () {
      try {
        this.loading = true
        let data = {
          ...this.queryform
        }
        let res = await api.getTableList(data)
        this.isAll = false
        res.list.forEach(t => {
          t.checked = false
        })
        this.dataTable = res.list
        this.page.total = res.total
      } finally {
        setTimeout(() => {
          this.loading = false
        }, 500)
      }
    },
    // 查看或办理跳转
    toCompactFun (row) {
      const { id } = row
      let detailFlag = row.editable
      this.$router.push({
        path: '/home/InventoryApply-detail', query: { id, detailFlag }
      })
    },
    // 导出
    async exportFile () {
      try {
        this.exportLoading = true
        let result = await api.exportExcelAsync({
          ...this.queryform
        })
        this.serialNo = result.serialNo
        downloadPolling(this, 10)
      } catch (error) {
        this.exportLoading = false
      }
    },
    // 弹框里的数据
    DialogDataFun (data) {
      this.dialogFlag = true
      this.dialogData = data
    },
    // 关闭批量审核弹框
    closeDiloagFun () {
      this.batchAudit.auditStatus = null
      this.batchAudit.ids = []
      this.batchAudit.reason = null
    },
    // 分页操作
    handleSizeChange (val) {
      this.page.pageSize = val
      this.queryform.pageSize = val
      this.getListFun()
    },
    handleCurrentChange (val) {
      this.queryform.pageNum = val
      this.page.currentPage = val
      window.sessionStorage.setItem('pageIndex', val)
      this.getListFun()
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
