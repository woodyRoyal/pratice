const permissionDict = {
  '资产专员': [
    'homeList_edit', // 家访管理-家访派单模块, 只有【资产专员】能【办理,提交】，其它角色为查看
    'homeRegisterExamine_edit' // 家访管理-家访登记审核模块, 只有【资产专员】能【办理,提交】，其它角色为查看
  ],
  '资产总监': [
    'overdue_list_edit', // 逾期车辆审核模块, 只有【资产总监】能【办理,提交】, 其它角色为查看
    'homeListExamine_edit', // 家访管理-家访派单审核模块, 只有【资产总监】能【办理,提交】，其它角色为查看
    'homeList_edit',
    'homeRegisterExamine_edit',
    'homeVisits_edit',
    'homeRegister_edit'
  ],
  '供应商': [
    'homeVisits_edit', // 家访管理-家访受理模块, 只有【供应商】能【办理,提交】，管理员只能查看，其它角色无法看到这个页面
    'homeRegister_edit' // 家访管理-家访登记模块, 只有【供应商】能【办理,提交】，管理员只能查看，其它角色无法看到这个页面
  ],
  '管理员': []
}

const getPermission = (identityList) => {
  let permissionList = []
  identityList.forEach(item => {
    permissionList.push(...(permissionDict[item] || []))
  })
  permissionList = Array.from(new Set(permissionList))
  let permission = {}
  permissionList.forEach(item => {
    permission[item] = true
  })
  return permission
}

export default getPermission
