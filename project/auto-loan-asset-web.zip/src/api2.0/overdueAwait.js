import request from '../utils/request'
import { url } from './mock.JS'
// let mock = ''
export default {
  // 获取列表
  getTableList: data => {
    return request({
      data,
      url: url + '/overdueCarProcess/getAuditList',
      method: 'post'
    })
  },
  // 查看详情
  getAuditDetailById: id => {
    return request({
      url: url + `/overdueCarProcess/getAuditDetailById?id=${id}`,
      method: 'get'
    })
  },
  // 逾期车辆审核
  audit: data => {
    return request({
      data,
      url: url + `/overdueCarProcess/audit`,
      method: 'post'
    })
  },
  // 逾期车辆审核
  batchAudit: data => {
    return request({
      data,
      url: url + `/overdueCarProcess/batchAudit`,
      method: 'post'
    })
  }
}
