import request from '@/utils/request'
import { url } from './../mock.JS'
// let mock = ''
export default {
  // 获取自弃车辆列表
  getCarList: data => {
    return request({
      data,
      url: url + '/abandon/queryPageInfo',
      method: 'post'
    })
  },
  // 校验申请编号
  checkApplyId: data => {
    return request({
      url: url + `/abandon/checkApplyId?applyId=${data}`,
      method: 'get'
    })
  },
  // 通过applyId获取基本信息和联系人信息
  getInfoApplyId: data => {
    return request({
      url: url + `/abandon/getInfoByApplyId?applyId=${data}`,
      method: 'get'
    })
  },
  // 通过id获取详细信息
  getInfoId: data => {
    return request({
      url: url + `/abandon/getDetailById?acceptId=${data}`,
      method: 'get'
    })
  },
  // 提交/修改自弃车辆信息
  updateInfo: data => {
    return request({
      data,
      url: url + '/abandon/submit',
      method: 'post'
    })
  }
}
