import request from '../../utils/request'
import { url } from '../mock.JS'
// let mock = ''
export default {
  // 获取列表
  getTableList: data => {
    return request({
      data,
      url: url + '/stockVehicleAudit/getList',
      method: 'post'
    })
  },
  // 获取詳情
  detail: data => {
    return request({
      data,
      url: url + '/stockVehicleAudit/detail',
      method: 'get'
    })
  },
  // 车辆审核
  audit: data => {
    return request({
      data,
      url: url + '/stockVehicleAudit/audit',
      method: 'post'
    })
  },
  // 批量审核
  batchAudit: data => {
    return request({
      data,
      url: url + '/stockVehicleAudit/batchAudit',
      method: 'post'
    })
  }
}
