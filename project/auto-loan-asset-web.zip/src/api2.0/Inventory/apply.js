import request from '../../utils/request'
import { url } from '../mock.JS'
// let mock = ''
export default {
  // 获取列表
  getTableList: data => {
    return request({
      data,
      url: url + '/stockVehicle/getList',
      method: 'post'
    })
  },
  // 获取详情
  detail: data => {
    return request({
      data,
      url: url + '/stockVehicle/detail',
      method: 'get'
    })
  },
  // 库存车辆办理
  submit: data => {
    return request({
      data,
      url: url + '/stockVehicle/submit',
      method: 'post'
    })
  },
  // 异步导出库存车辆处置申请信息
  exportExcelAsync: data => {
    return request({
      data,
      url: url + '/stockVehicle/exportExcelAsync',
      method: 'post'
    })
  }
}
