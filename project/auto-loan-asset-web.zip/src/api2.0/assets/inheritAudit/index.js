import request from '../../../utils/request'
import { url } from '../../mock.JS'
// let mock = ''
export default {
  // 资产保全派单数据字典
  getDict: data => {
    return request({
      data,
      url: url + '/protectSendOrder/getDict',
      method: 'get'
    })
  },
  // 获取列表
  getTableList: data => {
    return request({
      data,
      url: url + '/protectRegisterOrderAudit/getList',
      method: 'post'
    })
  },
  // 获取详情
  detail: data => {
    return request({
      data,
      url: url + '/protectRegisterOrderAudit/getInfo',
      method: 'get'
    })
  },
  // 派单提
  submit: data => {
    return request({
      data,
      url: url + '/protectRegisterOrderAudit/audit',
      method: 'post'
    })
  }
}
