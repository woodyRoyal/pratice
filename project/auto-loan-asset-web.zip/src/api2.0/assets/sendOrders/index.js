import request from '../../../utils/request'
import { url } from '../../mock.JS'
// let mock = ''
export default {
  // 资产保全派单数据字典
  getDict: data => {
    return request({
      data,
      url: url + '/protectSendOrder/getDict',
      method: 'get'
    })
  },
  // 获取列表
  getTableList: data => {
    return request({
      data,
      url: url + '/protectSendOrder/getList',
      method: 'post'
    })
  },
  // 获取详情
  detail: data => {
    return request({
      data,
      url: url + '/protectSendOrder/getInfo',
      method: 'get'
    })
  },
  // 派单提交
  submit: data => {
    return request({
      data,
      url: url + '/protectSendOrder/submit',
      method: 'post'
    })
  },
  // 批量派单提交
  batchDispatch: data => {
    return request({
      data,
      url: url + '/protectSendOrder/batchSubmit',
      method: 'post'
    })
  },
  // 挂靠公司列表
  getcompanyList: data => {
    return request({
      data,
      url: url + '/keyword/attachedCompanyName',
      method: 'get'
    })
  }
}
