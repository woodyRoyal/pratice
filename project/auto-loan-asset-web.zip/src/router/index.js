import Vue from 'vue'
import Router from 'vue-router'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import Home from '../home'

NProgress.inc(0.2)
NProgress.configure({ easing: 'ease', speed: 500, showSpinner: false })

Vue.use(Router)

let router = new Router({
  routes: [
    {
      path: '/',
      redirect: '/home/'
    },
    {
      path: '/login',
      name: '系统登陆中',
      component: () => import('../pages/login/login.vue')
    },
    {
      path: '/home',
      name: '车贷王资产管理系统',
      component: Home,
      children: [
        {
          path: '/',
          redirect: 'homepage'
        },
        {
          path: 'overdueAwait',
          name: '逾期车辆处理待审核',
          component: () => import('../pages/overdueAwait/index.vue')
        },
        {
          path: 'overdueAwaitDetail',
          name: '逾期车辆处理待审核详情',
          component: () => import('../pages/overdueAwait/detail.vue')
        },
        {
          path: 'InventoryApply',
          name: '库存车辆处置申请',
          component: () => import('../pages/Inventory/apply.vue')
        },
        {
          path: 'InventoryApply-detail',
          name: '库存车辆处置申请详情',
          component: () => import('../pages/Inventory/apply-detail.vue')
        },
        {
          path: 'InventoryExamine',
          name: '库存车辆处理待审核',
          component: () => import('../pages/Inventory/examine.vue')
        },
        {
          path: 'InventoryExamine-detail',
          name: '库存车辆处理待审核详情',
          component: () => import('../pages/Inventory/examine-detail.vue')
        },
        {
          path: 'homepage',
          name: '首页',
          component: () => import('../pages/homePage/index.vue')
        },
        {
          path: 'beOverdue',
          name: '逾期车辆审核',
          component: () => import('../pages/beOverdue/beOverdue.vue')
        },
        {
          path: 'abandonCar',
          name: '自弃车辆管理',
          component: () => import('../pages/abandonCar')
        },
        {
          path: 'abandonCardetail',
          name: '自弃车辆详情',
          component: () => import('../pages/abandonCar/detail.vue')
        },
        {
          path: 'beOverdueDetail',
          name: '处理方式审核',
          component: () => import('../pages/beOverdue/beOverdue-detail.vue')
        },
        {
          path: 'homeList',
          name: '家访派单',
          component: () => import('../pages/homeManagement/homeList/homeList.vue')
        },
        {
          path: 'homeListDetail',
          name: '家访派单详情',
          component: () => import('../pages/homeManagement/homeList/homeList-detail.vue')
        },
        {
          path: 'homeListExamine',
          name: '家访派单审核',
          component: () => import('../pages/homeManagement/homeListExamine/homeListExamine.vue')
        },
        {
          path: 'homeListExamineDetail',
          name: '家访派单审核详情',
          component: () => import('../pages/homeManagement/homeListExamine/homeListExamine-detail.vue')
        },
        {
          path: 'homeVisits',
          name: '家访受理',
          component: () => import('../pages/homeManagement/homeVisits/homeVisits.vue')
        },
        {
          path: 'homeVisitsDetail',
          name: '家访受理详情',
          component: () => import('../pages/homeManagement/homeVisits/homeVisits-detail.vue')
        },
        {
          path: 'homeRegister',
          name: '家访登记',
          component: () => import('../pages/homeManagement/homeRegister/homeRegister.vue')
        },
        {
          path: 'homeRegisterDetail',
          name: '家访登记详情',
          component: () => import('../pages/homeManagement/homeRegister/homeRegister-detail.vue')
        },
        {
          path: 'homeRegisterExamine',
          name: '家访登记审核',
          component: () => import('../pages/homeManagement/homeRegisterExamine/homeRegisterExamine.vue')
        },
        {
          path: 'homeRegisterExamineDetail',
          name: '家访登记审核详情',
          component: () => import('../pages/homeManagement/homeRegisterExamine/homeRegisterExamine-detail.vue')
        },
        {
          path: 'homeCost',
          name: '家访费用',
          component: () => import('../pages/homeManagement/homeCost/homeCost.vue')
        },
        {
          path: 'homeCostDetail',
          name: '家访费用详情',
          component: () => import('../pages/homeManagement/homeCost/homeCost-detail.vue')
        },
        {
          path: 'sendOrders',
          name: '资产保全派单',
          component: () => import('../pages/assets/sendOrders')
        },
        {
          path: 'sendOrders-detail',
          name: '资产保全派单详情',
          component: () => import('../pages/assets/sendOrders/detail.vue')
        },
        {
          path: 'sendOrdersAudit',
          name: '资产保全派单审核',
          component: () => import('../pages/assets/sendOrdersAudit')
        },
        {
          path: 'sendOrdersAudit-detail',
          name: '资产保全派单审核详情',
          component: () => import('../pages/assets/sendOrdersAudit/detail.vue')
        },
        {
          path: 'acceptance',
          name: '资产保全受理',
          component: () => import('../pages/assets/acceptance')
        },
        {
          path: 'acceptance-detail',
          name: '资产保全受理详情',
          component: () => import('../pages/assets/acceptance/detail.vue')
        },
        {
          path: 'inherit',
          name: '资产保全交接',
          component: () => import('../pages/assets/inherit')
        },
        {
          path: 'inherit-detail',
          name: '资产保全交接详情',
          component: () => import('../pages/assets/inherit/detail.vue')
        },
        {
          path: 'inheritAudit',
          name: '资产保全交接审核',
          component: () => import('../pages/assets/inheritAudit')
        },
        {
          path: 'inheritAudit-detail',
          name: '资产保全交接审核详情',
          component: () => import('../pages/assets/inheritAudit/detail.vue')
        },
        {
          path: 'assetsCost',
          name: '资产保全费用确认',
          component: () => import('../pages/assets/cost')
        },
        {
          path: 'assetsCost-detail',
          name: '资产保全费用确认详情',
          component: () => import('../pages/assets/cost/detail.vue')
        },
        {
          path: 'supplierManage',
          name: '供应商管理',
          component: () => import('../pages/supplier/supplierManage.vue')
        },
        {
          path: 'maintainSupplier',
          name: '供应商维护',
          component: () => import('../pages/supplier/maintainSupplier.vue')
        },
        {
          path: 'viewSupplier',
          name: '查看供应商信息',
          component: () => import('../pages/supplier/viewSupplier.vue')
        },
        {
          path: 'createSupplier',
          name: '新增供应商',
          component: () => import('../pages/supplier/createSupplier.vue')
        },
        {
          path: 'supplierAudit',
          name: '新增供应商审核',
          component: () => import('../pages/supplier/supplierAudit.vue')
        },
        {
          path: 'supplierAuditDetail',
          name: '新增供应商审核详情',
          component: () => import('../pages/supplier/supplierAuditDetail.vue')
        }
      ]
    }
  ]
})

router.beforeEach((to, from, next) => {
  // 修改页面标题
  document.title = to.name
  NProgress.start()
  next()
})

router.afterEach(() => {
  setTimeout(() => {
    NProgress.done()
  }, 500)
})

export default router
