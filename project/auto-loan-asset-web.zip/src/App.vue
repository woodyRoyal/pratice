<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
// 计算表格最大高度
import caclMaxTableHeightMixin from './mixins/caclMaxTableHeightMixin'
export default {
  name: 'app',
  mixins: [caclMaxTableHeightMixin]
}
</script>
<style lang='sass'>
  @import './assets/style/global.scss'
</style>
