/**
 * Created by yangm on 2019/5/21.
 * 定义两个存取localStorage的方法
 */
// 当前项目下的缓存全部使用ASSET_SERVICE命名空间

// saveType 取值 session || local
/**
* @para
* saveType: {存储类型，String：'session' || 'local'}
* key: 存储的键
* value: 值
* */

const saveToLocal = (saveType, key, value) => {
  let store = saveType === 'session' ? window.sessionStorage : window.localStorage
  let ASSET_SERVICE = store.__ASSET_SERVICE__
  if (!ASSET_SERVICE) {
    ASSET_SERVICE = {}
    ASSET_SERVICE[key] = value
  } else {
    ASSET_SERVICE = JSON.parse(ASSET_SERVICE)
    // if (!ASSET_SERVICE[id]) {
    //   ASSET_SERVICE[id] = {}
    // }
  }
  ASSET_SERVICE[key] = value
  store.__ASSET_SERVICE__ = JSON.stringify(ASSET_SERVICE)
}

/**
 * @para
 * saveType: {存储类型，String：'session' || 'local'}
 * key: 取值存储的键
 * value: 娶不到的默认值
 * */
const getFromLocal = (saveType, key, def) => {
  let store = saveType === 'session' ? window.sessionStorage : window.localStorage
  let ASSET_SERVICE = store.__ASSET_SERVICE__
  if (!ASSET_SERVICE) {
    return def
  }
  ASSET_SERVICE = JSON.parse(ASSET_SERVICE)
  if (ASSET_SERVICE[key] === 'undefined' || ASSET_SERVICE[key] === 'null') {
    return def
  }
  return ASSET_SERVICE[key] || def
}
export {
  saveToLocal,
  getFromLocal
}
