
import api from '@/api/comm'
// 轮训下载文件
export let downloadPolling = async (context, counter) => {
  try {
    if (counter <= 0) {
      context.exportLoading = false
      return context.$message.error('下载时间超时')
    }
    let result = await api.downloadPolling(context.serialNo)
    if (result && result.storePath) {
      window.location.href = result.storePath
      context.exportLoading = false
    } else {
      setTimeout(() => {
        downloadPolling(context, --counter)
      }, 1000)
    }
  } catch (error) {
    context.exportLoading = false
    throw error
  }
}
