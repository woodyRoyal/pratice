import env from '../config/env'

const login = () => {
  if (env !== 'development') {
    location.href = `${location.origin}/ucenter/`
  }
}

export default login
