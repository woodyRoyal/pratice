import axios from 'axios'
import hostApi from '../config/apiHost'
import { Notification } from 'element-ui'
import login from '../utils/login'
axios.defaults.headers.common['Content-Type'] = 'application/json;charset=UTF-8'
axios.defaults.baseURL = hostApi.basePath // 发送请求的基础url
axios.defaults.timeout = 30000 // 请求的超时时间
axios.defaults.withCredentials = true // 需要跨域携带认证

// 添加请求拦截器
axios.interceptors.response.use(config => {
  // console.log('begin request')
  return config
})

// 添加一个响应拦截器
axios.interceptors.response.use(res => {
  // 在这里对返回的数据进行处理/
  if (res.data.code !== '1000') {
    Notification.error({
      title: '请求出错',
      message: res.data.msg || '服务器请求出错！'
    })
    if (res.data.code === '1005') { // 未登录
      login()
    }
    return Promise.reject(res.data.msg || '服务器错误')
  }
  return res.data.result || res.data
}, (err) => {
  Notification.error({
    title: '请求出错',
    message: err || '服务器请求出错！'
  })
  return Promise.reject(err)
})

/***
 *  函数的参数options为axios的配置
 *  method => 方法名 "POST"等
 *  url => 路径,实际调用时传type即可，即为urlDict的key
 *  data => 数据的对象
 *  调用前将type值转为对应的url
 * **/
let request = options => {
  options.headers = options.header || {}
  options.method = options.method || 'post'
  if (options.method.toUpperCase() === 'GET') {
    options.params = options.data
  }
  return axios(options)
}

export default request
