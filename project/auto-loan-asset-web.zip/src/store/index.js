import Vue from 'vue'
import Vuex from 'vuex'
import {
  saveToLocal,
  getFromLocal
} from '../utils/storage'

Vue.use(Vuex)

let initData = {
  // 样例，取值 this.$store.state.userInfo,提交 this.$store.commit('userInfo', {})
  userInfo: {
    persistence: false, // 是否持久化，是否存入localStorage
    default: {}
  },
  cityTree: { // 城市树
    persistence: false,
    default: []
  },
  // 登陆状态，0未登录，1登陆，登陆成功后置为1
  loginStatus: {
    default: 0
  },
  maxTableHeight: { // 默认表格的最大高度，此值在App组件计算得出
    default: 500
  },
  userInfoName: { default: '' },
  // supplierAdministrators: { default: '' },
  routerLink: { // 权限路由
    default: []
  },
  bankList: { // 银行列表
    default: []
  },
  permission: { // 获取角色权限
    default: {}
  }
}

let state = {}

let mutations = {}

for (let key in initData) {
  if (initData[key].persistence) {
    state[key] = getFromLocal('local', key) || getFromLocal('session', key, initData[key].default)
    mutations[key] = (storeState, obj) => {
      storeState[key] = obj
      saveToLocal('session', key, obj)
      saveToLocal('local', key, obj)
    }
  } else {
    state[key] = getFromLocal('session', key, initData[key].default)
    mutations[key] = (storeState, obj) => {
      storeState[key] = obj
      saveToLocal('session', key, obj)
    }
  }
}

export default new Vuex.Store({
  state,
  mutations
})
