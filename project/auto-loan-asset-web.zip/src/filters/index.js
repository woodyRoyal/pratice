import dateFormatFn from '../utils/formatDate.js'
// 数据加密
function replacepos (text, start, stop, replacetext) {
  if (stop) {
    let startStr = text.substring(0, start)
    let endStr = text.substring(stop)
    return startStr + replacetext + endStr
  } else {
    return replacetext + text.substring(start + 1)
  }
}
// function replacMaxNumber (text, replacetext) {
//   let startStr = text.substring(0, 4)
//   let endStr = text.substring(text.length - 4)
//   let replaceStr = ''
//   for (let i = 0; i < text.length - 8; i++) {
//     replaceStr = replaceStr + replacetext
//   }
//   return startStr + replaceStr + endStr
// }
// 调用dateFormatFn，作为过滤器使用
export const formatDate = (time, rule) => {
  if (!time) {
    return '/'
  }
  if (typeof (time) === 'string') {
    time = time.replace(/-/g, '/')
  }
  let date = new Date(time)
  return dateFormatFn(date, rule)
}

// 金额过滤器，将单位为分的转化为元
export const amount = (num, len = 2) => {
  // 分转化为元
  let res = (Number(num) || 0) / 100
  return Math.round(res * Math.pow(10, len)) / Math.pow(10, len)
}

// 金额过滤器，将单位为元的转化为分
export const amountOfpoints = (num, len = 2) => {
  let res = Number(num) * 100
  return res
}
// 过滤姓名
export function formatName (value, type) {
  if (value) {
    return replacepos(value, 0, 0, '*')
  } else {
    if (type) {
      return value
    } else {
      return '/'
    }
  }
}

// 处理方式
export function dealMethodFilter (val) {
  if (!val || isNaN(isNaN)) return val
  const arr = ['拍卖', '保证金驳回 ', '结清赎回', '转租']
  return arr[val]
}

// 审核结果
export function auditStatusFilter (val) {
  if (!val || isNaN(isNaN)) return val
  const arr = ['待审核', '通过', '拒绝']
  return arr[val]
}
