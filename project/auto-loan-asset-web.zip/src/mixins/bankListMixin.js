import { mapState } from 'vuex'
export default {
  computed: {
    ...mapState(['bankList'])
  },
  created () {
    if (!this.bankList || !this.bankList.length) {
      this.getBankList()
    }
  },
  methods: {
    async getBankList () {
      try {
        let bankList = await this.$api.getBankList()
        if (!bankList || !bankList.length) {
          throw new Error()
        }
        this.$store.commit('bankList', bankList)
      } catch (e) {
        this.$notify.error({
          title: '错误',
          message: '获取银行字典失败'
        })
      }
    }
  }
}
