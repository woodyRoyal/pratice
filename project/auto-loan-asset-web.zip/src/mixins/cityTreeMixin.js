import { mapState } from 'vuex'
export default {
  computed: {
    ...mapState(['cityTree'])
  },
  created () {
    if (!this.cityTree || !this.cityTree.length) {
      this.getCityTree()
    }
  },
  methods: {
    async getCityTree () {
      try {
        let cityTree = await this.$api.getCityTree()
        if (!cityTree || !cityTree.length) {
          throw new Error()
        }
        let region = [{
          cityName: '全国区域',
          currentKey: '0',
          cityList: cityTree
        }]
        this.$store.commit('cityTree', region)
      } catch (e) {
        this.$notify.error({
          title: '错误',
          message: '获取全国城市数据失败'
        })
      }
    }
  }
}
