import TableCom from '@/components/TableCom'
export default {
  install (Vue) {
    Vue.component('TableCom', TableCom)
  }
}
