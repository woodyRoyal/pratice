/**
 * created by yangm 2019-05-22
 */

import request from '../utils/request'

export default {
  // 获取供应商基本信息
  getSupplierDetailById: data => {
    return request({
      data,
      url: '/supplier/getSupplierDetailById',
      method: 'get'
    })
  },
  // 获取供应商列表
  findSupplierList: data => {
    return request({
      data,
      url: '/supplier/findSupplierList',
      method: 'post'
    })
  },
  // 供应商基本信息保存
  saveSupplier: data => {
    return request({
      data,
      url: '/supplier/saveSupplier',
      method: 'post'
    })
  },
  // 供应商信息修改
  updateSupplier: data => {
    return request({
      data,
      url: '/supplier/updateSupplier',
      method: 'post'
    })
  },
  // 供应商审核
  audit: data => {
    return request({
      data,
      url: '/supplier/audit',
      method: 'get'
    })
  },
  // 保存供应商用户
  saveSupplierSystemUser: data => {
    return request({
      data,
      url: '/supplier/saveSupplierSystemUser',
      method: 'post'
    })
  },
  // 更新供应商系统用户
  updateSupplierSystemUser: data => {
    return request({
      data,
      url: 'supplier/updateSupplierSystemUser',
      method: 'post'
    })
  },
  // 查询供应商系统用户
  findSupplierSystemUserList: data => {
    return request({
      data,
      url: '/supplier/findSupplierSystemUserList',
      method: 'get'
    })
  },
  // 保存供应商附件信息
  saveSupplierFile: data => {
    return request({
      data,
      url: '/file/saveFileList',
      method: 'post'
    })
  },
  // 查询供应商文件信息
  getSupplierFileList (data) {
    return request({
      data,
      url: '/file/findFileList',
      method: 'get'
    })
  },
  // 设置供应商状态
  settingSupplierStatus: data => {
    return request({
      data,
      url: '/supplier/settingStatus',
      method: 'get'
    })
  },
  submitStatus: data => {
    return request({
      data,
      url: '/supplier/submitStatus',
      method: 'get'
    })
  }
}
