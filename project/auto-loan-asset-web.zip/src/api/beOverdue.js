/**
 * created by panyq 2019-05-27
 * 逾期车辆处理待审核列表和详情页
 */

import request from '@/utils/request'

export default {
  getAuditList: data => {
    return request({
      data,
      url: '/overdueCarProcess/getAuditList',
      method: 'post'
    })
  },
  getAuditDetailById: data => {
    return request({
      data,
      url: '/overdueCarProcess/getAuditDetailById',
      method: 'get'
    })
  },
  submitAudit: data => {
    return request({
      data,
      url: '/overdueCarProcess/audit',
      method: 'post'
    })
  }
}
