/**
 * created by panyq 2019-05-27
 * 家访派单
 */

import request from '@/utils/request'

export default {
  // 家访派单模块
  getList: data => {
    return request({
      data,
      url: '/sendOrder/getList',
      method: 'post'
    })
  },
  getInfo: data => {
    return request({
      data,
      url: '/sendOrder/getInfo',
      method: 'get'
    })
  },
  getDict: data => {
    return request({
      data,
      url: '/sendOrder/getDict',
      method: 'get'
    })
  },
  sendOrderSubmit: data => {
    return request({
      data,
      url: '/sendOrder/submit',
      method: 'post'
    })
  },
  // 家访派单审核模块
  getListExamine: data => {
    return request({
      data,
      url: '/sendOrderAudit/getList',
      method: 'post'
    })
  },
  batchAudit: data => {
    return request({
      data,
      url: '/sendOrderAudit/batchAudit',
      method: 'post'
    })
  },
  getSendOrderAuditDict: data => {
    return request({
      data,
      url: '/sendOrderAudit/getDict',
      method: 'get'
    })
  },
  sendOrderAudit: data => {
    return request({
      data,
      url: '/sendOrderAudit/audit',
      method: 'post'
    })
  },
  // 家访受理模块
  getCityList: data => {
    return request({
      data,
      url: '/acceptOrder/getDict',
      method: 'get'
    })
  },
  acceptOrderList: data => {
    return request({
      data,
      url: '/acceptOrder/getList',
      method: 'post'
    })
  },
  acceptOrderGetInfo: data => {
    return request({
      data,
      url: '/acceptOrder/getInfo',
      method: 'get'
    })
  },
  acceptance: data => {
    return request({
      data,
      url: '/acceptOrder/accept',
      method: 'post'
    })
  },
  acceptanceRefuse: data => {
    return request({
      data,
      url: '/acceptOrder/refuse',
      method: 'post'
    })
  },
  // 家访登记模块
  registerOrderList: data => {
    return request({
      data,
      url: '/registerOrder/getList',
      method: 'post'
    })
  },
  registerOrderGetInfo: data => {
    return request({
      data,
      url: '/registerOrder/getInfo',
      method: 'get'
    })
  },
  registerOrderSubmit: data => {
    return request({
      data,
      url: '/registerOrder/submit',
      method: 'post'
    })
  },
  // 家访登记审核模块
  examineList: data => {
    return request({
      data,
      url: '/registerOrderAudit/getList',
      method: 'post'
    })
  },
  registerOrderAuditInfor: data => {
    return request({
      data,
      url: '/registerOrderAudit/getInfo',
      method: 'get'
    })
  },
  registerOrderAuditSubmit: data => {
    return request({
      data,
      url: '/registerOrderAudit/audit',
      method: 'post'
    })
  },
  // 家访费用模块
  feeAffirm: data => {
    return request({
      data,
      url: '/feeAffirm/getList',
      method: 'post'
    })
  },
  feeAffirmInfo: data => {
    return request({
      data,
      url: '/feeAffirm/getInfo',
      method: 'get'
    })
  },
  feeAffirmSubmit: data => {
    return request({
      data,
      url: '/feeAffirm/submit',
      method: 'post'
    })
  },
  upLoadFile: data => {
    return request({
      data,
      url: '/file/upload',
      method: 'post'
    })
  }
}
