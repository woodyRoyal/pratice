/**
 * created by panyq 2019-05-27
 */

import request from '../utils/request'
export default {
  // 获取城市树
  getCityTree: data => {
    return request({
      data,
      url: '/city/getAllCitys',
      method: 'get'
    })
  },
  // 登陆
  login: data => {
    return request({
      data,
      url: '/login',
      method: 'post'
    })
  },
  // GPSinfo
  gpsInfo: data => {
    return request({
      data,
      url: '/gps/gpsInfo',
      method: 'get'
    })
  },
  // 获取供应商
  getSupplier: data => {
    return request({
      data,
      url: '/protectSendOrder/getDict',
      method: 'get'
    })
  },
  // 获取银行
  getBankList: data => {
    return request({
      data,
      url: '/bank/findAllBanks',
      method: 'get'
    })
  },
  // SP名称列表
  getSpnameList: data => {
    return request({
      data,
      url: '/keyword/spName',
      method: 'get'
    })
  },
  // 文件上传
  uploadV2: data => {
    return request({
      data,
      url: '/file/uploadV2',
      method: 'post'
    })
  },
  // 下载轮询
  downloadPolling: data => {
    return request({
      url: `/download/polling?serialNo=${data}`,
      method: 'get'
    })
  }
}
