/**
 * created by panyq 2019-05-27
 */

import request from '@/utils/request'

export default {
  getCountInfo: data => {
    return request({
      data,
      url: '/homepage/getCountInfo',
      method: 'get'
    })
  }
}
