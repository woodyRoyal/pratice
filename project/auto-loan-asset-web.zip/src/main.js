import Vue from 'vue'

import './assets/style/reset.css' // reset文件和公共部分
import ElementUI from 'element-ui'
import App from './App.vue'
import router from './router'
import store from './store'
import GlobalComponent from '@/plugins/globalComponent'
import PrivateMixin from '@/plugins/privateMixin'
import * as fliters from './filters'
import api from './api'

// 全局注册所有过滤器
Object.keys(fliters).forEach(key => {
  Vue.filter(key, fliters[key])
})
Vue.use(GlobalComponent)
window.privateMixin = PrivateMixin
// VUE原型添加api对象，方便调用
Vue.prototype.$api = api

Vue.use(ElementUI)
Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
