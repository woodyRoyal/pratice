<template>
  <el-container>
    <el-header class="layout-header" height="50px">
      <el-row style="height: 50px">
        <el-col :span="4"><div class="logo">车贷王资产管理系统</div></el-col>
        <el-col :span="2">
          <div @click="toggleCollapse" class="toogle-menu-wrapper">
            <el-tooltip v-if="isCollapse" class="item" effect="dark" content="展开菜单" placement="bottom">
              <i class="el-icon-arrow-right toogle-menu"></i>
            </el-tooltip>
            <el-tooltip v-else class="item" effect="dark" content="收起菜单" placement="bottom">
              <i class="el-icon-arrow-left toogle-menu"></i>
            </el-tooltip>
          </div>
        </el-col>
        <el-col v-if="userInfo.displayName" class="user-info" :span="4" :offset="14">
          <div class="display-name">{{userInfo.displayName}}</div>
          <el-button type="primary" size="mini" @click="logout">退出</el-button>
        </el-col>
      </el-row>
    </el-header>
    <el-container class="layout-bottom">
      <el-aside class="layout-aside" :width="sideWidth">
        <el-menu :default-active="activeMenu"
                 :unique-opened="true"
                 class="el-menu-vertical"
                 background-color="#2c3e50"
                 text-color="#aaa"
                 active-text-color="#fff"
                 @select="handleSelect"
                 :collapse-transition="false"
                 :collapse="isCollapse">
          <template v-for="mainItem in routerLink">
            <el-submenu  v-if="mainItem.children && mainItem.children.length" :index="mainItem.key" :key="mainItem.id">
              <template slot="title">
                <i :class="mainItem.icon"></i>
                <span slot="title">{{mainItem.name}}</span>
              </template>
              <template v-for="child in mainItem.children">
                <el-submenu v-if="child.children && child.children.length" :index="child.key" :key="child.id">
                  <span slot="title">{{child.name}}</span>
                  <template v-for="sChild in child.children">
                    <el-menu-item :index="sChild.key || ''" :key="sChild.id">{{sChild.name}}</el-menu-item>
                  </template>
                </el-submenu>
                <el-menu-item :index="child.key" :key="child.id">{{child.name}}</el-menu-item>
              </template>
            </el-submenu>
            <el-menu-item v-else :index="mainItem.key" :key="mainItem.id">
              <i :class="mainItem.icon"></i>
              <span slot="title">{{mainItem.name}}</span>
            </el-menu-item>
          </template>
        </el-menu>
      </el-aside>
      <el-main style="overflow-x: hidden;">
        <router-view/>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import logo from '../assets/logo/logo1.png'
import { mapState } from 'vuex'
import login from '../utils/login'

export default {
  data () {
    return {
      logo,
      isCollapse: false,
      sideWidth: '200px',
      activeMenu: ''
      // routerLink: [
      //   {
      //     id: '1',
      //     name: '首页',
      //     icon: 'el-icon-news',
      //     path: '/home/homepage'
      //   },
      //   {
      //     id: '2',
      //     name: '逾期',
      //     icon: 'el-icon-time',
      //     path: '/home/beOverDue'
      //   },
      //   {
      //     id: '3',
      //     name: '家访管理',
      //     icon: 'el-icon-time',
      //     children: [
      //       {
      //         name: '家访派单',
      //         path: '/home/homeList'
      //       },
      //       {
      //         name: '家访派单审核',
      //         path: '/home/homeListExamine'
      //       },
      //       {
      //         name: '家访受理',
      //         path: '/home/homeVisits'
      //       },
      //       {
      //         name: '家访登记',
      //         path: '/home/homeRegister'
      //       },
      //       {
      //         name: '家访登记审核',
      //         path: '/home/homeRegisterExamine'
      //       },
      //       {
      //         name: '家访费用',
      //         path: '/home/homeCost'
      //       }
      //     ]
      //   },
      //   {
      //     id: '4',
      //     name: '供应商',
      //     icon: 'el-icon-goods',
      //     children: [
      //       {
      //         name: '供应商管理',
      //         path: '/home/supplierManage'
      //       },
      //       {
      //         name: '新增供应商',
      //         path: '/home/createSupplier'
      //       },
      //       {
      //         name: '新增供应商审核',
      //         path: '/home/supplierAudit'
      //       }
      //     ]
      //   }
      // ]
    }
  },
  computed: {
    ...mapState(['userInfo', 'routerLink'])
  },
  created () {
    if (!this.checkLogin()) {
      login()
    }
  },
  watch: {
    '$route': {
      handler: function (to) {
        let path = to.path
        this.activeMenu = path
      },
      immediate: true,
      deep: true
    }
  },
  methods: {
    logout () { // 跳转互金后台
      this.$alert('你确定要退出系统吗？退出将跳转至互金后台。', '提示', {
        confirmButtonText: '确定',
        showCancelButton: true,
        callback: action => {
          if (action === 'confirm') {
            // 修改登陆状态
            this.$store.commit('loginStatus', 0)
            location.href = `${location.origin}/ucenter/`
          }
        }
      })
    },
    // 检测登陆返回布尔值
    checkLogin () {
      return this.$store.state.loginStatus === 1
    },
    toggleCollapse () {
      this.isCollapse = !this.isCollapse
      this.sideWidth = this.isCollapse ? '64px' : '250px'
    },
    handleSelect (index, path) {
      this.$router.push(index)
    }
  }
}
</script>

<style lang="sass" scoped>
  .layout-header
    height: 50px
    background: #324157
    .logo
      width: 180px
      height: 50px
      color: #fff
      font-size: 20px
      line-height: 50px
      padding-left: 50px
      background: url("../assets/logo/logo1.png") no-repeat center left
    .toogle-menu-wrapper
      padding-left: 20px
      .toogle-menu
        font-size: 20px
        color: #ccc
        line-height: 50px
        padding: 0 20px
        &:hover
          color: #fff
    .user-info
      height: 50px
      text-align: end
      display: flex
      justify-content: flex-end
      align-items: center
      .display-name
        color: #dcdfe6
        font-size: 20px
        margin-right: 15px
  .layout-bottom
    width: 100%
    position: fixed
    top: 50px
    bottom: 0
  .layout-aside
    background: #2c3e50
  .el-menu-vertical
    min-height: 400px
    border-right: none
    /deep/ .is-active
      background-color: rgb(35, 50, 64) !important
</style>
