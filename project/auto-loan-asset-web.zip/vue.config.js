const path = require('path')
const webpack = require('webpack')
const AddAssetHtmlPlugin = require('add-asset-html-webpack-plugin')
const resolve = (dir) => path.join(__dirname, dir)
let isDev = process.env.NODE_ENV === 'development'
let isProd = process.env.NODE_ENV === 'production'
console.log(isDev)
module.exports = {
  publicPath: isDev ? '/' : '', // 二级目录路径
  outputDir: 'auto-loan-asset-web', // 构建目录名称
  productionSourceMap: !isProd, // 生产环境sourceMap
  css: {
    sourceMap: !isProd // CSS sourceMap
  },
  lintOnSave: isDev, // 保存立即检查
  // 开发运行相关配置
  devServer: {
    open: true, // 自动打开浏览器
    port: 9001, // 端口
    proxy: {
      '/auto-loan-api': {
        target: 'http://t1-managerdaikuan.2345.com', // T1环境
        // target: 'http://d1-managerdaikuan.2345.com', // 目标网址，开发域名D2
        // target: 'http://172.16.0.141:10102', // 目标网址，开发域名D2
        // target: 'http://172.17.16.103:8080', // 目标网址，王浩机器
        // target: 'http://172.17.16.194:8080', // 目标网址，姜绵岳机器
        ws: false, // 是否启用websockets,此项目不存在ws连接
        changOrigin: true, // 是否将请求header中的origin修改为目标地址
        pathRewrite: {
          '^/auto-loan-api': ''
        }
      },
      '/asset-servic': {
        target: 'http://t1-managerdaikuan.2345.com', // T1环境
        // target: 'http://d1-managerdaikuan.2345.com', // 目标网址，开发域名D2
        // target: 'http://172.16.0.141:10102', // 目标网址，开发域名D2
        // target: 'http://172.17.16.103:8080', // 目标网址，王浩机器
        // target: 'http://172.17.16.194:8080', // 目标网址，姜绵岳机器
        ws: false, // 是否启用websockets,此项目不存在ws连接
        changOrigin: true // 是否将请求header中的origin修改为目标地址
      }
    }, // 转发代理配置
    // 浏览器 overlay（刷新） 同时显示eslint的警告和错误
    overlay: {
      warnings: true,
      errors: true
    }
  },
  configureWebpack: (config) => {
    config.resolve.extensions = ['.js', '.vue', '.css', '.json']
    if (isProd) {
      config.plugins.push(
        new webpack.DllReferencePlugin({
          context: process.cwd(),
          manifest: resolve('dll/dll_manifest.json')
        }),
        new webpack.DllReferencePlugin({
          context: process.cwd(),
          manifest: resolve('dll/element_manifest.json')
        }),
        new webpack.DllReferencePlugin({
          context: process.cwd(),
          manifest: resolve('dll/vuePolymerizationLib_manifest.json')
        }),
        new AddAssetHtmlPlugin({
          filepath: resolve('dll/*.js')
        })
      )
    }
  },
  runtimeCompiler: true // 运行时是否需要编译
  // transpileDependencies: [] // 默认babel-loader忽略mode_modules，添加无需babel-loader支持的包名
  // parallel: require('os').cpus().length > 1 // 构建时开启多进程处理babel编译
}
