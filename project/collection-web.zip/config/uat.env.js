/*
 * 线上测试环境
 * 域名：http://t1-managerdaikuan.2345.com/
 * 不同域名时需写明
 * */
module.exports = {
  NODE_ENV: '"uat"',
  BASE_API: '"/collection-service/"',
  COLLECTION_BASE_API: '"/collection/"', // 老催收系统
  UCENTER_SERVER_API: '"/ucenter-server/userCenter/"', // 用户中心服务端地址
  UCENTER_API: '"/ucenter/"', // 用户中心前端地址
  COLLECTION_BATCH_API: '"/collection-batch/"', // 催收定时任务
  IS_NOT_SSO: false // 是否单点登录开关
}
