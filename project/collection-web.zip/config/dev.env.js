/* 本地测试环境 */
module.exports = {
  NODE_ENV: '"development"',
  BASE_API: '"http://t1-managerdaikuan.2345.com/collection-service/"',
  // BASE_API: '"http://172.17.90.196:8080/collection-service/"', // qiny
  COLLECTION_BASE_API: '"http://t1-managerdaikuan.2345.com/collection/"', // 老催收系统
  UCENTER_SERVER_API: '"http://t1-managerdaikuan.2345.com/ucenter-server/userCenter/"', // 用户中心服务端地址
  UCENTER_API: '"http://t1-managerdaikuan.2345.com/ucenter/"', // 用户中心前端地址
  COLLECTION_BATCH_API: '"http://t1-managerdaikuan.2345.com/collection-batch/"', // 催收定时任务
  IS_NOT_SSO: false // 是否单点登录开关 默认false
}
