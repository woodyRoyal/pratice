import axios from 'axios'
import { Message, MessageBox } from 'element-ui'
import router from '../router'
import store from '../store'
import NProgress from 'nprogress' // Progress 进度条

const qs = require('qs') // 用于处理URL查询参数 转化为键值对的形式

// 创建axios实例
const service = axios.create({
  baseURL: process.env.COLLECTION_BATCH_API, // api的base_url
  timeout: 50000, // 指定请求超时的毫秒数(0 表示无超时时间)
  withCredentials: true, // 表示跨域请求时是否需要使用凭证 自动set-cookie
  headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'}
})

// request拦截器
service.interceptors.request.use(config => {
  // 开启进度条
  NProgress.start()
  if (config.method === 'post') { // 参数序列化
    config.data = qs.stringify(config.data)
  }
  return config
}, error => {
  // Do something with request error
  Promise.reject(error)
})

// respone拦截器
service.interceptors.response.use(
  response => {
    const code = response.data.errorCode
    /**
     * 下面的注释为通过response自定义errorCode来标示请求状态，当code返回如下情况为权限有问题，登出并返回到登录页
     * 如通过xmlhttprequest 状态码标识 逻辑可写在下面error中
     */
    // 未登陆：-100, 会话失效：-103
    if (code === -100 || code === -103) {
      console.log('请求信修Batch系统...')
      console.log(response.data)
      MessageBox.alert(response.data.errorMsg + ', 请重新登录', '提示', {
        confirmButtonText: '确定',
        type: 'warning',
        callback: action => {
          // 登出并返回到登录页
          if (!process.env.IS_NOT_SSO) { // 单点登录
            console.log('9999999999')
            store.dispatch('FilterLogout').then(() => {
              // 获取当前路由 以便登录后跳转回来
              window.location.href = process.env.UCENTER_API + '#/login'
            })
          } else { // 非单点登录
            store.dispatch('FilterLogout').then(() => {
              // 获取当前路由 以便登录后跳转回来
              let currUrl = window.location.href
              currUrl = currUrl.substring(currUrl.indexOf('#') + 1)
              router.push({path: '/login', query: {redirect: currUrl}})
            })
          }
        }
      })
    } else if (code !== 0) {
      Message({
        message: '请求信修Batch系统发生异常，' + response.data.errorMsg,
        type: 'error'
      })
    }
    // 关闭进度条
    NProgress.done()
    return response
  },
  error => {
    console.log('err' + error)// for debug
    if (error.response.status === 404) {
      Message({
        message: '网络连接异常',
        type: 'error'
      })
    } else {
      Message({
        message: '请求信修Batch系统发生错误，' + error.message,
        type: 'error'
      })
    }
    // 关闭进度条
    NProgress.done()
    return Promise.reject(error)
  }
)

export default service
