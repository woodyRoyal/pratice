export function getQueryObject (url) {
  url = url == null ? window.location.href : url
  const search = url.substring(url.lastIndexOf('?') + 1)
  const obj = {}
  const reg = /([^?&=]+)=([^?&=]*)/g
  search.replace(reg, (rs, $1, $2) => {
    const name = decodeURIComponent($1)
    let val = decodeURIComponent($2)
    val = String(val)
    obj[name] = val
    return rs
  })
  return obj
}

// Unexpected control character(s) in regular expression: \x00, \xff]/g
// src\utils\index.js:24:22
// if (val[i].match(/[^\x00-\xff]/ig) != null) {
// 如上错误，暂未解决，没使用过该方法，暂注释
/**
 *get getByteLen
 * @param {Sting} val input value
 * @returns {number} output value
 */
// export function getByteLen (val) {
//   let len = 0
//   for (let i = 0; i < val.length; i++) {
//     if (val[i].match(/[^\x00-\xff]/ig) != null) {
//       len += 1
//     } else { len += 0.5 }
//   }
//   return Math.floor(len)
// }

export function cleanArray (actual) {
  const newArray = []
  for (let i = 0; i < actual.length; i++) {
    if (actual[i]) {
      newArray.push(actual[i])
    }
  }
  return newArray
}

export function param (json) {
  if (!json) return ''
  return cleanArray(Object.keys(json).map(key => {
    if (json[key] === undefined) return ''
    return encodeURIComponent(key) + '=' +
      encodeURIComponent(json[key])
  })).join('&')
}

export function param2Obj (url) {
  const search = url.split('?')[1]
  return JSON.parse('{"' + decodeURIComponent(search).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g, '":"') + '"}')
}

export function html2Text (val) {
  const div = document.createElement('div')
  div.innerHTML = val
  return div.textContent || div.innerText
}

export function objectMerge (target, source) {
  /* Merges two  objects,
   giving the last one precedence */

  if (typeof target !== 'object') {
    target = {}
  }
  if (Array.isArray(source)) {
    return source.slice()
  }
  for (let property in source) {
    if (source.hasOwnProperty(property)) {
      const sourceProperty = source[property]
      if (typeof sourceProperty === 'object') {
        target[property] = objectMerge(target[property], sourceProperty)
        continue
      }
      target[property] = sourceProperty
    }
  }
  return target
}

export function scrollTo (element, to, duration) {
  if (duration <= 0) return
  const difference = to - element.scrollTop
  const perTick = difference / duration * 10
  setTimeout(() => {
    console.log(new Date())
    element.scrollTop = element.scrollTop + perTick
    if (element.scrollTop === to) return
    scrollTo(element, to, duration - 10)
  }, 10)
}

export function toggleClass (element, className) {
  if (!element || !className) {
    return
  }
  let classString = element.className
  const nameIndex = classString.indexOf(className)
  if (nameIndex === -1) {
    classString += '' + className
  } else {
    classString = classString.substr(0, nameIndex) + classString.substr(nameIndex + className.length)
  }
  element.className = classString
}

export const pickerOptions = [
  {
    text: '今天',
    onClick (picker) {
      const end = new Date()
      const start = new Date(new Date().toDateString())
      end.setTime(start.getTime())
      picker.$emit('pick', [start, end])
    }
  }, {
    text: '最近一周',
    onClick (picker) {
      const end = new Date(new Date().toDateString())
      const start = new Date()
      start.setTime(end.getTime() - 3600 * 1000 * 24 * 7)
      picker.$emit('pick', [start, end])
    }
  }, {
    text: '最近一个月',
    onClick (picker) {
      const end = new Date(new Date().toDateString())
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
      picker.$emit('pick', [start, end])
    }
  }, {
    text: '最近三个月',
    onClick (picker) {
      const end = new Date(new Date().toDateString())
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
      picker.$emit('pick', [start, end])
    }
  }]

export const pickerOptions1 = {
  // 禁止选择2017-09-15之前和明天之后的日期，但是快捷按键如果超过，那么无法禁止，官网如此，待更新
  // 一周，一个月，三个月（以今天为准，之前的日期）
  disabledDate (time) {
    return time.getTime() > new Date() || time.getTime() < new Date('2017-09-15')
  },
  shortcuts: [{
    text: '最近一周',
    onClick (picker) {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
      picker.$emit('pick', [start, end])
    }
  }, {
    text: '最近一个月',
    onClick (picker) {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
      picker.$emit('pick', [start, end])
    }
  }, {
    text: '最近三个月',
    onClick (picker) {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
      picker.$emit('pick', [start, end])
    }
  }]
}

export const pickerOptions2 = {
  // 禁止选择今天之前的日期，一周，一个月，三个月（以今天为准，之后的日期）
  disabledDate (time) {
    return time.getTime() < new Date().getTime() - 3600 * 1000 * 24
  },
  shortcuts: [{
    text: '一周',
    onClick (picker) {
      const end = new Date()
      const start = new Date()
      end.setTime(start.getTime() + 3600 * 1000 * 24 * 7)
      picker.$emit('pick', [start, end])
    }
  }, {
    text: '一个月',
    onClick (picker) {
      const end = new Date()
      const start = new Date()
      end.setTime(start.getTime() + 3600 * 1000 * 24 * 30)
      picker.$emit('pick', [start, end])
    }
  }, {
    text: '三个月',
    onClick (picker) {
      const end = new Date()
      const start = new Date()
      end.setTime(start.getTime() + 3600 * 1000 * 24 * 90)
      picker.$emit('pick', [start, end])
    }
  }]
}

export const pickerOptions3 = {
  // 禁止选择今天之后的日期，一周，一个月，三个月（以今天为准，之前的日期）
  disabledDate (time) {
    return time.getTime() > new Date().getTime() - 3600 * 1000 * 24
  },
  shortcuts: [{
    text: '一周',
    onClick (picker) {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
      picker.$emit('pick', [start, end])
    }
  }, {
    text: '一个月',
    onClick (picker) {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
      picker.$emit('pick', [start, end])
    }
  }, {
    text: '三个月',
    onClick (picker) {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
      picker.$emit('pick', [start, end])
    }
  }]
}

export const pickerOptions4 = {
  // 禁止选择今天之后的日期，一周，一个月，三个月（今天可选）
  disabledDate (time) {
    return time.getTime() > new Date().getTime()
  },
  shortcuts: [{
    text: '一周',
    onClick (picker) {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
      picker.$emit('pick', [start, end])
    }
  }, {
    text: '一个月',
    onClick (picker) {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
      picker.$emit('pick', [start, end])
    }
  }, {
    text: '三个月',
    onClick (picker) {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
      picker.$emit('pick', [start, end])
    }
  }]
}

export function getTime (type) {
  if (type === 'start') {
    return new Date().getTime() - 3600 * 1000 * 24 * 90
  } else {
    return new Date(new Date().toDateString())
  }
}

export function isEmptyObject (obj) {
  if (!obj) {
    return true
  }
  for (let item in obj) {
    return false // 返回false，不为空对象
  }
  return true // 返回true，为空对象
}

// 获取字符串长度 中文汉字占2个字符
export function getStrLeng (str) {
  let len = 0
  for (let i = 0; i < str.length; i++) {
    if (str.charCodeAt(i) > 0 && str.charCodeAt(i) < 128) { // 英文占1个字符
      len++
    } else { // 中文汉字占2个字符
      len += 2
    }
  }
  return len
}

/*
 获取对象所有key值
 @param Object
 example：{
     '1': 'test1',
     '2': 'test2',
     '3': 'test3'
    }
 @return Array
 */
export function getObjAllKeys (jsonObj) {
  let keys = []
  for (let key in jsonObj) {
    keys.push(key)
  }
  return keys
}

/**
 * 对象数组的深度拷贝.
 * source是原数据，extendObj是新增的键值对
 */
export const objArrDeepCopy = (source, extendObj) => {
  let sourceCopy = source instanceof Array ? [] : {}
  for (let item in source) {
    sourceCopy[item] = typeof source[item] === 'object' ? objArrDeepCopy(source[item], extendObj) : source[item]
    if (typeof extendObj === 'object' && !(sourceCopy instanceof Array)) {
      for (let param in extendObj) {
        sourceCopy[param] = extendObj[param]
      }
    }
  }
  return sourceCopy
}

/*
 获取URL后的参数
 @param name 参数名
 @return 参数值
 */
export function getQueryString (name) {
  let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)')
  // let r = window.location.search.substr(1).match(reg)
  let num = window.location.href.indexOf('?')
  let r = window.location.href.substr(num + 1).match(reg)
  if (r != null) return decodeURIComponent(r[2])
  return null
}

/**
 * 取整
 * @param value
 * @return 整数
 */
export function getIntger (value) {
  if (value !== '') {
    // 截取小数点前的数据
    if (value.indexOf('.') >= 0) {
      value = value.substring(0, value.indexOf('.'))
    }
    if (isNaN(value)) { // 只能输入数字
      value = value.replace(/[^\d]/g, '')
    }
  }
  return value
}

/**
 * 获取最多两位小数
 * @param value
 * @return 整数
 */
export function getMaxTwoDecimalPlaces (value) {
  if (value !== '') {
    // 先转为字符串
    value = value + ''
    // 只能输入数字和小数点
    value = value.replace(/[^\d.]/g, '')
    // 验证第一个字符是数字而不是.
    value = value.replace(/^\./g, '0.')
    // 只保留第一个. 清除多余的
    value = value.replace(/\.{2,}/g, '.')
    value = value.replace('.', '$#$').replace(/\./g, '').replace('$#$', '.')
    // 只能输入两个小数
    value = value.replace(/^(-)*(\d+)\.(\d\d).*$/, '$1$2.$3')

    value = value !== '' ? parseFloat(value) : value
  }
  return value
}

/**
 * 货币格式 分转化为元，并保留两位小数
 * value是原数据
 */
export function getFenToYuanCurrency (value) {
  let num = value * 0.01 // 分到元
  num += '' // 转成字符串
  if (num.indexOf('.') > -1) {
    return num
  } else {
    num = num + '.00'
  }
  let reg = num.indexOf('.') > -1 ? /(\d{1,3})(?=(?:\d{3})+\.)/g : /(\d{1,3})(?=(?:\d{3})+$)/g // 确定使用有哪个正则
  num = num.replace(reg, '$1,') // 千分位格式化
  return num
}

/**
 * 光标处插入值（调整：增加{}）
 * @param myField
 * @param myValue
 */
export function insertAtCursor (myField, myValue) {
  myValue = '{' + myValue + '}'
  if (document.selection) { // IE 浏览器
    myField.focus()
    let sel = document.selection.createRange()
    sel.text = myValue
    sel.select()
  } else if (myField.selectionStart || myField.selectionStart === 0) { // FireFox、Chrome等
    let startPos = myField.selectionStart
    let endPos = myField.selectionEnd

    // 保存滚动条
    let restoreTop = myField.scrollTop
    myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos, myField.value.length)
    if (restoreTop > 0) {
      myField.scrollTop = restoreTop
    }

    myField.focus()
    myField.selectionStart = startPos + myValue.length
    myField.selectionEnd = startPos + myValue.length
  } else {
    myField.value += myValue
    myField.focus()
  }
}
/**
 * 光标处插入值（原版：什么都不增加）
 * @param myField
 * @param myValue
 */
export function insertAtCursorOriginal (myField, myValue) {
  if (document.selection) { // IE 浏览器
    myField.focus()
    let sel = document.selection.createRange()
    sel.text = myValue
    sel.select()
  } else if (myField.selectionStart || myField.selectionStart === 0) { // FireFox、Chrome等
    let startPos = myField.selectionStart
    let endPos = myField.selectionEnd

    // 保存滚动条
    let restoreTop = myField.scrollTop
    myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos, myField.value.length)
    if (restoreTop > 0) {
      myField.scrollTop = restoreTop
    }

    myField.focus()
    myField.selectionStart = startPos + myValue.length
    myField.selectionEnd = startPos + myValue.length
  } else {
    myField.value += myValue
    myField.focus()
  }
}
/**
 * base64解码
 * @param str
 */
export function base64decode (str) {
  let base64decodechars = [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1]
  let c1, c2, c3, c4
  let i, len, out
  len = str.length
  i = 0
  out = ''
  while (i < len) {
    do {
      c1 = base64decodechars[str.charCodeAt(i++) & 0xff]
    } while (i < len && c1 === -1)
    if (c1 === -1) { break }
    do {
      c2 = base64decodechars[str.charCodeAt(i++) & 0xff]
    } while (i < len && c2 === -1)
    if (c2 === -1) { break }
    out += String.fromCharCode((c1 << 2) | ((c2 & 0x30) >> 4))

    do {
      c3 = str.charCodeAt(i++) & 0xff
      if (c3 === 61) { return out }
      c3 = base64decodechars[c3]
    } while (i < len && c3 === -1)
    if (c3 === -1) { break }
    out += String.fromCharCode(((c2 & 0xf) << 4) | ((c3 & 0x3c) >> 2))

    do {
      c4 = str.charCodeAt(i++) & 0xff
      if (c4 === 61) { return out }
      c4 = base64decodechars[c4]
    } while (i < len && c4 === -1)
    if (c4 === -1) { break }
    out += String.fromCharCode(((c3 & 0x03) << 6) | c4)
  }
  return out
}
