import Stomp from 'stompjs'
import SockJS from 'sockjs-client'

export const socket = {
  endpoint: 'endpoint',
  stompClient: null,
  bcScribeUrl: '/broadcast/message',
  p2pScribeUrl: '/user/1001/message', // /user/{userId}/message
  sendUrl: '/send_message',
  serviceNum: null,
  socketUrl: null,
  renderBcResult: null,
  renderP2pResult: null,
  successCallback: null,
  checkSocketClose: null
}
/**
 * 初始化webSocket
 *  1 连接到服务器端
 *  2 注册订阅回调函数
 * @param url
 * @param renderBcResult 广播回调函数
 * @param renderP2pResult 点对点回调函数
 * @param successCallback webSocket连接成功回调函数
 * @param checkSocketClose 连接失败回调函数
 */
export const outbound = {
  initWebSocket: (url, renderBcResult, renderP2pResult, successCallback, checkSocketClose) => { // 使用sockjs，替代原生的websocket
    socket.socketUrl = url
    socket.renderBcResult = renderBcResult
    socket.renderP2pResult = renderP2pResult
    socket.successCallback = successCallback
    socket.checkSocketClose = checkSocketClose
    /* eslint-disable */
    console.log(url)
    const socketJS = new SockJS(url + socket.endpoint)
    /* eslint-enable */
    if (!socket.stompClient) {
      socket.stompClient = Stomp.over(socketJS)
      // 默认debug日志打印到控制台
      socket.stompClient.debug = null
      // 心跳机制 client will send heartbeats every 20000ms
      socket.stompClient.heartbeat.outgoing = 2000
      // 心跳机制 client does not want to receive heartbeats from the server
      socket.stompClient.heartbeat.incoming = 4000
    }
    if (socket.stompClient !== null) {
      // 广播地址、点对点地址
      socket.stompClient.connect({}, () => {
        socket.stompClient.subscribe('/user/' + socket.serviceNum + '/message', renderP2pResult)
        successCallback()
      }, checkSocketClose)
    }
  },

  send: (message) => {
    socket.stompClient.send(socket.sendUrl, {}, JSON.stringify(message))
  },

  closeSession: () => {
    if (socket.stompClient !== null) {
      socket.stompClient.disconnect()
    }
  },

  reconnectWebsocket: () => {
    socket.stompClient = null
    this.initWebSocket(socket.socketUrl, socket.renderBcResult, socket.renderP2pResult, socket.successCallback, socket.checkSocketClose)
  }
}
