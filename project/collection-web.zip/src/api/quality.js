import fetch from 'utils/fetch'

// 打开案件详情
export const URL_OPEN_CASE_DETAIL = process.env.COLLECTION_BASE_API + 'caseDetail'

/* ----------人工质检---------- */

// 获取操作列表
export function fetchCallRecordList (caseId, callRecordId, pageable) {
  return fetch({
    url: 'restfulservice/qualityCheckingService/findCaseOperationListRecords',
    method: 'get',
    params: {caseId, callRecordId, pageable}
  })
}

// 获取差错类型列表
export function fetchMistakeList () {
  return fetch({
    url: 'restfulservice/qualityCheckingService/getCaseErrorType',
    method: 'get'
  })
}

// 获取案件信息
export function fetchCaseInfo () {
  return fetch({
    url: 'restfulservice/qualityCheckingService/getQualitycheckCase',
    method: 'get'
  })
}

// 提交质检结果
export function fetchCommitQCResult (commit) {
  const data = {
    commit
  }
  return fetch({
    url: 'restfulservice/qualityCheckingRecordService/commitQualityCheckingResult',
    method: 'post',
    data
  })
}

/* ---------- 质检员和催收等列表接口 ---------- */

// 获取质检信息数据
export function fetchGetQCMsg () {
  return fetch({
    url: 'restfulservice/qualityCheckingRecordService/getQualitityCheckingParamByRole',
    method: 'get'
  })
}

// 获取差错类型列表数据errorTypeList
export function fetchGetErrorTypeList () {
  return fetch({
    url: 'restfulservice/qualityCheckingService/getAllCaseErrorType',
    method: 'get'
  })
}

// 获取催收信息数据
export function fetchGetCollectionMsg () {
  return fetch({
    url: 'restfulservice/collectorQualityCheckingSumReportService/findCollectorQualityCheckingSumQueryParam',
    method: 'post'
  })
}

/* ---------- 质检员质检结果明细 ---------- */

// 获取质检明细数据 data为筛选参数
export function fetchGetQualityControlDetailList (paramBo, pageable) {
  const data = {
    paramBo,
    pageable
  }
  return fetch({
    // url: 'http://172.16.23.62:8080/collection-service/restfulservice/qualityCheckingRecordService/findCaseQualitityCheckingRecords',
    url: 'restfulservice/qualityCheckingRecordService/findCaseQualitityCheckingRecords',
    method: 'post',
    data
  })
}

// 通过或者不通过质检
export function fetchPassOrRejectQC (checkingRecordId, callRecordId, statusCode, reviewerDesc) {
  const data = {
    checkingRecordId,
    callRecordId,
    statusCode,
    reviewerDesc
  }
  return fetch({
    url: 'restfulservice/qualityCheckingRecordService/commitQualityReviewCheckingResult',
    method: 'post',
    data
  })
}

// 导出质检明细数据
export const URL_EXPORT_QC_DETAIL_DATA = process.env.BASE_API + 'download/qualityCheckingRecordService/exportCheckQualityCheckingReport'

/* ---------- 质检员工作统计 ---------- */

// 获取质检工作统计数据 data为筛选参数
export function fetchGetQualityControlJobAccountList (paramBo, pageable) {
  const data = {
    paramBo,
    pageable
  }
  return fetch({
    url: 'restfulservice/qualityCheckingCountReport/findQualityCheckingCountReport',
    method: 'post',
    data
  })
}

// 导出质检工作统计
export const URL_EXPORT_IQC_JOB_ACCOUNT_DATA = process.env.BASE_API + 'download/qualityCheckingCountReport/exportQualityCheckingCountReport'

/* ---------- 质检员质检汇总 ---------- */

// 获取质检员质检汇总数据 data为筛选参数
export function fetchGetQualityInspectionSummaryList (paramBo, pageable) {
  const data = {
    paramBo,
    pageable
  }
  return fetch({
    url: 'restfulservice/qualityCheckingSumCountReportService/findQualityCheckingSumCountReport',
    method: 'post',
    data
  })
}

// 导出质检员质检汇总
export const URL_EXPORT_IQC_SUMMARY_DATA = process.env.BASE_API + 'download/qualityCheckingSumCountReportService/exportQualityCheckingSumCountReport'

/* ---------- 催收员质检结果明细 ---------- */

// 获取催收员质检结果明细 data为筛选参数
export function fetchGetCollectorQCDetailList (paramBo, pageable) {
  const data = {
    paramBo,
    pageable
  }
  return fetch({
    url: 'restfulservice/collectorQualityCheckingReportService/findCollectorQualityCheckingReport',
    method: 'post',
    data
  })
}

// 导出催收员质检结果明细
export const URL_EXPORT_COLLECTOR_QC_DETAIL_DATA = process.env.BASE_API + 'download/collectorQualityCheckingReportService/exportCollectorQualityCheckingReport'

/* ---------- 催收员质检汇总 ---------- */

// 获取催收员质检汇总 data为筛选参数
export function fetchGetCollectorQCSummaryList (paramBo, pageable) {
  const data = {
    paramBo,
    pageable
  }
  return fetch({
    url: 'restfulservice/collectorQualityCheckingSumReportService/findCollectorQualityCheckingSumReport',
    method: 'post',
    data
  })
}

// 导出催收员质检汇总
export const URL_EXPORT_COLLECTOR_QC_SUMMARY_DATA = process.env.BASE_API + 'download/collectorQualityCheckingSumReportService/exportCollectorQualityCheckingSumReport'

/* ---------- 催收组质检汇总 ---------- */

// 获取催收组质检汇总  data为筛选参数
export function fetchGetCollectionGroupQCSummaryList (paramBo, pageable) {
  const data = {
    paramBo,
    pageable
  }
  return fetch({
    url: 'restfulservice/collectorGroupQualityCheckingSumReportService/findCollectorGroupQualityCheckingSumReport',
    method: 'post',
    data
  })
}

// 导出催收组质检汇总
export const URL_EXPORT_COLLECTION_GROUP_QC_SUMMARY_DATA = process.env.BASE_API + 'download/collectorGroupQualityCheckingSumReportService/exportCollectorGroupQualityCheckingSumReport'

/* ---------- 质检配置 ---------- */

// 获取质检配置列表
export function fetchGetCheckingPoolParam () {
  return fetch({
    url: 'restfulservice/checkingPoolParamService/findAll',
    method: 'post'
  })
}

// 修改质检配置
export function fetchSaveCheckingPoolParam (checkingPoolParam) {
  const data = {
    checkingPoolParam
  }
  return fetch({
    url: 'restfulservice/checkingPoolParamService/save',
    method: 'post',
    data
  })
}

/* ---------- 质检池清理 ---------- */

// 获取质检池列表
export function fetchGetCheckingPoolList () {
  return fetch({
    url: 'restfulservice/qualityCheckingService/findAll',
    method: 'post'
  })
}

// 清除质检池
export function fetchDeleteCheckingPool (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/qualityCheckingService/deleteCheckingPool',
    method: 'post',
    data
  })
}
