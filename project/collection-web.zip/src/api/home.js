import fetch from 'utils/fetch'

// 获取本月回款情况
export function fetchCurrCollectorRepaymentInfo (pageable) {
  return fetch({
    url: 'restfulservice/repaymentDetailService/findCurrCollectorRepaymentInfo',
    method: 'get',
    params: {pageable}
  })
}

// 获取今日提醒数据
export function fetchTodayRemindData (pageable, status) {
  return fetch({
    url: 'restfulservice/homePageService/getCurrentRemind',
    method: 'get',
    params: {pageable, status}
  })
}

// 获取近5天登录用户
export function fetchUserActiveInfo (pageable) {
  return fetch({
    url: 'restfulservice/homePageService/getUserActiveInfo',
    method: 'get',
    params: {pageable}
  })
}

// 近期登录操作变红
export function fetchSaveOverdueActiveOperate (caseId) {
  const data = {caseId}
  return fetch({
    url: 'restfulservice/homePageService/saveOverdueActiveOperate',
    method: 'post',
    data
  })
}

// 今日提醒操作变红
export function fetchHandleCurrentRemind (caseId) {
  const data = {caseId}
  return fetch({
    url: 'restfulservice/homePageService/handleCurrentRemind',
    method: 'post',
    data
  })
}

// 今日提醒每隔5分钟轮询接口==========GET
export function fetchCurrentRemindEvery5Minutes () {
  return fetch({
    url: 'restfulservice/homePageService/getCurrentRemindInterval',
    method: 'get'
  })
}

// 获取逾期用户激活信息提醒轮询接口
export function fetchOverdueUserActiveInfoRemind () {
  return fetch({
    url: 'restfulservice/homePageService/getOverdueUserActiveInfoRemindInterval',
    method: 'get'
  })
}

// 获取投诉信息提醒轮询接口
export function fetchFindComplainBillRemind (pollingmark) {
  return fetch({
    url: 'restfulservice/complainBillRemindService/findComplainBillRemind',
    method: 'get',
    params: {pollingmark}
  })
}

// 获取投诉数量
export function fetchGetComplainNum () {
  return fetch({
    url: 'restfulservice/complainBillRemindService/countComplainBillRemindNum',
    method: 'get'
  })
}

// 获取近5天更新了通讯录的
export function fetchUpdateContacts (pageable, days) {
  return fetch({
    url: 'restfulservice/homePageService/getUpdateContactBeforeSomeDays',
    method: 'get',
    params: {pageable, days}
  })
}
// 获取近5天更新了通讯录的，变红
export function fetchSaveContactUpdateCaseOperate (caseId) {
  const data = {caseId}
  return fetch({
    url: 'restfulservice/homePageService/saveContactUpdateCaseOperate',
    method: 'post',
    data
  })
}

// 获取近5天产生的共债案件
export function fetchGzCases (pageable, days) {
  return fetch({
    url: 'restfulservice/homePageService/getGzCaseRemindList',
    method: 'get',
    params: {pageable, days}
  })
}
// 获取近5天产生的共债案件，变红
export function fetchSaveGzCaseOperate (caseId) {
  const data = {caseId}
  return fetch({
    url: 'restfulservice/homePageService/checkGzCase',
    method: 'post',
    data
  })
}
