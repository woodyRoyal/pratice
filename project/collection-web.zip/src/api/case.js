import fetch from 'utils/fetch'
import store from '../store'
/* ----------案件管理---------- */

/* ----------公用接口 已废弃 start---------- */

// 获取催收员列表
export function fetchAllCollectorList () {
  return fetch({
    url: 'restfulservice/selectParamService/findCollectorList',
    method: 'get'
  })
}
// 获取机构列表
export function fetchAllMechanList () {
  return fetch({
    url: 'restfulservice/selectParamService/findMechanList',
    method: 'get'
  })
}

// 获取催收经理和催收组列表
export function fetchManagerAndGroupList () {
  return fetch({
    url: 'restfulservice/selectParamService/findManagerAndGroupList',
    method: 'get'
  })
}

/* ----------公用接口 已废弃 end---------- */

/* ----------分案上限设置页面---------- */

// 导入文件 下载
export const URL_DOWNLOAD_CASE_ASSIGN = process.env.BASE_API + 'download/caseAssignLimitService/downloadFile'

// 导入历史 表格数据获取
export function fetchGetAssignImportList (pageable) {
  const data = {
    pageable
  }
  return fetch({
    url: 'restfulservice/caseAssignLimitService/findImportHistory',
    method: 'post',
    data
  })
}

// 上传
export const URL_UPLOAD_CASE_ASSIGN = process.env.BASE_API + 'upload/caseAssignLimitService/uploadFile'

// 上传是否成功
export function fetchIsUploadOver (isUploadOverFlag) {
  return fetch({
    url: 'restfulservice/caseAssignLimitService/isUploadOver',
    method: 'get',
    params: {isUploadOverFlag}
  })
}

// 导入结果 fileId 查询失败结果
export function fetchGetImportResultByFileId (fileId, pageable) {
  const data = {
    fileId,
    pageable
  }
  return fetch({
    url: 'restfulservice/caseAssignLimitService/findImportResultByFileId',
    method: 'post',
    data
  })
}

/* ----------分案上限查询页面---------- */

// 用户名 中文名 组别 数据获取
export function fetchGetCaseLimitParams () {
  return fetch({
    url: 'restfulservice/caseAssignLimitService/caseLimitParams',
    method: 'get'
  })
}

// 表格数据获取
export function fetchGetAssignLimitList (param, pageable) {
  const data = {
    param,
    pageable
  }
  return fetch({
    url: 'restfulservice/caseAssignLimitService/findLimitList',
    method: 'post',
    data
  })
}

// 修改
export function fetchUpdateLimitList (ids, dayLimit, monthLimit) {
  const data = {
    ids,
    dayLimit,
    monthLimit
  }
  return fetch({
    url: 'restfulservice/caseAssignLimitService/updateLimitList',
    method: 'post',
    data
  })
}

// 删除
export function fetchCleanLimitList (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/caseAssignLimitService/cleanLimitList',
    method: 'post',
    data
  })
}

// 导出
export const URL_EXPORT_ASSIGN_LIMIT_LIST = process.env.BASE_API + 'download/caseAssignLimitService/exportLimitList'

/* ----------可分案配置---------- */

// 执行分案
export function fetchPerformAssignCase () {
  return fetch({
    url: 'restfulservice/assignCaseConfService/autoAssignCase',
    method: 'get'
  })
}

// 获取当前配置
export function fetchAssignableConfigList () {
  return fetch({
    url: 'restfulservice/assignCaseConfService/findAllAssignCaseConf',
    method: 'get'
  })
}

// 保存配置
export function fetchUpdateAssignableConfig (assignCaseConf) {
  const data = {
    assignCaseConf
  }
  return fetch({
    url: 'restfulservice/assignCaseConfService/saveOrUpdate',
    method: 'post',
    data
  })
}

/* ----------未分配案件导出---------- */
// 获取所有逾期阶段预设值
export function fetchOverdueDaysDefault () {
  return fetch({
    url: 'restfulservice/caseUnassignService/findOverdueDayConfigList',
    method: 'get'
  })
}

// 未分配案件列表
export function fetchUnassignedCaseList (param, pageable) {
  const data = {
    param, pageable
  }
  return fetch({
    url: 'restfulservice/caseUnassignService/findCaseUnassignList',
    method: 'post',
    data
  })
}

// 导出未分配案件列表
export const URL_EXPORT_UNASSIGNED_CASE = process.env.BASE_API + 'download/caseUnassignService/exportCaseUnassignList'

/* ----------分配案件---------- */

// 案件分配历史查询
export function fetchGetAssignHistoryList (param, pageable) {
  return fetch({
    url: 'restfulservice/caseAssignListService/getAssignHistoryData',
    method: 'get',
    params: {param, pageable}
  })
}

// 导出案件分配详细
export const URL_EXPORT_BY_ASSIGNID_AND_STATUS = process.env.BASE_API + 'download/caseAssignListService/exportByAssignIdAndStatus'

// 下载模板
export const URL_EXPORT_FILE_TEMPLATE = process.env.BASE_API + 'static/collection/manaul_assign_templet.csv'

// 查看最后一次自定义分配结果
export function fetchGetLastesAssignResult () {
  return fetch({
    url: 'restfulservice/caseAssignService/viewLastestAssignResult',
    method: 'get'
  })
}

// 上传 -分配案件
export const URL_IMPORT_CASE_ASSIGN_FILE = process.env.BASE_API + 'upload/caseAssignService/importFile'

/* ----------导入案件---------- */

// 上传 -导入案件
export const URL_IMPORT_CASE_FILE = process.env.BASE_API + 'upload/importMobileService/importFile'

// 查询导入案件历史
export function fetchGetImportHistoryList (pageable) {
  return fetch({
    url: 'restfulservice/importMobileService/getImoprtHistory',
    method: 'get',
    params: {pageable}
  })
}

// 查询最后一次上传记录
export function fetchGetLastImportResult () {
  return fetch({
    url: 'restfulservice/importMobileService/viewLastestImportResult',
    method: 'get'
  })
}

// 下载模板
export const URL_EXPORT_IMPORT_CASE_TEMPLATE = process.env.BASE_API + 'static/collection/import_case_templet.csv'

// 导入案件的导入文件下载
export const URL_EXPORT_LOAD_SIGNAGE = process.env.BASE_API + 'download/importMobileService/downLoadFileByFileId'

/* ----------案件查询---------- */
export function fetchIsReadRule () {
  return fetch({
    url: 'restfulservice/caseNewQueryService/isReadRule',
    method: 'get'
  })
}

export function fetchAgreeRule () {
  return fetch({
    url: 'restfulservice/caseNewQueryService/agreeRule',
    method: 'post'
  })
}

// 获取催收员点击案件记录
export function fetchSaveCaseOperationStatus (caseId, collectorId) {
  const data = {
    caseId,
    collectorId
  }
  return fetch({
    url: 'restfulservice/caseDetailService/saveCaseOperationStatus',
    method: 'post',
    data
  })
}

// 查询页需要属性信息
export function fetchCaseQueryAttributeVo () {
  return fetch({
    url: 'restfulservice/caseNewQueryService/getCaseQueryAttributeVo',
    method: 'get'
  })
}

// 查询案件详情
export function fetchCaseNewQueryDataList (caseQueryParmBo, pageable) {
  return fetch({
    url: 'restfulservice/caseNewQueryService/caseNewQueryDataList',
    method: 'get',
    params: {caseQueryParmBo, pageable}
  })
}

// 查询案件详情
export function fetchCountNewQueryDebtRepayAmount (caseQueryParmBo, uniqueTag) {
  return fetch({
    url: 'restfulservice/caseNewQueryService/countNewQueryDebtRepayAmount',
    method: 'get',
    params: {caseQueryParmBo, uniqueTag}
  })
}

// 分配案件
export function fetchCaseAssign (caseIds, collectors) {
  return fetch({
    url: 'restfulservice/caseAssignService/manaulAssignCaseByPerson',
    method: 'get',
    params: {caseIds, collectors}
  })
}

/* ----------历史结清案件查询---------- */

export function fetchHistoryCaseQueryData (repaidCaseHisDTO, pageable) {
  const data = {repaidCaseHisDTO, pageable}
  return fetch({
    url: 'restfulservice/caseHistoryService/getRepaidCaseList',
    method: 'post',
    data
  })
}

/* ----------案件详情---------- */
// 获取案件照片
export function fetchCasePicture (orderId) {
  return fetch({
    url: 'restfulservice/caseDetailService/getCaseUserImage',
    method: 'get',
    params: {orderId}
  })
}

// CallPhoneNumbersService isPassTheLimitTimes 判断是否超过限制次数，超过限制次数，不给予拨打
export function fetchIsPassTheLimitTimes (caseId, phone, order) {
  const data = {
    caseId, phone, order
  }
  return fetch({
    url: 'restfulservice/callPhoneNumbersService/isPassTheLimitTimes',
    method: 'post',
    data
  })
}
// 单呼获取uuid及callRecordId ICallPrjoecExecuteService.getSingleCallInfo
export function fetchGetSingleCallInfo (caseId, phone, calledName) {
  const data = {
    caseId, phone, calledName
  }
  return fetch({
    url: 'restfulservice/iCallPrjoecExecuteService/getSingleCallInfo',
    method: 'post',
    data
  })
}
// websocket 接口地址
const currentTest = store.getters.currentTest
// console.log('电呼接入：' + store.getters.currentTest)
let str = ''
// 如果是生产直接返回/call-outbound/
if (window.location.origin === 'https://managerdaikuan.2345.com') {
  str = 'https://hjbackoffice.2345.com/call-outbound/'
} else if (currentTest === 'T1') {
  str = 'https://t1-managerdaikuan.2345.com/call-outbound/'
} else if (currentTest === 'T2') {
  str = 'https://t2-managerdaikuan.2345.com/call-outbound/'
} else if (currentTest === 'T3') {
  str = 'https://t3-managerdaikuan.2345.com/call-outbound/'
}
console.log('356：', str)
export const URL_WEBSOCKET_SERVER = str

// 单呼
export function fetchCreateSingleTask (userDTO, serviceNum, resultUrl, caseId) {
  const data = {
    userDTO, serviceNum, resultUrl, caseId
  }
  return fetch({
    url: 'restfulservice/callCenterClientService/createSingleTask',
    method: 'post',
    data
  })
}

// 单呼回传地址
export const URL_SINGLE_CALL_CALL_BACK = process.env.BASE_API + 'restfulservice/callCenterClientService/callback'

// 挂断 hangUp
export function fetchHangUp (serviceNum, reason) {
  const data = {
    serviceNum, reason
  }
  return fetch({
    url: 'restfulservice/callCenterClientService/hangUp',
    method: 'post',
    data
  })
}
// ICallPrjoecExecuteService.saveCallRecord 创建获取recordId
export function fetchSaveCallRecord (callProjectId, executeId, caseId, phone, calledName, uuid) {
  const data = {
    callProjectId, executeId, caseId, phone, calledName, uuid
  }
  return fetch({
    url: 'restfulservice/iCallPrjoecExecuteService/saveCallRecord',
    method: 'post',
    data
  })
}
// 获取用户姓名拼音 CaseDetailService # getChinessPinyin
export function fetchGetChinessPinyin (calledName) {
  const data = {
    calledName
  }
  return fetch({
    url: 'restfulservice/caseDetailService/getChinessPinyin',
    method: 'post',
    data
  })
}
// 批呼-获取callRecordId 和 拼音 ICallPrjoecExecuteService.saveCallRecord2
export function fetchSaveCallRecord2 (callProjectId, executeId, caseId, phone, calledName, uuid) {
  const data = {
    callProjectId, executeId, caseId, phone, calledName, uuid
  }
  return fetch({
    url: 'restfulservice/iCallPrjoecExecuteService/saveCallRecord2',
    method: 'post',
    data
  })
}
// icallPrjoectUseService.updateCommunicateStatusAndProjectStatus 更新通话记录（结束：call_result）
export function fetchUpdateExecuteRecord2 (paramBo) {
  const data = {
    paramBo
  }
  return fetch({
    url: 'restfulservice/iCallPrjoectUseService/updateExecuteRecord2',
    method: 'post',
    data
  })
}
// 催记 token caseDetailService#createCaseOperationToken
export function fetchGetTokenByCaseId (caseId) {
  return fetch({
    url: 'restfulservice/caseDetailService/createCaseOperationToken',
    method: 'get',
    params: {caseId}
  })
}
// 批呼
export function fetchCreateSingleToBatchTask (users, serviceNum, controlratio, resultUrl, realTimeMonitor) {
  const data = {
    users, serviceNum, controlratio, resultUrl, realTimeMonitor
  }
  return fetch({
    url: 'restfulservice/callCenterClientService/createSingleToBatchTask',
    method: 'post',
    data
  })
}

// 批呼回传地址
export const URL_BATCH_CALL_CALL_BACK = process.env.BASE_API + 'restfulservice/callCenterClientService/batchCallback'

// 接听下一个 answerNext
export function fetchAnswerNext (taskId, serviceNum) {
  const data = {
    taskId, serviceNum
  }
  return fetch({
    url: 'restfulservice/callCenterClientService/answerNext',
    method: 'post',
    data
  })
}
// 暂停 pauseTask
export function fetchPauseTask (taskId, serviceNum, reason) {
  const data = {
    taskId, serviceNum, reason
  }
  return fetch({
    url: 'restfulservice/callCenterClientService/pauseTask',
    method: 'post',
    data
  })
}
// 继续 continueTask
export function fetchContinueTask (taskId, serviceNum, reason) {
  const data = {
    taskId, serviceNum, reason
  }
  return fetch({
    url: 'restfulservice/callCenterClientService/continueTask',
    method: 'post',
    data
  })
}
// 停止 stopTask
export function fetchStopTask (taskId, serviceNum, reason) {
  const data = {
    taskId, serviceNum, reason
  }
  return fetch({
    url: 'restfulservice/callCenterClientService/stopTask',
    method: 'post',
    data
  })
}

// 停止外呼 stopCallProject
export function fetchStopCallProject (callProjectId) {
  return fetch({
    url: 'restfulservice/iCallPrjoecExecuteService/stopCallProject',
    method: 'get',
    params: {callProjectId}
  })
}

// 强制杀死坐席 killServiceNum
export function fetchKillServiceNum (serviceNum) {
  const data = {
    serviceNum
  }
  return fetch({
    url: 'restfulservice/callCenterClientService/killServiceNum',
    method: 'post',
    data
  })
}

// 强制杀死自己的坐席
export function fetchkillOwnServiceNum () {
  return fetch({
    url: 'restfulservice/callCenterClientService/killOwnServiceNum ',
    method: 'post'
  })
}

// 查询案件信息
export function fetchGetCaseInfo (caseId) {
  return fetch({
    url: 'restfulservice/caseDetailService/getCaseInfo',
    method: 'get',
    params: {caseId}
  })
}

// 查询用户操作 getUserOperateInApp
export function fetchGetUserOperateInApp (searchVO, pageable) {
  const data = {
    searchVO, pageable
  }
  return fetch({
    url: 'restfulservice/caseDetailService/getUserOperateInApp',
    method: 'post',
    data
  })
}

// 查询交易记录 getUserTransaction
export function fetchGetUserTransaction (searchVO, pageable) {
  const data = {
    searchVO, pageable
  }
  return fetch({
    url: 'restfulservice/caseDetailService/getUserTransaction',
    method: 'post',
    data
  })
}

// 查询逾期记录 getUserOverdueRecord
export function fetchGetUserOverdueRecord (userId, pageable) {
  return fetch({
    url: 'restfulservice/caseDetailService/getUserOverdueRecord',
    method: 'get',
    params: {userId, pageable}
  })
}

// 获取投诉记录
export function fetchGetListComplainRecordByUserId (data) {
  return fetch({
    url: 'restfulservice/complainBillService/listComplainRecordByUserId',
    method: 'get',
    params: data
  })
}

// 获取用户短信联系人记录 CaseDetailService#getUserSmsList
export function fetchGetUserSmsList (param, pageable) {
  return fetch({
    url: 'restfulservice/caseDetailService/getUserSmsList',
    method: 'get',
    params: {param, pageable}
  })
}

// 获取用户短信明细记录
export function fetchUserSmsDetailList (caseId, phoneNum, pageable) {
  return fetch({
    url: 'restfulservice/caseDetailService/getUserSmsDetailList',
    method: 'get',
    params: { caseId, phoneNum, pageable }
  })
}

// 获取用户短信查询参数
export function fetchSmsKeywordType () {
  return fetch({
    url: 'restfulservice/caseDetailService/getSmsKeywordType',
    method: 'get'
  })
}

// 获取用户短信记录 getUserSmsHistoryList
export function fetchGetUserSmsHistoryList (userId, contactor) {
  return fetch({
    url: 'restfulservice/caseDetailService/getUserSmsHistoryList',
    method: 'get',
    params: {userId, contactor}
  })
}

// 查询免息券 getUserFreeInterestCoupon
export function fetchGetUserFreeInterestCoupon (userId, productId, caseTime) {
  return fetch({
    url: 'restfulservice/caseDetailService/getUserFreeInterestCoupon',
    method: 'get',
    params: {userId, productId, caseTime}
  })
}

// 获取催记列表 getCaseOperateData
export function fetchGetCaseOperateData (params) {
  return fetch({
    url: 'restfulservice/caseDetailService/getCaseOperateData',
    method: 'get',
    params
  })
}

// 获取通讯录列表 getCaseContactData
export function fetchGetCaseContactData (caseId, order) {
  return fetch({
    url: 'restfulservice/caseDetailService/getCaseContactData',
    method: 'get',
    params: {caseId, order}
  })
}

// 新增联系人 appendContactor
export function fetchAppendContactor (appendContactVO) {
  const data = {
    appendContactVO
  }
  return fetch({
    url: 'restfulservice/caseDetailService/appendContactor',
    method: 'post',
    data
  })
}
// 获取产品列表 ProductSettingService#getAllProduct4Menu
export function fetchGetAllProduct4Menu () {
  return fetch({
    url: 'restfulservice/productSettingService/getAllProduct4Menu',
    method: 'get'
  })
}
// 提交催记 caseDetailService updateOperation
export function fetchUpdateOperation (submitVO, repaymentList) {
  const data = {
    submitVO, repaymentList
  }
  return fetch({
    url: 'restfulservice/caseDetailService/updateOperation',
    method: 'post',
    data
  })
}
// 获取通话结果 CallResultService#findByTypes
export function fetchFindByTypes (types) {
  const data = {
    types
  }
  return fetch({
    url: 'restfulservice/callResultService/findByTypes',
    method: 'post',
    data
  })
}

// 更新联系人选中状态 caseDetailService updateSmsChecked
export function fetchUpdateSmsChecked (caseId, contactIds, smsChecked) {
  const data = {
    caseId, contactIds, smsChecked
  }
  return fetch({
    url: 'restfulservice/caseDetailService/updateSmsChecked',
    method: 'post',
    data
  })
}

// 更新欠款信息 CaseDetailService updateCaseDetail
export function fetchUpdateCaseDetail (orderId) {
  const data = {
    orderId
  }
  return fetch({
    url: 'restfulservice/caseDetailService/updateCaseDetail',
    method: 'post',
    data
  })
}

// 更新案件用户信息 CaseDetailService updateCaseUser
export function fetchUpdateCaseUser (updateCaseUserVO) {
  const data = {
    updateCaseUserVO
  }
  return fetch({
    url: 'restfulservice/caseDetailService/updateCaseUser',
    method: 'post',
    data
  })
}
// 划扣信息 caseReduceDebtService findReduceConfigByCaseId
export function fetchFindReduceConfigByCaseId (caseId, billId) {
  return fetch({
    url: 'restfulservice/caseReduceDebtService/findReduceConfigByCaseId',
    method: 'get',
    params: {caseId, billId}
  })
}
// 划扣 caseReduceDebtService#callWsCaseReduceDebtRecord
export function fetchCallWsCaseReduceDebtRecord (debt, reduceRate, reduceAmout, realRepayment, userId, caseId, billId, productId) {
  const data = {
    debt, reduceRate, reduceAmout, realRepayment, userId, caseId, billId, productId
  }
  return fetch({
    url: 'restfulservice/caseReduceDebtService/callWsCaseReduceDebtRecord',
    method: 'post',
    data
  })
}
// 立即贷划扣接口 及 车贷王划扣接口
export function fetchCallProductCoreReduce (param) {
  const data = {param}
  return fetch({
    url: 'restfulservice/caseReduceDebtService/callProductCoreReduce',
    method: 'post',
    data
  })
}
// 划扣时查询期数等信息
export function fetchFindReduceForBuckle (billId, caseId, productId) {
  return fetch({
    url: 'restfulservice/caseReduceDebtService/findReduceForBuckle',
    method: 'get',
    params: {billId, caseId, productId}
  })
}
// 获取忽略逾期滞纳金开关（V3.14）
export function fetchGetWithoutOverdueFeeSwitch () {
  return fetch({
    url: 'restfulservice/withoutOverdueFeeSwitchService/getWithoutOverdueFeeSwitch',
    method: 'get'
  })
}
// 激活手机号 caseDetailService#activeMobilephone
export function fetchActiveMobilephone (contactId, caseId) {
  const data = {
    contactId, caseId
  }
  return fetch({
    url: 'restfulservice/caseDetailService/activeMobilephone',
    method: 'post',
    data
  })
}
// 今日提醒 CaseDetailService#getCurrentRemindData
export function fetchGetCurrentRemindData () {
  return fetch({
    url: 'restfulservice/caseDetailService/getCurrentRemindData',
    method: 'get'
  })
}
/* ******************  投诉工单 ****************** */
// 投诉工单获取
export function fetchGetComplainData (data) {
  return fetch({
    url: 'restfulservice/complainBillService/findByCondition',
    method: 'post',
    data
  })
}
// 导出投诉工单
export const URL_DOWNLOAD_COMPLAIN = process.env.BASE_API + 'download/complainBillService/exportCommentBill'

// 确认认领
export function fetchConfirmClaim (customerBillId) {
  return fetch({
    url: 'restfulservice/complainBillService/confirmBill',
    method: 'get',
    params: {customerBillId}
  })
}

// 变更受理人
export function fetchChangeAddressee (customerBillId, receivePersonId) {
  return fetch({
    url: 'restfulservice/complainBillService/modifyReceivePerson',
    method: 'get',
    params: {customerBillId, receivePersonId}
  })
}

// 详情
export function fetchGetDetail (billId) {
  return fetch({
    url: 'restfulservice/complainBillFlowService/queryComplainBillFlowList',
    method: 'get',
    params: {billId}
  })
}

// 处理投诉
export function fetchDealComplain (caseId, customerBillId, processComment, processStatus) {
  return fetch({
    url: 'restfulservice/complainBillService/processBill',
    method: 'get',
    params: {caseId, customerBillId, processComment, processStatus}
  })
}

/* ****************** 催收工作台********************* */
// 工作台任务列表
export function fetchGetTodayAssignment () {
  return fetch({
    url: 'restfulservice/workbenchCacheService/getTodayAssignment',
    method: 'get'
  })
}

// 工作台任务通讯录列表
export function fetchGetAssignmentContacts (assignmentId) {
  return fetch({
    url: 'restfulservice/workbenchCacheService/getAssignmentContacts',
    method: 'get',
    params: { assignmentId }
  })
}
// 开始任务（批呼）系统大于等于2用这个接口。 单呼用老接口
export function fetchCreateMulBatchTask (users, serviceNum, controlratio, resultUrl, realTimeMonitor, assignmentId) {
  return fetch({
    url: 'restfulservice/workbenchCallCenterService/createMulBatchTask',
    method: 'post',
    data: { users, serviceNum, controlratio, resultUrl, realTimeMonitor, assignmentId }
  })
}
// 重点关注
export function fetchFocus (caseId, type) {
  return fetch({
    url: 'restfulservice/workbenchCaseFocusService/focus',
    method: 'get',
    params: { caseId, type }
  })
}
// 案件是否被关注
export function fetchIsFocus (caseId) {
  return fetch({
    url: 'restfulservice/workbenchCaseFocusService/isFocus',
    method: 'get',
    params: { caseId }
  })
}

// 检查手机号能否拨打
export function fetchCheckCaseAndPhone (caseId, phone, assignmentId, order) {
  return fetch({
    url: 'restfulservice/workbenchCallCenterService/checkCaseAndPhone',
    method: 'get',
    params: { caseId, phone, assignmentId, order }
  })
}

// 加密解密 0:加密，1解密
export function fetchExchangePhone (flag, phone) {
  return fetch({
    url: 'restfulservice/phoneExchangeService/exchangePhone',
    method: 'get',
    params: { flag, phone }
  })
}

// 停催激活案件 suspendColl 停催标识 0：否，1：是
export function fetchActiveSuspendCase (caseId, suspendColl) {
  return fetch({
    url: 'restfulservice/caseDetailService/activeSuspendCase',
    method: 'post',
    data: { caseId, suspendColl }
  })
}

//
export function fetchGetAnsweringResult (serviceNum) {
  return fetch({
    url: 'restfulservice/callCenterClientService/getAnsweringResult',
    method: 'get',
    params: { serviceNum }
  })
}
