import fetch from 'utils/fetch'
/* ----------公用接口---------- */

/* ---------- 催收接口 ---------- */

// 获取产品信息列表
export function fetchAllProductList () {
  return fetch({
    url: 'restfulservice/sProductService/findAllProduct',
    method: 'get'
  })
}

// 获取催收员列表
export function fetchAllCollectorVOList () {
  return fetch({
    url: 'restfulservice/selectParamService/findAllCollectorList',
    method: 'get'
  })
}

// 获取催收组列表
export function findAllGroupVOList () {
  return fetch({
    url: 'restfulservice/selectParamService/findAllGroupList',
    method: 'get'
  })
}

// 获取催收经理列表
export function findAllManagerVOList () {
  return fetch({
    url: 'restfulservice/selectParamService/findAllManagerList',
    method: 'get'
  })
}

// 获取机构列表
export function fetchAllMechanVOList () {
  return fetch({
    url: 'restfulservice/selectParamService/findAllMechanList',
    method: 'get'
  })
}

/* ---------- 质检接口 ---------- */

// 获取质检员数据列表
export function fetchQualitityCheckerList () {
  return fetch({
    url: 'restfulservice/qualityCheckingRecordService/getAllQualitityChecker',
    method: 'get'
  })
}

// 获取质检组长数据列表
export function fetchQualitityGroupList () {
  return fetch({
    url: 'restfulservice/qualityCheckingRecordService/getAllQualitityGroupLeader',
    method: 'get'
  })
}
