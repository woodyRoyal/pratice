import fetch from 'utils/fetch'
import fetchCollectionBatch from 'utils/fetchCollectionBatch'

// 上传 -用户管理
export const URL_IMPORT_CASE_ASSIGN_FILE = process.env.BASE_API + 'upload/rbacUserService/importFile'

// 下载模板
export const URL_EXPORT_FILE_TEMPLATE = process.env.BASE_API + 'static/collection/batch_update_user_templet.csv'

/* ----------菜单管理---------- */

// 获取菜单树
export function fetchMenuTree () {
  return fetch({
    url: 'restfulservice/rbacMenuService/findRbacMenuTree',
    method: 'get'
  })
}

// 新增或修改菜单
export function fetchSaveOrUpdateMenu (rbacMenu) {
  const data = {
    rbacMenu
  }
  return fetch({
    url: 'restfulservice/rbacMenuService/saveOrUpdate',
    method: 'post',
    data
  })
}

// 批量删除菜单
export function fetchDeleteMenuByIdList (idList) {
  const data = {
    idList
  }
  return fetch({
    url: 'restfulservice/rbacMenuService/deleteByIdList',
    method: 'post',
    data
  })
}

/* ----------用户管理---------- */

// 批量操作用户
export function fetchBatchOperation (userIds, groupIds, roleIds, job, autoAssignCaseEnabled) {
  const data = {userIds, groupIds, roleIds, job, autoAssignCaseEnabled}
  return fetch({
    url: 'restfulservice/rbacUserService/batchUpdateUser ',
    method: 'post',
    data
  })
}

// 获取角色列表
export function fetchRoles () {
  return fetch({
    url: 'restfulservice/rbacUserService/getRoles',
    method: 'get'
  })
}

// 获取分组列表
export function fetchGroups () {
  return fetch({
    url: 'restfulservice/rbacUserService/getGroups',
    method: 'get'
  })
}

// 获取中文名列表
export function fetchUsers () {
  return fetch({
    url: 'restfulservice/rbacUserService/findAllSysUserVoList',
    method: 'get'
  })
}

// 获取职位列表
export function fetchJobs () {
  return fetch({
    url: 'restfulservice/rbacUserService/getJobs',
    method: 'get'
  })
}

// 获取用户列表
// export function fetchUserList (username, displayName, pageable) {
//   return fetch({
//     url: 'restfulservice/rbacUserService/findRbacUser',
//     method: 'get',
//     params: {username, displayName, pageable}
//   })
// }

// 获取用户列表
export function fetchUserList (userIds1, username, userIds2, groupIds, roleIds, userIseffective, autoAssignCaseEnabled, pageSize, pageNo) {
  return fetch({
    url: 'restfulservice/rbacUserService/getUsers',
    method: 'get',
    params: {userIds1, username, userIds2, groupIds, roleIds, userIseffective, autoAssignCaseEnabled, pageSize, pageNo}
  })
}

// 获取用户名是否已存在 true存在 false不存在
export function fetchUsernameIsExists (username) {
  return fetch({
    url: 'restfulservice/rbacUserService/userNameExists',
    method: 'get',
    params: {username}
  })
}

// // 新增或修改用户
// export function fetchSaveOrUpdateUser (rbacUser) {
//   const data = {
//     rbacUser
//   }
//   return fetch({
//     url: 'restfulservice/rbacUserService/saveOrUpdate',
//     method: 'post',
//     data
//   })
// }

// 修改用户
export function fetchUpdateUser (rbacUser) {
  const data = {
    rbacUser
  }
  return fetch({
    url: 'restfulservice/rbacUserService/updateUser',
    method: 'post',
    data
  })
}

// 导出用户数据
export const URL_EXPORT_USER_CASE = process.env.BASE_API + 'download/rbacUserService/exportTableData'

// 修改用户角色
export function fetchUpdateUserRole (userId, rbacUserRoleList) {
  const data = {
    userId,
    rbacUserRoleList
  }
  return fetch({
    url: 'restfulservice/rbacUserService/saveRbacUserRole',
    method: 'post',
    data
  })
}

// 重置密码
export function fetchResetPassword (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/rbacUserService/resetPassword',
    method: 'post',
    data
  })
}

// 禁用
export function fetchDisableUser (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/rbacUserService/disable',
    method: 'post',
    data
  })
}

// 启用
export function fetchEnableUser (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/rbacUserService/enable',
    method: 'post',
    data
  })
}

// 锁定
export function fetchLockUser (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/rbacUserService/lock',
    method: 'post',
    data
  })
}

// 解锁
export function fetchUnlockUser (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/rbacUserService/unLock',
    method: 'post',
    data
  })
}

// 修改密码
export function fetchUpdatePassword (oldPassword, newPassword) {
  const data = {
    oldPassword, newPassword
  }
  return fetch({
    url: 'restfulservice/rbacUserService/updatePassword',
    method: 'post',
    data
  })
}

/* ----------分组管理---------- */

// 获取分组树
// export function fetchGroupTree () {
//   return fetch({
//     url: 'restfulservice/rbacGroupService/findRbacGroupTree',
//     method: 'get'
//   })
// }

// 获取分组列表
export function fetchGroupList (code, name, pageable) {
  return fetch({
    url: 'restfulservice/rbacGroupService/findRbacGroup',
    method: 'get',
    params: {code, name, pageable}
  })
}

// 新增或修改分组
// export function fetchSaveOrUpdateGroup (rbacGroup) {
//   const data = {
//     rbacGroup
//   }
//   return fetch({
//     url: 'restfulservice/rbacGroupService/saveOrUpdate',
//     method: 'post',
//     data
//   })
// }

// 新增分组
export function fetchCreateGroup (rbacGroup) {
  const data = {
    rbacGroup
  }
  return fetch({
    url: 'restfulservice/rbacGroupService/createGroup',
    method: 'post',
    data
  })
}

// 修改分组
export function fetchUpdateGroup (group) {
  const data = {
    group
  }
  return fetch({
    url: 'restfulservice/rbacGroupService/updateGroup',
    method: 'post',
    data
  })
}
// 获取机构列表
export function fetchMechanismList () {
  const classCode = 'mechanism_list'
  return fetch({
    url: 'restfulservice/paramParamService/findParamByClassCodeFromCacheOrDb',
    method: 'get',
    params: {classCode}
  })
}

// 删除分组
export function fetchDeleteGroup (groupIds) {
  const data = {
    groupIds
  }
  return fetch({
    url: 'restfulservice/rbacGroupService/deleteGroup',
    method: 'post',
    data
  })
}

// // 批量删除分组
// export function fetchDeleteGroupByIdList (idList) {
//   const data = {
//     idList
//   }
//   return fetch({
//     url: 'restfulservice/rbacGroupService/deleteByIdList',
//     method: 'post',
//     data
//   })
// }

/* ----------角色管理---------- */

// 获取角色列表
export function fetchRoleList (name, pageable) {
  return fetch({
    url: 'restfulservice/rbacRoleService/findRbacRole',
    method: 'get',
    params: {name, pageable}
  })
}

// 新增或修改角色
export function fetchSaveOrUpdateRole (rbacRole) {
  const data = {
    rbacRole
  }
  return fetch({
    url: 'restfulservice/rbacRoleService/saveOrUpdate',
    method: 'post',
    data
  })
}

// 批量删除角色
export function fetchDeleteRoleByIdList (idList) {
  const data = {
    idList
  }
  return fetch({
    url: 'restfulservice/rbacRoleService/deleteByIdList',
    method: 'post',
    data
  })
}

/* ----------权限管理---------- */

// 获取权限树
export function fetchPermissionTree () {
  return fetch({
    url: 'restfulservice/rbacPermissionService/findRbacPermissionTree',
    method: 'get'
  })
}

// 获取权限列表
export function fetchPermissionList (name, pageable) {
  return fetch({
    url: 'restfulservice/rbacPermissionService/findRbacPermission',
    method: 'get',
    params: {name, pageable}
  })
}

// 新增或修改权限
export function fetchSaveOrUpdatePermission (rbacPermission) {
  const data = {
    rbacPermission
  }
  return fetch({
    url: 'restfulservice/rbacPermissionService/saveOrUpdate',
    method: 'post',
    data
  })
}

// 批量删除权限
export function fetchDeletePermissionByIdList (idList) {
  const data = {
    idList
  }
  return fetch({
    url: 'restfulservice/rbacPermissionService/deleteByIdList',
    method: 'post',
    data
  })
}

/* ----------定时任务---------- */

// 登录  以用户名和token登陆
export function fetchBatchLoginByUsernameAndToken (username, token) {
  return fetchCollectionBatch({
    url: 'restfulservice/uCenterLoginService/login',
    method: 'get',
    params: {username, token}
  })
}
// 获取所有任务列表
export function fetchScheduleList () {
  return fetchCollectionBatch({
    url: 'restfulservice/scheduleTaskService/getAllTask',
    method: 'get'
  })
}

// 新增或修改任务
export function fetchSaveOrUpdateSchedule (task) {
  const data = {
    task
  }
  return fetchCollectionBatch({
    url: 'restfulservice/scheduleTaskService/saveOrUpdateTask',
    method: 'post',
    data
  })
}

// 删除任务
export function fetchDeleteScheduleById (taskId) {
  const data = {
    taskId
  }
  return fetchCollectionBatch({
    url: 'restfulservice/scheduleTaskService/deleteTask',
    method: 'post',
    data
  })
}

// 暂停任务
export function fetchPauseScheduleById (taskId) {
  const data = {
    taskId
  }
  return fetchCollectionBatch({
    url: 'restfulservice/scheduleTaskService/pauseTask',
    method: 'post',
    data
  })
}

// 重启任务
export function fetchResumeScheduleById (taskId) {
  const data = {
    taskId
  }
  return fetchCollectionBatch({
    url: 'restfulservice/scheduleTaskService/resumeTask',
    method: 'post',
    data
  })
}

// 执行一次任务
export function fetchRunOnceScheduleById (taskId) {
  const data = {
    taskId
  }
  return fetchCollectionBatch({
    url: 'restfulservice/scheduleTaskService/runOnceTask',
    method: 'post',
    data
  })
}

// 启动任务
export function fetchStartScheduleById (taskId) {
  const data = {
    taskId
  }
  return fetchCollectionBatch({
    url: 'restfulservice/scheduleTaskService/startTask',
    method: 'post',
    data
  })
}

// 停止任务
export function fetchStopScheduleById (taskId) {
  const data = {
    taskId
  }
  return fetchCollectionBatch({
    url: 'restfulservice/scheduleTaskService/stopTask',
    method: 'post',
    data
  })
}

/* ----------参数设置---------- */
/* 参数分类 */

// 获取所有参数分类列表
export function fetchAllParamParam () {
  return fetch({
    url: 'restfulservice/paramParamService/findAllParamParam',
    method: 'get'
  })
}

// 获取参数分类列表
export function fetchParamClassList (classCode, className, pageable) {
  const data = {
    classCode,
    className,
    pageable
  }
  return fetch({
    url: 'restfulservice/paramClassService/findParamClass',
    method: 'post',
    data
  })
}

// 删除参数分类
export function fetchDeleteParamClassById (ids) {
  const data = {
    ids
  }
  return fetch({
    url: 'restfulservice/paramClassService/deleteByIds',
    method: 'post',
    data
  })
}

// 新增或修改参数分类
export function fetchSaveOrUpdateParamClass (paramClass) {
  const data = {
    paramClass
  }
  return fetch({
    url: 'restfulservice/paramClassService/saveOrUpdate',
    method: 'post',
    data
  })
}

/* 参数 */

// 获取参数列表
export function fetchParamList (classIdList, pageable) {
  return fetch({
    url: 'restfulservice/paramParamService/findParamParam',
    method: 'get',
    params: {classIdList, pageable}
  })
}

// 删除参数
export function fetchDeleteParamById (id) {
  const data = {
    id
  }
  return fetch({
    url: 'restfulservice/paramParamService/deleteById',
    method: 'post',
    data
  })
}

// 新增或修改参数
export function fetchSaveOrUpdateParam (paramParam) {
  const data = {
    paramParam
  }
  return fetch({
    url: 'restfulservice/paramParamService/saveOrUpdate',
    method: 'post',
    data
  })
}

/* ----------催收频率限制---------- */

// 获取电话频率限制数据
export function fetchFindCallAll () {
  return fetch({
    url: 'restfulservice/callCallLimitService/findAll',
    method: 'get'
  })
}

// 获取短信频率限制数据
export function fetchFindMessageAll () {
  return fetch({
    url: 'restfulservice/smsSendLimitService/findAll',
    method: 'get'
  })
}

// 删除电话频率数据
export function fetchDeleteCall (id1, id2) {
  const data = {
    id1, id2
  }
  return fetch({
    url: 'restfulservice/callCallLimitService/deleteCallCallLimit',
    method: 'post',
    data
  })
}

// 删除短信频率数据
export function fetchDeleteMessage (id1, id2) {
  const data = {
    id1, id2
  }
  return fetch({
    url: 'restfulservice/smsSendLimitService/deleteCallCallLimit',
    method: 'post',
    data
  })
}

// 保存电话频率限制数据
export function fetchCallSaveOrUpdateList (callCallLimitList) {
  const data = {
    callCallLimitList
  }
  return fetch({
    url: 'restfulservice/callCallLimitService/saveOrUpdateList',
    method: 'post',
    data
  })
}

// 保存短信频率限制数据
export function fetchMessageSaveOrUpdateList (smsSendLimitList) {
  const data = {
    smsSendLimitList
  }
  return fetch({
    url: 'restfulservice/smsSendLimitService/saveOrUpdateList',
    method: 'post',
    data
  })
}

/* ----------产品设置---------- */

// 删除数据
export function fetchDeleteRuleData (ruleId) {
  const data = {
    ruleId
  }
  return fetch({
    url: 'restfulservice/productSettingService/deleteCaseRule',
    method: 'post',
    data
  })
}

// 删除数据
export function fetchDeletePhoneData (contactDisplayId) {
  const data = {
    contactDisplayId
  }
  return fetch({
    url: 'restfulservice/productSettingService/deleteContactDisplay',
    method: 'post',
    data
  })
}

// 获取产品数据
export function fetchProductMenu () {
  return fetch({
    url: 'restfulservice/productSettingService/getAllProduct4Menu',
    method: 'get'
  })
}

// 获取阶段、分配、回收规则数据
export function fetchProductInfo (productId) {
  return fetch({
    url: 'restfulservice/productSettingService/getCaseRule',
    method: 'get',
    params: {productId}
  })
}

// 获取联系人数据
export function fetchContactInfo (productId) {
  return fetch({
    url: 'restfulservice/productSettingService/getContactDisplay',
    method: 'get',
    params: {productId}
  })
}

// 新增或修改按钮
export function fetchAddOrEdit (caseProduct) {
  const data = {
    caseProduct
  }
  return fetch({
    url: 'restfulservice/productSettingService/saveProduct',
    method: 'post',
    params: data
  })
}

// 获取逾期阶段数据
export function fetchOverdueDays (id) {
  const classCode = 'overdue_level_' + id
  return fetch({
    url: 'restfulservice/paramParamService/findParamParamByClassCode',
    method: 'get',
    params: {classCode}
  })
}

// 保存阶段、分配、回收规则数据
export function fetchSaveCaseRuleBatch (caseRuleList) {
  const data = {
    caseRuleList
  }
  return fetch({
    url: 'restfulservice/productSettingService/saveCaseRuleBatch ',
    method: 'post',
    data
  })
}

// 保存联系人数据
export function fetchSaveContactDisplay (contactDisplayList) {
  const data = {
    contactDisplayList
  }
  return fetch({
    url: 'restfulservice/productSettingService/saveContactDisplay ',
    method: 'post',
    data
  })
}

/* ----------公用---------- */
export function fetchGroupTree () {
  const isTree = true
  return fetch({
    url: 'restfulservice/rbacGroupService/findAllGroups',
    method: 'get',
    params: {isTree}
  })
}
