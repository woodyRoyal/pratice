import fetch from 'utils/fetch'

/* ---------- 催收员工作量日报 ---------- */

// 获取催收员工作量日报
export function fetchGetCollectorDailyList (queryDTO, pageable) {
  const data = {
    queryDTO,
    pageable
  }
  return fetch({
    url: 'restfulservice/collectorWorkloadReportService/findCollectorDailyWorkloadReport',
    method: 'post',
    data
  })
}

// 导出催收员工作量日报
export const URL_EXPORT_COLLECTOR_DAILY_DATA = process.env.BASE_API + 'download/collectorWorkloadReportService/exportCollectorDailyWorkloadReport'

/* ---------- 催收员工作量月报 ---------- */

// 获取催收员工作量月报
export function fetchGetCollectorMonthlyList (queryDTO, pageable) {
  const data = {
    queryDTO,
    pageable
  }
  return fetch({
    url: 'restfulservice/collectorWorkloadReportService/findCollectorMonthlyWorkloadReport',
    method: 'post',
    data
  })
}

// 导出催收员工作量月报
export const URL_EXPORT_COLLECTOR_MONTHLY_DATA = process.env.BASE_API + 'download/collectorWorkloadReportService/exportCollectorMonthlyWorkloadReport'

/* ---------- 逾期阶段工作量日报 ---------- */

// 获取逾期阶段工作量日报
export function fetchGetLateStageDailyList (param, pageable) {
  const data = {
    param,
    pageable
  }
  return fetch({
    url: 'restfulservice/overlevelWorkloadDailyService/findOverlevelWorkloadDaily',
    method: 'post',
    data
  })
}

// 导出逾期阶段工作量日报
export const URL_EXPORT_LATE_STAGE_DAILY_DATA = process.env.BASE_API + 'download/overlevelWorkloadDailyService/exportfindOverlevelWorkloadDaily'

/* ---------- 逾期阶段工作量月报 ---------- */

// 获取逾期阶段工作量月报
export function fetchGetLateStageMonthlyList (param, pageable) {
  const data = {
    param,
    pageable
  }
  return fetch({
    url: 'restfulservice/overlevelWorkloadMonthlyService/findOverlevelWorkloadMonthly',
    method: 'post',
    data
  })
}

// 导出逾期阶段工作量月报
export const URL_EXPORT_LATE_STAGE_MONTHLY_DATA = process.env.BASE_API + 'download/overlevelWorkloadMonthlyService/exportfindOverlevelWorkloadMonthly'

/* ---------- 对公数据导出 ---------- */
// 查询数据 DGDataExportService#getUserData(DGParamBo
export function fetchGetUserData (paramBo, pageable) {
  return fetch({
    url: 'restfulservice/dGDataExportService/getUserData',
    method: 'get',
    params: {paramBo, pageable}
  })
}
// 导出 exportUserData
export const URL_EXPORT_USER_DATA = process.env.BASE_API + 'download/dGDataExportService/exportUserData'

/* ---------- 分案结果统计 ---------- */
// 个人明细数据
export function fetchPersonalDetailList (param, pageable) {
  return fetch({
    url: 'restfulservice/assignCaseCountReportService/personalDetailList',
    method: 'get',
    params: {param, pageable}
  })
}

// 导出个人明细
export const URL_EXPORT_PERSONAL_DETAIL_DATA = process.env.BASE_API +
  'download/assignCaseCountReportService/personalDetailExport'

// 个人汇总数据
export function fetchPersonalCollectList (param, pageable) {
  return fetch({
    url: 'restfulservice/assignCaseCountReportService/personalCollectList',
    method: 'get',
    params: {param, pageable}
  })
}

// 导出个人汇总数据
export const URL_EXPORT_PERSONAL_COLLECT_DATA = process.env.BASE_API +
  'download/assignCaseCountReportService/personalCollectExport'

// 产品&阶段汇总
export function fetchProductAndLevelCollectList (param, pageable) {
  return fetch({
    url: 'restfulservice/assignCaseCountReportService/productAndLevelCollectList',
    method: 'get',
    params: {param, pageable}
  })
}

// 导出产品阶段汇总数据
export const URL_EXPORT_PRODUCTANDLEVEL_COLLECT_DATA = process.env.BASE_API +
  'download/assignCaseCountReportService/productAndLevelCollectExport'

// 获取所有逾期阶段
export function fetchAllOverdueDays () {
  return fetch({
    url: 'restfulservice/caseRuleService/findCaseRuleForOverdueLevel',
    method: 'get'
  })
}

// 工作台数据查询
export function fetchGetBenchData (paramBo, pageable) {
  return fetch({
    url: 'restfulservice/workbenchCaseAssignmentService/getList',
    method: 'get',
    params: {paramBo, pageable}
  })
}

// 导出产品阶段汇总数据
export const URL_EXPORT_BENCH_DATA = process.env.BASE_API +
  'download/workbenchCaseAssignmentService/exportCsv'
