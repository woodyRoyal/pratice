import fetch from 'utils/fetch'

// 通话记录查询
export function fetchGetCallRecordList (queryBo, pageable) {
  const data = {
    queryBo,
    pageable
  }
  return fetch({
    url: 'restfulservice/iCallPrjoectUseService/queryCommunicateInfoList',
    method: 'post',
    data
  })
}

// 获取项目Id数据列表
export function fetchProjectIDList (collectorid, status) {
  const data = {
    collectorid,
    status
  }
  return fetch({
    url: 'restfulservice/iCallProjectManageService/queryByCollectorId',
    method: 'post',
    data
  })
}

// 项目管理
// 查询项目 queryWithLastExecuteByPage
export function fetchGetProjectList (projectBizStatus, createUserId, pager) {
  const data = {
    projectBizStatus,
    createUserId,
    pager
  }
  return fetch({
    url: 'restfulservice/iCallProjectManageService/queryWithLastExecuteByPage',
    method: 'post',
    data
  })
}
// 校验现在有没有正在进行拨打批呼项目 ICallPrjoectUseService getExecOrPauseProject
export function fetchGetExecOrPauseProject () {
  return fetch({
    url: 'restfulservice/iCallPrjoectUseService/getExecOrPauseProject',
    method: 'get'
  })
}
// 开始项目 icallPrjoecExecuteService startCallProject
export function fetchStartCallProject (callProjectId, phoneTotalNum) {
  const data = {
    callProjectId, phoneTotalNum
  }
  return fetch({
    url: 'restfulservice/iCallPrjoecExecuteService/startCallProject',
    method: 'post',
    data
  })
}
// 开始项目 获取电话 ICallPrjoecExecuteService queryCallProjectPhoneInfo
export function fetchQueryCallProjectPhoneInfo (callProjectId) {
  const data = {
    callProjectId
  }
  return fetch({
    url: 'restfulservice/iCallPrjoecExecuteService/queryCallProjectPhoneInfo',
    method: 'post',
    data
  })
}
// 完成一次批呼项目 ICallPrjoecExecuteService#callProjectCompleate
export function fetchCallProjectCompleate (callProjectId, executedId) {
  const data = {
    callProjectId, executedId
  }
  return fetch({
    url: 'restfulservice/iCallPrjoecExecuteService/callProjectCompleate',
    method: 'post',
    data
  })
}
// 批量删除 ICallProjectManageService deleteCallProjectBatch
export function fetchDeleteCallProjectBatch (callProjectIds) {
  const data = {
    callProjectIds
  }
  return fetch({
    url: 'restfulservice/iCallProjectManageService/deleteCallProjectBatch',
    method: 'post',
    data
  })
}
// 删除 ICallProjectManageService deleteCallProject
export function fetchDeleteCallProject (callProjectId) {
  return fetch({
    url: 'restfulservice/iCallProjectManageService/deleteCallProject',
    method: 'get',
    params: {callProjectId}
  })
}
// 号码名单 queryCallProjectPhoneList
export function fetchQueryCallProjectPhoneList (callProjectId, caseName, contactName, status, pageable) {
  const data = {
    callProjectId, caseName, contactName, status, pageable
  }
  return fetch({
    url: 'restfulservice/iCallPrjoectUseService/queryCallProjectPhoneList',
    method: 'post',
    data
  })
}
// 批量删除号码 iCallPrjoectUseService deleteCallProjectPhone
export function fetchDeleteCallProjectPhone (callProjectId, phoneIds) {
  const data = {
    callProjectId, phoneIds
  }
  return fetch({
    url: 'restfulservice/iCallPrjoectUseService/deleteCallProjectPhone',
    method: 'post',
    data
  })
}
// 修改项目 ICallProjectManageService updateProjectNameAndCallRatio
export function fetchUpdateProjectNameAndCallRatio (bo) {
  const data = {
    bo
  }
  return fetch({
    url: 'restfulservice/iCallProjectManageService/updateProjectNameAndCallRatio',
    method: 'post',
    data
  })
}
// 新增项目 ICallProjectManageService save
export function fetchAddBatchProject (bo) {
  const data = {
    bo
  }
  return fetch({
    url: 'restfulservice/iCallProjectManageService/save',
    method: 'post',
    data
  })
}
// 检查项目名称是否重复 ICallProjectManageService.queryByProjectName
export function fetchQueryByProjectName (callProjectName) {
  const data = {
    callProjectName
  }
  return fetch({
    url: 'restfulservice/iCallProjectManageService/queryByProjectName',
    method: 'post',
    data
  })
}
// 检查项目名称是否重复by当前登录的用户 ICallProjectManageService.queryByCollectorId
export function fetchQueryByCollectorId () {
  return fetch({
    url: 'restfulservice/iCallProjectManageService/queryByCollectorId',
    method: 'get'
  })
}
// 执行详情 ICallPrjoectUseService.queryCallProjectExecuteList
export function fetchQueryCallProjectExecuteList (callProjectId, bizStatusList, pageable) {
  const data = {
    callProjectId, bizStatusList, pageable
  }
  return fetch({
    url: 'restfulservice/iCallPrjoectUseService/queryCallProjectExecuteList',
    method: 'post',
    data
  })
}
// 通话记录-新增项目-保存 iCallProjectManageService#saveWithContact
export function fetchSaveWithContact (callRecordIds, callProjectName, callRatio, contactType) {
  const data = {
    callRecordIds, callProjectName, callRatio, contactType
  }
  return fetch({
    url: 'restfulservice/iCallProjectManageService/saveWithContact',
    method: 'post',
    data
  })
}
