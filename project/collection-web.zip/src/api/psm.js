import fetch from 'utils/fetch'

// 获取机构列表
export function fetchAllMechanList (name) {
  return fetch({
    url: 'restfulservice/selectParamService/findAllCollectorMechanList',
    method: 'get',
    params: {name}
  })
}

/* ---------- 业绩汇总 ---------- */

// 机构
export function fetchGetPerCompanyData (bo, pageable) {
  return fetch({
    url: 'restfulservice/achievSummaryDetailService/findMechanSummaryDetailList',
    method: 'get',
    params: {bo, pageable}
  })
}

// 机构导出
export const URL_EXPORT_PER_COMPANY_DATA = process.env.BASE_API + 'download/achievSummaryDetailService/exportMechanSummaryDetailList'

// 组别
export function fetchGetPerGroupData (bo, pageable) {
  return fetch({
    url: 'restfulservice/achievSummaryDetailService/findTeamSummaryDetailList',
    method: 'get',
    params: {bo, pageable}
  })
}

// 组别导出
export const URL_EXPORT_PER_GROUP_DATA = process.env.BASE_API + 'download/achievSummaryDetailService/exportTeamSummaryDetailList'

// 个人
export function fetchGetPerPersonData (bo, pageable) {
  return fetch({
    url: 'restfulservice/achievSummaryDetailService/findCollectorSummaryDetailList',
    method: 'get',
    params: {bo, pageable}
  })
}

// 个人导出
export const URL_EXPORT_PER_PERSON_DATA = process.env.BASE_API + 'download/achievSummaryDetailService/exportCollectorSummaryDetailList'

// 产品
export function fetchGetPerProductData (bo, pageable) {
  return fetch({
    url: 'restfulservice/achievSummaryDetailService/findAchievProductSumlList',
    method: 'get',
    params: {bo, pageable}
  })
}

// 产品导出
export const URL_EXPORT_PER_PRODUCT_DATA = process.env.BASE_API + 'download/achievSummaryDetailService/exportAchievProductSumlList'

/* ---------- 还款详情 ---------- */

// 产品
export function fetchGetPayProductData (bo, pageable) {
  return fetch({
    url: 'restfulservice/repaymentDetailService/findRepaymentDetaiVolist',
    method: 'get',
    params: {bo, pageable}
  })
}

// 产品导出
export const URL_EXPORT_PAY_PRODUCT_DATA = process.env.BASE_API + 'download/repaymentDetailService/exportRepaymentDetaiVolist'

// 机构
export function fetchGetPayCompanyData (bo, pageable) {
  return fetch({
    url: 'restfulservice/repaymentDetailService/findRepaymentMachievSummaryVoList',
    method: 'get',
    params: {bo, pageable}
  })
}

// 机构导出
export const URL_EXPORT_PAY_COMPANY_DATA = process.env.BASE_API + 'download/repaymentDetailService/exportRepaymentMachievSummaryVoList'

// 组别
export function fetchGetPayGroupData (bo, pageable) {
  return fetch({
    url: 'restfulservice/repaymentDetailService/findRepaymentTeamSummaryVoList',
    method: 'get',
    params: {bo, pageable}
  })
}

// 组别导出
export const URL_EXPORT_PAY_GROUP_DATA = process.env.BASE_API + 'download/repaymentDetailService/exportRepaymentTeamSummaryVoList'

// 个人
export function fetchGetPayPersonData (bo, pageable) {
  return fetch({
    url: 'restfulservice/repaymentDetailService/findRepaymentCollectorSummaryVoList',
    method: 'get',
    params: {bo, pageable}
  })
}

// 个人导出
export const URL_EXPORT_PAY_PERSON_DATA = process.env.BASE_API + 'download/repaymentDetailService/exportRepaymentCollectorSummaryVoList'

/* ---------- 迁移率 ---------- */
// 迁移率
export function fetchGetTransferAmountData (param, pageable) {
  const data = {
    param,
    pageable
  }
  return fetch({
    url: 'restfulservice/transferAmountService/findTransferAmount',
    method: 'post',
    data
  })
}

// 迁移率导出
export const URL_EXPORT_TRANSFER_AMOUNT_DATA = process.env.BASE_API + 'download/transferAmountService/exportTransferAmount'
