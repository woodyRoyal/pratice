import fetch from 'utils/fetch'

/* 短信管理 */

// 获取产品类型
export function fetchGetProductType () {
  return fetch({
    url: 'restfulservice/productSettingService/getAllProduct4Menu',
    method: 'get'
  })
}

// 获取短信渠道列表
export function fetchGetSmsChannelList () {
  return fetch({
    url: 'restfulservice/smsTemplateService/getSmsChannelList',
    method: 'get'
  })
}

// 获取短信模板列表
export function fetchGetSmsTemplateList (productIdList, pageable) {
  return fetch({
    url: 'restfulservice/smsTemplateService/findSmsTemplateList',
    method: 'get',
    params: {productIdList, pageable}
  })
}

// 新增或修改短信模板
export function fetchSaveOrUpdateSmsTemplate (smsTemplate) {
  const data = {
    smsTemplate
  }
  return fetch({
    url: 'restfulservice/smsTemplateService/saveOrUpdateSmsTemplate',
    method: 'post',
    data
  })
}

// 验证模板明是否可用
export function fetchValidSmsTemplateName (templateName) {
  return fetch({
    url: 'restfulservice/smsTemplateService/validSmsTemplateName',
    method: 'get',
    params: {templateName}
  })
}

// 删除模板
export function fetchRemoveSmsTemplateById (templateId) {
  const data = {
    templateId
  }
  return fetch({
    url: 'restfulservice/smsTemplateService/removeSmsTemplateById',
    method: 'post',
    data
  })
}

// 短信历史
export function fetchGetSmsHistoryList (smsHistorySearch, pageable) {
  const data = {
    smsHistorySearch,
    pageable
  }
  return fetch({
    url: 'restfulservice/smsHistoryService/findSmsHistoryList',
    method: 'post',
    data
  })
}

// 短信审核列表
export function fetchGetSmsAuditList (smsAuditDTO, pageable) {
  const data = {
    smsAuditDTO,
    pageable
  }
  return fetch({
    url: 'restfulservice/smsAuditService/findSmsAuditList',
    method: 'post',
    data
  })
}

// 短信审核
export function fetchSmsAudit (smsIdList, isPass) {
  const data = {
    smsIdList,
    isPass // 1：通过，2：拒绝
  }
  return fetch({
    url: 'restfulservice/smsAuditService/smsAudit',
    method: 'post',
    data
  })
}

// 发送短信 - 短信模板 getSmsTemplateList
export function fetchGetSmsTemplate (productId, type) {
  return fetch({
    url: 'restfulservice/smsTemplateService/getSmsTemplateList',
    method: 'get',
    params: {productId, type}
  })
}
// 发送短信 SmsManagerService addToSendList
export function fetchAddToSendList (caseId, orderId, debtorTempletId, contactTempletId) {
  const data = {
    caseId, orderId, debtorTempletId, contactTempletId
  }
  return fetch({
    url: 'restfulservice/smsManagerService/addToSendList',
    method: 'post',
    data
  })
}
// 批量发送短信 SmsManagerService addBatchToSendList
export function fetchAddBatchToSendList (caseIds, debtorTempletId, contactTempletId) {
  const data = {
    caseIds, debtorTempletId, contactTempletId
  }
  return fetch({
    url: 'restfulservice/smsManagerService/addBatchToSendList',
    method: 'post',
    data
  })
}
// 短信通道可用性 SmsManagerService#checkSmsChannelAvailable
export function fetchCheckSmsChannelAvailable (caseId, type) {
  return fetch({
    url: 'restfulservice/smsManagerService/checkSmsChannelAvailable',
    method: 'get',
    params: {caseId, type}
  })
}
