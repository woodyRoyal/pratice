import Mock from 'mockjs'
import loginAPI from './login'
import sysMockData from './sysMockData'

// 登录相关
Mock.mock(/\/login\/loginbyusername/, 'post', loginAPI.loginByUsername)
Mock.mock(/\/login\/logout/, 'post', loginAPI.logout)
Mock.mock(/\/user\/info\.*/, 'get', loginAPI.getInfo)

// 系统管理
Mock.mock(/\/restfulservice\/sys\/menu\/get/, 'get', sysMockData.getMenuTreeList)
Mock.mock(/\/restfulservice\/sys\/user\/page/, 'post', sysMockData.getUserList())

export default Mock
