const getters = {
  pkg: state => state.pkg,
  sidebar: state => state.app.sidebar,
  visitedViews: state => state.app.visitedViews,
  isFullscreen: state => state.app.isFullscreen,

  // 登陆用户信息
  userId: state => state.loginUser.userId,
  username: state => state.loginUser.username,
  displayName: state => state.loginUser.displayName,
  token: state => state.loginUser.token,
  roleIds: state => state.loginUser.roleIds,
  roleLevel: state => state.loginUser.roleLevel,
  roleList: state => state.loginUser.roleList,
  menuTreeList: state => state.loginUser.menuTreeList,
  permissionList: state => state.loginUser.permissionList,
  systemList: state => state.loginUser.systemList,
  showSelectObj: state => state.loginUser.showSelectObj,
  serviceNum: state => state.loginUser.serviceNum,

  // 菜单权限
  permissionRouters: state => state.permission.routers,
  addRouters: state => state.permission.addRouters,
  menuPathList: state => state.permission.menuPathList,

  // 短信数据
  appCodeList: state => state.sms.appCodeList,
  appType: state => state.sms.appType,

  // 催记信息
  currentCRInfo: state => state.cr.currentCRInfo,
  isSubmitted: state => state.cr.isSubmitted,
  isShowSmallBox: state => state.cr.isShowSmallBox,
  currentTaskId: state => state.cr.currentTaskId,
  timeLimit: state => state.cr.timeLimit,

  // 首页操作标记
  lateLoginStatus: state => state.cr.lateLoginStatus,
  todayRemindStatus: state => state.cr.todayRemindStatus,

  // 电呼
  currentTest: state => state.call.currentTest
}
export default getters
