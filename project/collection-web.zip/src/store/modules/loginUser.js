import {
  loginByUsername,
  logout,
  getUserInfo,
  getUcenterUserInfo,
  getApplicationInfo,
  logoutUcenter,
  loginByUsernameAndToken
} from 'api/login'
import Cookies from 'js-cookie'
import { PERMISSION_ROLE } from '../../views/quality/qualityConstant'
import packageConfig from 'package'

// 权限树转换为权限数组
function permissionTreeToList (source, target) {
  target.push(source.permission)
  // 递归处理子菜单
  if (source.children && source.children.length > 0) {
    source.children.map(item => permissionTreeToList(item, target))
  }
  return target
}

// 根据老系统的角色计算出角色等级
function getRoleLevel (roleIds) {
  if (!roleIds) {
    return null
  }
  if (roleIds.indexOf(PERMISSION_ROLE.sadmin) >= 0 ||
    roleIds.indexOf(PERMISSION_ROLE.padmin) >= 0 ||
    roleIds.indexOf(PERMISSION_ROLE.cadmin) >= 0) {
    return 1 // 最高等级角色
  } else if (roleIds.indexOf(PERMISSION_ROLE.organization) >= 0) {
    return 2 // 不能选机构
  } else if (roleIds.indexOf(PERMISSION_ROLE.collManager) >= 0 ||
    roleIds.indexOf(PERMISSION_ROLE.qcManager) >= 0) {
    return 3 // 不能选经理
  } else if (roleIds.indexOf(PERMISSION_ROLE.colGroupLeader) >= 0 ||
    roleIds.indexOf(PERMISSION_ROLE.qcGroupLeader) >= 0) {
    return 4 // 不能选机构和组
  } else if (roleIds.indexOf(PERMISSION_ROLE.collector) >= 0 ||
    roleIds.indexOf(PERMISSION_ROLE.checker) >= 0) {
    return 5 // 不能选机构和组、员
  }
}

// 是否显示下拉框权限
function getShowSelectObj (permissionList) {
  let showSelectObj = {
    isShowCompanySelect: false,
    isShowManagerSelect: false,
    isShowGroupSelect: false,
    isShowPersonSelect: false,
    isQCOperate: false,
    isAssign: false,
    isShowRecordPath: false, // 是否显示录音地址（案件详情）
    isShowActive: false, // 是否显示激活按钮（案件详情）
    isShowReduce: false, // 是否显示代扣按钮（案件详情）
    isShowReceivePerson: false, // 是否显示变更受理人（工单投诉）
    isShowSendSmsBatch: false, // 是否显示批量发送短信（案件查询）
    isShowActiveSuspend: false, // 是否显示停催/激活按钮（案件详情）
    isShowRecordDownload: false // 是否显示录音下载
  }
  if (!permissionList || !permissionList.length) {
    return showSelectObj
  }
  permissionList.map(item => {
    if (item) {
      if (item === '*.*') {
        showSelectObj = {
          isShowCompanySelect: true,
          isShowManagerSelect: true,
          isShowGroupSelect: true,
          isShowPersonSelect: true,
          isQCOperate: true,
          isAssign: true,
          isShowRecordPath: true, // 是否显示录音地址（案件详情）
          isShowActive: true, // 是否显示激活按钮（案件详情）
          isShowReduce: true, // 是否显示代扣按钮（案件详情）
          isShowReceivePerson: true, // 是否显示变更受理人（工单投诉）
          isShowSendSmsBatch: true, // 是否显示批量发送短信（案件查询）
          isShowActiveSuspend: true, // 是否显示停催/激活按钮（案件详情）
          isShowRecordDownload: true // 是否显示录音下载
        }
        return showSelectObj
      }
      if (item.indexOf('company.selectlist') !== -1) {
        showSelectObj.isShowCompanySelect = true
      }
      if (item.indexOf('manager.selectlist') !== -1) {
        showSelectObj.isShowManagerSelect = true
      }
      if (item.indexOf('group.selectlist') !== -1) {
        showSelectObj.isShowGroupSelect = true
      }
      if (item.indexOf('person.selectlist') !== -1) {
        showSelectObj.isShowPersonSelect = true
      }
      // 质检明细-操作权限
      if (item.indexOf('edit.qualityRechecking') !== -1) {
        showSelectObj.isQCOperate = true
      }
      // 按键查询-分配按钮操作权限
      if (item.indexOf('caseAssignService.manaulAssignCaseByPerson') !== -1) {
        showSelectObj.isAssign = true
      }
      // 案件详情-是否显示录音地址
      if (item.indexOf('caseNewQueryService.recordPath') !== -1) {
        showSelectObj.isShowRecordPath = true
      }
      // 案件详情-是否显示激活按钮
      if (item.indexOf('caseDetailService.activeMobilephone') !== -1) {
        showSelectObj.isShowActive = true
      }
      // 案件详情-是否显示代扣按钮
      if (item.indexOf('caseReduceDebtService.*') !== -1) {
        showSelectObj.isShowReduce = true
      }
      // 工单投诉-变更受理人 modifyReceivePerson
      if (item.indexOf('complainBillService.modifyReceivePerson') !== -1) {
        showSelectObj.isShowReceivePerson = true
      }
      // 案件查询-批量发送短信
      if (item.indexOf('smsManagerService.addBatchToSendList') !== -1) {
        showSelectObj.isShowSendSmsBatch = true
      }
      // 案件详情-停催激活案件
      if (item.indexOf('caseDetailService.activeSuspendCase') !== -1) {
        showSelectObj.isShowActiveSuspend = true
      }
      // 录音下载
      if (item.indexOf('soundDownload') !== -1) {
        showSelectObj.isShowRecordDownload = true
      }
    }
  })
  return showSelectObj
}

// 清除缓存数据
function clearAllCacheData () {
  // 清除本域名下所有cookie数据
  const cookies = Cookies.get()
  for (let key in cookies) {
    Cookies.remove(key)
  }

  // 清除本域名下所有localStorage数据
  const storage = window.localStorage
  /* if (storage && storage.length > 0) {
    for (let i = 0; i < storage.length; i++) {
      // key(i)获得相应的键，再用getItem()方法获得对应的值
      console.log(storage.key(i) + ': ' + storage.getItem(storage.key(i)))
    }
  } */
  storage.clear()
}

let cacheUser = window.localStorage.getItem('Collection-User')
if (!cacheUser) {
  cacheUser = {
    id: '',
    username: '',
    displayName: '',
    roleids: '',
    rbacUserRoleList: [],
    extension: ''
  }
} else {
  cacheUser = JSON.parse(cacheUser)
}

const cacheMenu = window.localStorage.getItem('Collection-MenuTreeList')
const cachePermission = window.localStorage.getItem('Collection-PermissionList')
const cacheSys = window.localStorage.getItem('UC-System-List')

const loginUser = {
  state: {
    userId: cacheUser.id,
    username: cacheUser.username,
    displayName: cacheUser.displayName,
    token: Cookies.get('Collection-Token'),
    roleIds: cacheUser.roleids, // 老系统的角色
    roleLevel: getRoleLevel(cacheUser.roleids), // 根据老系统的角色计算出角色等级
    roleList: cacheUser.rbacUserRoleList, // 新系统的角色
    menuTreeList: cacheMenu ? JSON.parse(cacheMenu) : [], // 菜单树列表
    permissionList: cachePermission ? JSON.parse(cachePermission) : [], // 权限列表
    systemList: cacheSys ? JSON.parse(cacheSys) : [],
    serviceNum: cacheUser.extension, // 坐席号
    // serviceNum: 'S1003', // 坐席号
    showSelectObj: getShowSelectObj(cachePermission ? JSON.parse(cachePermission) : []) // 下拉框显示
  },

  mutations: {
    SET_USER_ID: (state, userId) => {
      state.userId = userId
    },
    SET_USERNAME: (state, username) => {
      state.username = username
    },
    SET_DISPLAY_NAME: (state, displayName) => {
      state.displayName = displayName
    },
    SET_TOKEN: (state, token) => {
      state.token = token
      Cookies.set('Collection-Token', token)
    },
    SET_ROLEIDS: (state, roleIds) => {
      state.roleIds = roleIds
    },
    SET_ROLE_LEVEL: (state, roleIds) => {
      state.roleLevel = getRoleLevel(roleIds)
    },
    SET_ROLE_LIST: (state, rbacUserRoleList) => {
      state.roleList = rbacUserRoleList
    },

    SET_MENU_TREE_LIST: (state, rbacMenuList) => {
      state.menuTreeList = rbacMenuList
      window.localStorage.setItem('Collection-MenuTreeList', JSON.stringify(rbacMenuList))
    },
    SET_PERMISSION_LIST: (state, rbacPermissionList) => {
      let permissionList = []
      rbacPermissionList.map(item => permissionTreeToList(item, permissionList))
      state.permissionList = permissionList
      // 处理 显示下拉框对象
      state.showSelectObj = getShowSelectObj(permissionList)
      window.localStorage.setItem('Collection-PermissionList', JSON.stringify(permissionList))
    },
    SET_SERVICE_NUM: (state, serviceNum) => {
      state.serviceNum = serviceNum
    },
    SET_SYSTEM_LIST: (state, systemList) => {
      state.systemList = systemList
      window.localStorage.setItem('UC-System-List', JSON.stringify(systemList))
    },

    LOGOUT_USER: state => {
      state.userId = ''
      state.username = ''
      state.displayName = ''
      state.token = ''
      state.roleIds = ''
      state.roleLevel = ''
      state.roleList = []
      state.menuTreeList = []
      state.permissionList = []
      state.systemList = []
      state.serviceNum = ''
      state.showSelectObj = {
        isShowCompanySelect: false,
        isShowManagerSelect: false,
        isShowGroupSelect: false,
        isShowPersonSelect: false,
        isQCOperate: false,
        isAssign: false,
        isShowRecordPath: false, // 是否显示录音地址（案件详情）
        isShowActive: false, // 是否显示激活按钮（案件详情）
        isShowReduce: false, // 是否显示代扣按钮（案件详情）
        isShowReceivePerson: false, // 是否显示变更受理人按钮（工单投诉）
        isShowSendSmsBatch: false, // 是否显示批量发送短信（案件查询）
        isShowActiveSuspend: false, // 是否显示停催/激活按钮（案件详情）
        isShowRecordDownload: false // 是否显示录音下载
      }
    }
  },

  actions: {
    // 用户名登录
    LoginByUsername ({ dispatch, commit }, userInfo) {
      const username = userInfo.username.trim()
      return new Promise((resolve, reject) => {
        loginByUsername(username, userInfo.password).then(response => {
          const data = response.data
          if (data.errorCode === 0) {
            dispatch('GetUserInfo').then(() => {
              resolve()
            }).catch(error => {
              resolve(error.message)
            })
          } else {
            resolve(data.errorMsg)
          }
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 获取用户信息
    GetUserInfo ({ commit, state }) {
      return new Promise((resolve, reject) => {
        if (!(document.cookie || navigator.cookieEnabled)) {
          window.alert('Cookie已被禁用')
        }
        getUserInfo().then(response => {
          const data = response.data
          console.log(data, '11111')
          if (data.errorCode === 0 && data.data.rbacUser) {
            if (!data.data.rbacMenuList || data.data.rbacMenuList.length === 0) {
              throw new Error('无可用菜单或未分配角色，请联系管理员')
            }
            commit('SET_USER_ID', data.data.rbacUser.id)
            commit('SET_USERNAME', data.data.rbacUser.username)
            commit('SET_DISPLAY_NAME', data.data.rbacUser.displayName)

            if (!process.env.IS_NOT_SSO) { // 单点登录
              if (!data.data.token) {
                throw new Error('会话过期')
              } else {
                commit('SET_TOKEN', data.data.token)
              }
            } else {
              commit('SET_TOKEN', data.data.rbacUser.username + '_' + data.data.rbacUser.id)
            }
            commit('SET_ROLEIDS', data.data.rbacUser.roleids)
            commit('SET_ROLE_LEVEL', data.data.rbacUser.roleids)
            commit('SET_ROLE_LIST', data.data.rbacUser.rbacUserRoleList)
            commit('SET_MENU_TREE_LIST', data.data.rbacMenuList)
            commit('SET_PERMISSION_LIST', data.data.rbacPermissionList)
            // 坐席号-迁移加入新坐席号字段extension
            commit('SET_SERVICE_NUM', data.data.rbacUser.extension)

            window.localStorage.setItem('Collection-User', JSON.stringify(data.data.rbacUser))
          }
          resolve(response)
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 登出
    Logout ({ commit }) {
      return new Promise((resolve, reject) => {
        logout().then(response => {
          const data = response.data
          if (data.errorCode === 0) {
            commit('LOGOUT_USER')
            commit('CLEAR_ROUTERS')

            // 先清除缓存
            clearAllCacheData()
            resolve()
          } else {
            resolve(data.errorMsg)
          }
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 用户名登录
    LoginByUsernameAndToken ({ dispatch, commit }, user) {
      console.log('1 login user:')
      console.log(user)
      commit('LOGOUT_USER')
      commit('CLEAR_ROUTERS')
      return new Promise((resolve, reject) => {
        loginByUsernameAndToken(user.username, user.token).then(response => {
          const data = response.data
          if (data.errorCode === 0) {
            dispatch('GetUserInfo').then(() => {
              // dispatch('GetUcenterUserInfo').then(() => {
              //   resolve()
              // }).catch(error => {
              //   resolve(error.message)
              // })
              resolve()
            }).catch(error => {
              resolve(error.message)
            })
          } else {
            resolve(data.errorMsg)
          }
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 获取用户中心用户信息
    GetUcenterUserInfo ({ commit, state }) {
      return new Promise((resolve, reject) => {
        getUcenterUserInfo().then(response => {
          const data = response.data
          if (data.rtn === '000' && data.result.user) {
            if (!data.result.systemList || data.result.systemList.length === 0) {
              throw new Error('无可用系统')
            }
            if (!data.result.menuTree || data.result.menuTree.length === 0) {
              throw new Error('无可用菜单')
            }
            commit('SET_SYSTEM_LIST', data.result.systemList)
          }
          resolve(response)
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 获取应用信息
    GetApplicationInfo ({ commit, state }) {
      return new Promise((resolve, reject) => {
        getApplicationInfo().then(response => {
          const data = response.data
          if (data.errorCode === 0) {
            console.groupCollapsed('%c' + packageConfig.sysname, 'color: blue')
            // console.groupCollapsed('%c' + packageConfig.sysname, 'text-shadow: 0 1px 0 #ccc,0 2px 0 #c9c9c9,0 3px 0 #bbb,0 4px 0 #b9b9b9,0 5px 0 #aaa,0 6px 1px rgba(0,0,0,.1),0 0 5px rgba(0,0,0,.1),0 1px 3px rgba(0,0,0,.3),0 3px 5px rgba(0,0,0,.2),0 5px 10px rgba(0,0,0,.25),0 10px 10px rgba(0,0,0,.2),0 20px 20px rgba(0,0,0,.15);font-size:5em')
            console.log('%c 前端：系统信息-' + process.env.NODE_ENV + '，版本-' + packageConfig.version, 'color: blue')
            console.log('%c 后端：系统信息-' + data.data.profile + '，版本-' + data.data.version, 'color: blue')
            // console.log('%c', "padding: 50px 300px; line-height: 120px; background: url('../../assets/img/slogan.png') no-repeat;")
            console.groupEnd()
          }
          resolve(response)
        }).catch(error => {
          reject(error)
        })
      })
    },
    // 登出用户中心
    LogoutUcenter ({ commit }) {
      return new Promise((resolve, reject) => {
        logoutUcenter().then(response => {
          const data = response.data
          if (data.rtn === '000') {
            commit('LOGOUT_USER')
            commit('CLEAR_ROUTERS')

            // 先清除缓存
            clearAllCacheData()

            resolve()
          } else {
            resolve(data.errorMsg)
          }
        }).catch(error => {
          reject(error)
        })
      })
    },
    // 拦截器登出到login
    FilterLogout ({ commit }) {
      return new Promise(resolve => {
        commit('LOGOUT_USER')
        commit('CLEAR_ROUTERS')

        // 先清除缓存
        clearAllCacheData()
        resolve()
      })
    },

    // 刷新页面请求
    RefreshLoad ({ dispatch, commit }) {
      console.log('2 login user:')
      let user = {
        username: Cookies.get('UC-Username'),
        token: Cookies.get('UC-Token')
      }
      console.log(user)
      return new Promise((resolve, reject) => {
        loginByUsernameAndToken(user.username, user.token).then(response => {
          const data = response.data
          if (data.errorCode === 0) {
            commit('SET_TOKEN', user.token)
            commit('SET_USERNAME', user.username)
            resolve()
          } else {
            resolve(data.errorMsg)
          }
        }).catch(error => {
          reject(error)
        })
      })
    }
  }
}

export default loginUser
