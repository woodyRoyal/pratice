import {
  fetchGetProductType
} from 'api/sms'

const appCodeList = window.localStorage.getItem('Collection-AppCodeList')
const appType = window.localStorage.getItem('Collection-AppType')

const sms = {
  state: {
    appCodeList: appCodeList ? JSON.parse(appCodeList) : [], // 产品类型
    appType: appType ? JSON.parse(appType) : {} // 产品类型
  },

  mutations: {
    SET_APP_CODE_LIST: (state, appCodeList) => {
      state.appCodeList = appCodeList
      // 存储
      window.localStorage.setItem('Collection-AppCodeList', JSON.stringify(appCodeList))
    },
    SET_APP_TYPE: (state, appType) => {
      state.appType = appType
      // 存储
      window.localStorage.setItem('Collection-AppType', JSON.stringify(appType))
    }
  },

  actions: {
    // 获取产品类型
    GetAppCodeList ({commit, state}) {
      return new Promise((resolve, reject) => {
        // 如果已存在直接返回
        if (state.appCodeList.length) {
          resolve()
        } else {
          let classCode = 'product_app'
          fetchGetProductType(classCode)
            .then(response => {
              let res = response.data
              if (res.errorCode === 0 && res.data) {
                commit('SET_APP_CODE_LIST', res.data)
                // 获取产品类型常量
                let obj = {}
                res.data.map(item => {
                  obj[item.id] = item.name
                  return item
                })
                commit('SET_APP_TYPE', obj)
              }
              resolve(response)
            })
            .catch(error => {
              reject(error)
            })
        }
      })
    }
  }
}

export default sms
