// 催记信息

// const currentCRInfo = window.localStorage.getItem('Collection-CurrentCRInfo')

const cr = {
  state: {
    // currentCRInfo: currentCRInfo ? JSON.parse(currentCRInfo) : {}, // 当前催记信息
    currentCRInfo: {}, // 当前催记信息
    currentTaskId: '', // 当前任务id
    isShowSmallBox: false, // 是否显示缩小box
    isSubmitted: true, // 是否提交  已提交状态 true / 未提交状态 false
    lateLoginStatus: '',
    todayRemindStatus: '',
    updateContactsStatus: '',
    timeLimit: true // 单呼点击限制
  },

  mutations: {
    SET_CURRENT_CR_INFO: (state, currentCRInfo) => {
      state.currentCRInfo = currentCRInfo
      // 存储
      window.localStorage.setItem('Collection-CurrentCRInfo', JSON.stringify(currentCRInfo))
    },
    SET_CURRENT_TASK_ID: (state, currentTaskId) => {
      state.currentTaskId = currentTaskId
    },
    SET_IS_SHOW_SMALL_BOX: (state, status) => {
      state.isShowSmallBox = status
    },
    SET_IS_SUBMITTED: (state, status) => {
      state.isSubmitted = status
    },
    SET_LOGIN_OPERATION_STATUS: (state, status) => {
      state.lateLoginStatus = status
    },
    SET_REMIND_OPERATION_STATUS: (state, status) => {
      state.todayRemindStatus = status
    },
    SET_UPDATEZ_CONTACTS_STATUS: (state, status) => {
      state.updateContactsStatus = status
    },
    SET_TIME_LIMIT: (state, status) => {
      state.timeLimit = status
    }
  },

  actions: {
    // 获取当前催记信息
    GetCurrentCRInfo ({commit, state}, status) {
      commit('SET_CURRENT_CR_INFO', status)
    },
    // 获取当前任务id
    GetCurrentTaskId ({commit, state}, status) {
      commit('SET_CURRENT_TASK_ID', status)
    },
    // 是否显示缩小box
    IsShowSmallBox ({commit, state}, status) {
      commit('SET_IS_SHOW_SMALL_BOX', status)
    },
    IsSubmitted ({commit, state}, status) {
      commit('SET_IS_SUBMITTED', status)
    },
    // 最近登陆在右下角操作时首页的视图也更新
    lateLoginSaveStatus ({commit}, status) {
      commit('SET_LOGIN_OPERATION_STATUS', status)
    },
    // 今日提醒
    todayRemindSaveStatus ({commit}, status) {
      commit('SET_REMIND_OPERATION_STATUS', status)
    },
    // 五天通讯录
    saveUpdateContactsStatus ({commit}, status) {
      commit('SET_UPDATEZ_CONTACTS_STATUS', status)
    },
    // 单呼连续点击限制
    TimeLimit ({commit}, status) {
      commit('SET_TIME_LIMIT', status)
    }
  }
}

export default cr
