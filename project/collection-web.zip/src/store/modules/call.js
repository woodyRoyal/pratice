/*
 * @Author: sunp
 * @Date: 2019/4/18 10:51
 */
const currentTest = window.localStorage.getItem('Collection-CurrentTest')

const call = {
  state: {
    currentTest: currentTest || 'T3'
  },

  mutations: {
    SET_CURRENT_TEST: (state, currentTest) => {
      state.currentTest = currentTest
      // 存储
      window.localStorage.setItem('Collection-CurrentTest', currentTest)
    }
  },

  actions: {
    setCurrentTest ({ commit }, data) {
      commit('SET_CURRENT_TEST', data)
    }
  }
}

export default call
