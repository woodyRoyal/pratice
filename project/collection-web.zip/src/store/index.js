import Vue from 'vue'
import Vuex from 'vuex'
import app from './modules/app'
import loginUser from './modules/loginUser'
import permission from './modules/permission'
import sms from './modules/sms'
import cr from './modules/cr'
import call from './modules/call'
import getters from './getters'

Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    app,
    loginUser,
    permission,
    sms,
    cr,
    call
  },
  getters
})

export default store
