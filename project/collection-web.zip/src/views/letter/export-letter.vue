
<template>
  <div class="mobility-wrapper">
    <!-- 筛选条件开始 -->
    <el-form :inline="true"
             :model="filterForm"
             size="mini"
             class="filter-form">
      <div>
        <el-form-item label="选择产品">
          <el-select v-model="filterForm.product"
                     style="width:100px;"
                     disabled>
            <el-option :value="1"
                       label="车贷产品">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="导出时间">
          <el-date-picker v-model="value1"
                          type="datetime"
                          placeholder="选择日期时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="导出状态">
          <el-select v-model="filterForm.product"
                     style="width:100px;"
                     disabled>
            <el-option :value="1"
                       label="成功">
            </el-option>
            <el-option :value="0"
                       label="失败">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="申请编号">
          <el-input></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary">查询</el-button>
          <el-button type="primary">批量导出</el-button>
        </el-form-item>
      </div>
    </el-form>
    <!-- 表格 -->
    <el-table :data="tableData"
              v-loading="listLoading"
              stripe
              border
              style="width: 100%"
              :max-height="tableHeight">
      <el-table-column align="center"
                       type="selection"
                       min-width="40">
      </el-table-column>
      <el-table-column align="center"
                       prop="导出时间"
                       label="导出时间"
                       min-width="40">
      </el-table-column>
      <el-table-column align="center"
                       prop="申请编号"
                       label="申请编号"
                       min-width="40">
      </el-table-column>
      <el-table-column align="center"
                       prop="姓名"
                       label="姓名"
                       min-width="40">
      </el-table-column>
      <el-table-column align="center"
                       prop="导出状态"
                       label="导出状态"
                       min-width="40">
      </el-table-column>
    </el-table>
    <div v-show="!listLoading"
         class="pagination-container">
      <el-pagination @size-change="handleSizeChange"
                     @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo"
                     :page-sizes="pagData.pageSizes"
                     :page-size="pagData.pageSize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="pagData.total">
      </el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      // 筛选数据
      filterForm: {
        product: 1,
        day: 1,
        productIds: ''
      },
      tableData: [
        { 1: 1 },
        { 1: 1 },
        { 1: 1 }
      ],
      tableHeight: 600,
      listLoading: false,
      pagData: {
        pageSize: 100, // 每页条数
        pageNo: 1, // 页码
        total: 0, // 总记录数
        pageSizes: [10, 50, 100, 500]
      }

    }
  },
  mounted () {
    // 表格高度
    this.handleResize()
    window.addEventListener('resize', this.handleResize)

    // 获取产品
    this.getAllProductList()
  },
  methods: {
    // resize回调修改表格高度
    handleResize (event) {
      let h = document.documentElement.clientHeight
      this.tableHeight = h - 140
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    uploadSuccess (event, file, fileList) {

    },
    // 处理分页每页显示数改变事件
    handleSizeChange (val) {
      this.pagData.pageSize = val
      // 获取表格数据
      this.getTableData()
    },
    // 处理页码改变事件
    handleCurrentChange (val) {
      this.pagData.pageNo = val
      // 获取表格数据
      this.getTableData()
    }
  }
}
</script>

<style lang="scss" scoped>
.mobility-wrapper {
  .length-1 {
    width: 100px;
  }
  .length-2 {
    width: 180px;
  }
  .el-form-item {
    margin-bottom: 5px;
  }

  .pagination-container {
    margin-top: 5px;
    margin-bottom: 0;
  }
}
</style>
