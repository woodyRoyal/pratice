<template>
  <div>
    <div class="margin">
    <!--电话频率限制-->
    <div class="title">
      <span>电话频率限制</span>
      <el-button type="primary" size="small" style="float: right" @click="saveTelephoneFrequency">保存</el-button>
    </div>
    <el-table :data="callFrequencyData" :span-method="objectSpanMethod" border style="width: 100%; margin-top: 20px">
      <el-table-column prop="id" label="逾期天数" width="180" align="center">
        <template slot-scope="scope">
          <el-input class="input-width" size="mini" v-model="scope.row.startOverdueDays" @keyup.native="inputLimit($event, scope.row,scope.$index, 1)"></el-input>
          <span>~</span>
          <el-input class="input-width" size="mini" v-model="scope.row.endOverdueDays" @keyup.native="inputLimit($event, scope.row,scope.$index, 2)"></el-input>
        </template>
      </el-table-column>
      <el-table-column prop="limitRule" label="限制规则（说明）" align="center">
        <template slot-scope="scope">
            {{scope.row.limitRule === 'self' ? '本人' : '其他人'}}
        </template>
      </el-table-column>
      <el-table-column prop="amount1" label="频次" align="center">
        <template slot-scope="scope">
          <el-input-number :min="1" class="input-width" size="mini" v-model="scope.row.frequency" :controls="false"></el-input-number>
          <span>次/日</span>
        </template>
      </el-table-column>
      <el-table-column prop="amount2" label="操作" align="center">
        <template slot-scope="scope">
          <el-button v-if="scope.$index !== callFrequencyData.length - 2" type="danger" size="mini" @click="deleteTelephoneFrequency(scope.row, scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页开始-->
    <!--<div class="pagination-container">-->
      <!--<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"-->
                     <!--:current-page.sync="callPag.pagData.pageNo" :page-sizes="callPag.pageSizes"-->
                     <!--:page-size="callPag.pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"-->
                     <!--:total="callPag.totalRecord">-->
      <!--</el-pagination>-->
    <!--</div>-->
    <!-- 分页结束-->
    </div>
    <!--短信频率限制-->
    <div class="title">
      <span>短信频率限制</span>
      <el-button type="primary" size="small" style="float: right" @click="saveMessageFrequency">保存</el-button>
    </div>
    <el-table :data="messageFrequencyData" :span-method="objectSpanMethod" border style="width: 100%; margin-top: 20px">
      <el-table-column prop="id" label="逾期天数" width="180" align="center">
        <template slot-scope="scope">
          <el-input class="input-width" size="mini" v-model="scope.row.startOverdueDays" @keyup.native="inputLimit1($event, scope.row,scope.$index, 1)"></el-input>
          <span>~</span>
          <el-input class="input-width" size="mini" v-model="scope.row.endOverdueDays" @keyup.native="inputLimit1($event, scope.row,scope.$index, 2)"></el-input>
        </template>
      </el-table-column>
      <el-table-column label="限制规则（说明）" align="center">
        <template slot-scope="scope">
          {{scope.row.limitRule === 'self' ? '本人' : '其他人'}}
        </template>
      </el-table-column>
      <el-table-column prop="amount1" label="频次" align="center">
        <template slot-scope="scope">
          <el-input-number :min="1" class="input-width" size="mini" v-model="scope.row.timesFrequency" :controls="false"></el-input-number>
          <span>次</span>
          <el-input-number :min="1" class="input-width" size="mini" v-model="scope.row.dayFrequency" :controls="false"></el-input-number>
          <span>日</span>
        </template>
      </el-table-column>
      <el-table-column prop="amount2" label="操作" align="center">
        <template slot-scope="scope">
          <el-button v-if="scope.$index !== messageFrequencyData.length - 2" type="danger" size="mini" @click="deleteMessageFrequency(scope.row, scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页开始-->
    <!--<div class="pagination-container">-->
      <!--<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"-->
                     <!--:current-page.sync="messagePag.pagData.pageNo" :page-sizes="messagePag.pageSizes"-->
                     <!--:page-size="messagePag.pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"-->
                     <!--:total="messagePag.totalRecord">-->
      <!--</el-pagination>-->
    <!--</div>-->
    <!-- 分页结束-->
  </div>
</template>

<script>
  import {
    fetchFindCallAll,
    fetchFindMessageAll,
    fetchCallSaveOrUpdateList,
    fetchMessageSaveOrUpdateList
    // fetchDeleteCall,
    // fetchDeleteMessage
  } from '../../api/sys'
  export default {
    data () {
      return {
        callFrequencyData: [], // 电话频率限制数据
        messageFrequencyData: [], // 短信频率限制数据
        messageFrequencyLastData: [{
          limitRule: 'self', // 阶段名称
          startOverdueDays: null,
          endOverdueDays: null
        }, {
          limitRule: 'other', // 阶段名称
          startOverdueDays: null,
          endOverdueDays: null
        }],
        callFrequencyLastData: [{
          limitRule: 'self', // 阶段名称
          startOverdueDays: null,
          endOverdueDays: null
        }, {
          limitRule: 'other', // 阶段名称
          startOverdueDays: null,
          endOverdueDays: null
        }]
      }
    },
    methods: {
      // 逾期天数输入框的输入限制
      inputLimit (event, value, index, type) {
        this.limit(event, value, index, type, this.callFrequencyData)
      },
      inputLimit1 (event, value, index, type) {
        this.limit(event, value, index, type, this.messageFrequencyData)
      },
      // 输入框限制
      limit (event, value, index, type, data) {
        if (index + 2 === data.length) {
          data.push({
            limitRule: 'self', // 阶段名称
            startOverdueDays: null,
            endOverdueDays: null
          }, {
            limitRule: 'other', // 阶段名称
            startOverdueDays: null,
            endOverdueDays: null
          })
        }
        if (type === 1) {
          data[index].startOverdueDays = data[index].startOverdueDays + ''
          data[index].startOverdueDays = data[index].startOverdueDays === null ? null : data[index].startOverdueDays.replace(/\D/g, '')
        } else {
          data[index].endOverdueDays = data[index].endOverdueDays + ''
          data[index].endOverdueDays = data[index].endOverdueDays === null ? null : data[index].endOverdueDays.replace(/\D/g, '')
        }
      },
      // 删除电话频率限制
      deleteTelephoneFrequency (value, index) {
        this.callFrequencyData.forEach((item, index1) => {
          if (index === index1) {
            this.callFrequencyData.splice(index, 2)
          }
        })
        //        console.log(value.id, this.callFrequencyData[index + 1].id)
        //        fetchDeleteCall(value.id, this.callFrequencyData[index + 1].id)
        //          .then(response => {
        //            let res = response.data
        //            if (res.errorCode === 0) {
        //              this.$message.success('删除成功')
        //              this.getFindCallAll() // 删除成功，重新获取电话频率限制数据
        //            }
        //            console.log(response)
        //          })
        //          .catch(error => {
        //            console.log(error)
        //          })
      },
      // 删除短信频率限制
      deleteMessageFrequency (value, index) {
        this.messageFrequencyData.forEach((item, index1) => {
          if (index === index1) {
            this.messageFrequencyData.splice(index, 2)
          }
        })
        //        fetchDeleteMessage(value.id, this.messageFrequencyData[index + 1].id)
        //          .then(response => {
        //            let res = response.data
        //            if (res.errorCode === 0) {
        //              this.$message.success('删除成功')
        //              this.getFindMessageAll() // 删除成功，重新获取短信频率限制数据
        //            }
        //            console.log(response)
        //          })
        //          .catch(error => {
        //            console.log(error)
        //          })
      },
      // 保存电话频率限制
      saveTelephoneFrequency () {
        this.overDueDays(this.callFrequencyData, 1)
      },
      // 保存短频率限制
      saveMessageFrequency () {
        this.overDueDays(this.messageFrequencyData, 2)
      },
      // 逾期天数输入验证规则
      overDueDays (data, type) {
        if (data[0].startOverdueDays !== '1' && data[0].startOverdueDays !== 1) {
          this.$message.error('逾期天数必须以1开始')
          return false
        }
        if (data[data.length - 4].endOverdueDays !== '' && data[data.length - 4].endOverdueDays !== null) {
          this.$message.error('逾期天数必须以空结尾表示正无穷')
          return false
        }
        let flag = true
        data.forEach((item, index) => {
          if (index % 2 === 0) {
            if (index >= 0 && index <= data.length - 4) {
              //              if (index <= data.length - 6) {
              //                if (parseInt(item.endOverdueDays) < parseInt(item.startOverdueDays)) {
              //                  this.$message.error('逾期天数的后一天必须大于前一天')
              //                  flag = false
              //                }
              //              }
              if (index !== 0) {
                if (parseInt(data[index].startOverdueDays) !== parseInt(data[index - 2].endOverdueDays) + 1) {
                  this.$message.error('逾期天数一列拼起来是 [1,∞)，没有遗漏且没有交叉。')
                  flag = false
                }
              }
            }
          }
        })
        if (flag) {
          if (type === 1) {
            this.getCallSaveOrUpdateList()
          } else {
            this.getMessageSaveOrUpdateList()
          }
        }
      },
      // 保存电话频率限制
      getCallSaveOrUpdateList () {
        this.callFrequencyData[this.callFrequencyData.length - 4].endOverdueDays = null
        this.callFrequencyData.splice(this.callFrequencyData.length - 2, 2)
        this.callFrequencyData.forEach((item, index) => {
          item.endOverdueDays = item.endOverdueDays === null ? null : parseInt(item.endOverdueDays)
          item.startOverdueDays = parseInt(item.startOverdueDays)
          if (index % 2 !== 0) {
            this.callFrequencyData[index].endOverdueDays = this.callFrequencyData[index - 1].endOverdueDays
            this.callFrequencyData[index].startOverdueDays = this.callFrequencyData[index - 1].startOverdueDays
          }
        })
        fetchCallSaveOrUpdateList(JSON.stringify(this.callFrequencyData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success('保存成功')
              this.getFindCallAll() // 保存成功，重新获取电话频率限制数据
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      getMessageSaveOrUpdateList () { // 保存短信频率限制
        this.messageFrequencyData[this.messageFrequencyData.length - 4].endOverdueDays = null
        this.messageFrequencyData.splice(this.messageFrequencyData.length - 2, 2)
        this.messageFrequencyData.forEach((item, index) => {
          item.endOverdueDays = item.endOverdueDays === null ? null : parseInt(item.endOverdueDays)
          item.startOverdueDays = parseInt(item.startOverdueDays)
          if (index % 2 !== 0) {
            this.messageFrequencyData[index].endOverdueDays = this.messageFrequencyData[index - 1].endOverdueDays
            this.messageFrequencyData[index].startOverdueDays = this.messageFrequencyData[index - 1].startOverdueDays
          }
        })
        fetchMessageSaveOrUpdateList(JSON.stringify(this.messageFrequencyData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success('保存成功')
              this.getFindMessageAll() // 保存成功，重新获取电话频率限制数据
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 表格合并函数
      objectSpanMethod ({ row, column, rowIndex, columnIndex }) {
        if (columnIndex === 0) {
          if (rowIndex % 2 === 0) {
            return {
              rowspan: 2,
              colspan: 1
            }
          } else {
            return {
              rowspan: 0,
              colspan: 0
            }
          }
        } else if (columnIndex === 3) {
          if (rowIndex % 2 === 0) {
            return {
              rowspan: 2,
              colspan: 1
            }
          } else {
            return {
              rowspan: 0,
              colspan: 0
            }
          }
        }
      },
      // 获取电话频率限制数据
      getFindCallAll () {
        this.callFrequencyLastData.forEach((item, index) => {
          item.startOverdueDays = null
          item.endOverdueDays = null
        })
        fetchFindCallAll()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.callFrequencyData = res.data.content.concat(this.callFrequencyLastData)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取短信频率限制数据
      getFindMessageAll () {
        this.messageFrequencyLastData.forEach((item, index) => {
          item.startOverdueDays = null
          item.endOverdueDays = null
        })
        fetchFindMessageAll()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.messageFrequencyData = res.data.content.concat(this.messageFrequencyLastData)
            }
          })
          .catch(error => {
            console.log(error)
          })
      }
    },
    mounted () {
      this.getFindCallAll() // 获取电话频率限制数据
      this.getFindMessageAll() // 获取短信频率限制数据
    }
  }
</script>

<style lang="scss" scoped>
  .input-width{
    width: 70px;
  }
  .margin{
    margin-bottom: 10px;
  }
</style>