<!--定时任务-->
<template>
  <div class="schedule-wrapper">
    <div class="add-btn">
      <el-button size="small" type="primary" icon="plus" @click="handleAdd">新增</el-button>
    </div>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row style="width: 100%">
      <el-table-column align="center" label="任务名" min-width="80px">
        <template slot-scope="scope">
          <el-popover placement="top">
            <span>{{ scope.row.taskName }}</span>
            <div slot="reference" class="name-wrapper">
              <span>{{ scope.row.taskName }}</span>
            </div>
          </el-popover>
        </template>
      </el-table-column>

      <el-table-column align="center" label="任务分组" min-width="50px">
        <template slot-scope="scope">
          <span>{{ scope.row.taskGroup }}</span>
        </template>
      </el-table-column>

      <el-table-column align="center" label="描述">
        <template slot-scope="scope">
          <el-popover placement="top">
            <span>{{ scope.row.desc }}</span>
            <div slot="reference" class="name-wrapper">
              <span>{{ scope.row.desc }}</span>
            </div>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column align="center" label="类型" min-width="40px">
        <template slot-scope="scope">
          <span>{{ scope.row.type == 1 ? "cron" : "simple" }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="CRON表达式" min-width="80px">
        <template slot-scope="scope">
          <span>{{ scope.row.cronExpression }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="时间间隔" min-width="30px">
        <template slot-scope="scope">
          <span>{{ scope.row.repeatInterval }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="jobClass">
        <template slot-scope="scope">
          <el-popover placement="top">
            <span>{{ scope.row.jobClass }}</span>
            <div slot="reference" class="name-wrapper">
              <span>{{ scope.row.jobClass }}</span>
            </div>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column align="center" label="状态" min-width="40px">
        <template slot-scope="scope">
          <span>{{ scheduleStatusMap[scope.row.status] }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="正在运行" min-width="50px">
        <template slot-scope="scope">
          <span>{{ scope.row.isRunning ? "是" : "否" }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="上次执行时间" min-width="64px">
        <template slot-scope="scope">
          <span>{{ scope.row.preRunningTime }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="下次执行时间" min-width="64px">
        <template slot-scope="scope">
          <span>{{ scope.row.nextRunningTime }}</span>
        </template>
      </el-table-column>

      <el-table-column align="center" label="操作" min-width="260px">
        <template slot-scope="scope">
          <el-button type="primary" @click='handleEdit(scope.row)' size="mini"
                     icon="edit">编辑
          </el-button>
          <el-button v-show="scope.row.status == 'NORMAL' || scope.row.status == 'RUNNING'" size="mini"
                     @click="handlePauseSchedule(scope.row.taskId)">暂停
          </el-button>
          <el-button v-show="scope.row.status != 'DELETED'" @click="handleResumeSchedule(scope.row.taskId)"
                     size="mini">重启
          </el-button>
          <el-button @click="handleRunOnceSchedule(scope.row.taskId)"
                     size="mini">执行一次
          </el-button>
          <el-button v-show="scope.row.status != 'NORMAL'" @click="handleStartSchedule(scope.row.taskId)"
                     size="mini">启动
          </el-button>
          <el-button @click="handleStopSchedule(scope.row.taskId)"
                     size="mini">停止
          </el-button>
          <el-button v-show="scope.row.status != 'RUNNING'" type="danger" icon="delete2" size="mini"
                     @click="handleDeleteSchedule(scope.row.taskId)">删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <!--新增或修改任务-->
    <el-dialog :title="dialogTitle" :visible.sync="dialogFormVisible" @close="handleDialogClose" class="dialog-schedule-add-or-edit">
      <el-form :model="addScheduleform" :rules="addFormRules" ref="addScheduleform" label-width="100px">
        <el-form-item label="任务名" prop="taskName">
          <el-input v-model="addScheduleform.taskName" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="任务分组" prop="taskGroup">
          <el-input v-model="addScheduleform.taskGroup" disabled></el-input>
        </el-form-item>
        <el-form-item label="描述" prop="desc">
          <el-input v-model="addScheduleform.desc" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="jobClass" prop="jobClass">
          <el-input v-model="addScheduleform.jobClass" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="类型" prop="type" class="is-required">
          <el-radio-group v-model="addScheduleform.type">
            <el-radio :label="1">cron</el-radio>
            <el-radio :label="2">simple</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="CRON表达式" prop="cronExpression" v-show="addScheduleform.type==1">
          <el-input v-model="addScheduleform.cronExpression" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="时间间隔" prop="repeatInterval" v-show="addScheduleform.type==2">
          <el-input-number size="small" v-model="addScheduleform.repeatInterval"></el-input-number>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleAddScheduleCancel">取 消</el-button>
        <el-button type="primary" @click="handleAddScheduleConfirm">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import {
    fetchScheduleList,
    fetchSaveOrUpdateSchedule,
    fetchDeleteScheduleById,
    fetchPauseScheduleById,
    fetchResumeScheduleById,
    fetchRunOnceScheduleById,
    fetchStartScheduleById,
    fetchStopScheduleById,
    fetchBatchLoginByUsernameAndToken
  } from '../../api/sys'
  import { SCHEDULE_STATUS } from './sysConstant'
  import Cookies from 'js-cookie'

  export default {
    data () {
      // 权限
      const validatePermission = (rule, value, callback) => {
        if (!value || value.length === 0) {
          callback(new Error('请选择权限'))
        } else {
          callback()
        }
      }
      return {
        tableData: null, // 表数据
        listLoading: false,

        scheduleStatusMap: SCHEDULE_STATUS, // 定时任务状态
        dialogTitle: '新增任务',
        dialogFormVisible: false, // 显示新增任务框

        addScheduleform: { // 新增任务表单
          taskName: '',
          taskGroup: 'default',
          desc: '',
          jobClass: '',
          type: 1,
          cronExpression: '',
          repeatInterval: 0
        },
        // 新增任务表单输入验证规则
        addFormRules: {
          name: [
            {required: true, message: '请输入任务名', trigger: 'blur'}
          ],
          permissionIdList: [
            {validator: validatePermission, trigger: 'change'}
          ]
        }
      }
    },
    beforeCreate () {
      let user = {
        username: Cookies.get('UC-Username'),
        token: Cookies.get('UC-Token')
      }
      fetchBatchLoginByUsernameAndToken(user.username, user.token).then(response => {
        const data = response.data
        if (data.errorCode === 0) {
          console.log('登录成功')
          this.getTableData()
        }
      }).catch(error => {
        console.log(error)
      })
    },
    mounted () {
      // this.getTableData()
    },
    methods: {
      // 获取表格数据
      getTableData () {
        this.listLoading = true
        fetchScheduleList()
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              this.tableData = response.data.data
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 点击新增按钮
      handleAdd () {
        this.dialogFormVisible = true
        this.dialogTitle = '新增任务'
      },
      // 点击编辑按钮
      handleEdit (value) {
        this.dialogFormVisible = true
        this.dialogTitle = '修改任务'
        this.addScheduleform = Object.assign({}, value)
      },
      // 删除当前任务
      handleDeleteSchedule (taskId) {
        this.$confirm('确认删除此定时任务吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          fetchDeleteScheduleById(taskId)
            .then(res => {
              if (res.data.errorCode === 0) {
                this.$message.success('操作成功')
                this.getTableData()
              }
            })
            .catch(e => {
              console.log(e)
            })
        }).catch(() => {
        })
      },
      // 暂停任务
      handlePauseSchedule (taskId) {
        fetchPauseScheduleById(taskId)
          .then(res => {
            if (res.data.errorCode === 0) {
              this.$message.success('操作成功')
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 重启任务
      handleResumeSchedule (taskId) {
        fetchResumeScheduleById(taskId)
          .then(res => {
            if (res.data.errorCode === 0) {
              this.$message.success('操作成功')
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 任务 启动一次
      handleRunOnceSchedule (taskId) {
        fetchRunOnceScheduleById(taskId)
          .then(res => {
            if (res.data.errorCode === 0) {
              this.$message.success('操作成功')
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 启动任务
      handleStartSchedule (taskId) {
        fetchStartScheduleById(taskId)
          .then(res => {
            if (res.data.errorCode === 0) {
              this.$message.success('操作成功')
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 停止任务
      handleStopSchedule (taskId) {
        fetchStopScheduleById(taskId)
          .then(res => {
            if (res.data.errorCode === 0) {
              this.$message.success('操作成功')
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 新增或修改任务
      saveOrUpdateSchedule (schedule) {
        fetchSaveOrUpdateSchedule(JSON.stringify(schedule))
          .then(res => {
            if (res.data.errorCode === 0) {
              this.$message.success('操作成功')
              this.dialogFormVisible = false
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 弹窗确认按钮-新增或修改任务
      handleAddScheduleConfirm () {
        this.submitForm('addScheduleform')
      },
      // 弹窗取消按钮
      handleAddScheduleCancel () {
        this.dialogFormVisible = false
        this.resetForm('addScheduleform')
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.saveOrUpdateSchedule(this.addScheduleform)
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      // add Dialog 关闭的回调
      handleDialogClose () {
        this.addScheduleform = {
          taskName: '',
          taskGroup: 'default',
          desc: '',
          jobClass: '',
          type: 1,
          cronExpression: '',
          repeatInterval: 0
        }
        this.resetForm('addScheduleform')
      }
    }
  }
</script>

<style lang="scss" scoped>
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

</style>