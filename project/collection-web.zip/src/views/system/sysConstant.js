/* 系统管理相关 常量 */

// 定时任务状态
export const SCHEDULE_STATUS = {
  'NONE': '停止',
  'NORMAL': '启动',
  'PAUSED': '暂停',
  'RUNNING': '执行中',
  'DELETED': '删除',
  'STOPPED': '已停止',
  'ERROR': '错误'
}
export const TABLE_TITLE_TIP = {
  // 参数设置-提示信息
  'autoAssign': '开启后，即每天系统会对当前阶段、未分配、未回款的案件，按金额大小排列并S型分配。',
  'autoRecycle': '开启后，每天系统会对当前阶段、已分配的案件，根据以下规则进行回收：1、还清了欠款金额的案件。2、案件阶段与催收员所在配催收组不匹配'
}
