<!--角色管理-->
<template>
  <div class="role-manage">
    <!--表单-->
    <el-form :inline="true" :model="queryFormData" class="form-user-defined">
      <el-row>
        <el-col :span="12" class="form-btn">
          <el-form-item>
            <el-button size="small" type="primary" icon="plus" @click="openRoleDialog">新增</el-button>
          </el-form-item>
        </el-col>
        <el-col :span="12" style="text-align: right;" class="form-btn">
          <el-form-item>
            <el-input @keyup.enter.native="" size="small" class="length-1" placeholder="请输入角色名"
                      v-model="queryFormData.name">
              <el-button slot="append" type="primary" size="small" v-waves @click="handleSearchData">搜索</el-button>
            </el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row style="width: 100%">
      <el-table-column align="center" label="角色名" prop="name">
      </el-table-column>

      <el-table-column align="center" label="描述" prop="description" show-overflow-tooltip>
      </el-table-column>

      <el-table-column align="center" label="拥有权限" min-width="300px">
        <template slot-scope="scope">
          <el-popover placement="top">
            <span v-for="(item, index) in scope.row.rbacRolePermissionList">
              {{ index + 1 == scope.row.rbacRolePermissionList.length ? permissionListMap[item.permissionId] : permissionListMap[item.permissionId] + ","
              }}
            </span>
            <div slot="reference" class="name-wrapper">
              <span v-for="(item, index) in scope.row.rbacRolePermissionList">
                {{ index + 1 == scope.row.rbacRolePermissionList.length ? permissionListMap[item.permissionId] : permissionListMap[item.permissionId] + ","
                }}
              </span>
            </div>
          </el-popover>
        </template>
      </el-table-column>

      <el-table-column align="center" label="是否启用">
        <template slot-scope="scope">
          <!-- 0 禁用; 1 启用 -->
          <span>{{ scope.row.valid == '1' ? '是' : '否' }}</span>
        </template>
      </el-table-column>

      <el-table-column align="center" label="操作" min-width="100px">
        <template slot-scope="scope">
          <el-button type="primary" @click='handleEditRole(scope.row)' size="mini"
                     icon="edit">修改
          </el-button>
          <el-button type="danger" @click="handleDeleteRole(scope.row)" icon="delete2"
                     size="mini">删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="queryFormData.index" :page-sizes="pageSizes"
                     :page-size="queryFormData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="queryFormData.totalRecord">
      </el-pagination>
    </div>
    <!--新增角色-->
    <el-dialog :title="dialogTitle" size="tiny" :visible.sync="dialogFormVisible" @close="handleDialogClose" class="add-edit-role-dialog">
      <el-form :model="addRoleform" :rules="addFormRules" ref="addRoleform" label-width="80px">
        <el-form-item label="角色名" prop="name">
          <el-input v-model="addRoleform.name" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="描述" prop="description">
          <el-input v-model="addRoleform.description" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="权限" prop="permissionIdList" class="is-required">
          <el-tree show-checkbox highlight-current style="max-height: 300px;overflow: auto"
                   ref="permissionTreeData"
                   :check-strictly="true"
                   @check-change="handleCheckChange"
                   :data="permissionTreeData"
                   node-key="id" :props="permissionTreeProps">
          </el-tree>
        </el-form-item>
        <el-form-item label="是否启用" prop="valid">
          <el-radio class="radio" v-model="addRoleform.valid" label="1">是</el-radio>
          <el-radio class="radio" v-model="addRoleform.valid" label="0">否</el-radio>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleAddRoleCancel">取 消</el-button>
        <el-button type="primary" @click="handleAddRoleConfirm">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import ElSelectTree from '../../components/SelectTree/selectTree.vue'
  import {
    fetchRoleList,
    fetchPermissionTree,
    fetchPermissionList,
    fetchSaveOrUpdateRole,
    fetchDeleteRoleByIdList
  } from '../../api/sys'

  export default {
    components: {
      ElSelectTree
    },
    computed: {
      // 分页参数
      queryPage () {
        return {
          pageNo: this.queryFormData.index, // 页码
          pageSize: this.queryFormData.pageSize // 每页显示的记录数
        }
      }
    },
    data () {
      // 权限
      const validatePermission = (rule, value, callback) => {
        if (!value || value.length === 0) {
          callback(new Error('请选择权限'))
        } else {
          callback()
        }
      }
      return {
        // 查询表单参数
        queryFormData: {
          name: '', // 角色名
          pageSize: 50, // 每页条数
          index: 1, // 页码
          totalRecord: null, // 总记录数
          totalPage: null // 总页数
        },
        pageSizes: [50, 100, 200],

        tableData: null, // 表数据
        listLoading: false,

        dialogFormVisible: false, // 显示新增角色框

        permissionTreeData: [], // 权限树数据
        permissionListMap: {}, // 权限数据对象
        permissionTreeProps: { // 权限树配置 字段映射
          children: 'children',
          label: 'name',
          id: 'id'
        },

        addRoleform: { // 新增角色表单
          name: '',
          description: '',
          rbacRolePermissionList: [], // 角色权限对象数组
          permissionIdList: [], // 角色权限id数组 页面使用
          valid: '1' // 1_有效角色 0_无效角色
        },
        // 新增角色表单输入验证规则
        addFormRules: {
          name: [
            {required: true, message: '请输入角色名', trigger: 'blur'}
          ],
          permissionIdList: [
            {validator: validatePermission, trigger: 'change'}
          ]
        },
        dialogTitle: '' // 弹窗的title
      }
    },
    mounted () {
      this.getPermissionTree()
      this.getPermissionList()
      this.getTableData()
    },
    methods: {
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.queryFormData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.queryFormData.index = val
        this.getTableData()
      },
      // 搜索按钮
      handleSearchData () {
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        this.listLoading = true
        fetchRoleList(this.queryFormData.name, JSON.stringify(this.queryPage))
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              // 遍历处理数据
              this.tableData = response.data.data.content.map(item => {
                // 获取权限ID
                item.permissionIdList = []
                item.rbacRolePermissionList.map(obj => {
                  item.permissionIdList.push(obj.permissionId)
                })
                return item
              })
              this.queryFormData.totalRecord = response.data.data.totalRecord
              this.queryFormData.totalPage = response.data.data.totalPage
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取权限树
      getPermissionTree () {
        fetchPermissionTree()
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              this.permissionTreeData = response.data.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取权限列表
      getPermissionList () {
        fetchPermissionList()
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              // 数组转map对象
              const permissionList = response.data.data.content
              if (permissionList && permissionList.length > 0) {
                for (let item of permissionList) {
                  this.permissionListMap[item.id] = item.name
                }
              }
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 点击新增按钮，打开dialog
      openRoleDialog () {
        this.dialogFormVisible = true
        this.dialogTitle = '新增角色'
        // 新增角色表单置空
        this.addRoleform = { // 新增角色表单
          name: '',
          description: '',
          rbacRolePermissionList: [], // 角色权限对象数组
          permissionIdList: [], // 角色权限id数组 页面使用
          valid: '1' // 1_有效角色 0_无效角色
        }
      },
      // 清空树节点的选择
      resetChecked () {
        this.$refs.permissionTreeData.setCheckedKeys([])
      },
      // 通过key设置
      setCheckedKeys (keys) {
        this.$refs.permissionTreeData.setCheckedKeys(keys)
      },
      // Dialog 关闭的回调
      handleDialogClose () {
        this.resetChecked()
        this.getTableData()
      },
      // 点击修改按钮，打开弹窗，传递数据
      handleEditRole (role) {
        this.dialogFormVisible = true
        this.dialogTitle = '修改角色'
        this.addRoleform = Object.assign({}, role)
        // 给权限树赋值（等视图渲染完再，不然undefined）
        this.$nextTick(() => {
          this.setCheckedKeys(role.permissionIdList)
        })
      },
      // 新增或修改角色
      saveOrUpdateRole (role) {
        fetchSaveOrUpdateRole(JSON.stringify(role))
          .then(res => {
            if (res.data.errorCode === 0 && res.data.data) {
              this.$message.success('操作成功')
              this.dialogFormVisible = false
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 删除当前角色
      handleDeleteRole (role) {
        // id转为数组
        let ids = []
        ids[0] = role.id
        this.deleteRoles(ids, role.name)
      },
      // 删除角色
      deleteRoles (idList, roleName) {
        this.$confirm('确认删除角色【' + roleName + '】吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          fetchDeleteRoleByIdList(JSON.stringify(idList))
            .then(res => {
              if (res.data.errorCode === 0) {
                this.$message.success('操作成功')
                this.getTableData()
              }
            })
            .catch(e => {
              console.log(e)
            })
        }).catch(() => {
        })
      },
      // 处理权限树选中事件
      handleCheckChange (data, checked, indeterminate) {
        this.addRoleform.permissionIdList = this.$refs.permissionTreeData.getCheckedKeys()
      },
      // 确认添加角色
      handleAddRoleConfirm () {
        this.submitForm('addRoleform')
      },
      // 取消添加角色
      handleAddRoleCancel () {
        this.dialogFormVisible = false
        this.resetForm('addRoleform')
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.addRoleform.rbacRolePermissionList = []
            // 组装角色权限对象
            this.addRoleform.permissionIdList.map(permissionId => {
              let rolePermission = {
                permissionId: permissionId
              }
              this.addRoleform.rbacRolePermissionList.push(rolePermission)
            })
            this.saveOrUpdateRole(this.addRoleform)
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      handleCascaderChange (val) {
        this.addRoleform.groupId = val[val.length - 1] // 取最后一级分组的id
      }
    }
  }
</script>

<style lang="scss" scoped>
  .form-user-defined {
    .el-form-item {
      margin-right: 20px;
      margin-bottom: 10px;
    }
    .form-btn {
      .el-form-item {
        margin-right: 0;
      }
    }
  }

  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

</style>
