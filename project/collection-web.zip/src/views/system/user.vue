<!--用户管理-->
<template>
  <div class="user-manage">
    <!--表单-->
    <el-form :inline="true" :model="queryFormData" class="form-user-defined">
      <el-row>
        <!--<el-col :span="2" class="form-btn">-->
          <!--<el-form-item>-->
            <!--<el-button size="small" type="primary" icon="plus" @click="dialogFormVisible = true">新增</el-button>-->
          <!--</el-form-item>-->
        <!--</el-col>-->
        <el-col :span="24" class="form-btn">
          <el-form-item label="所在分组:">
            <vue-el-select v-model="groupIds" multiple filterable reserve-keyword size="small" class="length-1">
              <el-option
              v-for="item in groupList"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
            </vue-el-select>
          </el-form-item>
          <el-form-item label="中文名:">
            <vue-el-select v-model="userIds2" multiple filterable  size="small" class="length-1" remote
                           @visible-change="handleCollectorVisibleChange" :remote-method="filterCollector"
                           :loading="collectorLoading">
              <el-option
                v-for="item in collectorFilterList"
                :key="item.id"
                :label="item.displayName"
                :value="item.id">
              </el-option>
            </vue-el-select>
          </el-form-item>
          <el-form-item label="用户名:">
            <el-input size="small" class="length-1" v-model="queryFormData.username" placeholder="请输入用户名"
                      @keyup.enter.native="handleSearchData"></el-input>
          </el-form-item>
          <el-form-item label="角色:">
            <vue-el-select v-model="roleIds" multiple size="small" class="length-1">
              <el-option
                v-for="item in rolesList"
                :key="item.id"
                :label="item.name"
                :value="item.id">
              </el-option>
            </vue-el-select>
          </el-form-item>
          <el-form-item label="是否自动分案:">
            <el-select v-model="queryFormData.autoAssignCaseEnabled" size="small" class="length-1">
              <el-option  v-for="(item, index) in autoAssignCaseEnabledList"
                          :key="index"
                          :label="item"
                          :value="index === 'def' ? '' : Number(index)"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item>
            <!--<el-input @keyup.enter.native="" size="small" class="length-1" placeholder="请输入显示名"-->
                      <!--v-model="queryFormData.displayName" @keyup.enter.native="handleSearchData">-->
              <!--&lt;!&ndash;<el-button slot="append" type="primary" size="small" v-waves @click="handleSearchData">搜索</el-button>&ndash;&gt;-->
              <!--&lt;!&ndash;<el-button slot="append" type="primary" size="small" v-waves @click="handleSearchData">搜索</el-button>&ndash;&gt;-->
            <!--</el-input>-->
            <el-button type="primary" size="small" v-waves @click="handleSearchData" icon="el-icon-search">搜索</el-button>
            <el-button type="primary" size="small" v-waves @click="exportData">导出</el-button>
          </el-form-item>
          <el-form-item>
            <div class="upload-file-main">
              <!--上传组件 accept=".csv" application/vnd.ms-excel accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" -->
              <el-upload class="upload-user-defined" name="in" accept=".csv"
                         :action="uploadExcelUrl" :data="additionalData" :file-list="fileList" :show-file-list="false"
                         :with-credentials="true" :clearFiles="handleClearFiles"
                         :before-upload="handleUploadBefore" :on-success="handleUploadSuccess" :on-error="handleUploadError"
                         :on-progress="handleUploadProgress" :on-change="handleUploadChange" :disabled="isUploading">
                <el-button size="small" type="primary" :loading="isUploading">{{ uploadingText }}<i class="el-icon-upload el-icon--right"></i></el-button>
              </el-upload>
            </div>
          </el-form-item>
          <el-form-item>
            <span class="file-name" @click="downloadTemplate">点击下载</span>
            <span>文件模板</span>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="small" @click="exportBatchBtn">批量操作</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row style="width: 100%"
              :max-height="tableMaxHeight" @selection-change="handleSelectionChange">
      <el-table-column align="center" type="selection"></el-table-column>
      <el-table-column align="center" label="用户名" prop="username"></el-table-column>
      <el-table-column align="center" label="显示名" prop="displayName"></el-table-column>
      <!--<el-table-column align="center" label="所在分组">-->
      <!--<template slot-scope="scope">-->
      <!--<span>{{ groupListMap[scope.row.groupId] }}</span>-->
      <!--</template>-->
      <!--</el-table-column>-->
      <el-table-column align="center" label="所在分组" width="200">
        <template slot-scope="scope">
          <span>{{scope.row.groupNames.join('->')}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="职位" prop="positionDesc"></el-table-column>
      <el-table-column align="center" label="角色">
        <template slot-scope="scope">
         {{scope.row.roleNames.join(',')}}
        </template>
      </el-table-column>
      <el-table-column align="center" label="新坐席号" prop="extension"></el-table-column>
      <!--<el-table-column align="center" label="坐席号" prop="serviceNum"></el-table-column>-->
      <el-table-column align="center" label="是否自动分配案件">
        <template slot-scope="scope">
          <span>{{ scope.row.autoAssignCaseEnabled === 1 ? '是' : '否' }}</span>
        </template>
      </el-table-column>
      <!--<el-table-column align="center" label="是否显示通讯录">-->
        <!--<template slot-scope="scope">-->
          <!--<span>{{ scope.row.showContacts === 1 ? '是' : '否' }}</span>-->
        <!--</template>-->
      <!--</el-table-column>-->
      <el-table-column align="center" label="更新日期" prop="updatedate" width="150"></el-table-column>
      <!--<el-table-column align="center" label="开放通讯录的逾期扩展天数" prop="overdueStart"></el-table-column>-->
      <!--<el-table-column align="center" label="是否启用">-->
        <!--<template slot-scope="scope">-->
          <!--&lt;!&ndash; 0 禁用; 1 启用 &ndash;&gt;-->
          <!--<span>{{ scope.row.userIseffective === 1 ? '是' : '否' }}</span>-->
        <!--</template>-->
      <!--</el-table-column>-->

      <el-table-column align="center" label="操作">
        <template slot-scope="scope">
          <el-button v-if="userId !== scope.row.id" type="primary" @click='handleUpdateUser(scope.row)' size="mini"
                     icon="edit">修改
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="queryFormData.index" :page-sizes="pageSizes"
                     :page-size="queryFormData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="queryFormData.totalRecord">
      </el-pagination>
    </div>
    <!--新增用户-->
    <el-dialog :title="isAddDialog ? '批量操作': '修改用户'" size="tiny" width="40%" :visible.sync="dialogFormVisible"
               @close="handleDialogClose">
      <el-form :model="addOrEditForm" :rules="addOrEditFormRules" ref="addOrEditForm" label-width="200px">
        <el-form-item label="选择所属分组:">
          <el-select v-model="addOrEditForm.groupId" filterable size="small" class="length-1">
            <el-option
              v-for="item in groupList"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="选择角色:">
          <vue-el-select v-model="addOrEditForm.roleIdsList"  multiple size="small" class="length-1">
            <el-option
              v-for="item in rolesList"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </vue-el-select>
        </el-form-item>
        <el-form-item label="中文名:" v-show="!isAddDialog">
          <el-input v-model="addOrEditForm.displayName" size="small" class="length-1" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="新坐席号:" v-show="!isAddDialog">
          <el-input v-model="addOrEditForm.extension" size="small" class="length-1"></el-input>
        </el-form-item>
        <!--<el-form-item label="请输入坐席号:">-->
          <!--<el-input v-model="addOrEditForm.serviceNum" size="small" class="length-1"></el-input>-->
        <!--</el-form-item>-->
        <el-form-item label="请选择职位:">
          <el-select v-model="addOrEditForm.positionCode" size="small" class="length-1">
            <el-option
              v-for="item in jobsList"
              :key="item.value"
              :label="item.desc"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="是否自动分配案件:">
          <el-select v-model="addOrEditForm.autoAssignCaseEnabled" size="small" class="length-1">
            <el-option  v-for="(item, index) in showContactsList"
                        :key="index"
                        :label="item"
                        :value="Number(index)"></el-option>
          </el-select>
        </el-form-item>
        <!--<el-form-item label="是否显示通讯录:">-->
          <!--<el-select v-model="addOrEditForm.showContacts" size="small" class="length-1">-->
            <!--<el-option  v-for="(item, index) in showContactsList"-->
                        <!--:key="index"-->
                        <!--:label="item"-->
                        <!--:value="Number(index)"></el-option>-->
          <!--</el-select>-->
        <!--</el-form-item>-->
        <!--<el-form-item label="开放通讯录的逾期扩展天数:">-->
          <!--<el-input-number :controls="false" v-model="addOrEditForm.overdueStart" size="small"  class="length-1"></el-input-number>-->
        <!--</el-form-item>-->
        <!--<el-form-item label="用户名" prop="username">-->
          <!--<el-input v-model="addOrEditForm.username" auto-complete="off" disabled></el-input>-->
        <!--</el-form-item>-->
        <!--<el-form-item label="显示名" prop="displayName">-->
          <!--<el-input v-model="addOrEditForm.displayName" auto-complete="off" disabled></el-input>-->
        <!--</el-form-item>-->
        <!--&lt;!&ndash;<el-form-item label="分组" prop="groupIdList" class="is-required">&ndash;&gt;-->
        <!--&lt;!&ndash;&lt;!&ndash;级联选择器&ndash;&gt;&ndash;&gt;-->
        <!--&lt;!&ndash;<el-cascader v-model="addOrEditForm.groupIdList" :options="groupTreeData" :props="groupCascaderProps"&ndash;&gt;-->
        <!--&lt;!&ndash;placeholder="请选择分组" size="small" change-on-select :show-all-levels="false"&ndash;&gt;-->
        <!--&lt;!&ndash;@change="handleCascaderChange">&ndash;&gt;-->
        <!--&lt;!&ndash;</el-cascader>&ndash;&gt;-->
        <!--&lt;!&ndash;</el-form-item>&ndash;&gt;-->
        <!--<el-form-item label="角色" prop="roleIdList">-->
          <!--<el-select v-model="addOrEditForm.roleIdList" multiple size="small" placeholder="请选择角色">-->
            <!--<el-option v-for="item in roleListData" :key="item.id" :label="item.name" :value="item.id"-->
                       <!--:disabled="item.valid == '0'">-->
            <!--</el-option>-->
          <!--</el-select>-->
        <!--</el-form-item>-->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleAddUserCancel">取 消</el-button>
        <el-button type="primary" v-if="isAddDialog" @click="handleUserModify">确 定</el-button>
        <el-button type="primary" v-else @click="handleEditUserConfirm" :loading="editUserConfirmButton">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import VueElSelect from '../../components/VueElSelect'
  import { parseTime } from '../../utils/formatDate'
  import getFirstLetter from 'utils/chineseToPhoneticInitial'
  import {
    fetchUserList,
    // fetchUpdateUserRole,
    fetchUpdateUser,
    URL_EXPORT_USER_CASE,
    // fetchGroupTree,
    // fetchGroupList,
    fetchBatchOperation,
    fetchRoles,
    fetchGroups,
    fetchUsers,
    fetchJobs,
    // fetchRoleList,
    fetchSaveOrUpdateUser,
    fetchResetPassword,
    // fetchUsernameIsExists,
    fetchDisableUser,
    fetchEnableUser,
    URL_IMPORT_CASE_ASSIGN_FILE
    // URL_EXPORT_FILE_TEMPLATE
  } from '../../api/sys'

  export default {
    components: {
      VueElSelect
    },
    computed: {
      ...mapGetters([
        'permissionList',
        'userId' // 用户ID
      ]),
      // 分页参数
      queryPage () {
        return {
          pageNo: this.queryFormData.index, // 页码
          pageSize: this.queryFormData.pageSize // 每页显示的记录数
        }
      }
    },
    data () {
      // 校验用户名是否可用
      /* const validateUsername = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入用户名'))
        } else {
          fetchUsernameIsExists(value)
            .then(response => { // true存在 false不存在
              if (response.data.errorCode === 0 && response.data.data) { // true:重名 false:不重名
                callback(new Error('用户名已存在'))
              } else {
                callback()
              }
            })
            .catch(error => {
              callback(error)
            })
        }
      } */
      // 分组
      /* const validateGroupId = (rule, value, callback) => {
        if (!value || value.length === 0) {
          callback(new Error('请选择分组'))
        } else {
          callback()
        }
      } */
      // 角色
      /* const validateRoleId = (rule, value, callback) => {
        if (!value || value.length === 0) {
          callback(new Error('请选择角色'))
        } else {
          callback()
        }
      } */
      return {
        editUserConfirmButton: false, // 修改用户loading按钮
        // 查询表单参数
        queryFormData: {
          username: '', // 用户名
          displayName: '', // 显示名
          pageSize: 50, // 每页条数
          index: 1, // 页码
          totalRecord: 0, // 总记录数
          totalPage: 0, // 总页数
          groupIds: '',
          roleIds: '',
          userIds2: '',
          autoAssignCaseEnabled: '', // 是否自动分案
          userIseffective: '1',
          overdueStart: null
        },
        // 催收员列表
        collectorList: [],
        collectorTempList: [], // 联动过滤后下拉列表
        collectorFilterList: [], // 输入过滤后下拉列表
        collectorLoading: false,
        testinput: '',

        userIds: [], // 批量操作时的用户id列表
        userIds2: [],
        groupIds: [],
        roleIds: [],
        autoAssignCaseEnabledList: { // 自动分案
          'def': '所有',
          '1': '是',
          '0': '否'
        },
        showContactsList: {
          '1': '是',
          '0': '否'
        },
        multipleSelection: [],
        pageSizes: [50, 100, 200],
        uploadExcelUrl: URL_IMPORT_CASE_ASSIGN_FILE, // 上传的地址
        additionalData: {}, // 上传时附带的额外参数
        isUploading: false, // 文件上传中 按钮禁用提示
        fileList: [],
        tableData: null, // 表数据
        listLoading: false,
        tableMaxHeight: 600, // 表格最大高度

        dialogFormVisible: false, // 显示新增用户框
        isAddDialog: false,

        roleListData: [], // 角色列表数据
        roleListMap: {}, // 角色列表对象
        groupList: [], // 分组列表数据
        rolesList: [], // 角色数据列表
        usersList: [],
        jobsList: [], // 职位数据列表
        /* groupTreeData: [], // 分组树数据
        groupListMap: {}, // 分组数据对象
        groupTreeProps: { // 分组树配置 字段映射
          children: 'children',
          label: 'name',
          id: 'id'
        },
        groupCascaderProps: { // 分组级联选择器配置 字段映射
          children: 'children',
          label: 'name',
          value: 'id'
        }, */
        uploadingText: '批量修改上传', // 上传按钮文字
        addOrEditForm: { // 新增用户表单
          roleIdList: [], // 用户角色id数组 页面使用
          id: '',
          groupId: '',
          username: '',
          password: '',
          salt: '',
          displayName: '',
          roleids: '',
          locked: 0,
          extension: '',
          serviceNum: '',
          autoAssignCaseEnabled: 0,
          userIseffective: 1, // 1_有效用户 0_无效用户
          groupName: '',
          rbacUserRoleList: [],
          roleIdsList: [],
          positionCode: null,
          showContacts: 1
        },
        // 新增用户表单输入验证规则
        addOrEditFormRules: {
          /* username: [
            {validator: validateUsername, trigger: 'blur'}
          ],
          displayName: [
            {required: true, message: '请输入显示名', trigger: 'blur'}
          ],
           groupIdList: [
            {validator: validateGroupId, trigger: 'change'}
          ],
           roleIdList: [
            {validator: validateRoleId, trigger: 'change'}
          ] */
        }
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      // 监听窗口大小变化
      window.addEventListener('resize', this.handleResize)
      this.getTableData()
      // this.getGroupTree()
      // this.getGroupList()
      // this.getRoleList()
      // this.getUsers() // 获取中文名数据列表
      this.getGroups() // 获取分组数据列表
      this.getRoles() // 获取角色数据列表
      this.getJobs() // 获取职位数据列表
    },
    watch: {
      isUploading (val) {
        this.uploadingText = val ? '处理中' : '批量修改上传'
      }
    },
    methods: {
      // 上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
      handleUploadBefore (file) {
        if (file.name && file.name.length > 0) {
          this.additionalData.fileName = file.name
          const ldot = file.name.lastIndexOf('.')
          const type = file.name.toLowerCase().substring(ldot)
          if (type !== '.csv') {
            this.$message.warning('目前只支持.csv格式的文件')
            return false
          }
        }
      },
      // 文件上传成功时的钩子
      handleUploadSuccess (response, file, fileList) {
        if (response.errorCode === 0 && response.data.status) {
          this.$message.success('上传文件成功!')
          this.getTableData()
        } else {
          this.$message.error(response.data.errorMsg)
          // 移除文件
          this.handleClearFiles()
        }
      },
      // 文件上传失败时的钩子
      handleUploadError (err, file, fileList) {
        console.log(err)
        this.$message.error('上传文件失败!')
      },
      // 文件上传时的钩子
      handleUploadProgress (event, file, fileList) {
        this.isUploading = true // 开启提示
        this.fileList = fileList
        console.log('上传文件中...')
      },
      // 文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
      handleUploadChange (file, fileList) {
        this.isUploading = false // 关闭提示
        console.log('上传文件完成')
      },
      // 清空已上传的文件列表
      handleClearFiles () {
        this.fileList = []
      },
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let h = document.documentElement.clientHeight
          this.tableMaxHeight = h - 225
        })
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.queryFormData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.queryFormData.index = val
        this.getTableData()
      },
      // 搜索按钮
      handleSearchData () {
        this.getTableData()
      },
      // 导出按钮
      exportData () {
        this.queryFormData.userIds2 = this.userIds2.length === 0 ? '' : this.userIds2.join(',')
        this.queryFormData.groupIds = this.groupIds.length === 0 ? '' : this.groupIds.join(',')
        this.queryFormData.roleIds = this.roleIds.length === 0 ? '' : this.roleIds.join(',')
        this.queryFormData.userIds1 = this.queryFormData.username
        let currTime = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = `${URL_EXPORT_USER_CASE}?fileName=用户管理-${currTime}.csv&userIds1=${this.queryFormData.userIds1}&userIds2=${this.queryFormData.userIds2}&groupIds=${this.queryFormData.groupIds}&roleIds=${this.queryFormData.roleIds}&userIseffective=${this.queryFormData.userIseffective}&autoAssignCaseEnabled=${this.queryFormData.autoAssignCaseEnabled}&username=${this.queryFormData.username}`
        window.location.href = url
      },
      // 获取表格数据
      getTableData () {
        this.listLoading = true
        this.queryFormData.userIds2 = this.userIds2.length === 0 ? '' : this.userIds2.join(',')
        this.queryFormData.groupIds = this.groupIds.length === 0 ? '' : this.groupIds.join(',')
        this.queryFormData.roleIds = this.roleIds.length === 0 ? '' : this.roleIds.join(',')
        this.queryFormData.userIds1 = this.queryFormData.username
        fetchUserList(this.queryFormData.userIds1, this.queryFormData.username, this.queryFormData.userIds2, this.queryFormData.groupIds, this.queryFormData.roleIds, this.queryFormData.userIseffective, this.queryFormData.autoAssignCaseEnabled, this.queryFormData.pageSize, this.queryFormData.index)
          .then(response => {
            this.listLoading = false
            if (response.data.errorCode === 0) {
              this.tableData = response.data.data.content
              //              // 遍历处理数据
              //              this.tableData = response.data.data.map(item => {
              //                // 获取角色ID
              //                item.roleIdList = []
              //                item.rbacUserRoleList.map(role => {
              //                  item.roleIdList.push(role.roleId)
              //                })
              //                return item
              //              })
              //              this.queryFormData.totalRecord = response.data.data.totalRecord
              //              this.queryFormData.totalPage = response.data.data.totalPage
              if (this.tableData) {
                this.tableData.forEach((item, index) => {
                  item.roleIdsList = []
                  item.roleIdList.forEach((items) => {
                    item.roleIdsList.push(Number(items))
                  })
                })
              }
              this.queryFormData.totalRecord = response.data.data.totalRecord
              this.queryFormData.totalPage = response.data.data.totalPage
              this.queryFormData.index = response.data.data.pageNo
              this.queryFormData.pageSize = response.data.data.pageSize
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取分组列表
      getGroups () {
        fetchGroups()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.groupList = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取角色列表
      getRoles () {
        fetchRoles()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.rolesList = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      getUsers () {
        fetchUsers()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.usersList = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      getJobs () {
        fetchJobs()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.jobsList = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 修改用户信息
      handleUpdateUser (user) {
        this.addOrEditForm = Object.assign({}, user)
        //        // 处理角色
        //        this.addOrEditForm.roleIdList = []
        //        user.rbacUserRoleList.map(role => {
        //          this.addOrEditForm.roleIdList.push(role.roleId)
        //        })
        //        this.addOrEditForm.roleIdsList = []
        //        this.addOrEditForm.roleIdList.forEach((item, index) => {
        //          this.addOrEditForm.roleIdsList.push(Number(item))
        //        })
        this.addOrEditForm.positionCode = this.addOrEditForm.positionCode + ''
        this.isAddDialog = false
        this.dialogFormVisible = true
      },
      // 新增或修改用户
      saveOrUpdateUser (user) {
        fetchSaveOrUpdateUser(JSON.stringify(user))
          .then(res => {
            if (res.data.errorCode === 0 && res.data.data) {
              this.$message.success('操作成功')
              this.dialogFormVisible = false
              this.getTableData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 批量操作用户
      handleUserModify () {
        let data = {
          userIds: this.userIds.join(','),
          groupIds: this.addOrEditForm.groupId,
          roleIds: this.addOrEditForm.roleIdsList.join(','),
          job: this.addOrEditForm.positionCode === 'null' ? null : Number(this.addOrEditForm.positionCode),
          autoAssignCaseEnabled: this.addOrEditForm.autoAssignCaseEnabled
        }
        fetchBatchOperation(data.userIds, data.groupIds, data.roleIds, data.job, data.autoAssignCaseEnabled)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && !res.data) {
              this.$message.success('批量操作成功')
              this.dialogFormVisible = false
              this.getTableData()
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 修改用户角色
      handleEditUserConfirm () {
        //        this.addOrEditForm.rbacUserRoleList = []
        //        this.addOrEditForm.roleIdList.map(item => {
        //          let tmpUserRole = { // 用户角色关联对象
        //            roleId: item,
        //            roleName: this.roleListMap[item],
        //            userId: this.addOrEditForm.id
        //          }
        //          this.addOrEditForm.rbacUserRoleList.push(tmpUserRole)
        //        })

        //        fetchUpdateUserRole(this.addOrEditForm.id, JSON.stringify(this.addOrEditForm.rbacUserRoleList))
        //          .then(res => {
        //            if (res.data.errorCode === 0 && res.data.data) {
        //              this.$message.success('操作成功')
        //              this.dialogFormVisible = false
        //              this.getTableData()
        //            }
        //          })
        //          .catch(e => {
        //            console.log(e)
        //          })
        this.editUserConfirmButton = true // 点击确定loading出现
        let data = {
          groupId: this.addOrEditForm.groupId,
          // roleids: this.addOrEditForm.roleIdsList.join(','),
          roleIdList: this.addOrEditForm.roleIdsList,
          displayName: this.addOrEditForm.displayName,
          extension: this.addOrEditForm.extension,
          // serviceNum: this.addOrEditForm.serviceNum,
          positionCode: this.addOrEditForm.positionCode === 'null' ? null : Number(this.addOrEditForm.positionCode),
          autoAssignCaseEnabled: this.addOrEditForm.autoAssignCaseEnabled,
          userIseffective: this.addOrEditForm.userIseffective,
          // overdueStart: this.addOrEditForm.overdueStart,
          // showContacts: this.addOrEditForm.showContacts,
          id: this.addOrEditForm.id
        }
        fetchUpdateUser(JSON.stringify(data))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.dialogFormVisible = false
              this.$message.success('操作成功')
              this.getTableData()
            } else if (res.errorCode === 99) {
              this.$message.warning('该新坐席号已存在')
            }
            this.editUserConfirmButton = false
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 处理重置密码
      handleResetPassword (userId) {
        fetchResetPassword(userId)
          .then(response => {
            if (response.data.errorCode === 0) {
              this.$message.success('密码已重置为123456')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 处理禁用
      handleDisableUser (user) {
        fetchDisableUser(user.id)
          .then(response => {
            if (response.data.errorCode === 0) {
              this.$message.success('禁用成功')
              user.userIseffective = 0
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 处理启用
      handleEnableUser (user) {
        fetchEnableUser(user.id)
          .then(response => {
            if (response.data.errorCode === 0) {
              this.$message.success('启用成功')
              user.userIseffective = 1
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 确认添加用户
      handleAddUserConfirm () {
        this.submitForm('addOrEditForm')
      },
      // 取消添加用户
      handleAddUserCancel () {
        this.dialogFormVisible = false
        this.resetForm('addOrEditForm')
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.addOrEditForm.rbacUserRoleList = []
            // 组装用户角色对象
            this.addOrEditForm.roleIdList.map(roleId => {
              let userRole = {
                roleId: roleId
              }
              this.addOrEditForm.rbacUserRoleList.push(userRole)
            })
            this.saveOrUpdateUser(this.addOrEditForm)
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      // add Dialog 关闭的回调
      handleDialogClose () {
        this.addOrEditForm = { // 新增用户表单
          roleIdList: [], // 用户角色id数组 页面使用
          id: '',
          groupId: '',
          username: '',
          password: '',
          salt: '',
          displayName: '',
          roleids: '',
          locked: 0,
          extension: '',
          serviceNum: '',
          autoAssignCaseEnabled: 0,
          userIseffective: 1,
          groupName: '',
          rbacUserRoleList: [],
          roleIdsList: [],
          positionCode: null,
          showContacts: 1
        }
        this.resetForm('addOrEditForm')
      },
      // 批量操作
      exportBatchBtn () {
        if (!this.multipleSelection.length) {
          this.$message.warning('没选中数据')
          return false
        }
        this.addOrEditForm.positionCode = this.addOrEditForm.positionCode + ''
        this.isAddDialog = true
        this.dialogFormVisible = true
      },
      // 勾选数据表
      handleSelectionChange (val) {
        this.multipleSelection = val
        this.userIds = []
        this.multipleSelection.forEach((item, index) => {
          this.userIds.push(item.id)
        })
      },
      downloadTemplate () {
        let people = []
        // 用户名 中文名 分组 角色 新坐席号 坐席号 是否自动分配案件 是否显示通讯录 展示通讯录的逾期开始天数 展示通讯录的逾期结束天数 职位
        let head = [['用户名', '中文名', '分组', '角色', '新坐席号', '是否自动分配案件', '职位']]
        let p = people
        p.forEach((item, index) => {
          head.push([p[index].name, p[index].age, p[index].sex, p[index].birthday, p[index].phone, p[index].hobby])
        })
        let csvRows = []
        head.forEach((item, index) => {
          csvRows.push(head[index].join(','))
        })
        let csvString = csvRows.join('\n')
        // BOM的方式解决EXCEL乱码问题
        let BOM = '\uFEFF'
        csvString = BOM + csvString
        let a = document.createElement('a')
        a.href = 'data:attachment/csv,' + encodeURI(csvString)
        a.target = '_blank'
        a.download = '用户管理模板.csv'
        document.body.appendChild(a) // Firefox 中必须这么写，不然不会起效果
        a.click()
        document.body.removeChild(a)
      },
      /* handleCascaderChange (val) {
        this.addOrEditForm.groupId = val[val.length - 1] // 取最后一级分组的id
      } */
      // 催收员 下拉框出现/隐藏时触发
      handleCollectorVisibleChange (visible) {
        if (visible) {
          this.getAllCollectorList().then(() => {
            this.collectorTempList = JSON.parse(JSON.stringify(this.collectorList))
          })
        }
      },
      // 获取催收员列表
      getAllCollectorList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectorList && this.collectorList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionUsersList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectorList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchUsers()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectorList = res.data
                    let _this = this
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionUsersList', JSON.stringify(this.collectorList))
                    // 中文转拼音首字母
                    setTimeout(() => {
                      _this.handleChineseToPhoneticInitial()
                    }, 100)
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 根据输入过滤催收员列表
      filterCollector (query) {
        console.time('filterCollector')
        if (query !== '') {
          this.testinput = query
          this.collectorLoading = true
          this.collectorFilterList = []
          if (this.collectorTempList && this.collectorTempList.length > 0) {
            for (let i = 0, len = this.collectorTempList.length; i < len; i++) {
              if (this.collectorTempList[i].displayName.trim().indexOf(query.trim()) > -1 ||
                (this.collectorTempList[i].phoneticInitial && this.collectorTempList[i].phoneticInitial.indexOf(query.trim().toUpperCase()) > -1)) {
                this.collectorFilterList.push(this.collectorList[i])
              }
            }
          }
          this.collectorLoading = false
        } else {
          this.collectorFilterList = []
        }
        console.timeEnd('filterCollector')
      },
      handleChineseToPhoneticInitial () {
        console.time('handleChineseToPhoneticInitial')
        if (this.collectorList && this.collectorList.length > 0) {
          for (let index in this.collectorList) {
            this.collectorList[index].phoneticInitial = getFirstLetter(this.collectorList[index].displayName).join(',')
          }
          // 存入本地
          window.localStorage.setItem('Collection-CollectionUsersList', JSON.stringify(this.collectorList))
        }
        console.timeEnd('handleChineseToPhoneticInitial')
      }
    }
  }
</script>

<style lang="scss" scoped>
  .form-user-defined {
    .el-form-item {
      margin-right: 20px;
      margin-bottom: 10px;
    }
    .form-btn {
      .el-form-item {
        margin-right: 0;
      }
    }
  }

  .postscript {
    font-size: 12px;
    margin-left: 80px;
    margin-bottom: 10px;
  }
  .file-name {
    color: #2fa4e7;
    cursor: pointer;
    &:hover {
      text-decoration: underline;
      color: #428bca;
    }
  }
  .length-1 {
    width: 200px;
  }
</style>
