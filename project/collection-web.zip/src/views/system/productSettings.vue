<template>
  <div>
    <div class="button">
      <!--<el-button type="primary" size="mini" @click="addDialog(editableTabsValue)">新增</el-button>-->
      <!--<el-button type="primary" size="mini" @click="editDialog(editableTabsValue)">编辑</el-button>-->
    </div>
    <el-tabs v-model="editableTabsValue" type="card" @tab-click="handleTabChange">
      <el-tab-pane
        :key="item.id"
        v-for="item in appCodeList"
        :label="item.name"
        :name="item.id+''"
      >
        <template slot-scope="scope">
          <div v-if="item.id == editableTabsValue">
            <!--阶段、分配、回收规则-->
             <div class="title">
               <span>阶段、分配、回收规则</span><span class="downTitle">(请尽量在月初、月末改动，会影响报表和其他功能)</span>
               <el-button type="primary" size="small" style="float: right" @click="saveRuleButton">保存</el-button>
             </div>
             <el-table border stripe style="width: 100%" :data="totalData.ruleData">
               <el-table-column label="逾期天数" align="center">
                 <template slot-scope="scope">
                    <el-input class="input-width" size="mini" v-model="scope.row.startOverdueDays" @keyup.native="inputLimit($event, scope.row,scope.$index, 1)"></el-input>
                    <span>~</span>
                   <el-input class="input-width" size="mini" v-model="scope.row.endOverdueDays" @keyup.native="inputLimit($event, scope.row, scope.$index, 2)"></el-input>
                 </template>
               </el-table-column>
               <el-table-column label="阶段名称" align="center">
                 <template slot-scope="scope">
                     <el-select size="small" style="width: 70%;" v-model="scope.row.overdueLevelCode">
                       <el-option
                         v-for="(item, index) in phaseNameList"
                         :key="item.id"
                         :label="item.paramName"
                         :value="item.id + ''">
                       </el-option>
                     </el-select>
                 </template>
               </el-table-column>
               <el-table-column label="是否自动分配" align="center" prop="autoAssign" :render-header="renderHeader">
                 <template slot-scope="scope">
                   <el-switch
                     style="display: block"
                     v-model="scope.row.autoAssign"
                     active-color="#13ce66"
                     active-text="是"
                     inactive-text="否">
                   </el-switch>
                 </template>
               </el-table-column>
               <el-table-column label="自动分案金额范围(元)" align="center">
                 <template slot-scope="scope">
                   <el-input class="input-width1" size="mini" v-model="scope.row.minAmount" @keyup.native="inputLimitM($event, scope.row,scope.$index, 1)"></el-input>
                   <span>~</span>
                   <el-input class="input-width1" size="mini" v-model="scope.row.maxAmount" @keyup.native="inputLimitM($event, scope.row,scope.$index, 2)"></el-input>
                 </template>
               </el-table-column>
               <el-table-column label="可分配到的组（以下组别的催收员，有资格被分）" align="center">
                 <template slot-scope="scope">
                   <el-button v-if="scope.row.groupIdList.length === 0" size="mini" type="primary" @click="chooseGroup(scope.row, scope.$index)">{{scope.row.groupText}}</el-button>
                   <el-button v-else size="mini" type="success" @click="chooseGroup(scope.row, scope.$index)">{{scope.row.groupText}}</el-button>
                 </template>
               </el-table-column>
               <el-table-column label="是否自动回收" align="center" prop="autoRecycle" :render-header="renderHeader">
                 <template slot-scope="scope">
                   <el-switch
                     style="display: block"
                     v-model="scope.row.autoRecycle"
                     active-color="#13ce66"
                     active-text="是"
                     inactive-text="否">
                   </el-switch>
                 </template>
               </el-table-column>
               <el-table-column label="操作" align="center">
                 <template slot-scope="scope">
                   <el-button v-if="scope.$index !== totalData.ruleData.length - 1" type="danger" size="mini" @click="deleteRuleData(scope.row.id)">删除</el-button>
                 </template>
               </el-table-column>
             </el-table>
            <!--todo 2019-05-09 隐藏通讯录可见范围-->
            <!--通讯录可见范围-->
            <!--<div class="title margin">-->
              <!--<span>通讯录可见范围</span>-->
              <!--<el-button type="primary" size="small" style="float: right" @click="saveAddressButton">保存</el-button>-->
            <!--</div>-->
            <!--<el-table border stripe style="width: 100%" :data="totalData.phoneData">-->
              <!--<el-table-column label="逾期天数" align="center">-->
                <!--<template slot-scope="scope">-->
                  <!--<el-input class="input-width" size="mini" v-model="scope.row.startOverdueDays" @keyup.native="inputLimit1($event, scope.row,scope.$index, 1)"></el-input>-->
                  <!--<span>~</span>-->
                  <!--<el-input class="input-width" size="mini" v-model="scope.row.endOverdueDays" @keyup.native="inputLimit1($event, scope.row,scope.$index, 2)"></el-input>-->
                <!--</template>-->
              <!--</el-table-column>-->
              <!--<el-table-column label="可见范围" align="center">-->
                <!--<template slot-scope="scope">-->
                  <!--<el-select size="small" v-model="scope.row.displayRule">-->
                    <!--<el-option-->
                      <!--v-for="(item,index) in addressRangeList"-->
                      <!--:key="index"-->
                      <!--:label="item"-->
                      <!--:value="index">-->
                    <!--</el-option>-->
                  <!--</el-select>-->
                <!--</template>-->
              <!--</el-table-column>-->
              <!--<el-table-column label="操作" align="center">-->
                <!--<template slot-scope="scope">-->
                  <!--<el-button v-if="scope.$index !== totalData.phoneData.length - 1" type="danger" size="mini" @click="deletePhoneData(scope.row.id)">删除</el-button>-->
                <!--</template>-->
              <!--</el-table-column>-->
            <!--</el-table>-->
          </div>
        </template>
      </el-tab-pane>
    </el-tabs>
    <!--新增按钮弹窗-->
    <el-dialog :title="dialogTitle" :visible.sync="dialogFormVisible"  @close="handleDialogClose">
      <span class="font">请正确设置产品类型，这会影响后续的业务及报表!</span>
      <el-form>
        <el-form-item label="产品名称">
          <el-input class="length-1" size="small" v-model="addOrEditProductForm.productName"></el-input>
        </el-form-item>
        <el-form-item label="产品类型">
          <el-select v-model="addOrEditProductForm.productType" size="small">
            <el-option
              v-for="(item, index) in productTypeList"
              :key="index"
              :label="item"
              :value="index">
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="productConfirm(addOrEditStatus)">确 定</el-button>
      </div>
    </el-dialog>
    <!--选择分组-->
    <el-dialog title="选择分组" :visible.sync="dialogTableVisible" @close="handleTreeDialogClose">
      <el-input placeholder="输入关键字进行过滤" v-model="filterText"></el-input>
      <el-tree class="filter-tree tree-height" :data="treeData" :props="defaultProps"  :filter-node-method="filterNode" ref="tree" show-checkbox @check-change="handleCheckClick"  check-strictly  node-key="id" :default-expand-all="isExpandAll">
      </el-tree>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="expandAll">展开所有</el-button>
        <el-button size="small" @click="takeAll">收起所有</el-button>
        <el-button size="small" @click="handleTreeDialogCancel">取 消</el-button>
        <el-button  type="primary" size="small" @click="handleTreeDialogConfirm">确 定</el-button>
     </span>
    </el-dialog>
    <!--保存提示信息-->
    <el-dialog title="提示" :visible.sync="dialogVisibleSave" width="30%">
      <span style="color: red">本次修改将会影响该产品的所有案件阶段，请慎重！！</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisibleSave = false">取 消</el-button>
        <el-button type="primary" @click="handleSaveData">确 定</el-button>
      </span>
    </el-dialog>

  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import {
    fetchGroupTree,
    // fetchProductMenu,
    fetchProductInfo,
    fetchContactInfo,
    fetchAddOrEdit,
    fetchOverdueDays,
    fetchSaveCaseRuleBatch,
    fetchSaveContactDisplay
    // fetchDeleteRuleData,
    // fetchDeletePhoneData
  } from '../../api/sys'
  import VueElTooltip from '../../components/VueElTooltip'
  import { TABLE_TITLE_TIP } from './sysConstant'
  export default {
    data () {
      return {
        isExpandAll: false, // 是否默认展开树
        ruleLastData: [{
          'autoAssign': 'no',
          'autoRecycle': 'no',
          'startOverdueDays': null,
          'endOverdueDays': null,
          'minAmount': 0,
          'maxAmount': 0,
          'groupIdList': [],
          'overdueLevelCode': null,
          'groupText': '请分配组'
        }], // 阶段、分配、回收规则最后一组数据
        phoneLastData: [{
          'startOverdueDays': null,
          'endOverdueDays': null,
          'displayRule': 'base'
        }], // 通讯录回收规则最后一组数据
        filterText: '',
        currentIndex: null, // 当前树形控件的索引
        treeData: [],
        defaultProps: {
          children: 'children',
          label: 'name'
        },
        editableTabsValue: '1',
        // appCodeList: [], // 产品数据信息
        tabIndex: 2,
        // 新增弹出框
        dialogFormVisible: false, // 新增以及编辑弹框的显示与隐藏
        productTypeList: { // 产品类型
          'bystage': '分期',
          'single': '单期'
        },
        dialogTitle: '新增产品',
        addOrEditProductForm: { // 产品表单
          productType: 'single', // 产品类型
          productName: '' // 产品名称
        },
        addOrEditStatus: 1, // 1 新增 2 编辑
        totalData: {
          ruleData: [], // 阶段、分配、回收规则数据
          phoneData: [] // 通讯录数据
        },
        phaseNameList: {}, // 自动分配规则
        addressRangeList: {
          'all': '全部',
          'base': '本人+紧急联系人'
        },
        dialogTableVisible: false, // 分组弹框
        dialogVisibleSave: false, // 保存弹框
        saveType: null // 保存类型 1-阶段、分配、回收规则保存 2-阶段、分配、回收规则保存
      }
    },
    computed: {
      ...mapGetters([
        'appCodeList', // 产品类型
        'appType' // 产品类型常量
      ])
    },
    watch: {
      filterText (val) {
        this.$refs.tree.filter(val)
      }
    },
    methods: {
      // 删除阶段、分配回收规则数据
      deleteRuleData (id) {
        this.totalData.ruleData.forEach((item, index) => {
          if (item.id === id) {
            this.totalData.ruleData.splice(index, 1)
          }
        })
        //        fetchDeleteRuleData(id)
        //          .then(response => {
        //            let res = response.data
        //            if (res.errorCode === 0) {
        //              this.$message.success('删除成功')
        //              // this.getProductInfo(this.editableTabsValue) // 页面加载是获取当前Tab阶段、分配、回收规则数据
        //            }
        //          })
        //          .catch(error => {
        //            console.log(error)
        //          })
      },
      // 删除通讯录信息
      deletePhoneData (id) {
        this.totalData.phoneData.forEach((item, index) => {
          if (item.id === id) {
            this.totalData.phoneData.splice(index, 1)
          }
        })
        //        fetchDeletePhoneData(id)
        //          .then(response => {
        //            let res = response.data
        //            if (res.errorCode === 0) {
        //              this.$message.success('删除成功')
        //              // this.getContactInfo(this.editableTabsValue) // 页面加载是获取联系人数据
        //            }
        //          })
        //          .catch(error => {
        //            console.log(error)
        //          })
      },
      // 关闭分组dialog弹框
      handleTreeDialogClose () {
        this.dialogTableVisible = false
        // this.$refs.tree.setCheckedKeys([])
        // this.totalData.ruleData[this.currentIndex].groupText = '请分配组'
      },
      // 选择分组取消
      handleTreeDialogCancel () {
        this.dialogTableVisible = false
        // this.$refs.tree.setCheckedKeys([])
        // this.totalData.ruleData[this.currentIndex].groupText = '请分配组'
      },
      // 选择分组确认
      handleTreeDialogConfirm () {
        this.dialogTableVisible = false
        this.totalData.ruleData.forEach((item, index) => {
          item.groupText = '请分配组'
          if (item.groupIdList.length > 0) {
            item.groupText = '已分配组'
          }
        })
      },
      // 展开所有菜单树
      expandAll () {
        this.isExpandAll = true
        this.$refs.tree.store._getAllNodes().forEach((item, index) => {
          this.$refs.tree.store._getAllNodes()[index].expanded = this.isExpandAll
        })
      },
      // 收起所有菜单树
      takeAll () {
        this.isExpandAll = false
        this.$refs.tree.store._getAllNodes().forEach((item, index) => {
          this.$refs.tree.store._getAllNodes()[index].expanded = this.isExpandAll
        })
      },
      // 解决tab标签的改变问题
      handleTabChange () {
        this.getOverdueDays(this.editableTabsValue) // 获取逾期阶段数据
        this.getProductInfo(this.editableTabsValue) // 获取规则数据
        this.getContactInfo(this.editableTabsValue) // 获取通讯录数据
      },
      // 树节点点击事件
      handleCheckClick () {
        let arr = []
        let dataRecieve = this.$refs.tree.getCheckedNodes() // 记录所选数据的数组
        dataRecieve.forEach((item, index) => {
          arr.push(item.id)
        })
        this.totalData.ruleData[this.currentIndex].groupIdList = arr
      },
      filterNode (value, data) {
        if (!value) return true
        return data.name.indexOf(value) !== -1
      },
      // 选择分组
      chooseGroup (value, index) {
        // this.defaultChoose = value.groupIdList
        this.currentIndex = index // 记录当前树节点的索引
        this.dialogTableVisible = true
        this.$nextTick(() => {
          this.$refs.tree.setCheckedKeys(value.groupIdList)
        })
      },
      // 通讯录保存按钮
      saveAddressButton () {
        this.overDueDays(this.totalData.phoneData, 2)
      },
      // 阶段、分配、回收规则保存按钮
      saveRuleButton () {
        this.phaseName(this.totalData.ruleData)
      },
      // 阶段名称验证
      phaseName (data) {
        let flagF = true
        data.forEach((item, index) => {
          if (index < data.length - 1) {
            if (item.overdueLevelCode === '' || item.overdueLevelCode === null) {
              this.$message.error('请选择阶段名称')
              flagF = false
            }
          }
        })
        if (flagF) {
          this.overDueMoney(this.totalData.ruleData)
        }
      },
      // 分期金额验证
      overDueMoney (data) {
        let flagTW = true
        data.forEach((item, index) => {
          if (isNaN(item.minAmount)) {
            this.$message.error('分期金额的起始金额存在非数值')
            flagTW = false
          }
          if (index < data.length - 1) {
            if (isNaN(item.maxAmount)) {
              this.$message.error('分期金额的结束金额存在非数值')
              flagTW = false
            }
            if (parseInt(item.maxAmount) <= parseInt(item.minAmount)) {
              this.$message.error('分配金额后一项必须大于前一项')
              flagTW = false
            }
            if (item.minAmount === '' || item.minAmount === null) {
              this.$message.error('请填写分配金额初始金额')
              flagTW = false
            }
          }
        })
        if (flagTW) {
          this.overDueDays(this.totalData.ruleData, 1)
        }
      },
      // 逾期天数输入验证规则
      overDueDays (data, type) {
        if (data[data.length - 2].endOverdueDays !== '' && data[data.length - 2].endOverdueDays !== null) {
          this.$message.error('逾期天数必须以空结尾表示正无穷')
          return false
        }
        // todo 逾期天数都从1开始
        if (data[0].startOverdueDays.toString() !== '1') {
          this.$message.error('逾期天数必须以1开始')
          return false
        }
        // 车贷王 6 、老车贷王 10 逾期天数从0开始
        // if (this.editableTabsValue.toString() !== '6' && this.editableTabsValue.toString() !== '10' && data[0].startOverdueDays.toString() !== '1') {
        //   this.$message.error('逾期天数必须以1开始')
        //   return false
        // }
        // if ((this.editableTabsValue.toString() === '6' || this.editableTabsValue.toString() === '10') && data[0].startOverdueDays.toString() !== '0') {
        //   this.$message.error('逾期天数必须以0开始')
        //   return false
        // }
        let flagT = true
        data.forEach((item, index) => {
          if (isNaN(item.startOverdueDays)) {
            this.$message.error('逾期天数的起始天数存在非数值')
            flagT = false
          }
          if (index < data.length - 1) {
            //            if (index <= data.length - 3) {
            //              if (parseInt(item.endOverdueDays) < parseInt(item.startOverdueDays)) {
            //                this.$message.error('逾期天数的后一天必须大于前一天')
            //                flagT = false
            //              }
            //            }
            if (isNaN(item.endOverdueDays)) {
              this.$message.error('逾期天数的结束天数存在非数值')
              flagT = false
            }
            if (index !== 0) {
              if (parseInt(data[index].startOverdueDays) !== parseInt(data[index - 1].endOverdueDays) + 1) {
                this.$message.error('逾期天数一列拼起来是 [1,∞)，没有遗漏且没有交叉。')
                flagT = false
              }
            }
          }
        })
        if (flagT) {
          this.dialogVisibleSave = true
          if (type === 1) {
            this.saveType = 1
          } else {
            this.saveType = 2
          }
        }
      },
      // 确认保存阶段、分配、回收规则数据
      handleSaveData () {
        this.dialogVisibleSave = false
        if (this.saveType === 1) {
          this.getRuleSaveOrUpdateList()
        } else {
          this.getPhoneSaveOrUpdateList()
        }
      },
      // 阶段、分配、回收规则保存接口
      getRuleSaveOrUpdateList () {
        this.totalData.ruleData[this.totalData.ruleData.length - 2].endOverdueDays = null
        this.totalData.ruleData.splice(this.totalData.ruleData.length - 1, 1)
        this.totalData.ruleData.forEach((item, index) => {
          if (item.autoAssign) { item.autoAssign = 'yes' } else { item.autoAssign = 'no' }
          if (item.autoRecycle) { item.autoRecycle = 'yes' } else { item.autoRecycle = 'no' }
          item.maxAmount = item.maxAmount === '' || item.maxAmount === null ? null : item.maxAmount
          if (!item.productId) { item.productId = this.editableTabsValue }
        })
        fetchSaveCaseRuleBatch(JSON.stringify(this.totalData.ruleData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success('保存阶段、分配、回收规则成功')
            } else if (res.errorCode === 107) {
              this.$message.warning('存在重复的阶段名，请重新选择')
            }
            this.getProductInfo(this.editableTabsValue)
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 通讯录保存按钮
      getPhoneSaveOrUpdateList () {
        this.totalData.phoneData[this.totalData.phoneData.length - 2].endOverdueDays = null
        this.totalData.phoneData.splice(this.totalData.phoneData.length - 1, 1)
        this.totalData.phoneData.forEach((item, index) => {
          if (item.autoAssign) { item.autoAssign = 'yes' } else { item.autoAssign = 'no' }
          if (item.autoRecycle) { item.autoRecycle = 'yes' } else { item.autoRecycle = 'no' }
          if (!item.productId) { item.productId = this.editableTabsValue }
        })
        fetchSaveContactDisplay(JSON.stringify(this.totalData.phoneData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success('保存通讯录成功')
              this.getContactInfo(this.editableTabsValue)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 逾期天数输入框的输入限制
      inputLimit (event, value, index, type) {
        this.limit(event, value, index, type, this.totalData.ruleData)
      },
      inputLimit1 (event, value, index, type) {
        this.limit(event, value, index, type, this.totalData.phoneData)
      },
      // 输入框限制
      limit (event, value, index, type, data) {
        if (index + 1 === data.length) {
          data.push({
            'id': index + 1,
            'autoAssign': 'no',
            'autoRecycle': 'no',
            'startOverdueDays': null,
            'endOverdueDays': null,
            'minAmount': 0,
            'maxAmount': 0,
            'groupIdList': [],
            'displayRule': 'base',
            'overdueLevelCode': null,
            'groupText': '请分配组'
          })
        }
        if (type === 1) {
          data[index].startOverdueDays = data[index].startOverdueDays + ''
          data[index].startOverdueDays = data[index].startOverdueDays === null ? null : data[index].startOverdueDays.replace(/\D/g, '')
        } else {
          data[index].endOverdueDays = data[index].endOverdueDays + ''
          data[index].endOverdueDays = data[index].endOverdueDays === null ? null : data[index].endOverdueDays.replace(/\D/g, '')
        }
        //        if ((data[data.length - 2].startOverdueDays === '' || data[data.length - 2].startOverdueDays === null) && (data[data.length - 2].endOverdueDays === '' || data[data.length - 2].endOverdueDays === null)) {
        //          data.pop()
        //        }
      },
      // 分配金额范围的输入限制
      inputLimitM (event, value, index, type) {
        if (type === 1) {
          this.totalData.ruleData[index].minAmount = this.totalData.ruleData[index].minAmount + ''
          this.totalData.ruleData[index].minAmount = this.totalData.ruleData[index].minAmount.replace(/\D/g, '')
        } else {
          this.totalData.ruleData[index].maxAmount = this.totalData.ruleData[index].maxAmount + ''
          this.totalData.ruleData[index].maxAmount = this.totalData.ruleData[index].maxAmount.replace(/\D/g, '')
        }
      },
      // 添加项目确认按钮
      productConfirm (value) {
        if (this.addOrEditProductForm.productName.length > 10) {
          this.$message.error('产品名称必须在10个字以内')
          return false
        }
        if (this.addOrEditProductForm.productName.length === 0) {
          this.$message.error('请输入产品名称或取消')
          return false
        }
        if (value === 1) {
          this.addProduct()
        } else {
          this.editProduct()
        }
        this.dialogFormVisible = false
      },
      // 新增项目
      addProduct () {
        let param = {
          name: this.addOrEditProductForm.productName,
          type: this.addOrEditProductForm.productType
        }
        fetchAddOrEdit(JSON.stringify(param))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success('新增成功')
              this.getProductMenu() // 新增成功重新获取
            }
          })
          .catch(error => {
            console.log(error)
          })
        // this.dialogFormVisible = false
      },
      // 编辑项目
      editProduct () {
        let param = {
          name: this.addOrEditProductForm.productName,
          type: this.addOrEditProductForm.productType,
          id: this.editableTabsValue
        }
        fetchAddOrEdit(JSON.stringify(param))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success('修改成功')
              this.getProductMenu() // 修改成功重新获取
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 新增按钮弹框
      addDialog (targetName) {
        this.dialogFormVisible = true
        this.dialogTitle = '新增产品'
        this.addOrEditStatus = 1
      },
      // 编辑按钮弹框
      editDialog (targetName) {
        this.dialogFormVisible = true
        this.dialogTitle = '编辑产品'
        this.addOrEditStatus = 2
        this.appCodeList.forEach((item, index) => {
          if (item.id + '' === targetName) {
            this.addOrEditProductForm.productName = item.name
            this.addOrEditProductForm.productType = item.type
          }
        })
      },
      // 关闭dialog的回调
      handleDialogClose () {
        this.addOrEditProductForm = {
          productType: 'single', // 产品类型
          productName: '' // 产品名称
        }
      },
      // 获取自动分组数据
      getGroup () {
        fetchGroupTree()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.treeData = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取产品表头数据
      //      getProductMenu () {
      //        fetchProductMenu()
      //          .then(response => {
      //            let res = response.data
      //            if (res.errorCode === 0 && res.data) {
      //              this.appCodeList = res.data
      //            }
      //          })
      //          .catch(error => {
      //            console.log(error)
      //          })
      //      },
      getProductMenu () {
        if (!this.appCodeList.length) {
          this.$store.dispatch('GetAppCodeList')
            .then(res => {
            })
            .catch(err => {
              console.log(err)
            })
        }
      },
      // 获取阶段、分配、规则信息
      getProductInfo (id) {
        this.ruleLastData.forEach((item, index) => {
          item.startOverdueDays = null
          item.endOverdueDays = null
        })
        fetchProductInfo(id)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data.content) {
              res.data.content.forEach((item, index) => {
                item.autoAssign = (item.autoAssign === 'yes')
                item.autoRecycle = (item.autoRecycle === 'yes')
                item.groupText = '请分配组'
                if (item.groupIdList.length > 0) {
                  item.groupText = '已分配组'
                }
              })
              this.totalData.ruleData = res.data.content.concat(this.ruleLastData)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取联系人信息
      getContactInfo (id) {
        this.phoneLastData.forEach((item, index) => {
          item.startOverdueDays = null
          item.endOverdueDays = null
        })
        fetchContactInfo(id)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              res.data = res.data === null ? [] : res.data
              this.totalData.phoneData = res.data.concat(this.phoneLastData)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取逾期阶段数据
      getOverdueDays (id) {
        fetchOverdueDays(id)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.phaseNameList = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 表头
      renderHeader (createElement, {column}) {
        return createElement(VueElTooltip, {
          props: {
            label: column.label,
            content: TABLE_TITLE_TIP[column.property]
          }
        })
      }
    },
    mounted () {
      this.getOverdueDays(this.editableTabsValue) // 获取逾期阶段数据
      this.getGroup()
      this.getProductMenu() // 获取产品菜单
      this.getProductInfo(this.editableTabsValue) // 页面加载是获取当前Tab阶段、分配、回收规则数据
      this.getContactInfo(this.editableTabsValue) // 页面加载是获取联系人数据
    }
  }
</script>

<style lang="scss" scoped>
  .button{
    position: absolute;
    z-index:2000;
    right:20px;
  }
  .length-1{
    width:200px;
  }
  .font{
    color: red;
  }
  .title{
    font-size: 18px;
    font-weight: bolder;
    margin-bottom: 10px;
  }
   .downTitle{
     font-size: 12px;
     font-weight: normal;
   }
  .input-width{
    width: 70px;
  }
  .input-width1{
    width: 70px;
  }
  .margin{
    margin-top:10px;
  }
  .tree-height {
    max-height: 510px;
    overflow: auto;
  }
</style>
