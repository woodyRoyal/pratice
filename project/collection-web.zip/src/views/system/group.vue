<!--分组管理-->
<template>
  <imp-panel>
    <h3 class="box-title" slot="header" style="width: 100%;">
      <el-button type="primary" icon="plus" size="small" @click="addNewGroup">新增</el-button>
      <el-button type="danger" icon="delete" size="small" @click="batchDelete">删除</el-button>
    </h3>
    <el-row slot="body" :gutter="20">
      <el-col :span="8">
        <el-tree class="el-card tree-height" v-if="groupTree" show-checkbox highlight-current default-expand-all
                 ref="groupTree" check-strictly :expand-on-click-node="false" :data="groupTree"
                 @node-click="handleNodeClick" node-key="id" :props="treeProps">
        </el-tree>
      </el-col>
      <el-col :span="16">
        <el-card class="box-card">
          <div class="card-title" v-if="isAddForm">新增分组</div>
          <div class="text item">
            <el-form :model="form" ref="form" label-width="100px">
              <el-form-item label="父级">
                <!--下拉数选择器-->
                <el-select-tree v-model="form.parentid" :treeData="groupTree" :propNames="treeProps" clearable
                                placeholder="请选择父级">
                </el-select-tree>
              </el-form-item>
              <el-form-item label="名称">
                <el-input v-model="form.name" auto-complete="off"></el-input>
              </el-form-item>
              <!--<el-form-item label="分组码">-->
                <!--<el-input v-model="form.code" auto-complete="off"></el-input>-->
              <!--</el-form-item>-->
              <!--<el-form-item label="是否启用">-->
                <!--<el-radio class="radio" v-model="form.available" label="1">是</el-radio>-->
                <!--<el-radio class="radio" v-model="form.available" label="0">否</el-radio>-->
              <!--</el-form-item>-->
              <el-form-item label="所属机构">
                <el-select v-model="form.mechanismId" auto-complete="off">
                  <el-option label="空" :value = null></el-option>
                  <el-option v-for="(item, index) in mechanismList"
                             :key="item.id"
                             :label="item.paramName"
                             :value="item.paramCode">
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="所属阶段">
                <el-select v-model="form.overdueLevel" auto-complete="off">
                  <el-option v-for="(item, index) in stage"
                             :key="index"
                             :label="item"
                             :value="index === '-1' ? null : index ">
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="">
                <el-button type="primary" @click="onSubmit" v-text="form.id?'修改':'新增'"></el-button>
                <el-button type="danger" @click="deleteSelected" v-show="form.id && form.id!=null">删除
                </el-button>
              </el-form-item>
            </el-form>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </imp-panel>

</template>
<script type="text/babel">
  import panel from '../../components/SelectTree/panel.vue'
  import SelectTree from '../../components/SelectTree/selectTree.vue'
  import treeter from '../../components/SelectTree/treeter'
  import merge from 'element-ui/src/utils/merge'
  import {
    fetchGroupTree, fetchCreateGroup, fetchDeleteGroup, fetchUpdateGroup, fetchMechanismList
  } from '../../api/sys'

  export default {
    mixins: [treeter],
    components: {
      'imp-panel': panel,
      'el-select-tree': SelectTree
    },
    data () {
      return {
        treeProps: { // 树选择器配置选项 字段映射
          children: 'children',
          label: 'name',
          id: 'id'
        },
        groupTree: [], // 分组树
        mechanismList: [], // 机构列表
        // 表单数据
        form: {
          id: null,
          parentid: null,
          name: '',
          // code: '',
          available: '1',
          mechanismId: null,
          overdueLevel: null
        },
        isAddForm: false,
        stage: {
          '-1': '空',
          '1': 'M1',
          '2': 'M2',
          '3': 'M3',
          '4': 'M4'
        }
      }
    },
    methods: {
      // 新增分组 置空form
      addNewGroup () {
        this.form = {
          id: null,
          parentid: null,
          name: '',
          // code: '',
          available: '1',
          mechanismId: null,
          overdueLevel: null
        }
        this.isAddForm = true
      },
      // 删除当前选择的分组
      deleteSelected () {
        // id转为数组
        let ids = []
        ids.push(this.form.id)
        this.deleteGroups(ids)
      },
      // 批量删除
      batchDelete () {
        let checkKeys = this.$refs.groupTree.getCheckedKeys()
        if (checkKeys == null || checkKeys.length === 0) {
          this.$message.warning('请选择要删除的分组')
          return
        }
        this.$confirm('确定要删除所选分组吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.deleteGroups(checkKeys)
        }).catch(() => {
        })
      },
      // 删除分组
      deleteGroups (idList) {
        fetchDeleteGroup(JSON.stringify(idList))
          .then(res => {
            if (res.data.errorCode === 0) {
              this.$message.success('操作成功')
              this.addNewGroup()
              this.getGroupTree()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 树节点点击事件
      handleNodeClick (data) {
        this.isAddForm = false
        data.available = '' + data.available
        data.overdueLevel = data.overdueLevel === null ? null : '' + data.overdueLevel
        data.mechanismId = data.mechanismId === null ? null : '' + data.mechanismId
        this.form = merge({}, data)
      },
      // 提交表单
      onSubmit () {
        //        fetchCreateGroup(JSON.stringify(this.form))
        //          .then(res => {
        //            if (res.data.errorCode === 0 && res.data.data) {
        //              this.$message.success('操作成功')
        //              if (this.form.id == null) { // 新增
        //                this.form.id = res.data.data.id
        //                this.appendTreeNode(this.groupTree, res.data.data)
        //                this.isAddForm = false
        //              } else { // 修改
        //                this.updateTreeNode(this.groupTree, res.data.data)
        //              }
        //              this.getGroupTree()
        //            }
        //          })
        //          .catch(e => {
        //            console.log(e)
        //          })

        if (this.form.id == null) { // 新增
          if (this.form.parentid === null) {
            this.$message.warning('请选择父级')
            return false
          }
          if (this.form.name === '') {
            this.$message.warning('请输入名称')
            return false
          }
          fetchCreateGroup(JSON.stringify(this.form))
            .then(res => {
              if (res.data.errorCode === 0 && res.data.data) {
                this.$message.success('新增操作成功')
                this.form.id = res.data.data.id
                this.appendTreeNode(this.groupTree, res.data.data)
                this.isAddForm = false
                this.getGroupTree()
              }
            })
            .catch(error => {
              console.log(error)
            })
        } else { // 修改
          if (this.form.parentid === null) {
            this.$message.warning('请选择父级')
            return false
          }
          if (this.form.name === '') {
            this.$message.warning('请输入名称')
            return false
          }
          // children子组不用传过去
          this.form.children = null
          fetchUpdateGroup(JSON.stringify(this.form))
            .then(res => {
              if (res.data.errorCode === 0 && res.data.data) {
                this.$message.success('修改操作成功')
                this.updateTreeNode(this.groupTree, res.data.data)
                this.getGroupTree()
              }
            })
            .catch(error => {
              console.log(error)
            })
        }
      },
      // 获取分组树
      getGroupTree () {
        fetchGroupTree()
          .then(res => {
            if (res.data.errorCode === 0 && res.data.data) {
              this.groupTree = res.data.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      getMechanism () {
        fetchMechanismList()
          .then(res => {
            if (res.data.errorCode === 0 && res.data.data) {
              this.mechanismList = res.data.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      }
    },
    created () {
      this.getGroupTree()
      this.getMechanism()
    }
  }
</script>

<style lang="scss" scoped>
  .el-card {
    border-radius: 0;
  }

  .tree-height {
    max-height: 510px;
    overflow: auto;
  }

  /*文字淡入效果*/
  .card-title {
    margin-bottom: 10px;
    opacity: 0; /*实先规定文字的状态是不显示的*/
    animation: fade-in 4s ease 0s 1;
    /*规定动画的最后状态为结束状态*/
    animation-fill-mode: forwards;
  }

  /*自定义一个透明度从0到1的动画，它的名称是fade-in*/
  @keyframes fade-in {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
</style>
