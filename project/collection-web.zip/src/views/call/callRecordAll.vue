<!--通话记录-->
<template>
  <div class="call">
    <el-form class="filter-form" :inline="true">
      <!--通话时间-->
      <el-form-item class="margin">
        <span class="demonstration width">通话时间: </span>
        <el-date-picker
          class="length-1"
          v-model="date"
          type="date"
          size="small"
          :editable="false"
          :clearable="false"
          :picker-options="pickerOptions1"
          placeholder="选择日期">
        </el-date-picker>
        <el-time-picker
          class="length-2"
          is-range
          v-model="time"
          size="small"
          :editable="false"
          :clearable="false"
          range-separator="-"
          start-placeholder="开始时间"
          end-placeholder="结束时间"
          placeholder="选择时间范围">
        </el-time-picker>
      </el-form-item>
        <!--催收组-->
      <el-form-item class="margin">
        <vue-el-select size="small" class="input-width" v-model="filterForm.groups" reserve-keyword multiple filterable placeholder="请选择催收组" @visible-change="handleGroupVisibleChange">
          <el-option  v-for="item in collectionGroupFilterList"
                      :key="item.id"
                      :label="item.name"
                      :value="item.id"
          >
          </el-option>
        </vue-el-select>
      </el-form-item>
        <!--催收员-->
      <el-form-item class="margin">
        <vue-el-select size="small" class="input-width" v-model="collecotorIdsList" reserve-keyword multiple filterable remote placeholder="输入并选择催收员" @visible-change="handleCollectorVisibleChange" :remote-method="filterCollector">
          <el-option  v-for="item in collectorFilterList"
                      :key="item.id"
                      :label="item.displayName"
                      :value="item.id" >
          </el-option>
        </vue-el-select>
      </el-form-item>

      <!--客户姓名、联系人电话、联系人电话-->
      <el-form-item class="demo-input-size margin">
        <span class="width center">客户姓名：</span>
        <el-input class="input-width-1" size="small"  v-model="filterForm.caseName"></el-input>
      </el-form-item>
      <el-form-item class="margin">
        <span class="width center">联系人电话：</span>
        <el-tooltip class="item" effect="dark" content="请输入数字" placement="top-start">
          <el-input class="input-width-1" size="small" v-model="filterForm.callPhone" @keyup.native="numberLimit({'Content':filterForm.callPhone,'Tag':'num'})" @blur="dotLimit({'Content':filterForm.callPhone,'Tag':'num'})"></el-input>
        </el-tooltip>
      </el-form-item>
      <el-form-item class="margin">
        <span class="width center">联系人姓名：</span>
        <el-input class="input-width-1" size="small" v-model="filterForm.callName"></el-input>
      </el-form-item>

      <!--呼叫、接通、挂断、通话时长-->
      <el-form-item class="margin">
        <span class="font">通话时长: </span>
        <el-tooltip class="item" effect="dark" content="请输入数字" placement="top-start">
          <el-input class="input-width-2" size="small" v-model="filterForm.minCallTime" @keyup.native="numberLimit({'Content':filterForm.minCallTime,'Tag':'start'})" @blur="dotLimit({'Content':filterForm.minCallTime,'Tag':'start'})">
          </el-input>
        </el-tooltip>
        <span class="font">至</span>
        <el-tooltip class="item" effect="dark" content="请输入数字" placement="top-start">
          <el-input class="input-width-2" size="small" v-model="filterForm.maxCallTime" @keyup.native="numberLimit({'Content':filterForm.maxCallTime,'Tag':'end'})" @blur="dotLimit({'Content':filterForm.maxCallTime,'Tag':'end'})">
          </el-input>
        </el-tooltip>
        <span class="font">(秒)</span>
      </el-form-item>
      <!--查询-->
      <el-form-item class="margin">
        <el-button type="success" size="small" @click="searchBtn" :loading="searchLoading">查询</el-button>
      </el-form-item>
    </el-form>
    <hr/>
    <!--表格-->
    <el-table style="width: 100%" :data="tableData" stripe border v-loading="listLoading" :max-height="tableHeight">
      <el-table-column type="selection" align="center"></el-table-column>
      <el-table-column label="通话时间" align="center" prop="createAt" width="78"></el-table-column>
      <el-table-column label="主叫" align="center" prop="collectorName" min-width="50"></el-table-column>
      <el-table-column label="案件" align="center" min-width="50">
        <template slot-scope="scope">
          <span class="to-case-detail" @click="toCaseDetail(scope.row.caseId)">{{ scope.row.caseName }}</span>
        </template>
      </el-table-column>
      <el-table-column label="被叫" align="center" prop="calledName" min-width="70"></el-table-column>
      <el-table-column label="UUID" align="center" min-width="70">
        <template slot-scope="scope">
          <el-tooltip class="item" effect="dark" :content="scope.row.callCenterCallId" placement="left">
            <span style="width: 70px;overflow: hidden; text-overflow:ellipsis; white-space: nowrap;">{{ scope.row.callCenterCallId }}</span>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column label="振铃时长" align="center" prop="ringingTime" min-width="70"></el-table-column>
      <el-table-column label="IVR时长" align="center" prop="ivrTime" min-width="70"></el-table-column>
      <el-table-column label="通话时长" align="center" prop="callTime" min-width="70"></el-table-column>
      <el-table-column label="呼叫类型" align="center" prop="callType" min-width="60"></el-table-column>
      <el-table-column label="接通状态" align="center" prop="statusStr" min-width="60"></el-table-column>
      <el-table-column label="挂断原因" align="center" prop="hangupReasonStr" min-width="60"></el-table-column>
      <el-table-column label="项目" align="center" prop="callProjectName" min-width="60"></el-table-column>
      <el-table-column label="录音" align="center" prop="recordPath" min-width="60">
        <template slot-scope="scope">
          <el-button v-if="scope.row.recordPath && scope.row.isPlay === 0" type="primary" size="mini" @click="playBtn(scope.row)">播放</el-button>
          <el-button v-if="scope.row.recordPath && scope.row.isPlay === 1" type="danger" size="mini" @click="pauseBtn(scope.row)">停止</el-button>
          <el-button v-if="scope.row.recordPath && scope.row.isPlay === 2" type="success" size="mini" @click="continueBtn(scope.row)">继续
          </el-button>
        </template>
      </el-table-column>
      <el-table-column label="电话标记" align="center" prop="resultDescStr" min-width="60"></el-table-column>
      <el-table-column label="备注" align="center" prop="memo" min-width="60"></el-table-column>
    </el-table>
    <!-- 分页开始-->
    <div class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

    <!--弹框提示信息-->
    <el-dialog title="提示" :visible.sync="dialogVisible" width="30%">
      <span>只能查询一天之内的通话记录</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
     </span>
    </el-dialog>

    <!-- 播放 -->
    <el-row class="footer-player" v-show="isShowPlayer">
      <vue-aplayer autoplay mutex theme="#13CE66" mode="circulation"
                   @playing="handleAudioPlaying"
                   @play="handleAudioPlay"
                   @pause="handleAudioPause"
                   @error="handleAudioError"
                   :playOrPause="audioPlayer.playOrPause"
                   :music="music">
      </vue-aplayer>
    </el-row>

  </div>
</template>

<script>
  import {fetchGetCallRecordList} from '../../api/call'
  import { parseTime, formatMillisecondTo } from '../../utils/formatDate'
  import VueElSelect from '../../components/VueElSelect'
  import VueAplayer from '../../components/AudioPlayer/index.vue'
  import {
    fetchAllCollectorVOList,
    findAllGroupVOList
  } from '../../api/common'
  import getFirstLetter from 'utils/chineseToPhoneticInitial'
  import ElForm from '../../../node_modules/element-ui/packages/form/src/form.vue'
  import ElFormItem from '../../../node_modules/element-ui/packages/form/src/form-item.vue'

  export default {
    components: {
      ElFormItem,
      ElForm,
      VueElSelect,
      VueAplayer
    },
    data: function () {
      return {
        searchLoading: false, // 搜索按钮
        date: new Date(), // 日期
        time: [new Date().getTime() - 3600 * 1000, new Date().getTime()], // 时间
        pickerOptions1: {
          disabledDate (time) {
            return time.getTime() > Date.now() || time.getTime() < new Date('2019-03-20')
          }
        },
        filterForm: {
          startDate: null, // 开始时间
          endDate: null, // 结束时间
          callName: null, // 联系人姓名
          callPhone: null, // 联系人电话
          caseName: null, // 客户姓名
          maxCallTime: null, // 最大通话时长
          minCallTime: null, // 最小通话时长
          collecotorIds: null,
          // managerIdList: [], // 催收经理
          // mechanIdList: [], // 催收机构
          groups: [] // 催收组
        },
        collecotorIdsList: [], // 催收员
        // 催收员列表
        collectorList: [],
        collectorTempList: [], // 联动过滤后下拉列表
        collectorFilterList: [], // 输入过滤后下拉列表
        collectorLoading: false,

        // 催收组列表
        collectionGroupList: [],
        collectionGroupFilterList: [], // 过滤后下拉列表
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [50, 100, 200],
        // 表格高度
        tableHeight: 600,
        listLoading: false,
        tableData: [],
        dialogVisible: false, // 弹框控制
        audioPlayer: {
          currentTime: 0,
          playOrPause: false
        },
        music: {
          title: 'audio', // 必填字段
          author: 'dev', // 必填字段
          url: 'http://devtest.qiniudn.com/Preparation.mp3' // 必填字段
        },
        id: null, // 播放索引（案件ID）
        recordStatus: false, // 播放状态
        errorTypeList: [], // 错误类型
        isShowPlayer: false, // 是否显示播放器
        aplayerObj: null // 播放器对象
      }
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          let h = document.documentElement.clientHeight
          if (formHeight >= 90) {
            this.tableHeight = h - 290
          } else if (formHeight >= 45) {
            this.tableHeight = h - 100
          }
        })
      },
      // 催收组 下拉框出现/隐藏时触发
      handleGroupVisibleChange (visible) {
        if (visible) {
          this.getAllGroupList().then(() => {
            this.collectionGroupFilterList = JSON.parse(JSON.stringify(this.collectionGroupList))
            // 然后过滤数据 mechanismId
            // if (this.filterForm.mechanIdList.length === 0) {
            //  this.collectionGroupFilterList = JSON.parse(JSON.stringify(this.collectionGroupList))
            // } else {
            //  this.collectionGroupFilterList = this.collectionGroupList.filter(item => {
            //     return this.filterForm.mechanIdList.join(',').indexOf(item.mechanismId) >= 0
            // })
            //  }
          })
        }
      },
      // 催收员 下拉框出现/隐藏时触发
      handleCollectorVisibleChange (visible) {
        if (visible) {
          this.getAllCollectorList().then(() => {
            // 然后过滤数据 mechanismId groupId
            if (this.filterForm.groups.length === 0) {
              this.collectorTempList = JSON.parse(JSON.stringify(this.collectorList))
            } else {
              //  this.collectorTempList = this.collectorList.filter(item => {
              // 机构、组下拉框
              //  if (this.filterForm.groups.length > 0) { // 组选了 返回组下面的
              //   return this.filterForm.groups.join(',').indexOf(item.groupId) >= 0
              //  } else if (this.filterForm.mechanIdList.length > 0) { // 机构选了、组没选 返回机构下面的
              //   return this.filterForm.mechanIdList.join(',').indexOf(item.mechanismId) >= 0
              //  } else {
              //  return false
              //  }
              //   })
              this.collectorTempList = this.collectorList.filter(item => {
                // 机构、组下拉框
                if (this.filterForm.groups.length > 0) { // 组选了 返回组下面的
                  return this.filterForm.groups.join(',').indexOf(item.groupId) >= 0
                } else {
                  return false
                }
              })
            }
          })
        }
      },
      // 点击搜索按钮，获取表格数据
      searchBtn () {
        this.getTableData()
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        this.searchLoading = true
        this.listLoading = true
        this.filterForm.startDate = parseTime(this.date, 'YYYY-MM-DD') + ' ' + parseTime(this.time[0], 'HH:mm:ss')
        this.filterForm.endDate = parseTime(this.date, 'YYYY-MM-DD') + ' ' + parseTime(this.time[1], 'HH:mm:ss')
        this.filterForm.collecotorIds = (this.collecotorIdsList.length === 0 ? null : this.collecotorIdsList.join(','))
        fetchGetCallRecordList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            if (response.data.errorCode === 0) {
              if (response.data.data) {
                response.data.data.content.map(item => {
                  // 增加字段isplay  false暂停状态/true播放状态
                  if (item.id === this.id) {
                    if (this.recordStatus) {
                      item.isPlay = 1
                    } else {
                      item.isPlay = 2
                    }
                  } else {
                    item.isPlay = 0
                  }
                  item.callTime = formatMillisecondTo(item.callTime)
                  item.ivrTime = formatMillisecondTo(item.ivrTime)
                  item.ringingTime = formatMillisecondTo(item.ringingTime)
                })
                let data = response.data.data
                this.pagData.pageSize = data.pageSize
                this.pagData.pageNo = data.pageNo
                this.totalRecord = data.totalRecord
                this.tableData = data.content
              } else {
                this.pagData.pageSize = 100
                this.pagData.pageNo = 1
                this.totalRecord = 0
                this.tableData = []
              }
            }
            this.listLoading = false
            this.searchLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
            this.searchLoading = false
            this.tableData = []
          })
      },
      // 限制输入的类型为数字并进行类型转换
      numberLimit (json) {
        if (isNaN(json.Content)) {
          if (json.Tag === 'num') {
            this.filterForm.callPhone = json.Content.replace(/\D/g, '')
          } else if (json.Tag === 'start') {
            this.filterForm.minCallTime = json.Content.replace(/\D/g, '')
          } else if (json.Tag === 'end') {
            this.filterForm.maxCallTime = json.Content.replace(/\D/g, '')
          }
        } else {
          if (json.Tag === 'start') {
            this.filterForm.minCallTime = (json.Content === '' || json.Content === null) ? null : json.Content
          } else if (json.Tag === 'end') {
            this.filterForm.maxCallTime = (json.Content === '' || json.Content === null) ? null : json.Content
          }
        }
      },
      // 输入小数点限制
      dotLimit (json) {
        if (json.Tag === 'num') {
          this.filterForm.callPhone = (json.Content === '' || json.Content === null) ? null : parseInt(json.Content)
        } else if (json.Tag === 'start') {
          this.filterForm.minCallTime = (json.Content === '' || json.Content === null) ? null : parseInt(json.Content)
        } else if (json.Tag === 'end') {
          this.filterForm.maxCallTime = (json.Content === '' || json.Content === null) ? null : parseInt(json.Content)
        }
      },
      // 获取催收组列表
      getAllGroupList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionGroupList && this.collectionGroupList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionGroupList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionGroupList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              findAllGroupVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionGroupList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionGroupList', JSON.stringify(this.collectionGroupList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取催收员列表
      getAllCollectorList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectorList && this.collectorList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionCollectorList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectorList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchAllCollectorVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectorList = res.data
                    let _this = this
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionCollectorList', JSON.stringify(this.collectorList))
                    // 中文转拼音首字母
                    setTimeout(() => {
                      _this.handleChineseToPhoneticInitial()
                    }, 100)
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 根据输入过滤催收员列表
      filterCollector (query) {
        console.time('filterCollector')
        if (query !== '') {
          this.testinput = query
          this.collectorLoading = true
          this.collectorFilterList = []
          if (this.collectorTempList && this.collectorTempList.length > 0) {
            for (let i = 0, len = this.collectorTempList.length; i < len; i++) {
              if (this.collectorTempList[i].displayName.trim().indexOf(query.trim()) > -1 ||
                (this.collectorTempList[i].phoneticInitial && this.collectorTempList[i].phoneticInitial.indexOf(query.trim().toUpperCase()) > -1)) {
                this.collectorFilterList.push(this.collectorList[i])
              }
            }
          }
          this.collectorLoading = false
        } else {
          this.collectorFilterList = []
        }
        console.timeEnd('filterCollector')
      },
      handleChineseToPhoneticInitial () {
        console.time('handleChineseToPhoneticInitial')
        if (this.collectorList && this.collectorList.length > 0) {
          for (let index in this.collectorList) {
            this.collectorList[index].phoneticInitial = getFirstLetter(this.collectorList[index].displayName).join(',')
          }
          // 存入本地
          window.localStorage.setItem('Collection-CollectionCollectorList', JSON.stringify(this.collectorList))
        }
        console.timeEnd('handleChineseToPhoneticInitial')
      },
      // 播放
      playBtn (value) {
        // 如果相同索引，不赋值music，不相同索引，就重新赋值music
        if (value.id !== this.id) {
          // 新建对象
          this.music = null
          this.music = {
            title: '案件ID：' + value.caseId, // 必填字段
            author: 'dev', // 必填字段
            url: value.recordPath // 必填字段
          }
        }
        // 点击播放，所有都变为播放按钮
        this.tableData.map(item => {
          item.isPlay = 0
          return item
        })
        // 列表展示播放状态，暂停按钮
        value.isPlay = 1
        this.recordStatus = true
        this.id = value.id
        // 控件播放状态
        this.isShowPlayer = true
        this.audioPlayer.playOrPause = true
      },
      // 继续
      continueBtn (value) {
        // 当前点击的变为暂停按钮
        value.isPlay = 1
        this.recordStatus = true
        this.id = value.id
        // 控件播放状态
        this.audioPlayer.playOrPause = true
      },
      // 暂停
      pauseBtn (value) {
        // 列表展示暂停状态，播放按钮
        value.isPlay = 2
        this.recordStatus = false
        // 控件暂停状态
        this.audioPlayer.playOrPause = false
      },
      // 监听播放器的播放事件
      handleAudioPlay () {
        this.tableData.map(item => {
          if (item.id === this.id) {
            item.isPlay = 1
          }
          return item
        })
      },
      // 监听播放器的暂停事件
      handleAudioPause () {
        this.tableData.map(item => {
          if (item.id === this.id) {
            item.isPlay = 2
          }
          return item
        })
      },
      // 监听播放中 以便获取 当前播放时间
      handleAudioPlaying (player) {
        // 播放对象
        this.aplayerObj = player
      },
      handleAudioError () {
        this.$message.error('获取录音文件资源失败')
      },
      // 跳转到案件详情
      toCaseDetail (caseId) {
        window.open('#/case-detail/' + caseId)
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    }
  }
</script>

<style lang="scss" scoped>
  .width {
    width: 300px;
    font-size: 12px;
  }
  .center {
    line-height: 30px;
  }
  .font {
    font-size: 12px;
    line-height: 40px;
  }
  .input-width {
    width: 180px;
  }
  .input-width-1 {
    width: 150px;
  }
  .input-width-2{
    width: 100px;
  }
  .margin {
    margin-bottom: 5px;
  }
  .length-1 {
    width: 140px;
  }
  .length-2 {
    width: 180px;
  }
  .footer-player {
    position: absolute;
    width: calc(100% - 20px);
    bottom: 0;
    left: 10px;
    z-index: 100;
  }
  .to-case-detail {
    color: blue;
    cursor: pointer;
    &:hover {
      text-decoration: underline;
    }
  }
</style>

