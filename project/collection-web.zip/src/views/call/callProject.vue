<!--项目管理-->
<template>
  <div class="call-project-wrapper" v-loading="fullscreenLoading" element-loading-text="正在获取电话号码">

    <div class="call-form">
      <p>
        已还清的欠款的案件本人和联系人，将会从项目中删除；已停催的案件将不会显示和拨打
      </p>
    </div>

    <!-- 筛选条件 -->
    <el-form :inline="true" class="filter-form">
      <el-form-item label="项目状态">
        <el-form :inline="true">
          <el-form-item>
            <el-checkbox :indeterminate="isCallProject" v-model="checkAllCallProject" @change="handleCheckAllCallProjectChange">全选</el-checkbox>
          </el-form-item>
          <el-form-item>
            <el-checkbox-group v-model="filterForm.callProject" @change="handleCallProjectChange">
              <el-checkbox v-for="item in callProjectList" :label="item.code" :key="item.code">{{ item.value }}</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
        </el-form>
      </el-form-item>

      <el-form-item v-if="showSelectObj.isShowGroupSelect">
        <vue-el-select v-model="filterForm.groupIdList" multiple filterable placeholder="请选择催收组" size="small"
                       @visible-change="handleGroupVisibleChange" @clear="removeTag" @change="groupChange">
          <el-option
            v-for="item in collectionGroupFilterList"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>

      <el-form-item v-if="showSelectObj.isShowPersonSelect">
        <el-select v-model="filterForm.collectorId" filterable placeholder="请选择催收员" size="small"
                       @visible-change="handleCollectorVisibleChange" clearable
                       :disabled="showSelectObj.isShowPersonSelect && showSelectObj.isShowGroupSelect && !filterForm.groupIdList.length">
          <el-option
            v-for="item in collectorTempList"
            :key="item.id"
            :label="item.displayName"
            :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn">搜索</el-button>
      </el-form-item>

      <el-form-item style="float: right">
        <span>已选择 {{ multipleSelectionProject.length }} 条</span>
        <el-button type="danger" size="small" @click="deleteProjectBatch">批量删除</el-button>
      </el-form-item>
    </el-form>

    <!-- table开始 -->
    <el-table :data="tableData" v-loading="listLoading" border stripe style="width: 100%" :max-height="tableHeight"
              ref="multipleProjectTable" @selection-change="handleSelectionProjectChange">
      <el-table-column align="center" type="selection" width="30"></el-table-column>
      <el-table-column align="center" prop="createAt" label="创建时间" width="70"></el-table-column>
      <el-table-column align="center" prop="callProjectName" label="项目名称" min-width="120"></el-table-column>
      <el-table-column align="center" prop="collectorName" label="创建人" min-width="60"></el-table-column>
      <el-table-column align="center" label="执行次数" min-width="40">
        <template slot-scope="scope">
          <span class="imitate-a-label" v-if="scope.row.executeTimes" @click="openExecuteDetail(scope.row.id)">{{ scope.row.executeTimes }}</span>
          <span v-else>0</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="lastExecuteAt" label="上次执行时间" width="70"></el-table-column>
      <el-table-column align="center" prop="totalPhoneNum" label="总数" min-width="40"></el-table-column>
      <el-table-column align="center" prop="calledNum" label="已呼叫" min-width="40"></el-table-column>
      <el-table-column align="center" prop="callSuccessNum" label="已呼通" min-width="40"></el-table-column>
      <el-table-column align="center" prop="answeredNum" label="已接听" min-width="40"></el-table-column>
      <el-table-column align="center" label="呼通率" min-width="50">
        <template slot-scope="scope">
          <span v-if="scope.row.callSuccessNum && scope.row.calledNum">{{ ((scope.row.callSuccessNum / scope.row.calledNum) * 100 ).toFixed(2) + '%' }}</span>
          <span v-else>0.00%</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="接听率" min-width="50">
        <template slot-scope="scope">
          <span v-if="scope.row.answeredNum && scope.row.callSuccessNum">{{ ((scope.row.answeredNum / scope.row.callSuccessNum) * 100 ).toFixed(2) + '%' }}</span>
          <span v-else>0.00%</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="bizStatusStr" label="状态" min-width="50"></el-table-column>
      <el-table-column align="center" label="执行操作" min-width="120">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="toCaseDetail(scope.row)" v-if="scope.row.bizStatusStr === '未开始'">开始项目</el-button>
          <el-button type="text" size="mini" @click="toCaseDetail(scope.row)" v-if="scope.row.bizStatusStr === '已停止' || scope.row.bizStatusStr === '已结束'">再次呼叫</el-button>
          <el-button type="text" size="mini" @click="forcedTermination(scope.row)" style="color: red;">强制终止</el-button>
        </template>
      </el-table-column>
      <el-table-column align="center" label="操作" min-width="160">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="editPhoneNum(scope.row)">编辑号码</el-button>
          <el-button type="text" size="mini" @click="editProject(scope.row)">修改项目</el-button>
          <el-button type="text" size="mini" @click="deleteProject(scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- table结束 -->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

    <!-- 号码名单弹窗 -->
    <el-dialog title="号码名单" :visible.sync="dialogNumList">
      <el-form :inline="true">
        <el-form-item>
          <div>已还清的欠款的案件本人和联系人，将会从项目中删除</div>
          <div>已停催的案件将不会显示和拨打</div>
        </el-form-item>
        <el-form-item style="float: right;">
          <span>已选择 {{ multipleSelection.length }} 人</span>
          <el-button type="success" size="small" @click="deleteNumList">删除</el-button>
          <el-button type="danger" size="small" @click="addNum">添加</el-button>
        </el-form-item>
      </el-form>
      <el-form :inline="true">
        <el-form-item label="案件：">
          <el-input v-model="numFilterForm.caseName" size="small" placeholder="请输入案件" class="length-1"></el-input>
        </el-form-item>
        <el-form-item label="联系人：">
          <el-input v-model="numFilterForm.contactName" size="small" placeholder="请输入联系人" class="length-1"></el-input>
        </el-form-item>
        <el-form-item >
          <el-button type="primary" size="small" @click="searchNumListBtn">查询</el-button>
        </el-form-item>
      </el-form>
      <el-table :data="numListData" v-loading="numlistLoading" border stripe style="width: 100%" :max-height="numListTableHeight"
                ref="multipleTable" @selection-change="handleSelectionChange">
        <el-table-column align="center" type="selection" width="55"></el-table-column>
        <el-table-column align="center" property="createAt" label="添加时间" min-width="150"></el-table-column>
        <el-table-column align="center" property="caseName" label="案件" min-width="60">
          <template slot-scope="scope">
            <span class="imitate-a-label" @click="toCaseDetailByCaseId(scope.row.caseId)">{{ scope.row.caseName }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" property="contactName" label="联系人" min-width="100"></el-table-column>
        <el-table-column align="center" property="phone" label="号码" min-width="100"></el-table-column>
        <el-table-column align="center" label="操作" min-width="60">
          <template slot-scope="scope">
            <el-button type="text" size="mini" @click="deleteNum(scope.row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页开始-->
      <div v-show="!numlistLoading" class="pagination-container">
        <el-pagination @size-change="handleSizeChangeDialog" @current-change="handleCurrentChangeDialog"
                       :current-page.sync="pagDataDialog.pageNo" :page-sizes="pageSizesDialog"
                       :page-size="pagDataDialog.pageSize" layout="total, sizes, prev, pager, next, jumper"
                       :total="totalRecordDialog">
        </el-pagination>
      </div>
      <!-- 分页结束-->
    </el-dialog>

    <!-- 执行详情弹窗 -->
    <el-dialog title="执行详情" :visible.sync="dialogExecute">
      <el-table :data="executeData" v-loading="ExecuteLoading" border stripe style="width: 100%" :max-height="ExecuteTableHeight">
        <el-table-column align="center" property="executedTimes" label="执行次数" min-width="40"></el-table-column>
        <el-table-column align="center" property="executeAt" label="执行时间" min-width="60"></el-table-column>
        <el-table-column align="center" property="phoneTotalNum" label="总数" min-width="40"></el-table-column>
        <el-table-column align="center" property="phoneCalledNum" label="已呼叫" min-width="40"></el-table-column>
        <el-table-column align="center" property="phoneCallSuccessNum" label="已呼通" min-width="40"></el-table-column>
        <el-table-column align="center" property="phoneCallFailNum" label="未呼通" min-width="40"></el-table-column>
        <el-table-column align="center" property="phoneAnsweredNum" label="已接听" min-width="40"></el-table-column>
        <el-table-column align="center" property="answeredRatio" label="呼通率" min-width="40"></el-table-column>
        <el-table-column align="center" property="transferRatio" label="接听率" min-width="40"></el-table-column>
      </el-table>
      <!-- 分页开始-->
      <!--<div v-show="!ExecuteLoading" class="pagination-container">-->
        <!--<el-pagination @size-change="handleSizeChangeExecute" @current-change="handleCurrentChangeExecute"-->
                       <!--:current-page.sync="pagDataExecute.pageNo" :page-sizes="pageSizesExecute"-->
                       <!--:page-size="pagDataExecute.pageSize" layout="total, sizes, prev, pager, next, jumper"-->
                       <!--:total="totalRecordExecute">-->
        <!--</el-pagination>-->
      <!--</div>-->
      <!-- 分页结束-->
    </el-dialog>

    <!--批量外呼 修改项目-->
    <edit-project :PMProps="PMProps"></edit-project>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  // import { base64decode } from 'utils/index'
  import VueElSelect from '../../components/VueElSelect'
  import {
    fetchStopCallProject, // 停止外呼
    fetchKillServiceNum // 强制杀死坐席
  } from '../../api/case'
  import {
    fetchGetProjectList, // 获取项目列表
    fetchDeleteCallProjectBatch, // 批量删除项目
    fetchDeleteCallProject, // 删除项目
    fetchQueryCallProjectPhoneList, // 查询号码名单
    fetchDeleteCallProjectPhone, // 删除号码名单
    fetchStartCallProject, // 开始项目
    fetchQueryCallProjectExecuteList, // 获取执行详情
    fetchQueryCallProjectPhoneInfo, // 获取电话号码
    fetchGetExecOrPauseProject // 校验现在有没有正在进行拨打批呼项目
  } from '../../api/call'
  import {
    fetchAllCollectorVOList,
    findAllGroupVOList
  } from '../../api/common'
  import getFirstLetter from 'utils/chineseToPhoneticInitial'
  import editProject from '../case/components/editProject'

  export default {
    computed: {
      ...mapGetters([
        'showSelectObj',
        'userId',
        'serviceNum'
      ])
    },
    components: {
      VueElSelect, editProject
    },
    data () {
      return {
        fullscreenLoading: false,
        filterForm: {
          callProject: [],
          collectorId: '', // 催收员
          groupIdList: [] // 催收组
        },
        // 项目状态-复选框
        checkAllCallProject: false,
        isCallProject: false,
        callProjectList: [
          {value: '未开始', code: 0},
          {value: '呼叫中', code: 1},
          {value: '暂停中', code: 2},
          {value: '已停止', code: 3},
          {value: '已结束', code: 4}
        ], // 项目状态
        // 选择项目条数
        multipleSelectionProject: [],
        // 表格高度
        tableHeight: 600,
        listLoading: false,
        // 表格数据
        tableData: [],
        pagData: {
          pageSize: 20, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 20, 50, 100],
        // 号码名单弹窗
        dialogNumList: false, // 是否打开号码名单弹窗
        numListData: [], // 号码名单-表格数据
        numlistLoading: false, // 号码名单-loading加载
        numListTableHeight: '200', // 号码名单-表格高度
        pagDataDialog: {
          pageSize: 20, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecordDialog: 0, // 总记录数
        pageSizesDialog: [10, 20, 50, 100],
        multipleSelection: [], // 勾选的数组
        numFilterForm: {
          caseName: '', // 案件
          contactName: '' // 联系人
        },
        // 执行详情弹窗
        dialogExecute: false, // 是否打开执行详情
        executeData: [], // 执行详情-表格数据
        ExecuteLoading: false, // 执行详情-loading加载
        ExecuteTableHeight: '500', // 执行详情-表格高度
        pagDataExecute: {
          pageSize: 20, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecordExecute: 0, // 总记录数
        pageSizesExecute: [10, 20, 50, 100],
        // 催收员列表
        collectorList: [],
        collectorTempList: [], // 联动过滤后下拉列表
        collectorFilterList: [], // 输入过滤后下拉列表
        collectorLoading: false,

        // 催收组列表
        collectionGroupList: [],
        collectionGroupFilterList: [], // 过滤后下拉列表
        // 批量外呼
        PMProps: {},
        currentCallProjectId: null // 当前选中的项目ID
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
      // 获取表格数据
      this.getTableData()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize () {
        this.$nextTick(() => {
          // let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          let h = document.documentElement.clientHeight
          this.tableHeight = h - 214
        })
      },
      // 案件状态-复选框
      handleCheckAllCallProjectChange (val) {
        let arr = []
        this.callProjectList.map(item => {
          arr.push(item.code)
          return item
        })
        this.filterForm.callProject = val ? arr : []
        this.isCallProject = false
      },
      handleCallProjectChange (value) {
        let checkedCount = value.length
        this.checkAllCallProject = checkedCount === this.callProjectList.length
        this.isCallProject = checkedCount > 0 && checkedCount < this.callProjectList.length
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 选择项目条数
      handleSelectionProjectChange (val) {
        this.multipleSelectionProject = val
      },
      // 号码名单-选择人数
      handleSelectionChange (val) {
        this.multipleSelection = val
      },
      // 查询
      getTableData () {
        //        if (!this.filterForm.collectorId) {
        //          this.$message.warning('请输入催收员后再查询！')
        //          return false
        //        }
        this.listLoading = true
        let projectBizStatus = this.filterForm.callProject.join(',')
        let createUserId = this.filterForm.collectorId ? this.filterForm.collectorId : this.userId
        // let createUserId = this.userId // 默认查找当前登录用户 拥有管理查询岗位可以选择成员 没有则只能查看自己的
        fetchGetProjectList(projectBizStatus, createUserId, JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.tableData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 搜索
      searchBtn () {
        console.log(this.filterForm)
        this.getTableData()
      },
      // 批量删除项目
      deleteProjectBatch () {
        if (!this.multipleSelectionProject.length) {
          this.$message.warning('没有数据被选中')
          return false
        }
        this.$confirm('确定要删除这' + this.multipleSelectionProject.length + '个项目吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let arr = []
          this.multipleSelectionProject.map(item => {
            arr.push(item.id)
            return item
          })
          let callProjectIds = arr.join(',')
          fetchDeleteCallProjectBatch(callProjectIds)
            .then(response => {
              let res = response.data
              if (res.errorCode === 0) {
                this.getTableData()
              }
            })
            .catch(error => {
              console.log(error)
            })
        }).catch(() => {
          console.log('已取消操作')
        })
      },
      // 强制终止项目
      forcedTermination (project) {
        this.$confirm('强制终止此项目，将会挂断此坐席下所有电话，确定操作吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          if (!this.serviceNum) {
            this.$message.warning('坐席号不能为空')
            return false
          }
          let callProjectId = project.id
          // 停止项目
          fetchStopCallProject(callProjectId)
            .then(response => {
              let res = response.data
              if (res.errorCode === 0) {
                console.log('停止外呼')
                // 杀死坐席
                fetchKillServiceNum(this.serviceNum)
                  .then(response => {
                    let res = response.data
                    if (res.errorCode === 0) {
                      console.log('强制终止此项目成功')
                      this.getTableData()
                    }
                  })
                  .catch(error => {
                    console.log(error)
                  })
              }
            })
            .catch(error => {
              console.log(error)
            })
        }).catch(() => {
          console.log('取消此操作')
        })
      },
      // 编辑号码
      editPhoneNum (val) {
        this.dialogNumList = true
        this.currentCallProjectId = val.id
        this.getNumListData()
      },
      // 获取号码名单的表格数据
      getNumListData () {
        let status = 1 // 状态 :0, "停用";1, "启用"
        fetchQueryCallProjectPhoneList(this.currentCallProjectId, this.numFilterForm.caseName, this.numFilterForm.contactName, status, JSON.stringify(this.pagDataDialog))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.numListData = res.data.content
              this.totalRecordDialog = res.data.totalRecord
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 处理分页每页显示数改变事件dialog
      handleSizeChangeDialog (val) {
        this.pagDataDialog.pageSize = val
        this.getNumListData()
      },
      // 处理页码改变事件dialog
      handleCurrentChangeDialog (val) {
        this.pagDataDialog.pageNo = val
        this.getNumListData()
      },
      // 跳转到案件详情
      toCaseDetailByCaseId (caseId) {
        window.open('#/case-detail/' + caseId)
      },
      // 删除号码
      deleteCallProjectPhone (phoneIds) {
        fetchDeleteCallProjectPhone(this.currentCallProjectId, phoneIds)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.getNumListData()
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 号码名单-删除(批量)
      deleteNumList () {
        if (!this.multipleSelection.length) {
          this.$message.warning('没有数据被选中')
          return false
        }
        this.$confirm('确定要删除这' + this.multipleSelection.length + '个联系人吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let arr = []
          this.multipleSelection.map(item => {
            arr.push(item.id)
            return item
          })
          let phoneIds = arr.join(',')
          this.deleteCallProjectPhone(phoneIds)
        }).catch(() => {
          console.log('已取消操作')
        })
      },
      // 号码名单-添加
      addNum () {
        console.log('添加')
        window.open('#/case/case-query')
      },
      // 号码名单-查询
      searchNumListBtn () {
        this.getNumListData()
      },
      // 号码名单-删除(单个)
      deleteNum (id) {
        this.$confirm('确定要删除此联系人吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.deleteCallProjectPhone(id)
        }).catch(() => {
          console.log('已取消操作')
        })
      },
      // 修改项目
      editProject (project) {
        this.PMProps = {
          dialogVisible: true,
          project
        }
      },
      // 删除项目
      deleteProject (id) {
        this.$confirm('确定要删除此项目吗??', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          fetchDeleteCallProject(id)
            .then(response => {
              let res = response.data
              if (res.errorCode === 0) {
                console.log('删除成功')
                this.getTableData()
              }
            })
            .catch(error => {
              console.log(error)
            })
        }).catch(() => {
          console.log('已取消操作')
        })
      },
      // 跳转到案件详情 开始批呼
      toCaseDetail (val) {
        if (!this.serviceNum) {
          this.$message.warning('坐席号不能为空')
          return false
        }
        this.currentCallProjectId = val.id
        // this.getNumListData(1, val.callRatio) // 传1代表开始项目 传空代表查询号码
        this.getExecOrPauseProject()
      },
      // 校验现在有没有正在进行拨打批呼项目
      getExecOrPauseProject () {
        fetchGetExecOrPauseProject()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && !res.data) {
              // 校验成功则开始获取电话
              this.queryCallProjectPhoneInfo()
            } else if (res.errorCode === 0 && res.data) {
              this.$message.warning('有项目正在呼叫中，请勿再次操作！')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 开始项目 获取电话
      queryCallProjectPhoneInfo () {
        this.fullscreenLoading = true
        fetchQueryCallProjectPhoneInfo(this.currentCallProjectId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              let phoneTotalNum = res.data.phoneList.length // 电话总数
              let caseId = res.data.phoneList[0].caseId // 取第一个的caseId
              let callRatio = res.data.callRatio // 取第一个的caseId
              let arr = []
              let displayUsers = {}
              let callRecordMap = {}
              res.data.phoneList.map(item => {
                callRecordMap[item.uuid] = {
                  callRecordId: item.callRecordId,
                  chinessPinYin: item.chinessPinYin
                }
                arr.push(
                  {
                    // phone: base64decode(item.phone),
                    phone: item.phone,
                    data: {
                      caseId: item.caseId,
                      calledName: item.calledName,
                      phone: item.displayPhone,
                      // realPhone: base64decode(item.phone)
                      realPhone: item.phone
                    },
                    uuid: item.uuid
                  }
                )
                displayUsers[item.uuid] = item.displayPhone
                return item
              })
              this.startCallProject(caseId, phoneTotalNum, arr, displayUsers, callRecordMap, callRatio)
            }
            this.fullscreenLoading = false
          })
          .catch(error => {
            console.log(error)
            this.fullscreenLoading = false
          })
      },
      // 开始项目
      startCallProject (caseId, phoneTotalNum, arr, displayUsers, callRecordMap, callRatio) {
        fetchStartCallProject(this.currentCallProjectId, phoneTotalNum)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              let executeId = res.data
              arr.map(item => {
                item.data.executeId = executeId
                return item
              })
              let obj = {
                arr,
                displayUsers,
                callRecordMap,
                callRatio,
                executeId,
                callProjectId: this.currentCallProjectId
              }
              this.getTableData()
              window.sessionStorage.setItem('Collection-BatchCall', JSON.stringify(obj))
              window.open('#/case-detail-batch/')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取催收组列表
      getAllGroupList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionGroupList && this.collectionGroupList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionGroupList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionGroupList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              findAllGroupVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionGroupList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionGroupList', JSON.stringify(this.collectionGroupList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取催收员列表
      getAllCollectorList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectorList && this.collectorList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionCollectorList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectorList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchAllCollectorVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectorList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionCollectorList', JSON.stringify(this.collectorList))
                    // 中文转拼音首字母
                    //                    setTimeout(() => {
                    //                      _this.handleChineseToPhoneticInitial()
                    //                    }, 100)
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 多选模式下移除tag时触发
      removeTag () {
        console.log(11111111111)
        this.filterForm.collectorId = ''
      },
      // 催收组change
      groupChange () {
        this.filterForm.collectorId = this.filterForm.groupIdList.length ? this.filterForm.collectorId : ''
      },
      // 催收组 下拉框出现/隐藏时触发
      handleGroupVisibleChange (visible) {
        if (visible) {
          this.getAllGroupList().then(() => {
            this.collectionGroupFilterList = JSON.parse(JSON.stringify(this.collectionGroupList))
          })
        }
      },
      // 催收员 下拉框出现/隐藏时触发
      handleCollectorVisibleChange (visible) {
        if (visible) {
          this.getAllCollectorList().then(() => {
            // 然后过滤数据 groupId
            if (this.filterForm.groupIdList.length === 0) {
              this.collectorTempList = JSON.parse(JSON.stringify(this.collectorList))
            } else {
              this.collectorTempList = this.collectorList.filter(item => {
                // 机构、组下拉框
                if (this.filterForm.groupIdList.length > 0) { // 组选了 返回组下面的
                  return this.filterForm.groupIdList.join(',').indexOf(item.groupId) >= 0
                } else {
                  return false
                }
              })
            }
          })
        }
      },
      // 根据输入过滤催收员列表
      filterCollector (query) {
        console.time('filterCollector')
        if (query !== '') {
          this.testinput = query
          this.collectorLoading = true
          this.collectorFilterList = []
          if (this.collectorTempList && this.collectorTempList.length > 0) {
            for (let i = 0, len = this.collectorTempList.length; i < len; i++) {
              if (this.collectorTempList[i].displayName.trim().indexOf(query.trim()) > -1 ||
                (this.collectorTempList[i].phoneticInitial && this.collectorTempList[i].phoneticInitial.indexOf(query.trim().toUpperCase()) > -1)) {
                this.collectorFilterList.push(this.collectorList[i])
              }
            }
          }
          this.collectorLoading = false
        } else {
          this.collectorFilterList = []
        }
        console.timeEnd('filterCollector')
      },
      handleChineseToPhoneticInitial () {
        console.time('handleChineseToPhoneticInitial')
        if (this.collectorList && this.collectorList.length > 0) {
          for (let index in this.collectorList) {
            this.collectorList[index].phoneticInitial = getFirstLetter(this.collectorList[index].displayName).join(',')
          }
          // 存入本地
          window.localStorage.setItem('Collection-CollectionCollectorList', JSON.stringify(this.collectorList))
        }
        console.timeEnd('handleChineseToPhoneticInitial')
      },
      // 打开执行详情弹窗
      openExecuteDetail (callProjectId) {
        this.currentCallProjectId = callProjectId
        this.dialogExecute = true
        this.getExecuteDetail()
      },
      // 获取执行详情数据
      getExecuteDetail () {
        this.ExecuteLoading = true
        let bizStatusList = null
        fetchQueryCallProjectExecuteList(this.currentCallProjectId, bizStatusList, JSON.stringify(this.pagDataExecute))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.executeData = res.data.content
              this.totalRecordExecute = res.data.totalRecord
            }
            this.ExecuteLoading = false
          })
          .catch(error => {
            console.log(error)
            this.ExecuteLoading = false
          })
      },
      // 处理分页每页显示数改变事件
      handleSizeChangeExecute (val) {
        this.pagDataExecute.pageSize = val
        this.getExecuteDetail()
      },
      // 处理页码改变事件
      handleCurrentChangeExecute (val) {
        this.pagDataExecute.pageNo = val
        this.getExecuteDetail()
      }
    }
  }
</script>

<style lang="scss" scoped>
  .call-project-wrapper {
    .call-form {
      font-size: 12px;
      line-height: 20px;
      border-bottom: 1px solid #bbb;
      p {
        margin: 0 50px 0 0;
      }
    }

    .length-1 {
      width: 140px;
    }

    .filter-form {
      .el-form-item {
        margin-bottom: 0;
      }
    }

  }
</style>
