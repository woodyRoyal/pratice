<!--通话记录-->
<template>
  <div class="call">
    <el-form class="filter-form" :inline="true">
      <!--通话时间-->
      <el-form-item class="margin">
        <span class="width font">通话时间：</span>
        <el-date-picker
          class="length-1"
          v-model="date"
          type="date"
          size="small"
          :editable="false"
          :clearable="false"
          :picker-options="pickerOptions1"
          placeholder="选择日期">
        </el-date-picker>
        <el-time-picker
          class="length-2"
          is-range
          v-model="time"
          size="small"
          :editable="false"
          :clearable="false"
          range-separator="-"
          start-placeholder="开始时间"
          end-placeholder="结束时间"
          placeholder="选择时间范围">
        </el-time-picker>
      </el-form-item>
      <!--项目-->
      <el-form-item class="margin">
        <span class="demonstration width">项目：</span>
        <el-select size="small" class="input-width" v-model="filterForm.callProjectId">
          <el-option v-for="(item,index) in callProjectIdList" :key="item.id" :label="item.callProjectName" :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>

      <!--客户姓名、联系人电话、联系人电话-->
      <el-form-item class="demo-input-size margin">
        <span class="width center">客户姓名：</span>
        <el-input class="input-width" size="small"  v-model="filterForm.caseName"></el-input>
      </el-form-item>
      <el-form-item class="margin">
        <span class="width center">联系人电话：</span>
        <el-tooltip class="item" effect="dark" content="请输入数字" placement="top-start">
          <el-input class="input-width" size="small" v-model="filterForm.callPhone" @keyup.native="numberLimit({'Content':filterForm.callPhone,'Tag':'num'})" @blur="dotLimit({'Content':filterForm.callPhone,'Tag':'num'})"></el-input>
        </el-tooltip>
      </el-form-item>
      <el-form-item class="margin">
        <span class="width center">联系人姓名：</span>
        <el-input class="input-width" size="small" v-model="filterForm.callName"></el-input>
      </el-form-item>

      <!--呼叫、接通、挂断、通话时长-->
      <el-form-item class="margin">
        <span class="width">呼叫：</span>
        <el-select size="small" class="input-width" v-model="filterForm.callType">
          <el-option v-for="(item,index) in callOptions" :key="index" :label="item" :value="index === 'default'? null: index">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item class="margin">
        <span class="width">接通：</span>
        <el-select size="small" class="input-width" v-model="filterForm.callStatus">
          <el-option v-for="(item,index) in connectOptions" :key="index" :label="item" :value="index === 'default'? null: index">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item class="margin">
        <span class="width">挂断：</span>
        <el-select size="small" class="input-width" v-model="filterForm.hangupReason">
          <el-option v-for="(item,index) in hangOptions" :key="index" :label="item" :value="index === 'default'? null: index"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item class="margin">
        <span class="font">通话时长: </span>
        <el-tooltip class="item" effect="dark" content="请输入数字" placement="top-start">
          <el-input class="input-width" size="small" v-model="filterForm.minCallTime" @keyup.native="numberLimit({'Content':filterForm.minCallTime,'Tag':'start'})" @blur="dotLimit({'Content':filterForm.minCallTime,'Tag':'start'})">
          </el-input>
        </el-tooltip>
        <span class="font">至</span>
        <el-tooltip class="item" effect="dark" content="请输入数字" placement="top-start">
          <el-input class="input-width" size="small" v-model="filterForm.maxCallTime" @keyup.native="numberLimit({'Content':filterForm.maxCallTime,'Tag':'end'})" @blur="dotLimit({'Content':filterForm.maxCallTime,'Tag':'end'})">
          </el-input>
        </el-tooltip>
        <span class="font">(秒)</span>
      </el-form-item>

      <!--电话标记-->
      <el-form-item class="margin">
        <span class="demonstration width">电话标记：</span>
        <el-select size="small" v-model="filterForm.resultDesc">
          <el-option v-for="(item,index) in TagOptions" :key="index" :label="item" :value="index === 'default'? null: index"></el-option>
        </el-select>
      </el-form-item>

      <!--查询-->
      <el-form-item class="margin">
        <el-button type="success" size="small" @click="searchBtn" :loading="searchLoading">查询</el-button>
        <el-button type="primary" size="small" @click="newProject">新建项目</el-button>
      </el-form-item>
    </el-form>
    <hr/>
    <!--表格-->
    <el-table style="width: 100%" :data="tableData" stripe border v-loading="listLoading" @selection-change="handleSelectionChange" :max-height="tableHeight">
      <el-table-column type="selection" align="center"></el-table-column>
      <el-table-column label="通话时间" align="center" prop="createAt" width="78"></el-table-column>
      <el-table-column label="主叫" align="center" prop="collectorName" min-width="50"></el-table-column>
      <el-table-column label="案件" align="center" min-width="50">
        <template slot-scope="scope">
          <span class="to-case-detail" @click="toCaseDetail(scope.row.caseId)">{{ scope.row.caseName }}</span>
        </template>
      </el-table-column>
      <el-table-column label="被叫" align="center" prop="calledName" min-width="70"></el-table-column>
      <el-table-column label="UUID" align="center" min-width="70">
        <template slot-scope="scope">
          <el-tooltip class="item" effect="dark" :content="scope.row.callCenterCallId" placement="left">
            <span style="width: 70px;overflow: hidden; text-overflow:ellipsis; white-space: nowrap;">{{ scope.row.callCenterCallId }}</span>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column label="振铃时长" align="center" prop="ringingTime" min-width="70"></el-table-column>
      <el-table-column label="IVR时长" align="center" prop="ivrTime" min-width="70"></el-table-column>
      <el-table-column label="通话时长" align="center" prop="callTime" min-width="70"></el-table-column>
      <el-table-column label="呼叫类型" align="center" prop="callType" min-width="60"></el-table-column>
      <el-table-column label="接通状态" align="center" prop="statusStr" min-width="60"></el-table-column>
      <el-table-column label="挂断原因" align="center" prop="hangupReasonStr" min-width="60"></el-table-column>
      <el-table-column label="项目" align="center" prop="callProjectName" min-width="60"></el-table-column>
      <el-table-column label="录音" align="center" prop="recordPath" min-width="60">
        <template slot-scope="scope">
          <el-button v-if="scope.row.recordPath && scope.row.isPlay === 0" type="primary" size="mini" @click="playBtn(scope.row)">播放</el-button>
          <el-button v-if="scope.row.recordPath &&scope.row.isPlay === 1" type="danger" size="mini" @click="pauseBtn(scope.row)">停止</el-button>
          <el-button v-if="scope.row.recordPath &&scope.row.isPlay === 2" type="success" size="mini" @click="continueBtn(scope.row)">继续
          </el-button>
        </template>
      </el-table-column>
      <el-table-column label="电话标记" align="center" prop="resultDescStr" min-width="60"></el-table-column>
      <el-table-column label="备注" align="center" prop="memo" min-width="60"></el-table-column>
    </el-table>
    <!-- 分页开始-->
    <div class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

    <!--弹框提示信息-->
    <el-dialog title="提示" :visible.sync="dialogVisible" width="30%">
      <span>只能查询一天之内的通话记录</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
     </span>
    </el-dialog>

    <!-- 播放 -->
    <el-row class="footer-player" v-show="isShowPlayer">
      <i class="el-icon-close" title="关闭" @click="handleCloseAplayer"></i>
      <vue-aplayer autoplay mutex theme="#13CE66" mode="circulation"
                   @playing="handleAudioPlaying"
                   @play="handleAudioPlay"
                   @pause="handleAudioPause"
                   @error="handleAudioError"
                   :playOrPause="audioPlayer.playOrPause"
                   :music="music">
      </vue-aplayer>
    </el-row>
    <!--新建项目-->
    <el-dialog title="新建项目" :visible.sync="dialogVisibleProject" class="project-management-wrapper" @close="handleClose">
      <el-form :model="form" :rules="rules" ref="form" label-width="80px" style="margin-top: 10px;">
        <el-form-item label="提示">
          <div>已还清的欠款的案件本人和联系人，都无法添加到项目中</div>
          <div>已停催的案件将不会显示和拨打</div>
        </el-form-item>
        <el-form-item label="项目名称" prop="projectName">
          <el-input v-model="form.callProjectName" placeholder="请输入项目名称" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item label="呼叫系数">
          <!--<el-input v-model="editProjectForm.callCoefficient" placeholder="请输入呼叫系数" class="length-1"></el-input>-->
          <el-input-number v-model="form.callRatio" :min="1" :max="15" label="请输入呼叫系数" @blur="inputNumberBlur" class="length-1"></el-input-number>
          <span>控制同时呼出的电话数量，范围1~15的整数</span>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleCancelProject">取 消</el-button>
        <el-button type="primary" @click="handleNewProject">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import {fetchGetCallRecordList, fetchProjectIDList, fetchQueryByProjectName, fetchSaveWithContact} from '../../api/call'
  import { parseTime, formatMillisecondTo } from '../../utils/formatDate'
  import VueAplayer from '../../components/AudioPlayer/index.vue'
  import { CALL_OPTIONS, CONNECT_OPTIONS, HANG_OPTIONS, TAG_OPTIONS } from './callConstantList'
  import { mapGetters } from 'vuex'
  export default {
    components: {
      VueAplayer
    },
    computed: {
      ...mapGetters([
        'userId' // 用户ID
      ])
    },
    mounted () {
      // 表格高度
      this.handleResize()
      // 获取项目列表数据
      this.handleProjectId()
      window.addEventListener('resize', this.handleResize)
    },
    data: function () {
      // 校验项目名称
      let checkProjectName = (rule, value, callback) => {
        if (!this.form.callProjectName) {
          return callback(new Error('项目名称不能为空'))
        } else if (this.form.callProjectName.length > 50) {
          return callback(new Error('项目名称的长度请在50个字符以内'))
        } else {
          // 校验重复
          fetchQueryByProjectName(this.form.callProjectName)
            .then(response => {
              let res = response.data
              if (res.errorCode === 0 && res.data) {
                return callback(new Error('项目名称不能重复'))
              } else {
                callback()
              }
            })
            .catch(error => {
              console.log(error)
            })
        }
      }
      return {
        searchLoading: false, // 搜索按钮
        date: new Date(), // 日期
        time: [new Date().getTime() - 3600 * 1000, new Date().getTime()], // 时间
        pickerOptions1: {
          disabledDate (time) {
            return time.getTime() > Date.now() || time.getTime() < new Date('2019-03-20')
          }
        },
        filterForm: {
          startDate: null, // 开始时间
          endDate: null, // 结束时间
          callProjectId: null, // 项目Id
          callType: null, // 呼叫类型
          callStatus: null, // 接通状态
          hangupReason: null, // 挂断状态
          resultDesc: null, // 电话标记状态
          callName: null, // 联系人姓名
          callPhone: null, // 联系人电话
          caseName: null, // 客户姓名
          maxCallTime: null, // 最大通话时长
          minCallTime: null // 最小通话时长
        },
        // 呼叫目录
        callOptions: CALL_OPTIONS,
        // 接通目录
        connectOptions: CONNECT_OPTIONS,
        // 挂断目录
        hangOptions: HANG_OPTIONS,
        // 电话标记目录
        TagOptions: TAG_OPTIONS,
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [50, 100, 200],
        // 表格高度
        tableHeight: 600,
        listLoading: false,
        tableData: [],
        callProjectIdList: [], // 项目Id列表
        dialogVisible: false, // 查询时间控制弹框
        audioPlayer: {
          currentTime: 0,
          playOrPause: false
        },
        music: {
          title: 'audio', // 必填字段
          author: 'dev', // 必填字段
          url: 'http://devtest.qiniudn.com/Preparation.mp3' // 必填字段
        },
        id: null, // 播放索引（案件ID）
        recordStatus: false, // 播放状态
        errorTypeList: [], // 错误类型
        isShowPlayer: false, // 是否显示播放器
        aplayerObj: null, // 播放器对象
        collectorId: null, // 项目Id
        status: 1,
        noLimit: [{callProjectName: '全部', id: null}], // 添加项目列表的全部选项
        dialogVisibleProject: false, // 新建项目弹框
        multipleSelection: [], // 勾选数据
        form: { // 新增项目绑定数据
          callProjectName: '',
          // contactType: [],
          callRatio: ''
        },
        rules: {
          projectName: [
            { validator: checkProjectName, trigger: 'blur' }
          ]
        },
        callRecordIds: '' // 已选的通话记录
      }
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // 失焦校验
      inputNumberBlur () {
        this.form.callRatio = parseInt(this.form.callRatio)
      },
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          let h = document.documentElement.clientHeight
          if (formHeight >= 90) {
            this.tableHeight = h - 315
          } else if (formHeight >= 45) {
            this.tableHeight = h - 100
          }
        })
      },
      searchBtn () {
        this.getTableData()
      },
      // 新建项目
      newProject () {
        if (this.multipleSelection.length) {
          this.dialogVisibleProject = true
        } else {
          this.$message({
            message: '没有数据被选中',
            type: 'warning'
          })
        }
      },
      // 勾选数据表
      handleSelectionChange (val) {
        this.multipleSelection = val
        let arr = []
        this.multipleSelection.forEach(item => {
          arr.push(item.id)
        })
        this.callRecordIds = arr.join(',')
      },
      handleNewProject () { // 新建项目确定
        this.submitForm('form')
      },
      handleCancelProject () { // 取消新建
        this.handleClose()
        this.dialogVisibleProject = false
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.save()
            this.dialogVisibleProject = false
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      // save
      save () {
        let callRecordIds = this.callRecordIds
        let callProjectName = this.form.callProjectName
        let callRatio = this.form.callRatio
        let contactType = '4'
        fetchSaveWithContact(callRecordIds, callProjectName, callRatio, contactType)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success('新增成功')
              // this.getTableData()
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 关闭新建项目弹框
      handleClose () {
        this.resetForm('form')
        this.form = {
          callProjectName: '',
          callRatio: ''
        }
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        this.searchLoading = true
        this.listLoading = true
        this.filterForm.startDate = parseTime(this.date, 'YYYY-MM-DD') + ' ' + parseTime(this.time[0], 'HH:mm:ss')
        this.filterForm.endDate = parseTime(this.date, 'YYYY-MM-DD') + ' ' + parseTime(this.time[1], 'HH:mm:ss')
        this.filterForm.collecotorIds = this.userId
        fetchGetCallRecordList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            if (response.data.errorCode === 0) {
              if (response.data.data) {
                response.data.data.content.map(item => {
                  // 增加字段isplay  false暂停状态/true播放状态
                  if (item.id === this.id) {
                    if (this.recordStatus) {
                      item.isPlay = 1
                    } else {
                      item.isPlay = 2
                    }
                  } else {
                    item.isPlay = 0
                  }
                  item.callTime = formatMillisecondTo(item.callTime)
                  item.ivrTime = formatMillisecondTo(item.ivrTime)
                  item.ringingTime = formatMillisecondTo(item.ringingTime)
                })
                let data = response.data.data
                this.pagData.pageSize = data.pageSize
                this.pagData.pageNo = data.pageNo
                this.totalRecord = data.totalRecord
                this.tableData = data.content
              } else {
                this.pagData.pageSize = 100
                this.pagData.pageNo = 1
                this.totalRecord = 0
                this.tableData = []
              }
            }
            this.listLoading = false
            this.searchLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
            this.searchLoading = false
            this.tableData = []
          })
      },
      // 限制输入的类型为数字并进行类型转换
      numberLimit (json) {
        if (isNaN(json.Content)) {
          if (json.Tag === 'num') {
            this.filterForm.callPhone = json.Content.replace(/\D/g, '')
          } else if (json.Tag === 'start') {
            this.filterForm.minCallTime = json.Content.replace(/\D/g, '')
          } else if (json.Tag === 'end') {
            this.filterForm.maxCallTime = json.Content.replace(/\D/g, '')
          }
        } else {
          if (json.Tag === 'start') {
            this.filterForm.minCallTime = (json.Content === '' || json.Content === null) ? null : json.Content
          } else if (json.Tag === 'end') {
            this.filterForm.maxCallTime = (json.Content === '' || json.Content === null) ? null : json.Content
          }
        }
      },
      // 输入小数点限制
      dotLimit (json) {
        if (json.Tag === 'num') {
          this.filterForm.callPhone = (json.Content === '' || json.Content === null) ? null : parseInt(json.Content)
        } else if (json.Tag === 'start') {
          this.filterForm.minCallTime = (json.Content === '' || json.Content === null) ? null : parseInt(json.Content)
        } else if (json.Tag === 'end') {
          this.filterForm.maxCallTime = (json.Content === '' || json.Content === null) ? null : parseInt(json.Content)
        }
      },
      // 播放
      playBtn (value) {
        // 如果相同索引，不赋值music，不相同索引，就重新赋值music
        if (value.id !== this.id) {
          // 新建对象
          this.music = null
          this.music = {
            title: '案件ID：' + value.caseId, // 必填字段
            author: 'dev', // 必填字段
            url: value.recordPath // 必填字段
            // url: 'http://cdnringuc.shoujiduoduo.com/ringres/user/a24/949/34307949.aac' // 必填字段
          }
        }
        // 点击播放，所有都变为播放按钮
        this.tableData.map(item => {
          item.isPlay = 0
          return item
        })
        // 列表展示播放状态，暂停按钮
        value.isPlay = 1
        this.recordStatus = true
        this.id = value.id
        // 控件播放状态
        this.isShowPlayer = true
        this.audioPlayer.playOrPause = true
      },
      // 继续
      continueBtn (value) {
        // 当前点击的变为暂停按钮
        value.isPlay = 1
        this.recordStatus = true
        this.id = value.id
        // 显示控件播放状态
        this.isShowPlayer = true
        // 控件播放状态
        this.audioPlayer.playOrPause = true
      },
      // 暂停
      pauseBtn (value) {
        // 列表展示暂停状态，播放按钮
        value.isPlay = 2
        this.recordStatus = false
        // 控件暂停状态
        this.audioPlayer.playOrPause = false
      },
      // 监听播放器的播放事件
      handleAudioPlay () {
        this.tableData.map(item => {
          if (item.id === this.id) {
            item.isPlay = 1
          }
          return item
        })
      },
      // 监听播放器的暂停事件
      handleAudioPause () {
        this.tableData.map(item => {
          if (item.id === this.id) {
            item.isPlay = 2
          }
          return item
        })
      },
      // 监听播放中 以便获取 当前播放时间
      handleAudioPlaying (player) {
        // 播放对象
        this.aplayerObj = player
      },
      handleAudioError () {
        this.$message.error('获取录音文件资源失败')
      },
      // 关闭播放器
      handleCloseAplayer () {
        this.isShowPlayer = false
        if (this.aplayerObj) {
          // 点击搜索，播放暂停
          this.audioPlayer.playOrPause = false
          // 播放状态
          this.recordStatus = false
        }
      },

      // 获取项目数据列表
      handleProjectId () {
        fetchProjectIDList(JSON.stringify(this.collectorId), JSON.stringify(this.status))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.callProjectIdList = res.data.concat(this.noLimit)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 跳转到案件详情
      toCaseDetail (caseId) {
        window.open('#/case-detail/' + caseId)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .width {
    width: 300px;
    font-size: 12px;
  }
  .center {
    line-height: 30px;
  }
  .font {
    font-size: 12px;
    line-height: 40px;
  }
  .input-width {
    width: 120px;
  }
  .margin {
    margin-bottom: 5px;
  }
  .length-1 {
    width: 140px;
  }
  .length-2 {
    width: 180px;
  }
  .footer-player {
    position: absolute;
    width: calc(100% - 20px);
    bottom: 0;
    left: 10px;
    z-index: 100;
    .el-icon-close {
      color: #cdcdcd;
      font-size: 0;
      position: absolute;
      right: 7px;
      top: 7px;
      cursor: pointer;
    }
    &:hover {
      .el-icon-close {
        font-size: 20px;
      }
    }
  }
  .to-case-detail {
    color: blue;
    cursor: pointer;
    &:hover {
     text-decoration: underline;
     }
  }
</style>

