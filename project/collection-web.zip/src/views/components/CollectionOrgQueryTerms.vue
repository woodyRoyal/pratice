/**
* 机构查询条件选项公用组件
* Created by zuo on 2017/11/9.
*/

<template>
  <!-- 筛选条件开始 -->
  <el-form :inline="true" :model="filterForm" class="filter-form">
    <el-form-item label="日期">
      <el-date-picker
        v-model="dateRange"
        type="daterange"
        size="small"
        :editable="false"
        :clearable="false"
        class="length-3"
        placeholder="选择日期范围"
        :picker-options="pickerOptions1">
      </el-date-picker>
    </el-form-item>
    <el-form-item v-if="showSelectObj.isShowCompanySelect">
      <vue-el-select v-model="filterForm.groupIds" multiple filterable placeholder="请选择催收机构" size="small"
                     class="length-2" @visible-change="handleMechanVisibleChange">
        <el-option
          v-for="item in collectionAgenciesList"
          :key="item.id"
          :label="item.name"
          :value="item.id">
        </el-option>
      </vue-el-select>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" size="small" @click="handleSearchData">搜索</el-button>
      <el-button type="success" size="small" @click="handleExportData">导出</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
  import { pickerOptions1 } from '../../utils/index'
  import { parseTime } from '../../utils/formatDate'
  import VueElSelect from '../../components/VueElSelect'
  import { mapGetters } from 'vuex'
  import { fetchAllMechanVOList } from '../../api/common'

  export default {
    components: {
      VueElSelect
    },
    props: {},
    computed: {
      ...mapGetters([
        'showSelectObj'
      ])
    },
    data () {
      return {
        pickerOptions1, // 日期范围组件配置常量
        dateRange: [new Date().getTime() - 3600 * 1000 * 24, new Date().getTime()],
        // 筛选数据
        filterForm: {
          startDate: null, // 开始时间
          endDate: null, // 结束时间
          groupIds: [] // 催收机构
        },
        // 催收机构列表
        collectionAgenciesList: []
      }
    },
    mounted () {
      this.getAllMechanList()
    },
    methods: {
      // 获取催收机构列表
      getAllMechanList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionAgenciesList && this.collectionAgenciesList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionOrganizationList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionAgenciesList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchAllMechanVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionAgenciesList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionOrganizationList', JSON.stringify(this.collectionAgenciesList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 催收机构 下拉框出现/隐藏时触发
      handleMechanVisibleChange (visible) {
        if (visible) {
          // 用Promise保证执行顺序 先获取到数据再过滤
          // 先获取总数据
          this.getAllMechanList().then(() => {
            // 然后过滤数据
          })
        }
      },
      handleSearchData () {
        this.filterForm.startDate = parseTime(this.dateRange[0], 'YYYY-MM-DD')
        this.filterForm.endDate = parseTime(this.dateRange[1], 'YYYY-MM-DD')
        if (this.filterForm.groupIds && this.filterForm.groupIds.length === 0) {
          this.collectionAgenciesList.forEach(item => {
            this.filterForm.groupIds.push(item.id)
          })
        }
        this.$emit('search', this.filterForm)
      },
      handleExportData () {
        if (this.filterForm.groupIds && this.filterForm.groupIds.length === 0) {
          this.collectionAgenciesList.forEach(item => {
            this.filterForm.groupIds.push(item.id)
          })
        }
        this.$emit('export', this.filterForm)
      }
    }
  }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  .filter-form {
    .length-2 {
      width: 200px;
    }
    .length-3 {
      width: 220px;
    }
    .el-form-item {
      margin-bottom: 5px;
    }
  }
</style>
