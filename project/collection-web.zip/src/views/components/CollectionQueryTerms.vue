/**
* 催收查询条件选项公用组件
* Created by zuo on 2017/11/9.
*/

<template>
  <!-- 筛选条件开始 -->
  <el-form :inline="true" :model="filterForm" class="filter-form">
    <el-form-item label="日期">
      <el-date-picker
        v-model="dateRange"
        type="daterange"
        size="small"
        :editable="false"
        :clearable="false"
        class="length-3"
        placeholder="选择日期范围"
        :picker-options="pickerOptions1">
      </el-date-picker>
    </el-form-item>
    <el-form-item v-if="showSelectObj.isShowCompanySelect">
      <vue-el-select v-model="filterForm.mechanIdList" multiple filterable placeholder="请选择催收机构" size="small"
                     class="length-2" @visible-change="handleMechanVisibleChange">
        <el-option
          v-for="item in collectionAgenciesList"
          :key="item.id"
          :label="item.name"
          :value="item.id">
        </el-option>
      </vue-el-select>
    </el-form-item>
    <el-form-item v-if="showSelectObj.isShowManagerSelect">
      <vue-el-select v-model="filterForm.managerIdList" multiple filterable placeholder="请选择催收经理" size="small"
                     class="length-2" @visible-change="handleManagerVisibleChange">
        <el-option
          v-for="item in collectionManagerFilterList"
          :key="item.id"
          :label="item.displayName"
          :value="item.id">
        </el-option>
      </vue-el-select>
    </el-form-item>
    <el-form-item v-if="showSelectObj.isShowGroupSelect">
      <vue-el-select v-model="filterForm.groupIdList" multiple filterable placeholder="请选择催收组" size="small"
                     class="length-2" @visible-change="handleGroupVisibleChange">
        <el-option
          v-for="item in collectionGroupFilterList"
          :key="item.id"
          :label="item.name"
          :value="item.id">
        </el-option>
      </vue-el-select>
    </el-form-item>
    <el-form-item v-if="showSelectObj.isShowPersonSelect">
      <vue-el-select v-model="filterForm.collectorIdList" multiple filterable remote placeholder="请输入并选择催收员"
                     size="small"
                     class="length-2" @visible-change="handleCollectorVisibleChange" :remote-method="filterCollector"
                     :loading="collectorLoading">
        <el-option
          v-for="item in collectorFilterList"
          :key="item.id"
          :label="item.displayName"
          :value="item.id">
        </el-option>
      </vue-el-select>
    </el-form-item>

    <el-form-item>
      <el-button type="primary" size="small" @click="handleSearchData">搜索</el-button>
      <el-button type="success" size="small" @click="handleExportData">导出</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
  import { pickerOptions1 } from '../../utils/index'
  import { parseTime } from '../../utils/formatDate'
  import VueElSelect from '../../components/VueElSelect'
  import { mapGetters } from 'vuex'
  import {
    fetchAllCollectorVOList,
    findAllGroupVOList,
    findAllManagerVOList,
    fetchAllMechanVOList
  } from '../../api/common'

  export default {
    components: {
      VueElSelect
    },
    props: {},
    computed: {
      ...mapGetters([
        'showSelectObj'
      ])
    },
    data () {
      return {
        pickerOptions1, // 日期范围组件配置常量
        dateRange: [new Date().getTime() - 3600 * 1000 * 24, new Date().getTime()],
        // 筛选数据
        filterForm: {
          startDate: null, // 开始时间
          endDate: null, // 结束时间
          collectorIdList: [], // 催收员
          groupIdList: [], // 催收组
          managerIdList: [], // 催收经理
          mechanIdList: [] // 催收机构
        },
        // 催收员列表
        collectorList: [],
        collectorTempList: [], // 联动过滤后下拉列表
        collectorFilterList: [], // 过滤后下拉列表
        collectorLoading: false,
        // 催收经理列表
        collectionManagerList: [],
        collectionManagerFilterList: [], // 过滤后下拉列表
        // 催收组列表
        collectionGroupList: [],
        collectionGroupFilterList: [], // 过滤后下拉列表
        // 催收机构列表
        collectionAgenciesList: []
      }
    },
    mounted () {
      this.getAllMechanList()
    },
    methods: {
      // 获取催收机构列表
      getAllMechanList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionAgenciesList && this.collectionAgenciesList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionOrganizationList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionAgenciesList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchAllMechanVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionAgenciesList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionOrganizationList', JSON.stringify(this.collectionAgenciesList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取催收经理列表
      getAllManagerList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionManagerList && this.collectionManagerList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionManagerList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionManagerList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              findAllManagerVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionManagerList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionManagerList', JSON.stringify(this.collectionManagerList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取催收组列表
      getAllGroupList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionGroupList && this.collectionGroupList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionGroupList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionGroupList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              findAllGroupVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionGroupList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionGroupList', JSON.stringify(this.collectionGroupList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取催收员列表
      getAllCollectorList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectorList && this.collectorList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionCollectorList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectorList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchAllCollectorVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectorList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionCollectorList', JSON.stringify(this.collectorList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },

      // 催收机构 下拉框出现/隐藏时触发
      handleMechanVisibleChange (visible) {
        if (visible) {
          // 用Promise保证执行顺序 先获取到数据再过滤
          // 先获取总数据
          this.getAllMechanList().then(() => {
            // 然后过滤数据
          })
        }
      },
      // 催收经理 下拉框出现/隐藏时触发
      handleManagerVisibleChange (visible) {
        if (visible) {
          this.getAllManagerList().then(() => {
            // 然后过滤数据 mechanismId
            // 机构下拉框没选 返回全部
            if (this.filterForm.mechanIdList.length === 0) {
              this.collectionManagerFilterList = JSON.parse(JSON.stringify(this.collectionManagerList))
            } else {
              this.collectionManagerFilterList = this.collectionManagerList.filter(item => {
                return this.filterForm.mechanIdList.join(',').indexOf(item.mechanismId) >= 0
              })
            }
          })
        }
      },
      // 催收组 下拉框出现/隐藏时触发
      handleGroupVisibleChange (visible) {
        if (visible) {
          this.getAllGroupList().then(() => {
            // 然后过滤数据
            // 机构、经理下拉框都没选 返回全部
            if (this.filterForm.mechanIdList.length === 0 && this.filterForm.managerIdList.length === 0) {
              this.collectionGroupFilterList = JSON.parse(JSON.stringify(this.collectionGroupList))
            } else {
              this.collectionGroupFilterList = this.collectionGroupList.filter(item => {
                // 机构、经理下拉框
                if (this.filterForm.managerIdList.length > 0) { // 经理选了 返回经理下面的组
                  return this.filterForm.managerIdList.join(',').indexOf(item.managerId) >= 0
                } else if (this.filterForm.mechanIdList.length > 0) { // 经理没选、机构选了 返回机构下面的组
                  return this.filterForm.mechanIdList.join(',').indexOf(item.mechanismId) >= 0
                } else {
                  return false
                }
              })
            }
          })
        }
      },
      // 催收员 下拉框出现/隐藏时触发
      handleCollectorVisibleChange (visible) {
        if (visible) {
          this.getAllCollectorList().then(() => {
            // 然后过滤数据 mechanismId groupId
            // 机构、经理、组下拉框都没选 返回全部
            if (this.filterForm.mechanIdList.length === 0 && this.filterForm.managerIdList.length === 0 &&
              this.filterForm.groupIdList.length === 0) {
              this.collectorTempList = JSON.parse(JSON.stringify(this.collectorList))
            } else {
              this.collectorTempList = this.collectorList.filter(item => {
                // 机构、经理、组下拉框
                if (this.filterForm.groupIdList.length > 0) { // 选了组 就取组下面的员
                  return this.filterForm.groupIdList.join(',').indexOf(item.groupId) >= 0
                } else if (this.filterForm.managerIdList.length > 0) { // 没选组 选了经理 就取经理下面的员
                  return this.filterForm.managerIdList.join(',').indexOf(item.managerId) >= 0
                } else if (this.filterForm.mechanIdList.length > 0) { // 没选组、经理，选了机构 就取机构下面的员
                  return this.filterForm.mechanIdList.join(',').indexOf(item.mechanismId) >= 0
                } else {
                  return false
                }
              })
            }
          })
        }
      },
      filterCollector (query) {
        if (query !== '') {
          this.collectorLoading = true
          this.collectorFilterList = this.collectorTempList.filter(item => {
            return item.displayName.trim().indexOf(query.trim()) > -1
          })
          this.collectorLoading = false
        } else {
          this.collectorFilterList = []
        }
      },
      handleSearchData () {
        this.filterForm.startDate = parseTime(this.dateRange[0], 'YYYY-MM-DD')
        this.filterForm.endDate = parseTime(this.dateRange[1], 'YYYY-MM-DD')
        if (this.filterForm.mechanIdList && this.filterForm.mechanIdList.length === 0) {
          this.collectionAgenciesList.forEach(item => {
            this.filterForm.mechanIdList.push(item.id)
          })
        }
        this.$emit('search', this.filterForm)
      },
      handleExportData () {
        if (this.filterForm.mechanIdList && this.filterForm.mechanIdList.length === 0) {
          this.collectionAgenciesList.forEach(item => {
            this.filterForm.mechanIdList.push(item.id)
          })
        }
        this.$emit('export', this.filterForm)
      }
    }
  }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  .filter-form {
    .length-2 {
      width: 200px;
    }
    .length-3 {
      width: 220px;
    }
    .el-form-item {
      margin-bottom: 5px;
    }
  }
</style>
