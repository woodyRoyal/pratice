<!-- 短信模板 -->
<template>
  <div class="sms-template-wrapper">
    <el-form :inline="true" :model="filterForm" class="filter-form">
      <el-form-item>
        <el-button type="success" size="small" @click="addTemplate">添加模板</el-button>
      </el-form-item>
      <el-form-item label="产品">
        <vue-el-select multiple size="small" v-model="filterForm.appCodeList" placeholder="请选择">
          <el-option
            v-for="item in appCodeListNew"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn">搜索</el-button>
      </el-form-item>
    </el-form>

    <!-- table开始 -->
    <el-table :data="tableData" v-loading="listLoading" border stripe style="width: 100%" :max-height="tableHeight">
      <el-table-column align="center" prop="createAt" label="时间" min-width="100"></el-table-column>
      <el-table-column align="center" prop="operatorName" label="操作员" min-width="60"></el-table-column>
      <el-table-column align="center" label="产品" min-width="60">
        <template slot-scope="scope">
          <span v-if="scope.row.productId != 0">{{ appType[scope.row.productId]}}</span>
          <span v-else>通用</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="name" label="模板名称" min-width="80"></el-table-column>
      <el-table-column align="center" prop="content" label="短信内容" min-width="300"></el-table-column>
      <el-table-column align="center" label="操作" min-width="130">
        <template slot-scope="scope">
          <el-button type="primary" size="mini" @click="editTemplate(scope.row)">修改</el-button>
          <el-button type="danger" size="mini" @click="deleteTemplate(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- table结束 -->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

    <!-- 弹窗 -->
    <el-dialog :title="dialogTitle" :visible.sync="dialogSmsTemplate" @close="handleDialogClose">
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <!--<el-form-item label="接收人" prop="rcptType">-->
          <!--<el-radio-group v-model="ruleForm.rcptType">-->
            <!--<el-radio :label="1">To本人</el-radio>-->
            <!--<el-radio :label="2">To联系人</el-radio>-->
          <!--</el-radio-group>-->
        <!--</el-form-item>-->
        <el-form-item label="短信通道" prop="smsChannelId">
          <el-radio-group v-model="ruleForm.smsChannelId">
            <el-radio v-for="item in smsChannelList" :label="item.paramCode" :key="item.id" @change="smsChannelIdChange(item)">{{ item.paramName }}</el-radio>
          </el-radio-group>
        </el-form-item>
        <!--<el-form-item label="APP" prop="productAppCode">-->
          <!--<el-radio-group v-model="ruleForm.productAppCode">-->
            <!--<el-radio v-for="item in appCodeList" :label="item.paramCode" :key="item.id">{{ item.paramName }}</el-radio>-->
          <!--</el-radio-group>-->
        <!--</el-form-item>-->
        <el-form-item label="模板名称" prop="name">
          <el-input v-model="ruleForm.name" placeholder="请输入模板名称"></el-input>
        </el-form-item>
        <el-form-item label="短信内容" prop="content">
          <div class="insert-content">
            <el-button v-for="(item, index) in insertContentList" :key="index" size="mini"
                       type="text" @click="insertValue('textarea', item)">
              {{ item }}
            </el-button>
          </div>
          <el-input id="textarea" type="textarea" :maxlength="maxContentLength" resize="none" :rows="4"
                    placeholder="请输入短信内容" v-model="ruleForm.content" @input="handleContentPrompt"
                    @blur="handleContentPrompt" @focus="handleContentPrompt" @change="handleContentPrompt">
          </el-input>
          <span>已输入{{ contentLength }}字符（最多{{ maxContentLength }}个，一条短信140个字符，注意预留参数的字符数量）</span>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleAddOrEditCancel">取 消</el-button>
        <el-button type="primary"  @click="handleAddOrEditConfirm">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import VueElSelect from '../../components/VueElSelect'
  import { insertAtCursor } from '../../utils'
  import { INSERT_CONTENT_LIST, INSERT_CONTENT_COMMON_LIST } from './smsConstant'
  import {
    fetchGetSmsChannelList, // 获取短信渠道列表
    fetchGetSmsTemplateList, // 获取短信模板列表
    fetchSaveOrUpdateSmsTemplate, // 新增短信模板
    fetchValidSmsTemplateName, // 验证模板明是否可用
    fetchRemoveSmsTemplateById // 删除模板
  } from '../../api/sms'

  export default {
    components: {
      VueElSelect
    },
    data () {
      // 校验短信内容
      const validateContent = (rule, value, callback) => {
        if (!value) {
          callback(new Error('请输入短信内容'))
        } else if (value.length > this.maxContentLength) {
          callback(new Error('已超出输入限制'))
        } else {
          callback()
        }
      }

      // 校验模板名称
      const validateName = (rule, value, callback) => {
        if (!value) {
          callback(new Error('请输入模板名称'))
        } else if (value.length > 20) {
          callback(new Error('已超出输入限制20字符'))
        } else if (this.ruleForm.name === value) {
          callback()
        } else {
          fetchValidSmsTemplateName(value)
            .then(response => {
              let res = response.data
              if (res.errorCode === 0 && res.data) {
                callback()
              } else {
                callback(new Error('模板名称已存在'))
              }
            })
            .catch(error => {
              console.log(error)
            })
        }
      }
      return {
        smsChannelList: [], // 所有短信通道
        insertContentList: INSERT_CONTENT_LIST, // 通知（通知）插值内容
        filterForm: {
          appCodeList: [] // 选择的产品类型
        },
        appCodeListNew: [], // 增加通用后的产品类型
        // 增加通用产品类型
        appCodeListAdd: [
          {id: 0, 'name': '通用'}
        ],
        // 表格高度
        tableHeight: 600,
        listLoading: false,
        // 表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 50, 100, 500],
        // 弹窗
        dialogTitle: '增加短信模板',
        dialogSmsTemplate: false,
        ruleForm: {
          // rcptType: null, // 接收人
          smsChannelId: null, // 短信通道
          // productAppCode: null, // app
          name: '', // 模板名称
          content: '' // 短信内容
        },
        maxContentLength: 420, // 最大字数限制
        contentLength: 0, // 短信内容 已输入字数
        rules: {
          //          rcptType: [
          //            { required: true, message: '请选择接收人', trigger: 'change' }
          //          ],
          smsChannelId: [
            { required: true, message: '请选择短信通道', trigger: 'change' }
          ],
          //          productAppCode: [
          //            { required: true, message: '请选择产品类型', trigger: 'change' }
          //          ],
          name: [
            { validator: validateName, trigger: 'blur' }
          ],
          content: [
            { validator: validateContent, trigger: 'blur' }
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'appCodeList', // 产品类型
        'appType' // 产品类型常量
      ])
    },
    created () {
      // 获取产品类型
      this.getProductType()
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
      // 获取短信通道
      this.getSmsChannelList()
      // 获取table数据
      this.getTableData()
      // 产品选项增加通用项
      this.appCodeListNew = this.appCodeList.concat(this.appCodeListAdd)
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // 短信通道改变事件
      smsChannelIdChange (item) {
        console.log(item.paramName)
        if (item.paramName.indexOf('通用') !== -1) {
          this.insertContentList = INSERT_CONTENT_COMMON_LIST
        } else {
          this.insertContentList = INSERT_CONTENT_LIST
        }
      },
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let h = document.documentElement.clientHeight
          this.tableHeight = h - 146
        })
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 处理通知内容字数提示
      handleContentPrompt () {
        this.ruleForm.content = document.getElementById('textarea').value
        let content = this.ruleForm.content
        this.contentLength = content.length
      },
      // 获取产品类型
      getProductType () {
        if (!this.appCodeList.length) {
          this.$store.dispatch('GetAppCodeList')
            .then(res => {
            })
            .catch(err => {
              console.log(err)
            })
        }
      },
      // 获取短信通道
      getSmsChannelList () {
        fetchGetSmsChannelList()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.smsChannelList = res.data.map(item => {
                item.paramCode = Number(item.paramCode)
                return item
              })
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 搜索
      searchBtn () {
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        this.listLoading = true
        fetchGetSmsTemplateList(JSON.stringify(this.filterForm.appCodeList), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 添加模板
      addTemplate () {
        this.dialogSmsTemplate = true
      },
      // 修改模板
      editTemplate (sms) {
        this.dialogSmsTemplate = true
        this.ruleForm = JSON.parse(JSON.stringify(sms))
        console.log(this.ruleForm)
        // 字数
        this.contentLength = this.ruleForm.content.length
      },
      // 删除btn
      deleteTemplate (sms) {
        this.$confirm('此操作将删除该模板, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.removeSmsTemplateById(sms.id)
        }).catch(() => {
          console.log('取消删除')
        })
      },
      // 删除模板
      removeSmsTemplateById (templateId) {
        fetchRemoveSmsTemplateById(templateId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success('删除成功!')
              this.getTableData()
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // Dialog 关闭的回调
      handleDialogClose () {
        this.ruleForm = {
          // rcptType: '', // 接收人
          smsChannelId: null, // 短信通道
          name: '', // 模板名称
          content: '' // 短信内容
        }
        this.contentLength = 0
        this.resetForm('ruleForm')
      },
      // 取消
      handleAddOrEditCancel () {
        this.dialogSmsTemplate = false
      },
      // 确定（添加或修改）
      handleAddOrEditConfirm () {
        this.submitForm('ruleForm')
      },
      // 新增或修改
      saveOrUpdateSmsTemplate () {
        fetchSaveOrUpdateSmsTemplate(JSON.stringify(this.ruleForm))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.dialogSmsTemplate = false
              this.$message.success('操作成功')
              this.getTableData()
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            console.log('submit!')
            this.saveOrUpdateSmsTemplate()
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      // 插入标签
      insertValue (id, item) {
        insertAtCursor(document.getElementById(id), item)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .sms-template-wrapper {
    .filter-form {
      .el-form-item {
        margin-bottom: 5px;
      }
    }

    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }

    .insert-content {
      border: 1px solid #bfcbd9;
      border-bottom: none;
      background: #f5f7fa;
      line-height: 26px;
      .el-button {
        margin-left: 6px;
        padding: 4px;
      }
      .el-button--text:focus, .el-button--text:hover{
        background: #fff;
      }
    }
  }
</style>