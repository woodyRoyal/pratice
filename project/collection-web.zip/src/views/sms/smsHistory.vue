<!-- 短信历史 -->
<template>
  <div class="sms-history-wrapper">
    <!-- 案件 -->
    <div class="sms-history-form">
      <p>
        无效手机号码，将不会发送短信；
      </p>
      <p>
        已还清欠款的案件本人与联系人，将不会发送短信；
      </p>
      <p>
        上次电话结果为“查无此人/停机、空号、呼入限制”的手机号，将不会发送短信。
      </p>
    </div>

    <!-- 筛选条件 -->
    <el-form :inline="true" :model="filterForm" class="filter-form">

      <el-form-item label="起始时间：">
        <!--<el-date-picker-->
          <!--v-model="date"-->
          <!--type="datetimerange"-->
          <!--size="small"-->
          <!--class="length-3"-->
          <!--:editable="false"-->
          <!--:clearable="false"-->
          <!--:picker-options="pickerOptions1"-->
          <!--range-separator="至"-->
          <!--start-placeholder="开始日期"-->
          <!--end-placeholder="结束日期">-->
        <!--</el-date-picker>-->
        <el-date-picker
          class="length-1"
          v-model="date"
          type="date"
          size="small"
          :editable="false"
          :clearable="false"
          :picker-options="pickerOptions1"
          placeholder="选择日期">
        </el-date-picker>
        <el-time-picker
          class="length-2"
          is-range
          v-model="time"
          size="small"
          :editable="false"
          :clearable="false"
          range-separator="-"
          start-placeholder="开始时间"
          end-placeholder="结束时间"
          placeholder="选择时间范围">
        </el-time-picker>
      </el-form-item>

      <el-form-item v-if="showSelectObj.isShowGroupSelect">
        <vue-el-select v-model="filterForm.groupIdList" multiple filterable placeholder="请选择催收组" size="small"
                       @visible-change="handleGroupVisibleChange">
          <el-option
            v-for="item in collectionGroupFilterList"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>

      <el-form-item v-if="showSelectObj.isShowPersonSelect">
        <vue-el-select v-model="filterForm.collectorIdList" multiple filterable remote placeholder="请输入催收员" size="small"
                       @visible-change="handleCollectorVisibleChange" :remote-method="filterCollector"
                       :loading="collectorLoading">
          <el-option
            v-for="item in collectorFilterList"
            :key="item.id"
            :label="item.displayName"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>

      <el-form-item label="手机号码：">
        <el-input v-model="filterForm.phoneNum" size="small"
                  class="length-1" placeholder="请输入手机号码"></el-input>
      </el-form-item>

      <el-form-item label="产品">
        <vue-el-select multiple class="length-1" size="small" v-model="filterForm.appCodeList" placeholder="请选择">
          <el-option
            v-for="item in appCodeListNew"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn">搜索</el-button>
      </el-form-item>
    </el-form>

    <!-- table开始 -->
    <el-table :data="tableData" v-loading="listLoading" border stripe style="width: 100%" :max-height="tableHeight">
      <el-table-column align="center" prop="createAtSms" label="发送时间" min-width="120"></el-table-column>
      <el-table-column align="center" prop="displayName" label="发送者" min-width="60"></el-table-column>
      <el-table-column align="center" label="案件" min-width="60">
        <template slot-scope="scope">
          <span class="to-case-detail" @click="toCaseDetail(scope.row.caseId)">{{ scope.row.debtName }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="contactName" label="接收人" min-width="80"></el-table-column>
      <el-table-column align="center" prop="phone" label="手机号" min-width="80"></el-table-column>
      <el-table-column align="center" prop="msg" label="发送结果" min-width="100"></el-table-column>
      <el-table-column align="center" label="产品" min-width="100">
        <template slot-scope="scope">
          <span v-if="scope.row.productId != 0">{{ appType[scope.row.productId] }}</span>
          <span v-else>通用</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="tempName" label="模板名称" min-width="100"></el-table-column>
      <el-table-column align="center" prop="content" label="短信内容" min-width="300"></el-table-column>
    </el-table>
    <!-- table结束 -->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { parseTime } from '../../utils/formatDate'
  import VueElSelect from '../../components/VueElSelect'
  import {
    fetchAllCollectorVOList,
    findAllGroupVOList
  } from '../../api/common'
  import getFirstLetter from 'utils/chineseToPhoneticInitial'
  import {
    fetchGetSmsHistoryList // 获取短信历史列表
  } from '../../api/sms'

  export default {
    data () {
      return {
        date: new Date(), // 日期
        time: [new Date().getTime() - 3600 * 1000, new Date().getTime()], // 时间
        pickerOptions1: {
          disabledDate (time) {
            return time.getTime() > Date.now()
          }
        },
        appCodeListNew: [], // 增加通用后的产品类型
        // 增加通用产品类型
        appCodeListAdd: [
          {id: 0, 'name': '通用'}
        ],
        // 筛选条件
        filterForm: {
          startDate: null,
          endDate: null,
          appCodeList: [], // 选中的app
          collectorIdList: [], // 催收员
          groupIdList: [], // 催收组
          phoneNum: ''
        },
        // 催收员列表
        collectorList: [],
        collectorTempList: [], // 联动过滤后下拉列表
        collectorFilterList: [], // 输入过滤后下拉列表
        collectorLoading: false,

        // 催收组列表
        collectionGroupList: [],
        collectionGroupFilterList: [], // 过滤后下拉列表
        // 表格高度
        tableHeight: 600,
        listLoading: false,
        // 表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 50, 100, 500]
      }
    },
    computed: {
      ...mapGetters([
        'appCodeList', // 产品类型
        'appType', // 产品类型常量
        'showSelectObj'
      ])
    },
    components: {
      VueElSelect
    },
    created () {
      // 获取产品类型
      this.getProductType()
    },
    mounted () {
      // this.getTableData()
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
      // 产品选项增加通用项
      this.appCodeListNew = this.appCodeList.concat(this.appCodeListAdd)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        let h = document.documentElement.clientHeight
        this.tableHeight = h - 296
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 获取产品类型
      getProductType () {
        if (!this.appCodeList.length) {
          this.$store.dispatch('GetAppCodeList')
            .then(res => {
            })
            .catch(err => {
              console.log(err)
            })
        }
      },
      // 搜索
      searchBtn () {
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        //        if (parseTime(this.date[0], 'YYYY-MM-DD') !== parseTime(this.date[1], 'YYYY-MM-DD')) {
        //          this.$message.warning('只能查询时间范围为一天内的数据!')
        //          return false
        //        }
        if (this.filterForm.phoneNum && !(/^1[3|4|5|8][0-9]\d{4,8}$/.test(this.filterForm.phoneNum))) {
          this.$message.warning('手机号格式不正确')
          return false
        }
        this.listLoading = true
        this.filterForm.startDate = parseTime(this.date, 'YYYY-MM-DD') + ' ' + parseTime(this.time[0], 'HH:mm:ss')
        this.filterForm.endDate = parseTime(this.date, 'YYYY-MM-DD') + ' ' + parseTime(this.time[1], 'HH:mm:ss')
        let queryForm = {
          startDate: this.filterForm.startDate,
          endDate: this.filterForm.endDate,
          groupIds: this.filterForm.groupIdList,
          userIds: this.filterForm.collectorIdList,
          productIdList: this.filterForm.appCodeList,
          phone: this.filterForm.phoneNum
        }
        fetchGetSmsHistoryList(JSON.stringify(queryForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 获取催收组列表
      getAllGroupList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionGroupList && this.collectionGroupList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionGroupList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionGroupList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              findAllGroupVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionGroupList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionGroupList', JSON.stringify(this.collectionGroupList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取催收员列表
      getAllCollectorList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectorList && this.collectorList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionCollectorList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectorList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchAllCollectorVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectorList = res.data
                    let _this = this
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionCollectorList', JSON.stringify(this.collectorList))
                    // 中文转拼音首字母
                    setTimeout(() => {
                      _this.handleChineseToPhoneticInitial()
                    }, 100)
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 催收组 下拉框出现/隐藏时触发
      handleGroupVisibleChange (visible) {
        if (visible) {
          this.getAllGroupList().then(() => {
            this.collectionGroupFilterList = JSON.parse(JSON.stringify(this.collectionGroupList))
          })
        }
      },
      // 催收员 下拉框出现/隐藏时触发
      handleCollectorVisibleChange (visible) {
        if (visible) {
          this.getAllCollectorList().then(() => {
            // 然后过滤数据 mechanismId groupId
            if (this.filterForm.groupIdList.length === 0) {
              this.collectorTempList = JSON.parse(JSON.stringify(this.collectorList))
            } else {
              this.collectorTempList = this.collectorList.filter(item => {
                // 机构、组下拉框
                if (this.filterForm.groupIdList.length > 0) { // 组选了 返回组下面的
                  return this.filterForm.groupIdList.join(',').indexOf(item.groupId) >= 0
                } else {
                  return false
                }
              })
            }
          })
        }
      },
      // 根据输入过滤催收员列表
      filterCollector (query) {
        console.time('filterCollector')
        if (query !== '') {
          this.testinput = query
          this.collectorLoading = true
          this.collectorFilterList = []
          if (this.collectorTempList && this.collectorTempList.length > 0) {
            for (let i = 0, len = this.collectorTempList.length; i < len; i++) {
              if (this.collectorTempList[i].displayName.trim().indexOf(query.trim()) > -1 ||
                (this.collectorTempList[i].phoneticInitial && this.collectorTempList[i].phoneticInitial.indexOf(query.trim().toUpperCase()) > -1)) {
                this.collectorFilterList.push(this.collectorList[i])
              }
            }
          }
          this.collectorLoading = false
        } else {
          this.collectorFilterList = []
        }
        console.timeEnd('filterCollector')
      },
      handleChineseToPhoneticInitial () {
        console.time('handleChineseToPhoneticInitial')
        if (this.collectorList && this.collectorList.length > 0) {
          for (let index in this.collectorList) {
            this.collectorList[index].phoneticInitial = getFirstLetter(this.collectorList[index].displayName).join(',')
          }
          // 存入本地
          window.localStorage.setItem('Collection-CollectionCollectorList', JSON.stringify(this.collectorList))
        }
        console.timeEnd('handleChineseToPhoneticInitial')
      },
      // 跳转到案件详情
      toCaseDetail (caseId) {
        window.open('#/case-detail/' + caseId)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .sms-history-wrapper {
    .sms-history-form {
      font-size: 12px;
      border-bottom: 1px solid #bbb;
    }

    .el-form-item {
       margin-bottom: 5px;
    }
    .length-1 {
      width: 140px;
    }
    .length-2 {
      width: 180px;
    }
    .length-3 {
      width: 360px;
    }
    .to-case-detail {
      color: blue;
      cursor: pointer;
      &:hover {
        text-decoration: underline;
      }
    }
  }
</style>