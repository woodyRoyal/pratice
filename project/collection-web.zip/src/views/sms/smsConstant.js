/* 短信管理常量 */

// 插入值
export const INSERT_CONTENT_LIST = [
  '欠款人名字', '欠款金额', '逾期天数', '逾期月份'
]

// 插入值
export const INSERT_CONTENT_COMMON_LIST = [
  '欠款人名字', '所有逾期产品'
]
