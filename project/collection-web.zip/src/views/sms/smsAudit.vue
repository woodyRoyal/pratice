<!-- 短信审核 -->
<template>
  <div class="sms-audit-wrapper">

    <!-- 筛选条件 -->
    <el-form :inline="true" :model="filterForm" class="filter-form">

      <el-form-item label="起始时间：">
        <!--<el-date-picker-->
          <!--v-model="date"-->
          <!--type="datetimerange"-->
          <!--size="small"-->
          <!--:editable="false"-->
          <!--:clearable="false"-->
          <!--:picker-options="pickerOptions1"-->
          <!--range-separator="至"-->
          <!--start-placeholder="开始日期"-->
          <!--end-placeholder="结束日期">-->
        <!--</el-date-picker>-->
        <el-date-picker
          class="length-1"
          v-model="date"
          type="date"
          size="small"
          :editable="false"
          :clearable="false"
          :picker-options="pickerOptions1"
          placeholder="选择日期">
        </el-date-picker>
        <el-time-picker
          class="length-2"
          is-range
          v-model="time"
          size="small"
          :editable="false"
          :clearable="false"
          range-separator="-"
          start-placeholder="开始时间"
          end-placeholder="结束时间"
          placeholder="选择时间范围">
        </el-time-picker>
      </el-form-item>

      <el-form-item label="APP">
        <vue-el-select multiple size="small" v-model="filterForm.appCodeList" placeholder="请选择">
          <el-option
            v-for="item in appCodeList"
            :key="item.id"
            :label="item.paramName"
            :value="item.paramCode">
          </el-option>
        </vue-el-select>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn">搜索</el-button>
      </el-form-item>
      <el-form-item style="float: right;">
        <span>已选择 {{ multipleSelection.length }} 人</span>
        <el-button type="success" size="small" @click="batchAudit(1)">通过</el-button>
        <el-button type="danger" size="small" @click="batchAudit(2)">拒绝</el-button>
      </el-form-item>
    </el-form>

    <!-- table开始 -->
    <el-table :data="tableData" v-loading="listLoading" border stripe style="width: 100%" :max-height="tableHeight"
              ref="multipleTable" @selection-change="handleSelectionChange">
      <el-table-column align="center" type="selection" width="55" :selectable="selectable"></el-table-column>
      <el-table-column align="center" prop="createAt" label="发送时间" min-width="120"></el-table-column>
      <el-table-column align="center" prop="collectorName" label="发送者" min-width="60"></el-table-column>
      <el-table-column align="center" prop="debtorName" label="案件" min-width="60">
        <template slot-scope="scope">
          <span class="to-case-detail" @click="toCaseDetail(scope.row.caseId)">{{ scope.row.debtorName }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="逾期阶段" min-width="80">
        <template slot-scope="scope">
          <span>{{ 'M' + scope.row.overdueLevel }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="APP" min-width="100">
        <template slot-scope="scope">
          <span>{{ appType[scope.row.productAppCode] }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="模板名称" min-width="100">
        <template slot-scope="scope">
          <div v-if="scope.row.debtorTempletName && scope.row.contactTempletName">
            <div>{{ scope.row.debtorTempletName }}</div>
            <div>{{ scope.row.contactTempletName }}</div>
          </div>
          <span v-else>
            {{ scope.row.debtorTempletName || scope.row.contactTempletName }}
          </span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="发送数量" min-width="100">
        <template slot-scope="scope">
          <span>{{ (scope.row.debtorNum || 0) + (scope.row.contactNum || 0) }}</span>
          <span>({{ scope.row.debtorNum || 0 }}+</span>
          <span>{{ scope.row.contactNum || 0 }})</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="操作" min-width="100">
        <template slot-scope="scope">
          <div v-if="scope.row.status === 1">已通过</div>
          <div v-if="scope.row.status === 2">已拒绝</div>
          <div v-if="scope.row.status === 0">
            <el-button type="success" size="mini" @click="passAudit(scope.row, 1)">通过</el-button>
            <el-button type="danger" size="mini" @click="passAudit(scope.row, 2)">拒绝</el-button>
          </div>
        </template>
      </el-table-column>
    </el-table>
    <!-- table结束 -->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { parseTime } from '../../utils/formatDate'
  import VueElSelect from '../../components/VueElSelect'
  import {
    fetchGetSmsAuditList,
    fetchSmsAudit
  } from '../../api/sms'

  export default {
    data () {
      return {
        date: new Date(), // 日期
        time: [new Date().getTime() - 3600 * 1000, new Date().getTime()], // 时间
        pickerOptions1: {
          disabledDate (time) {
            return time.getTime() > Date.now()
          }
        },
        // 筛选条件
        filterForm: {
          startDate: null, // 开始时间
          endDate: null, // 结束时间
          appCodeList: []
        },
        // 表格高度
        tableHeight: 600,
        listLoading: false,
        // 表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 50, 100, 500],
        multipleSelection: [],
        auditIds: [] // 已选择短信id组
      }
    },
    computed: {
      ...mapGetters([
        'appCodeList', // 产品类型
        'appType' // 产品类型常量
      ])
    },
    components: {
      VueElSelect
    },
    created () {
      // 获取产品类型
      this.getProductType()
    },
    mounted () {
      // this.getTableData()
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        let h = document.documentElement.clientHeight
        this.tableHeight = h - 172
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 获取产品类型
      getProductType () {
        if (!this.appCodeList.length) {
          this.$store.dispatch('GetAppCodeList')
            .then(res => {
            })
            .catch(err => {
              console.log(err)
            })
        }
      },
      // 搜索
      searchBtn () {
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        //        if (parseTime(this.date[0], 'YYYY-MM-DD') !== parseTime(this.date[1], 'YYYY-MM-DD')) {
        //          this.$message.warning('只能查询时间范围为一天内的数据!')
        //          return false
        //        }
        this.listLoading = true
        this.filterForm.startDate = parseTime(this.date, 'YYYY-MM-DD') + ' ' + parseTime(this.time[0], 'HH:mm:ss')
        this.filterForm.endDate = parseTime(this.date, 'YYYY-MM-DD') + ' ' + parseTime(this.time[1], 'HH:mm:ss')
        let queryForm = {
          startDate: this.filterForm.startDate,
          endDate: this.filterForm.endDate,
          appCodeList: this.filterForm.appCodeList
        }
        fetchGetSmsAuditList(JSON.stringify(queryForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // single审核
      passAudit (audit, isPass) {
        let auditMsg = ''
        if (isPass === 1) {
          auditMsg = '此操作将通过该短信的审核, 是否继续?'
        } else {
          auditMsg = '此操作将拒绝该短信的审核, 是否继续?'
        }
        this.$confirm(auditMsg, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let arr = []
          arr.push(audit.id)
          this.smsAudit(arr, isPass)
        }).catch(() => {
        })
      },
      // 审核
      smsAudit (smsIdList, isPass) {
        // 1：通过，2：拒绝
        fetchSmsAudit(JSON.stringify(smsIdList), JSON.parse(isPass))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              isPass === 2 ? this.$message.success('拒绝成功') : this.$message.success('通过成功')
              this.getTableData()
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 批量审批
      batchAudit (isPass) {
        if (!this.multipleSelection.length) {
          this.$message.warning('未有数据选中')
          return false
        }
        let auditMsg = ''
        if (isPass === 1) {
          auditMsg = '此操作将批量通过已选择短信的审核, 是否继续?'
        } else {
          auditMsg = '此操作将批量拒绝已选择短信的审核, 是否继续?'
        }
        this.$confirm(auditMsg, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.smsAudit(this.auditIds, isPass)
        }).catch(() => {
        })
      },
      handleSelectionChange (val) {
        let arr = []
        this.multipleSelection = val
        this.multipleSelection.map(item => {
          arr.push(item.id)
          return item
        })
        this.auditIds = arr
        console.log(val)
      },
      // 是否可以勾选
      selectable (row, index) {
        console.log(row)
        // status 1 已通过 2 已拒绝 状态不可以勾选    0  未审核 状态 可以勾选
        if (row.status === 1 || row.status === 2) {
          return false
        } else {
          return true
        }
      },
      // 跳转到案件详情
      toCaseDetail (caseId) {
        window.open('#/case-detail/' + caseId)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .sms-audit-wrapper {

    .el-form-item {
      margin-bottom: 5px;
    }

    .length-1 {
      width: 140px;
    }
    .length-2 {
      width: 180px;
    }
    .to-case-detail {
      color: blue;
      cursor: pointer;
      &:hover {
        text-decoration: underline;
      }
    }
  }
</style>