<!-- 工作台数据 -->
<template>
  <div class="bench-data-wrapper">
    <!-- 筛选条件开始 -->
    <collection-bench-query-terms @search="searchBtn" @export="exportBtn">
    </collection-bench-query-terms>
    <!-- 筛选条件结束 -->

    <!-- 工作台数据开始-->
    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
      <el-table-column align="center" prop="createAt" label="任务生成时间" min-width="50"></el-table-column>
      <el-table-column align="center" prop="companyName" label="机构" min-width="40"></el-table-column>
      <el-table-column align="center" prop="teamName" label="催收组" min-width="50"></el-table-column>
      <el-table-column align="center" prop="collectorName" label="催收员" min-width="40"></el-table-column>
      <el-table-column align="center" prop="name" label="任务名称" min-width="40"></el-table-column>
      <el-table-column align="center" prop="callTimes" label="拨打电话数" min-width="40"></el-table-column>
      <el-table-column align="center" prop="calledTimes" label="呼通数" min-width="40"></el-table-column>
      <el-table-column align="center" prop="connectedTimes" label="接通数" min-width="40"></el-table-column>
      <el-table-column align="center" prop="calledRate" label="呼通率" min-width="40">
        <template slot-scope="scope">
          <span>{{ parseInt(scope.row.calledRate * 10000) / 100 + '%' }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="connectedRate" label="接通率" min-width="40">
        <template slot-scope="scope">
          <span>{{ parseInt(scope.row.connectedRate * 10000) / 100 + '%' }}</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 工作台数据结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
  </div>
</template>

<script>
  import { parseTime } from '../../utils/formatDate'
  import CollectionBenchQueryTerms from '../components/CollectionBenchQueryTerms'
  import VueElTooltip from '../../components/VueElTooltip'
  import { TABLE_TITLE_TIP } from './csmConstant'
  import {
    fetchGetBenchData,
    URL_EXPORT_BENCH_DATA
  } from '../../api/csm'
  import { POSITION_STATUS } from '../quality/qualityConstant'
  import { CONST_OVERDUE_LEVEL_MAP } from '../case/caseConstant'

  export default {
    components: {
      CollectionBenchQueryTerms, VueElTooltip
    },
    data () {
      return {
        // 筛选数据
        filterForm: {},
        // 质检明细表格高度
        tableHeight: 600,
        listLoading: false,
        // 质检明细表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 50, 100, 500],
        POSITION_STATUS, // 职位状态
        overdueLevelMap: CONST_OVERDUE_LEVEL_MAP // 逾期阶段字符串映射
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          let h = document.documentElement.clientHeight
          if (formHeight >= 90) {
            this.tableHeight = h - 189
          } else if (formHeight >= 45) {
            this.tableHeight = h - 144
          }
        })
      },
      deactivated () {
        window.removeEventListener('resize', this.handleResize)
      },
      beforeDestroy () {
        window.removeEventListener('resize', this.handleResize)
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        // 获取表格数据
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        // 获取表格数据
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        // 列表开始加载
        this.listLoading = true
        fetchGetBenchData(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 搜索按钮
      searchBtn (queryData) {
        this.filterForm = queryData
        this.getTableData()
      },
      // 导出按钮
      exportBtn (queryData) {
        this.filterForm = queryData
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = URL_EXPORT_BENCH_DATA + '?fileName=工作台数据-' + date + '.csv&paramBo=' + encodeURI(JSON.stringify(this.filterForm))
        window.location.href = url
      },
      // 表头
      renderHeader (createElement, {column}) {
        return createElement(VueElTooltip, {
          props: {
            label: column.label,
            content: TABLE_TITLE_TIP[column.property]
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .bench-data-wrapper {
    .el-form-item {
      margin-bottom: 5px;
    }
    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }
  }
</style>
