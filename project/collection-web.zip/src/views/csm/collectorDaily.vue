<!-- 催收员工作量日报 -->
<template>
  <div class="collector-daily-wrapper">
    <!-- 筛选条件开始 -->
    <collection-query-terms @search="searchBtn" @export="exportBtn">
    </collection-query-terms>
    <!-- 筛选条件结束 -->

    <!-- 催收员工作量日报开始-->
    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
      <el-table-column align="center" prop="reportDate" label="日期" min-width="50">
        <template slot-scope="scope">
          <span v-show="scope.row.weekNo === 6" style="color: green;">{{ scope.row.reportDate }}</span>
          <span v-show="scope.row.weekNo === 0" style="color: red;">{{ scope.row.reportDate }}</span>
          <span v-show="scope.row.weekNo >= 1 && scope.row.weekNo <= 5">{{ scope.row.reportDate }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="collectorName" label="催收员" min-width="40"></el-table-column>
      <el-table-column align="center" label="职位" min-width="40">
        <template slot-scope="scope">
          <span>{{ POSITION_STATUS[scope.row.position] }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="groupType" label="组别" min-width="50"></el-table-column>
      <el-table-column align="center" label="逾期阶段" min-width="40">
        <template slot-scope="scope">
          <span v-if="scope.row.overdueLevel">{{ overdueLevelMap[scope.row.overdueLevel] }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="managerName" label="所属经理" min-width="40"></el-table-column>
      <el-table-column align="center" prop="companyName" label="机构" min-width="40"></el-table-column>
      <el-table-column align="center" prop="inCollectCaseNo" label="在催案数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="touchCaseNo" label="触碰案数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="touchRate" label="触碰率" min-width="40"
                       :render-header="renderHeader">
        <template slot-scope="scope">
          <span>{{ parseInt(scope.row.touchRate * 10000) / 100 }}%</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="actionNo" label="行动量" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="connectedCaseNo" label="联系到人的案数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="connectRate" label="联系率" min-width="40"
                       :render-header="renderHeader">
        <template slot-scope="scope">
          <span>{{ parseInt(scope.row.connectRate * 10000) / 100 }}%</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="infiltrateRate" label="渗透率" min-width="40"
                       :render-header="renderHeader">
        <template slot-scope="scope">
          <span>{{ parseInt(scope.row.infiltrateRate * 10000) / 100 }}%</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="callDensity" label="拨打密度" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="dailyValidCallNo" label="当日有效单呼数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="dailyValidBatchCallNo" label="当日有效批呼数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="dailyTotalCallNo" label="当日全部单呼数" min-width="40"
                       :render-header="renderHeader"></el-table-column>                 
      <el-table-column align="center" prop="dailyTotalBatchCallNo" label="当日全部批呼数" min-width="40"
                       :render-header="renderHeader"></el-table-column>                             
      <el-table-column align="center" prop="totalCallTime" label="当日有效通话时长" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageCallTime" label="平均有效通话时长" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="dailyTotalMsgNo" label="当日短信数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
    </el-table>
    <!-- 催收员工作量日报结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
  </div>
</template>

<script>
  import { parseTime, formatMillisecondTo, getWeekNo } from '../../utils/formatDate'
  import CollectionQueryTerms from '../components/CollectionQueryTerms'
  import VueElTooltip from '../../components/VueElTooltip'
  import { TABLE_TITLE_TIP } from './csmConstant'
  import {
    fetchGetCollectorDailyList,
    URL_EXPORT_COLLECTOR_DAILY_DATA
  } from '../../api/csm'
  import { POSITION_STATUS } from '../quality/qualityConstant'
  import { CONST_OVERDUE_LEVEL_MAP } from '../case/caseConstant'

  export default {
    components: {
      CollectionQueryTerms, VueElTooltip
    },
    data () {
      return {
        // 筛选数据
        filterForm: {},
        // 质检明细表格高度
        tableHeight: 600,
        listLoading: false,
        // 质检明细表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 50, 100, 500],
        POSITION_STATUS, // 职位状态
        overdueLevelMap: CONST_OVERDUE_LEVEL_MAP // 逾期阶段字符串映射
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          let h = document.documentElement.clientHeight
          if (formHeight >= 90) {
            this.tableHeight = h - 189
          } else if (formHeight >= 45) {
            this.tableHeight = h - 144
          }
        })
      },
      deactivated () {
        window.removeEventListener('resize', this.handleResize)
      },
      beforeDestroy () {
        window.removeEventListener('resize', this.handleResize)
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        // 获取表格数据
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        // 获取表格数据
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        // 列表开始加载
        this.listLoading = true
        fetchGetCollectorDailyList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content.map(item => {
                item.totalCallTime = formatMillisecondTo(item.totalCallTime)
                item.averageCallTime = formatMillisecondTo(item.averageCallTime)
                // 周几（增加字段）
                item.weekNo = getWeekNo(item.reportDate)
                return item
              })
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 搜索按钮
      searchBtn (queryData) {
        this.filterForm = queryData
        this.getTableData()
      },
      // 导出按钮
      exportBtn (queryData) {
        this.filterForm = queryData
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = URL_EXPORT_COLLECTOR_DAILY_DATA + '?fileName=催收员工作量日报-' + date + '.csv&queryDTO=' + encodeURI(JSON.stringify(this.filterForm))
        window.location.href = url
      },
      // 表头
      renderHeader (createElement, {column}) {
        return createElement(VueElTooltip, {
          props: {
            label: column.label,
            content: TABLE_TITLE_TIP[column.property]
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .collector-daily-wrapper {
    .el-form-item {
      margin-bottom: 5px;
    }
    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }
  }
</style>
