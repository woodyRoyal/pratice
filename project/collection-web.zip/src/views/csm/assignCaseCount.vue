<template>
  <div class="assign-case-count-wrapper">
    <div>
      <div style="font-size:14px; margin-bottom:10px;margin-top:10px;">该报表只统计，在分案当天（T日）属于首次分案的案件<span style="color:red">（在其逾期阶段内是首次分案）</span>情况。</div>
    </div>
    <el-tabs v-model="editableTabsValue" type="card" @tab-click="handleTabChange">
      <el-tab-pane v-for="item in assignTitleData" :key="item.id" :label="item.name" :name="item.id+''">
        <!--查询表单-->
        <el-form :inline="true" :model="filterForm">
          <el-form-item label="分案时间" v-if="item.id != 3">
            <el-date-picker
              v-model="date"
              class="length-1"
              size="small"
              type="daterange"
              range-separator="-"
              start-placeholder="开始日期"
              end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item v-if="item.id != 3">
            <!--请选择催收组-->
            <vue-el-select size="small" class="input-width" v-model="filterForm.groupIdList" multiple filterable placeholder="请选择催收组" @visible-change="handleGroupVisibleChange">
              <el-option  v-for="item in collectionGroupFilterList"
                          :key="item.id"
                          :label="item.name"
                          :value="item.id"
              >
              </el-option>
            </vue-el-select>
          </el-form-item>
          <el-form-item v-if="item.id != 3">
              <!--请选择催收员-->
              <vue-el-select size="small" class="input-width" v-model="filterForm.collectorIdList"  remote multiple filterable  placeholder="请输入并选择催收员" @focus="handleCollectorVisibleChange" :remote-method="collectorRemoteMethod">
                <el-option  v-for="item in collectorInTempList"
                            :key="item.id"
                            :label="item.displayName"
                            :value="item.id" >
                </el-option>
              </vue-el-select>
          </el-form-item>
          <el-form-item label="产品:" v-if="item.id == 3">
            <el-radio-group v-model="filterForm.productId" @change="handleCheckedProductChange">
              <el-radio v-for="value in appCodeList" :label="value.id" :key="value.id">{{value.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <div>
          <el-form-item label="逾期阶段:" v-if="item.id == 3">
            <el-checkbox-group v-model="filterForm.overDueLevelNameList">
              <el-checkbox v-for="value in overdueLevelData" :label="value.overdueLevelCode" :key="value.overdueLevelCode">{{value.overdueLevelCode}}</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
          </div>
          <el-form-item>
            <el-button type="primary" size="small" @click="handleSearch">搜索</el-button>
            <el-button type="primary" size="small" @click="handleExport">导出</el-button>
          </el-form-item>
        </el-form>
        <!--个人明细数据展示-->
        <el-table border v-if="item.id == 1" :data="personalDetailData" :max-height="tableHeight">
          <el-table-column label="催收员" align="center" prop="collectorName"></el-table-column>
          <el-table-column label="分案日期" align="center" prop="assignDate"></el-table-column>
          <el-table-column label="组别" align="center" prop="groupName"></el-table-column>
          <el-table-column label="当日分案件数" align="center" prop="todayNum"></el-table-column>
          <el-table-column label="当日分案金额" align="center" prop="todayMoneyString"></el-table-column>
          <el-table-column label="当月分案件数" align="center" prop="monthNum"></el-table-column>
          <el-table-column label="当月分案金额" align="center" prop="monthMoneyString"></el-table-column>
        </el-table>
        <!--个人汇总数据展示-->
        <el-table border v-if="item.id == 2" :data="personalCollectData" :max-height="tableHeight">
          <el-table-column label="催收员" align="center" prop="collectorName"></el-table-column>
          <el-table-column label="组别" align="center" prop="groupName"></el-table-column>
          <el-table-column label="当期分案件数" align="center" prop="assignNum"></el-table-column>
          <el-table-column label="当期分案金额" align="center" prop="assignMoneyString"></el-table-column>
        </el-table>
        <!--产品&阶段数据展示-->
        <el-table border v-if="item.id == 3" :data="productAndLevelCollectData" :max-height="tableHeight">
          <el-table-column label="分案日期" align="center" prop="assignDate"></el-table-column>
          <el-table-column label="产品" align="center" prop="productName"></el-table-column>
          <el-table-column label="逾期阶段" align="center" prop="overdueLevelName"></el-table-column>
          <el-table-column label="当日分案件数" align="center" prop="todayAssignNum"></el-table-column>
          <el-table-column label="当日分案金额" align="center" prop="todayAssignMoneyString"></el-table-column>
        </el-table>

        <!-- 分页开始-->
        <div class="pagination-container">
          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                         :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                         :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                         :total="totalRecord">
          </el-pagination>
        </div>
        <!-- 分页结束-->
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import VueElSelect from '../../components/VueElSelect'
  import {
    findAllGroupVOList,
    fetchAllCollectorVOList
  } from '../../api/common'
  import getFirstLetter from 'utils/chineseToPhoneticInitial'
  import {
    fetchPersonalDetailList,
    fetchPersonalCollectList,
    fetchProductAndLevelCollectList,
    fetchAllOverdueDays,
    URL_EXPORT_PERSONAL_DETAIL_DATA,
    URL_EXPORT_PERSONAL_COLLECT_DATA,
    URL_EXPORT_PRODUCTANDLEVEL_COLLECT_DATA
  } from '../../api/csm'
  import { parseTime } from '../../utils/formatDate'
  export default {
    components: {
      VueElSelect
    },
    computed: {
      ...mapGetters([
        'appCodeList' // 产品类型
      ])
    },
    created () {
      this.getProductType() // 获取产品类型
    },
    data () {
      return {
        personalDetailData: [], // 个人明细数据
        personalCollectData: [], // 个人汇总数据
        productAndLevelCollectData: [], // 产品以及阶段数据
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 20, 50, 100],
        date: [new Date().getTime() - 3 * 24 * 3600 * 1000, new Date().getTime()],
        filterForm: {
          startDate: parseTime(new Date().getTime() - 3600 * 1000 * 24, 'YYYY-MM-DD'), // 开始时间
          endDate: parseTime(new Date().getTime(), 'YYYY-MM-DD'), // 结束时间
          // 产品
          productId: 3, // 选中的产品Id
          groupIdList: [], // 选中的催收组
          collectorIdList: [], // 选中的催收员
          overDueLevelNameList: [] // 选中的的逾期阶段对应的名称
        },
        editableTabsValue: '1',
        // 表头
        assignTitleData: [
          {id: 1, 'name': '个人明细'},
          {id: 2, 'name': '个人汇总'},
          {id: 3, 'name': '产品&阶段'}
        ],
        // 逾期阶段
        overduesList: [], // 所有逾期阶段
        overdueLevelData: [],

        // 催收组
        collectionGroupList: [], // 所有催收组数据
        collectionGroupFilterList: [], // 过滤后下拉列表

        // 催收员
        collectorList: [], // 所有催收员数据
        collectorTempList: [], // 通过催收组过滤后的催收员
        collectorInTempList: [], // 催收员输入匹配暂存数组

        // 表格高度
        tableHeight: 600
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
      // 获取个人明细
      this.getPersonalDetail()
      // 获取所有逾期阶段
      this.getAllOverdueDays()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // 调整表格高度
      handleResize (event) {
        this.$nextTick(() => {
          // let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          // let h = document.documentElement.clientHeight
          this.tableHeight = 580
        })
      },
      // 解决tab切换问题
      handleTabChange () {
        this.date = [new Date().getTime() - 3 * 24 * 3600 * 1000, new Date().getTime()]
        this.filterForm = {
          startDate: parseTime(new Date().getTime() - 3600 * 1000 * 24, 'YYYY-MM-DD'), // 开始时间
          endDate: parseTime(new Date().getTime(), 'YYYY-MM-DD'), // 结束时间
          // 产品
          productId: 3, // 选中的产品Id
          groupIdList: [], // 选中的催收组
          collectorIdList: [], // 选中的催收员
          overDueLevelNameList: [] // 选中的的逾期阶段对应的名称
        }
        this.overdueLevelData = [] // 预先清空预期阶段框
        this.overduesList.forEach((item, index) => { // 相应的产品展示相应的逾期阶段
          if (item.productId === this.filterForm.productId) {
            this.overdueLevelData.push(item)
          }
        })
        //        if (this.editableTabsValue === '1') {
        //          this.getPersonalDetail()
        //        } else if (this.editableTabsValue === '2') {
        //          this.getPersonalCollect()
        //        } else {
        //          this.getProductAndLevelCollect()
        //        }
        this.handleSearch() // tab切换时获取数据
      },
      // 获取所有逾期阶段
      getAllOverdueDays () {
        fetchAllOverdueDays()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.overduesList = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 点击搜索
      handleSearch () {
        if (this.editableTabsValue === '1') {
          this.getPersonalDetail()
        } else if (this.editableTabsValue === '2') {
          this.getPersonalCollect()
        } else {
          this.getProductAndLevelCollect()
        }
      },
      // 导出
      handleExport () {
        if (this.editableTabsValue === '1') {
          this.exportPersonalDetail()
        } else if (this.editableTabsValue === '2') {
          this.exportPersonalCollect()
        } else {
          this.exportProductAndLevelCollect()
        }
      },
      exportPersonalDetail () {
        let param = this.getQueryData()
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = URL_EXPORT_PERSONAL_DETAIL_DATA + '?fileName=个人明细-' + date + '.csv&param=' + encodeURI(JSON.stringify(param))
        window.location.href = url
      },
      exportPersonalCollect () {
        let param = this.getQueryData()
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = URL_EXPORT_PERSONAL_COLLECT_DATA + '?fileName=个人汇总-' + date + '.csv&param=' + encodeURI(JSON.stringify(param))
        window.location.href = url
      },
      exportProductAndLevelCollect () {
        let param = this.getQueryData()
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = URL_EXPORT_PRODUCTANDLEVEL_COLLECT_DATA + '?fileName=产品-阶段-' + date + '.csv&param=' + encodeURI(JSON.stringify(param))
        window.location.href = url
      },
      // 获取个人明细数据
      getPersonalDetail () {
        let param = this.getQueryData()
        let pageable = {
          pageNo: this.pagData.pageNo, // 页码
          pageSize: this.pagData.pageSize // 每页显示的记录数
        }
        fetchPersonalDetailList(JSON.stringify(param), JSON.stringify(pageable))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.personalDetailData = res.data.content
              // console.log(res.data.content)
              this.totalRecord = res.data.totalRecord
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取个人汇总数据
      getPersonalCollect () {
        let param = this.getQueryData()
        let pageable = {
          pageNo: this.pagData.pageNo, // 页码
          pageSize: this.pagData.pageSize // 每页显示的记录数
        }
        fetchPersonalCollectList(JSON.stringify(param), JSON.stringify(pageable))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.personalCollectData = res.data.content
              // console.log(res.data.content)
              this.totalRecord = res.data.totalRecord
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取产品&阶段数据
      getProductAndLevelCollect () {
        let param = this.getQueryData()
        let pageable = {
          pageNo: this.pagData.pageNo, // 页码
          pageSize: this.pagData.pageSize // 每页显示的记录数
        }
        fetchProductAndLevelCollectList(JSON.stringify(param), JSON.stringify(pageable))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.productAndLevelCollectData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      getQueryData () {
        if (this.editableTabsValue === '1') {
          return {
            startDate: this.date ? parseTime(this.date[0], 'YYYY-MM-DD') : null,
            endDate: this.date ? parseTime(this.date[1], 'YYYY-MM-DD') : null,
            groupIdList: this.filterForm.groupIdList.length === 0 ? null : this.filterForm.groupIdList,
            collectorIdList: this.filterForm.collectorIdList.length === 0 ? null : this.filterForm.collectorIdList,
            productId: null,
            overDueLevelNameList: null
          }
        } else if (this.editableTabsValue === '2') {
          return {
            startDate: this.date ? parseTime(this.date[0], 'YYYY-MM-DD') : null,
            endDate: this.date ? parseTime(this.date[1], 'YYYY-MM-DD') : null,
            groupIdList: this.filterForm.groupIdList.length === 0 ? null : this.filterForm.groupIdList,
            collectorIdList: this.filterForm.collectorIdList.length === 0 ? null : this.filterForm.collectorIdList,
            productId: null,
            overDueLevelNameList: null
          }
        } else {
          return {
            startDate: null,
            endDate: null,
            groupIdList: null,
            collectorIdList: null,
            productId: this.filterForm.productId,
            overDueLevelNameList: this.filterForm.overDueLevelNameList.length === 0 ? null : this.filterForm.overDueLevelNameList
          }
        }
      },
      // 获取产品类型
      getProductType () {
        if (!this.appCodeList.length) {
          this.$store.dispatch('GetAppCodeList')
            .then(res => {
            })
            .catch(err => {
              console.log(err)
            })
        }
      },
      // 选择产品
      handleCheckedProductChange (value) {
        this.filterForm.overDueLevelNameList = []
        this.overdueLevelData = []
        this.overduesList.forEach((item, index) => { // 相应的产品展示相应的逾期阶段
          if (item.productId === this.filterForm.productId) {
            this.overdueLevelData.push(item)
          }
        })
      },
      // 催收组 下拉框出现/隐藏时触发
      handleGroupVisibleChange (visible) {
        if (visible) {
          this.getAllGroupList().then(() => {
            this.collectionGroupFilterList = JSON.parse(JSON.stringify(this.collectionGroupList))
          })
        }
      },
      // 获取催收组列表
      getAllGroupList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionGroupList && this.collectionGroupList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionGroupList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionGroupList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              findAllGroupVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionGroupList = res.data
                    // 存入本地
                    // window.localStorage.setItem('Collection-CollectionGroupList', JSON.stringify(this.collectionGroupList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 催收员 下拉框出现/隐藏时触发
      handleCollectorVisibleChange (visible) {
        if (visible) {
          this.getAllCollectorList().then(() => {
            // 然后过滤数据 mechanismId groupId
            if (this.filterForm.groupIdList.length === 0) {
              this.collectorTempList = JSON.parse(JSON.stringify(this.collectorList))
            } else {
              this.collectorTempList = this.collectorList.filter(item => {
                // 机构、组下拉框
                if (this.filterForm.groupIdList.length > 0) { // 组选了 返回组下面的
                  return this.filterForm.groupIdList.join(',').indexOf(item.groupId) >= 0
                } else {
                  return false
                }
              })
            }
          })
        }
      },
      // 获取催收员列表
      getAllCollectorList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectorList && this.collectorList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionCollectorList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectorList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchAllCollectorVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectorList = res.data
                    this.collectorList.forEach((item, index) => {
                      this.collectorList[index].phoneticInitial = getFirstLetter(this.collectorList[index].displayName).join(',')
                    })
                    // let _this = this
                    // 存入本地
                    // window.localStorage.setItem('Collection-CollectionCollectorList', JSON.stringify(this.collectorList))
                    // 中文转拼音首字母
                    //                    setTimeout(() => {
                    //                      _this.handleChineseToPhoneticInitial()
                    //                    }, 100)
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 催收员远端方法
      collectorRemoteMethod (query) {
        if (query !== '') {
          this.collectorInTempList = [] // 先清空过滤的数组
          // this.classifyLoading = true // loading出现
          // 遍历数组取出符合输入条件的数据
          this.collectorTempList.forEach((item, index) => {
            if (item.displayName.indexOf(query) > -1 || (item.phoneticInitial && item.phoneticInitial.indexOf(query.trim().toUpperCase()) > -1)) {
              this.collectorInTempList.push(item)
            }
          })
          // this.classifyLoading = false // loading消失
        } else {
          this.collectorInTempList = []
        }
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.handleSearch() // 页码改变处理数据
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.handleSearch() // 页码改变处理数据
      }
    }
  }
</script>

<style lang="scss" scoped>
    .assign-case-count-wrapper {
      .length-1 {
        width: 300px;
      }
      .el-form-item {
        margin-bottom: 5px;
      }
    }



</style>