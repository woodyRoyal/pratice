<!-- 逾期阶段工作量月报 -->
<template>
  <div class="late-stage-monthly-wrapper">
    <!-- 筛选条件开始 -->
    <collection-org-query-terms @search="searchBtn" @export="exportBtn">
    </collection-org-query-terms>
    <!-- 筛选条件结束 -->

    <!-- 逾期阶段工作量月报开始-->
    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
      <el-table-column align="center" prop="reportDate" label="日期" min-width="60">
        <template slot-scope="scope">
          <span v-show="scope.row.weekNo === 6" style="color: green;">{{ scope.row.reportDate }}</span>
          <span v-show="scope.row.weekNo === 0" style="color: red;">{{ scope.row.reportDate }}</span>
          <span v-show="scope.row.weekNo >= 1 && scope.row.weekNo <= 5">{{ scope.row.reportDate }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="逾期阶段" min-width="60">
        <template slot-scope="scope">
          <span>{{ overdueLevelMap[scope.row.overdueLevel] }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="groupType" label="催收机构" min-width="60"></el-table-column>
      <el-table-column align="center" prop="averageCollectorNum" label="本月日均催收员数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageCollectingCasesStr" label="本月日均在催案数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageCollectedCasesStr" label="本月日均触碰案数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageCollectedRateStr" label="本月日均触碰率" min-width="40"
                       :render-header="renderHeader">
        <template slot-scope="scope">
          <span>{{ parseInt(scope.row.averageCollectedRateStr * 10000) / 100 }}%</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="averageActionCasesStr" label="本月日均行动量" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageHasPhonedCasesStr" label="本月日均联系到人的案数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageHasPhonedRate" label="本月日均渗透率" min-width="40"
                       :render-header="renderHeader">
        <template slot-scope="scope">
          <span>{{ parseInt(scope.row.averageHasPhonedRate * 10000) / 100 }}%</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="averageValidCall" label="本月日均有效单呼数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageValidBatchCall" label="本月日均有效批呼数" min-width="40"
                       :render-header="renderHeader"></el-table-column>                 
      <el-table-column align="center" prop="averageCalledTimesSumStr" label="本月日均有效通话时长" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageSmsCases" label="本月日均短信数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
    </el-table>
    <!-- 逾期阶段工作量月报结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
  </div>
</template>

<script>
  import { parseTime, formatMillisecondTo, getWeekNo } from '../../utils/formatDate'
  import CollectionOrgQueryTerms from '../components/CollectionOrgQueryTerms'
  import VueElTooltip from '../../components/VueElTooltip'
  import { TABLE_TITLE_TIP } from './csmConstant'
  import {
    fetchGetLateStageMonthlyList,
    URL_EXPORT_LATE_STAGE_MONTHLY_DATA
  } from '../../api/csm'
  import { CONST_OVERDUE_LEVEL_MAP } from '../case/caseConstant'

  export default {
    components: {
      CollectionOrgQueryTerms, VueElTooltip
    },
    data () {
      return {
        // 筛选数据
        filterForm: {},
        // 质检明细表格高度
        tableHeight: 600,
        listLoading: false,
        // 质检明细表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 50, 100, 500],
        overdueLevelMap: CONST_OVERDUE_LEVEL_MAP // 逾期阶段字符串映射
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          let h = document.documentElement.clientHeight
          if (formHeight >= 90) {
            this.tableHeight = h - 189
          } else if (formHeight >= 45) {
            this.tableHeight = h - 144
          }
        })
      },
      deactivated () {
        window.removeEventListener('resize', this.handleResize)
      },
      beforeDestroy () {
        window.removeEventListener('resize', this.handleResize)
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        // 获取表格数据
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        // 获取表格数据
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        // 列表开始加载
        this.listLoading = true
        fetchGetLateStageMonthlyList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              res.data.content.map(item => {
                // 表头render需要，因与其他页面字段重复，所以修改字段，区分
                item.averageCollectingCasesStr = item.averageCollectingCases
                item.averageCollectedCasesStr = item.averageCollectedCases
                item.averageCollectedRateStr = item.averageCollectedRate
                item.averageActionCasesStr = item.averageActionCases
                item.averageHasPhonedCasesStr = item.averageHasPhonedCases
                item.averageCalledTimesSumStr = formatMillisecondTo(item.averageCalledTimesSum)
                // 周几（增加字段）
                item.weekNo = getWeekNo(item.reportDate)
                return item
              })
              this.tableData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 搜索按钮
      searchBtn (queryData) {
        this.filterForm = queryData
        this.getTableData()
      },
      // 导出按钮
      exportBtn (queryData) {
        this.filterForm = queryData
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = URL_EXPORT_LATE_STAGE_MONTHLY_DATA + '?fileName=机构工作量月报-' + date + '.csv&param=' + encodeURI(JSON.stringify(this.filterForm))
        window.location.href = url
      },
      // 表头
      renderHeader (createElement, {column}) {
        return createElement(VueElTooltip, {
          props: {
            label: column.label,
            content: TABLE_TITLE_TIP[column.property]
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .late-stage-monthly-wrapper {
    .el-form-item {
      margin-bottom: 5px;
    }

    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }
  }
</style>
