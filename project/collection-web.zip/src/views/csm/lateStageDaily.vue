<!-- 逾期阶段工作量日报 -->
<template>
  <div class="late-stage-daily-wrapper">
    <!-- 筛选条件开始 -->
    <collection-org-query-terms @search="searchBtn" @export="exportBtn">
    </collection-org-query-terms>
    <!-- 筛选条件结束 -->

    <!-- 逾期阶段工作量日报开始-->
    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
      <el-table-column align="center" prop="reportDate" label="日期" min-width="60">
        <template slot-scope="scope">
          <span v-show="scope.row.weekNo === 6" style="color: green;">{{ scope.row.reportDate }}</span>
          <span v-show="scope.row.weekNo === 0" style="color: red;">{{ scope.row.reportDate }}</span>
          <span v-show="scope.row.weekNo >= 1 && scope.row.weekNo <= 5">{{ scope.row.reportDate }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="逾期阶段" min-width="40">
        <template slot-scope="scope">
          <span>{{ overdueLevelMap[scope.row.overdueLevel] }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="groupType" label="催收机构" min-width="50"></el-table-column>
      <el-table-column align="center" prop="collectorNum" label="催收员数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="collectingCases" label="在催案数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="collectedCases" label="触碰案数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="collectedRate" label="触碰率" min-width="40"
                       :render-header="renderHeader">
        <template slot-scope="scope">
          <span>{{ parseInt(scope.row.collectedRate * 10000) / 100 }}%</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="actionCases" label="行动量" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="hasPhonedCases" label="联系到人的案数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="hasPhonedCasesRate" label="联系率" min-width="40"
                       :render-header="renderHeader">
        <template slot-scope="scope">
          <span>{{ parseInt(scope.row.hasPhonedCasesRate * 10000) / 100 }}%</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="hasPhonedRate" label="渗透率" min-width="40"
                       :render-header="renderHeader">
        <template slot-scope="scope">
          <span>{{ parseInt(scope.row.hasPhonedRate * 10000) / 100 }}%</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="validCallCases" label="当日有效单呼数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="callCases" label="当日全部单呼数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="validBatchCallCases" label="当日有效批呼数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="batchCallCases" label="当日全部批呼数" min-width="40"
                       :render-header="renderHeader"></el-table-column>                                  
      <el-table-column align="center" prop="calledTimesSum" label="当日有效通话总时长" min-width="40"
                       :render-header="renderHeader"></el-table-column>                                
      <el-table-column align="center" prop="smsCases" label="当日短信数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageCollectingCases" label="人均在催案数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageCollectedCases" label="人均触碰案数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageCollectedRate" label="人均触碰率" min-width="40"
                       :render-header="renderHeader">
        <template slot-scope="scope">
          <span>{{ parseInt(scope.row.averageCollectedRate * 10000) / 100 }}%</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="averageActionCases" label="人均行动量" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageHasPhonedCases" label="人均联系到人的案数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageValidCallCases" label="人均有效电话数" min-width="40"
                       :render-header="renderHeader"></el-table-column>
      <el-table-column align="center" prop="averageCalledTimesSum" label="人均有效通话总时长" min-width="40"
                       :render-header="renderHeader"></el-table-column>
    </el-table>
    <!-- 逾期阶段工作量日报结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
  </div>
</template>

<script>
  import { parseTime, formatMillisecondTo, getWeekNo } from '../../utils/formatDate'
  import CollectionOrgQueryTerms from '../components/CollectionOrgQueryTerms'
  import VueElTooltip from '../../components/VueElTooltip'
  import { TABLE_TITLE_TIP } from './csmConstant'
  import {
    fetchGetLateStageDailyList,
    URL_EXPORT_LATE_STAGE_DAILY_DATA
  } from '../../api/csm'
  import { CONST_OVERDUE_LEVEL_MAP } from '../case/caseConstant'

  export default {
    components: {
      CollectionOrgQueryTerms, VueElTooltip
    },
    data () {
      return {
        // 筛选数据
        filterForm: {},
        // 质检明细表格高度
        tableHeight: 600,
        listLoading: false,
        // 质检明细表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 50, 100, 500],
        overdueLevelMap: CONST_OVERDUE_LEVEL_MAP // 逾期阶段字符串映射
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          let h = document.documentElement.clientHeight
          if (formHeight >= 90) {
            this.tableHeight = h - 189
          } else if (formHeight >= 45) {
            this.tableHeight = h - 144
          }
        })
      },
      deactivated () {
        window.removeEventListener('resize', this.handleResize)
      },
      beforeDestroy () {
        window.removeEventListener('resize', this.handleResize)
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        // 获取表格数据
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        // 获取表格数据
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        // 列表开始加载
        this.listLoading = true
        fetchGetLateStageDailyList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content.map(item => {
                item.calledTimesSum = formatMillisecondTo(item.calledTimesSum)
                item.averageCalledTimesSum = formatMillisecondTo(item.averageCalledTimesSum)
                // 周几（增加字段）
                item.weekNo = getWeekNo(item.reportDate)
                return item
              })
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 搜索按钮
      searchBtn (queryData) {
        this.filterForm = queryData
        this.getTableData()
      },
      // 导出按钮
      exportBtn (queryData) {
        this.filterForm = queryData
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = URL_EXPORT_LATE_STAGE_DAILY_DATA + '?fileName=机构工作量日报-' + date + '.csv&param=' + encodeURI(JSON.stringify(this.filterForm))
        window.location.href = url
      },
      // 表头
      renderHeader (createElement, {column}) {
        return createElement(VueElTooltip, {
          props: {
            label: column.label,
            content: TABLE_TITLE_TIP[column.property]
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .late-stage-daily-wrapper {
    .el-form-item {
      margin-bottom: 5px;
    }

    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }
  }
</style>
