<template>
  <div class="home-wrapper">
    <!--首页-->
    <el-row>
      <el-col :span="6">
        <el-card class="box-card" :body-style="{ padding: '0px'}">
          <div class="remind">今日提醒</div>
          <!--多选框-->
          <el-radio-group v-model="status" style="padding-left: 15%;padding-top:2px;" @change="typeChange">
            <el-radio :label="0">未过期</el-radio>
            <el-radio :label="1">已过期</el-radio>
          </el-radio-group>
          <!--多选框-->
          <div v-for="(item, index) in todayRemind" :key="index" class="item">
            <span class="font">{{ item.remindTime.substr(10) }}</span>,
            <span class="font">{{ item.callResultValue }}</span>,
            <el-popover placement="top-start" trigger="hover" :content="item.memo" :disabled="item.memo.length < 12">
              <span slot="reference" v-if="item.isDeal == 1" class="imitate-a-label" @click="openDetailByIdToday(item, index)" style="color:red">{{ item.contactName }}({{ item.memo.length >= 12 ? item.memo.substr(0, 11) + '...' : item.memo }})</span>
              <span slot="reference" v-if="item.isDeal == 0" class="imitate-a-label" @click="openDetailByIdToday(item, index)">{{ item.contactName }}({{ item.memo.length >= 12 ? item.memo.substr(0, 11) + '...' : item.memo  }})</span>
            </el-popover>
          </div>
          <!--分页对象-->
          <div class="pagination-container">
            <div class="font-2">共<span v-html="pagDataRemind.total"></span>条</div>
            <div class="font-2">共<span v-html="pagDataRemind.totalPage"></span>页</div>
            <el-select v-model="pagDataRemind.pageNo" @change="todayChange" size="small" placeholder="请选择">
              <el-option  v-for="item in pagDataRemind.totalPage" :value="item" :key="item">{{item}}</el-option>
            </el-select>
          </div>
        </el-card>
      </el-col>
      <!--<el-col :span="6">-->
        <!--<el-card class="box-card" :body-style="{ padding: '0px' }">-->
          <!--<div class="remind">近5天登录了app的用户</div>-->
          <!--<div v-for="(item, index) in lateLogin" :key="index" class="item">-->
            <!--<span class="font">{{ item.activeAt }}</span>,-->
            <!--<span v-if="item.isDeal === 1" class="imitate-a-label" @click="openDetailByIdLate(item, index)" style="color:red">{{ item.userName }}</span>-->
            <!--<span v-if="item.isDeal === 0" class="imitate-a-label" @click="openDetailByIdLate(item, index)">{{ item.userName }}</span>-->
          <!--</div>-->
          <!--&lt;!&ndash;分页对象&ndash;&gt;-->
          <!--<div class="pagination-container">-->
            <!--<div class="font-2">共<span v-html="pagDataLogin.total"></span>条</div>-->
            <!--<div class="font-2">共<span v-html="pagDataLogin.totalPage"></span>页</div>-->
            <!--<el-select v-model="pagDataLogin.pageNo" @change="remindChange" size="small" placeholder="请选择">-->
              <!--<el-option  v-for="item in pagDataLogin.totalPage" :value="item" :key="item">{{item}}</el-option>-->
            <!--</el-select>-->
          <!--</div>-->
        <!--</el-card>-->
      <!--</el-col>-->
      <!--<el-col :span="6">-->
        <!--<el-card class="box-card" :body-style="{ padding: '0px' }">-->
          <!--<div class="remind">近5天更新了的用户</div>-->
          <!--<div v-for="(item, index) in updateContacts" :key="index" class="item">-->
            <!--<span class="font">{{ item.updateAt }}</span>，-->
            <!--&lt;!&ndash; 动态style 或者动态class切换就行了，没必要多写一个dom 节点 &ndash;&gt;-->
            <!--&lt;!&ndash; <span v-if="item.isDeal === 1" class="imitate-a-label" @click="openDetailByIdUpdate(item, index)" style="color:red">{{ item.username }}</span> &ndash;&gt;-->
            <!--<span :class="['imitate-a-label',item.isDeal === 1? 'bg_red':'']" @click="openDetailByIdUpdate(item, index)" >{{ item.username }}</span>-->
          <!--</div>-->
          <!--<div class="pagination-container">-->
            <!--<div class="font-2">共<span v-html="pagDataUpdate.total"></span>条</div>-->
            <!--<div class="font-2">共<span v-html="pagDataUpdate.totalPage"></span>页</div>-->
            <!--<el-select v-model="pagDataUpdate.pageNo" size="small" placeholder="请选择" @change="changePagDataUpdate">-->
              <!--<el-option  v-for="item in pagDataUpdate.totalPage" :value="item" :key="item">{{item}}</el-option>-->
            <!--</el-select>-->
          <!--</div>-->
        <!--</el-card>-->
      <!--</el-col>-->
      <!--<el-col :span="6">-->
        <!--<el-card class="box-card" :body-style="{ padding: '0px' }">-->
          <!--<div class="remind">近5天产生的共债案件</div>-->
          <!--<div v-for="(item, index) in gzCases" :key="index" class="item">-->
            <!--<span class="font">{{ item.gzAt }}</span>，-->
            <!--<span :class="['imitate-a-label', item.checked === 1 ? 'bg_red' : '']" @click="openDetailByIdGzCase(item, index)">-->
              <!--<span>{{ item.name }}</span>-->
              <!--<span>(</span>-->
              <!--<span>{{ item.productNames }}</span>-->
              <!--<span>)</span>-->
            <!--</span>-->
          <!--</div>-->
          <!--<div class="pagination-container">-->
            <!--<div class="font-2">共<span v-html="pagDataGzCase.total"></span>条</div>-->
            <!--<div class="font-2">共<span v-html="pagDataGzCase.totalPage"></span>页</div>-->
            <!--<el-select v-model="pagDataGzCase.pageNo" size="small" placeholder="请选择" @change="gzCaseChange">-->
              <!--<el-option  v-for="item in pagDataGzCase.totalPage" :value="item" :key="item">{{item}}</el-option>-->
            <!--</el-select>-->
          <!--</div>-->
        <!--</el-card>-->
      <!--</el-col>-->
      <el-col :span="18">
        <el-card class="box-card" :body-style="{ padding: '0px' }">
          <div class="remind">本月回款情况</div>
          <el-table border :data="monthReturn" :max-height="maxTableHeight">
            <el-table-column label="时间" align="center" prop="statictisDate"></el-table-column>
            <el-table-column label="结清案件数" align="center" prop="currCycleCasecount"></el-table-column>
            <el-table-column label="回款金额(含未结清)" align="center" prop="currCycleAmountString">
              <template slot-scope="scope">
                <span>{{scope.row.currCycleAmountString ? scope.row.currCycleAmountString : 0 }}</span>
              </template>
            </el-table-column>
          </el-table>
          <!--分页对象-->
          <div class="pagination-container">
            <div class="font-2">共<span v-html="pagDataMonth.total - 1"></span>条</div>
            <div class="font-2">共<span v-html="pagDataMonth.totalPage"></span>页</div>
            <el-select v-model="pagDataMonth.pageNo" @change="monthChange" size="small" placeholder="请选择">
              <el-option  v-for="item in pagDataMonth.totalPage" :value="item" :key="item">{{item}}</el-option>
            </el-select>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import {
    fetchCurrCollectorRepaymentInfo, // 获取本月回款情况
    fetchUserActiveInfo, // 获取近5天登录用户
    fetchTodayRemindData, // 获取今日提醒数据
    fetchSaveOverdueActiveOperate, // 最近登录操作变红
    fetchHandleCurrentRemind, // 今日提醒操作变红
    fetchUpdateContacts, // 五天更新通讯录用户
    fetchSaveContactUpdateCaseOperate, // 五天更新通讯录用户变红接口
    fetchGzCases, // 获取近五天产生的共债案件
    fetchSaveGzCaseOperate // 近五天产生的共债案件变红接口
  } from '../../api/home'
  import { mapGetters } from 'vuex'
  export default {
    computed: {
      ...mapGetters([
        'lateLoginStatus',
        'todayRemindStatus'
      ])
    },
    watch: {
      'lateLoginStatus' (newValue, oldValue) {
        this.lateLogin.forEach((item, index) => {
          if (newValue === item.caseId) {
            let value = this.lateLogin[index]
            value.isDeal = 1
            this.$set(this.lateLogin, index, value)
          }
        })
      },
      'todayRemindStatus' (newValue, oldValue) {
        this.todayRemind.forEach((item, index) => {
          if (newValue === item.caseId) {
            let value = this.todayRemind[index]
            value.isDeal = 1
            this.$set(this.todayRemind, index, value)
          }
        })
      }
    },
    data () {
      return {
        maxTableHeight: 486,
        status: 0, // 是否过期
        pagDataRemind: { // 今日提醒分页对象
          pageSize: 22,
          total: 0,
          pageNo: 1,
          totalPage: 1
        },
        pagDataLogin: { // 近5天登录了app的用户分页对象
          pageSize: 23,
          total: 0,
          pageNo: 1,
          totalPage: 1
        },
        // 近五天更新了通讯录的分页
        pagDataUpdate: {
          pageSize: 10,
          total: 0,
          pageNo: 1,
          totalPage: 1
        },
        // 近五天产生的共债案件的分页
        pagDataGzCase: {
          pageSize: 10,
          total: 0,
          pageNo: 1,
          totalPage: 1
        },
        pagDataMonth: {
          pageSize: 16,
          total: 0,
          pageNo: 1,
          totalPage: 1
        },
        todayRemind: [], // 今日提醒
        lateLogin: [], // 近5天登录了App的用户
        updateContacts: [], // 近5天更新了通讯录的用户
        gzCases: [], // 近5天产生的共债案件
        monthReturn: [] // 本月回款情况
      }
    },
    methods: {
      // 打开详情页
      openDetailByIdLate (val, index) {
        // 先请求接口
        fetchSaveOverdueActiveOperate(val.caseId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              // 更新视图
              let newValue = this.lateLogin[index]
              newValue.isDeal = 1
              this.$set(this.lateLogin, index, newValue)
            }
          })
          .catch(error => {
            console.log(error)
          })
        window.open('#/case-detail/' + val.caseId)
      },
      // 打开详情页
      openDetailByIdToday (val, index) {
        // 请求接口
        fetchHandleCurrentRemind(val.caseId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              // 更新视图
              let newValue = this.todayRemind[index]
              newValue.isDeal = 1
              this.$set(this.todayRemind, index, newValue)
            }
          })
          .catch(error => {
            console.log(error)
          })
        // 操作变红 今日提醒
        window.open('#/case-detail/' + val.caseId)
      },
      // 获取本月回款情况
      getCurrCollectorRepaymentInfo () {
        let pageable = {
          pageSize: this.pagDataMonth.pageSize,
          pageNo: this.pagDataMonth.pageNo
        }
        fetchCurrCollectorRepaymentInfo(pageable)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.monthReturn = res.data.content
              this.pagDataMonth.total = res.data.totalRecord
              this.pagDataMonth.totalPage = res.data.totalPage
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取近5天登录的用户
      getUserActiveInfo () {
        let pageable = {
          pageSize: this.pagDataLogin.pageSize,
          pageNo: this.pagDataLogin.pageNo
        }
        fetchUserActiveInfo(pageable)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.lateLogin = res.data.content
              this.pagDataLogin.total = res.data.totalRecord
              this.pagDataLogin.totalPage = res.data.totalPage
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      typeChange () {
        this.getTodayRemindData()
      },
      // 获取今日提醒数据
      getTodayRemindData () {
        let pageable = {
          pageSize: this.pagDataRemind.pageSize,
          pageNo: this.pagDataRemind.pageNo
        }
        fetchTodayRemindData(pageable, this.status)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.todayRemind = res.data.content
              this.pagDataRemind.total = res.data.totalRecord
              this.pagDataRemind.totalPage = res.data.totalPage
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取近五日更新通讯录
      async getUpdateContacts () {
        let pageable = {
          pageSize: this.pagDataUpdate.pageSize,
          pageNo: this.pagDataUpdate.pageNo
        }
        let days = 5
        let response = await fetchUpdateContacts(pageable, days)
        let res = response.data
        if (res && res.errorCode === 0) {
          this.updateContacts = res.data.content
          this.pagDataUpdate.total = res.data.totalRecord
          this.pagDataUpdate.totalPage = res.data.totalPage
        }
      },
      // 打开详情页
      async openDetailByIdUpdate (val, index) {
        let response = await fetchSaveContactUpdateCaseOperate(val.caseId)
        let res = response.data
        if (res.errorCode === 0) {
          // 更新视图
          let newValue = this.updateContacts[index]
          newValue.isDeal = 1
          this.$set(this.updateContacts, index, newValue)
        }
        window.open('#/case-detail/' + val.caseId)
      },
      // 获取近五日产生的共债案件
      async getGzCaseInfo () {
        let pageable = {
          pageSize: this.pagDataGzCase.pageSize,
          pageNo: this.pagDataGzCase.pageNo
        }
        let days = 5
        let response = await fetchGzCases(pageable, days)
        let res = response.data
        if (res && res.errorCode === 0) {
          this.gzCases = res.data.content
          this.pagDataGzCase.total = res.data.totalRecord
          this.pagDataGzCase.totalPage = res.data.totalPage
        }
      },
      // 近五日产生的共债案件 变红-打开案件详情
      async openDetailByIdGzCase (val, index) {
        let response = await fetchSaveGzCaseOperate(val.caseId)
        let res = response.data
        if (res.errorCode === 0) {
          // 更新视图
          let newValue = this.gzCases[index]
          newValue.checked = 1
          this.$set(this.gzCases, index, newValue)
        }
        window.open('#/case-detail/' + val.caseId)
      },
      // 今日提醒选中页变化
      todayChange () {
        this.getTodayRemindData()
      },
      // 近5天登录页数变化
      remindChange () {
        this.getUserActiveInfo()
      },
      // 近5天更新页数变化
      changePagDataUpdate () {
        this.getUpdateContacts()
      },
      // 近5天共债页数变化
      gzCaseChange () {
        this.getGzCaseInfo()
      },
      // 本月回款数据
      monthChange () {
        this.getCurrCollectorRepaymentInfo()
      }
    },
    mounted () {
      // 获取本月回款情况
      this.getCurrCollectorRepaymentInfo()
      // 获取近5天登录用户
      // this.getUserActiveInfo()
      // 获取今日提醒数据
      this.getTodayRemindData()
      // this.getUpdateContacts()
      // 获取近五日产生的共债案件
      // this.getGzCaseInfo()
    }

  }
</script>

<style lang="scss" scoped>
  .home-wrapper {
    .remind {
      background: #eef0ff;
      font-size: 14px;
      height: 30px;
      line-height: 30px;
      padding-left: 10px;
    }
    .item {
      margin-top: 5px;
      font-size: 14px;
      padding-left: 10px;
    }
    .font {
      font-size: 10px;
    }
    .box-card {
      height: 600px;
      position: relative;
      // overflow-x: auto;
    }
    .pagination-container {
      position: absolute;
      display: flex;
      bottom: 0;
      right: 4px;
      width: 135px;
    }
    .font-2 {
      font-size: 10px;
      line-height: 33px;
      padding-right: 5px;
    }
  }
  .bg_red{
    color: red;
  }
</style>
