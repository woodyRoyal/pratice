<!--处理投诉-->
<template>
  <div class="deal-complain-wrapper">
    <span class="status">用户投诉中</span>
    <el-button v-if="dealStatus === 4" type="info" size="small" disabled>已处理</el-button>
    <el-button v-else type="danger" size="small" @click="openDialog">处理投诉</el-button>

    <el-dialog title="处理投诉" :visible.sync="dialogVisible" width="30%">
      <el-form label-position="top" size="small" class="filter-form" :model="form" ref="form" :rules="rules">
        <el-form-item label="处理结果" prop="dealResult">
          <el-radio-group v-model="form.dealResult">
            <el-radio v-for="(item, key) in DEAL_RESULT_LIST" :key="key" :label="key">{{ item }}</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="备注">
          <el-input type="textarea" v-model="form.remark" :maxlength="maxContentLength" :rows="4" placeholder="备注" resize="none"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="handleSubmit" :disabled="isSubmitAbled">提 交</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  import { DEAL_RESULT_LIST } from '../caseConstant'
  import { fetchDealComplain } from '../../../api/case'
  export default {
    name: 'dealComplain',
    props: {
      'complainBillStatus': {
        required: true
      },
      'customerBillId': {
        required: true
      }
    },
    data () {
      return {
        isSubmitAbled: false,
        DEAL_RESULT_LIST,
        dialogVisible: false,
        form: {
          dealResult: null,
          remark: ''
        },
        dealStatus: 1, // {1:'待确认'},{2:'待处理'},{3:'处理中'},{4:'已处理'},{5:'已结束'}
        maxContentLength: 140, // 备注最大长度
        rules: {
          dealResult: [
            { required: true, message: '请选择处理结果', trigger: 'change' }
          ]
        }
      }
    },
    created () {
      this.dealStatus = JSON.parse(JSON.stringify(this.complainBillStatus))
    },
    methods: {
      // 打开弹窗
      openDialog () {
        // 状态为1 待处理 弹窗提醒
        if (this.dealStatus === 1) {
          this.$alert('你还未认领，请先在工单投诉页“确认认领”该工单后，再进行处理', '提示', {
            confirmButtonText: '确定',
            type: 'warning'
          })
          return false
        }
        this.dialogVisible = true
      },
      // 提交
      handleSubmit () {
        this.$refs['form'].validate((valid) => {
          if (valid) {
            this.dealComplain()
          } else {
            return false
          }
        })
      },
      // 处理投诉
      async dealComplain () {
        this.isSubmitAbled = true
        let caseId = this.$route.params.id
        let response = await fetchDealComplain(caseId, this.customerBillId, this.form.remark, this.form.dealResult)
        let res = response.data
        if (res.errorCode === 0) {
          // 已处理
          if (this.form.dealResult === '1' || this.form.dealResult === '2') {
            this.dealStatus = 4
          }
          this.$message.success('处理投诉成功')
          this.dialogVisible = false
          this.isSubmitAbled = false
        } else {
          this.dialogVisible = false
          this.isSubmitAbled = false
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .deal-complain-wrapper {
    .status {
      color: red;
    }
    /deep/ .el-radio+.el-radio {
      margin-left: 0;
    }
    .el-radio {
      display: block;
      margin-bottom: 20px;
    }
  }
</style>