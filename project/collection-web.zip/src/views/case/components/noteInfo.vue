
<!-- 短信 -->

<template>
  <div class="note-info-wrapper">
    <el-row>
      <el-col :span="10">
        <el-radio-group v-model="message" style="padding-top: 8px;" @change="search">
          <el-radio :label="2">客户发出</el-radio>
          <el-radio :label="1">客户接收</el-radio>
        </el-radio-group>
      </el-col>
      <el-col :span="14">
        <!--<span class="imitate-a-label" v-for="(item, index) in smsKeywordType">-->
          <!--<span @click="search(item)">{{item.paramName}}</span>-->
        <!--</span>-->
        <el-radio-group size="mini" v-model="paramCode" @change="search">
          <el-radio-button v-for="(item, index) in smsKeywordType" :label="item.paramCode" :key="index">{{item.paramName}}</el-radio-button>
        </el-radio-group>
        <span v-if="!paramCode" style="color:red; padding-left: 10px;">请选择相关分类搜索</span>
      </el-col>
      <!--<el-col :span="6">
        <span class="imitate-a-label" @click="search">搜索</span>
      </el-col>-->
    </el-row>
    <ul style="overflow: auto; max-height: 180px;">
      <!--<li v-for="(item, index) in noteInfoData" :key="item.id">
        <div class="title-wrapper" @click="handleShow(item, index)">
          &lt;!&ndash;<div>{{ username + '（本人）' }}</div>&ndash;&gt;
          <div>{{ item.name }}</div>
          <span>|</span>
          &lt;!&ndash;<div v-if="item.smsType === 1">{{ item.contactUsername }}</div>&ndash;&gt;
          &lt;!&ndash;<div v-if="item.smsType === 2">{{ username }}</div>&ndash;&gt;
          <div class="last-msg"><span v-html="item.smsBody"></span></div>
          <span>|</span>
          <div class="last-time">{{ item.date }}</div>
        </div>
        &lt;!&ndash;对话&ndash;&gt;
        &lt;!&ndash;<el-row class="msg-wrapper" v-if="item.isShowInfo">
          <el-col :span="24" v-for="(i, index) in item.smsDetailList" :key="index" class="msg-main">
            &lt;!&ndash;type 1-接收 2-发送&ndash;&gt;
            <div v-if="i.smsType === 1">
              <el-col :span="4" class="msg-name">{{ i.contactUsername }}：</el-col>
              <el-col :span="14" class="msg-content"><span v-html="i.content" @click="handleCall(i, $event)"></span></el-col>
              <el-col :span="6" class="msg-time">{{ i.sendTime }}</el-col>
            </div>
            <div v-if="i.smsType === 2">
              <el-col :span="6" class="msg-time">{{ i.sendTime }}</el-col>
              <el-col :span="14" class="msg-content"><span v-html="i.content" @click="handleCall(i, $event)"></span></el-col>
              <el-col :span="4" class="msg-name">：{{ username }}</el-col>
            </div>
          </el-col>
        </el-row>&ndash;&gt;
      </li>-->

       <el-table border :data="noteInfoData" style="margin-top: 3px;">
         <el-table-column prop="name" align="center" width="130" :label="message == 2 ? '接收方' : '发送方'">
            <template slot-scope="scope">
              <div><span style="color: blue; cursor: pointer;" @click.stop="handleCall2(scope.row)">{{scope.row.name}}</span></div>
            </template>
         </el-table-column>
         <el-table-column prop="smsBody" align="center" label="短信内容">
           <template slot-scope="scope">
             <div v-html="scope.row.smsBody"  @click.stop="handleCall(scope.row, $event)"></div>
           </template>
         </el-table-column>
         <el-table-column prop="date" align="center" width="80" label="时间">
           <template slot-scope="scope">
             <span>{{scope.row.date.substr(0,10)}}</span>
           </template>
         </el-table-column>
         <el-table-column align="center" width="45" label="操作">
           <template slot-scope="scope">
             <div class="imitate-a-label" @click="handleShow(scope.row, scope.$index)">详情</div>
           </template>
         </el-table-column>
       </el-table>

      <!-- 分页开始-->
      <div v-show="!noteRecordMsg.listLoading" class="pagination-container">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                       :current-page.sync="noteRecordMsg.pagData.pageNo" :page-sizes="noteRecordMsg.pageSizes"
                       :page-size="noteRecordMsg.pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                       :total="noteRecordMsg.totalRecord">
        </el-pagination>
      </div>
      <!-- 分页结束-->
    </ul>

    <!--短信对话弹框-->
    <el-dialog :title="'与' + title + '的短信记录'" :visible.sync="dialogVisible">
      <el-table border :data="smsDetailList" max-height="300">
        <el-table-column label="姓名" align="center" width="130" prop="name">
          <template slot-scope="scope">
            <div><span style="color: blue; cursor: pointer;" @click.stop="handleCall2(scope.row)">{{scope.row.name}}</span></div>
          </template>
        </el-table-column>
        <el-table-column label="短信内容" align="center" prop="smsBody">
          <template slot-scope="scope">
            <div v-html="scope.row.smsBody" @click.stop="handleCall(scope.row, $event)"></div>
          </template>
        </el-table-column>
        <el-table-column label="时间" align="center" width="130" prop="date"></el-table-column>
      </el-table>
      <div class="pagination-container">
        <el-pagination @size-change="handleSizeChange2" @current-change="handleCurrentChange2"
                       :current-page.sync="recordMsgDetail.pagData.pageNo" :page-sizes="recordMsgDetail.pageSizes"
                       :page-size="recordMsgDetail.pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                       :total="recordMsgDetail.totalRecord">
        </el-pagination>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  // import Vue from 'vue'
  import { mapGetters } from 'vuex'
  // import { base64decode } from 'utils/index'
  import {
    fetchGetUserSmsList,
    fetchUserSmsDetailList, // 获取用户短信明细记录
    fetchSmsKeywordType // 获取用户短信查询参数
  } from '../../../api/case'
  export default {
    props: {
      caseId: {
        required: true
      },
      username: {
        required: true
      }
    },
    computed: {
      ...mapGetters([
        'timeLimit' // 单呼点击限制
      ])
    },
    data () {
      return {
        title: '', // 短信记录详情标题
        phoneNum: '',
        paramCode: '',
        smsDetailList: [], // 短信来往细节
        dialogVisible: false,
        smsKeywordType: [], // 短信查询参数
        message: 2, // 短信收发类型
        activeNames: [],
        noteInfoData: [],
        noteRecordMsg: {
          listLoading: false,
          maxTableHeight: 200,
          pagData: {
            pageSize: 10, // 每页条数
            pageNo: 1 // 页码
          },
          totalRecord: 0, // 总记录数
          pageSizes: [10, 20]
        },
        // 短信记录详情页码
        recordMsgDetail: {
          pagData: {
            pageSize: 10, // 每页条数
            pageNo: 1 // 页码
          },
          totalRecord: 0, // 总记录数
          pageSizes: [10, 20, 50]
        }
      }
    },
    mounted () {
      // this.getUserInfo()
      this.getSmsKeywordType() // 获取用户短信查询参数
    },
    methods: {
      handleCall (val, event) {
        if (this.timeLimit) {
          // event.target.onclick = function () {
          if (event.target.nodeName.toLowerCase() === 'span') {
            this.$store.dispatch('TimeLimit', false)
            val.phonenum = event.target.getAttribute('phonenum')
            this.$emit('handleCall', val)
          }
        }
        // }
      },
      // 短信详情弹框姓名列和短信记录表格第一列打电话
      handleCall2 (item) {
        if (this.timeLimit) {
          this.$store.dispatch('TimeLimit', false)
          item.phonenum = item.phoneNum
          this.$emit('handleCall', item)
        }
      },
      handleShow (item, index) {
        this.title = item.name
        this.getUserSmsDetailList(item)
        // 重新设置this.noteInfoData[index].isShowInfo的值，更新视图
        /* let newValue = this.noteInfoData[index]
        newValue.isShowInfo = !newValue.isShowInfo
        // 无论什么情况，缩和展，都是收起详情
        newValue.isShowTable = false
        // 然后更新视图
        Vue.set(this.noteInfoData, index, newValue) */
      },
      // 面板change
      handleChange (val) {
        console.log(val)
      },
      search () {
        if (!this.paramCode) {
          return false
        }
        this.getUserInfo()
      },
      // 获取短信记录
      getUserInfo () {
        let param = {
          caseId: this.caseId,
          paramCode: this.paramCode,
          type: this.message
        }
        let pageable = {
          pageSize: this.noteRecordMsg.pagData.pageSize,
          pageNo: this.noteRecordMsg.pagData.pageNo
        }
        fetchGetUserSmsList(JSON.stringify(param), JSON.stringify(pageable))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.noteInfoData = res.data.content
              /* this.noteInfoData = res.data.content.map((item, index) => {
                // 是否显示信息
                item.isShowInfo = false
                return item
              }) */
            }
            this.noteRecordMsg.totalRecord = res.data.totalRecord
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取用户短信明细记录
      getUserSmsDetailList (val) {
        this.phoneNum = val.phoneNum
        this.getUserSmsDetailListAga() // 获取用户短信明细记录
      },
      getUserSmsDetailListAga () {
        let pageable = {
          pageSize: this.recordMsgDetail.pagData.pageSize,
          pageNo: this.recordMsgDetail.pagData.pageNo
        }
        // fetchUserSmsDetailList(this.caseId, base64decode(this.phoneNum), pageable)
        fetchUserSmsDetailList(this.caseId, this.phoneNum, pageable)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.smsDetailList = res.data.content
              this.dialogVisible = true
            }
            this.recordMsgDetail.totalRecord = res.data.totalRecord
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取用户短信查询参数
      getSmsKeywordType () {
        fetchSmsKeywordType()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.smsKeywordType = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.noteRecordMsg.pagData.pageSize = val
        this.getUserInfo()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.noteRecordMsg.pagData.pageNo = val
        this.getUserInfo()
      },
      // 处理分页每页显示数改变事件
      handleSizeChange2 (val) {
        this.recordMsgDetail.pagData.pageSize = val
        this.getUserSmsDetailListAga()
      },
      // 处理页码改变事件
      handleCurrentChange2 (val) {
        this.recordMsgDetail.pagData.pageNo = val
        this.getUserSmsDetailListAga()
      }
    }
  }
</script>

<style lang="scss" scoped>

  .note-info-wrapper {
    font-size: 12px;
    color: #666;
    max-height: 200px;
    li {
      margin: 6px 0;
      .title-wrapper {
        height: 30px;
        line-height: 30px;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        .last-msg {
          width: 150px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .last-time {
          font-weight: 700;
        }
      }
      .msg-wrapper {
        border-top: 1px solid #eee;
        max-height: 100px;
        overflow: auto;
        /*background-color: #4ab7bd;*/
        .msg-main {
          margin-bottom: 4px;
          .msg-name {
            font-weight: 700;
          }
          .msg-content {
            /*border: 1px solid #bbb;*/
            /*border-radius: 4px;*/
            border-bottom: 1px dotted #eee;
          }
          .msg-time {
            color: #bbb;
          }
        }
      }
    }
    .imitate-a-label {
       padding-left: 10px;
    }
  }

</style>
