
<!-- 操作信息 -->
<template>
  <div>
    <el-table :data="opeTableData" style="width: 100%" class="operate-table-wrapper"
              :span-method="arraySpanMethod" border v-loading="listLoading">
      <el-table-column align="center" prop="operateTime" label="操作时间" width="72"></el-table-column>
      <el-table-column align="center" prop="operatorName" label="操作员" min-width="40"></el-table-column>
      <el-table-column align="center" prop="actionDesc" label="行动码" min-width="60"></el-table-column>
      <el-table-column align="center" label="电话结果" min-width="100">
        <template slot-scope="scope">
          <span>{{ scope.row.operationDesc }}</span>
          <span v-if="scope.row.operationDesc && scope.row.resultDesc">，</span>
          <span>{{ scope.row.resultDesc }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="memo" label="备注" min-width="100"></el-table-column>
      <el-table-column align="center" label="录音" min-width="40">
        <template slot-scope="scope">
          <span v-if="scope.row.recordPath && showSelectObj.isShowRecordPath" class="file-name" @click="playBtn(scope.row)">播放</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页开始-->
      <div v-show="!listLoading" class="pagination-container">
        <el-pagination @size-change="handleSizeChangeTrade" @current-change="handleCurrentChangeTrade"
                       :current-page.sync="tradeRecordMsg.pagData.pageNo" :page-sizes="tradeRecordMsg.pageSizes"
                       :page-size="tradeRecordMsg.pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                       :total="tradeRecordMsg.totalRecord">
        </el-pagination>
      </div>
    <!-- 播放 -->
    <el-row class="footer-player" v-show="isShowPlayer">
      <i class="el-icon-close" title="关闭" @click="handleCloseAplayer"></i>
      <vue-aplayer autoplay mutex theme="#13CE66" mode="circulation"
                   @playing="handleAudioPlaying"
                   @play="handleAudioPlay"
                   @pause="handleAudioPause"
                   @error="handleAudioError"
                   :playOrPause="audioPlayer.playOrPause"
                   :music="music">
      </vue-aplayer>
    </el-row>
  </div>

</template>

<script>
  import { mapGetters } from 'vuex'
  import {
    fetchGetCaseOperateData // 获取催记数据
  } from '../../../api/case'
  import VueAplayer from '../../../components/AudioPlayer/index.vue'

  export default {
    props: {
      // 是否更新数据
      OTProps: {
        required: true
      },
      caseId: {
        required: true
      }
    },
    components: {
      VueAplayer
    },
    computed: {
      ...mapGetters([
        'showSelectObj' // 是否显示
      ])
    },
    data () {
      return {
        tradeRecordMsg: {
          listLoading: false,
          maxTableHeight: 200,
          pagData: {
            pageSize: 10, // 每页条数
            pageNo: 1 // 页码
          },
          totalRecord: 0, // 总记录数
          pageSizes: [10, 20, 50]
        },
        // 操作 表格
        opeTableData: [],
        listLoading: false,
        // 录音
        id: null, // 播放索引（案件ID）
        recordStatus: false, // 播放状态
        isShowPlayer: false, // 是否显示播放器
        aplayerObj: null, // 播放器对象
        audioPlayer: {
          currentTime: 0,
          playOrPause: true
        },
        music: {
          title: 'audio', // 必填字段
          author: 'dev', // 必填字段
          url: '' // 必填字段
        }
      }
    },
    watch: {
      'OTProps.isUpdate' (val) {
        let _this = this
        if (val.indexOf('update') > -1) {
          // 获取操作表格数据 后端异步操作，立即请求获取不到刚添加的操作码，所以延时一秒再去请求
          this.listLoading = true
          //          setTimeout(function () {
          //            _this.getOpeTableData()
          //          }, 1000)
          _this.getOpeTableData()
        }
      }
    },
    mounted () {
      // 获取操作表格数据
      // this.getOpeTableData()
    },
    methods: {
      // 处理分页每页显示数改变事件
      handleSizeChangeTrade (val) {
        this.tradeRecordMsg.pagData.pageSize = val
        this.getOpeTableData()
      },
      // 处理页码改变事件
      handleCurrentChangeTrade (val) {
        this.tradeRecordMsg.pagData.pageNo = val
        this.getOpeTableData()
      },
      // 获取操作表格数据
      getOpeTableData () {
        this.listLoading = true
        let caseId = this.caseId ? this.caseId : this.$route.params.id
        const data = {
          caseId: caseId,
          pageNo: this.tradeRecordMsg.pagData.pageNo,
          pageSize: this.tradeRecordMsg.pagData.pageSize
          // pageSize: 15
        }
        fetchGetCaseOperateData(data)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tradeRecordMsg.totalRecord = res.data.totalRecord
              this.tradeRecordMsg.pageNo = res.data.pageNo
              this.opeTableData = res.data.content.map(item => {
                // item.recordPath = 'http://dx.sc.chinaz.com/Files/DownLoad/sound1/201708/9025.mp3'
                // 增加字段isplay  false暂停状态/true播放状态
                if (item.id === this.id) {
                  if (this.recordStatus) {
                    item.isPlay = 1
                  } else {
                    item.isPlay = 2
                  }
                } else {
                  item.isPlay = 0
                }
                return item
              })
            } else {
              this.opeTableData = []
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },

      // 合并行动码 假如是三行  是3 0 0  假如是一行 是 1   假如是两行 是2 0
      arraySpanMethod ({ row, column, rowIndex, columnIndex }) {
        if (columnIndex === 0 || columnIndex === 1 || columnIndex === 2) {
          if (row.rowspan) {
            return {
              rowspan: row.rowspan,
              colspan: 1
            }
          } else {
            return {
              rowspan: 0,
              colspan: 0
            }
          }
        }
      },
      // 播放
      playBtn (value) {
        console.log(value)
        console.log(this.id)
        // 如果相同索引，不赋值music，不相同索引，就重新赋值music
        if (value.id !== this.id) {
          // 新建对象
          this.music = null
          this.music = {
            title: 'ID：' + value.id, // 必填字段
            author: 'dev', // 必填字段
            url: value.recordPath // 必填字段
            // url: 'http://cdnringuc.shoujiduoduo.com/ringres/user/a24/949/34307949.aac' // 必填字段
          }
        }
        // 点击播放，所有都变为播放按钮
        this.opeTableData.map(item => {
          item.isPlay = 0
          return item
        })
        // 当前点击的变为暂停按钮
        value.isPlay = 1
        this.recordStatus = true
        this.id = value.id
        // 显示控件播放状态
        this.isShowPlayer = true
        this.audioPlayer.playOrPause = true
      },
      // 监听播放器的播放事件
      handleAudioPlay () {
        this.opeTableData.map(item => {
          if (item.id === this.id) {
            item.isPlay = 1
          }
          return item
        })
      },
      // 监听播放器的暂停事件
      handleAudioPause () {
        this.opeTableData.map(item => {
          if (item.id === this.id) {
            item.isPlay = 2
          }
          return item
        })
      },
      // 监听播放中 以便获取 当前播放时间
      handleAudioPlaying (player) {
        // 播放对象
        this.aplayerObj = player
      },
      handleAudioError () {
        this.$message.error('获取录音文件资源失败')
      },
      // 关闭播放器
      handleCloseAplayer () {
        this.isShowPlayer = false
        if (this.aplayerObj) {
          // 点击搜索，播放暂停
          this.audioPlayer.playOrPause = false
          // 播放状态
          this.recordStatus = false
        }
      }
    }
  }
</script>

<style lang="scss" scoped>

  .operate-table-wrapper {
    /* fileName */
    .file-name {
      color: #2fa4e7;
      cursor: pointer;
      &:hover {
        text-decoration: underline;
        color: #428bca;
      }
    }
  }

  .footer-player {
    position: fixed;
    width: calc(100% - 20px);
    bottom: 0;
    left: 10px;
    z-index: 100;
    .el-icon-close {
      color: #cdcdcd;
      font-size: 20px;
      position: absolute;
      right: 7px;
      top: 7px;
      cursor: pointer;
    }
  }

</style>