/**
* 工作台-弹窗 Created by sunp
**/
<template>
  <div class="bench-dialog-wrapper">
    <el-dialog border stripe :visible.sync="dialogVisible" width="80%" top="5vh">
      <el-row :gutter="22">
        <el-col :span="7" class="task-list">
          <div class="task-list-title">呼叫策略执行阶段：</div>
          <div class="task-list-main">
            <ul>
              <li v-for="(item, key) in taskList" :key="key" :class="{'active': item.id === currentCallTaskId, 'gray': item.id === currentClickTaskId}" @click="handleTask(item.id, item.name)">
                <span>{{ item.name }}</span>
                <span>({{ item.num }})</span>
              </li>
            </ul>
          </div>
        </el-col>
        <el-col :span="17">
          <div style="height: 400px; border: 1px dashed #999;">
            <div style="height: 29px;">
              <el-checkbox-group v-if="currentClickTaskName !== '预约拨打'" v-model="phoneType" @change="phoneTypeChange" :disabled="currentCallTaskId === currentClickTaskId && benchMap[currentClickTaskId] && benchMap[currentClickTaskId].isStart !== 0">
                <el-checkbox label="1">
                  <span>本人</span>
                  <span>({{ phoneList1.length }})</span>
                </el-checkbox>
                <el-checkbox label="2">
                  <span>紧急联系人</span>
                  <span>({{ phoneList2.length }})</span>
                </el-checkbox>
                <el-checkbox label="3">
                  <span>银行卡预留</span>
                  <span>({{ phoneList3.length }})</span>
                </el-checkbox>
                <el-checkbox label="4">
                  <span>公司</span>
                  <span>({{ phoneList4.length }})</span>
                </el-checkbox>
                <el-checkbox label="5">
                  <span>手动添加</span>
                  <span>({{ phoneList5.length }})</span>
                </el-checkbox>
              </el-checkbox-group>
            </div>
            <div class="phone-list">
              <header>
                <span>最近状态码</span>
                <span>电话</span>
                <span>案件</span>
                <span>关系</span>
                <span v-if="benchMap[currentClickTaskId] && benchMap[currentClickTaskId].isStart === 0" style="cursor: pointer;" @click="handleTimes">
                  <strong v-if="timesStatus === 0">拨打次数<i class="el-icon-d-caret"></i></strong>
                  <strong v-if="timesStatus === 1" style="color: red;">拨打次数<i class="el-icon-caret-top"></i></strong>
                  <strong v-if="timesStatus === -1" style="color: red;">拨打次数<i class="el-icon-caret-bottom"></i></strong>
                </span>
                <span v-else>
                  <strong>拨打次数<i class="el-icon-d-caret"></i></strong>
                </span>
                <span v-if="benchMap[currentClickTaskId] && benchMap[currentClickTaskId].isStart === 0" style="cursor: pointer;" @click="handleCallAt">
                  <strong v-if="callAtStatus === 0">最近联系<i class="el-icon-d-caret"></i></strong>
                  <strong v-if="callAtStatus === 1" style="color: red;">最近联系<i class="el-icon-caret-top"></i></strong>
                  <strong v-if="callAtStatus === -1" style="color: red;">最近联系<i class="el-icon-caret-bottom"></i></strong>
                </span>
                <span v-else>
                  <strong>最近联系<i class="el-icon-d-caret"></i></strong>
                </span>
                <span v-if="benchMap[currentClickTaskId] && benchMap[currentClickTaskId].isStart === 0" style="cursor: pointer;" @click="handleMoney">
                  <strong v-if="moneyStatus === 0">金额<i class="el-icon-d-caret"></i></strong>
                  <strong v-if="moneyStatus === 1" style="color: red;">金额<i class="el-icon-caret-top"></i></strong>
                  <strong v-if="moneyStatus === -1" style="color: red;">金额<i class="el-icon-caret-bottom"></i></strong>
                </span>
                <span v-else>
                  <strong>金额<i class="el-icon-d-caret"></i></strong>
                </span>
              </header>
              <section ref="phoneListSection">
                <ul ref="phoneListUl">
                  <!--:class="{'active': item.currentCallTaskId === ringAndCall[1].assignmentId + item.realPhone === currentCallId}"-->
                  <!--<li v-for="(item, key) in phoneList" :key="key" v-bind:class="classObject(item, key)">-->
                  <li v-for="(item, key) in phoneList" :key="key">
                    <span>{{ item.resultDesc }}</span>
                    <span>{{ item.phone }}</span>
                    <span class="imitate-a-label" @click="openCaseDetail(item.caseId)">{{ item.oneSelfName }}</span>
                    <span>{{ item.name }}</span>
                    <span>
                      <span>{{ item.connectedTimes || 0 }}</span>
                      <span>/</span>
                      <span>{{ item.callTimes || 0 }}</span>
                    </span>
                    <span>{{ item.latestCallAt }}</span>
                    <span>{{ item.debt }}</span>
                  </li>
                </ul>
              </section>
            </div>
            <div>
              <span>拨打系数：</span>
              <el-input-number v-model="callRatio" size="mini" :min="1" :max="15" @change="callRatioChange"
                               :disabled="currentCallTaskId === currentClickTaskId && benchMap[currentClickTaskId] && benchMap[currentClickTaskId].isStart !== 0"></el-input-number>
              <span>控制同时呼出的电话数量，范围1~15的整数</span>
            </div>
            <div style="float: right;">
              <!--{{ currentCallTaskId }}-->
              <!--{{ currentClickTaskId }}-->
              <!--{{ benchMap[currentClickTaskId] }}-->
              <!--<el-button type="danger" size="mini" @click="handleBtn"></el-button>-->
              <el-button type="primary" size="mini" @click="handlePause(callRatio, 'dialog')"
                         v-if="benchMap[currentClickTaskId] && benchMap[currentClickTaskId].isStart === 1 && benchMap[currentClickTaskId].isPause === 0">暂停拨打</el-button>
              <el-button type="primary" size="mini" @click="handleContinue(callRatio, 'dialog')"
                         v-if="benchMap[currentClickTaskId] && benchMap[currentClickTaskId].isStart === 1 && benchMap[currentClickTaskId].isPause === 1">继续拨打</el-button>
              <el-button type="primary" size="mini" @click="handleStart"
                         v-if="benchMap[currentClickTaskId] && benchMap[currentClickTaskId].isStart === 0" :loading="isStartLoading">开始拨打</el-button>
              <el-button type="primary" size="mini" @click="handleStop(callRatio, 'dialog')"
                         v-if="benchMap[currentClickTaskId] && benchMap[currentClickTaskId].isStart === 1 && benchMap[currentClickTaskId].isStart === 1">停止</el-button>
            </div>
          </div>
        </el-col>
        <el-col :span="12">
          <!--<div v-if="Number(callRatio) > 1">-->
            <!--<div>等待接听</div>-->
            <!--<ul>-->
              <!--<li v-for="(item, key) in aiVoice" :key="key">-->
                <!--<span>{{ item.phone }}</span>-->
                <!--<span>{{ item.calledName }}</span>-->
                <!--<span>等待接听</span>-->
                <!--<span>{{ item.createTime }}</span>-->
              <!--</li>-->
            <!--</ul>-->
          <!--</div>-->
        </el-col>
        <el-col :span="12" style="float: right;">
          <div>提示</div>
          <ul>
            <li>1、已还款案件和承诺还款案件，本人及联系人将不会在无意愿任务中进行拨打</li>
            <li>2、批呼每次拨打都会切换线路</li>
            <li>3、标记为不要联系的号码将不会再拨打</li>
            <li>4、1个号码在一个小时内最多只会拨打10次</li>
            <li>5、已停催的案件将不会显示和拨打</li>
          </ul>
        </el-col>
      </el-row>
    </el-dialog>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  // import { base64decode } from 'utils/index'
  import {
    fetchGetTodayAssignment,
    fetchGetAssignmentContacts,
    fetchPauseTask, // 暂停
    fetchContinueTask, // 继续
    fetchStopTask // 停止
  } from '../../../api/case'
  export default {
    name: 'BenchDialog',
    computed: {
      ...mapGetters([
        'currentCRInfo', // 当前催记信息
        'isSubmitted', // 提交状态
        'isShowSmallBox', // 小按钮
        'serviceNum', // 坐席
        'showSelectObj', // 是否显示
        'displayName', // 显示中文名
        'userId', // userId
        'timeLimit' // 单呼点击限制
      ])
    },
    data () {
      return {
        dialogVisible: true,
        aiVoice: {}, // 等待接听的对象
        ringAndCall: {}, // 高亮的对象
        benchMap: {}, // 工作台map
        phoneMap: {}, // 通讯录map
        // 任务
        taskList: [], // 任务列表
        currentClickTaskName: null, // 当前点击任务的name
        currentClickTaskId: null, // 当前点击任务的id，高亮
        currentCallTaskId: null, // 当前呼叫任务的id，高亮
        // 电话
        phoneType: ['1'],
        phoneList: [], // 显示的
        phoneListAll: [], // 全部
        phoneList1: [], // 本人列表
        phoneList2: [], // 紧急联系人列表
        phoneList3: [], // 银行卡预留列表
        phoneList4: [], // 公司列表
        phoneList5: [], // 手动添加列表
        callRatio: 1,
        count: 0,
        currentScrollTopIndex: 0, // 当前滑块的索引
        currentCallId: 0, // 当前拨打电话的id，高亮
        // 定时刷新任务列表
        timeOut: null,
        getTaskCount: 0, // 计数（获取任务的次数）

        // 拨打次数排序
        timesStatus: 0,
        callAtStatus: 0,
        moneyStatus: 0,

        // 开始拨打loading
        isStartLoading: false,
        timeFun: null
      }
    },
    // watch: {
    //   benchMap (val) {
    //     console.log(val)
    //   }
    // },
    created () {
    },
    mounted () {
      let that = this
      // 工作台任务列表
      this.getTodayAssignment()
      this.timeOut = setInterval(function () {
        that.getTodayAssignment()
      }, 1000 * 60)
    },
    beforeDestroy () {
      clearInterval(this.timeOut)
      clearInterval(this.timeFun)
    },
    methods: {
      // 高亮当前电话
      // classObject (item, key) {
      //   for (const i in this.ringAndCall) {
      //     // :class="{'active': item.currentCallTaskId === ringAndCall[1].assignmentId + item.realPhone === currentCallId}"
      //     if (this.currentCallTaskId === this.ringAndCall[i].assignmentId && this.ringAndCall[i].phone.indexOf(base64decode(item.realPhone)) > -1) {
      //       // this.currentScrollTopIndex = key
      //       // // ul内容超出，出现滚动条，那么可以改变scrollTop
      //       // if (this.$refs.phoneListUl.clientHeight > 280) {
      //       //   this.$refs.phoneListSection.scrollTop = 20 * this.currentScrollTopIndex
      //       // }
      //       return {
      //         active: true
      //       }
      //     }
      //   }
      // },
      // 工作台任务列表
      async getTodayAssignment () {
        const response = await fetchGetTodayAssignment()
        const res = response.data
        if (res.errorCode === 0) {
          // console.log(this.getTaskCount)
          if (!this.getTaskCount) {
            this.taskList = res.data.map(item => {
              this.$set(this.benchMap, item.id, {isStart: 0, isPause: 0, count: 0})
              this.$set(this.phoneMap, item.id, {phoneType: ['1'], callRatio: 1, currentHighlight: 0, phoneList: [], timesStatus: 0, callAtStatus: 0, moneyStatus: 0})
              return item
            })
          } else {
            this.taskList = res.data
          }
          this.getTaskCount += 1
        }
      },
      returnPhoneList (phoneType) {
        if (phoneType) {
          if (!phoneType.length) {
            this.phoneList = []
          } else {
            if (phoneType.length === 1) {
              if (phoneType.indexOf('1') > -1) {
                this.phoneList = this.phoneList1
              } else if (phoneType.indexOf('2') > -1) {
                this.phoneList = this.phoneList2
              } else if (phoneType.indexOf('3') > -1) {
                this.phoneList = this.phoneList3
              } else if (phoneType.indexOf('4') > -1) {
                this.phoneList = this.phoneList4
              } else if (phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList5
              }
            } else if (phoneType.length === 2) {
              if (phoneType.indexOf('1') > -1 && phoneType.indexOf('2') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList2)
              } else if (phoneType.indexOf('1') > -1 && phoneType.indexOf('3') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList3)
              } else if (phoneType.indexOf('1') > -1 && phoneType.indexOf('4') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList4)
              } else if (phoneType.indexOf('1') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList5)
              } else if (phoneType.indexOf('2') > -1 && phoneType.indexOf('3') > -1) {
                this.phoneList = this.phoneList2.concat(this.phoneList3)
              } else if (phoneType.indexOf('2') > -1 && phoneType.indexOf('4') > -1) {
                this.phoneList = this.phoneList2.concat(this.phoneList4)
              } else if (phoneType.indexOf('2') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList2.concat(this.phoneList5)
              } else if (phoneType.indexOf('3') > -1 && phoneType.indexOf('4') > -1) {
                this.phoneList = this.phoneList3.concat(this.phoneList4)
              } else if (phoneType.indexOf('3') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList3.concat(this.phoneList5)
              } else if (phoneType.indexOf('4') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList4.concat(this.phoneList5)
              }
            } else if (phoneType.length === 3) {
              if (phoneType.indexOf('1') > -1 && phoneType.indexOf('2') > -1 && phoneType.indexOf('3') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList2).concat(this.phoneList3)
              } else if (phoneType.indexOf('1') > -1 && phoneType.indexOf('2') > -1 && phoneType.indexOf('4') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList2).concat(this.phoneList4)
              } else if (phoneType.indexOf('1') > -1 && phoneType.indexOf('2') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList2).concat(this.phoneList5)
              } else if (phoneType.indexOf('1') > -1 && phoneType.indexOf('3') > -1 && phoneType.indexOf('4') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList3).concat(this.phoneList4)
              } else if (phoneType.indexOf('1') > -1 && phoneType.indexOf('3') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList3).concat(this.phoneList5)
              } else if (phoneType.indexOf('1') > -1 && phoneType.indexOf('4') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList4).concat(this.phoneList5)
              } else if (phoneType.indexOf('2') > -1 && phoneType.indexOf('3') > -1 && phoneType.indexOf('4') > -1) {
                this.phoneList = this.phoneList2.concat(this.phoneList3).concat(this.phoneList4)
              } else if (phoneType.indexOf('2') > -1 && phoneType.indexOf('3') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList2.concat(this.phoneList3).concat(this.phoneList5)
              } else if (phoneType.indexOf('2') > -1 && phoneType.indexOf('4') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList2.concat(this.phoneList4).concat(this.phoneList5)
              } else if (phoneType.indexOf('3') > -1 && phoneType.indexOf('4') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList3.concat(this.phoneList4).concat(this.phoneList5)
              }
            } else if (phoneType.length === 4) {
              if (phoneType.indexOf('1') > -1 && phoneType.indexOf('2') > -1 && phoneType.indexOf('3') > -1 && phoneType.indexOf('4') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList2).concat(this.phoneList3).concat(this.phoneList4)
              } else if (phoneType.indexOf('1') > -1 && phoneType.indexOf('2') > -1 && phoneType.indexOf('3') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList2).concat(this.phoneList3).concat(this.phoneList5)
              } else if (phoneType.indexOf('1') > -1 && phoneType.indexOf('2') > -1 && phoneType.indexOf('4') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList2).concat(this.phoneList4).concat(this.phoneList5)
              } else if (phoneType.indexOf('1') > -1 && phoneType.indexOf('3') > -1 && phoneType.indexOf('4') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList1.concat(this.phoneList3).concat(this.phoneList4).concat(this.phoneList5)
              } else if (phoneType.indexOf('2') > -1 && phoneType.indexOf('3') > -1 && phoneType.indexOf('4') > -1 && phoneType.indexOf('5') > -1) {
                this.phoneList = this.phoneList2.concat(this.phoneList3).concat(this.phoneList4).concat(this.phoneList5)
              }
            } else if (phoneType.length === 5) {
              this.phoneList = this.phoneListAll
            }
          }
        }
      },
      // 工作台任务通讯录列表
      async getAssignmentContacts (id) {
        const response = await fetchGetAssignmentContacts(id)
        const res = response.data
        if (res.errorCode === 0) {
          this.phoneListAll = res.data
          // 1:本人 2:家人,3:朋友,4:同事,5:公司,6:银行预留,20:新添加
          this.phoneList1 = res.data.filter(item => item.order === 1)
          this.phoneList2 = res.data.filter(item => item.order === 2 || item.order === 3 || item.order === 4)
          this.phoneList3 = res.data.filter(item => item.order === 6)
          this.phoneList4 = res.data.filter(item => item.order === 5)
          this.phoneList5 = res.data.filter(item => item.order === 20)
          let phoneType = this.phoneMap[id].phoneType
          let callRatio = this.phoneMap[id].callRatio
          let timesStatus = this.phoneMap[id].timesStatus
          let callAtStatus = this.phoneMap[id].callAtStatus
          let moneyStatus = this.phoneMap[id].moneyStatus
          this.phoneType = phoneType
          this.callRatio = callRatio
          this.timesStatus = timesStatus
          this.callAtStatus = callAtStatus
          this.moneyStatus = moneyStatus
          // 切换任务时，是预约拨打则全部是phoneList，无则走returnPhoneList方法计算对应的phoneList
          if (this.currentClickTaskName === '预约拨打') {
            this.phoneList = this.phoneListAll
          } else {
            this.returnPhoneList(phoneType)
          }
          // 再根据当前的排序规则重新排序
          if (this.phoneMap[this.currentClickTaskId].timesStatus) {
            this.timesStatus = this.timesStatus === 0 ? 1 : this.timesStatus === 1 ? -1 : 1
            this.handleTimes()
          } else if (this.phoneMap[this.currentClickTaskId].callAtStatus) {
            this.callAtStatus = this.callAtStatus === 0 ? 1 : this.callAtStatus === 1 ? -1 : 1
            this.handleCallAt()
          } else if (this.phoneMap[this.currentClickTaskId].moneyStatus) {
            this.moneyStatus = this.moneyStatus === 0 ? 1 : this.moneyStatus === 1 ? -1 : 1
            this.handleMoney()
          }
          // 获取通讯录缓存到phoneMap
          this.$set(this.phoneMap, id, {phoneType, callRatio, currentHighlight: 0, phoneList: this.phoneList, timesStatus, callAtStatus, moneyStatus})
        }
      },
      // phone类型change
      phoneTypeChange (val) {
        // console.log(val)
        if (val) {
          this.returnPhoneList(val)
          // 切换时，记录状态，从新排序
          if (this.phoneMap[this.currentClickTaskId].timesStatus) {
            this.timesStatus = this.timesStatus === 0 ? 1 : this.timesStatus === 1 ? -1 : 1
            this.handleTimes()
          } else if (this.phoneMap[this.currentClickTaskId].callAtStatus) {
            this.callAtStatus = this.callAtStatus === 0 ? 1 : this.callAtStatus === 1 ? -1 : 1
            this.handleCallAt()
          } else if (this.phoneMap[this.currentClickTaskId].moneyStatus) {
            this.moneyStatus = this.moneyStatus === 0 ? 1 : this.moneyStatus === 1 ? -1 : 1
            this.handleMoney()
          }
          // console.log(this.phoneList)
        }
        this.$set(this.phoneMap, this.currentClickTaskId, {phoneType: this.phoneType, callRatio: this.callRatio, currentHighlight: 0, phoneList: this.phoneList, timesStatus: this.timesStatus, callAtStatus: this.callAtStatus, moneyStatus: this.moneyStatus})
      },
      // 系数change
      callRatioChange (val) {
        // console.log(val)
        // console.log(this.callRatio)
        // console.log(this.currentClickTaskId)
        this.$set(this.phoneMap, this.currentClickTaskId, {phoneType: this.phoneType, callRatio: val, currentHighlight: 0, phoneList: this.phoneList, timesStatus: this.timesStatus, callAtStatus: this.callAtStatus, moneyStatus: this.moneyStatus})
        // console.log(this.phoneMap)
      },
      // 点击任务列表
      handleTask (id, name) {
        // console.log(id)
        // console.log(name)
        // console.log(this.phoneMap)
        this.currentClickTaskName = name
        // 高亮对应的行
        this.currentClickTaskId = id
        // 请求对应任务通讯录列表
        this.getAssignmentContacts(id)
      },
      // 打开案件详情-新页面
      openCaseDetail (caseId) {
        window.open('#/case-detail/' + caseId)
      },
      // 模拟电话来一个，高亮一个电话列表对应的行
      handleBtn () {
        // this.count += 5
        // this.currentCallId += 1
        // console.log(this.$refs.phoneListUl.clientHeight)
        if (this.$refs.phoneListUl.clientHeight > 50) {
          // this.$refs.phoneListSection.scrollTop = 20 * this.currentScrollTopIndex
          this.$refs.phoneListSection.scrollTop = 20 * 2
        }
        // this.$refs.phoneListUl.scrollTop = 20 * this.currentScrollTopIndex
      },
      // 开始
      handleStart () {
        // 开始拨打按钮设置3s延时拨打
        let that = this
        this.isStartLoading = true
        this.timeFun = setTimeout(function () {
          that.isStartLoading = false
        }, 1000 * 3)
        if (this.isSubmitted) {
          if (this.phoneList && !this.phoneList.length) {
            this.$message.warning('没有通讯录，不能拨打')
            return false
          }
          // 如果点击开始，那么当前呼叫任务的id = 当前点击任务的id
          this.currentCallTaskId = this.currentClickTaskId
          // 该任务正在进行中
          this.$emit('listenStart', this.phoneList, Number(this.callRatio), this.currentCallTaskId)
          if (Number(this.callRatio) === 1) {
            this.$emit('listenPauseOrContinue', 'start', this.phoneList, this.benchMap[this.currentClickTaskId].count)
          }
          // 开始批呼不用传start，批呼接口成功后再
          // else if (Number(this.callRatio) > 1) {
          //   this.$emit('listenResetBatch', 'start')
          // }
        } else {
          this.$message.warning('当前通话还未全部挂断，请稍后再试。')
        }
      },
      // 设置按钮状态
      setIsStart (val, count, callRatio) {
        // console.log(val)
        // console.log(count)
        // console.log(this.phoneMap[this.currentCallTaskId].phoneList)
        if (val === 1) {
          this.$set(this.benchMap, this.currentCallTaskId, {isStart: 1, isPause: 0, count})
          this.$emit('listenPauseOrContinue', 'continue', this.phoneMap[this.currentCallTaskId].phoneList, count)
        } else if (val === 0) {
          // 按钮变为开始，任务列表高亮清除，通讯录列表高亮清除
          this.$set(this.benchMap, this.currentCallTaskId, {isStart: 0, isPause: 0, count})
          // this.currentCallTaskId = null // todo 停止后高亮--暂时
          // this.currentCallId = null
          if (Number(callRatio) > 1) {
            this.$emit('listenResetBatch', 'reset')
          }
        }
        // console.log(this.benchMap)
      },
      // 设置按钮状态-批呼
      setIsStartBatch (val) {
        // console.log(val)
        if (val === 1) {
          this.$set(this.benchMap, this.currentCallTaskId, {isStart: 1, isPause: 0})
          // this.$emit('listenPauseOrContinue', 'continue', this.phoneList, count)
        } else if (val === 0) {
          // 按钮变为开始，任务列表高亮清除，通讯录列表高亮清除
          this.$set(this.benchMap, this.currentCallTaskId, {isStart: 0, isPause: 0})
          // this.currentCallTaskId = null // todo 停止后高亮--暂时
          // this.currentCallId = null
        }
        // console.log(this.benchMap)
      },
      // 暂停
      handlePause (callRatio, val) {
        this.$emit('listenCallRatio', callRatio)
        // 如果点击开始，那么当前呼叫任务的id = 当前点击任务的id
        if (val === 'dialog') {
          this.currentCallTaskId = this.currentClickTaskId
        }
        // this.currentCallTaskId = this.currentClickTaskId
        if (Number(callRatio) === 1) {
          this.$set(this.benchMap, this.currentCallTaskId, {isStart: 1, isPause: 1, count: this.benchMap[this.currentCallTaskId].count})
          this.$emit('listenPauseOrContinue', 'pause', this.phoneMap[this.currentCallTaskId].phoneList, this.benchMap[this.currentCallTaskId].count)
        } else if (Number(callRatio) > 1) {
          if (val === 'from') {
            this.$set(this.benchMap, this.currentCallTaskId, {isStart: 1, isPause: 1})
          } else {
            this.$set(this.benchMap, this.currentCallTaskId, {isStart: 1, isPause: 1})
            this.$emit('listenPauseBatch')
          }
          let reason = null
          fetchPauseTask(this.currentCallTaskId, this.serviceNum, reason)
            .then(response => {
              let res = response.data
              if (res.errorCode === 0) {
                console.log('暂停成功')
                // this.isPause = true
                // this.$refs.benchDialog.handlePause('from')
              }
            })
            .catch(error => {
              console.log(error)
            })
        }
      },
      // 继续
      handleContinue (callRatio, val) {
        this.$emit('listenCallRatio', callRatio)
        // 如果点击开始，那么当前呼叫任务的id = 当前点击任务的id
        if (val === 'dialog') {
          this.currentCallTaskId = this.currentClickTaskId
        }
        // this.currentCallTaskId = this.currentClickTaskId
        if (Number(callRatio) === 1) {
          this.$set(this.benchMap, this.currentCallTaskId, {isStart: 1, isPause: 0, count: this.benchMap[this.currentCallTaskId].count})
          this.$emit('listenPauseOrContinue', 'continue', this.phoneMap[this.currentCallTaskId].phoneList, this.benchMap[this.currentCallTaskId].count)
        } else if (Number(callRatio) > 1) {
          if (val === 'from') {
            this.$set(this.benchMap, this.currentCallTaskId, {isStart: 1, isPause: 0})
          } else {
            this.$set(this.benchMap, this.currentCallTaskId, {isStart: 1, isPause: 0})
            this.$emit('listenContinueBatch')
          }
          let reason = null
          fetchContinueTask(this.currentCallTaskId, this.serviceNum, reason)
            .then(response => {
              let res = response.data
              if (res.errorCode === 0) {
                console.log('继续成功')
                // this.isPause = false
                // this.$refs.benchDialog.handleContinue('from')
              }
            })
            .catch(error => {
              console.log(error)
            })
        }
      },
      // 停止
      handleStop (callRatio, val) {
        this.$emit('listenCallRatio', callRatio)
        // 如果点击开始，那么当前呼叫任务的id = 当前点击任务的id
        if (val === 'dialog') {
          this.currentCallTaskId = this.currentClickTaskId
        }
        // this.currentCallTaskId = this.currentClickTaskId
        if (Number(callRatio) === 1) {
          this.$confirm('任务停止后，下次拨打将重新开始，是否要停止?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.$set(this.benchMap, this.currentCallTaskId, {isStart: 0, isPause: 0, count: this.benchMap[this.currentCallTaskId].count})
            this.$emit('listenPauseOrContinue', 'stop', this.phoneMap[this.currentCallTaskId].phoneList, this.benchMap[this.currentCallTaskId].count)
          }).catch(() => {
            console.log('取消停止')
          })

        } else if (Number(callRatio) > 1) {
          if (val === 'from') {
            this.$confirm('任务停止后，下次拨打将重新开始，是否要停止?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              // this.$set(this.benchMap, this.currentClickTaskId, {isStart: 0, isPause: 0})
              let reason = null
              fetchStopTask(this.currentCallTaskId, this.serviceNum, reason)
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0) {
                    console.log('停止成功')
                    this.setIsStart(0, 0)
                    // this.isShowCallBtn = false
                    // this.$refs.benchDialog.handleStop('from')
                    // this.$refs.benchDialog.setIsStart(0, 0)
                  }
                })
                .catch(error => {
                  console.log(error)
                })
            }).catch(() => {
              console.log('取消停止')
            })
          } else {
            // this.$set(this.benchMap, this.currentClickTaskId, {isStart: 0, isPause: 0})
            this.$emit('listenStopBatch')
          }
        }
      },
      // 拨打次数点击排序
      handleTimes () {
        this.callAtStatus = 0
        this.moneyStatus = 0
        this.timesStatus = this.timesStatus === 0 ? 1 : this.timesStatus === 1 ? -1 : 1
        if (this.phoneList && this.phoneList.length) {
          if (this.timesStatus === 1) {
            this.phoneList = this.phoneList.sort((a, b) => {
              return a.callTimes - b.callTimes
            })
          } else {
            this.phoneList = this.phoneList.sort((a, b) => {
              return b.callTimes - a.callTimes
            })
          }
        }
        this.$set(this.phoneMap, this.currentClickTaskId, {phoneType: this.phoneType, callRatio: this.callRatio, currentHighlight: 0, phoneList: this.phoneList, timesStatus: this.timesStatus, callAtStatus: this.callAtStatus, moneyStatus: this.moneyStatus})
      },
      // 最近联系点击排序
      handleCallAt () {
        this.timesStatus = 0
        this.moneyStatus = 0
        this.callAtStatus = this.callAtStatus === 0 ? 1 : this.callAtStatus === 1 ? -1 : 1
        if (this.phoneList && this.phoneList.length) {
          if (this.callAtStatus === 1) {
            this.phoneList = this.phoneList.sort((a, b) => {
              return new Date(a.latestCallAt).getTime() - new Date(b.latestCallAt).getTime()
            })
          } else {
            this.phoneList = this.phoneList.sort((a, b) => {
              return new Date(b.latestCallAt).getTime() - new Date(a.latestCallAt).getTime()
            })
          }
        }
        this.$set(this.phoneMap, this.currentClickTaskId, {phoneType: this.phoneType, callRatio: this.callRatio, currentHighlight: 0, phoneList: this.phoneList, timesStatus: this.timesStatus, callAtStatus: this.callAtStatus, moneyStatus: this.moneyStatus})
      },
      // 金额点击排序
      handleMoney () {
        this.timesStatus = 0
        this.callAtStatus = 0
        this.moneyStatus = this.moneyStatus === 0 ? 1 : this.moneyStatus === 1 ? -1 : 1
        if (this.phoneList && this.phoneList.length) {
          if (this.moneyStatus === 1) {
            this.phoneList = this.phoneList.sort((a, b) => {
              return a.debt - b.debt
            })
          } else {
            this.phoneList = this.phoneList.sort((a, b) => {
              return b.debt - a.debt
            })
          }
        }
        this.$set(this.phoneMap, this.currentClickTaskId, {phoneType: this.phoneType, callRatio: this.callRatio, currentHighlight: 0, phoneList: this.phoneList, timesStatus: this.timesStatus, callAtStatus: this.callAtStatus, moneyStatus: this.moneyStatus})
      }
    }
  }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  .bench-dialog-wrapper {
    /deep/ .el-dialog__wrapper {
      /*z-index: 20000!important;*/
    }
    .gray {
      background-color: gray;
      color: #fff;
    }
    .active {
      background-color: #0a6cd6;
      color: #fff;
    }
    .task-list {
      min-width: 180px;
      height: 400px;
      border: 1px dashed #999;
      .task-list-title {
        height: 29px;
        border-bottom: 1px dashed #999;
      }
      .task-list-main {
        height: 370px;
        overflow: auto;
        ul {
          height: 100%;
          li {
            cursor: pointer;
            &:hover {
              background-color: #aaa;
              color: #fff;
            }
          }
        }
      }
    }
    .phone-list {
      width: 100%;
      font-size: 12px;
      height: 300px;
      border-bottom: 1px dashed #999;
      border-top: 1px dashed #999;
      header {
        height: 20px;
        line-height: 20px;
        margin-right: 15px;
        display: flex;
        justify-content: space-between;
        span {
          display: inline-block;
          text-align: center;
        }
        span:nth-child(1) {
          width: 15%;
        }
        span:nth-child(2) {
          width: 15%;
        }
        span:nth-child(3) {
          width: 10%;
        }
        span:nth-child(4) {
          width: 15%;
        }
        span:nth-child(5) {
          width: 15%;
        }
        span:nth-child(6) {
          width: 20%;
        }
        span:nth-child(7) {
          width: 10%;
        }
      }
      section {
        height: 280px;
        overflow: auto;
        ul {
          li {
            display: flex;
            justify-content: space-between;
            /*height: 20px;*/
            line-height: 20px;
            span {
              display: inline-block;
              text-align: center;
            }
            span:nth-child(1) {
              width: 15%;
            }
            span:nth-child(2) {
              width: 15%;
            }
            span:nth-child(3) {
              width: 10%;
            }
            span:nth-child(4) {
              width: 15%;
            }
            span:nth-child(5) {
              width: 15%;
            }
            span:nth-child(6) {
              width: 20%;
            }
            span:nth-child(7) {
              width: 10%;
            }
          }
        }
      }
    }
  }
</style>
