<!--选择短信模板弹窗-->

<template>
  <div>
    <!-- 选择短信模板 -->
    <el-dialog title="选择短信模板" :visible.sync="sendSmsProps.dialogVisible" class="send-sms-wrapper" @close="handleClose">
      <el-form :model="form" :rules="rules" ref="form" label-width="80px">
        <h3>发给本人</h3>
        <el-form-item label="模板名称">
          <el-row type="flex" class="row-bg" justify="space-between">
            <el-col :span="10">
              <el-select v-model="form.name1" placeholder="请选择要发送的短信" @change="toSelfChange" clearable>
                <el-option v-for="item in smsList1" :key="item.id" :label="item.name" :value="item.id"></el-option>
              </el-select>
            </el-col>
            <el-col :span="8">
              <span style="color: red; font-size: 12px;">{{ nameMsg1 }}</span>
            </el-col>
            <el-col :span="6">
              <span class="imitate-a-label" style="float: right;" @click="check(1)">短信通道可用性</span>
            </el-col>
          </el-row>
        </el-form-item>
        <el-form-item label="短信内容" prop="content">
          <el-input type="textarea" disabled :rows="2" placeholder="" v-model="form.content1"></el-input>
        </el-form-item>
        <h3>发给联系人</h3>
        <el-form-item label="模板名称">
          <el-row type="flex" class="row-bg" justify="space-between">
            <el-col :span="10">
              <el-select v-model="form.name2" placeholder="请选择要发送的短信" @change="toContactChange" clearable>
                <el-option v-for="item in smsList2" :key="item.id" :label="item.name" :value="item.id"></el-option>
              </el-select>
            </el-col>
            <el-col :span="8">
              <span style="color: red; font-size: 12px;">{{ nameMsg2 }}</span>
            </el-col>
            <el-col :span="6">
              <span class="imitate-a-label" style="float: right;" @click="check(2)">短信通道可用性</span>
            </el-col>
          </el-row>
        </el-form-item>
        <el-form-item label="短信内容" prop="content">
          <el-input type="textarea" disabled :rows="2" placeholder="" v-model="form.content2"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleCancel">取 消</el-button>
        <el-button type="primary" @click="handleConfirm" :loading="btnLoading">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 选择短信模板 -->
    <el-dialog title="短信通道可用性" :visible.sync="checkDialogVisible">
      <el-table :data="checkData" style="width: 100%" border v-loading="listLoading" :max-height="tableHeight">
        <el-table-column align="center" type="index"></el-table-column>
        <el-table-column align="center" prop="contactName" label="联系人"></el-table-column>
        <el-table-column align="center" prop="phone" label="号码"></el-table-column>
        <el-table-column align="center" prop="telecomOperators" label="运营商"></el-table-column>
        <el-table-column align="center" label="是否可用">
          <template slot-scope="scope">
            <span v-if="scope.row.telecoStatus">可用</span>
            <span v-else>不可用</span>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
  import {
    fetchGetSmsTemplate, // 获得短信模板
    fetchAddToSendList, // 发送短信
    fetchCheckSmsChannelAvailable // 检查短信通道可用性
  } from '../../../api/sms'
  export default {
    props: {
      // 是否打开选择短信模板弹窗
      sendSmsProps: {
        required: true
      }
    },
    data () {
      return {
        // 编辑项目弹窗
        // dialogEditProject: dialogProject, // 是否打开编辑项目弹窗
        form: {
          name1: '', // 项目名称
          content1: '', // 项目名单
          id1: '',
          name2: '', // 项目名称
          content2: '', // 项目名单
          id2: ''
        },
        btnLoading: false, // 确认按钮loading
        nameMsg1: '', // 提示信息1
        nameMsg2: '', // 提示信息2
        rules: {
          name1: [
            { required: true, message: '请选择模板名称', trigger: 'change' }
          ],
          name2: [
            { required: true, message: '请选择模板名称', trigger: 'change' }
          ]
        },
        smsList1: [],
        smsList2: [],
        checkDialogVisible: false,
        listLoading: false,
        tableHeight: '600',
        checkData: []
      }
    },
    watch: {
      'sendSmsProps.dialogVisible' (val) {
        if (val) {
          // 获取短信模板
          this.getSmsList(1)
          this.getSmsList(2)
        }
      }
    },
    methods: {
      // 获取短信模板
      getSmsList (type) {
        // 联系人类型 1-本人, 2-联系人
        fetchGetSmsTemplate(this.sendSmsProps.productId, type)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              if (type === 1) {
                this.smsList1 = res.data
              } else if (type === 2) {
                this.smsList2 = res.data
              }
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 本人
      toSelfChange (val) {
        // 选择本人后，错误提示信息置空
        this.nameMsg1 = ''
        this.nameMsg2 = ''
        this.smsList1.map(item => {
          if (val === item.id) {
            this.form.content1 = item.content
            this.form.id1 = item.id
          }
          return item
        })
      },
      // 联系人
      toContactChange (val) {
        // 选择联系人后，错误提示信息置空
        this.nameMsg1 = ''
        this.nameMsg2 = ''
        this.smsList2.map(item => {
          if (val === item.id) {
            this.form.content2 = item.content
            this.form.id2 = item.id
          }
          return item
        })
      },
      // 确认
      handleConfirm () {
        this.submitForm('form')
      },
      // 取消
      handleCancel () {
        this.handleClose()
        this.sendSmsProps.dialogVisible = false
      },
      // 关闭
      handleClose () {
        this.resetForm('form')
        this.nameMsg1 = ''
        this.nameMsg2 = ''
        this.form = {
          name1: '', // 项目名称
          content1: '', // 项目名单
          id1: '',
          name2: '', // 项目名称
          content2: '', // 项目名单
          id2: ''
        }
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (!this.form.name1 && !this.form.name2) {
              this.nameMsg1 = '请选择模板名称'
              this.nameMsg2 = '请选择模板名称'
              return false
            }
            this.btnLoading = true
            let caseId = this.sendSmsProps.caseId
            let orderId = this.sendSmsProps.orderId
            let debtorTempletId = this.form.id1
            let contactTempletId = this.form.id2
            fetchAddToSendList(caseId, orderId, debtorTempletId, contactTempletId)
              .then(response => {
                let res = response.data
                if (res.errorCode === 0) {
                  this.sendSmsProps.dialogVisible = false
                  this.$message.success('添加到发送队列成功')
                }
                this.btnLoading = false
              })
              .catch(error => {
                console.log(error)
                this.btnLoading = false
              })
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      // 检查短信通达可用性
      check (type) {
        this.checkDialogVisible = true
        this.listLoading = true
        let caseId = this.sendSmsProps.caseId
        fetchCheckSmsChannelAvailable(caseId, type)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.checkData = res.data
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      }
    }
  }
</script>

<style lang="scss" scoped>

  .send-sms-wrapper {
    .length-1 {
      width: 140px;
    }
  }
</style>