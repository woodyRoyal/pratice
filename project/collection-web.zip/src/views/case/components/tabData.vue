
<!-- tab 信息 -->

<template>
  <div>
  <el-tabs v-model="activeName" @tab-click="handleTabsClick" class="tab-data-wrapper">
    <!-- 用户操作 -->
    <el-tab-pane v-if="productId !== 6 && productId !== 10" label="用户操作" name="first">
      <!-- 日期 -->
      <el-form ref="userOperationForm" :model="userOperationForm">
        <el-form-item label="日期">
          <el-date-picker
            class="w-240"
            v-model="userOperationForm.date"
            type="daterange"
            size="small"
            :editable="false"
            :clearable="false"
            unlink-panels
            range-separator="-"
            start-placeholder="开始日期"
            end-placeholder="结束日期">
          </el-date-picker>
          <el-select class="w-140" v-model="userOperationForm.product" placeholder="请选择产品" size="small">
            <el-option v-for="(item,index) in productList" :key="index" :label="item.productName" :value="item.productId"></el-option>
          </el-select>
          <el-button type="primary" size="small" @click="userOperationSearchBtn">搜索</el-button>
        </el-form-item>
      </el-form>
      <!-- 表格 -->
      <el-table :data="userOperationTableData" stripe border style="width: 100%"
                v-loading="userOperationMsg.listLoading" :max-height="userOperationMsg.maxTableHeight">
        <el-table-column align="center" prop="operateDate" label="操作日期" min-width="60"></el-table-column>
        <el-table-column align="center" prop="operateTime" label="时间" min-width="60"></el-table-column>
        <!--<el-table-column align="center" prop="product" label="产品" min-width="60"></el-table-column>-->
        <el-table-column align="center" prop="operationDesc" label="操作" min-width="60"></el-table-column>
      </el-table>
      <!-- 分页开始-->
      <div v-show="!userOperationMsg.listLoading" class="pagination-container">
        <el-pagination @size-change="handleSizeChangeUser" @current-change="handleCurrentChangeUser"
                       :current-page.sync="userOperationMsg.pagData.pageNo" :page-sizes="userOperationMsg.pageSizes"
                       :page-size="userOperationMsg.pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                       :total="userOperationMsg.totalRecord">
        </el-pagination>
      </div>
      <!-- 分页结束-->
    </el-tab-pane>

    <!-- 交易记录 -->
    <el-tab-pane label="交易记录" name="second">
      <!-- 日期 -->
      <el-form ref="tradeRecordForm" :model="tradeRecordForm">
        <el-form-item label="日期">
          <el-date-picker
            class="w-240"
            v-model="tradeRecordForm.date"
            type="daterange"
            size="small"
            :editable="false"
            :clearable="false"
            unlink-panels
            range-separator="-"
            start-placeholder="开始日期"
            end-placeholder="结束日期">
          </el-date-picker>
          <el-select class="w-140" v-model="tradeRecordForm.product" placeholder="请选择产品" size="small">
            <el-option v-for="(item,index) in productList" :key="index" :label="item.productName" :value="item.productId"></el-option>
          </el-select>
          <el-button type="primary" size="small" @click="tradeRecordSearchBtn">搜索</el-button>
        </el-form-item>
      </el-form>
      <!-- 表格 -->
      <el-table :data="tradeRecordTableData" stripe border style="width: 100%"
                v-loading="tradeRecordMsg.listLoading" :max-height="tradeRecordMsg.maxTableHeight">
        <el-table-column align="center" prop="operateDate" label="日期" min-width="60"></el-table-column>
        <el-table-column align="center" prop="operateTime" label="时间" min-width="60"></el-table-column>
        <!--<el-table-column align="center" prop="product" label="产品" min-width="60"></el-table-column>-->
        <el-table-column align="center" prop="operateDesc" label="操作" min-width="60"></el-table-column>
        <!--<el-table-column align="center" prop="productName" label="资金方" min-width="60"></el-table-column>-->
        <el-table-column align="center" prop="operateResult" label="操作结果" min-width="60">
          <!--<template slot-scope="scope">-->
            <!--&lt;!&ndash;通过返回的list判断&ndash;&gt;-->
            <!--<span v-if="!scope.row.failList">还款成功</span>-->
            <!--<span v-else class="imitate-a-label" @click="showLoseDetail(scope.row)">还款失败</span>-->
            <!--&lt;!&ndash;<span @click="showLoseDetail(scope.row)" class="imitate-a-label">{{scope.row.operateResult}}</span>&ndash;&gt;-->
          <!--</template>-->
        </el-table-column>
      </el-table>
      <!-- 分页开始-->
      <div v-show="!tradeRecordMsg.listLoading" class="pagination-container">
        <el-pagination @size-change="handleSizeChangeTrade" @current-change="handleCurrentChangeTrade"
                       :current-page.sync="tradeRecordMsg.pagData.pageNo" :page-sizes="tradeRecordMsg.pageSizes"
                       :page-size="tradeRecordMsg.pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                       :total="tradeRecordMsg.totalRecord">
        </el-pagination>
      </div>
    </el-tab-pane>

    <!--todo 20190419 隐藏-->
    <!--&lt;!&ndash;逾期记录&ndash;&gt;-->
    <!--<el-tab-pane v-if="productId !== 6 && productId !== 10" :label="'逾期记录（' + overdueNum + '条）'" name="third">-->
      <!--&lt;!&ndash; 表格 &ndash;&gt;-->
      <!--<el-table :data="overdueRecordTableData" stripe border style="width: 100%"-->
                <!--v-loading="overdueRecordMsg.listLoading" :max-height="overdueRecordMsg.maxTableHeight">-->
        <!--<el-table-column align="center" prop="borrowTime" label="借款日期" min-width="60"></el-table-column>-->
        <!--<el-table-column align="center" prop="productName" label="产品" min-width="60"></el-table-column>-->
        <!--<el-table-column align="center" prop="borrowAmount" label="借款金额(元)" min-width="40"></el-table-column>-->
        <!--<el-table-column align="center" prop="repaymentDate" label="还清时间" min-width="60"></el-table-column>-->
        <!--<el-table-column align="center" prop="overdueDays" label="逾期天数" min-width="40"></el-table-column>-->
        <!--<el-table-column align="center" label="详情" min-width="60">-->
          <!--<template slot-scope="scope">-->
            <!--<span v-if="scope.row.detail">当前案件</span>-->
            <!--<span v-else class="imitate-a-label" @click="toCaseDetail(scope.row.caseId)">查看</span>-->
          <!--</template>-->
        <!--</el-table-column>-->
      <!--</el-table>-->
    <!--</el-tab-pane>-->

    <!--&lt;!&ndash;投诉记录&ndash;&gt;-->
    <!--<el-tab-pane v-if="productId !== 6 && productId !== 10" :label="'投诉记录（' + complainNum + '条）'" name="fourth">-->
      <!--&lt;!&ndash; 表格 &ndash;&gt;-->
      <!--<el-table :data="complainRecordTableData" stripe border style="width: 100%"-->
                <!--v-loading="complainRecordMsg.listLoading" :max-height="complainRecordMsg.maxTableHeight">-->
        <!--<el-table-column align="center" prop="createAt" label="投诉时间" min-width="60"></el-table-column>-->
        <!--<el-table-column align="center" prop="typeName" label="投诉类别" min-width="60"></el-table-column>-->
        <!--<el-table-column align="center" prop="content" label="投诉内容" min-width="40"></el-table-column>-->
        <!--<el-table-column align="center" prop="statusName" label="状态" min-width="60"></el-table-column>-->
        <!--<el-table-column align="center" label="处理过程" min-width="40">-->
          <!--<template slot-scope="scope">-->
            <!--<span class="imitate-a-label" @click="openComplainRecordDetail(scope.row)">查看</span>-->
          <!--</template>-->
        <!--</el-table-column>-->
      <!--</el-table>-->
      <!--&lt;!&ndash; 分页开始&ndash;&gt;-->
      <!--<div v-show="!complainRecordMsg.listLoading" class="pagination-container">-->
        <!--<el-pagination @size-change="handleSizeChangeComplain" @current-change="handleCurrentChangeComplain"-->
                       <!--:current-page.sync="complainRecordMsg.pagData.pageNo" :page-sizes="complainRecordMsg.pageSizes"-->
                       <!--:page-size="complainRecordMsg.pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"-->
                       <!--:total="complainRecordMsg.totalRecord">-->
        <!--</el-pagination>-->
      <!--</div>-->
    <!--</el-tab-pane>-->

    <!--短信记录-->
    <!--todo 降投诉需求 20190325 隐藏-->
    <!--<el-tab-pane label="短信记录" name="fifth">-->
      <!--<note-info :caseId="caseId" :username="username" v-on:handleCall="handleCall"></note-info>-->
    <!--</el-tab-pane>-->

    <!--免息券-->
    <el-tab-pane v-if="productId !== 6 && productId !== 10" label="优惠券" name="sixth">
      <div class="free-ticket-filter">
        <span>该用户最近获得的10条优惠券</span>
        <el-select class="w-140" v-model="freeTicketForm.product" placeholder="请选择产品" size="small" style="float: right;" @change="freeTicketChange">
          <el-option v-for="(item,index) in productList" :key="index" :label="item.productName" :value="item.productId"></el-option>
        </el-select>
      </div>
      <!-- 表格 -->
      <el-table :data="freeTicketTableData"  stripe border style="width: 100%"
                v-loading="freeTicketMsg.listLoading" :max-height="freeTicketMsg.maxTableHeight">
        <el-table-column align="center" type="index" label="序号" min-width="60"></el-table-column>
        <el-table-column align="center" prop="couponName" label="名称" min-width="60"></el-table-column>
        <el-table-column align="center" prop="couponStatusDesc" label="状态" min-width="60"></el-table-column>
        <el-table-column align="center" prop="sendDateStr" label="发送日期" min-width="60"></el-table-column>
        <el-table-column align="center" prop="endDateStr" label="截止日期" min-width="60"></el-table-column>
        <el-table-column align="center" prop="effectiveDays" label="有效天数" min-width="60"></el-table-column>
      </el-table>
    </el-tab-pane>
  </el-tabs>

    <!--交易记录失败弹框-->
    <el-dialog title="交易记录失败详情" :visible.sync="dialogTradeRecordVisible">
      <div v-for="(item,index) in failList" :key="index">{{item}}</div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogTradeRecordVisible = false">关 闭</el-button>
      </div>
    </el-dialog>
    <!--投诉工单详情-->
    <complain-detail ref="complainDetail"></complain-detail>
  </div>
</template>

<script>
  import Vue from 'vue'
  // import { mapGetters } from 'vuex'
  import { parseTime } from 'utils/formatDate'
  import noteInfo from './noteInfo'
  import complainDetail from './complainDetail'
  import {
    fetchGetUserOperateInApp, // 获取用户操作
    fetchGetUserTransaction, // 获取交易记录
    fetchGetUserOverdueRecord, // 获取逾期记录
    fetchGetListComplainRecordByUserId, // 获取投诉记录
    fetchGetUserFreeInterestCoupon // 获取免息券
    // fetchGetAllProduct4Menu // 获取产品列表
  } from '../../../api/case'

  export default {
    props: {
      userInfoProp: {
        required: true
      }
    },
    components: {
      noteInfo, complainDetail
    },
    // computed: {
    //   ...mapGetters([
    //     'appCodeList' // 产品类型
    //   ])
    // },
    watch: {
      'userInfoProp' (val) {
        if (val) {
          console.log(val)
          this.userId = val.userId
          this.caseId = val.caseId
          this.username = val.username
          this.caseTime = val.caseTime
          this.productList = val.caseProductInfoList // 当前产品下拉框列表
          this.userOperationForm.product = this.tradeRecordForm.product = this.freeTicketForm.product = this.productId = val.caseProductInfoList[0].productId
          // 逾期记录
          this.getOverdueTableData()
          // 投诉记录
          this.getComplainTableData()
          // 免息券
          // this.getFreeTableData()
          // // 当前产品下拉框列表
          // val.caseProductInfoList && val.caseProductInfoList.forEach((item, key) => {
          //   this.productList[key] = {
          //     productId: item.productId,
          //     productName: item.productName
          //   }
          // })
          // 车贷王 6 和 老车贷 10 只展示交易记录，申请编号
          if (this.productId === 6 || this.productId === 10) {
            this.activeName = 'second'
            this.applyId = val.caseProductInfoList[0].applyNo
          }
        }
      }
    },
    data () {
      return {
        failList: [], // 交易记录失败详情
        dialogTradeRecordVisible: false,
        // form: {}, // 交易记录详情弹框
        userId: null, // 当前案件用户id
        caseId: null,
        username: '',
        productId: null, // 预期最久的产品ID
        caseTime: '', // 案件创建时间
        activeName: 'first',
        overdueNum: 0, // 逾期记录num
        complainNum: 0, // 投诉记录num
        productList: [], // 产品列表
        applyId: null, // 车贷王、老车贷的申请编号
        // 用户操作 表单
        userOperationForm: {
          date: [new Date().getFullYear() - 1 + '-' + parseTime(new Date(), 'MM-DD'), new Date()],
          product: null // 默认所有
        },
        // 用户操作 表格
        userOperationTableData: [],
        userOperationMsg: {
          listLoading: false,
          maxTableHeight: 200,
          pagData: {
            pageSize: 10, // 每页条数
            pageNo: 1 // 页码
          },
          totalRecord: 0, // 总记录数
          pageSizes: [10, 20, 50]
        },
        // 交易记录 表单
        tradeRecordForm: {
          date: [new Date().getFullYear() - 1 + '-' + parseTime(new Date(), 'MM-DD'), new Date()],
          product: null // 默认所有
        },
        // 交易记录 表格
        tradeRecordTableData: [],
        tradeRecordMsg: {
          listLoading: false,
          maxTableHeight: 200,
          pagData: {
            pageSize: 10, // 每页条数
            pageNo: 1 // 页码
          },
          totalRecord: 0, // 总记录数
          pageSizes: [10, 20, 50]
        },
        // 逾期记录 表格
        overdueRecordTableData: [],
        overdueRecordMsg: {
          listLoading: false,
          maxTableHeight: 200
        },
        // 投诉记录 表格
        complainRecordTableData: [
          {id: 1},
          {id: 2},
          {id: 3}
        ],
        complainRecordMsg: {
          listLoading: false,
          maxTableHeight: 200,
          pagData: {
            pageSize: 10, // 每页条数
            pageNo: 1 // 页码
          },
          totalRecord: 0, // 总记录数
          pageSizes: [10, 20, 50]
        },
        // 免息券 表单
        freeTicketForm: {
          product: null // 默认所有
        },
        // 免息券 表格
        freeTicketTableData: [],
        freeTicketMsg: {
          listLoading: false,
          maxTableHeight: 200
        }
      }
    },
    mounted () {
      // this.getProductMenu() // 获取产品菜单
    },
    methods: {
      // 交易记录失败详情
      showLoseDetail (val) {
        this.dialogTradeRecordVisible = true
        this.failList = val.failList
      },
      // 短信打电话事件
      handleCall (val) {
        this.$emit('handleCallAgain', val)
      },
      // 切换tab
      handleTabsClick (tab, event) {
        if (tab.name === 'third') {
          this.getOverdueTableData()
        } else if (tab.name === 'fourth') {
          this.getComplainTableData()
        } else if (tab.name === 'sixth') {
          this.getFreeTableData()
        }
      },
      // 获取产品列表
      // getProductMenu () {
      //   if (!this.appCodeList.length) {
      //     this.$store.dispatch('GetAppCodeList')
      //       .then(res => {
      //         console.log(this.appCodeList)
      //       })
      //       .catch(err => {
      //         console.log(err)
      //       })
      //   }
      // },
      /* *********** 用户操作 *************** */
      // 用户操作-搜索
      userOperationSearchBtn () {
        console.log('用户操作-搜索')
        this.getUserTableData()
      },
      // 获取用户操作数据
      getUserTableData () {
        this.userOperationMsg.listLoading = true
        let searchVO = {
          startTime: parseTime(this.userOperationForm.date[0], 'YYYY-MM-DD 00:00:00'),
          endTime: parseTime(this.userOperationForm.date[1], 'YYYY-MM-DD 23:59:59'),
          productId: this.userOperationForm.product,
          userId: this.userId,
          caseTime: this.caseTime
        }
        fetchGetUserOperateInApp(JSON.stringify(searchVO), JSON.stringify(this.userOperationMsg.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.userOperationTableData = res.data.content
              this.userOperationMsg.totalRecord = res.data.totalRecord
            }
            this.userOperationMsg.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.userOperationMsg.listLoading = false
          })
      },
      // 处理分页每页显示数改变事件
      handleSizeChangeUser (val) {
        this.userOperationMsg.pagData.pageSize = val
        this.getUserTableData()
      },
      // 处理页码改变事件
      handleCurrentChangeUser (val) {
        this.userOperationMsg.pagData.pageNo = val
        this.getUserTableData()
      },
      /* *********** 交易记录 *************** */
      // 交易记录-搜索
      tradeRecordSearchBtn () {
        console.log('交易操作-搜索')
        this.getTradeTableData()
      },
      // 获取交易记录数据
      getTradeTableData () {
        this.tradeRecordMsg.listLoading = true
        let searchVO = {
          startTime: parseTime(this.tradeRecordForm.date[0], 'YYYY-MM-DD'),
          endTime: parseTime(this.tradeRecordForm.date[1], 'YYYY-MM-DD'),
          productId: this.tradeRecordForm.product,
          userId: this.userId,
          caseTime: this.caseTime,
          applyId: this.applyId
        }
        fetchGetUserTransaction(JSON.stringify(searchVO), JSON.stringify(this.tradeRecordMsg.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tradeRecordTableData = res.data.content
              this.tradeRecordMsg.totalRecord = res.data.totalRecord
            }
            this.tradeRecordMsg.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.tradeRecordMsg.listLoading = false
          })
      },
      // 处理分页每页显示数改变事件
      handleSizeChangeTrade (val) {
        this.tradeRecordMsg.pagData.pageSize = val
        this.getTradeTableData()
      },
      // 处理页码改变事件
      handleCurrentChangeTrade (val) {
        this.tradeRecordMsg.pagData.pageNo = val
        this.getTradeTableData()
      },
      /* *********** 逾期记录 *************** */
      // 获取逾期记录数据
      getOverdueTableData () {
        this.overdueRecordMsg.listLoading = false
        fetchGetUserOverdueRecord(this.userId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.overdueRecordTableData = res.data.content.map(item => {
                // item.borrowTime = parseTime(item.borrowTime, 'YYYY-MM-DD HH:mm:ss')
                item.detail = item.caseId === Number(this.caseId) ? 1 : 0 // 1当前案件 0其他案件
                return item
              })
              // 重新设置this.overdueNum的值，更新视图
              Vue.set(this, 'overdueNum', res.data.totalRecord)
            }
            this.overdueRecordMsg.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.overdueRecordMsg.listLoading = false
          })
      },
      toCaseDetail (caseId) {
        window.open('#/case-detail/' + caseId)
      },
      /* *********** 投诉记录 *************** */
      // 获取逾期记录数据
      openComplainRecordDetail (row) {
        this.$refs.complainDetail.dialogDetailVisible = true
        this.$refs.complainDetail.row = row
      },
      // 处理分页每页显示数改变事件
      handleSizeChangeComplain (val) {
        this.complainRecordMsg.pagData.pageSize = val
        this.getComplainTableData()
      },
      // 处理页码改变事件
      handleCurrentChangeComplain (val) {
        this.complainRecordMsg.pagData.pageNo = val
        this.getComplainTableData()
      },
      // 投诉记录table
      async getComplainTableData () {
        this.complainRecordMsg.listLoading = true
        let queryForm = {
          pageNo: this.complainRecordMsg.pagData.pageNo,
          pageSize: this.complainRecordMsg.pagData.pageSize,
          userId: this.userId
        }
        try {
          let response = await fetchGetListComplainRecordByUserId(queryForm)
          let res = response.data
          // {"version":"1.0","errorCode":0,"errorMsg":null,"data":{"total":0,"data":[]}}
          if (res.errorCode === 0 && res.data) {
            this.complainRecordTableData = res.data.content
            this.complainRecordMsg.totalRecord = res.data.totalRecord
            // 重新设置this.complainNum的值，更新视图
            Vue.set(this, 'complainNum', res.data.totalRecord)
          } else {
            this.complainRecordTableData = []
            this.complainRecordMsg.totalRecord = 0
          }
          this.complainRecordMsg.listLoading = false
        } catch (e) {
          this.complainRecordMsg.listLoading = false
        }
      },
      /* *********** 免息券 *************** */
      // 获取免息券数据
      getFreeTableData () {
        this.freeTicketMsg.listLoading = true
        fetchGetUserFreeInterestCoupon(this.userId, this.freeTicketForm.product, JSON.stringify(this.caseTime))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.freeTicketTableData = res.data.map(item => {
                item.sendDateStr = parseTime(item.sendDate, 'YYYY-MM-DD')
                item.endDateStr = parseTime(item.endDate, 'YYYY-MM-DD')
                return item
              })
            }
            this.freeTicketMsg.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.freeTicketMsg.listLoading = false
          })
      },
      // 免息券-产品-change
      freeTicketChange () {
        this.getFreeTableData()
      }
    }
  }
</script>

<style lang="scss" scoped>

  .tab-data-wrapper {
    .el-form-item {
      margin-bottom: 0;
    }
    .length-3 {
      width: 300px;
    }

    .free-ticket-filter {
      display: flex;
      justify-content: space-between;
      span {
        color: #666;
        font-size: 12px;
        line-height: 36px;
      }
    }
    .w-240 {
      width: 240px;
    }
    .w-140 {
      width: 140px;
    }
  }

</style>
