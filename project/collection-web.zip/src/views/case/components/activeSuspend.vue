<!--停催激活案件-->
<template>
  <!--权限管理-->
  <span v-if="showSelectObj.isShowActiveSuspend">
    <el-button :loading="loading" type="danger" size="mini" @click="handleSuspend(0)">停催</el-button>
  </span>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { fetchActiveSuspendCase } from '../../../api/case'
  export default {
    name: 'activeSuspend',
    props: {
      caseId: {
        required: true
      }
    },
    computed: {
      ...mapGetters([
        'showSelectObj'
      ])
    },
    data () {
      return {
        loading: false
      }
    },
    methods: {
      // 停催
      async handleSuspend (val) {
        this.loading = true
        try {
          const type = 1
          const { data } = await fetchActiveSuspendCase(this.caseId, type)
          if (data.errorCode === 0) {
            this.$message.success('停催成功')
            this.$emit('listenSuspendStatus', type)
          }
          this.loading = false
        } catch (e) {
          this.loading = false
        }
      }
    }
  }
</script>

<style lang="scss" scoped>

</style>
