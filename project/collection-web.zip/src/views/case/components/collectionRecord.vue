<!--催记弹窗 单呼-->

<template>
  <el-dialog :title="title" :visible.sync="CRProps.dialogVisible" class="collection-record-wrapper" @close="closeDialog">
    <el-form :model="form" :rules="rules" ref="form" label-width="110px">
      <el-form-item label="电话结果" prop="result">
        <el-radio-group v-model="form.result" @change="radioChange">
          <div>
            <el-radio style="color: #59ac59; margin-bottom: 10px;" v-for="item in callResultList1" :label="item.id" :key="item.id">{{ item.desc }}</el-radio>
          </div>
          <div>
            <el-radio style="color: red; margin-bottom: 10px;" v-for="item in callResultList2" :label="item.id" :key="item.id">{{ item.desc }}</el-radio>
          </div>
          <div>
            <el-radio style="color: #ffbe46; margin-bottom: 10px;" v-for="item in callResultList3" :label="item.id" :key="item.id">{{ item.desc }}</el-radio>
          </div>
          <div v-if="productId === 6">
            <el-radio style="color: #ff454a; margin-bottom: 10px;" v-for="item in callResultList5" :label="item.id" :key="item.id">{{ item.desc }}</el-radio>
          </div>
        </el-radio-group>

      </el-form-item>
      <el-form-item v-if="Number(form.result) === 1 || Number(form.result) === 22 || Number(form.result) === 24" label="预约还款时间" class="is-required">
        <el-date-picker v-model="form.appointTime" type="datetime" size="small" placeholder="选择预约还款时间"
                        format="yyyy/MM/dd HH:mm" value-format="yyyy/MM/dd HH:mm" :picker-options="pickerOptions1" :clearable="false"
                        :editable="false" @change="dataChange"></el-date-picker>
        <span style="display: inline-block; width: 45%; color: red; font-size: 12px;">{{ timeWarnMsg }}</span>
        <div style="font-size: 12px; color: #aaa;">若用户未在约定时间还款，则会自动进入催收工作台“跳票”任务中</div>
      </el-form-item>
      <el-form-item label="预约拨打时间">
        <el-date-picker v-model="form.resultDetail" type="datetime" size="small" placeholder="选择预约拨打时间"
                        format="yyyy/MM/dd HH:mm" value-format="yyyy/MM/dd HH:mm"
                        :editable="false"></el-date-picker>
        <div style="font-size: 12px; color: #aaa;">到达预约时间时，将自动进入催收工作台”预约拨打“任务中</div>
      </el-form-item>
      <el-form-item label="备注">
        <el-input id="textarea" type="textarea" :rows="2" placeholder="请输入备注" v-model="form.memo"></el-input>
      </el-form-item>

      <el-form-item label="快捷备注" v-if="form.result">
        <el-button type="info" size="mini" v-for="(item, key) in quickNote" :key="key" @click="insertValue('textarea', item)">{{ item }}</el-button>
      </el-form-item>

      <el-form-item>
        <div style="float: right;">
          <el-button type="text" @click="handleForm">对公还款信息登记</el-button>
        </div>
      </el-form-item>


      <div v-if="isShow" v-for="(item, index) in form.repayList" :key="index">
        <el-form-item label="产品">
          <el-radio-group v-model="item.productId">
            <el-radio v-for="item in productList" :label="item.id" :key="item.id">{{ item.name }}</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="是否本人还款">
          <el-radio-group v-model="item.isSelfRepayment" @change="isSelfChange(item, index)">
            <el-radio label="1">是</el-radio>
            <el-radio label="0">否</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="打款人姓名">
          <el-input placeholder="请输入打款人姓名" v-model="item.repaymentName"></el-input>
        </el-form-item>
        <el-form-item label="打款方式">
          <el-radio-group v-model="item.cashOrTransfer">
            <el-radio label="1">现金</el-radio>
            <el-radio label="2">转账</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="转账流水卡号" v-if="item.cashOrTransfer === '1'">
          <el-input placeholder="请输入转账流水卡号" v-model="item.cashTransferNum"></el-input>
        </el-form-item>
        <el-form-item label="打款人卡号" v-if="item.cashOrTransfer === '2'">
          <el-input placeholder="请输入打款人卡号" v-model="item.cardNum"></el-input>
        </el-form-item>
        <el-form-item label="对公还款金额">
          <el-input placeholder="请输入对公还款金额" v-model="item.repaymentAmount"></el-input>
        </el-form-item>
        <el-form-item label="对公还款时间">
          <el-date-picker v-model="item.repaymentAt" type="datetime" format="yyyy-MM-dd HH:mm" value-format="yyyy-MM-dd HH:mm" placeholder="选择对公还款时间"></el-date-picker>
        </el-form-item>
        <el-form-item label="">
          <span class="imitate-a-label" @click="addRepayInfo" v-if="index === (form.repayList.length - 1)">新增</span>
          <span class="imitate-a-label" @click="deleteRepayInfo(index)" v-if="index === (form.repayList.length - 1) && index !== 0">删除</span>
        </el-form-item>
      </div>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <div style="text-align: left; margin-bottom: 10px;">
        <el-input-number v-if="outTouch === undefined" v-model="outTouch" :min="0" :max="12" :step="0" size="mini"></el-input-number>
        <el-input-number v-else v-model="outTouch" :min="0" :max="12" :step="1" size="mini"></el-input-number>
        <span style="font-size: 12px;">小时内不进行联系。（仅对工作台生效）</span>
      </div>
      <div style="display: flex; justify-content: space-between;">
        <el-checkbox v-model="notice" style="color: red;">客户明确表达不要再联系他/她</el-checkbox>
        <div>
          <el-button @click="handleHangUp">挂断</el-button>
          <el-button type="primary" @click="handleConfirm" :loading="btnLoading">提交</el-button>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script>
  import { mapGetters } from 'vuex'
  // import { base64decode } from 'utils/index'
  import { parseTime } from 'utils/formatDate'
  import { insertAtCursorOriginal } from '../../../utils'
  import {
    fetchHangUp, // 挂断
    fetchUpdateOperation, // 提交催记
    fetchGetTokenByCaseId, // token
    fetchFindByTypes, // 通话结果
    fetchGetAllProduct4Menu // 获取产品列表
  } from '../../../api/case'

  export default {
    props: {
      // 是否打开催记弹窗
      CRProps: {
        required: true
      },
      // 数据
      CRData: {
        required: true
      },
      // 当前通话录音
      currentVoicePath: {
        required: true
      },
      currentConnect: {
        required: true
      },
      // 当前callRecordId
      callRecordId: {
        required: true
      },
      userName: {
        required: true
      },
      caseId: {
        required: true
      },
      productId: {
        required: true
      }
    },
    computed: {
      title: function () {
        return this.CRData.name + '(' + this.CRData.pinyin + ')' + this.CRData.phone
      },
      ...mapGetters([
        'currentCRInfo', // 当前催记信息
        'isSubmitted', // 提交状态
        'isShowSmallBox', // 小按钮
        'serviceNum', // 坐席
        'currentTaskId' // 当前任务ID
      ])
    },
    data () {
      return {
        pickerOptions1: {
          disabledDate (time) {
            return time.getTime() < new Date().getTime() - 1000 * 60 * 60 * 24 || time.getTime() > new Date().getTime() + 1000 * 60 * 60 * 24 * 3
          }
        },
        form: {
          result: null,
          appointTime: parseTime(new Date().getTime() + 1000 * 60 * 60 * 2, 'YYYY/MM/DD HH:mm'),
          resultDetail: null,
          memo: '',
          // 对公还款信息登记
          repayList: [
            {
              productId: null,
              isSelfRepayment: '0',
              repaymentName: '',
              cashOrTransfer: '2',
              cashTransferNum: null,
              cardNum: null,
              repaymentAmount: null,
              repaymentAt: null
            }
          ]
        },
        btnLoading: false, // 提交按钮loading
        timeWarnMsg: '', // 时间警告信息
        outTouch: undefined, // 几小时内不进行联系（仅对工作台生效）
        notice: false, // 联系人是否不再拨打
        productList: [], // 产品列表
        token: null, // token
        callResultMap: {}, // 电话结果map
        quickNote: [], // 快捷备注
        callResultList1: [],
        callResultList2: [],
        callResultList3: [],
        callResultList5: [],
        isShow: false, // 是否显示对公信息登记
        rules: {
          result: [
            { required: true, message: '请选择电话结果', trigger: 'change' }
          ],
          productId: [
            { required: true, message: '请选择产品', trigger: 'change' }
          ],
          isSelfRepayment: [
            { required: true, message: '请选择是否本人还款', trigger: 'change' }
          ],
          repaymentName: [
            { required: true, message: '请输入打款人姓名', trigger: 'blur' }
          ],
          cashOrTransfer: [
            { required: true, message: '请选择打款方式', trigger: 'change' }
          ],
          cashTransferNum: [
            { required: true, message: '请输入转账流水卡号', trigger: 'blur' }
          ],
          cardNum: [
            { required: true, message: '请输入打款人卡号', trigger: 'blur' }
          ],
          repaymentAmount: [
            { required: true, message: '请输入对公还款金额', trigger: 'blur' }
          ],
          repaymentAt: [
            { required: true, message: '请选择对公还款时间', trigger: 'blur' }
          ]
        }
      }
    },
    mounted () {
      this.getTokenByCaseId()
      this.getCallResultByTypes()
      this.getProductList()
    },
    methods: {
      // 获取产品列表
      getProductList () {
        fetchGetAllProduct4Menu()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.productList = res.data
              this.form.repayList[0].productId = this.productList[0].id
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 生成token
      getTokenByCaseId () {
        fetchGetTokenByCaseId(this.caseId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.token = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取通话结果
      getCallResultByTypes () {
        let types = null // null 全部 1 本人 2 第三方 3 未接听 4 其他 5 家访拖车
        fetchFindByTypes(types)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              let arr1 = []
              let arr2 = []
              let arr3 = []
              let arr5 = []
              res.data.forEach(item => {
                if (item.type === 1) {
                  arr1.push(item)
                } else if (item.type === 2) {
                  arr2.push(item)
                } else if (item.type === 3) {
                  arr3.push(item)
                } else if (item.type === 5) {
                  arr5.push(item)
                }
                this.callResultMap[item.id] = item
              })
              this.callResultList1 = arr1
              this.callResultList2 = arr2
              this.callResultList3 = arr3
              this.callResultList5 = arr5
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 提交
      handleConfirm () {
        //        this.form.repayList.map(item => {
        //          if (!item.productId) {
        //            this.$message.warning('请选择产品')
        //            return false
        //          }
        //          if (!item.productId) {
        //            this.$message.warning('请选择是否本人还款')
        //            return false
        //          }
        //          if (!item.productId) {
        //            this.$message.warning('请输入打款人姓名')
        //            return false
        //          }
        //          if (!item.productId) {
        //            this.$message.warning('请选择打款方式')
        //            return false
        //          }
        //          if (!item.productId) {
        //            this.$message.warning('请输入转账流水卡号')
        //            return false
        //          }
        //          if (!item.productId) {
        //            this.$message.warning('请输入打款人卡号')
        //            return false
        //          }
        //          if (!item.productId) {
        //            this.$message.warning('请输入对公还款金额')
        //            return false
        //          }
        //          if (!item.productId) {
        //            this.$message.warning('请选择对公还款时间')
        //            return false
        //          }
        //        })
        this.submitForm('form')
      },
      // 挂断
      handleHangUp () {
        let reason = null
        if (!this.serviceNum) {
          console.log('坐席号为空')
          return false
        }
        fetchHangUp(this.serviceNum, reason)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              console.log('挂断操作')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 关闭的回调
      closeDialog () {
        if (!this.isSubmitted) {
          this.$store.dispatch('IsShowSmallBox', true)
        }
      },
      // 电话结果判断
      resultJudge () {
        // 电话结果等于 承诺还款，预约还款时间必须选择
        if ((this.form.result === 1 || this.form.result === 22 || this.form.result === 24) && !this.form.appointTime) {
          this.timeWarnMsg = '请选择预约还款时间'
        } else {
          if (new Date(this.form.appointTime).getTime() < new Date().getTime()) {
            this.timeWarnMsg = '预约还款时间不能小于当前时间'
          } else if (new Date(this.form.appointTime).getTime() > new Date().getTime() + 1000 * 60 * 60 * 48) {
            this.timeWarnMsg = '预约还款时间不可超过48小时'
          } else {
            this.timeWarnMsg = ''
          }
        }
        // 快捷备注
        this.quickNote = this.callResultMap[this.form.result].remarks
      },
      // 电话结果change
      radioChange () {
        this.resultJudge()
      },
      // 预约还款时间change
      dataChange () {
        this.resultJudge()
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            // 挂断
            this.handleHangUp()
            // 电话结果等于 ”承诺还款”、”未承诺还款但有诚意还款”、”代偿”，预约还款时间必须选择
            // 电话结果等于 承诺还款，预约还款时间必须选择
            if ((this.form.result === 1 || this.form.result === 22 || this.form.result === 24) && !this.form.appointTime) {
              this.timeWarnMsg = '请选择预约还款时间'
              return false
            } else {
              if (new Date(this.form.appointTime).getTime() < new Date().getTime()) {
                this.timeWarnMsg = '预约还款时间不能小于当前时间'
                return false
              } else if (new Date(this.form.appointTime).getTime() > new Date().getTime() + 1000 * 60 * 60 * 48) {
                this.timeWarnMsg = '预约还款时间不可超过48小时'
                return false
              } else {
                this.timeWarnMsg = ''
              }
            }
            if (this.form.memo.length > 120) {
              this.$message.warning('备注字数超过限制')
              return false
            }
            // 提交
            this.btnLoading = true
            let submitVO = {
              caseId: this.caseId, // 案件id
              callRecordId: this.callRecordId,
              operationId: 16,
              contactName: this.CRData.name, // 联系人姓名
              // contactNum: base64decode(this.CRData.realPhone), // 联系人手机号
              contactNum: this.CRData.realPhone, // 联系人手机号
              callResultId: this.form.result, // 电呼结果
              appointTime: Number(this.form.result) === 1 || Number(this.form.result) === 22 || Number(this.form.result) === 24 ? this.form.appointTime : null, // 预约还款时间
              resultDetail: this.form.resultDetail, // 预约拨打时间
              memo: this.form.memo, // 备注
              noContactTime: this.outTouch !== undefined ? parseTime(new Date().getTime() + this.outTouch * 60 * 60 * 1000, 'YYYY/MM/DD HH:mm') : null, // 几小时内不进行联系（仅对工作台生效）
              phoneCalledStatus: this.notice ? 1 : 0, // 联系人是否不再拨打
              recordPath: this.currentConnect ? this.currentVoicePath : '',
              token: this.token // 当前token
            }
            let repaymentList = this.isShow ? this.form.repayList : []
            fetchUpdateOperation(JSON.stringify(submitVO), JSON.stringify(repaymentList))
              .then(response => {
                let res = response.data
                if (res.errorCode === 0) {
                  // 更新催记接口
                  // 向父组件传递事件-催记记录更新-可以传递参数
                  console.log('向父组件传递事件')
                  this.$emit('updateOT')
                  this.CRProps.dialogVisible = false
                  // 提交成功 1状态变更 2小按钮消失
                  // 未提交状态  变更为  提交状态
                  this.$store.dispatch('IsSubmitted', true)
                  this.$store.dispatch('IsShowSmallBox', false)
                  // todo 改动
                  this.$emit('listenCallNext')
                  // 提交成功 置空
                  this.resetForm('form')
                  this.form = {
                    result: null,
                    appointTime: parseTime(new Date().getTime() + 1000 * 60 * 60 * 2, 'YYYY/MM/DD HH:mm'),
                    resultDetail: null,
                    memo: '',
                    // 对公还款信息登记
                    repayList: [{
                      productId: this.productList[0].id,
                      isSelfRepayment: '1',
                      repaymentName: this.userName,
                      cashOrTransfer: '2',
                      cashTransferNum: null,
                      cardNum: null,
                      repaymentAmount: null,
                      repaymentAt: null
                    }]
                  }
                  this.outTouch = undefined // 几小时内不进行联系（仅对工作台生效）
                  this.notice = false // 联系人是否不再拨打
                  this.isShow = false // 是否显示对公信息
                }
                this.btnLoading = false
              })
              .catch(error => {
                console.log(error)
                this.btnLoading = false
              })
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      // 打开或者关闭对公信息登记
      handleForm () {
        this.isShow = !this.isShow
      },
      // 是否是本人change
      isSelfChange (val, i) {
        this.form.repayList[i].repaymentName = val.isSelfRepayment === '1' ? this.userName : ''
      },
      // 新增对公信息
      addRepayInfo () {
        let obj = {
          productId: this.productList[0].id,
          isSelfRepayment: '1',
          repaymentName: this.userName,
          cashOrTransfer: '2',
          cashTransferNum: null,
          cardNum: null,
          repaymentAmount: null,
          repaymentAt: null
        }
        let arr = this.form.repayList
        arr.push(obj)
        this.form.repayList = arr
      },
      // 删除对公信息
      deleteRepayInfo (index) {
        this.form.repayList.splice(index, 1)
      },
      // 插入标签
      insertValue (id, item) {
        if (item.indexOf('*') > -1) {
          let value = item.replace(/\*/, this.form.appointTime)
          insertAtCursorOriginal(document.getElementById(id), value)
        } else {
          insertAtCursorOriginal(document.getElementById(id), item)
        }
        this.form.memo = document.getElementById(id).value // 插值转化为data绑定属性
      }
    }
  }
</script>

<style lang="scss" scoped>

  .collection-record-wrapper {
    .length-1 {
      width: 140px;
    }
  }
</style>
