<!--项目管理-新增项目-->

<template>
  <!-- 新增项目弹窗 -->
  <el-dialog title="新增项目" :visible.sync="PMProps.dialogVisible" class="project-management-wrapper" @close="handleClose">
    <el-form :model="form" :rules="rules" ref="form" label-width="80px">
      <el-form-item label="提示">
        <div>已还清的欠款的案件本人和联系人，都无法添加到项目中</div>
        <div>已停催的案件将不会显示和拨打</div>
      </el-form-item>
      <el-form-item label="项目名称" prop="projectName">
        <!--<el-input v-model="form.callProjectName" placeholder="请输入项目名称" style="display: inline-block; width: 50%;"></el-input>-->
        <!--<span style="display: inline-block; width: 45%; color: red; font-size: 12px;">{{ warnMsg }}</span>-->
        <input list="browsers" name="browser" v-model="form.callProjectName" class="input-name" @blur="inputBlur"/>
        <datalist id="browsers">
          <option v-for="item in allProjectList" :value="item.callProjectName" :key="item.id"></option>
        </datalist>
        <span style="display: inline-block; width: 45%; color: red; font-size: 12px;">{{ warnMsg }}</span>
      </el-form-item>
      <el-form-item label="项目名单" prop="contactType">
        <!--1-本人，2-三个紧急联系人，3-系统推荐人，4-勾选人-->
        <el-checkbox-group v-model="form.contactType">
          <el-checkbox v-for="item in contactList" :label="item.code" :key="item.code">{{item.name}}</el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <el-form-item label="呼叫系数">
        <!--<el-input v-model="editProjectForm.callCoefficient" placeholder="请输入呼叫系数" class="length-1"></el-input>-->
        <el-input-number v-model="form.callRatio" :min="1" :max="15" label="请输入呼叫系数" @blur="inputNumberBlur" class="length-1"></el-input-number>
        <span>控制同时呼出的电话数量，范围1~15的整数</span>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">取 消</el-button>
      <el-button type="primary" @click="handleConfirm" :loading="btnLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {
    fetchAddBatchProject, // 新增项目
    fetchQueryByCollectorId // 检查项目名称是否重复
  } from '../../../api/call'
  export default {
    props: {
      // 是否打开编辑项目弹窗
      PMProps: {
        required: true
      }
    },
    watch: {
      'PMProps.dialogVisible' (val) {
        if (val) {
          this.getAllProjectByCollectorId()
        }
      }
    },
    data () {
      return {
        // 编辑项目弹窗
        // dialogEditProject: dialogProject, // 是否打开编辑项目弹窗
        allProjectList: [], // 所有项目list
        form: {
          callProjectName: '',
          contactType: [],
          callRatio: ''
        },
        btnLoading: false, // 确定按钮loading
        contactList: [
          {code: '1', name: '本人'},
          {code: '2', name: '三个联系人'}
          // {code: '4', name: '勾选人'}
        ],
        isAdd: true, // 是否新增项目
        warnMsg: '', // 提醒信息
        bo: {},
        rules: {
          contactType: [
            { type: 'array', required: true, message: '请至少选择一个项目名单', trigger: 'change' }
          ]
        }
      }
    },
    mounted () {
      // 获取改登录用户所有的项目
      this.getAllProjectByCollectorId()
    },
    methods: {
      // 获取改登录用户所有的项目
      getAllProjectByCollectorId () {
        fetchQueryByCollectorId()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.allProjectList = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 确认
      handleConfirm () {
        this.submitForm('form')
      },
      // 取消
      handleCancel () {
        this.handleClose()
        this.PMProps.dialogVisible = false
      },
      // 关闭
      handleClose () {
        this.resetForm('form')
        this.form = {
          callProjectName: '',
          contactType: [],
          callRatio: ''
        }
        this.isAdd = true
        this.warnMsg = ''
      },
      inputBlur () {
        if (!this.form.callProjectName) {
          this.warnMsg = '项目名称不能为空'
        } else if (this.form.callProjectName.length > 50) {
          this.warnMsg = '项目名称的长度请在50个字符以内'
        } else {
          let flag = false
          let obj = {}
          this.allProjectList.map(item => {
            if (item.callProjectName === this.form.callProjectName) {
              flag = true
              obj = item
              return false
            }
          })
          if (flag) {
            this.isAdd = false // 修改
            this.warnMsg = '项目名已存在，将更新项目'
            this.bo.id = obj.id
            this.bo.caseId = this.PMProps.caseId ? this.PMProps.caseId : this.$route.params.id
          } else {
            this.isAdd = true // 新增
            this.warnMsg = ''
            this.bo = {}
          }
        }
      },
      // 失焦校验
      inputNumberBlur () {
        this.form.callRatio = parseInt(this.form.callRatio)
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (!this.form.callProjectName) {
              this.warnMsg = '项目名称不能为空'
              return false
            } else if (this.form.callProjectName.length > 50) {
              this.warnMsg = '项目名称的长度请在50个字符以内'
              return false
            }
            // isAdd false  更新  true 新增
            if (!this.isAdd) {
              let bo = this.bo
              this.save(bo)
            } else {
              let bo = {
                id: null,
                caseId: this.PMProps.caseId ? this.PMProps.caseId : this.$route.params.id
              }
              this.save(bo)
            }
            this.PMProps.dialogVisible = false
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      // save
      save (bo) {
        this.btnLoading = true
        bo.callProjectName = this.form.callProjectName
        bo.callRatio = this.form.callRatio
        bo.contactType = this.form.contactType.join(',')
        console.log(bo)
        fetchAddBatchProject(JSON.stringify(bo))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success(res.data.desc)
            }
            this.btnLoading = false
          })
          .catch(error => {
            console.log(error)
            this.btnLoading = false
          })
      }
    }
  }
</script>

<style lang="scss" scoped>

  .project-management-wrapper {
    .length-1 {
      width: 140px;
    }
    .input-name {
      width: 50%;
      height: 40.5px;
      text-indent: 16px;
      line-height: 40.5px;
      border: 1px solid #eee;
      -webkit-border-radius: 4px;
      -moz-border-radius: 4px;
      border-radius: 4px;
    }
  }
</style>
