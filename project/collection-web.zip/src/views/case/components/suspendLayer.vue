/*
* @Author: sunp
* @Date: 2019/3/6 9:38
*/
<template>
  <transition name="bounce">
    <div ref="suspendDiv" class="suspend-layer">
      <el-button v-if="showSelectObj.isShowActiveSuspend" :loading="loading" type="success" @click="handleSuspend">恢复催收</el-button>
      <div v-else>该案件已停催</div>
    </div>
  </transition>

</template>

<script>
  import { mapGetters } from 'vuex'
  import { fetchActiveSuspendCase } from '../../../api/case'
  export default {
    name: 'suspendLayer',
    props: {
      caseId: {
        required: true
      }
    },
    computed: {
      ...mapGetters([
        'showSelectObj' // 是否显示
      ])
    },
    data () {
      return {
        loading: false
      }
    },
    mounted () {
      this.$refs.suspendDiv.style.height = document.documentElement.clientHeight + 'px'
    },
    methods: {
      // 恢复停催
      async handleSuspend () {
        this.loading = true
        try {
          const type = 0
          const { data } = await fetchActiveSuspendCase(this.caseId, type)
          if (data.errorCode === 0) {
            this.$message.success('恢复催收成功')
            this.$emit('listenSuspendStatus', type)
          }
          this.loading = false
        } catch (e) {
          this.loading = false
        }
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .suspend-layer {
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 30px;
    overflow: hidden;
  }

  .bounce-enter-active {
    animation: bounce-in .5s;
  }
  .bounce-leave-active {
    animation: bounce-in .5s reverse;
  }
  @keyframes bounce-in {
    0% {
      transform: scale(0);
    }
    100% {
      transform: scale(1);
    }
  }
</style>
