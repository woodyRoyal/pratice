
<!-- 多产品用户信息 -->

<template>
  <ul class="user-info-wrapper">
    <li v-for="(item, index) in userInfoData" :key="index" class="form-block">
      <!--isCleared 2 已还清 1 未还清-->
      <div :class="[ item.isCleared === 2 ? 'gray-style' : 'stress-style' ]" @click="handleShow(index)">
        <div>
          <span>{{ item.overdueDays }}天</span>
          <span>{{ item.productName }}</span>
          <span style="margin-left: 20px;" v-if="item.channelName || item.channelApp">
            <span v-if="item.channelName">借款产品：“{{ item.channelName }}”</span>
            <span v-if="item.channelApp" style="margin-left: 20px;">用户使用“{{ item.channelApp }}”APP借款</span>
            <!--<span v-if="item.channelName">借款产品叫：{{ item.channelName }}。</span>-->
            <!--<span v-if="item.channelApp">用户使用{{ item.channelApp }}APP借款。</span>-->
          </span>
        </div>
        <!--车贷王 6  老车贷 10-->
        <span v-if="item.productId !== 6 && item.productId !== 10">{{ item.balance }}</span>
      </div>
      <el-row v-if="item.isShowInfo" class="user-info">
        <!--车贷王 6  老车贷 10-->
        <div v-if="item.productId === 6 || item.productId === 10">
          <el-col :span="22">
            <span class="f-w-7">申请编号：</span>
            <span>{{ item.realApplyNo }}</span>
          </el-col>
          <el-col :span="2" v-if="showSelectObj.isShowReduce">
            <!--车贷王6展示划扣，老车贷10不展示划扣-->
            <span v-if="item.productId === 6" class="imitate-a-label" @click="handleDeductAutoLoan(item.productId, item.billId)">划扣</span>
          </el-col>
          <el-col :span="24">
            <span class="f-w-7">住址：</span>
            <span>{{ item.homeAddress }}</span>
          </el-col>
          <!--todo 车贷王、老车贷正常展示 单位字段-->
          <el-col :span="24">
            <span class="f-w-7">单位：</span>
            <span>{{ item.unitName }}</span>
            <span>（{{ item.unitAddress }}）</span>
          </el-col>
          <el-col :span="12">
            <span class="f-w-7">车牌：</span>
            <span>{{ item.carCard }}</span>
          </el-col>
          <el-col :span="12">
            <span class="f-w-7">车型：</span>
            <span>{{ item.carType }}</span>
          </el-col>
          <el-col :span="24">
            <span class="f-w-7">借记卡卡号：</span>
            <span>{{ item.bankCard }}</span>
            <span>( {{ item.bankName }} )</span>
          </el-col>
          <el-col :span="12">
            <span class="f-w-7">放款时间：</span>
            <span>{{ item.borrowTime }}</span>
          </el-col>
          <el-col :span="12">
            <span class="f-w-7">月租：</span>
            <span>{{ item.monthlyRent || 0 }}元</span>
          </el-col>
          <el-col :span="12">
            <span class="f-w-7">借款期数：</span>
            <span>{{ item.loanTotalStage || 0 }}期</span>
          </el-col>
          <el-col :span="12">
            <span class="f-w-7">已还期数：</span>
            <span>{{ item.loanPaidStage || 0 }}期</span>
            <!--催月供（本金+利息)，不催罚息，仅针对车贷王-->
            <span v-if="isMonthlyPayment && item.productId === 6">（月供结清即视为当期已还）</span>
          </el-col>
          <el-col :span="12">
            <span class="f-w-7">逾期金额：</span>
            <span style="font-weight: 700;color: #C03639;">{{ item.debt || 0 }}元</span>
          </el-col>
          <el-col :span="10">
            <span class="f-w-7">逾期天数：</span>
            <span>{{ item.overdueDays || 0 }}天</span>
          </el-col>
          <!-- productType  single 单期  bystage 多期-->
          <el-col :span="2" v-if="item.productType === 'bystage' && item.isCleared === 1">
            <span class="imitate-a-label" @click="handleTable(index)" v-show="item.isShowTable">收起详情</span>
            <span class="imitate-a-label" @click="handleTable(index)" v-show="!item.isShowTable">展开详情</span>
          </el-col>
          <el-col :span="22">
            <div v-if="item.productId !== 6">
              <span class="f-w-7">资方：</span>
              <span>{{ item.financeParty }}</span>
            </div>
          </el-col>
        </div>
        <!--不是车贷的产品，逻辑不变，避免改动造成影响-->
        <div v-else>
          <el-col :span="22">
            <span class="f-w-7">住址：</span>
            <span>{{ item.homeAddress }}</span>
          </el-col>
          <el-col :span="2" v-if="item.productId !== 1 && item.productId !== 2">
            <span class="imitate-a-label" @click="checkImage(item)">影像</span>
          </el-col>
          <el-col :span="2" v-if="(item.productId === 1 || item.productId === 2) && isShowUpdateBtn">
            <span class="imitate-a-label" @click="updateCaseDetail(item.orderId)">更新欠款</span>
          </el-col>

          <!--todo 除了车贷王、老车贷，其他产品不展示单位字段 和 修改信息-->
          <!--<el-col :span="22">-->
            <!--<span class="f-w-7">单位：</span>-->
            <!--<span>{{ item.unitName }}</span>-->
            <!--<span>（{{ item.unitAddress }}）</span>-->
          <!--</el-col>-->
          <!--<el-col :span="2">-->
            <!--<span class="imitate-a-label" @click="openUserInfoDialogBtn(item)">修改信息</span>-->
          <!--</el-col>-->
          <!--卡贷王-->
          <el-col :span="11" v-if="item.productId === 4">
            <span class="f-w-7">借记卡卡号：</span>
            <span>{{ item.bankCard }}</span>
            <span>( {{ item.bankName }} )</span>
          </el-col>
          <el-col :span="22" v-if="item.productId === 8">
            <span class="f-w-7">借记卡卡号：</span>
            <span>{{ item.bankCard }}</span>
            <span>( {{ item.bankName }} )</span>
          </el-col>
          <!--4 卡贷王-->
          <el-col :span="11" v-if="item.productId === 4">
            <span class="f-w-7">信用卡卡号：</span>
            <span>{{ item.creditBank }}</span>
            <span>( {{ item.creditCard }} )</span>
          </el-col>
          <!--其他产品-->
          <el-col :span="22" v-if="item.productId !== 4 && item.productId !== 8">
            <span class="f-w-7">银行卡卡号：</span>
            <span>{{ item.bankCard }}</span>
            <span>( {{ item.bankName }} )</span>
          </el-col>
          <el-col :span="2">
            <span class="imitate-a-label" @click="sendSms(item.productId, item.orderId)">发短信</span>
          </el-col>

          <el-col :span="11">
            <span class="f-w-7">借款时间：</span>
            <span>{{ item.borrowTime }}</span>
          </el-col>
          <el-col :span="11">
            <span class="f-w-7">贷款编号：</span>
            <span>{{ item.contractNo }}</span>
          </el-col>
          <el-col :span="2">
            <!--4 卡贷王划扣按钮不显示-->
            <span class="imitate-a-label" v-if="showSelectObj.isShowReduce && item.productId !== 4" @click="getReduceConfigByCaseId(item.productId, item.billId)">手动扣款</span>
          </el-col>

          <el-col :span="22">
            <span class="f-w-7">欠款金额：</span>
            <span style="font-weight: 700;color: #C03639;">{{ item.balance }}元</span>
            <!--1 贷款王 2 即刻贷-->
            <span v-if="item.productId === 1 || item.productId === 2">（本金{{ item.principal }}元{剩{{ item.principalBalance }}} + 利息{{ item.interest }}元{剩{{ item.interestBalance }}} + 逾期管理费{{ item.overdueFee }}元{剩{{ item.overdueFeeBalance }}}  - 已还{{ item.repaymentAmount }}元）</span>

            <!--4 卡贷王-->
            <span v-else-if="item.productId === 4">（本金{{ item.principal }}元 + 利息{{ item.interest }}元 + 服务费{{ item.manageFee }}元 + 逾期违约金{{ item.penaltyFee }}元 + 逾期滞纳费{{ item.overdueFee }}元  - 已还{{ item.repaymentAmount }}元）</span>

            <!--8 2345借款-->
            <span v-else-if="item.productId === 8">（本金{{ item.principal }}元 + （利息 + 逾期利息）{{ item.interest }}元 + 服务费{{ item.manageFee }}元 + 逾期违约金{{ item.penaltyFee }}元 + 逾期滞纳费{{ item.overdueFee }}元 - 已还{{ item.repaymentAmount }}元）</span>

            <!--3 立即贷 、 5 随心借 、 7 畅借款 、 9 好借-->
            <span v-else>（本金{{ item.principal }}元 + 利息{{ item.interest }}元 + 逾期管理费{{ item.overdueFee }}元 - 已还{{ item.repaymentAmount }}元）</span>
          </el-col>
          <!-- productType  single 单期  bystage 多期-->
          <el-col :span="2" v-if="item.productType === 'bystage' && item.isCleared === 1">
            <span class="imitate-a-label" @click="handleTable(index)" v-show="item.isShowTable">收起详情</span>
            <span class="imitate-a-label" @click="handleTable(index)" v-show="!item.isShowTable">展开详情</span>
          </el-col>
        </div>
      </el-row>
      <!--车贷王 6  老车贷 10-->
      <el-table v-if="(item.productId === 6 || item.productId === 10) && item.isShowTable" :data="item.billItemList" style="width: 100%" border>
        <el-table-column align="center" prop="currentPeriod" label="期次" min-width="20"></el-table-column>
        <el-table-column align="center" prop="financeParty" label="资方" min-width="50"
                         v-if="item.productId === 6"></el-table-column>
        <el-table-column align="center" prop="nextPayDate" label="应还款日期" min-width="50"></el-table-column>
        <el-table-column align="center" prop="monthlyRentAmount" label="月租" min-width="50"></el-table-column>
        <el-table-column align="center" label="还款状态" min-width="40">
          <template slot-scope="scope">
            <span v-if="scope.row.status === 1">待还款</span>
            <span v-if="scope.row.status === 2">已还清</span>
            <span v-if="scope.row.status === 3" style="color: red;">已逾期</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="overdueDays" label="逾期天数" min-width="40"></el-table-column>
        <el-table-column align="center" prop="remainPrincipal" label="剩余本金" min-width="40"></el-table-column>
        <el-table-column align="center" prop="remainInterest" label="剩余利息" min-width="40"></el-table-column>
        <el-table-column align="center" prop="remainOverduePenalty" label="剩余逾期滞纳金" min-width="40"></el-table-column>
        <el-table-column align="center" prop="remainFee" label="剩余费用" min-width="40"></el-table-column>
        <el-table-column align="center" prop="repayPrincipal" label="已还本金" min-width="40"></el-table-column>
        <el-table-column align="center" prop="repayInterest" label="已还利息" min-width="50"></el-table-column>
        <el-table-column align="center" prop="repayOverduePenalty" label="已还逾期滞纳金" min-width="50"></el-table-column>
        <el-table-column align="center" prop="repayFee" label="已还费用" min-width="50"></el-table-column>
        <el-table-column align="center" prop="principal" label="应还本金" min-width="50"></el-table-column>
        <el-table-column align="center" prop="interest" label="应还利息" min-width="50"></el-table-column>
        <el-table-column align="center" prop="overduePenalty" label="应还逾期滞纳金" min-width="50"></el-table-column>
        <el-table-column align="center" prop="fee" label="应还费用" min-width="50"></el-table-column>
      </el-table>
      <el-table v-if="item.productId !== 6 && item.productId !== 10 && item.isShowTable" :data="item.billItemList" style="width: 100%" border>
        <!--<el-table-column align="center" type="index" label="第几期" min-width="20"></el-table-column>-->
        <el-table-column align="center" type="index" label="期次" min-width="20"></el-table-column>
        <el-table-column align="center" prop="nextPayDate" label="应还款日期" min-width="50"></el-table-column>
        <el-table-column align="center" label="还款状态" min-width="40">
          <template slot-scope="scope">
            <!--<span v-if="scope.row.status === 2">已还清</span>-->
            <!--<span v-if="scope.row.status === 1">-->
            <!--<span v-if="scope.row.isOverdue === 1" style="color: red;">已逾期</span>-->
            <!--<span v-if="scope.row.isOverdue === 2">待还款</span>-->
            <!--</span>-->
            <span v-if="scope.row.status === 1">待还款</span>
            <span v-if="scope.row.status === 2">已还清</span>
            <span v-if="scope.row.status === 3" style="color: red;">已逾期</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="principal" label="本金" min-width="40"></el-table-column>
        <el-table-column align="center" prop="interest" label="利息" min-width="40"></el-table-column>
        <el-table-column align="center" prop="manageFee" label="服务费" min-width="50"></el-table-column>
        <!--<el-table-column align="center" prop="overdueDays" label="逾期天数" min-width="40">-->
        <!--<template slot-scope="scope">-->
        <!--<span v-if="scope.row.isCleared === 1 && scope.row.isOverdue === 1" style="color: red;">{{ scope.row.overdueDays }}</span>-->
        <!--<span v-else>{{ scope.row.overdueDays }}</span>-->
        <!--</template>-->
        <!--</el-table-column>-->
        <!--<el-table-column align="center" prop="balance" label="欠款金额" min-width="30">-->
        <!--<template slot-scope="scope">-->
        <!--<span v-if="scope.row.isCleared === 1 && scope.row.isOverdue === 1" style="color: red;">{{ scope.row.balance }}</span>-->
        <!--<span v-else>{{ scope.row.balance }}</span>-->
        <!--</template>-->
        <!--</el-table-column>-->
        <!--<el-table-column align="center" prop="needRePayPrincipal" label="应还本金" min-width="40"></el-table-column>-->
        <!--<el-table-column align="center" prop="needRepayInterest" label="应还利息" min-width="40"></el-table-column>-->
        <!--<el-table-column align="center" prop="needRepayOverdueInterest" label="应还逾期利息" min-width="50"></el-table-column>-->
        <!--<el-table-column align="center" prop="needRepayManageFee" label="应还管理费" min-width="40"></el-table-column>-->
        <!--<el-table-column align="center" prop="repayAmount" label="已还金额" min-width="40"></el-table-column>-->
      </el-table>
    </li>

    <!-- 修改用户信息弹窗 start -->
    <el-dialog title="修改信息" :visible.sync="dialogEditUserInfo" @close="dialogEditUserInfoClose">
      <el-form :model="editUserInfoForm" :rules="editUserInfoRules" ref="editUserInfoForm" label-width="100px">
        <el-form-item label="住宅住址：" prop="newHomeAddress">
          <el-input v-model="editUserInfoForm.newHomeAddress"
                    auto-complete="off" :placeholder="userInfoForm.homeAddress">
          </el-input>
        </el-form-item>
        <el-form-item label="原住宅住址：">
          <span>{{ userInfoForm.originalHomeAddress }}</span>
        </el-form-item>
        <el-form-item label="单位名称：" prop="newUnitName">
          <el-input v-model="editUserInfoForm.newUnitName"
                    auto-complete="off" :placeholder="userInfoForm.unitName">
          </el-input>
        </el-form-item>
        <el-form-item label="原单位名称：">
          <span>{{ userInfoForm.originalUnitName }}</span>
        </el-form-item>
        <el-form-item label="单位住址：" prop="newUnitAddress">
          <el-input v-model="editUserInfoForm.newUnitAddress"
                    auto-complete="off" :placeholder="userInfoForm.unitAddress">
          </el-input>
        </el-form-item>
        <el-form-item label="原单位住址：">
          <span>{{ userInfoForm.originalUnitAddress }}</span>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogEditUserInfoCancel">取 消</el-button>
        <el-button type="primary" @click="dialogEditUserInfoConfirm" :loading="editBtnLoading">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 修改用户信息 弹窗 end -->

    <!--发短信-->
    <send-sms :sendSmsProps="sendSmsProps"></send-sms>

    <!--代扣-->
    <el-dialog title="减免还款" :visible.sync="dialogReduce" @close="dialogReduceClose" class="reduce-dialog">
      <el-form :model="reduceForm" :rules="reduceRules" ref="reduceForm" label-width="100px">
        <el-form-item label="应还金额：" prop="newHomeAddress">
          <span style="font-weight: 700; font-size: 20px;">{{ reduceForm.balance }}</span>
          <span>元</span>
        </el-form-item>
        <el-form-item label="减免款项：" prop="newHomeAddress">
          <!--剩余本金0元 + 逾期综合费用327.9元 + 贷后综合费用107.14元-->
          <el-checkbox-group v-model="reduceForm.checkList" @change="handleChangeCheckList">
            <el-checkbox v-for="item in reduceList" :label="item.paramCode" :key="item.paramCode" :disabled="item.paramValue === 'N'">{{ item.name }}</el-checkbox>
            <!--<el-checkbox v-for="item in reduceList" :label="item.paramCode" :key="item.paramCode">{{ item.name }}</el-checkbox>-->
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="减免比例：">
          <el-select v-model="reduceForm.reduceRate1" placeholder="请选择" clearable size="small" class="length-1" :disabled="disabled1 === 'N'" @change="handleChange1" @clear="handleClear1">
            <!--<el-select v-model="reduceForm.reduceRate1" placeholder="请选择" clearable size="small" class="length-1">-->
            <el-option
              v-for="item in reduceRateTotal1"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
          <el-select v-model="reduceForm.reduceRate2" placeholder="请选择" clearable size="small" class="length-1" :disabled="rate2 || disabled2 === 'N'" @change="handleChange2" @clear="handleClear2">
            <!--<el-select v-model="reduceForm.reduceRate2" placeholder="请选择" clearable size="small" class="length-1">-->
            <el-option
              v-for="item in reduceRateTotal2"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
          <el-select v-model="reduceForm.reduceRate3" placeholder="请选择" clearable size="small" class="length-1" :disabled="rate3 || disabled3 === 'N'" @change="handleChange3" @clear="handleClear3">
            <!--<el-select v-model="reduceForm.reduceRate3" placeholder="请选择" clearable size="small" class="length-1">-->
            <el-option
              v-for="item in reduceRateTotal3"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
          <!--<el-button type="primary" size="small" @click="calculate">计算</el-button>-->
        </el-form-item>
        <el-form-item label="减免金额：" prop="">
          <el-input v-if="currentProductId === 1 || currentProductId === 2" v-model="reduceForm.reduceAmout" @blur="handleBlur" placeholder="请输入内容" size="small" class="length-1"></el-input>
          <span v-else v-html="reduceForm.reduceAmout"></span><span>元</span>
        </el-form-item>
        <el-form-item label="划扣金额：">
          <span>{{ reduceForm.realRepayment }}</span>
          <span>元</span>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogReduceConfirmChoose" :loading="reduceBtnLoading">立即划扣</el-button>
      </div>
    </el-dialog>
    
    <!--划扣（仅限车贷王产品）-->
    <el-dialog title="划扣确认" :visible.sync="dialogDeduct">
      <div style="padding-left: 20px; color: #aaa; line-height: 20px;">
        <div>1、仅RZZL-CDW资方的账单支持划扣</div>
        <div>2、联合资方时只能划扣RZZL-CDW资方的金额</div>
      </div>
      <el-form :model="deductForm" :rules="deductRules" ref="deductForm" size="small" label-width="100px">
        <el-form-item label="划扣方式：" prop="chargeMethod">
          <el-select v-model="deductForm.chargeMethod" placeholder="请选择" class="length-1" @change="handleChangeChargeMethod">
            <el-option label="全额划扣" :value="1"></el-option>
            <el-option label="按期划扣" :value="2"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-if="deductForm.chargeMethod === 2" label="划扣期数：" prop="chargePeriod">
          <el-select v-model="deductForm.chargePeriod" placeholder="请选择" class="length-1" @change="handleChangeChargePeriod">
            <el-option
              v-for="item in billInfo.billStagingList"
              :key="item.periodNo"
              :label="'第' + item.periodNo + '期'"
              :value="item.periodNo">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="划扣金额：" prop="chargeMoneyMethod">
          <el-radio-group v-model="deductForm.chargeMoneyMethod">
            <span v-show="deductForm.chargeMethod === 1">
              <el-radio :label="1" disabled>{{ `本金+利息（${billInfo.totalAmount}元)` }}</el-radio>
              <el-radio :label="2" disabled>{{ `本金+利息+逾期滞纳金（${billInfo.totalAmountPenalty}元)` }}</el-radio>
            </span>
            <span v-show="deductForm.chargeMethod === 2">
              <el-radio :label="1">{{ `本金+利息（${totalAmount}元)` }}</el-radio>
              <el-radio :label="2">{{ `本金+利息+逾期滞纳金（${totalAmountPenalty}元)` }}</el-radio>
            </span>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" @click="dialogDeduct = false">取消</el-button>
        <el-button type="primary" size="small" @click="dialogDeductConfirmChoose" :loading="deductBtnLoading" :disabled="deductBtnDisabled">确认</el-button>
      </div>
    </el-dialog>
  </ul>
</template>

<script>
  import Vue from 'vue'
  import { mapGetters } from 'vuex'
  import sendSms from './sendSms'
  import { getMaxTwoDecimalPlaces } from '../../../utils/index'
  import {
    fetchUpdateCaseUser, // 更新案件用户信息
    fetchUpdateCaseDetail, // 更新欠款信息
    fetchFindReduceConfigByCaseId, // 手动扣款-获取划扣信息
    fetchCallWsCaseReduceDebtRecord, // 手动扣款
    fetchCallProductCoreReduce, // 立即贷手动扣款
    fetchFindReduceForBuckle // 划扣时查询期数等信息
  } from '../../../api/case'

  export default {
    components: {
      sendSms
    },
    props: {
      userInfoProp: {
        required: true
      },
      isMonthlyPayment: {
        type: Boolean,
        required: true
      }
    },
    computed: {
      ...mapGetters([
        'showSelectObj' // 是否显示
      ]),
      deductBtnDisabled () {
        if (this.deductForm.chargeMethod === 1) {
          return !this.deductForm.chargeMoneyMethod
        } else {
          if (this.deductForm.chargePeriod) {
            return !this.deductForm.chargeMoneyMethod
          } else {
            return true
          }
        }
      }
    },
    watch: {
      'userInfoProp.caseProductInfoList' (val) {
        this.userInfoData = val.map((item, index) => {
          // 是否显示信息
          item.isShowInfo = true
          if (index === 0) {
            item.isShowInfo = true
          }
          // 结清案件默认不展示
          if (item.isCleared === 2) {
            item.isShowInfo = false
          }
          item.isShowTable = false
          return item
        })
      },
      'userInfoProp.userId' (val) {
        if (val) {
          this.userId = val
        }
      },
      'userInfoProp.caseId' (val) {
        if (val) {
          this.caseId = val
        }
      }
    },
    data () {
      return {
        billId: null,
        currentProductId: null, // 当前手动代扣产品Id
        userId: null,
        caseId: null,
        activeNames: [0],
        userInfoData: [],
        // 修改信息弹窗
        dialogEditUserInfo: false,
        editBtnLoading: false, // loading
        editUserInfoForm: {
          newHomeAddress: '',
          newUnitName: '',
          newUnitAddress: ''
        },
        userInfoForm: {
          homeAddress: '',
          unitName: '',
          unitAddress: '',
          originalHomeAddress: '',
          originalUnitName: '',
          originalUnitAddress: ''
        },
        editUserInfoRules: {
          newHomeAddress: [
            { required: true, message: '请输入住宅地址', trigger: 'blur' }
          ],
          newUnitName: [
            { required: true, message: '请输入单位名称', trigger: 'blur' }
          ],
          newUnitAddress: [
            { required: true, message: '请输入单位地址', trigger: 'blur' }
          ]
        },
        // 发短信
        sendSmsProps: {},
        // 代扣
        dialogReduce: false, // 减免弹窗
        reduceBtnLoading: false, // loading
        reduceForm: {
          balance: null, // 应还金额
          checkList: [], // 勾选的减免款项
          reduceRate1: null, // 减免率1
          reduceRate2: null, // 减免率2
          reduceRate3: null, // 减免率3
          reduceAmout: 0, // 减免金额
          realRepayment: 0 // 实际欠款金额
        },
        reduceRules: {}, // 减免规则校验
        reduceList: [], // 减免款项
        reduceRateTotal1: [],
        reduceRateTotal2: [],
        reduceRateTotal3: [],
        disabled1: false,
        disabled2: false,
        disabled3: false,

        isShowUpdateBtn: true, // 是否显示更新欠款按钮
        rate2: true,
        rate3: true,
        // 划扣（仅限车贷王）
        dialogDeduct: false,
        deductForm: {
          chargeMethod: 1,
          chargePeriod: null,
          chargeMoneyMethod: 2
        },
        deductRules: {
          chargeMethod: [
            { required: true, message: '请选择划扣方式', trigger: 'change' }
          ],
          chargePeriod: [
            { required: true, message: '请选择划扣期数', trigger: 'change' }
          ],
          chargeMoneyMethod: [
            { required: true, message: '请选择划扣金额', trigger: 'change' }
          ]
        },
        deductBtnLoading: false,
        billInfo: {}, // 划扣信息
        billStagingMap: {}, // 划扣的期数map
        totalAmount: [], // 划扣金额（本金+利息)
        totalAmountPenalty: [] // 划扣金额（本金+利息+逾期滞纳金)
      }
    },
    mounted () {
    },
    methods: {
      // 减免款项改变时间
      handleChangeCheckList () {
        this.calculate() // 重新计算
      },
      // 处理罚改变事件
      handleChange1 () {
        if (this.reduceForm.reduceRate1 === this.reduceRateTotal1[this.reduceRateTotal1.length - 1].value) {
          this.rate2 = false
        } else {
          this.rate2 = true
          this.rate3 = true
          this.reduceForm.reduceRate2 = null
          this.reduceForm.reduceRate3 = null
        }
        this.calculate() // 重新计算
      },
      // 处理罚清除事件
      handleClear1 () {
        this.rate2 = true
        this.rate3 = true
        this.reduceForm.reduceRate2 = null
        this.reduceForm.reduceRate3 = null
        this.calculate() // 重新计算
      },
      // 处理利息改变事件
      handleChange2 () {
        if (this.reduceForm.reduceRate2 === this.reduceRateTotal2[this.reduceRateTotal2.length - 1].value) {
          this.rate3 = false
        } else {
          this.rate3 = true
          this.reduceForm.reduceRate3 = null
        }
        this.calculate() // 重新计算
      },
      // 处理利息清除事件
      handleClear2 () {
        this.rate3 = true
        this.reduceForm.reduceRate3 = null
        this.calculate() // 重新计算
      },
      // 处理本金改变事件
      handleChange3 () {
        this.calculate() // 重新计算
      },
      // 处理本金清除事件
      handleClear3 () {
        this.calculate() // 重新计算
      },
      checkImage (val) {
        window.open('#/case-detail-image/' + val.orderId)
      },
      handleShow (index) {
        // 重新设置this.userInfoData[index].isShowInfo的值，更新视图
        let newValue = this.userInfoData[index]
        newValue.isShowInfo = !newValue.isShowInfo
        // 无论什么情况，缩和展，都是收起详情
        newValue.isShowTable = false
        // 然后更新视图
        Vue.set(this.userInfoData, index, newValue)
      },
      // 面板change
      handleChange (val) {
        console.log(val)
      },
      // 收起或者展开详情
      handleTable (index) {
        let newValue = this.userInfoData[index]
        newValue.isShowTable = !newValue.isShowTable
        Vue.set(this.userInfoData, index, newValue)
      },
      // ****************弹窗 修改信息 ******************
      // 点击修改信息按钮
      openUserInfoDialogBtn (val) {
        console.log(val)
        this.dialogEditUserInfo = true
        this.userInfoForm = {
          homeAddress: val.homeAddress,
          unitName: val.unitName,
          unitAddress: val.unitAddress,
          originalHomeAddress: val.originalHomeAddress,
          originalUnitName: val.originalUnitName,
          originalUnitAddress: val.originalUnitAddress
        }
        this.editUserInfoForm.orderId = val.orderId
      },
      // 修改信息 确认按钮
      dialogEditUserInfoConfirm () {
        this.$refs['editUserInfoForm'].validate((valid) => {
          if (valid) {
            this.editBtnLoading = true
            let updateCaseUserVO = {
              orderId: this.editUserInfoForm.orderId,
              homeAddress: this.editUserInfoForm.newHomeAddress,
              unitAddress: this.editUserInfoForm.newUnitAddress,
              unitName: this.editUserInfoForm.newUnitName
            }
            fetchUpdateCaseUser(JSON.stringify(updateCaseUserVO))
              .then(response => {
                let res = response.data
                if (res.errorCode === 0) {
                  // 向父组件传递事件-更新用户信息-可以传递参数
                  this.$emit('updateUserInfo')
                  this.$message.success('修改信息成功')
                }
                this.dialogEditUserInfo = false
                this.editBtnLoading = false
              })
              .catch(error => {
                console.log(error)
                this.dialogEditUserInfo = false
                this.editBtnLoading = false
              })
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      // 修改信息 取消按钮
      dialogEditUserInfoCancel () {
        // 重置
        this.$refs['editUserInfoForm'].resetFields()
        this.dialogEditUserInfo = false
      },
      // 关闭弹窗回调
      dialogEditUserInfoClose () {
        // 重置
        this.$refs['editUserInfoForm'].resetFields()
      },
      // ****************弹窗 发短信 ******************
      sendSms (productId, orderId) {
        this.sendSmsProps = {
          dialogVisible: true,
          productId: productId,
          orderId: orderId,
          caseId: this.caseId
        }
      },
      // 更新欠款信息
      updateCaseDetail (orderId) {
        fetchUpdateCaseDetail(orderId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.isShowUpdateBtn = false
              this.$message.success('更新成功')
              // 向父组件传递事件-更新欠款信息-可以传递参数
              this.$emit('updateCaseDetail')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // ********************划扣**********************
      // 手动扣款-获取划扣信息
      getReduceConfigByCaseId (productId, billId) {
        this.currentProductId = productId
        this.billId = billId
        fetchFindReduceConfigByCaseId(this.caseId, this.billId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              // 应还金额
              this.reduceForm.balance = res.data.bill.balance / 100
              // 划扣金额
              this.reduceForm.realRepayment = (Math.round((this.reduceForm.balance - this.reduceForm.reduceAmout) * 100)) / 100
              // this.reduceForm.balance = debt
              // 剩余本金0元 + 逾期综合费用327.9元 + 贷后综合费用107.14元
              this.tempArr = {1: null, 2: null, 3: null} // 暂存剩余本金、逾期综合费用、贷后综合费用
              this.tempArr[1] = res.data.bill.overdueFeeBlance / 100
              this.tempArr[2] = res.data.bill.interestBalance / 100
              this.tempArr[3] = res.data.bill.principalBalance / 100
              this.reduceList = [
                {
                  paramCode: res.data.overdueAmountParam.paramCode,
                  amount: res.data.bill.overdueFeeBlance / 100,
                  name: '逾期综合费用' + res.data.bill.overdueFeeBlance / 100 + '元',
                  paramExtone: res.data.overdueAmountParam.paramExtone,
                  paramValue: res.data.overdueAmountParam.paramValue
                },
                {
                  paramCode: res.data.taxAmountParam.paramCode,
                  amount: res.data.bill.interestBalance / 100,
                  name: '贷后综合费用' + res.data.bill.interestBalance / 100 + '元',
                  paramExtone: res.data.taxAmountParam.paramExtone,
                  paramValue: res.data.taxAmountParam.paramValue
                },
                {
                  paramCode: res.data.balanceParam.paramCode,
                  amount: res.data.bill.principalBalance / 100,
                  name: '剩余本金' + res.data.bill.principalBalance / 100 + '元',
                  paramExtone: res.data.balanceParam.paramExtone,
                  paramValue: res.data.balanceParam.paramValue
                }
              ]
              let arr1 = [{value: 0.1, label: '10%'}, {value: 0.2, label: '20%'}, {value: 0.3, label: '30%'}, {value: 0.4, label: '40%'}, {value: 0.5, label: '50%'}, {value: 0.6, label: '60%'}, {value: 0.7, label: '70%'}, {value: 0.8, label: '80%'}, {value: 0.9, label: '90%'}, {value: 1, label: '100%'}]
              let arr2 = [{value: 0.1, label: '10%'}, {value: 0.2, label: '20%'}, {value: 0.3, label: '30%'}, {value: 0.4, label: '40%'}, {value: 0.5, label: '50%'}, {value: 0.6, label: '60%'}, {value: 0.7, label: '70%'}, {value: 0.8, label: '80%'}, {value: 0.9, label: '90%'}, {value: 1, label: '100%'}]
              let arr3 = [{value: 0.1, label: '10%'}, {value: 0.2, label: '20%'}, {value: 0.3, label: '30%'}, {value: 0.4, label: '40%'}, {value: 0.5, label: '50%'}, {value: 0.6, label: '60%'}, {value: 0.7, label: '70%'}, {value: 0.8, label: '80%'}, {value: 0.9, label: '90%'}, {value: 1, label: '100%'}]
              // 剩余本金
              arr3.splice(res.data.balanceParam.paramExtone)
              this.reduceRateTotal3 = arr3
              this.disabled3 = res.data.balanceParam.paramValue
              // 逾期综合费用
              arr1.splice(res.data.overdueAmountParam.paramExtone)
              this.reduceRateTotal1 = arr1
              this.disabled1 = res.data.overdueAmountParam.paramValue
              // 贷后综合费用
              arr2.splice(res.data.taxAmountParam.paramExtone)
              this.reduceRateTotal2 = arr2
              this.disabled2 = res.data.taxAmountParam.paramValue

              this.dialogReduce = true
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 计算
      calculate () {
        let sum = 0
        if (!this.reduceForm.checkList.length) {
          sum = 0
          if (this.currentProductId === 1 || this.currentProductId === 2) {
            return false
          } else {
            this.reduceForm.reduceAmout = 0
          }
        }
        this.reduceForm.checkList.map(code => {
          this.reduceList.map((j, index) => {
            if (code === j.paramCode) {
              let re = 'reduceRate' + (index + 1)
              sum += j.amount * this.reduceForm[re]
            }
          })
        })
        this.reduceForm.reduceAmout = (Math.round(sum * 100)) / 100
        this.reduceForm.realRepayment = (Math.round((this.reduceForm.balance - this.reduceForm.reduceAmout) * 100)) / 100
      },
      calculateConfirm () {
        let sum = 0
        if (!this.reduceForm.checkList.length) {
          sum = 0
          if (this.currentProductId === 1 || this.currentProductId === 2) {
            return false
          } else {
            this.reduceForm.reduceAmout = 0
          }
        }
        this.reduceForm.checkList.map(code => {
          this.reduceList.map((j, index) => {
            if (code === j.paramCode) {
              let re = 'reduceRate' + (index + 1)
              sum += j.amount * this.reduceForm[re]
            }
          })
        })
        // this.reduceForm.realRepayment = (Math.round((this.reduceForm.balance - this.reduceForm.reduceAmout) * 100)) / 100
        return (Math.round(sum * 100)) / 100
      },
      // 最大值
      maxValue () {
        let maxValue = 0
        this.reduceList.forEach((item, index) => {
          if (item.paramValue === 'Y') {
            maxValue += item.paramExtone * 0.1 * item.amount
          }
        })
        return maxValue
      },
      // 失焦事件
      handleBlur () {
        this.reduceForm.reduceAmout = getMaxTwoDecimalPlaces(this.reduceForm.reduceAmout)
        if (this.reduceForm.reduceAmout < 0) {
          this.$message.warning('减免金额不能为负')
          return false
        }
        if (!this.calculateConfirm()) {
          if (this.reduceForm.reduceAmout > this.maxValue()) {
            this.$message.warning('减免金额不能大于最大减免金额')
            return false
          }
        } else {
          if (this.reduceForm.reduceAmout > this.calculateConfirm()) {
            this.$message.warning('减免金额不能大于计算后的金额')
            return false
          }
        }
        console.log(this.reduceForm.reduceAmout)
        this.reduceForm.realRepayment = (Math.round((this.reduceForm.balance - this.reduceForm.reduceAmout) * 100)) / 100
      },
      // 选择调用的划扣接口
      dialogReduceConfirmChoose () {
        // 1 2 老产品
        if (this.currentProductId === 1 || this.currentProductId === 2) {
          this.dialogReduceConfirm()
        } else {
          this.dialogCoreReduceConfirm() // 调用立即贷划扣接口（新产品）
        }
      },
      // 立即贷划扣
      dialogCoreReduceConfirm () {
        let arr = []
        this.reduceForm.checkList.map(code => {
          this.reduceList.map((j, index) => {
            if (code === j.paramCode) {
              arr.push(index)
            }
          })
        })
        this.tempBrr = {1: null, 2: null, 3: null} // 暂存数组
        arr.forEach((item, index) => {
          let re = 'reduceRate' + (item + 1)
          this.tempBrr[item + 1] = this.tempArr[item + 1] * this.reduceForm[re]
        })
        this.$confirm('确定执行划扣操作?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          // 确认后调用划扣接口
          this.dialogCoreReduceConfirmAgain()
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消划扣操作'
          })
        })
      },
      // 立即划扣
      dialogReduceConfirm () {
        if (!this.calculateConfirm()) {
          if (this.reduceForm.reduceAmout > this.maxValue()) {
            this.$message.warning('减免金额不能大于最大减免金额')
            return false
          }
        } else {
          if (this.reduceForm.reduceAmout > this.calculateConfirm()) {
            this.$message.warning('减免金额不能大于计算后的金额')
            return false
          }
        }
        this.reduceForm.realRepayment = (Math.round((this.reduceForm.balance - this.reduceForm.reduceAmout) * 100)) / 100
        if (this.reduceForm.realRepayment <= 0 || this.reduceForm.realRepayment > this.reduceForm.balance) {
          this.$message.warning('实际还款金额不在规定内')
          return false
        }
        this.$confirm('确定执行划扣操作?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          // 确认后调用划扣接口
          this.dialogReduceConfirmAgain()
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消划扣操作'
          })
        })
      },
      // 确认执行立即贷划扣
      dialogCoreReduceConfirmAgain () {
        this.reduceBtnLoading = true
        let reduceRate1 = this.reduceForm.reduceRate1 ? this.reduceForm.reduceRate1 : '请选择'
        let reduceRate2 = this.reduceForm.reduceRate2 ? this.reduceForm.reduceRate2 : '请选择'
        let reduceRate3 = this.reduceForm.reduceRate3 ? this.reduceForm.reduceRate3 : '请选择'
        let param = {
          billId: this.billId,
          caseId: this.caseId,
          productId: this.currentProductId,
          reduceRate: reduceRate1 + ',' + reduceRate2 + ',' + reduceRate3,
          reduceOverdueFee: Math.round(this.tempBrr[1] * 100), // 扣除的罚
          reduceInterest: Math.round(this.tempBrr[2] * 100), // 扣除的利
          reducePrincipal: Math.round(this.tempBrr[3] * 100) // 扣除的本金
        }
        fetchCallProductCoreReduce(JSON.stringify(param))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success('已通知后台进行划扣，请稍后查看扣款结果')
            }
            this.dialogReduce = false
            this.reduceBtnLoading = false
          })
          .catch(error => {
            console.log(error)
            this.reduceBtnLoading = false
          })
      },
      // 确认执行立即划扣
      dialogReduceConfirmAgain () {
        this.reduceBtnLoading = true
        let debt = Math.round(this.reduceForm.balance * 100)
        let reduceAmout = Math.round(this.reduceForm.reduceAmout * 100)
        let realRepayment = Math.round(this.reduceForm.realRepayment * 100)
        let userId = this.userId
        let caseId = this.caseId
        let productId = this.currentProductId
        let billId = this.billId

        let reduceRate1 = this.reduceForm.reduceRate1 ? this.reduceForm.reduceRate1 : '请选择'
        let reduceRate2 = this.reduceForm.reduceRate2 ? this.reduceForm.reduceRate2 : '请选择'
        let reduceRate3 = this.reduceForm.reduceRate3 ? this.reduceForm.reduceRate3 : '请选择'
        let reduceRate = reduceRate1 + ',' + reduceRate2 + ',' + reduceRate3
        fetchCallWsCaseReduceDebtRecord(debt, reduceRate, reduceAmout, realRepayment, userId, caseId, billId, productId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              let obj = {status: 1}
              if (res.data === JSON.stringify(obj)) {
                this.$message.success('已通知后台进行划扣，请稍后查看扣款结果')
              } else {
                this.$message.warning(res.data)
              }
            }
            this.dialogReduce = false
            this.reduceBtnLoading = false
          })
          .catch(error => {
            console.log(error)
            this.reduceBtnLoading = false
          })
      },
      // 关闭
      dialogReduceClose () {
        this.reduceForm = {
          balance: null, // 应还金额
          checkList: [], // 勾选的减免款项
          reduceRate1: null, // 减免率1
          reduceRate2: null, // 减免率2
          reduceRate3: null, // 减免率3
          reduceAmout: 0, // 减免金额
          realRepayment: 0 // 实际欠款金额
        }
        this.reduceList = [] // 减免款项
        this.reduceRateTotal1 = []
        this.reduceRateTotal2 = []
        this.reduceRateTotal3 = []
        this.disabled1 = false
        this.disabled2 = false
        this.disabled3 = false
        this.rate2 = true
        this.rate3 = true
      },
      // 划扣按钮 打开弹窗（仅限车贷王）
      async handleDeductAutoLoan (productId, billId) {
        this.deductBtnLoading = false // 确认按钮loading取消
        this.billInfo.billStagingList = [] // 划扣的期数列表清空
        try {
          const { data } = await fetchFindReduceForBuckle(billId, this.caseId, productId)
          if (data.errorCode === 0) {
            this.billInfo = data.data
            data.data.billStagingList.forEach(item => {
              this.billStagingMap[item.periodNo] = item
            })
            this.dialogDeduct = true // 划扣期数接口成功后再打开弹窗并渲染数据
          } else {
            this.billInfo.billStagingList = []
          }
        } catch (e) {
          this.billInfo.billStagingList = []
        }
      },
      // 划扣确认按钮（仅限车贷王)
      dialogDeductConfirmChoose () {
        this.$refs['deductForm'].validate((valid) => {
          if (valid) {
            // 划扣金额 === 本金+利息
            if (this.deductForm.chargeMoneyMethod === 1) {
              if (this.totalAmount === 0) {
                this.$message.warning('划扣金额为0，不能执行划扣操作')
                return false
              }
            } else { // 划扣金额 === 本金+利息+逾期滞纳金
              if (this.totalAmountPenalty === 0) {
                this.$message.warning('划扣金额为0，不能执行划扣操作')
                return false
              }
            }
            // 划扣金额不为0，则调用划扣接口进行划扣
            this.callProductCoreReduce()
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      // 划扣接口
      async callProductCoreReduce () {
        this.deductBtnLoading = true
        try {
          const { billId, caseId, productId } = this.billInfo
          let param = {
            billId,
            caseId,
            productId,
            ...this.deductForm
          }
          const response = await fetchCallProductCoreReduce(JSON.stringify(param))
          const res = response.data
          if (res.errorCode === 0) {
            this.$message({ type: 'success', message: '操作成功，请等待系统划扣', duration: 1000 })
          }
        } finally {
          this.deductBtnLoading = false
          this.dialogDeduct = false
        }
      },
      // 划扣方式改变
      handleChangeChargeMethod (val) {
        this.deductForm.chargePeriod = null // 划扣期数置空
        this.deductForm.chargeMoneyMethod = val === 1 ? 2 : null
      },
      // 划扣期数改变
      handleChangeChargePeriod (val) {
        this.totalAmount = this.billStagingMap[val].totalAmount
        this.totalAmountPenalty = this.billStagingMap[val].totalAmountPenalty
      }
    }
  }
</script>

<style lang="scss" scoped>

  .user-info-wrapper {

    .user-info {
      border-top: 1px solid #eee;
    }
    .length-1 {
      width: 150px;
    }
    .f-w-7 {
      font-weight: 700;
    }
    li {
      font-size: 12px;
      color: #333;
      span {
        line-height: 20px;
      }
      /* 强调样式 */
      .stress-style {
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        span {
          color: #C03639;
          font-weight: 700;
          font-size: 14px;
          line-height: 30px;
        }
      }
      /* 置灰 */
      .gray-style {
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        span {
          color: #999;
          font-size: 14px;
          line-height: 30px;
        }
      }
    }
  }

</style>
