<!--投诉工单详情-->
<template>
  <el-dialog title="详情" :visible.sync="dialogDetailVisible">
    <ul>
      <li v-for="item in details" :key="item.id">
        <span>{{ item.createAt }}</span>
        <!--<span>{{ '【' + item.processPersonName + '】' }}</span>-->
        <span>{{ item.processDetail }}</span>
      </li>
    </ul>
    <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="dialogDetailVisible = false">关 闭</el-button>
      </span>
  </el-dialog>
</template>

<script>
  import { fetchGetDetail } from '../../../api/case'
  export default {
    name: 'complainDetail',
    data () {
      return {
        // 详情弹窗
        row: null,
        dialogDetailVisible: false,
        details: []
      }
    },
    watch: {
      dialogDetailVisible (val) {
        if (val) {
          this.getDetail()
        }
      }
    },
    methods: {
      // 详情
      async getDetail () {
        console.log(this.row)
        this.dialogDetailVisible = true
        this.details = [
          {id: 1, createAt: '2018-08-03 14:00', processPersonName: '客服', processDetail: '发起信修投诉'},
          {id: 2, createAt: '2018-08-03 14:11', processPersonName: '王莽', processDetail: '确认认领'}
        ]
        let response = await fetchGetDetail(this.row.customerBillId)
        let res = response.data
        if (res.errorCode === 0 && res.data) {
          this.details = res.data
        }
      }
    }
  }
</script>

<style lang="scss" scoped>

</style>