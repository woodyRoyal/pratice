<!--重点关注-->
<template>
  <span>
    <span v-show="focus <= 0">
      <el-button :loading="loading" type="primary" size="mini" @click="handleFocus(1)">关注本人</el-button>
      <el-button :loading="loading" type="primary" size="mini" @click="handleFocus(2)">关注本+联</el-button>
    </span>
    <span v-show="focus === 1">
      <el-button :loading="loading" type="primary" size="mini" @click="handleFocus(-1)">取消本人</el-button>
      <el-button disabled type="primary" size="mini" @click="handleFocus(2)">关注本+联</el-button>
    </span>
    <span v-show="focus === 2">
      <el-button disabled type="primary" size="mini" @click="handleFocus(1)">关注本人</el-button>
      <el-button :loading="loading" type="primary" size="mini" @click="handleFocus(-2)">取消本+联</el-button>
    </span>
  </span>
</template>

<script>
  import { fetchFocus, fetchIsFocus } from '../../../api/case'
  export default {
    name: 'focusPhone',
    data () {
      return {
        focus: 0,
        loading: false,
        caseId: null
      }
    },
    methods: {
      // 获取是否关注
      async getIsFocus (caseId) {
        this.caseId = caseId
        let response = await fetchIsFocus(caseId)
        let res = response.data
        if (res.errorCode === 0) {
          this.focus = !res.data ? 0 : Number(res.data)
        }
      },
      // 关注
      async handleFocus (val) {
        this.loading = true
        try {
          let type = val === -1 || val === -2 ? '' : val
          let response = await fetchFocus(this.caseId, type)
          let res = response.data
          if (res.errorCode === 0) {
            val === 1 && this.$message.success('重点关注本人成功')
            val === 2 && this.$message.success('重点关注本人+联系人成功')
            val === -1 && this.$message.success('取消重点关注本人')
            val === -2 && this.$message.success('取消重点关注本人+联系人')
            this.focus = val
          }
          this.loading = false
        } catch (e) {
          this.loading = false
        }
      }
    }
  }
</script>

<style lang="scss" scoped>

</style>