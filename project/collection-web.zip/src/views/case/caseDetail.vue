<!-- 案件详情 -->
<template>
  <div class="case-detail-wrapper">

    <!--停催居中div-->
    <suspend-layer v-show="suspendColl === 1" :caseId="caseId" @listenSuspendStatus="listenSuspendStatus"></suspend-layer>

    <el-row  v-show="!suspendColl">
      <!-- 左侧 -->
      <el-col :span="12">
        <!-- 用户基本信息展示 -->
        <el-form ref="userInfoForm" :model="userInfoForm" class="form-block" v-if="JSON.stringify(userInfoForm) !== '{}'">
          <el-form-item>
            <b class="form-block-b" style="font-size: 16px;">{{ userInfoForm.username }}</b>
            <span class="form-block-b">({{ userInfoForm.userId }}，{{ userInfoForm.gender }}，{{ userInfoForm.age }}，{{ userInfoForm.birthday }}，{{ userInfoForm.identityCard }})</span>
            <!--是v3.14只催月供，也是车贷王时，展示该样式-->
            <b class="form-block-b" style="float: right;" v-if="isMonthlyPayment && isCDW">
              <span style="display: block; line-height: 24px;">
                <span>合计欠款:</span>
                <span style="color: red;">{{ userInfoForm.totalDebt }}</span>
              </span>
              <span style="display: block; line-height: 16px; font-weight: normal; font-size: 12px;">
                <span>（{{ userInfoForm.totalDebtDesc }}）</span>
              </span>
            </b>
            <!--其他还展示之前样式-->
            <b class="form-block-b" style="float: right;"
               v-else>
              <span>合计欠款:</span>
              <span style="color: red;">{{ userInfoForm.totalDebt }}</span>
            </b>
          </el-form-item>
        </el-form>

        <!--多产品信息展示-->
        <user-info :userInfoProp="userInfoForm" :isMonthlyPayment="isMonthlyPayment" v-on:updateUserInfo="updateUserInfo" v-on:updateCaseDetail="updateCaseDetail"></user-info>

        <!--tab-->
        <tab-data class="form-block" :userInfoProp="userInfoForm" v-on:handleCallAgain="handleCallAgain"></tab-data>

        <!-- 操作信息-->
        <operate-table class="form-block" :OTProps="OTProps" :caseId="null"></operate-table>
      </el-col>
      <!-- 右侧 -->
      <el-col :span="12">
        <!-- 按钮 start -->
        <el-form class="form-block">
          <el-form-item>
            <!--{1:'待确认'},{2:'待处理'},{3:'处理中'},{4:'已处理'},{5:'已结束'}-->
            <deal-complain style="float: left;" v-if="userInfoForm.complainBillStatus && userInfoForm.complainBillStatus < 5"
                           :complainBillStatus="userInfoForm.complainBillStatus" :customerBillId="userInfoForm.customerBillId"></deal-complain>
            <div style="float: right;">
              <!--重点关注本人手机号 重点关注本人+联系人-->
              <focus-phone ref="focusPhone"></focus-phone>
              <el-button type="primary" size="mini" @click="resetSoftPhone">重置软电话</el-button>
              <el-button type="primary" size="mini" @click="sendSms" v-if="IsSendMessage > 1">发短信</el-button>
              <el-button type="primary" size="mini" @click="openAddContact">增加联系人</el-button>
              <span>已选择{{ multipleSelection.length }}人</span>
              <el-button type="primary" size="mini" @click="batchCall">批量外呼</el-button>
              <!--停催激活案件-->
              <active-suspend ref="activeSuspend" :caseId="caseId" @listenSuspendStatus="listenSuspendStatus"></active-suspend>
            </div>
          </el-form-item>
        </el-form>
        <!-- 按钮 end -->

        <!-- 通讯录表格 start -->
        <div class="form-block call-table" ref="callTableBox">
          <water-mark :displayName="displayName" :userId="userId" :boxWidth="callTableWidth" :boxHeight="callTableHeight"></water-mark>
          <table ref="callTable" width="100%" min-height="100px" border="1" cellspacing="0" cellpadding="0" v-loading="callMsg.listLoading">
            <tr>
              <th width="30px">
                <input type="checkbox" :checked="isCheckedAll" @change="handleSelectAll">
              </th >
              <th width="30px">序号</th>
              <th width="100px">姓名</th>
              <th width="120px">手机</th>
              <!--<th width="60px" style="cursor: pointer;" @click="getCallTableData((timesOrder ++) % 2 === 1 ? 'times desc' : 'times asc')">-->
                <!--通话次数-->
                <!--<i class="el-icon-caret-top" v-show="timesOrder % 2 === 1"></i>-->
                <!--<i class="el-icon-caret-bottom" v-show="timesOrder % 2 === 0"></i>-->
              <!--</th>-->
              <!--<th width="80px">最近联系</th>-->
              <!--<th width="60px" style="cursor: pointer;" @click="getCallTableData((latestCallAtOrder ++) % 2 === 1 ? 'latestCallAt desc' : 'latestCallAt asc')">-->
                <!--接通次数/拨打次数-->
                <!--<i class="el-icon-caret-top" v-show="latestCallAtOrder % 2 === 1"></i>-->
                <!--<i class="el-icon-caret-bottom" v-show="latestCallAtOrder % 2 === 0"></i>-->
              <!--</th>-->
              <th width="80px" style="cursor: pointer;" @click="getCallTableData((resultDescOrder ++) % 2 === 1 ? 'resultDesc desc' : 'resultDesc asc')">
                电话结果
                <i class="el-icon-caret-top" v-show="resultDescOrder % 2 === 1"></i>
                <i class="el-icon-caret-bottom" v-show="resultDescOrder % 2 === 0"></i>
              </th>
              <th>备注</th>
            </tr>
            <!--8 => 30-->
            <tr v-for="(item, index) in callTableData" :key="index" :class="{'bg_red': item.order === 30}">
              <td>
                <input type="checkbox" :checked="item.isChecked" @change="handleSelect(item, index)" :disabled="item.forbstatus === 1">
              </td>
              <td>{{ index + 1 }}</td>
              <td>{{ item.name }}</td>
              <td>
                <!--禁用 或者 停催-->
                <span v-if="item.forbstatus || suspendColl === 1" style="color: #999;">{{ item.phone }}</span>
                <span v-else class="file-name" @click="singleCallLimit(item)">{{ item.phone }}</span>
                <!--<span v-else class="file-name" @click="singleCall(item)">{{ item.phone }}</span>-->
                <span>({{ item.location }})</span>
              </td>
              <!--<td>{{ item.times }}</td>-->
              <!--<td>{{ item.latestCallAt }}</td>-->
              <!--<td>-->
                <!--<span v-if="item.callTimes">{{ item.connectedTimes || 0 }}</span>-->
                <!--<span v-if="item.callTimes">/</span>-->
                <!--<span>{{ item.callTimes }}</span>-->
              <!--</td>-->
              <td width=80px>{{ item.resultDesc }}</td>
              <td>
                <span class="file-name" v-if="!item.forbstatus" @click="openCollectionRecord(item)">催记</span>
                <span class="file-name" v-if="item.forbstatus && showSelectObj.isShowActive && !suspendColl" @click="activeMobilephone(item)">激活</span>
                {{ item.memo }}
              </td>
            </tr>
          </table>
        </div>
        <!-- 通讯录表格 end -->
      </el-col>
    </el-row>

    <!-- 增加联系人 弹窗 start -->
    <el-dialog title="增加联系人" :visible.sync="dialogAddContact" @close="dialogAddContactClose">
      <el-form :model="addContactForm" :rules="addContactRules" ref="addContactForm" label-width="120px">
        <el-form-item label="关系：" prop="relationId">
          <el-radio-group v-model="addContactForm.relationId">
            <el-radio :label="1">本人</el-radio>
            <el-radio :label="2">家人</el-radio>
            <el-radio :label="3">朋友</el-radio>
            <el-radio :label="4">同事</el-radio>
            <el-radio :label="5">公司</el-radio>
            <el-radio :label="99">其他</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="联系人姓名：" prop="contactName">
          <el-input v-model="addContactForm.contactName" auto-complete="off"></el-input>
        </el-form-item>

        <el-form-item label="联系号码：" prop="phone">
          <el-input v-model="addContactForm.phone" auto-complete="off"></el-input>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogAddContactCancel">取 消</el-button>
        <el-button type="primary" @click="dialogAddContactConfirm" :loading="addContactLoading">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 增加联系人 弹窗 end -->

    <!--批量外呼-->
    <add-project :PMProps="PMProps"></add-project>

    <!--催记弹窗-->
    <collection-record :userName="userInfoForm.username" :productId="productId" :CRProps="CRProps" :CRData="CRData" :currentVoicePath="currentVoicePath" :currentConnect="currentConnect"
                       :caseId="caseId" :callRecordId="callRecordId" v-on:updateOT="updateOT"></collection-record>

    <!--小按钮-->
    <div class="small-box" @click="smallBtn" v-show="isShowSmallBox">{{ currentCRInfo.name }}{{ currentCRInfo.phone }}</div>

    <!--批呼刚进来的遮罩层-->
    <div v-loading.fullscreen.lock="fullscreenLoading" element-loading-text="拼命拨打电话中"></div>

    <!--发短信-->
    <send-sms :sendSmsProps="sendSmsProps"></send-sms>

    <!--每日提醒-->
    <!--<div class="day-remind" @click="dayRemindBtn" v-show="!isShowDayRemind">
      <i class="el-icon-warning"></i>
      今日{{ currentRemindList.length }}个提醒
    </div>-->

    <el-dialog title="今日提醒" :visible.sync="isShowDayRemind">
      <el-table :data="currentRemindList" style="width: 100%">
        <el-table-column align="center" label="联系人姓名">
          <template slot-scope="scope">
            <span class="imitate-a-label" @click="openCaseDetailById(scope.row)">{{ scope.row.contactName }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="remindTime" label="提醒时间"></el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { socket, outbound } from 'utils/outbound'
  import { parseTime } from 'utils/formatDate'
  // import { base64decode } from 'utils/index'
  import { CONST_OVERDUE_LEVEL_MAP } from './caseConstant'
  import userInfo from './components/userInfo'
  import tabData from './components/tabData'
  import operateTable from './components/operateTable'
  import addProject from './components/addProject'
  import collectionRecord from './components/collectionRecord'
  import WaterMark from '@/components/WaterMark' // 水印
  import dealComplain from './components/dealComplain' // 投诉
  import focusPhone from './components/focusPhone' // 重点关注
  import activeSuspend from './components/activeSuspend' // 激活停催案件
  import suspendLayer from './components/suspendLayer' // 停催层
  //  import isEmptyObject from 'utils/index'
  import {
    URL_WEBSOCKET_SERVER, // websocket地址
    fetchCreateSingleTask, // 单呼
    URL_SINGLE_CALL_CALL_BACK, // 单呼回传地址
    fetchGetCaseInfo, // 获取用户信息 by caseId
    fetchGetCaseContactData, // 获取通讯录
    fetchAppendContactor, // 增加联系人
    fetchUpdateSmsChecked, // 更新联系人选中状态
    fetchGetSingleCallInfo, // 创建获取uuid 和 callRecordId
    fetchUpdateExecuteRecord2, // 更新通话记录
    fetchIsPassTheLimitTimes, // 判断是否超过限制次数，超过限制次数，不给予拨打
    fetchActiveMobilephone, // 激活手机号
    fetchGetCurrentRemindData, // 今日提醒
    fetchkillOwnServiceNum, // 强制杀死自己的坐席
    fetchExchangePhone, // 加密解密
    fetchGetWithoutOverdueFeeSwitch // 获取忽略逾期滞纳金开关
  } from '../../api/case'
  import sendSms from './components/sendSms'
  export default {
    components: {
      userInfo, tabData, operateTable, addProject, collectionRecord, sendSms, WaterMark, dealComplain, focusPhone, activeSuspend, suspendLayer
    },
    computed: {
      ...mapGetters([
        'currentCRInfo', // 当前催记信息
        'isSubmitted', // 提交状态
        'isShowSmallBox', // 小按钮
        'serviceNum', // 坐席
        'showSelectObj', // 是否显示
        'displayName', // 显示中文名
        'userId', // userId
        'timeLimit' // 单呼点击限制
      ]),
      productId () {
        if (this.userInfoForm && this.userInfoForm.caseProductInfoList && this.userInfoForm.caseProductInfoList.length) {
          return this.userInfoForm.caseProductInfoList[0].productId
        } else {
          return null
        }
      },
      // 是否是车贷王
      isCDW () {
        return this.userInfoForm.caseProductInfoList[0] && this.userInfoForm.caseProductInfoList[0].productId === 6
      }
    },
    data () {
      return {
        isMonthlyPayment: true, // 催月供（本金+利息)，不催罚息 ：可配置（后端Apollo)通过接口更改
        caseId: null,
        IsSendMessage: null,
        parseTime,
        // 用户信息
        userInfoForm: {},
        mountedCount: 0, // mounted次数
        suspendColl: 2, // 0 null激活状态  1 停催状态 // 设置为大于1的值
        CONST_OVERDUE_LEVEL_MAP,

        // 勾选的人数
        multipleSelection: [],
        // 案件联系 通讯录 表格
        callTableData: [],
        callTableWidth: 0,
        callTableHeight: 0,
        callMsg: {
          listLoading: false
        },
        // 增加联系人 弹窗
        dialogAddContact: false,
        addContactLoading: false, // loading
        addContactForm: {
          relationId: '',
          contactName: '',
          phone: ''
        },
        addContactRules: {
          relationId: [
            { required: true, message: '请选择关系', trigger: 'change' }
          ],
          contactName: [
            { required: true, message: '请输入联系人名称', trigger: 'blur' }
          ],
          phone: [
            { required: true, message: '请输入联系号码', trigger: 'blur' }
          ]
        },
        // 批量外呼
        PMProps: {},
        // 催记
        CRProps: {},
        CRData: {},
        socket: {
          url: URL_WEBSOCKET_SERVER
        },
        currentPhone: null, // 当前电话
        currentUuid: null, // 当前uuid
        currentCallStatus: '', // 当前通话状态
        currentCallData: '', // 当前通话信息
        currentVoicePath: '', // 当前通话录音地址
        currentConnect: false, // 当前是否接通过
        fullscreenLoading: false,
        OTProps: {}, // 传入操作信息的数据
        updateStr: 0,
        callRecordId: null, // callRecordId
        isCheckedAll: false,
        timesOrder: 0, // 通话次数规则 "times desc"通话次数降序 "times asc" 通话次数升序
        latestCallAtOrder: 0, // 最后通话时间规则 "latestCallAt desc" 最后通话时间降序 "latestCallAt asc" 最后通话时间升序
        resultDescOrder: 0, // 电话结果规则 "resultDesc desc" 电话结果降序 "resultDesc asc" 电话结果升序

        isShowDayRemind: false,
        currentRemindList: [],
        // timeFun: null,
        // timeLimit: true, // 单呼连续点击限制
        timer: null,

        // 发短信
        sendSmsProps: {}
      }
    },
    deactivated () {
      // clearInterval(this.timeFun)
      $(window).unbind('beforeunload')
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      // clearInterval(this.timeFun)
      $(window).unbind('beforeunload')
      window.removeEventListener('resize', this.handleResize)
    },
    created () {
      this.caseId = this.$route.params.id
			this.getWithoutOverdueFeeSwitch()
    },
    mounted () {
      this.$refs.focusPhone.getIsFocus(this.caseId)
      window.addEventListener('resize', this.handleResize)

      if (window.location.href.indexOf('/case-detail') > -1) {
        document.title = '案件详情'
      }
      // 刷新、关闭页面提醒
      //      window.onbeforeunload = function (event) {
      //        alert(111)
      //        event.returnValue="确定离开当前页面吗？"
      //      }
      //      window.addEventListener('beforeunload', function (event) {
      //        event.returnValue = "确定离开当前页面吗？"
      //      })
      //      $(window).bind('unload', function (event) {
      //        event.returnValue = "确定离开当前页面吗？"
      //      })
      console.log(this.serviceNum)
      // 建立websocket链接
      // this.initWebSocket()
      // 通过caseId获取用户信息
      this.getUserInfoByCaseId()
      // 获取案件联系表格数据
      // this.getCallTableData()
      // 获取催记记录信息列表
      // this.OTProps = {isUpdate: 'update' + this.updateStr}

      // 每日提醒 3mins调一次
      // this.getCurrentRemindData()
      /* let _this = this
      _this.timeFun = setInterval(function () {
        _this.getCurrentRemindData()
      }, 180000) */
    },
    methods: {
      // 获取忽略逾期滞纳金开关（V3.14）
      async getWithoutOverdueFeeSwitch () {
        const { data } = await fetchGetWithoutOverdueFeeSwitch()
				if (data.errorCode === 0) {
          this.isMonthlyPayment = data.data
				}
			},
      handleResize () {
        this.$refs.callTable.style.width = this.$refs.callTableBox.clientWidth - 8 + 'px'
        this.callTableWidth = this.$refs.callTable.clientWidth - 8
        this.callTableHeight = this.$refs.callTable.clientHeight
        this.$refs.callTableBox.style.height = this.callTableHeight + 12 +'px'
      },
      // 短信记录里面的打电话
      handleCallAgain (val) {
        let flag = true
        this.callTableData.forEach((item, index) => {
           // if (base64decode(val.phonenum) &&  base64decode(val.phonenum) === base64decode(item.realPhone)) {
           if (val.phonenum && val.phonenum === item.realPhone) {
             flag = false
             this.singleCall(item)  // 开始单呼
           }
        })
        if (flag) {
          // this.addContactForm.phone = base64decode(val.phonenum)
          // 解密成功后再弹窗添加联系人
          this.exchangePhone(1, val.phonenum)
        }
      },
      // 加密解密
      async exchangePhone (flag, phone) {
        let response = await fetchExchangePhone(flag, phone)
        let res = response.data
        if (res.errorCode === 0) {
          this.addContactForm.phone = res.data
          this.dialogAddContact = true
          this.$store.dispatch('TimeLimit', true)
          // this.$message.warning('请先将该联系人增加到通讯录中再拨打')
        }
      },
      // 重置软电话
      resetSoftPhone () {
        fetchkillOwnServiceNum()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success('软电话重置成功')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // ****************弹窗 发短信 ******************
      sendSms (productId, orderId) {
        let caseId = this.$route.params.id
        this.sendSmsProps = {
          dialogVisible: true,
          productId: 0,
          orderId: null,
          caseId: caseId
        }
      },
      // 每日提醒 3mins调一次
      getCurrentRemindData () {
        fetchGetCurrentRemindData()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.currentRemindList = res.data.map(item => {
                let date = parseTime(new Date(), 'YYYY-MM-DD') + ' ' + item.remindTime
                let time = new Date(date).getTime()
                if (time >= new Date().getTime() - 5 * 60 * 1000 && time <= new Date().getTime()) {
                  this.$notify.info({
                    title: '消息',
                    message: '联系人：' + item.contactName + '，提醒时间：' + item.remindTime
                  })
                }
                return item
              })
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 每日提醒
      dayRemindBtn () {
        this.isShowDayRemind = true
      },
      // 跳转到案件详情
      openCaseDetailById (val) {
        window.open('#/case-detail/' + val.caseId)
      },
      // 获取用户信息 by caseId
      getUserInfoByCaseId () {
        fetchGetCaseInfo(this.$route.params.id)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.userInfoForm = res.data
              this.suspendColl = this.userInfoForm.suspendColl
              // this.$refs.activeSuspend.status = this.userInfoForm.suspendColl
              this.IsSendMessage = this.userInfoForm.caseProductInfoList.length
              document.title = this.userInfoForm.username + '-案件详情'

              // todo 不停催状态获取
              if (!this.mountedCount && this.suspendColl !== 1) {
                // 获取案件联系表格数据
                this.getCallTableData()
                // 获取催记记录信息列表
                this.OTProps = {isUpdate: 'update' + this.updateStr}
              }
              this.mountedCount ++
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 监听来自子组件的事件-更新用户信息
      updateUserInfo () {
        this.getUserInfoByCaseId()
      },
      // 监听来自子组件的事件-更新欠款信息
      updateCaseDetail () {
        this.getUserInfoByCaseId()
      },
      // 监听来自子组件的事件-催记记录更新
      updateOT () {
        let _this = this
        _this.updateStr += 1
        _this.OTProps = {isUpdate: 'update' + this.updateStr}
        // 同时更新通讯录
        // _this.callMsg.listLoading = true
        //        setTimeout(function () {
        //          _this.getCallTableData()
        //        }, 1000)
      },
      // 激活手机号
      activeMobilephone(val) {
        let _this = this
        _this.callMsg.listLoading = true
        fetchActiveMobilephone(val.id, this.$route.params.id)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              setTimeout(function () {
                _this.getCallTableData()
              }, 1000)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取通讯录表格数据
      getCallTableData (order) {
        this.callMsg.listLoading = true
        let caseId = this.$route.params.id
        fetchGetCaseContactData(caseId, order)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              let arr = []
              this.callTableData = res.data.map(item => {
                if (item.smsChecked) {
                  item.isChecked = true
                  arr.push(item)
                }
                return item
              })
              // 判断是否全勾选
              this.isCheckedAll = arr.length === this.callTableData.length
              // 计算勾选数
              this.multipleSelection = arr
            }
            this.callMsg.listLoading = false
            // 更新dom，table宽度、高度变化，canvas变化
            this.$nextTick(() => {
              this.$refs.callTable.style.width = this.$refs.callTableBox.clientWidth - 8 + 'px'
              this.callTableWidth = this.$refs.callTable.clientWidth - 8
              this.callTableHeight = this.$refs.callTable.clientHeight
              this.$refs.callTableBox.style.height = this.callTableHeight + 12 +'px'
            })
          })
          .catch(error => {
            console.log(error)
            this.callMsg.listLoading = false
          })
      },
      // 单选
      handleSelect (item, index) {
        // 切换是否勾选
        this.callTableData[index].isChecked = !this.callTableData[index].isChecked
        // 计算总的勾选项
        let arr = []
        this.callTableData.map(item => {
          if (item.isChecked) {
            arr.push(item)
          }
        })
        this.multipleSelection = arr
        // 判断是否全部勾选
        this.isCheckedAll = this.callTableData.length === arr.length
        // 请求
        let caseId = this.$route.params.id
        let contactIds = item.id.toString().split(',')
        let smsChecked = item.isChecked ? 1 : 0 // 是否选中：0 未选中；1 选中
        fetchUpdateSmsChecked(caseId, JSON.stringify(contactIds), smsChecked)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              console.log('更新联系人选中状态')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 全选
      handleSelectAll () {
        let contactIds = []
        // 切换是否勾选
        this.isCheckedAll = !this.isCheckedAll
        if (this.isCheckedAll) {
          // 计算勾选数
          this.multipleSelection = this.callTableData
          this.callTableData.map(item=> {
            item.isChecked = true
            contactIds.push(item.id)
            return item
          })
        } else {
          // 计算勾选数
          this.multipleSelection = []
          this.callTableData.map(item => {
            item.isChecked = false
            contactIds.push(item.id)
            return item
          })
        }
        let caseId = this.$route.params.id
        let smsChecked = this.isCheckedAll ? 1 : 0 // 是否选中：0 未选中；1 选中
        fetchUpdateSmsChecked(caseId, JSON.stringify(contactIds), smsChecked)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              console.log('更新联系人选中状态')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // ****************弹窗 增加联系人 ******************
      // 点击修改信息按钮
      openAddContact () {
        this.dialogAddContact = true
      },
      // 增加联系人 确认按钮
      dialogAddContactConfirm () {
        this.$refs['addContactForm'].validate((valid) => {
          if (valid) {
            this.addContactLoading = true
            let appendContactVO = {
              caseId: this.$route.params.id,
              contactName: this.addContactForm.contactName,
              phone: 	this.addContactForm.phone,
              relationId: this.addContactForm.relationId
            }
            fetchAppendContactor(JSON.stringify(appendContactVO))
              .then(response => {
                let res = response.data
                if (res.errorCode === 0) {
                  // 获取案件联系表格数据
                  this.getCallTableData()
                  // 催记记录更新
                  this.OTProps = {isUpdate: 'update1111'}
                  this.$message.success('新增联系人成功')
                }
                this.dialogAddContact = false
                this.addContactLoading = false
              })
              .catch(error => {
                console.log(error)
                this.addContactLoading = false
              })
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      // 增加联系人 取消按钮
      dialogAddContactCancel () {
        // 重置
        this.$refs['addContactForm'].resetFields()
        this.dialogAddContact = false
      },
      // 关闭弹窗回调
      dialogAddContactClose () {
        this.$refs['addContactForm'].resetFields()
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            console.log('submit!')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      // ****************弹窗 批量外呼 ******************
      batchCall () {
        this.PMProps = {
          dialogVisible: true
        }
      },
      // 催记
      openCollectionRecord (val) {
        if (this.isSubmitted) {
          // 打开催记弹窗
          this.CRData = val
          this.CRProps = {dialogVisible: true}
          this.$store.dispatch('IsShowSmallBox', false)
          // 存储当前催记信息
          this.$store.dispatch('GetCurrentCRInfo', val)
          // 提交状态  变更为  未提交状态
          this.$store.dispatch('IsSubmitted', false)
        } else {
          if (val.id === this.currentCRInfo.id) {
            // this.CRData = val
            this.CRProps = {dialogVisible: true}
            this.$store.dispatch('IsShowSmallBox', false)
          } else {
            //            this.CRData = this.currentCRInfo
            //            this.CRProps = {
            //              dialogVisible: true
            //            }
            //            this.$store.dispatch('IsShowSmallBox', false)
            this.$message.warning('还有通话窗口未关闭！')
          }
        }
      },
      // 小按钮
      smallBtn () {
        if (this.currentCRInfo) {
          this.CRProps = {dialogVisible: true}
          this.$store.dispatch('IsShowSmallBox', false)
        }
      },
      // 使用sockjs，替代原生的websocket
      initWebSocket (val, phone) {
        if (typeof socket != 'undefined') {
          // 建立websocket连接
          socket.serviceNum = this.serviceNum
          // socket.serviceNum = 'S1003'
          if (socket.stompClient == null) {
            outbound.initWebSocket(this.socket.url, this.renderBcResult, this.renderP2pResult, this.successCallback, this.checkSocketClose)
            console.log('建立websocket连接')
          }
          // 第一次socket.stompClient为null，以后都是不为null，不用创建直接拨打
          this.createSingleTask(val, phone)
        } else {
          this.$message.warning('socket未连接')
          this.$store.dispatch('TimeLimit', true)
        }
      },
      // 成功回调
      successCallback () {
        console.log('websocket连接成功')
      },
      // TCP链接断开，提醒用户，退出重新登录
      checkSocketClose () {
        this.$alert('websocket断开，请点击确定重连TGP', '提示', {
          confirmButtonText: '确定',
          callback: action => {
            console.log('重新连接TGP')
            this.initWebSocket()
          }
        })
      },
      // 获取状态
      renderBcResult (data) {
        // console.log(data)
      },
      // 获取状态
      renderP2pResult (data) {
        if (data.body) {
          let data1 = JSON.parse(data.body)
          let type = data1.resonseType
          let res = data1.responseData
          if (res.status) {
            let status = res.status
            // 设置当前电话状态
            this.currentCallStatus = status
            this.currentCallData = res
          }
          if (type === 'monitor') {
            this.$store.dispatch('GetCurrentTaskId', res.taskId)
          }
          // {"resonseType":"error","responseData":"ip :172.17.16.2 serviceNum: S1003 没有注册!"}
          if (type === 'error') {
            this.$message.error(res)
          }
          // call_result
          if (type === 'call_result') {
            let data = JSON.parse(res)
            // 单呼，同时开启多个标签页，一个电话结束后，另一个标签页没发起单呼也收到了call_result状态，发送给后端的数据就不对了，所以做容错校验
            // 1、如果没发起单呼，currentUuid为null 2、如果发起单呼，currentUuid获取到，与websocket推过来的不一致
            if (this.currentUuid !== data.uuid) {
              return false
            }
            this.currentVoicePath = data.connect ? data.voicePath : '' // 当前通话录音地址
            this.currentConnect = data.connect // 是否接通
            let queryParams = {
              callProjectId: -1,
              executeId: -1,
              callRecordId: this.callRecordId,
              contactNum: this.currentPhone, // 传入当前电话，不然外地加0，后端没法处理
              caseId: data.caseId,
              callCenterCallId: data.uuid,
              hangupType: data.hangUpType,
              callTime: data.chatDuration,
              ringingTime: data.ringDuration,
              ivrTime: data.ivrDuration,
              connected: data.connect,
              unAnswerType: data.unAnswerType,
              recordPath: data.voicePath
            }
            fetchUpdateExecuteRecord2(JSON.stringify(queryParams))
              .then(response => {
                let res = response.data
                if (res.errorCode === 0) {
                }
              })
              .catch(error => {
                console.log(error)
              })
          }
        }
      },
      // 单呼限制连续点击
      singleCallLimit (val) {
        if (this.timeLimit) {
          this.$store.dispatch('TimeLimit', false)
          // this.timeLimit = false
          this.singleCall(val)
        }
        //        this.timer = setTimeout( () => {
        //          this.timeLimit = true // 防止连续点击
        //        },1000)
      },
      // 单呼
      singleCall (val) {
        if (this.isSubmitted) {
          console.log('开始创建单呼任务')
          this.isPassTheLimitTimes(val)
        } else {
          // this.timeLimit = true
          this.$store.dispatch('TimeLimit', true)
          if (val.id === this.currentCRInfo.id) {
            this.CRData = val
            this.CRProps = {dialogVisible: true}
            this.$store.dispatch('IsShowSmallBox', false)
          } else {
            //            this.CRData = this.currentCRInfo
            //            this.CRProps = {
            //              dialogVisible: true
            //            }
            //            this.$store.dispatch('IsShowSmallBox', false)
            this.$message.warning('还有通话窗口未关闭！')
          }
        }
      },
      // 判断是否超过限制次数，超过限制次数，不给予拨打
      isPassTheLimitTimes (val) {
        // let phone = base64decode(val.realPhone)
        let phone = val.realPhone
        let order = val.order // 1本人 否则其他
        fetchIsPassTheLimitTimes(this.$route.params.id, phone, order)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && !res.data) {
              this.getUuidAndCallRecordId(val, phone)
            } else if (res.errorCode === 0 && res.data) {
              this.$message.error('超过限制次数，不给予拨打')
              // this.timeLimit = true
              this.$store.dispatch('TimeLimit', true)
            }
          })
          .catch(error => {
            console.log(error)
            // this.timeLimit = true
            this.$store.dispatch('TimeLimit', true)
          })
      },
      // 单呼获取uuid及callRecordId
      getUuidAndCallRecordId (val, phone) {
        let calledName = val.name
        fetchGetSingleCallInfo(this.$route.params.id, phone, calledName)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.callRecordId = res.data.callRecordId
              this.currentUuid = res.data.uuid
              // todo 先不创建单呼任务，先初始化成功后再创建单呼任务
              // this.createSingleTask(val, phone)
              // 建立websocket连接
              this.initWebSocket(val, phone)
            } else {
              // this.timeLimit = true
              this.$store.dispatch('TimeLimit', true)
            }
          })
          .catch(error => {
            console.log(error)
            // this.timeLimit = true
            this.$store.dispatch('TimeLimit', true)
          })
      },
      // 创建单呼任务
      createSingleTask (val, phone) {
        if (!this.serviceNum) {
          this.$message.error('坐席为空，请填写完整')
          // this.timeLimit = true
          this.$store.dispatch('TimeLimit', true)
          return false
        }
        this.currentPhone = phone
        let userDTO = "{\"phone\":\"" + phone + "\",\"data\":\"\",\"uuid\":\"" + this.currentUuid +"\"}"
        let resultUrl = ''
        if (window.location.host.indexOf('localhost') > -1) {
          resultUrl = URL_SINGLE_CALL_CALL_BACK // 单呼回传地址
        } else {
          let host = window.location.host.indexOf('t') > -1 ? 'http://' : 'https://'
          resultUrl = host + window.location.host + URL_SINGLE_CALL_CALL_BACK // 单呼回传地址
        }
        fetchCreateSingleTask(JSON.stringify(userDTO), this.serviceNum, resultUrl, this.caseId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              console.log('创建单呼任务成功')
              // todo 解决上一通电话接通提交成功，当前电话网络波动，录音地址还是沿用上一次的记录，重置
              this.currentVoicePath = '' // 当前通话录音地址
              this.currentConnect = false // 当前是否接通过
              // 打开催记弹窗
              this.CRData = val
              this.CRProps = {dialogVisible: true}
              this.$store.dispatch('IsShowSmallBox', false)
              // 存储当前催记信息
              this.$store.dispatch('GetCurrentCRInfo', val)
              // 提交状态  变更为  未提交状态
              this.$store.dispatch('IsSubmitted', false)
              // this.timeLimit = true
              this.$store.dispatch('TimeLimit', true)
            } else {
              this.$message.error(res.errorMsg)
              // this.timeLimit = true
              this.$store.dispatch('TimeLimit', true)
            }
          })
          .catch(error => {
            console.log(error)
            // this.timeLimit = true
            this.$store.dispatch('TimeLimit', true)
          })
      },
      // 监听停催状态
      listenSuspendStatus (val) {
        this.suspendColl = val
        // 获取案件联系表格数据
        this.getCallTableData()
        // 更新操作记录
        this.updateStr += 1
        this.OTProps = {isUpdate: 'update' + this.updateStr}
        // 更新dom，table宽度、高度变化，canvas变化
        this.$nextTick(() => {
          this.$refs.callTable.style.width = this.$refs.callTableBox.clientWidth - 8 + 'px'
          this.callTableWidth = this.$refs.callTable.clientWidth - 8
          this.callTableHeight = this.$refs.callTable.clientHeight
          this.$refs.callTableBox.style.height = this.callTableHeight + 12 +'px'
        })
      }
    },
    watch: {
      'currentCallData' (val) {
        if (val.status === 'STATUS_ON_RING') {
          this.currentConnect = val.connect // 是否接通
        }
        if (val.status === 'STATUS_ON_CALL') {
          this.currentConnect = val.connect // 是否接通
          this.currentVoicePath = val.voicePath // 当前通话录音地址
        }
      },
      'isSubmitted' (val) {
        if (val) {
          $(window).unbind('beforeunload')
        } else {
          $(window).bind('beforeunload', function () {
            return''
          })
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .case-detail-wrapper {
    background-color: #EBF0F3;
    .length-1 {
      width: 140px;
    }

    .form-block {
      .form-block-b {
        font-size: 14px;
      }
      .el-form-item {
        margin-bottom: 0;
      }
    }
    /* fileName */
    .file-name {
      color: #2fa4e7;
      cursor: pointer;
      &:hover {
        text-decoration: underline;
        color: #428bca;
      }
    }
    /* 小按钮 */
    .small-box {
      height: 22px;
      color: #fff;
      line-height: 14px;
      text-align: center;
      font-size: 12px;
      border-radius: 2px;
      padding: 4px;
      background: #e12b31;
      cursor: pointer;
      position: fixed;
      z-index: 3;
      bottom: 0;
      right: 200px;
    }

    .monitor-layer {
      width: 300px;
      height: 60px;
      position: fixed;
      /* fullscreenLoading的z-index 10000 */
      z-index: 11111;
      bottom: 0px;
      left: 0px;
      right: 0px;
      margin-left: auto;
      margin-right: auto;
      background: #bbb;
      border-radius: 4px;
      .call-btn {
        padding: 5px 30px;
      }
      .monitor-msg {
        text-align: center;
        font-size: 14px;
      }
    }

    /*通讯录表格*/
    .call-table {
      font-size: 12px;
      color: #333;
      text-align: center;
      line-height: 20px;
      position: relative; // 为水印做的
      table, table tr th, table tr td {
        border: 1px solid #eee;
      }
      table {
        position: absolute;
        z-index: 2;
        min-height: 25px;
        line-height: 25px;
        text-align: center;
        border-collapse: collapse;
        /*padding: 2px;*/
      }
      input[type='checkbox'] {
        cursor: pointer;
      }
    }

    /*每日提醒*/
    .day-remind {
      height: 22px;
      color: #fff;
      line-height: 14px;
      text-align: center;
      font-size: 12px;
      border-radius: 2px;
      padding: 4px;
      background: #54b4eb;
      cursor: pointer;
      position: fixed;
      right: 60px;
      bottom: 0;
    }
  }
  .bg_red {
    background: rgb(181, 236, 218);
  }
</style>
