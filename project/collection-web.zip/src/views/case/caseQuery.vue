<!-- 案件查询 -->
<template>
  <div class="case-query-wrapper">
    <!-- 筛选条件 -->
    <el-form :inline="true" :model="filterForm" class="filter-form" style="overflow: hidden">
      <div>
        <el-form-item label="产品:">
          <el-form :inline="true">
            <el-form-item>
              <el-checkbox :indeterminate="productType" v-model="checkAllProductType" @change="handleCheckAllProductTypeChange">全选</el-checkbox>
            </el-form-item>
            <el-form-item>
              <el-checkbox-group v-model="productIds" @change="handleProductTypeChange">
                <el-checkbox v-for="item in productList" :label="item.id" :key="item.id">{{ item.name }}</el-checkbox>
              </el-checkbox-group>
            </el-form-item>
          </el-form>
        </el-form-item>
        <el-form-item label="逾期阶段:" v-show="showOverdueLevel">
          <el-form :inline="true">
            <el-form-item>
              <el-checkbox :indeterminate="isOverdueLevel" v-model="checkAllOverdueLevel" @change="handleCheckAllOverdueLevelChange">全选</el-checkbox>
            </el-form-item>
            <el-form-item>
              <el-checkbox-group v-model="overdues" @change="handleOverdueLevelChange">
                <el-checkbox v-for="item in overduesListFilter" :label="item.id" :key="item.id">{{ item.overdueLevelCode }}</el-checkbox>
              </el-checkbox-group>
            </el-form-item>
          </el-form>
        </el-form-item>
      </div>

      <el-form-item label="案件状态:">
        <el-form :inline="true">
          <el-form-item>
            <el-checkbox :indeterminate="isCaseStatus" v-model="checkAllCaseStatus" @change="handleCheckAllCaseStatusChange">全选</el-checkbox>
          </el-form-item>
          <el-form-item>
            <el-checkbox-group v-model="caseStatuses" @change="handleCaseStatusChange">
              <el-checkbox v-for="item in caseStatusList" :label="item.id" :key="item.id">{{ item.desc }}</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
        </el-form>
      </el-form-item>
      <el-form-item label="分案时间:">
        <!--<el-date-picker-->
          <!--v-model="assignCaseStartDate"-->
          <!--type="date"-->
          <!--size="small"-->
          <!--class="length-1"-->
          <!--:editable="false"-->
          <!--:clearable="false"-->
          <!--placeholder="选择日期">-->
        <!--</el-date-picker>-->
        <!--<span>-</span>-->
        <!--<el-date-picker-->
          <!--v-model="assignCaseEndDate"-->
          <!--type="date"-->
          <!--size="small"-->
          <!--class="length-1"-->
          <!--:editable="false"-->
          <!--:clearable="false"-->
          <!--placeholder="选择日期">-->
        <!--</el-date-picker>-->
        <el-date-picker
          size="small"
          v-model="date"
          class="length-2"
          type="daterange"
          :editable="false"
        >
        </el-date-picker>
      </el-form-item>
      <el-form-item label="逾期天数:">
        <el-input v-model="filterForm.minOverdueDays" size="small"
                  class="length-3" @keyup.native="inputLimit" @blur="blurLimit"></el-input>
        <span>-</span>
        <el-input v-model="filterForm.maxOverdueDays" size="small"
                  class="length-3" @keyup.native="inputLimit" @blur="blurLimit"></el-input>
      </el-form-item>
      <el-form-item label="停催:">
        <el-checkbox v-model="suspendColl"></el-checkbox>
      </el-form-item>
      <el-form-item label="仅搜索共债:">
        <el-radio-group v-model="filterForm.multiple">
          <el-radio :label="1">是</el-radio>
          <el-radio :label="0">否</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="欠款金额:">
        <el-input v-model="filterForm.minDebtAmount" size="small"
                  class="length-3"  @keyup.native="inputLimit" @blur="blurLimit"></el-input>
        <span>-</span>
        <el-input v-model="filterForm.maxDebtAmount" size="small"
                  class="length-3" @keyup.native="inputLimit" @blur="blurLimit"></el-input>
      </el-form-item>
      <!--还款时间-->
      <el-form-item label="还款时间:">
        <el-date-picker
          size="small"
          v-model="datePay"
          class="length-2"
          type="daterange"
          :editable="false"
        >
        </el-date-picker>
      </el-form-item>
      <div>
        <span class="define">自定义：</span>
        <el-form-item v-show="isShowGroupSelect">
          <!--请选择催收组-->
            <vue-el-select size="small" class="input-width" v-model="filterForm.groups" reserve-keyword multiple filterable placeholder="请选择催收组" @visible-change="handleGroupVisibleChange" @change="customChooseGroup">
              <el-option label="所有" value=""></el-option>
              <el-option  v-for="item in collectionGroupFilterList"
                          :key="item.id"
                          :label="item.name"
                          :value="item.id"
              >
              </el-option>
            </vue-el-select>
        </el-form-item>
        <el-form-item v-show="isShowPersonSelect">
          <!--请选择催收员-->
          <vue-el-select size="small" class="input-width" v-model="collecotorIdsList" reserve-keyword multiple filterable  placeholder="请选择催收员" @visible-change="handleCollectorVisibleChange" @change="customChooseGroupPerson">
            <el-option label="所有" value=""></el-option>
            <el-option  v-for="item in collectorTempList"
                        :key="item.id"
                        :label="item.displayName"
                        :value="item.id" >
            </el-option>
          </vue-el-select>
        </el-form-item>
        <el-form-item>
          <el-input v-model="filterForm.debtorPhone" size="small"
                    class="length-1" placeholder="客户手机号" @keyup.native="inputLimit"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="filterForm.contactPhone" size="small"
                    class="length-1" placeholder="联系人手机号" @keyup.native="inputLimit"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="filterForm.debtorName" size="small"
                    class="length-1" placeholder="客户姓名"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="filterForm.userId" size="small"
                    class="length-1" placeholder="UID" @keyup.native="inputLimit" @blur="blurLimit"></el-input>
        </el-form-item>
      </div>
      <el-form-item label="行动码:">
        <el-form :inline="true">
          <el-form-item>
            <el-checkbox :indeterminate="isActionCode" v-model="checkAllActionCode" @change="handleCheckAllActionCodeChange">全选</el-checkbox>
          </el-form-item>
          <el-form-item>
            <el-checkbox-group v-model="actionCodes" @change="handleActionCodeChange">
              <el-checkbox v-for="item in actionCodeList" :label="item.paramCode" :key="item.id">{{item.paramName}}</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
        </el-form>
      </el-form-item>
      <!--<el-form-item label="资金方类型：">-->
        <!--<el-form :inline="true">-->
          <!--<el-form-item>-->
            <!--<el-checkbox :indeterminate="isProductStatus" v-model="checkAllProductStatus" @change="handleCheckAllProductStatusChange">全选</el-checkbox>-->
          <!--</el-form-item>-->
          <!--<el-form-item>-->
            <!--<el-checkbox-group v-model="filterForm.productStatus" @change="handleProductStatusChange">-->
              <!--<el-checkbox v-for="item in productStatusList" :label="item" :key="item">{{ item }}</el-checkbox>-->
            <!--</el-checkbox-group>-->
          <!--</el-form-item>-->
        <!--</el-form>-->
      <!--</el-form-item>-->
      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn" :loading="searchLoading">搜索</el-button>
        <!--<el-button type="primary" size="small" @click="exportBtn">导出</el-button>-->
      </el-form-item>
      <el-form-item v-if="showSelectObj.isShowSendSmsBatch && isShowSendSmsBatchBtn">
        <el-button type="warning" size="small" @click="openBatchSendDialog">{{ sendSmsBatchText }}</el-button>
      </el-form-item>
      <el-form-item style="float: right;">
        <div style="display: inline-block; font-size: 12px;" v-loading="debtAndRepayLoading">
          <div style="line-height: 20px;">欠款金额汇总：{{ debtAndRepay.debtAmount }}元</div>
          <div style="line-height: 20px;">还款金额汇总：{{ debtAndRepay.repayAmount }}元</div>
        </div>
        <span>已选择 {{ multipleSelection.length }} 人</span>
        <el-button type="primary" size="small" @click="handleCall">批量外呼</el-button>
        <el-button type="primary" size="small" @click="manualAssign" v-show="showSelectObj.isAssign">分配</el-button>
        <!--<el-button type="primary" size="small" @click="recycling">回收</el-button>-->
        <!--<el-button type="primary" size="small" @click="texting">分配</el-button>-->
        <!--<el-button type="primary" size="small" @click="texting">发短信</el-button>-->
      </el-form-item>
    </el-form>

    <!--发短信-->
    <send-sms-batch :sendSmsBatchProps="sendSmsBatchProps"></send-sms-batch>

    <!--<el-form :inline="true" class="filter-form">-->
      <!--<el-form-item style="float: right;">-->
        <!--<span>已选择 {{ multipleSelection.length }} 人</span>-->
        <!--<el-button type="primary" size="small" @click="handleCall">批量外呼</el-button>-->
        <!--<el-button type="primary" size="small" @click="manualAssign">手工分案</el-button>-->
        <!--<el-button type="primary" size="small" @click="recycling">回收</el-button>-->
        <!--<el-button type="primary" size="small" @click="texting">发短信</el-button>-->
      <!--</el-form-item>-->
    <!--</el-form>-->
    <!--table开始-->
    <div class="call-table" :style="listLoading ? 'overflow: hidden' : 'overflow-y: auto'" width="100%" v-loading="listLoading">
      <table width="100%" min-height="100px" border="1" cellspacing="0" cellpadding="0">
        <thead>
        <tr>
          <th width="30px">
            <input type="checkbox" :checked="isCheckedAll" @change="handleSelectAll">
          </th>
          <th width="50px" @click="getTableData((uid ++) % 2 === 1 ? 'userId desc' : 'userId asc')">
            UID
            <i class="el-icon-caret-top" v-show="uid % 2 === 1"></i>
            <i class="el-icon-caret-bottom" v-show="uid % 2 === 0"></i>
          </th>
          <th width="90px">客户姓名</th>
          <th width="90px" @click="getTableData((collectorName ++) % 2 === 1 ? 'collectorName desc' : 'collectorName asc')">
            催收员
            <i class="el-icon-caret-top" v-show="collectorName % 2 === 1"></i>
            <i class="el-icon-caret-bottom" v-show="collectorName % 2 === 0"></i>
          </th>
          <th width="90px" @click="getTableData((latestCollectAt ++) % 2 === 1 ? 'latestCollectAt desc' : 'latestCollectAt asc')">
            上次催收时间
            <i class="el-icon-caret-top" v-show="latestCollectAt % 2 === 1"></i>
            <i class="el-icon-caret-bottom" v-show="latestCollectAt % 2 === 0"></i>
          </th>
          <!--todo v20190425隐藏-->
          <!--<th width="90px" @click="getTableData((totalCollectTimes ++) % 2 === 1 ? 'totalCollectTimes desc' : 'totalCollectTimes asc')">-->
            <!--催收员/总催收次数-->
            <!--<i class="el-icon-caret-top" v-show="totalCollectTimes % 2 === 1"></i>-->
            <!--<i class="el-icon-caret-bottom" v-show="totalCollectTimes % 2 === 0"></i>-->
          <!--</th>-->
          <th width="90px" @click="getTableData((productId ++) % 2 === 1 ? 'productId desc' : 'productId asc')">
            产品
            <i class="el-icon-caret-top" v-show="productId % 2 === 1"></i>
            <i class="el-icon-caret-bottom" v-show="productId % 2 === 0"></i>
          </th>
          <el-tooltip class="item" effect="dark" content="该案件自入催以来的天数，直至案件结清停止计算" placement="top-start">
          <th width="90px" @click="getTableData((assignOverdueDays ++) % 2 === 1 ? 'assignOverdueDays desc' : 'assignOverdueDays asc')">
            <i class="el-icon-info"></i>
            入催天数
            <i class="el-icon-caret-top" v-show="assignOverdueDays % 2 === 1"></i>
            <i class="el-icon-caret-bottom" v-show="assignOverdueDays % 2 === 0"></i>
          </th>
          </el-tooltip>
          <th width="90px" @click="getTableData((overdueLevel ++) % 2 === 1 ? 'overdueLevel desc' : 'overdueLevel asc')">
            逾期阶段
            <i class="el-icon-caret-top" v-show="overdueLevel % 2 === 1"></i>
            <i class="el-icon-caret-bottom" v-show="overdueLevel % 2 === 0"></i>
          </th>
          <th width="90px" @click="getTableData((overdueDays ++) % 2 === 1 ? 'overdueDays desc' : 'overdueDays asc')">
            逾期天数
            <i class="el-icon-caret-top" v-show="overdueDays % 2 === 1"></i>
            <i class="el-icon-caret-bottom" v-show="overdueDays % 2 === 0"></i>
          </th>
          <th width="90px" @click="getTableData((debtAmount ++) % 2 === 1 ? 'debtAmount desc' : 'debtAmount asc')">
            欠款金额
            <i class="el-icon-caret-top" v-show="debtAmount % 2 === 1"></i>
            <i class="el-icon-caret-bottom" v-show="debtAmount % 2 === 0"></i>
          </th>
          <th width="90px" @click="getTableData((repaymentAmount ++) % 2 === 1 ? 'repaymentAmount desc' : 'repaymentAmount asc')">
            已还金额
            <i class="el-icon-caret-top" v-show="repaymentAmount % 2 === 1"></i>
            <i class="el-icon-caret-bottom" v-show="repaymentAmount % 2 === 0"></i>
          </th>
          <th width="90px" @click="getTableData((repaymentDate ++) % 2 === 1 ? 'repaymentDate desc' : 'repaymentDate asc')">
            还款时间
            <i class="el-icon-caret-top" v-show="repaymentDate % 2 === 1"></i>
            <i class="el-icon-caret-bottom" v-show="repaymentDate % 2 === 0"></i>
          </th>
          <th width="90px" @click="getTableData((caseStatusDesc ++) % 2 === 1 ? 'caseStatusDesc desc' : 'caseStatusDesc asc')">
            案件状态
            <i class="el-icon-caret-top" v-show="caseStatusDesc % 2 === 1"></i>
            <i class="el-icon-caret-bottom" v-show="caseStatusDesc % 2 === 0"></i>
          </th>
          <th width="90px">行动码</th>
          <th width="90px" @click="getTableData((assignAt ++) % 2 === 1 ? 'assignAt desc' : 'assignAt asc')">
            分案时间
            <i class="el-icon-caret-top" v-show="assignAt % 2 === 1"></i>
            <i class="el-icon-caret-bottom" v-show="assignAt % 2 === 0"></i>
          </th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="(item, index) in tableData" :key="index" v-if="tableData.length !== 0" :style="{'background-color': item.rencentlyGz ? '#b5ecda' : ''}">
          <td width="30px">
            <input type="checkbox" @change="handleSelect(item, index)" :checked="item.isChecked">
          </td>
          <td>{{ item.userId }}</td>
          <td>
            <span class="imitate-a-label" v-if="item.isQueryed === 0" @click="handleDetail(item, index)">{{ item.debtorName }}</span>
            <span class="imitate-a-label" v-else style="color: red" @click="handleDetail(item, index)">{{ item.debtorName }}</span>
          </td>
          <td>{{ item.collectorName }}</td>
          <td>{{ item.latestCollectAt }}</td>
          <!--<td>-->
            <!--<span>{{ item.currCollectTimes + '(' + item.totalCollectTimes + ')'}}</span>-->
          <!--</td>-->
          <td>
            <span>{{ item.productNames }}</span>
          </td>
          <td>{{ item.assignOverdueDays }}</td>
          <td>{{ item.overdueLevel }}</td>
          <td>{{ item.overdueDays }}</td>
          <td>
            <span>{{ item.debtAmount === null ? 0 : (parseInt(item.debtAmount)/100).toFixed(2)}}</span>
          </td>
          <td>
            <span>{{ item.repaymentAmount === null ? 0 : (parseInt(item.repaymentAmount) / 100).toFixed(2) }}</span>
          </td>
          <td>{{ item.repaymentDate }}</td>
          <td>{{ item.caseStatusDesc }}</td>
          <td>{{ item.actionCodeDesc }}</td>
          <td>{{ item.assignAt }}</td>
        </tr>
        <tr v-if="tableData.length === 0" style="height:50px;">
          <td colspan="16">暂无数据</td>
        </tr>
        </tbody>
      </table>
    </div>
    <!--table结束-->
    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
    <!-- 手工分案-弹窗 -->
    <el-dialog title="手工分案" :visible.sync="dialogManualAssign" :show-close="false">
      <el-form :model="manualAssignForm" :inline="true" label-width="80px" style="position: relative">
        <!--<el-form-item label="催收员">-->
          <!--<select multiple class="length-1" id="selectCollector" name="collectors" v-model="manualAssignForm.collectorIds">-->
            <!--<option v-for="item in collectorIdList" :value="item.id" :title="item.displayName">{{item.displayName}}</option>-->
          <!--</select>-->
        <!--</el-form-item>-->
        <el-form-item>
          <!--请选择催收组-->
          <vue-el-select size="small" class="input-width" v-model="filterForm.groupsHand" reserve-keyword multiple filterable placeholder="请选择催收组" @visible-change="handleGroupVisibleChange" @change="distributionChooseGroup" v-show="isShowGroupSelect">
            <el-option label="所有" value="" ></el-option>
            <el-option  v-for="item in collectionGroupFilterList"
                        :key="item.id"
                        :label="item.name"
                        :value="item.id"
                        id="selector"
            >
            </el-option>
          </vue-el-select>
          <!--请选择催收员-->
          <vue-el-select size="small" class="input-width" v-model="manualAssignForm.collectors" reserve-keyword multiple filterable  placeholder="输入并选择催收员" @visible-change="handleCollectorVisibleChangeDis" @change="distributionChooseGroupPerson" v-show="isShowPersonSelect">
            <el-option label="所有" value=""></el-option>
            <el-option  v-for="item in collectorTempList"
                        :key="item.id"
                        :label="item.displayName"
                        :value="item.id" >
            </el-option>
          </vue-el-select>
        </el-form-item>
        <el-form-item>
          <span>共选择</span>
          <span>{{ multipleSelection.length }}</span>
          <span>个案件，</span>
          <span>共选择</span>
          <span>{{ manualAssignForm.collectors.length }}</span>
          <span>个催收员</span>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleCancel">取 消</el-button>
        <el-button type="primary" @click="handleManualAssignConfirm">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 选择短信模板-弹窗 -->
    <el-dialog title="选择短信模板" :visible.sync="dialogSms">
      <el-form :model="smsForm" label-width="80px">
        <h5>发给本人</h5>
        <el-form-item label="模板名称">
          <el-select v-model="smsForm.templateName" placeholder="请选择模板名称" style="width: 100%;">
            <el-option
              v-for="item in templateNameList"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="模板内容">
          <el-input
            type="textarea"
            :rows="2"
            :disabled="true"
            v-model="smsForm.templateContent">
          </el-input>
        </el-form-item>
        <h5>发给联系人</h5>
        <el-form-item label="模板名称">
          <el-select v-model="smsForm.templateName" placeholder="请选择模板名称" style="width: 100%;">
            <el-option
              v-for="item in templateNameList"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="模板内容">
          <el-input
            type="textarea"
            :rows="2"
            :disabled="true"
            v-model="smsForm.templateContent">
          </el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogSms = false">取 消</el-button>
        <el-button type="primary" @click="handleSmsConfirm">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 编辑项目弹窗 -->
    <!--<el-dialog title="新建项目" :visible.sync="dialogCall">-->
      <!--<el-form label-width="80px">-->
        <!--<el-form-item>-->
          <!--<span>提示：已还清的欠款的案件本人和联系人，都无法添加到项目中</span>-->
        <!--</el-form-item>-->
        <!--<el-form-item label="项目名称">-->
          <!--<el-input v-model="callForm.projectName" placeholder="请输入项目名称" class="length-1"></el-input>-->
        <!--</el-form-item>-->
        <!--<el-form-item label="项目名单">-->
          <!--<el-radio-group v-model="callForm.projectList">-->
            <!--<el-radio :label="3">本人</el-radio>-->
            <!--<el-radio :label="6">三个联系人</el-radio>-->
            <!--<el-radio :label="9">勾选人</el-radio>-->
          <!--</el-radio-group>-->
        <!--</el-form-item>-->
        <!--<el-form-item label="呼叫系数">-->
          <!--<el-input-number v-model="callForm.callCoefficient" :min="1" :max="15" class="length-1"></el-input-number>-->
          <!--<span>控制同时呼出的电话数量，范围1~15的整数</span>-->
        <!--</el-form-item>-->
      <!--</el-form>-->
      <!--<div slot="footer" class="dialog-footer">-->
        <!--<el-button @click="dialogCall = false">取 消</el-button>-->
        <!--<el-button type="primary" @click="dialogCall = false">确 定</el-button>-->
      <!--</div>-->
    <!--</el-dialog>-->

    <!--批量外呼-->
    <add-project :PMProps="PMProps"></add-project>
    <!--催收作业规则蒙层-->
    <el-dialog title="催收作业基本守则" :visible.sync="dialogMongoliaLayer" center top="1vh" :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false">
      <span>1、遵守公司各项规定及政策<br/>2、债务人还款必须通过银行入帐，严禁催收人员经手现金；<br/>3、不得以任何名义向债务人收取除应收款项以外的任何费用；<br/>4、不得采取扰乱债务人正常工作和生活的方式进行电话催收，如辱骂、侮辱债务人，恐吓、胁迫债务人及其联系人，蓄意泄漏、散布债务人财务信息等；<br/>5、不得进行不合法现场催收，如骚扰债务人生活、限制债务人人身自由、丑化债务人名誉、破坏债务人财产、扣押债务人财物等；<br/>6、不得与债务人恶意串通，姑息、纵容债务人的逾期行为，隐瞒、伪造债务人信息或还款凭证，帮助债务人逃避债务以获取利益或为关系人牟取便利；<br/>7、不得接受债务人馈赠的钱物或请吃、请喝、请玩等消费享受；<br/>8、应向客户充分说明还款逾期的责任和后果，不得做出超过职责范围的任何承诺，不得越权承诺客户免除任何应缴纳款项；<br/>9、未经批准，不得向第三方透露债务人财物信息和客户资料，或擅自将债务人资料拷贝、重复以作他用；<br/>10、必须秉持守法原则执行业务，不得与不法组织或人员合作牟利，不得从事不法行为以致损害公司权益及声誉；<br/>11、不得泄漏公司业务机密，不得破坏公司声誉；<br/>12、不得在外兼任其他企业的催收工作。</span>
      <span slot="footer" class="dialog-footer">
       <el-button type="primary" @click="handleMongoliaLayer">同 意</el-button>
      </span>
    </el-dialog>

    <!--今日提醒-->
    <!--<div class="day-remind" @click="dayRemindBtn" v-show="!isShowDayRemind">-->
      <!--<i class="el-icon-warning"></i>-->
      <!--今日{{ currentRemindList.length }}个提醒-->
    <!--</div>-->

    <!--<el-dialog title="今日提醒" :visible.sync="isShowDayRemind">-->
      <!--<el-table :data="currentRemindList" style="width: 100%">-->
        <!--<el-table-column align="center" label="联系人姓名">-->
          <!--<template slot-scope="scope">-->
            <!--<span class="imitate-a-label" @click="openCaseDetailById(scope.row)">{{ scope.row.contactName }}</span>-->
          <!--</template>-->
        <!--</el-table-column>-->
        <!--<el-table-column align="center" prop="remindTime" label="提醒时间"></el-table-column>-->
      <!--</el-table>-->
    <!--</el-dialog>-->
  </div>
</template>

<script>
  // import Vue from 'vue'
  import { mapGetters } from 'vuex'
  import { parseTime } from '../../utils/formatDate'
  import VueElSelect from '../../components/VueElSelect'
  import addProject from './components/addProject'
  import sendSmsBatch from './components/sendSmsBatch'
  import {
    fetchAllCollectorVOList,
    findAllGroupVOList
  } from '../../api/common'
  import {
    fetchCaseQueryAttributeVo,
    fetchCaseNewQueryDataList,
    fetchCountNewQueryDebtRepayAmount,
    fetchCaseAssign,
    fetchSaveCaseOperationStatus,
    fetchAgreeRule,
    fetchIsReadRule,
    fetchGetCurrentRemindData // 今日提醒
  } from '../../api/case'
  export default {
    components: {
      VueElSelect,
      addProject,
      sendSmsBatch
    },
    data () {
      return {
        isShowSendSmsBatchBtn: false, // 是否显示批量发送短信的按钮
        sendSmsBatchText: '', // 批量发送短信的按钮text
        // 欠还款金额汇总
        debtAndRepayLoading: false,
        debtAndRepay: {
          debtAmount: 0, // 总欠款金额(元)
          repayAmount: 0 // 总还款金额(元)
        },
        searchLoading: false, // 搜索限制
        date: null,
        datePay: null,
        // 筛选条件
        filterForm: {
          suspendColl: 0, // 停催 0：否，1：是
          multiple: 0, // 是否共债 0：不共债，1：共债
          caseStatuses: [], // 被选中的案件状态
          caseStatusList: [],
          startRepaymentDate: null, // 还清开始时间
          endRepaymentDate: null, // 还清结束时间
          startAssignAt: null, // 分案开始时间
          endAssignAt: null, // 分案结束时间
          minDebtAmount: null, // 欠款金额开始
          maxDebtAmount: null, // 欠款金额结束
          minOverdueDays: null, // 逾期天数开始
          maxOverdueDays: null, // 逾期天数结束
          overdues: [], // 被选中的逾期阶段
          overdueLevelList: [],
          productList: [], // 产品类型
          productIds: [],
          // productStatus: [], // 被选中的资金方类型
          // 自定义项
          debtorPhone: '', // 客户手机号
          contactPhone: '', // 联系人手机号
          debtorName: '', // 客户名
          userId: null, // uid
          actionCodes: null, // 被选中的行动码
          groups: [], //  催收组
          groupsHand: [] // 手工分案催收组
        },
        suspendColl: false, // 停催
        showOverdueLevel: false, // 逾期阶段
        collecotorIdsList: [], // 催收员
        // 催收员列表
        collectorList: [],
        collectorTempList: [], // 联动过滤后下拉列表
        collectorFilterList: [], // 输入过滤后下拉列表
        collectorLoading: false,
        // 催收组列表
        collectionGroupList: [],
        collectionGroupFilterList: [], // 过滤后下拉列表
        collectionAll: [], // 所有催收组的id组成的数组
        collectionAllPerson: [], // 所有催收员的id组成的数组
        // 案件状态-复选框
        checkAllCaseStatus: false,
        isCaseStatus: false,
        caseStatusList: [], // 案件状态
        caseStatuses: [], // 暂存案件状态数组
        // 逾期阶段-复选框
        checkAllOverdueLevel: false,
        isOverdueLevel: false,
        overdues: [],
        overduesList: [], // 逾期阶段
        overduesListFilter: [],
        // 产品类型复选框
        productType: false,
        checkAllProductType: false,
        productList: [], // 产品类型
        productMap: {}, // 产品类型map
        productIds: [],
        // 资金方-复选框
        checkAllProductStatus: false,
        isProductStatus: false,
        productStatusList: [], // 资金方类型
        callResultsList: [], // 电话结果列表
        // 行动码
        checkAllActionCode: false,
        isActionCode: false,
        actionCodeList: [], // 行动码列表
        actionCodes: [],
        // 表格高度
        tableHeight: 600,
        listLoading: false,
        // 表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 20, 50, 100],
        multipleSelection: [], // 已选择人数
        // 弹窗-手工分案
        dialogManualAssign: false,
        manualAssignForm: {
          collectors: [], // 选中的催收员
          caseIds: []
        },
        collectorIdList: [], // 所有催收员列表
        // 弹窗-选择的短信模板
        dialogSms: false,
        smsForm: {
          templateName: '', // 模板名称
          templateContent: '' // 模板内容
        },
        templateNameList: [], // 所有模板名称
        // 批量外呼
        PMProps: {},
        // 弹窗-批量外呼
        dialogCall: false,
        callForm: {
          projectName: '', // 项目名称
          projectList: 3, // 项目名单
          callCoefficient: '1' // 呼叫系数
        },
        dialogMongoliaLayer: false, // 页面催收作业遮罩蒙层,
        isShowGroupSelect: true, // 是否展示催收组选项
        isShowPersonSelect: true, // 是否展示催收员选项
        // collectionTip: COLLECTION_TIP
        // 今日提醒
        isShowDayRemind: false,
        currentRemindList: [],
        // timeFun: null,
        uid: 0,
        collectorName: 0,
        latestCollectAt: 0,
        totalCollectTimes: 0,
        productId: 0,
        assignOverdueDays: 0,
        overdueLevel: 0,
        overdueDays: 0,
        debtAmount: 0,
        repaymentAmount: 0,
        repaymentDate: 0,
        caseStatusDesc: 0,
        assignAt: 0,
        isCheckedAll: false,
        // 批量发短信
        sendSmsBatchProps: {}
      }
    },
    computed: {
      ...mapGetters([
        'showSelectObj',
        'userId'
      ])
    },
    mounted () {
      this.getIsReadRule() // 获取该用户是否已经阅读催收作业准则信息
      // 表格高度
      this.handleResize()
      // 获取案件池列表
      // this.getTableData()
      this.caseStatuses = [11] // 默认选中待催收
      this.getCaseQueryAttributeVo() // 查询页需要属性信息
      window.addEventListener('resize', this.handleResize)

      // 每日提醒 3mins调一次
      // this.getCurrentRemindData()
      /* let _this = this
      _this.timeFun = setInterval(function () {
        _this.getCurrentRemindData()
      }, 180000) */
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
      // clearInterval(this.timeFun)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
      // clearInterval(this.timeFun)
    },
    methods: {
      // 单选
      handleSelect (item, index) {
        this.tableData[index].isChecked = !this.tableData[index].isChecked
        // 计算总的勾选项
        let arr = []
        this.tableData.map(item => {
          if (item.isChecked) {
            arr.push(item)
          }
        })
        this.multipleSelection = arr
        // 判断是否全部勾选
        this.isCheckedAll = this.tableData.length === arr.length
      },
      // 全选
      handleSelectAll () {
        // 切换是否勾选
        this.isCheckedAll = !this.isCheckedAll
        if (this.isCheckedAll) {
          // 计算勾选数
          this.multipleSelection = this.tableData
          this.tableData.map(item => {
            item.isChecked = true
            return item
          })
        } else {
          // 计算勾选数
          this.multipleSelection = []
          this.tableData.map(item => {
            item.isChecked = false
            return item
          })
        }
      },
      // 每日提醒 3mins调一次
      getCurrentRemindData () {
        fetchGetCurrentRemindData()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.currentRemindList = res.data.map(item => {
                let date = parseTime(new Date(), 'YYYY-MM-DD') + ' ' + item.remindTime
                let time = new Date(date).getTime()
                if (time >= new Date().getTime() - 5 * 60 * 1000 && time <= new Date().getTime()) {
                  this.$notify.info({
                    title: '消息',
                    message: '联系人：' + item.contactName + '，提醒时间：' + item.remindTime
                  })
                }
                return item
              })
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 每日提醒
      dayRemindBtn () {
        this.isShowDayRemind = true
      },
      // 跳转到案件详情
      openCaseDetailById (val) {
        window.open('#/case-detail/' + val.caseId)
      },
      // 获取是否阅读催收作业规则
      getIsReadRule () {
        fetchIsReadRule()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              if (res.data === 0) {
                this.dialogMongoliaLayer = true
              }
              this.getAllGroupList().then(() => {
                if (this.collectionGroupList.length <= 1) { // 如果催收组的长度为1的话，催收组输入框就不展示
                  this.isShowGroupSelect = false
                }
              })
              this.getAllCollectorList().then(() => {
                if (this.collectorList.length <= 1) { // 如果催收员的长度为1的话，催收员输入框就不展示
                  this.isShowPersonSelect = false
                }
                if (this.filterForm.groups.length === 0 && this.collectorList.length > 1) { // 如果催收员的人数大于1人就循环遍历并且选中默认催收组，默认勾选当前催收员
                  let arr = JSON.parse(JSON.stringify(this.collectorList))
                  arr.forEach((item, index) => {
                    if (item.id === this.userId) {
                      this.collecotorIdsList.push(this.userId)
                    }
                  })
                  this.collectorTempList = this.collecotorIdsList
                }
              })
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 点击催收准则信息的统一按钮，获取是否同意催收作业规则。
      handleMongoliaLayer () {
        fetchAgreeRule()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && !res.errorMsg) {
              this.dialogMongoliaLayer = false // 点击同意催收准则
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 操作过的催收员名字变红
      handleDetail (value, index) {
        fetchSaveCaseOperationStatus(value.id, value.collectorId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              // this.getTableData()
              if (value.collectorId === this.userId) {
                let newValue = this.tableData[index]
                newValue.isQueryed = 1
                this.$set(this.tableData, index, newValue)
              }
              // this.tableData[index].isQueryed = 1
            }
          })
          .catch(error => {
            console.log(error)
          })
        // 跳转到案件详情页
        window.open('#/case-detail/' + value.id)
      },
      handleResize (event) {
        this.$nextTick(() => {
          let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          let h = document.documentElement.clientHeight
          if (formHeight >= 90) {
            this.tableHeight = h - 315
          } else if (formHeight >= 45) {
            this.tableHeight = h - 100
          }
        })
      },
      // 输入限制
      inputLimit (value) {
        this.filterForm.userId = this.filterForm.userId === '' || this.filterForm.userId === null ? null : this.filterForm.userId.replace(/\D/g, '')
        this.filterForm.minOverdueDays = this.filterForm.minOverdueDays === '' || this.filterForm.minOverdueDays === null ? null : this.filterForm.minOverdueDays.replace(/\D/g, '')
        this.filterForm.maxOverdueDays = this.filterForm.maxOverdueDays === '' || this.filterForm.maxOverdueDays === null ? null : this.filterForm.maxOverdueDays.replace(/\D/g, '')
        this.filterForm.debtorPhone = this.filterForm.debtorPhone === '' || this.filterForm.debtorPhone === null ? null : this.filterForm.debtorPhone.replace(/\D/g, '')
        this.filterForm.contactPhone = this.filterForm.contactPhone === '' || this.filterForm.contactPhone === null ? null : this.filterForm.contactPhone.replace(/\D/g, '')
        this.filterForm.minDebtAmount = this.filterForm.minDebtAmount === '' || this.filterForm.minDebtAmount === null ? null : this.filterForm.minDebtAmount.replace(/\D/g, '')
        this.filterForm.maxDebtAmount = this.filterForm.maxDebtAmount === '' || this.filterForm.maxDebtAmount === null ? null : this.filterForm.maxDebtAmount.replace(/\D/g, '')
      },
      // 失焦事件
      blurLimit () {
        if (isNaN(this.filterForm.minOverdueDays)) { this.filterForm.minOverdueDays = null }
        if (isNaN(this.filterForm.maxOverdueDays)) { this.filterForm.maxOverdueDays = null }
        if (isNaN(this.filterForm.minDebtAmount)) { this.filterForm.minDebtAmount = null }
        if (isNaN(this.filterForm.maxDebtAmount)) { this.filterForm.maxDebtAmount = null }
        if (isNaN(this.filterForm.userId)) { this.filterForm.userId = null }
      },
      // 查询页需要属性信息
      getCaseQueryAttributeVo () {
        fetchCaseQueryAttributeVo()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.actionCodeList = res.data.actionCodeList
              this.caseStatusList = res.data.caseStatuses
              this.productList = res.data.caseProductList.map(item => {
                this.productMap[item.id] = item
                return item
              })
              this.overduesList = res.data.overDueLevels
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 催收组 下拉框出现/隐藏时触发
      handleGroupVisibleChange (visible) {
        if (visible) {
          this.getAllGroupList().then(() => {
            this.collectionGroupFilterList = JSON.parse(JSON.stringify(this.collectionGroupList))
            // 记录所有催收组成员的id
            this.collectionAll = []
            this.collectionGroupFilterList.forEach((item, index) => {
              this.collectionAll.push(item.id)
            })
          })
        }
      },
      // 催收员 下拉框出现/隐藏时触发
      handleCollectorVisibleChange (visible) {
        if (visible) {
          this.getAllCollectorList().then(() => {
            this.collectionAllPerson = [] // 储存所有所有催收员的id
            // 然后过滤数据 mechanismId groupId
            if (this.filterForm.groups.length === 0) {
              this.collectorTempList = JSON.parse(JSON.stringify(this.collectorList))
            } else {
              this.collectorTempList = this.collectorList.filter(item => {
                // 机构、组下拉框
                if (this.filterForm.groups.length > 0) { // 组选了 返回组下面的
                  return this.filterForm.groups.join(',').indexOf(item.groupId) >= 0
                } else {
                  return false
                }
              })
            }
            // 自定义-存储过滤后的催收员列表Id
            this.collectorTempList.forEach((item, index) => {
              this.collectionAllPerson.push(item.id)
            })
          })
        }
      },
      // 手工分案催收员 下拉框出现/隐藏时触发
      handleCollectorVisibleChangeDis (visible) {
        if (visible) {
          this.getAllCollectorList().then(() => {
            this.collectionAllPerson = []
            // 然后过滤数据 mechanismId groupId
            if (this.filterForm.groupsHand.length === 0) {
              this.collectorTempList = JSON.parse(JSON.stringify(this.collectorList))
            } else {
              this.collectorTempList = this.collectorList.filter(item => {
                // 机构、组下拉框
                if (this.filterForm.groupsHand.length > 0) { // 组选了 返回组下面的
                  return this.filterForm.groupsHand.join(',').indexOf(item.groupId) >= 0
                } else {
                  return false
                }
              })
            }
            // 手工分案——存储过滤后的催收员列表Id
            this.collectorTempList.forEach((item, index) => {
              this.collectionAllPerson.push(item.id)
            })
          })
        }
      },
      // 获取催收组列表
      getAllGroupList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionGroupList && this.collectionGroupList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionGroupList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionGroupList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              findAllGroupVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionGroupList = res.data
                    // 存入本地
                    // window.localStorage.setItem('Collection-CollectionGroupList', JSON.stringify(this.collectionGroupList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取催收员列表
      getAllCollectorList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectorList && this.collectorList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionCollectorList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectorList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchAllCollectorVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectorList = res.data
                    // let _this = this
                    // 存入本地
                    // window.localStorage.setItem('Collection-CollectionCollectorList', JSON.stringify(this.collectorList))
                    // 中文转拼音首字母
                    //                    setTimeout(() => {
                    //                      _this.handleChineseToPhoneticInitial()
                    //                    }, 100)
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 根据输入过滤催收员列表
      filterCollector (query) {
        console.time('filterCollector')
        if (query !== '') {
          this.testinput = query
          this.collectorLoading = true
          this.collectorFilterList = []
          if (this.collectorTempList && this.collectorTempList.length > 0) {
            for (let i = 0, len = this.collectorTempList.length; i < len; i++) {
              if (this.collectorTempList[i].displayName.trim().indexOf(query.trim()) > -1 ||
                (this.collectorTempList[i].phoneticInitial && this.collectorTempList[i].phoneticInitial.indexOf(query.trim().toUpperCase()) > -1)) {
                this.collectorFilterList.push(this.collectorList[i])
              }
            }
          }
          this.collectorLoading = false
        } else {
          this.collectorFilterList = []
        }
        console.timeEnd('filterCollector')
      },
      // 案件状态-复选框
      handleCheckAllCaseStatusChange (val) {
        let arr = []
        this.caseStatusList.map(item => {
          arr.push(item.id)
          return item
        })
        this.caseStatuses = val ? arr : []
        this.isCaseStatus = false
      },
      handleCaseStatusChange (value) {
        let checkedCount = value.length
        this.checkAllCaseStatus = checkedCount === this.caseStatusList.length
        this.isCaseStatus = checkedCount > 0 && checkedCount < this.caseStatusList.length
      },
      // 逾期阶段-复选框
      handleCheckAllOverdueLevelChange (val) {
        let arr = []
        this.overduesList.map(item => {
          arr.push(item.id)
          return item
        })
        this.overdues = val ? arr : []
        this.isOverdueLevel = false
      },
      handleOverdueLevelChange (value) {
        let checkedCount = value.length
        this.checkAllOverdueLevel = checkedCount === this.overduesList.length
        this.isOverdueLevel = checkedCount > 0 && checkedCount < this.overduesList.length
      },
      // 产品类型-复选框
      handleCheckAllProductTypeChange (val) {
        this.overduesListFilter = [] // 先清空预期阶段框
        let arr = []
        this.productList.map(item => {
          arr.push(item.id)
          return item
        })
        this.showOverdueLevel = false
        this.productIds = val ? arr : []
        this.productType = false
        if (this.productIds.length === 1) {
          this.showOverdueLevel = true
          this.overduesList.forEach((item, index) => {
            if (item.productId === this.productIds[0].id) {
              this.overduesListFilter.push(item)
            }
          })
        }
      },
      handleProductTypeChange (value) {
        this.overduesListFilter = [] // 先清空预期阶段框
        this.showOverdueLevel = false
        let checkedCount = value.length
        this.checkAllProductType = checkedCount === this.productList.length
        this.productType = checkedCount > 0 && checkedCount < this.productList.length
        if (this.productIds.length === 1) {
          this.showOverdueLevel = true
          this.overduesList.forEach((item, index) => { // 相应的产品展示相应的逾期阶段
            if (item.productId === this.productIds[0]) {
              this.overduesListFilter.push(item)
            }
          })
        }
      },
      // 资金方-复选框
      handleCheckAllProductStatusChange (val) {
        this.filterForm.productStatus = val ? this.productStatusList : []
        this.isProductStatus = false
      },
      handleProductStatusChange (value) {
        let checkedCount = value.length
        this.checkAllProductStatus = checkedCount === this.productStatusList.length
        this.isProductStatus = checkedCount > 0 && checkedCount < this.productStatusList.length
      },
      // 行动码-复选框
      handleCheckAllActionCodeChange (val) {
        let arr = []
        this.actionCodeList.map(item => {
          arr.push(item.paramCode)
          return item
        })
        this.actionCodes = val ? arr : []
        this.isActionCode = false
      },
      handleActionCodeChange (value) {
        let checkedCount = value.length
        this.checkAllActionCode = checkedCount === this.actionCodeList.length
        this.isActionCode = checkedCount > 0 && checkedCount < this.actionCodeList.length
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 参数
      queryForm () {
        if (!this.showOverdueLevel) { // 如果逾期阶段未显示，则将逾期阶段置空
          this.overdues = []
          this.isOverdueLevel = false
        }
        this.filterForm.collectors = (this.collecotorIdsList.length === 0 ? null : this.collecotorIdsList.join(','))
        this.filterForm.collectorList = (this.collecotorIdsList.length === 0 ? null : this.collecotorIdsList)
        if (this.collecotorIdsList.length === 0 && this.filterForm.groups.length > 0) { // 如果只选择了催收组，则将该催收组里所有的催收员传给后端
          this.filterForm.collectorList = []
          this.collectorTempList.forEach((item, index) => {
            this.filterForm.collectorList.push(item.id)
          })
          this.filterForm.collectors = this.filterForm.collectorList.join(',')
        }
        this.filterForm.currCollectorId = this.userId
        this.filterForm.productIds = (this.productIds.length === 0 ? null : this.productIds.join(','))
        this.filterForm.productList = (this.productIds.length === 0 ? null : this.productIds)
        this.filterForm.startAssignAt = this.date === null ? null : parseTime(this.date[0], 'YYYY-MM-DD')
        this.filterForm.endAssignAt = this.date === null ? null : parseTime(this.date[1], 'YYYY-MM-DD')
        this.filterForm.overdues = (this.overdues.length === 0 ? null : this.overdues.join(','))
        this.filterForm.overdueLevelList = (this.overdues.length === 0 ? null : this.overdues)
        this.filterForm.caseStatusList = this.caseStatuses.length === 0 ? null : this.caseStatuses
        this.filterForm.caseStatuses = this.caseStatuses.length === 0 ? null : this.caseStatuses.join(',')
        this.filterForm.actionCodes = this.actionCodes.length === 0 ? null : this.actionCodes
        this.filterForm.startRepaymentDate = this.datePay === null ? null : parseTime(this.datePay[0], 'YYYY-MM-DD')
        this.filterForm.endRepaymentDate = this.datePay === null ? null : parseTime(this.datePay[1], 'YYYY-MM-DD')
        this.filterForm.suspendColl = this.suspendColl ? 1 : 0
      },
      // 获取案件池数据
      getTableData (order) {
        this.listLoading = true
        this.filterForm.order = order
        this.queryForm()
        fetchCaseNewQueryDataList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.isCheckedAll = false
              this.multipleSelection = [] // 清空已选择人数
              this.tableData = res.data.content.map((item, index) => {
                item.isChecked = false
                return item
              })
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
            this.searchLoading = false
          })
          .catch(error => {
            console.log(error)
            this.searchLoading = false
            this.listLoading = false
          })
      },
      // 搜索
      searchBtn () {
        // 点击搜索按钮后，是否显示批量发送短信的按钮
        if (this.productIds.length === 1) {
          this.isShowSendSmsBatchBtn = true
          this.sendSmsBatchText = `批量发送${this.productMap[this.productIds].name}短信`
        } else {
          this.isShowSendSmsBatchBtn = false
        }
        this.searchLoading = true
        this.getTableData()
        this.getDebtAndRepay()
      },
      // 欠还款金额汇总
      async getDebtAndRepay () {
        this.debtAndRepayLoading = true
        this.queryForm()
        try {
          const response = await fetchCountNewQueryDebtRepayAmount(JSON.stringify(this.filterForm), new Date().getTime())
          const res = response.data
          if (res.errorCode === 0 && res.data) {
            this.debtAndRepay = res.data
          } else {
            this.debtAndRepay = {
              debtAmount: 0, // 总欠款金额(元)
              repayAmount: 0 // 总还款金额(元)
            }
          }
          this.debtAndRepayLoading = false
        } catch (e) {
          console.log(e)
          this.debtAndRepayLoading = false
        }
      },
      // 导出按钮
      exportBtn () {
        console.log('.....')
      },
      // 勾选数据表
      handleSelectionChange (val) {
        this.multipleSelection = val
      },
      // 批量外呼
      handleCall () {
        if (this.multipleSelection.length) {
          let arr = []
          this.multipleSelection.map(item => {
            arr.push(item.id)
            return item
          })
          this.PMProps = {
            dialogVisible: true,
            caseId: arr.join(',')
          }
        } else {
          this.$message({
            message: '没有数据被选中',
            type: 'warning'
          })
        }
      },
      // 手工分案
      manualAssign () {
        if (this.multipleSelection.length) {
          console.log('打开')
          this.dialogManualAssign = true
        } else {
          this.$message({
            message: '没有数据被选中',
            type: 'warning'
          })
        }
      },
      // 回收
      recycling () {
        let len = this.multipleSelection.length
        if (len) {
          this.$confirm('确定要回收选中的' + len + '条数据吗?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.$message({
              type: 'success',
              message: '操作成功!'
            })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '已取消操作'
            })
          })
        } else {
          this.$message({
            message: '没有数据被选中',
            type: 'warning'
          })
        }
      },
      // 发短信
      texting () {
        if (this.multipleSelection.length) {
          console.log('打开')
          this.dialogSms = true
        } else {
          this.$message({
            message: '没有数据被选中',
            type: 'warning'
          })
        }
      },
      // 取消手工分案
      handleCancel () {
        this.dialogManualAssign = false
        this.filterForm.groupsHand = []
        this.manualAssignForm.collectors = []
      },
      // 确定手工分案
      handleManualAssignConfirm () {
        //        if (this.manualAssignForm.collectors.length === 0) {
        //          this.$message.error('请选择催收员')
        //          return false
        //        }
        if (this.manualAssignForm.collectors.length === 0 && this.filterForm.groupsHand.length > 0) {
          this.manualAssignForm.collectors = []
          this.collectorTempList.forEach((item, index) => {
            this.manualAssignForm.collectors.push(item.id)
          })
        }
        this.multipleSelection.forEach((item, index) => {
          this.manualAssignForm.caseIds.push(item.id)
        })
        fetchCaseAssign(JSON.stringify(this.manualAssignForm.caseIds), JSON.stringify(this.manualAssignForm.collectors))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success(res.data.errorMsg)
              this.filterForm.groupsHand = [] // 清空手工分案的催收组数据
              this.manualAssignForm.collectors = [] // 清空手工分案的催收员数据
              this.manualAssignForm.caseIds = [] // 清空手工分案的催收员数据
              this.getTableData()
            }
          })
          .catch(error => {
            console.log(error)
            this.manualAssignForm.caseIds = []
          })
        this.dialogManualAssign = false
      },
      // 确定-选择短信模板
      handleSmsConfirm () {
        this.dialogSms = false
      },
      //  手工分案-选择所有催收组
      distributionChooseGroup () {
        if (this.filterForm.groupsHand.length > 0) {
          this.filterForm.groupsHand.forEach((item, index) => {
            if (item === '') {
              this.filterForm.groupsHand = this.collectionAll
            }
          })
        }
        this.handleCollectorVisibleChangeDis(true) // 手工分案-催收组下拉出现即过滤出催收员
      },
      // 手工分案-选择所有催收员
      distributionChooseGroupPerson () {
        if (this.manualAssignForm.collectors.length > 0) {
          this.manualAssignForm.collectors.forEach((item, index) => {
            if (item === '') {
              this.manualAssignForm.collectors = this.collectionAllPerson
            }
          })
        }
      },
      // 自定义-选择所有催收组
      customChooseGroup () {
        if (this.filterForm.groups.length > 0) {
          this.filterForm.groups.forEach((item, index) => {
            if (item === '') {
              this.filterForm.groups = this.collectionAll
            }
          })
        }
        this.handleCollectorVisibleChange(true) //  自定义-催收组下拉出现即过滤出催收员
      },
      // 自定义-选择所有催收员
      customChooseGroupPerson () {
        if (this.collecotorIdsList.length > 0) {
          this.collecotorIdsList.forEach((item, index) => {
            if (item === '') {
              this.collecotorIdsList = this.collectionAllPerson
            }
          })
        }
      },
      // 打开批量发送短信弹窗
      openBatchSendDialog () {
        if (this.multipleSelection.length) {
          let caseIds = []
          this.multipleSelection.map(item => {
            caseIds.push(item.id)
            return item
          })
          this.sendSmsBatchProps = {
            dialogVisible: true,
            caseIds: caseIds,
            productId: this.productIds[0]
          }
        } else {
          this.$message({
            message: '请勾选要发送的案件',
            type: 'warning'
          })
        }
        // let caseIds =
        // this.sendSmsProps = {
        //   dialogVisible: true,
        //   caseIds: caseIds
        // }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .case-query-wrapper {

    .filter-form {
      .el-form-item {
        margin-bottom: 0;
      }
      // 多选框
      .el-checkbox+.el-checkbox {
        margin-left: 14px;
      }
      /deep/ .el-checkbox__label {
        padding-left: 4px;
      }
      /* 单选框 */
      /deep/ .el-radio+.el-radio {
        margin-left: 14px;
      }
      /deep/ .el-radio__label {
        padding-left: 4px;
      }
    }
    .length-1 {
      width: 135px;
    }
    .length-2 {
      width: 240px;
    }
    .length-3 {
      width: 100px;
    }

    /*每日提醒*/
    .day-remind {
      height: 22px;
      color: #fff;
      line-height: 14px;
      text-align: center;
      font-size: 12px;
      border-radius: 2px;
      padding: 4px;
      background: #54b4eb;
      cursor: pointer;
      position: fixed;
      right: 60px;
      bottom: 0;
    }
  }
  .input-width {
    width: 200px;
  }
  .define {
    font-size: 14px;
    font-weight: bolder;
    line-height: 35px;
  }
  /*通讯录表格*/
  .call-table {
    font-size: 12px;
    color: #333;
    text-align: center;
    line-height: 20px;
    /*max-height: 570px;*/
    border: 1px #eee solid;
    table, table tr th, table tr td {
      border: 1px solid #eee;
    }
    table {
      min-height: 25px;
      line-height: 25px;
      text-align: center;
      border-collapse: collapse;
      padding: 2px;
    }
    input[type='checkbox'] {
      cursor: pointer;
    }
  }
</style>
