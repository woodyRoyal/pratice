<!-- 分案上限设置 -->
<template>
  <div class="upper-limit-wrapper">

    <!-- 筛选条件开始 -->
    <el-form :inline="true" :model="filterForm" class="filter-form">

      <el-form-item>
        <vue-el-select v-model="filterForm.overdueLevel" multiple filterable placeholder="请选择阶段" size="small"
                       class="length-2">
          <el-option
            v-for="item in groupList"
            :key="item.id"
            :label="item.displayName"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>
      <el-form-item>
        <vue-el-select v-model="filterForm.nameIdList" multiple filterable remote placeholder="请选择用户名" size="small"
                       class="length-2" @visible-change="handleCollectorVisibleChange" :remote-method="filterCollector"
                       :loading="collectorLoading">
          <el-option
            v-for="item in usernameFilterList"
            :key="item.id"
            :label="item.username"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>
      <el-form-item>
        <vue-el-select v-model="filterForm.displayIdList" multiple filterable remote placeholder="请选择中文名" size="small"
                       class="length-2" @visible-change="handleCollectorVisibleChange" :remote-method="filterCollector"
                       :loading="collectorLoading">
          <el-option
            v-for="item in displayNameFilterList"
            :key="item.id"
            :label="item.displayName"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn" :loading="searchLoading">搜索</el-button>
        <el-button type="success" size="small" @click="exportBtn">导出</el-button>
        <el-button type="success" size="small" @click="exportBatchBtn">批量操作</el-button>
      </el-form-item>
    </el-form>
    <!-- 筛选条件结束 -->

    <!-- 分案上限数据开始-->
    <el-table :data="tableData" v-loading="listLoading" border stripe style="width: 100%" :max-height="tableHeight"
              ref="multipleTable" @selection-change="handleSelectionChange">
      <el-table-column align="center" type="selection" width="55"></el-table-column>
      <el-table-column align="center" prop="username" label="用户名" min-width="60"></el-table-column>
      <el-table-column align="center" prop="displayName" label="中文名" min-width="60"></el-table-column>
      <el-table-column align="center" label="阶段" min-width="60">
        <template slot-scope="scope">
          <span>{{ overdueLevelMap[scope.row.overdueLevel] }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="日上限" min-width="60">
        <template slot-scope="scope">
          <el-input v-model="scope.row.dayLimit1" size="mini" :class="scope.row.isActiveDay ? 'active-class' : ''"></el-input>
        </template>
      </el-table-column>
      <el-table-column align="center" label="月上限" min-width="60">
        <template slot-scope="scope">
          <el-input v-model="scope.row.monthLimit1" size="mini" :class="scope.row.isActiveMonth ? 'active-class' : ''"></el-input>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="todayNum" label="今日分案数" min-width="60">
        <template slot-scope="scope">
          <span>{{ scope.row.todayNum || 0 }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="todayMoneyString" label="当日分案金额（元）" min-width="70"></el-table-column>
      <el-table-column align="center" prop="monthNum" label="当月分案数" min-width="60">
        <template slot-scope="scope">
          <span>{{ scope.row.monthNum || 0 }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="monthMoneyString" label="当月分案金额（元）" min-width="70"></el-table-column>
      <el-table-column align="center" label="操作" min-width="100">
        <template slot-scope="scope">
          <el-button type="primary" size="mini" @click="editUpperLimit(scope.row)">修改</el-button>
          <el-button type="danger" size="mini" @click="deleteUpperLimit(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分案上限数据结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

    <!-- 批量操作 -->
    <el-dialog title="批量操作" :visible.sync="dialogFormVisible" @close="handleCloseDialog">
      <el-form :model="batchForm" :rules="rules" ref="ruleForm" label-width="80px">
        <el-form-item>
          <i class="el-icon-information"></i>
          已选择{{ multipleSelection.length }}项数据，选中的今日分案数最大值为{{ todayNumMax }}，选中的当月分案数最大值为{{ monthNumMax }}
        </el-form-item>
        <el-form-item label="日上限：" prop="dayLimit">
          <el-input v-model="batchForm.dayLimit" :placeholder="'请输入大于等于' + todayNumMax + '的整数'"></el-input>
        </el-form-item>
        <el-form-item label="月上限：" prop="monthLimit">
          <el-input v-model="batchForm.monthLimit" :placeholder="'请输入大于等于' + monthNumMax + '的整数'"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleCancelBatch">取 消</el-button>
        <el-button type="primary" @click="handleSaveBatch">保 存</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import VueElSelect from '../../components/VueElSelect'
  import {
    fetchGetAssignLimitList, // 获取 表格数据
    URL_EXPORT_ASSIGN_LIMIT_LIST, // 导出
    fetchUpdateLimitList, // 修改上限
    // fetchGetCaseLimitParams, // 获取用户名、中文名列表
    fetchCleanLimitList, // 删除
    fetchAllCollectorList
  } from '../../api/case'
  import { parseTime } from '../../utils/formatDate'
  import { CONST_OVERDUE_LEVEL_MAP } from './caseConstant'

  export default {
    components: {
      VueElSelect
    },
    data () {
      let validateDayLimit = (rule, value, callback) => {
        if (!value) {
          callback(new Error('请输入日上限'))
        } else {
          let reg = /^(0|[1-9]\d*)$/
          if (!reg.test(value)) {
            callback(new Error('请输入非负整数'))
          } else if (value < this.todayNumMax) {
            callback(new Error('请输入大于等于' + this.todayNumMax + '的整数'))
          }
          callback()
        }
      }
      let validateMonthLimit = (rule, value, callback) => {
        if (!value) {
          callback(new Error('请输入月下限'))
        } else {
          let reg = /^(0|[1-9]\d*)$/
          if (!reg.test(value)) {
            callback(new Error('请输入非负整数'))
          } else if (value < this.monthNumMax) {
            callback(new Error('请输入大于等于' + this.monthNumMax + '的整数'))
          }
          callback()
        }
      }
      return {
        searchLoading: false, // 搜索loading条
        // 初始状态
        statusFlag: true,
        // 筛选条件
        filterForm: {
          nameIdList: [], // 用户名
          displayIdList: [], // 中文名
          overdueLevel: [] // 所在组别
        },
        usernameList: [], // 用户名列表
        nameList: [], // 中文名列表
        // 催收员列表
        collectorList: [],
        usernameFilterList: [], // 过滤后用户名下拉列表
        displayNameFilterList: [], // 过滤后中文名下拉列表
        // collectorFilterList: [], // 过滤后下拉列表
        collectorLoading: false,
        groupList: [
          {id: 1, displayName: 'M1'},
          {id: 2, displayName: 'M2'},
          {id: 3, displayName: 'M3'},
          {id: 4, displayName: 'M4'},
          {id: 5, displayName: 'M5'},
          {id: 6, displayName: 'M6'},
          {id: 7, displayName: 'M7+'}
        ], // 所在组别列表
        // 表格
        tableHeight: 600, // 表格高度
        listLoading: false, // 加载
        tableData: [], // 表格数据
        // 分页
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 25, 50, 100, 500, 1000],
        multipleSelection: [], // 已选择人数
        // 弹窗
        dialogFormVisible: false,
        todayNumMax: null, // 最大 今日分案数
        monthNumMax: null, // 最大 当月分案数
        batchForm: {
          dayLimit: null,
          monthLimit: null
        },
        rules: {
          dayLimit: [
            { validator: validateDayLimit, trigger: 'blur' }
          ],
          monthLimit: [
            { validator: validateMonthLimit, trigger: 'blur' }
          ]
        },
        overdueLevelMap: CONST_OVERDUE_LEVEL_MAP // 逾期阶段字符串映射
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
      // 获取表格数据
      // this.getTableData()
      // 获取用户名、中文名、组别等列表
      // this.getFilterList()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let h = document.documentElement.clientHeight
          this.tableHeight = h - 140
        })
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 获取用户名、中文名等列表
      //      getFilterList () {
      //        if (this.statusFlag) {
      //          this.getFile()
      //        }
      //      },
      // 用户列表请求
      //      getFile () {
      //        fetchGetCaseLimitParams()
      //          .then(response => {
      //            let res = response.data
      //            if (res.errorCode === 0 && res.data) {
      //              this.usernameList = this.nameList = res.data
      //              this.statusFlag = false
      //            }
      //          })
      //          .catch(error => {
      //            console.log(error)
      //          })
      //      },
      // 催收员 下拉框出现/隐藏时触发
      handleCollectorVisibleChange (visible) {
        if (visible) {
          this.getAllCollectorList()
        }
      },
      // 获取催收员列表
      getAllCollectorList () {
        if (this.collectorList && this.collectorList.length > 0) {
          return false
        }
        const cacheCollectorList = window.localStorage.getItem('Collection-CollectorList')
        if (cacheCollectorList && JSON.parse(cacheCollectorList) && JSON.parse(cacheCollectorList).length > 0) {
          this.collectorList = JSON.parse(cacheCollectorList) // 催收员
          return false
        }
        fetchAllCollectorList()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.collectorList = res.data
              // 存入本地
              window.localStorage.setItem('Collection-CollectorList', JSON.stringify(this.collectorList))
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      filterCollector (query) {
        if (query !== '') {
          this.collectorLoading = true
          //          if (!this.collectorList || this.collectorList.length === 0) {
          //            this.getAllCollectorList()
          //          }
          this.displayNameFilterList = this.collectorList.filter(item => {
            return item.displayName.trim().indexOf(query.trim()) > -1
          })
          this.usernameFilterList = this.collectorList.filter(item => {
            return item.username.trim().indexOf(query.trim()) > -1
          })
          this.collectorLoading = false
        } else {
          this.displayNameFilterList = []
          this.usernameFilterList = []
        }
      },
      // 获取表格列表数据
      getTableData () {
        this.searchLoading = true
        // 列表开始加载
        this.listLoading = true
        fetchGetAssignLimitList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content.map(item => {
                item.dayLimit1 = item.dayLimit
                item.monthLimit1 = item.monthLimit
                // class
                item.isActiveDay = false
                item.isActiveMonth = false
                return item
              })
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
            this.searchLoading = false
          })
          .catch(error => {
            console.log(error)
            this.searchLoading = false
            this.listLoading = false
          })
      },
      // 搜索按钮
      searchBtn () {
        this.getTableData()
      },
      // 导出按钮
      exportBtn () {
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = URL_EXPORT_ASSIGN_LIMIT_LIST + '?fileName=分案上限-' + date + '.csv&param=' + encodeURI(JSON.stringify(this.filterForm))
        window.location.href = url
      },
      // 修改按钮
      editUpperLimit (value) {
        // 非负整数
        let reg = /^(0|[1-9]\d*)$/
        if (value.dayLimit1 === '') {
          this.$message.warning('请输入日上限')
          value.isActiveDay = true
          value.isActiveMonth = false
          return false
        } else if (!reg.test(value.dayLimit1)) {
          this.$message.warning('日上限输入非法字符')
          value.isActiveDay = true
          value.isActiveMonth = false
          return false
        }
        if (value.monthLimit1 === '') {
          this.$message.warning('请输入月上限')
          value.isActiveDay = false
          value.isActiveMonth = true
          return false
        } else if (!reg.test(value.monthLimit1)) {
          this.$message.warning('月上限输入非法字符')
          value.isActiveDay = false
          value.isActiveMonth = true
          return false
        }
        let dayLimit = parseInt(value.dayLimit1)
        let monthLimit = parseInt(value.monthLimit1)
        if (value.todayNum > dayLimit) {
          this.$message.warning('日上限不能小于今日分案数' + value.todayNum)
          value.isActiveDay = true
          value.isActiveMonth = false
          return false
        }
        if (value.monthNum > monthLimit) {
          this.$message.warning('月上限不能小于当月分案数' + value.monthNum)
          value.isActiveDay = false
          value.isActiveMonth = true
          return false
        }
        let ids = []
        ids.push(value.id)
        // 输入框校验通过
        value.isActiveDay = false
        value.isActiveMonth = false
        this.updateLimitList(ids, dayLimit, monthLimit)
      },
      // 修改
      updateLimitList (ids, dayLimit, monthLimit) {
        // 修改 发送请求
        fetchUpdateLimitList(JSON.stringify(ids), JSON.stringify(dayLimit), JSON.stringify(monthLimit))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success('修改成功')
            }
          })
          .catch(error => {
            console.log(error)
            this.$message.error('修改失败')
          })
      },
      // 删除按钮
      deleteUpperLimit (value) {
        this.$confirm('此操作将用户' + value.username + '的日上限和月上限重置为0, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          // 删除
          fetchCleanLimitList(JSON.stringify(value.id))
            .then(response => {
              let res = response.data
              if (res.errorCode === 0) {
                this.$message.success('删除成功')
                value.dayLimit = value.dayLimit1 = 0
                value.monthLimit = value.monthLimit1 = 0
                value.isActiveDay = false
                value.isActiveMonth = false
              }
            })
            .catch(error => {
              console.log(error)
              this.$message.error('删除失败')
            })
        }).catch(() => {
          this.$message.info('已取消删除')
        })
      },
      // 勾选数据表
      handleSelectionChange (val) {
        this.multipleSelection = val
        let arr1 = []
        let arr2 = []
        val.map(item => {
          arr1.push(item.todayNum)
          arr2.push(item.monthNum)
          return item
        })
        this.todayNumMax = Math.max.apply(null, arr1)
        this.monthNumMax = Math.max.apply(null, arr2)
      },
      // 批量操作
      exportBatchBtn () {
        if (!this.multipleSelection.length) {
          this.$message.warning('没选中数据')
          return false
        }
        this.dialogFormVisible = true
      },
      // 保存批量操作
      handleSaveBatch () {
        this.submitForm('ruleForm')
      },
      // 取消批量操作
      handleCancelBatch () {
        this.dialogFormVisible = false
        this.resetForm('ruleForm')
      },
      // 弹窗关闭的回调
      handleCloseDialog () {
        this.resetForm('ruleForm')
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let ids = []
            this.multipleSelection.map(item => {
              ids.push(item.id)
              return item
            })
            let dayLimit = parseInt(this.batchForm.dayLimit)
            let monthLimit = parseInt(this.batchForm.monthLimit)
            // 批量修改 发送请求
            fetchUpdateLimitList(JSON.stringify(ids), JSON.stringify(dayLimit), JSON.stringify(monthLimit))
              .then(response => {
                let res = response.data
                if (res.errorCode === 0) {
                  this.$message.success('保存成功')
                  this.dialogFormVisible = false
                  this.getTableData()
                }
              })
              .catch(error => {
                console.log(error)
                this.$message.error('保存失败')
              })
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      }
    }
  }
</script>

<style lang="scss" scoped>
  .upper-limit-wrapper {
    .length-1 {
      width: 100px;
    }
    .length-2 {
      width: 180px;
    }
    .filter-form {
      .el-form-item {
        margin-bottom: 5px;
      }
    }
    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }

  }
</style>