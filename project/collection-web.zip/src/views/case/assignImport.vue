<!-- 分案导入 -->
<template>
  <div class="assign-import-wrapper">

    <!-- 导入文件开始 -->
    <el-form label-position="top" label-width="80px" class="upload-wrapper">
      <el-form-item label="导入csv文件说明">
        <div class="upload-file-explain">
          <li>请按照模板格式导入csv文件，仅支持.csv格式</li>
          <li>csv里面只有一个sheet，数据存放在A列，文本格式</li>
          <li>
            <span class="file-name" @click="downloadTemplate">下载最新分案上限设置</span>
          </li>
        </div>
        <div class="upload-file-main">
          <!--上传组件 accept=".csv" application/vnd.ms-excel accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" -->
          <el-upload class="upload-user-defined" name="in" accept=".csv"
                     :action="uploadExcelUrl" :data="additionalData" :file-list="fileList" :show-file-list="false"
                     :with-credentials="true" :clearFiles="handleClearFiles"
                     :before-upload="handleUploadBefore" :on-success="handleUploadSuccess" :on-error="handleUploadError"
                     :on-progress="handleUploadProgress" :on-change="handleUploadChange" :disabled="isUploading">
            <el-button size="small" type="primary" :loading="isUploading">{{ uploadingText }}</el-button>
            <div slot="tip" class="el-upload__tip">
              <span>只能上传.csv格式的文件</span>
            </div>
          </el-upload>
        </div>
      </el-form-item>
    </el-form>
    <!-- 导入文件结束 -->

    <!-- 历史上传文档开始 -->
    <el-form label-position="top" label-width="80px" class="upload-wrapper">
      <el-form-item label="导入历史"></el-form-item>
    </el-form>
    <el-table :data="tableData" v-loading="listLoading" border stripe style="width: 100%" :max-height="tableHeight">
      <el-table-column align="center" prop="createAt" label="导入时间" min-width="120"></el-table-column>
      <el-table-column align="center" prop="operatorName" label="导入人" min-width="60"></el-table-column>
      <el-table-column align="center" prop="fileName" label="导入文件（点击可下载）" min-width="200">
        <template slot-scope="scope">
          <span class="file-name" @click="downloadFile(scope.row)">{{scope.row.fileName}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="导入结果" min-width="100">
        <template slot-scope="scope">
          <span>{{scope.row.success || 0}}项成功，{{scope.row.fail || 0}}项失败</span>
          <span v-if="scope.row.fail" class="file-name" @click="openResultDialog(scope.row)">查看</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 历史上传文档结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
    <el-dialog title="数据处理结果" :visible.sync="dialogVisible">
      <span class="dialog-result">{{ returnResult }}</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog title="导入结果" :visible.sync="dialogVisibleResult">
      <el-table :data="tableDataResult" v-loading="listLoadingResult" border stripe style="width: 100%" :max-height="tableHeightResult">
        <el-table-column align="center" prop="username" label="失败用户名" min-width="60"></el-table-column>
        <el-table-column align="center" prop="resultDetail" label="失败原因" min-width="60"></el-table-column>
      </el-table>
      <div v-show="!listLoadingResult" class="pagination-container">
        <el-pagination @size-change="handleSizeChangeResult" @current-change="handleCurrentChangeResult"
                       :current-page.sync="pagDataResult.pageNo" :page-sizes="pageSizesResult"
                       :page-size="pagDataResult.pageSize" layout="total, sizes, prev, pager, next, jumper"
                       :total="totalRecordResult">
        </el-pagination>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisibleResult = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  import {
    URL_DOWNLOAD_CASE_ASSIGN,
    fetchGetAssignImportList,
    URL_UPLOAD_CASE_ASSIGN,
    fetchIsUploadOver,
    fetchGetImportResultByFileId
  } from '../../api/case'
  import { parseTime } from '../../utils/formatDate'

  export default {
    data () {
      return {
        uploadExcelUrl: URL_UPLOAD_CASE_ASSIGN, // 上传的地址
        additionalData: {}, // 上传时附带的额外参数
        fileName: '', // 文件名
        isUploading: false, // 文件上传中 按钮禁用提示
        uploadingText: '上传', // 上传按钮文字
        fileList: [],
        // 表格
        tableHeight: 600, // 表格高度
        listLoading: false, // 加载
        // 质检明细表格数据
        tableData: [], // 数据
        // 分页
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 25, 50, 100, 500, 1000],
        timer: null, // 定时器
        // 弹窗
        dialogVisible: false,
        returnResult: '', // 返回结果

        // 导入结果弹窗
        currentFileId: null,
        dialogVisibleResult: false,
        tableHeightResult: 300, // 表格高度
        listLoadingResult: false, // 加载
        // 质检明细表格数据
        tableDataResult: [], // 数据
        pagDataResult: {
          pageSize: 10, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecordResult: 0, // 总记录数
        pageSizesResult: [10, 50, 100, 500]
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
      // 获取表格数据
      this.getTableData()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        let h = document.documentElement.clientHeight
        this.tableHeight = h - 310
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 获取表格列表数据
      getTableData () {
        // 列表开始加载
        this.listLoading = true
        fetchGetAssignImportList(JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 下载文件
      downloadFile (value) {
        let url = URL_DOWNLOAD_CASE_ASSIGN + '?fileName=' + value.fileName + '&fileId=' + value.id
        window.location.href = url
      },
      // 下载最新分案上限设置
      downloadTemplate () {
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = URL_DOWNLOAD_CASE_ASSIGN + '?fileName=最新分案上限设置-' + date + '.csv&fileId='
        window.location.href = url
      },
      // 上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
      handleUploadBefore (file) {
        if (file.name && file.name.length > 0) {
          this.additionalData.filename = file.name
          const ldot = file.name.lastIndexOf('.')
          const type = file.name.toLowerCase().substring(ldot)
          if (type !== '.csv') {
            this.$message.warning('目前只支持.csv格式的文件')
            return false
          }
        }
      },
      // 验证是否上传成功
      isUploadOver (isUploadOverFlag) {
        fetchIsUploadOver(isUploadOverFlag)
          .then(resp => {
            if (resp.data.errorCode === 0) {
              if (!resp.data.data.flag) {
                // false 代表 上传成功
                this.$message('数据处理完成!')
                this.isUploading = false // 关闭提示
                clearInterval(this.timer)
                this.getTableData() // 获取表格数据
                // 打开弹窗
                if (resp.data.data.result) {
                  this.dialogVisible = true
                  this.returnResult = resp.data.data.result
                }
              } else {
                // true 代表  上传成功，数据正在处理中
                this.isUploading = true
              }
            } else {
              this.$message.error(resp.data.errorMsg)
              this.isUploading = false // 关闭提示
              clearInterval(this.timer)
            }
          })
          .catch(error => {
            console.log(error)
            this.$message.error('数据处理失败!')
            this.isUploading = false // 关闭提示
            clearInterval(this.timer)
          })
      },
      // 文件上传成功时的钩子
      handleUploadSuccess (response, file, fileList) {
        let _this = this
        if (response.errorCode === 0) {
          let isUploadOverFlag = response.data
          // 根据返回的code，去定时请求另外接口，来验证是否上传成功
          if (isUploadOverFlag) {
            this.$message.success('上传成功，数据正在处理中!')
            this.timer = setInterval(function () {
              _this.isUploadOver(isUploadOverFlag)
            }, 3000)
          }
        } else {
          this.$message.error(response.errorMsg)
          // 移除文件
          this.handleClearFiles()
        }
      },
      // 文件上传失败时的钩子
      handleUploadError (err, file, fileList) {
        console.log(err)
        this.$message.error('上传失败!')
      },
      // 文件上传时的钩子
      handleUploadProgress (event, file, fileList) {
        this.isUploading = true // 开启提示
        this.fileList = fileList
        console.log('上传中...')
      },
      // 文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
      handleUploadChange (file, fileList) {
        // this.isUploading = false // 关闭提示
        console.log('上传完成')
      },
      // 清空已上传的文件列表
      handleClearFiles () {
        this.fileList = []
      },
      // 打开导入结果弹窗
      openResultDialog (value) {
        this.dialogVisibleResult = true
        this.currentFileId = value.id
        this.getTableDataResult()
      },
      getTableDataResult () {
        this.listLoadingResult = true
        fetchGetImportResultByFileId(JSON.stringify(this.currentFileId), JSON.stringify(this.pagDataResult))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableDataResult = res.data.content
              this.totalRecordResult = res.data.totalRecord
            }
            this.listLoadingResult = false
          })
          .catch(error => {
            console.log(error)
            this.listLoadingResult = false
          })
      },
      // 处理分页每页显示数改变事件
      handleSizeChangeResult (val) {
        this.pagDataResult.pageSize = val
        this.getTableDataResult()
      },
      // 处理页码改变事件
      handleCurrentChangeResult (val) {
        this.pagDataResult.pageNo = val
        this.getTableDataResult()
      }
    },
    watch: {
      isUploading (val) {
        this.uploadingText = val ? '处理中' : '上传'
      }
    }
  }
</script>

<style lang="scss" scoped>
  .assign-import-wrapper {
    .upload-wrapper {
      margin-bottom: 10px;
      .el-form-item {
        margin-bottom: 5px;
      }
      .el-form-item__label {
        color: #317eac;
      }
      li {
        font-size: 12px;
        line-height: 30px;
      }
      .el-upload-dragger {
        .el-upload__text {
          color: #97a8be;
          font-size: 12px;
          text-align: center;
        }
      }
      .upload-file-main,
      .upload-file-explain {
        float: left;
        margin-left: 10px;
        margin-right: 10px;
        /*.el-button {*/
        /*font-size: 12px;*/
        /*padding: 0;*/
        /*}*/
        /*.el-button {*/
          /*width: 68px;*/
          /*height: 28px;*/
        /*}*/
      }
    }

    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }

    /* fileName */
    .file-name {
      color: #2fa4e7;
      cursor: pointer;
      &:hover {
        text-decoration: underline;
        color: #428bca;
      }
    }
    /* dialog 强制换行 */
    .dialog-result {
      word-break: break-all;
      word-wrap: break-word;
    }
  }
</style>
