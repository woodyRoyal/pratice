/**
* 可分案配置
* Created on 2017/9/19.
*/

<template>
  <el-form :inline="true" class="assignable-form" label-width="75px">
    <el-row class="execute-assign">
      <el-button type="primary" @click="handleExecuteAssign">执行分案
      </el-button>
    </el-row>
    <el-row v-for="(item, index) in configList" :key="item.overdueLevel">
      <el-form-item :label="overdueLevelMap[item.overdueLevel] + ':'">
        <el-input placeholder="请输入金额" class="length-1" size="small"
                  v-model="item.minAmount"
                  @blur="handleCheckInput(item)"
                  :disabled="!item.editable">
          <template slot="append"><span style="font-size: 14px;" title="大于等于">≤</span></template>
        </el-input>
        <div class="amount-variable" title="案件金额 范围">X</div>
        <el-input placeholder="请输入金额" class="length-1" size="small"
                  v-model="item.maxAmount"
                  @blur="handleCheckInput(item)"
                  :disabled="!item.editable">
          <template slot="prepend"><span title="小于">&lt;</span></template>
        </el-input>
      </el-form-item>
      <el-form-item label="生效时间:">
        <el-date-picker
          v-model="item.time"
          size="small"
          :disabled="!item.editable"
          type="datetimerange"
          :editable="false"
          :clearable="false"
          format="yyyy-MM-dd HH:mm:ss"
          :picker-options="pickerOptions2"
          placeholder="选择时间范围">
        </el-date-picker>

      </el-form-item>
      <el-form-item>
        <el-button v-show="!item.editable" type="primary" @click="item.editable=true" size="small"
                   icon="edit">编辑
        </el-button>
        <el-button v-show="item.editable" type="success" @click="handleSaveConfig(item)" size="small"
                   icon="check">保存
        </el-button>
        <el-button v-show="item.editable" @click="handleCancelConfig(item)" size="small"
                   icon="close">取消
        </el-button>
      </el-form-item>
    </el-row>
  </el-form>
</template>

<script>
  import { parseTime } from '../../utils/formatDate'
  import { CONST_OVERDUE_LEVEL_MAP } from './caseConstant'
  import {
    fetchAssignableConfigList,
    fetchUpdateAssignableConfig,
    fetchPerformAssignCase
  } from '../../api/case'
  import { getIntger, pickerOptions2 } from '../../utils/index'

  export default {
    computed: {},
    data () {
      return {
        // 表单数据
        configList: [],
        tempConfigList: [], // 中间量 存储查询得到的数据 用于取消编辑时还原数据
        pickerOptions2,
        overdueLevelMap: CONST_OVERDUE_LEVEL_MAP // 逾期阶段字符串映射
      }
    },
    mounted () {
      // 获取当前配置列表
      this.getAssignableConfigList()
    },
    methods: {
      // 获取当前配置列表
      getAssignableConfigList () {
        fetchAssignableConfigList()
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              // 遍历处理数据
              this.configList = response.data.data.map(item => {
                // 生效时间
                item.time = [
                  item.startTime,
                  item.endTime
                ]
                // 给每一条增加是否可编辑的字段
                item.editable = false
                return item
              })
              // 保存数据 深拷贝
              this.tempConfigList = JSON.parse(JSON.stringify(this.configList))
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 执行分案
      handleExecuteAssign () {
        // 调用接口执行job
        fetchPerformAssignCase()
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              this.$message.success('操作成功')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 点击保存按钮
      handleSaveConfig (config) {
        if (!config.minAmount || !config.maxAmount) {
          this.$message.warning('请输入金额')
          return false
        }
        if (parseInt(config.minAmount) >= parseInt(config.maxAmount)) {
          this.$message.warning('案件金额范围异常')
          return false
        }
        //        if (!config.time[0] || !config.time[1]) {
        //          this.$message.warning('请选择时间范围')
        //          return false
        //        }
        // 时间time 为 null elementui 2.0
        if (!config.time) {
          this.$message.warning('请选择时间范围')
          return false
        }

        config.startTime = config.time[0]
        config.endTime = config.time[1]
        // 取消可编辑状态
        for (let item of this.configList) {
          if (item.id === config.id) {
            // 取消可编辑状态
            item.editable = false
            break
          }
        }
        // 提交数据
        this.saveConfig(config)
      },
      // 点击取消按钮 还原数据
      handleCancelConfig (config) {
        for (let item of this.tempConfigList) {
          if (item.id === config.id) {
            // 原始数据
            config = item
            break
          }
        }

        for (let item of this.configList) {
          if (item.id === config.id) {
            // 取消可编辑状态
            item.editable = false
            // 还原数据
            item.minAmount = config.minAmount
            item.maxAmount = config.maxAmount
            item.startTime = config.startTime
            item.endTime = config.endTime
            break
          }
        }
      },
      // 保存设置
      saveConfig (config) {
        let params = {
          id: config.id,
          overdueLevel: config.overdueLevel,
          minAmount: config.minAmount,
          maxAmount: config.maxAmount,
          startTime: parseTime(config.startTime, 'YYYY-MM-DD HH:mm:ss'),
          endTime: parseTime(config.endTime, 'YYYY-MM-DD HH:mm:ss')
        }
        fetchUpdateAssignableConfig(JSON.stringify(params))
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              this.$message.success('操作成功')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 输入校验 onkeyup="value=value.replace(/[^\d]/g,'')"
      handleCheckInput (obj) {
        let minAmount = (obj && obj.minAmount).toString()
        let maxAmount = (obj && obj.maxAmount).toString()
        if (minAmount !== '') { // 只能输入数字
          // obj.minAmount = obj.minAmount.replace(/[^\d.]/g, '')
          obj.minAmount = getIntger(minAmount)
        }
        if (maxAmount !== '') { // 只能输入数字
          // obj.maxAmount = obj.maxAmount.replace(/[^\d.]/g, '')
          obj.maxAmount = getIntger(maxAmount)
        }
      }
    }
  }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  .assignable-form {
    .execute-assign {
      text-align: right;
      margin-bottom: 10px;
      margin-right: 20px;
    }
    .el-form-item {
      margin-bottom: 5px;
    }
    .length-1 {
      width: 120px;
    }
    .length-2 {
      width: 180px;
    }
    .amount-variable {
      display: inline-block;
      background-color: #fbfdff;
      color: #97a8be;
      border: 1px solid #bfcbd9;
      border-radius: 3px;
      height: 30px;
      width: 30px;
      line-height: 30px;
      text-align: center;
      position: relative;
      top: 1px;
    }
  }
</style>
