/**
* 未分配案件导出
* Created by zuo on 2017/9/19.
*/

<template>
  <div>
    <el-form :inline="true" :model="formData" class="unassigned-form">
      <el-form-item label="UID:">
        <el-input placeholder="请输入UID" class="length-1" size="small"
                  v-model="formData.caseId">
        </el-input>
      </el-form-item>
      <el-form-item label="客户姓名:">
        <el-input placeholder="请输入客户姓名" class="length-1" size="small"
                  v-model="formData.displayName">
        </el-input>
      </el-form-item>
      <el-form-item label="产品信息:">
        <vue-el-select v-model="formData.productId" multiple placeholder="请选择产品信息" size="small"
                       class="length-1">
          <el-option
            v-for="item in appCodeList"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>
      <el-form-item label="逾期天数:">
        <vue-el-select v-model="formData.overdueDayList" multiple size="small" class="length-3" @change="handleOverdueDaysChange">
          <el-option v-for="(item, index) in overdueDayData" :label="item" :key="index" :value="item"></el-option>
        </vue-el-select>
        <el-input class="length-2" size="small" v-model="formData.overdueDayStart" placeholder="天"
                  @blur="handleCheckInputDays(formData)">
        </el-input>
        ~
        <el-input class="length-2" size="small" v-model="formData.overdueDayEnd" placeholder="天"
                  @blur="handleCheckInputDays(formData)">
        </el-input>
      </el-form-item>
      <el-form-item label="逾期金额:">
        <el-input class="length-2" size="small" v-model="formData.overdueMoneyStart" placeholder="元"
                  @blur="handleCheckInputAmount(formData)">
        </el-input>
        ~
        <el-input class="length-2" size="small" v-model="formData.overdueMoneyEnd" placeholder="元"
                  @blur="handleCheckInputAmount(formData)">
        </el-input>
      </el-form-item>
      <el-form-item class="operate-btn">
        <el-button type="primary" @click="handleSearchData" size="small" :loading="searchLoading">搜索
        </el-button>
        <el-button type="success" @click="handleExportData" size="small">导出
        </el-button>
      </el-form-item>
    </el-form>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row style="width: 100%"
              :max-height="tableMaxHeight">
      <el-table-column align="center" label="UID" prop="uid">
      </el-table-column>
      <el-table-column align="center" label="案件ID" prop="caseId">
      </el-table-column>
      <!--<el-table-column align="center" label="借据编号" prop="borrowId">-->
        <!--<template slot-scope="scope">-->
          <!--<span>{{ scope.row.borrowId || '&#45;&#45;' }}</span>-->
        <!--</template>-->
      <!--</el-table-column>-->

      <el-table-column align="center" label="客户姓名" prop="displayName">
      </el-table-column>

      <el-table-column align="center" label="逾期天数" prop="overdueDay">
      </el-table-column>
      <el-table-column align="center" label="逾期金额(元)" prop="overdueMoney">
      </el-table-column>
      <el-table-column align="center" label="产品信息" prop="productNames">
      </el-table-column>
    </el-table>
    <!--分页-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="formData.pageNo" :page-sizes="pageSizes"
                     :page-size="formData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="formData.totalRecord">
      </el-pagination>
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import VueElSelect from '../../components/VueElSelect'
  import { getIntger, getMaxTwoDecimalPlaces } from '../../utils/index'
  import { parseTime } from '../../utils/formatDate'
  import {
    fetchUnassignedCaseList,
    URL_EXPORT_UNASSIGNED_CASE,
    fetchOverdueDaysDefault
  } from '../../api/case'
  // import { fetchAllProductList } from '../../api/common'

  export default {
    components: {
      VueElSelect
    },
    computed: {
      ...mapGetters([
        'appCodeList', // 产品类型
        'appType' // 产品类型常量
      ])
    },
    data () {
      return {
        // 逾期阶段预设值
        overdueDayData: [],
        overdueDayDataLimit: {'': '无'},
        searchLoading: false, // 搜索按钮loading
        // 表单数据
        formData: {
          caseId: '', // UID
          displayName: '', // 客户姓名
          productId: [], // 产品信息
          overdueDayStart: '', // 逾期天数
          overdueDayEnd: '',
          overdueDayList: [], // 逾期天数预设值
          overdueMoneyStart: '', // 逾期金额 输入元 请求时需转为分
          overdueMoneyEnd: '',

          // 分页参数
          pageSize: 100, // 默认每页条数
          pageNo: 1, // 页码
          totalRecord: 0, // 总记录数
          totalPage: 0 // 总页数
        },
        pageSizes: [50, 100, 200],

        productInfoList: [], // 产品信息列表
        // productInfoMap: {}, // 产品信息

        tableData: null, // 表数据
        listLoading: false,
        tableMaxHeight: 600 // 表格最大高度
      }
    },
    created () {
      this.getProductType() // 获取产品类型
    },
    mounted () {
      // 表格高度
      this.handleResize()
      // 监听窗口大小变化
      window.addEventListener('resize', this.handleResize)
      // this.getAllProductList()
      // this.getTableData()
      this.getOverdueDaysDefault()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // 获取所有逾期阶段预设值
      getOverdueDaysDefault () {
        fetchOverdueDaysDefault()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.overdueDayData = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 预设值改变事件
      handleOverdueDaysChange () {
        if (this.formData.overdueDayList.length > 0) {
          this.formData.overdueDayStart = ''
          this.formData.overdueDayEnd = ''
        }
      },
      // resize回调修改表格高度
      handleResize (event) {
        let formHeight = document.getElementsByClassName('unassigned-form')[0].offsetHeight
        let h = document.documentElement.clientHeight
        if (formHeight >= 82) {
          this.tableMaxHeight = h - 204
        } else if (formHeight >= 41) {
          this.tableMaxHeight = h - 160
        }
      },
      // 获取产品列表
      //      getAllProductList () {
      //        fetchAllProductList()
      //          .then(response => {
      //            if (response.data.errorCode === 0 && response.data.data) {
      //              // 遍历处理数据
      //              this.productInfoList = response.data.data
      //              // 数组转map对象
      //              /* if (this.productInfoList && this.productInfoList.length > 0) {
      //                for (let item of this.productInfoList) {
      //                  this.productInfoMap[item.productId] = item.name
      //                }
      //              } */
      //            }
      //            this.listLoading = false
      //          })
      //          .catch(error => {
      //            console.log(error)
      //          })
      //      },
      // 获取产品类型
      getProductType () {
        if (!this.appCodeList.length) {
          this.$store.dispatch('GetAppCodeList')
            .then(res => {
            })
            .catch(err => {
              console.log(err)
            })
        }
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.formData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.formData.pageNo = val
        this.getTableData()
      },
      // 搜索按钮
      handleSearchData () {
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        this.searchLoading = true
        this.listLoading = true
        // 查询参数
        let param = this.getQueryParams()
        // 分页参数
        let queryPage = {
          pageNo: this.formData.pageNo, // 页码
          pageSize: this.formData.pageSize // 每页显示的记录数
        }
        fetchUnassignedCaseList(JSON.stringify(param), JSON.stringify(queryPage))
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              // 遍历处理数据
              this.tableData = response.data.data.content
              this.formData.totalRecord = response.data.data.totalRecord
              this.formData.totalPage = response.data.data.totalPage
            }
            this.listLoading = false
            this.searchLoading = false
          })
          .catch(error => {
            this.searchLoading = false
            this.listLoading = false
            console.log(error)
          })
      },
      getQueryParams () {
        return {
          caseId: this.formData.caseId || null, // UID
          displayName: this.formData.displayName, // 客户姓名
          productIds: this.formData.productId, // 产品信息
          overdueDayList: this.formData.overdueDayList.length === 0 ? null : this.formData.overdueDayList,
          overdueDayStart: this.formData.overdueDayStart === '' ? this.formData.overdueDayEnd === '' ? null : this.formData.overdueDayEnd : this.formData.overdueDayStart,
          overdueDayEnd: this.formData.overdueDayEnd === '' ? this.formData.overdueDayStart === '' ? null : this.formData.overdueDayStart : this.formData.overdueDayEnd,
          overdueMoneyStart: this.formData.overdueMoneyStart !== '' ? parseInt(parseFloat(this.formData.overdueMoneyStart) * 100) : null, // 逾期金额 元转分
          overdueMoneyEnd: this.formData.overdueMoneyEnd !== '' ? parseInt(parseFloat(this.formData.overdueMoneyEnd) * 100) : null
        }
      },
      // 输入天数校验 取整 onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))">
      handleCheckInputDays (obj) {
        if (obj.overdueDayStart !== '') {
          obj.overdueDayStart = getIntger(obj.overdueDayStart)
          this.formData.overdueDayList = []
        }
        if (obj.overdueDayEnd !== '') {
          obj.overdueDayEnd = getIntger(obj.overdueDayEnd)
          this.formData.overdueDayList = []
        }
      },

      // 输入金额校验 可保留两位小数
      handleCheckInputAmount (obj) {
        if (obj.overdueMoneyStart !== '') {
          obj.overdueMoneyStart = getMaxTwoDecimalPlaces(obj.overdueMoneyStart)
        }
        if (obj.overdueMoneyEnd !== '') {
          obj.overdueMoneyEnd = getMaxTwoDecimalPlaces(obj.overdueMoneyEnd)
        }
      },
      // 导出数据
      handleExportData () {
        let param = this.getQueryParams()
        let currTime = parseTime(new Date(), 'YYYYMMDDHHmmss')
        window.location.href = URL_EXPORT_UNASSIGNED_CASE + '?fileName=未分配案件-' + currTime + '.csv&param=' + encodeURI(JSON.stringify(param))
      }
    }
  }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  .unassigned-form {
    .el-form-item {
      margin-bottom: 5px;
    }
    .length-1 {
      width: 150px;
    }
    .length-2 {
      width: 80px;
    }
    .length-3 {
      width: 100px;
    }
    .operate-btn {
      float: right;
    }
  }
</style>
