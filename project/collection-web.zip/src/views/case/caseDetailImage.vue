/*
* @Author: sunp
* @Date: 2019/1/15 14:13
*/
<template>
  <div class="case-detail-image-wrapper" v-loading="isLoading"
       element-loading-text="拼命加载中"
       element-loading-spinner="el-icon-loading"
       element-loading-background="rgba(0, 0, 0, 0.8)">
    <!--<img :src="src" class="img"/>-->
    <el-row>
      <el-col :span="6" v-for="(item, key) in photoList" :key="key" style="height: 330px;">
        <pic-view :url="item.imageUrl" @fullScreen="fullScreen"></pic-view>
      </el-col>
      <el-col :span="6" v-for="(item, key) in videoList" :key="key" style="height: 330px;">
        <video id="videoPlayer" controls autoplay loop preload="metadata" style="height: 100%; width: 100%;"
               :src="item.imageUrl"></video>
      </el-col>
    </el-row>

    <!--遮罩层-->
    <div id="maskLayer" v-show="bigPic.flag"></div>

    <!--放大图片-->
    <div id="bigPic" ref="bigPic" v-show="bigPic.flag" @click="fullScreen">
      <img ref="bigPicImg" :src="bigPic.picUrl" :onerror="imgError" />
      <div class="operation-wrapper">
        <a class="left-rotate" title="左旋转" href="javascript:" @click.stop="bigPicRotate('left')"></a>
        <a class="right-rotate" title="右旋转" href="javascript:" @click.stop="bigPicRotate('right')"></a>
      </div>
    </div>
  </div>
</template>

<script>
  import { fetchCasePicture } from '../../api/case'
  import picView from '../../components/PicView'

  export default {
    components: {
      picView
    },
    computed: {
      // 图片路径无效 或 图片无效时触发
      imgError () {
        let src = require('assets/imgerror.png')
        // img 使用 onerror 以后，如果 onerror 指定的图片也是不存在的话，会出现无限死循环 404。 解决办法this.onerror=null
        return `javascript:this.src="${src}";this.onerror=null`
      }
    },
    data () {
      return {
        isLoading: false,
        // 大图片
        bigPic: {
          flag: false, // 判断显隐
          picUrl: '' // url地址
        },
        bigRotate: 0, // 大图的旋转角度
        photoList: [],
        videoList: []
      }
    },
    mounted () {
      // 获取案件的照片信息
      this.getUserPicture()
    },
    methods: {
      // 获取案件的照片信息
      getUserPicture () {
        this.isLoading = true
        fetchCasePicture(this.$route.params.orderId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              // f_video 和 u_video 为视频，其他的作为图片处理
              this.videoList = res.data.filter(item => item.imageType === 'f_video' || item.imageType === 'u_video')
              this.photoList = res.data.filter(item => item.imageType !== 'f_video' && item.imageType !== 'u_video')
            } else {
              this.videoList = []
              this.photoList = []
            }
            this.isLoading = false
          })
          .catch(error => {
            console.log(error)
            this.isLoading = false
          })
      },
      // 照片全屏
      fullScreen (imgUrl) {
        if (imgUrl) {
          this.bigPic.picUrl = imgUrl
        } else {
          this.bigRotate = 0 // 清除图片的旋转角度
          let bigPicImg = this.$refs.bigPicImg
          bigPicImg.style.webkitTransform = 'rotate(0deg)'
          bigPicImg.style.Transform = 'rotate(0deg)'
        }
        this.bigPic.flag = !this.bigPic.flag
      },
      // 大图旋转
      bigPicRotate (direction) {
        let bigPicImg = this.$refs.bigPicImg
        let bigPic = this.$refs.bigPic
        let rotate = (direction === 'right') ? this.bigRotate += 90 : this.bigRotate -= 90
        this.rotateAnimate(direction, bigPicImg, bigPic, rotate)
      },
      // 旋转动画
      rotateAnimate (direction, bigPicImg, bigPic, rotate) {
        let w = bigPic.offsetWidth
        let h = bigPic.offsetHeight
        if (Math.abs((rotate / 90) % 2) === 1) {
          bigPicImg.style.maxWidth = h + 'px'
          bigPicImg.style.maxHeight = w + 'px'
        } else if (Math.abs((rotate / 90) % 2) === 0) {
          bigPicImg.style.maxWidth = w + 'px'
          bigPicImg.style.maxHeight = h + 'px'
        }
        bigPicImg.style.webkitTransform = 'rotate(' + (rotate) + 'deg)'
        bigPicImg.style.Transform = 'rotate(' + (rotate) + 'deg)'
      }
    }
  }
</script>

<style lang="scss" scoped>
  #maskLayer {
    width: 100%;
    height: 100%;
    position: fixed;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    text-indent: -9999px;
    overflow: hidden;
    z-index: 2500;
  }

  #bigPic {
    width: 100%;
    height: 100%;
    position: fixed;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 3000;
    img {
      display: block;
      max-height: 90%;
      max-width: 90%;
      user-select: none;
      transition: all 0.8s;
    }
    .operation-wrapper {
      height: 36px;
      text-align: center;
      position: absolute;
      left: 0;
      right: 0;
      bottom: 10px;
      font-size: 0;
      line-height: 0;
      z-index: 20;
      a {
        width: 36px;
        height: 36px;
        display: inline-block;
        margin-left: 10px;
        background-image: url(../../assets/img/icon.png);
        background-repeat: no-repeat;
      }
      .left-rotate {
        background-position: left -46px;
      }
      .right-rotate {
        background-position: -46px -46px;
      }
      .fixedBox {
        background-position: -92px -46px;
      }
      .left-rotate:hover {
        background-position: left top;
      }
      .right-rotate:hover {
        background-position: -46px top;
      }
      .fixedBox:hover {
        background-position: -92px top;
      }
      .new-page:hover {
        background-position: -138px top;
      }
    }
  }
</style>
