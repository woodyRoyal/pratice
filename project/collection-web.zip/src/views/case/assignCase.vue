<!-- 分配案件 -->
<template>
  <div class="assign-case-wrapper">
    <!-- 导入文件开始 -->
    <el-form label-position="top" label-width="80px" class="upload-wrapper">
      <el-form-item label="自定义分配案件">
        <div class="upload-file-explain">
          <li>上传csv文件，按文件中案件与催收员的对应关系进行分配</li>
          <li>文件首列为案件Id，第二列为将要分配的催收员名字</li>
          <li>
            <!--<span class="file-name" @click="downloadTemplate">点击下载</span>-->
            <a class="file-name" href="./assets/分配案件模板.csv">点击下载</a>
            <span>文件模板（</span>
            <span class="file-name" @click="openResultDialog">查看</span>
            <span>最后一次自定义分配结果）</span>
          </li>
        </div>
        <div class="upload-file-main">
          <!--上传组件 accept=".csv" application/vnd.ms-excel accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" -->
          <el-upload class="upload-user-defined" name="in" accept=".csv"
                     :action="uploadExcelUrl" :data="additionalData" :file-list="fileList" :show-file-list="false"
                     :with-credentials="true" :clearFiles="handleClearFiles"
                     :before-upload="handleUploadBefore" :on-success="handleUploadSuccess" :on-error="handleUploadError"
                     :on-progress="handleUploadProgress" :on-change="handleUploadChange" :disabled="isUploading">
            <el-button size="small" type="primary" :loading="isUploading">{{ uploadingText }}</el-button>
            <div slot="tip" class="el-upload__tip">
              <span>只能上传.csv格式的文件</span>
            </div>
          </el-upload>
        </div>
      </el-form-item>
    </el-form>
    <!-- 导入文件结束 -->
    <el-form :inline="true">
       <el-form-item label="分配时间">
         <el-date-picker
           size="small"
           v-model="date"
           class="length-2"
           type="datetimerange"
           start-placeholder="开始日期"
           end-placeholder="结束日期"
           :editable="false"
         >
         </el-date-picker>
       </el-form-item>
      <!--<el-form-item label="产品:">-->
        <!--<el-form :inline="true">-->
          <!--<el-form-item>-->
            <!--<el-checkbox :indeterminate="productType" v-model="checkAllProductType" @change="handleCheckAllProductTypeChange">全选</el-checkbox>-->
          <!--</el-form-item>-->
          <!--<el-form-item>-->
            <!--<el-checkbox-group v-model="filterForm.productType" @change="handleProductTypeChange">-->
              <!--<el-checkbox v-for="item in ProductTypeList" :label="item" :key="item">{{ item }}</el-checkbox>-->
            <!--</el-checkbox-group>-->
          <!--</el-form-item>-->
        <!--</el-form>-->
      <!--</el-form-item>-->
      <el-form-item>
        <el-input v-model="filterForm.operatorName" size="small"
                  class="length-1" placeholder="操作人"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button size="small" type="primary" @click="searchHistory" :loading="searchLoading">搜索</el-button>
      </el-form-item>
    </el-form>

    <!-- 历史上传文档开始 -->
    <!--<el-form label-position="top" label-width="80px" class="upload-wrapper">-->
      <!--<el-button size="small" type="primary" @click="searchHistory">查看历史</el-button>-->
    <!--</el-form>-->

    <el-table :data="tableData" v-loading="listLoading" border stripe style="width: 100%" :max-height="tableHeight">
      <el-table-column align="center" prop="operateAt" label="分配时间" min-width="120"></el-table-column>
      <el-table-column align="center" prop="operatorName" label="操作者" min-width="60"></el-table-column>
      <!--<el-table-column align="center" prop="operatorName" label="产品" min-width="60"></el-table-column>-->
      <el-table-column align="center" prop="totalcount" label="分配总数" min-width="60"></el-table-column>
      <el-table-column align="center" prop="failcount" label="失败数" min-width="60"></el-table-column>
      <el-table-column align="center" label="分配失败文件" min-width="60">
        <template slot-scope="scope">
          <span class="file-name" v-if="scope.row.failcount > 0" @click="downloadFile(scope.row.id, 0)">下载</span>
          <span v-else>--</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="分配文件" min-width="60">
        <template slot-scope="scope">
          <span class="file-name" v-if="scope.row.totalcount > 0 && scope.row.failcount !== scope.row.totalcount" @click="downloadFile(scope.row.id, 1)">下载</span>
          <span v-else>--</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 历史上传文档结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
    <el-dialog title="数据处理结果" :visible.sync="dialogVisible">
      <span class="dialog-result">{{ returnResult }}</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog title="导入结果" :visible.sync="dialogVisibleResult">
      <p style="color: green;">分配成功：{{ successNum }}条</p>
      <el-table :data="tableDataSuccessResult" v-loading="listLoadingResult" border stripe style="width: 100%" :max-height="tableHeightResult">
        <el-table-column align="center" prop="collectorName" label="催收员" min-width="60"></el-table-column>
        <el-table-column align="center" prop="sumNum" label="分得个数" min-width="60"></el-table-column>
        <el-table-column align="center" prop="sumMoney" label="分得金额" min-width="60"></el-table-column>
        <el-table-column align="center" prop="total" label="案件总数" min-width="60"></el-table-column>
      </el-table>
      <p style="color: red;">分配失败：{{ this.tableDataFailResult.length }}条</p>
      <!--<el-table :data="tableDataFailResult" v-loading="listLoadingResult" border stripe style="width: 100%" :max-height="tableHeightResult">-->
        <!--<el-table-column align="center" prop="borrowId" label="借据编号" min-width="60"></el-table-column>-->
        <!--<el-table-column align="center" prop="name" label="催收员" min-width="60"></el-table-column>-->
        <!--<el-table-column align="center" prop="resultDesc" label="失败原因" min-width="60"></el-table-column>-->
      <!--</el-table>-->

      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisibleResult = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  import {
    URL_EXPORT_BY_ASSIGNID_AND_STATUS, // 导出案件分配详细
    fetchGetAssignHistoryList, // 案件分配历史查询
    // URL_EXPORT_FILE_TEMPLATE, // 下载模板
    fetchGetLastesAssignResult, // 查看最后一次自定义分配结果
    URL_IMPORT_CASE_ASSIGN_FILE // 上传
  } from '../../api/case'
  import { parseTime } from '../../utils/formatDate'

  export default {
    data () {
      return {
        searchLoading: false, // 搜索loading
        // 筛选条件
        filterForm: {
          startDate: null,
          endDate: null,
          operatorName: ''
        },
        // 产品类型复选框
        productType: false,
        checkAllProductType: false,
        date: null,
        uploadExcelUrl: URL_IMPORT_CASE_ASSIGN_FILE, // 上传的地址
        additionalData: {}, // 上传时附带的额外参数
        fileName: '', // 文件名
        isUploading: false, // 文件上传中 按钮禁用提示
        uploadingText: '上传文件', // 上传按钮文字
        fileList: [],
        // 表格
        tableHeight: 600, // 表格高度
        listLoading: false, // 加载
        // 质检明细表格数据
        tableData: [], // 数据
        // 分页
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 25, 50, 100, 500, 1000],
        timer: null, // 定时器
        // 弹窗
        dialogVisible: false,
        returnResult: '', // 返回结果

        // 导入结果弹窗
        dialogVisibleResult: false,
        tableHeightResult: 200, // 表格高度
        listLoadingResult: false, // 加载
        // 质检明细表格数据
        tableDataSuccessResult: [], // 成功数据
        tableDataFailResult: [], // 失败数据
        successNum: 0
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
      // 获取表格数据
      this.getTableData()
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        let h = document.documentElement.clientHeight
        this.tableHeight = h - 310
      },
      deactivated () {
        window.removeEventListener('resize', this.handleResize)
      },
      beforeDestroy () {
        window.removeEventListener('resize', this.handleResize)
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      searchHistory () {
        this.getTableData()
      },
      // 获取表格列表数据
      getTableData () {
        this.searchLoading = true // 搜索按钮loading
        // 列表开始加载
        this.listLoading = true
        this.filterForm.startDate = this.date === null ? null : parseTime(this.date[0], 'YYYY-MM-DD HH:mm:ss')
        this.filterForm.endDate = this.date === null ? null : parseTime(this.date[1], 'YYYY-MM-DD HH:mm:ss')
        fetchGetAssignHistoryList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
            this.searchLoading = false
          })
          .catch(error => {
            console.log(error)
            this.searchLoading = false
            this.listLoading = false
          })
      },
      // 产品类型-复选框
      handleCheckAllProductTypeChange (val) {
        this.filterForm.productType = val ? this.ProductTypeList : []
        this.productType = false
      },
      handleProductTypeChange (value) {
        let checkedCount = value.length
        this.checkAllProductType = checkedCount === this.ProductTypeList.length
        this.productType = checkedCount > 0 && checkedCount < this.ProductTypeList.length
      },
      // 下载失败或成功文件
      downloadFile (id, status) {
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let str = status ? '成功' : '失败'
        let url = URL_EXPORT_BY_ASSIGNID_AND_STATUS + '?fileName=分案' + str + '名单-' + date + '.csv&assignId=' + id + '&resultStatus=' + status
        window.location.href = url
      },
      // 下载文件模板
      //      downloadTemplate () {
      //        window.location.href = URL_EXPORT_FILE_TEMPLATE
      //      },
      // 上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
      handleUploadBefore (file) {
        if (file.name && file.name.length > 0) {
          this.additionalData.fileName = file.name
          const ldot = file.name.lastIndexOf('.')
          const type = file.name.toLowerCase().substring(ldot)
          if (type !== '.csv') {
            this.$message.warning('目前只支持.csv格式的文件')
            return false
          }
        }
      },
      // 文件上传成功时的钩子
      handleUploadSuccess (response, file, fileList) {
        if (response.errorCode === 0) {
          this.$message.success('上传文件成功!')
          this.getTableData()
        } else {
          this.$message.error(response.errorMsg)
          // 移除文件
          this.handleClearFiles()
        }
      },
      // 文件上传失败时的钩子
      handleUploadError (err, file, fileList) {
        console.log(err)
        this.$message.error('上传文件失败!')
      },
      // 文件上传时的钩子
      handleUploadProgress (event, file, fileList) {
        this.isUploading = true // 开启提示
        this.fileList = fileList
        console.log('上传文件中...')
      },
      // 文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
      handleUploadChange (file, fileList) {
        this.isUploading = false // 关闭提示
        console.log('上传文件完成')
      },
      // 清空已上传的文件列表
      handleClearFiles () {
        this.fileList = []
      },
      // 打开导入结果弹窗
      openResultDialog (value) {
        this.getTableDataResult()
      },
      getTableDataResult () {
        this.listLoadingResult = true
        fetchGetLastesAssignResult()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              if (res.data.status === false) {
                this.$message.error(res.data.errorMsg)
              } else {
                let successNum = 0
                if (res.data.assignSuccessRes && res.data.assignSuccessRes.length) {
                  this.tableDataSuccessResult = res.data.assignSuccessRes.map(item => {
                    successNum += item.sumNum
                    return item
                  }) // 成功数据
                }
                this.tableDataFailResult = res.data.assignFailRes // 失败数据
                this.successNum = successNum
                this.dialogVisibleResult = true
              }
            }
            this.listLoadingResult = false
          })
          .catch(error => {
            console.log(error)
            this.listLoadingResult = false
          })
      },
      downloadTemplate () {
        let head = [[2100001, '张三', 0, 0], [2100002, '李四', 0, 0], [2100003, '王二麻子', 0, 0]]
        let csvRows = []
        head.forEach((item, index) => {
          csvRows.push(head[index].join(','))
        })
        let csvString = csvRows.join('\n')
        // BOM的方式解决EXCEL乱码问题
        let BOM = '\uFEFF'
        csvString = BOM + csvString
        let a = document.createElement('a')
        a.href = 'data:attachment/csv,' + encodeURI(csvString)
        a.target = '_blank'
        a.download = 'assignCase.csv'
        document.body.appendChild(a) // Firefox 中必须这么写，不然不会起效果
        a.click()
        document.body.removeChild(a)
      }
    },
    watch: {
      isUploading (val) {
        this.uploadingText = val ? '处理中' : '上传文件'
      }
    }
  }
</script>

<style lang="scss" scoped>
  .assign-case-wrapper {
    .upload-wrapper {
      margin-bottom: 10px;
      .el-form-item {
        margin-bottom: 5px;
      }
      .el-form-item__label {
        color: #317eac;
      }
      li {
        font-size: 12px;
        line-height: 30px;
      }
      .el-upload-dragger {
        .el-upload__text {
          color: #97a8be;
          font-size: 12px;
          text-align: center;
        }
      }
      .upload-file-main,
      .upload-file-explain {
        float: left;
        margin-left: 10px;
        margin-right: 10px;
        /*.el-button {*/
        /*font-size: 12px;*/
        /*padding: 0;*/
        /*}*/
        /*.el-button {*/
        /*width: 68px;*/
        /*height: 28px;*/
        /*}*/
      }
    }

    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }

    /* fileName */
    .file-name {
      color: #2fa4e7;
      cursor: pointer;
      &:hover {
        text-decoration: underline;
        color: #428bca;
      }
    }
    /* dialog 强制换行 */
    .dialog-result {
      word-break: break-all;
      word-wrap: break-word;
    }
    .length-2 {
      width: 350px;
    }
  }
</style>
