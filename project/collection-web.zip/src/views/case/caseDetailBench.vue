<!-- 催收工作台 系数为1及系数为2以上 -->
<template>
  <div class="case-detail-wrapper">

    <!--停催居中div-->
    <suspend-layer v-show="suspendColl === 1" :caseId="currentCaseId" @listenSuspendStatus="listenSuspendStatus"></suspend-layer>

    <el-row v-show="!suspendColl">
      <!-- 左侧 -->
      <el-col :span="12">
        <!-- 用户基本信息展示 -->
        <el-form ref="userInfoForm" :model="userInfoForm" class="form-block" v-if="JSON.stringify(userInfoForm) !== '{}'">
          <el-form-item>
            <b class="form-block-b" style="font-size: 16px;">{{ userInfoForm.username }}</b>
            <span class="form-block-b">({{ userInfoForm.userId }}，{{ userInfoForm.gender }}，{{ userInfoForm.age }}，{{ userInfoForm.birthday }}，{{ userInfoForm.identityCard }})</span>
            <!--是v3.14只催月供，也是车贷王时，展示该样式-->
            <b class="form-block-b" style="float: right;" v-if="isMonthlyPayment && isCDW">
              <span style="display: block; line-height: 24px;">
                <span>合计欠款:</span>
                <span style="color: red;">{{ userInfoForm.totalDebt }}</span>
              </span>
              <span style="display: block; line-height: 16px; font-weight: normal; font-size: 12px;">
                <span>（{{ userInfoForm.totalDebtDesc }}）</span>
              </span>
            </b>
            <!--其他还展示之前样式-->
            <b class="form-block-b" style="float: right;"
               v-else>
              <span>合计欠款:</span>
              <span style="color: red;">{{ userInfoForm.totalDebt }}</span>
            </b>
          </el-form-item>
        </el-form>

        <!--多产品信息展示-->
        <user-info :userInfoProp="userInfoForm" :isMonthlyPayment="isMonthlyPayment" v-on:updateUserInfo="updateUserInfo" v-on:updateCaseDetail="updateCaseDetail"></user-info>

        <!--tab-->
        <tab-data class="form-block" :userInfoProp="userInfoForm"></tab-data>

        <!-- 操作信息-->
        <operate-table class="form-block" :OTProps="OTProps" :caseId="currentCaseId"></operate-table>
      </el-col>
      <!-- 右侧 -->
      <el-col :span="12">
        <!-- 按钮 start -->
        <el-form class="form-block" v-if="currentCaseId">
          <el-form-item>
            <!--{1:'待确认'},{2:'待处理'},{3:'处理中'},{4:'已处理'},{5:'已结束'}-->
            <deal-complain style="float: left;" v-if="userInfoForm.complainBillStatus && userInfoForm.complainBillStatus < 5"
                           :complainBillStatus="userInfoForm.complainBillStatus" :customerBillId="userInfoForm.customerBillId"></deal-complain>
            <div style="float: right;">
              <!--重点关注本人手机号 重点关注本人+联系人-->
              <focus-phone ref="focusPhone"></focus-phone>
              <el-button type="primary" size="mini" @click="openAddContact">增加联系人</el-button>
              <span>已选择{{ multipleSelection.length }}人</span>
              <el-button type="primary" size="mini" @click="batchCall">批量外呼</el-button>
              <!--停催激活案件-->
              <active-suspend ref="activeSuspend" :caseId="currentCaseId" @listenSuspendStatus="listenSuspendStatus"></active-suspend>
            </div>
          </el-form-item>
        </el-form>
        <!-- 按钮 end -->

        <!-- 通讯录表格 start -->
        <div class="form-block call-table" ref="callTableBox">
          <water-mark :displayName="displayName" :userId="userId" :boxWidth="callTableWidth" :boxHeight="callTableHeight"></water-mark>
          <table ref="callTable" width="100%" min-height="100px" border="1" cellspacing="0" cellpadding="0" v-loading="callMsg.listLoading">
            <tr>
              <th width="30px">
                <input type="checkbox" :checked="isCheckedAll" @change="handleSelectAll">
              </th >
              <th width="30px">序号</th>
              <th width="100px">姓名</th>
              <th width="120px">手机</th>
              <!--<th width="60px" style="cursor: pointer;" @click="getCallTableData((timesOrder ++) % 2 === 1 ? 'times desc' : 'times asc')">-->
                <!--通话次数-->
                <!--<i class="el-icon-caret-top" v-show="timesOrder % 2 === 1"></i>-->
                <!--<i class="el-icon-caret-bottom" v-show="timesOrder % 2 === 0"></i>-->
              <!--</th>-->
              <!--<th width="80px">最近联系</th>-->
              <!--<th width="60px" style="cursor: pointer;" @click="getCallTableData((latestCallAtOrder ++) % 2 === 1 ? 'latestCallAt desc' : 'latestCallAt asc')">-->
                <!--接通次数/拨打次数-->
                <!--<i class="el-icon-caret-top" v-show="latestCallAtOrder % 2 === 1"></i>-->
                <!--<i class="el-icon-caret-bottom" v-show="latestCallAtOrder % 2 === 0"></i>-->
              <!--</th>-->
              <th style="cursor: pointer;" @click="getCallTableData((resultDescOrder ++) % 2 === 1 ? 'resultDesc desc' : 'resultDesc asc')">
                电话结果
                <i class="el-icon-caret-top" v-show="resultDescOrder % 2 === 1"></i>
                <i class="el-icon-caret-bottom" v-show="resultDescOrder % 2 === 0"></i>
              </th>
              <th>备注</th>
            </tr>
            <!--8 => 30-->
            <tr v-for="(item, index) in callTableData" :key="index" :class="{'bg_red': item.order === 30}">
              <td>
                <input type="checkbox" :checked="item.isChecked" @change="handleSelect(item, index)" :disabled="item.forbstatus === 1">
              </td>
              <td>{{ index + 1 }}</td>
              <td>{{ item.name }}</td>
              <td>
                <!--禁用 或者 停催-->
                <span v-if="item.forbstatus || suspendColl === 1" style="color: #999;">{{ item.phone }}</span>
                <span v-else class="file-name" @click="singleCallDetail(item)">{{ item.phone }}</span>
                <span>（{{ item.location }}）</span>
              </td>
              <!--<td>{{ item.times }}</td>-->
              <!--<td>{{ item.latestCallAt }}</td>-->
              <!--<td>-->
                <!--<span v-if="item.callTimes">{{ item.connectedTimes || 0 }}</span>-->
                <!--<span v-if="item.callTimes">/</span>-->
                <!--<span>{{ item.callTimes }}</span>-->
              <!--</td>-->
              <td>{{ item.resultDesc }}</td>
              <td>
                <span class="file-name" v-if="!item.forbstatus" @click="openCollectionRecord(item)">催记</span>
                <span class="file-name" v-if="item.forbstatus && showSelectObj.isShowActive && !suspendColl" @click="activeMobilephone(item)">激活</span>
                {{ item.memo }}
              </td>
            </tr>
          </table>
        </div>
        <!-- 通讯录表格 end -->
      </el-col>
    </el-row>

    <!-- 增加联系人 弹窗 start -->
    <el-dialog title="增加联系人" :visible.sync="dialogAddContact" @close="dialogAddContactClose">
      <el-form :model="addContactForm" :rules="addContactRules" ref="addContactForm" label-width="120px">
        <el-form-item label="关系：" prop="relationId">
          <el-radio-group v-model="addContactForm.relationId">
            <el-radio :label="1">本人</el-radio>
            <el-radio :label="2">家人</el-radio>
            <el-radio :label="3">朋友</el-radio>
            <el-radio :label="4">同事</el-radio>
            <el-radio :label="5">公司</el-radio>
            <el-radio :label="99">其他</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="联系人姓名：" prop="contactName">
          <el-input v-model="addContactForm.contactName" auto-complete="off"></el-input>
        </el-form-item>

        <el-form-item label="联系号码：" prop="phone">
          <el-input v-model="addContactForm.phone" auto-complete="off"></el-input>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogAddContactCancel">取 消</el-button>
        <el-button type="primary" @click="dialogAddContactConfirm" :loading="addContactLoading">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 增加联系人 弹窗 end -->

    <!--批量外呼-->
    <add-project :PMProps="PMProps"></add-project>

    <!--催记弹窗-单呼-->
    <collection-record v-if="Number(callRatio) === 1" :userName="userInfoForm.username" :productId="productId" :CRProps="CRProps" :CRData="CRData" :currentVoicePath="currentVoicePath" :currentConnect="currentConnect"
                       :caseId="currentCaseId" :callRecordId="callRecordId" v-on:updateOT="updateOT"></collection-record>
    <!--&lt;!&ndash;催记弹窗-批呼&ndash;&gt;-->
    <collection-record-batch v-if="Number(callRatio) > 1" :userName="userInfoForm.username" :productId="productId" :CRProps="CRProps" :CRData="CRData" :currentVoicePath="currentVoicePath"
                             :caseId="currentCaseId" :callRecordId="callRecordId" v-on:updateOT="updateOT"></collection-record-batch>

    <!--小按钮-->
    <div class="small-box" @click="smallBtn" v-show="isShowSmallBox">{{ currentCRInfo.name }}{{ currentCRInfo.phone }}</div>

    <!--批呼刚进来的遮罩层-->
    <!--<div v-loading.fullscreen.lock="fullscreenLoading" element-loading-text="拼命拨打电话中"></div>-->
    <div :class="{'loading-mask': fullscreenLoading}" v-loading="fullscreenLoading" element-loading-text="拼命拨打电话中" element-loading-background="rgba(255, 255, 255, 0.8)"></div>
    <!--催收工作台-->
    <bench-dialog ref="benchDialog" @listenStart="listenStart" @listenPauseOrContinue="listenPauseOrContinue" @listenCallRatio="listenCallRatio"
                  @listenPauseBatch="pauseTask" @listenContinueBatch="continueTask" @listenStopBatch="stopTask" @listenResetBatch="listenResetBatch"></bench-dialog>

    <!--每日提醒-->
    <!--<div class="day-remind" @click="dayRemindBtn" v-show="!isShowDayRemind">
      <i class="el-icon-warning"></i>
      今日{{ currentRemindList.length }}个提醒
    </div>-->

    <!--<el-dialog title="今日提醒" :visible.sync="isShowDayRemind">
      <el-table :data="currentRemindList" style="width: 100%">
        <el-table-column align="center" label="联系人姓名">
          <template slot-scope="scope">
            <span class="imitate-a-label" @click="openCaseDetailById(scope.row)">{{ scope.row.contactName }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="remindTime" label="提醒时间"></el-table-column>
      </el-table>
    </el-dialog>-->

    <!--断开Web Socket-->
    <!--<el-button class="close-session" type="primary" size="mini" @click="handleCloseSession">断开WebSocket</el-button>-->
    <!--手动弹窗-->
    <div class="manual-trigger">
      <el-button v-if="!isDisabledManualTrigger" type="warning" size="mini" @click="handleManualTrigger">
        <div>已接通，未弹窗</div>
        <div>手动弹窗</div>
      </el-button>
      <el-button v-else type="warning" size="mini" disabled>{{ downCount }}</el-button>
    </div>
    <!--催收工作台控制模块-->
    <div class="monitor-layer">
      <div v-if="Number(callRatio) === 1" :class="[ isShowCallBtn ? 'monitor-msg' : 'monitor-msg-no']">
        <span>应呼叫:{{ phoneList.length || 0 }}</span>
        <span>已呼叫:{{ currentCallingCount || 0 }}</span>
        <span v-if="currentCallStatus === 'STATUS_ON_RING'">呼叫中:1</span>
        <span v-else>呼叫中:0</span>
        <!--<span>等待接听:{{ monitorData.ivrCallNum || 0  }}</span>-->
      </div>
      <div v-if="Number(callRatio) > 1" :class="[ isShowCallBtn ? 'monitor-msg' : 'monitor-msg-no']">
        <span>应呼叫:{{ monitorData.totalNum || 0 }}</span>
        <span>已呼叫:{{ monitorData.alreadyCallNum || 0 }}</span>
        <span>呼叫中:{{ monitorData.onCallNum || 0  }}</span>
        <!--<span>等待接听:{{ monitorData.ivrCallNum || 0  }}</span>-->
      </div>
      <div class="call-btn" style="height: 38px;">
        <div v-if="Number(callRatio) === 1 && pauseOrContinue && pauseOrContinue !== 'stop'">
          <el-button type="primary" size="mini" @click="pauseTaskSingle" v-show="pauseOrContinue === 'continue'">暂停</el-button>
          <el-button type="primary" size="mini" @click="continueTaskSingle" v-show="pauseOrContinue === 'pause'">继续</el-button>
          <el-button type="primary" size="mini" @click="stopTaskSingle">停止</el-button>
        </div>
        <div v-if="Number(callRatio) > 1 && resetBatch === 'start'">
          <el-button type="primary" size="mini" @click="answerNext">接听下一个<span>({{ monitorData.ivrCallNum  }})</span></el-button>
          <el-button type="primary" size="mini" @click="pauseTask" v-show="!isPause">暂停</el-button>
          <el-button type="primary" size="mini" @click="continueTask" v-show="isPause">继续</el-button>
          <el-button type="primary" size="mini" @click="stopTask">停止</el-button>
        </div>
      </div>
      <div class="call-btn">
        <el-button type="primary" size="mini" @click="openBench" style="width: 100%;">催收工作台</el-button>
      </div>
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { socket, outbound } from 'utils/outbound'
  import { parseTime } from 'utils/formatDate'
  // import { base64decode } from 'utils/index'
  import { CONST_OVERDUE_LEVEL_MAP } from './caseConstant'
  import userInfo from './components/userInfo'
  import tabData from './components/tabData'
  import operateTable from './components/operateTable'
  import addProject from './components/addProject'
  import collectionRecord from './components/collectionRecord'
  import collectionRecordBatch from './components/collectionRecordBatch'
  import WaterMark from '@/components/WaterMark' // 水印
  import dealComplain from './components/dealComplain' // 水印
  import benchDialog from './components/benchDialog' // 投诉
  import focusPhone from './components/focusPhone' // 重点关注
  import activeSuspend from './components/activeSuspend' // 激活停催案件
  import suspendLayer from './components/suspendLayer' // 停催层
  //  import isEmptyObject from 'utils/index'
  import {
    URL_WEBSOCKET_SERVER, // websocket地址
    fetchCreateMulBatchTask, // 工作台批呼
    URL_BATCH_CALL_CALL_BACK, // 批呼回传地址
    fetchGetCaseInfo, // 获取用户信息 by caseId
    fetchGetCaseContactData, // 获取通讯录
    fetchAppendContactor, // 增加联系人
    fetchUpdateSmsChecked, // 更新联系人选中状态
    fetchGetSingleCallInfo, // 创建获取uuid 和 callRecordId
    fetchUpdateExecuteRecord2, // 更新通话记录
    fetchCheckCaseAndPhone, // 检查手机号能否拨打
    fetchCreateSingleTask, // 单呼
    URL_SINGLE_CALL_CALL_BACK, // 单呼回传地址
    fetchSaveCallRecord, // 创建获取recordId
    fetchGetChinessPinyin, // 获取用户姓名拼音
    // fetchUpdateExecuteRecord2, // 更新通话记录
    fetchAnswerNext, // 接听下一个
    fetchPauseTask, // 暂停
    fetchContinueTask, // 继续
    fetchStopTask, // 停止
    fetchGetCurrentRemindData, // 今日提醒
    fetchGetAnsweringResult // 获取电呼信息
  } from '../../api/case'
  import {
    fetchCallProjectCompleate // 完成一次批呼项目
  } from '../../api/call'


  export default {
    components: {
      userInfo, tabData, operateTable, addProject, collectionRecord, collectionRecordBatch, WaterMark, dealComplain, benchDialog, focusPhone, activeSuspend, suspendLayer
    },
    computed: {
      ...mapGetters([
        'currentCRInfo', // 当前催记信息
        'isSubmitted', // 提交状态
        'isShowSmallBox', // 小按钮
        'serviceNum', // 坐席
        'displayName', // 显示中文名
        'userId', // userId
        'currentTaskId', // 当前任务ID
        'showSelectObj' // 是否显示
      ]),
      productId () {
        if (this.userInfoForm && this.userInfoForm.caseProductInfoList && this.userInfoForm.caseProductInfoList.length) {
          return this.userInfoForm.caseProductInfoList[0].productId
        } else {
          return null
        }
      },
      // 是否是车贷王
      isCDW () {
        return this.userInfoForm.caseProductInfoList[0] && this.userInfoForm.caseProductInfoList[0].productId === 6
      },
      // 去呼叫下一个
      toCallNext () {
        // console.log('274------------' + this.pauseOrContinue)
        // console.log('275------------' + this.isSubmitted)
        // console.log('276------------' + this.currentCallingCount)
        // console.log('277------------' + this.currentCallingCount <= this.phoneList.length - 1)
        // console.log('278------------')
        // console.log(this.phoneList)
        // return this.pauseOrContinue === 'continue' && this.taskStatus === 'STATUS_END' && this.isSubmitted && this.currentCallingCount && this.currentCallingCount <= this.phoneList.length - 1
        // return this.pauseOrContinue === 'continue' && this.isSubmitted && this.currentCallingCount && this.currentCallingCount <= this.phoneList.length - 1
        return this.pauseOrContinue === 'continue' && this.isSubmitted && this.currentCallStatus === 'STATUS_END_CALL' && this.currentCallingCount && this.currentCallingCount <= this.phoneList.length - 1
      }
    },
    data () {
      return {
        isMonthlyPayment: true, // 催月供（本金+利息)，不催罚息 ：可配置（后端Apollo)通过接口更改
        parseTime,
        // 用户信息
        userInfoForm: {},
        mountedCount: 0, // mounted次数
        suspendColl: 2, // 0 null激活状态  1 停催状态 // 设置为大于1的值
        CONST_OVERDUE_LEVEL_MAP,

        // 勾选的人数
        multipleSelection: [],
        // 案件联系 通讯录 表格
        callTableData: [],
        callTableWidth: 0,
        callTableHeight: 0,
        callMsg: {
          listLoading: false
        },
        // 增加联系人 弹窗
        dialogAddContact: false,
        addContactLoading: false, // loading
        addContactForm: {
          relationId: '',
          contactName: '',
          phone: ''
        },
        addContactRules: {
          relationId: [
            { required: true, message: '请选择关系', trigger: 'change' }
          ],
          contactName: [
            { required: true, message: '请输入联系人名称', trigger: 'blur' }
          ],
          phone: [
            { required: true, message: '请输入联系号码', trigger: 'blur' }
          ]
        },
        callRatio: 1, // 工作台传过来的系数
        phoneList: [], // 工作台传过来的电话列表
        assignmentId: [], // 工作台传过来的任务ID
        currentCallingCount: 0,
        // 单呼
        currentConnect: false, // 当前是否接通过
        pauseOrContinue: '',
        // benchMap: {}, // 工作台map
        // currentClickTaskId: null, // 当前点击任务的id，高亮
        // 批量外呼
        aiVoice: {}, // 等待接听的对象
        ringAndCall: {}, // 高亮的对象
        resetBatch: '',
        PMProps: {},
        // 催记
        CRProps: {},
        CRData: {},
        socket: {
          url: URL_WEBSOCKET_SERVER
        },
        currentCaseId: null,
        currentUuid: null, // 当前uuid
        currentCallStatus: '', // 当前通话状态
        currentCallData: '', // 当前通话信息
        currentVoicePath: '', // 当前通话录音地址
        fullscreenLoading: false,
        OTProps: {}, // 传入操作信息的数据
        updateStr: 0,
        callRecordId: null, // 催记弹开后的当前callRecordId
        taskStatus: '', // 当前任务状态
        isPause: false, // 是否暂停
        monitorData: {}, // 监控数据

        callProjectId: null, // 当前项目id
        executeId: null, // 当前执行id
        callRecordMap: {}, // callRecordId 和 uuid 一一映射
        displayUsers: {}, // 脱敏 name 和 phone 一一映射
        isShowCallBtn: true, // 是否显示接听下一个、暂停、继续、停止按钮

        isCheckedAll: false,
        timesOrder: 0, // 通话次数规则 "times desc"通话次数降序 "times asc" 通话次数升序
        latestCallAtOrder: 0, // 最后通话时间规则 "latestCallAt desc" 最后通话时间降序 "latestCallAt asc" 最后通话时间升序
        resultDescOrder: 0, // 电话结果规则 "resultDesc desc" 电话结果降序 "resultDesc asc" 电话结果升序

        isShowDayRemind: false,
        currentRemindList: [],
        // timeFun: null
        countDown: null, // 定时器
        isDisabledManualTrigger: false,
        downCount: 3 // 倒计时 3
      }
    },
    deactivated () {
      // clearInterval(this.timeFun)
      $(window).unbind('beforeunload')
      // window.removeEventListener('beforeunload')
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      // clearInterval(this.timeFun)
      $(window).unbind('beforeunload')
      // window.removeEventListener('beforeunload')
      window.removeEventListener('resize', this.handleResize)
    },
    created () {
      this.getWithoutOverdueFeeSwitch()
    },
    mounted () {
      window.addEventListener('resize', this.handleResize)

      if (window.location.href.indexOf('/case-detail-bench') > -1) {
        document.title = '催收工作台'
      }
      // 刷新、关闭页面提醒
      //      window.onbeforeunload = function (event) {
      //        window.sessionStorage.removeItem('Collection-BatchCall')
      //        event.returnValue = "确定离开当前页面吗？"
      //      }
      //      window.onbeforeunload = function () {
      //        let n = window.event.screenX - window.screenLeft
      //        let b = n > document.documentElement.scrollWidth - 20
      //        if (b && window.event.clientY < 0 || window.event.altKey) {
      //          window.event.returnValue = "是否关闭？"
      //          window.sessionStorage.removeItem('Collection-BatchCall')
      //        }else{
      //          window.sessionStorage.removeItem('Collection-BatchCall')
      //        }
      //      }
      //      window.addEventListener('beforeunload', function (event) {
      //        window.sessionStorage.removeItem('Collection-BatchCall')
      //        event.returnValue = "确定离开当前页面吗？"
      //      })
      // todo 先注释
      $(window).bind('beforeunload', function () {
        return''
      })

      // if (!window.sessionStorage.getItem('Collection-BatchCall')) {
      //   window.close()
      // }
      // todo 先注释
      // this.fullscreenLoading = true
      // 建立websocket链接
      this.initWebSocket()

      // 每日提醒 3mins调一次
      // this.getCurrentRemindData()
      /* let _this = this
      _this.timeFun = setInterval(function () {
        _this.getCurrentRemindData()
      }, 180000) */
    },
    methods: {
      // 获取忽略逾期滞纳金开关（V3.14）
      async getWithoutOverdueFeeSwitch () {
        const { data } = await fetchGetWithoutOverdueFeeSwitch()
        if (data.errorCode === 0) {
          this.isMonthlyPayment = data.data
        }
      },
      // 断开web socket
      handleCloseSession () {
        outbound.closeSession()
      },
      // 监听工作台 -开始按钮
      listenStart (data, callRatio, assignmentId) {
        this.fullscreenLoading = true
        // console.log('430---------------')
        // console.log(data)
        this.phoneList = data
        this.callRatio = callRatio
        this.assignmentId = assignmentId
        // 批呼 直接开始呼叫
        // todo 系数
        if (Number(this.callRatio) === 1) {
          // 单呼
          this.currentCallingCount = 0
          this.singleCall(this.phoneList[this.currentCallingCount])
        } else if (Number(this.callRatio) > 1) {
          // 批呼
          this.createSingleToBatchTask()
        }
      },
      handleResize () {
        this.$refs.callTable.style.width = this.$refs.callTableBox.clientWidth - 8 + 'px'
        this.callTableWidth = this.$refs.callTable.clientWidth - 8
        this.callTableHeight = this.$refs.callTable.clientHeight
        this.$refs.callTableBox.style.height = this.callTableHeight + 12 +'px'
      },
      // 每日提醒 3mins调一次
      getCurrentRemindData () {
        fetchGetCurrentRemindData()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              // console.log(res.data)
              this.currentRemindList = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 每日提醒
      dayRemindBtn () {
        this.isShowDayRemind = true
      },
      // 跳转到案件详情
      openCaseDetailById (val) {
        window.open('#/case-detail/' + val.caseId)
      },
      // 获取用户信息 by caseId
      getUserInfoByCaseId () {
        fetchGetCaseInfo(this.currentCaseId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.userInfoForm = res.data
              this.suspendColl = this.userInfoForm.suspendColl
              // this.$refs.activeSuspend.status = this.userInfoForm.suspendColl
              document.title = this.userInfoForm.username + '-案件详情'
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 监听来自子组件的事件-更新用户信息
      updateUserInfo () {
        this.getUserInfoByCaseId()
      },
      // 监听来自子组件的事件-更新欠款信息
      updateCaseDetail () {
        this.getUserInfoByCaseId()
      },
      // 监听来自子组件的事件-催记记录更新
      updateOT () {
        let _this = this
        _this.updateStr += 1
        _this.OTProps = {isUpdate: 'update' + this.updateStr}
        // 同时更新通讯录
        _this.callMsg.listLoading = true
        setTimeout(function () {
          _this.getCallTableData()
        }, 1000)
      },
      // 激活手机号
      activeMobilephone(val) {
        let _this = this
        _this.callMsg.listLoading = true
        fetchActiveMobilephone(val.id, currentCaseId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              setTimeout(function () {
                _this.getCallTableData()
              }, 1000)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取通讯录表格数据
      getCallTableData (order) {
        this.callMsg.listLoading = true
        fetchGetCaseContactData(this.currentCaseId, order)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              let arr = []
              this.callTableData = res.data.map(item => {
                if (item.smsChecked) {
                  item.isChecked = true
                  arr.push(item)
                }
                return item
              })
              // 判断是否全勾选
              this.isCheckedAll = arr.length === this.callTableData.length
              // 计算勾选数
              this.multipleSelection = arr
            }
            this.callMsg.listLoading = false
            // 更新dom，table宽度、高度变化，canvas变化
            this.$nextTick(() => {
              this.$refs.callTable.style.width = this.$refs.callTableBox.clientWidth - 8 + 'px'
              this.callTableWidth = this.$refs.callTable.clientWidth - 8
              this.callTableHeight = this.$refs.callTable.clientHeight
              this.$refs.callTableBox.style.height = this.callTableHeight + 12 +'px'
            })
          })
          .catch(error => {
            console.log(error)
            this.callMsg.listLoading = false
          })
      },
      // 单选
      handleSelect (item, index) {
        // console.log(item.isChecked)
        // 切换是否勾选
        this.callTableData[index].isChecked = !this.callTableData[index].isChecked
        // 计算总的勾选项
        let arr = []
        this.callTableData.map(item => {
          if (item.isChecked) {
            arr.push(item)
          }
        })
        this.multipleSelection = arr
        // 判断是否全部勾选
        this.isCheckedAll = this.callTableData.length === arr.length
        // 请求
        let contactIds = item.id.toString().split(',')
        let smsChecked = item.isChecked ? 1 : 0 // 是否选中：0 未选中；1 选中
        fetchUpdateSmsChecked(this.currentCaseId, JSON.stringify(contactIds), smsChecked)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              console.log('更新联系人选中状态')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 全选
      handleSelectAll () {
        let contactIds = []
        // console.log(this.isCheckedAll)
        // 切换是否勾选
        this.isCheckedAll = !this.isCheckedAll
        if (this.isCheckedAll) {
          // 计算勾选数
          this.multipleSelection = this.callTableData
          this.callTableData.map(item=> {
            item.isChecked = true
            contactIds.push(item.id)
            return item
          })
        } else {
          // 计算勾选数
          this.multipleSelection = []
          this.callTableData.map(item => {
            item.isChecked = false
            contactIds.push(item.id)
            return item
          })
        }
        let smsChecked = this.isCheckedAll ? 1 : 0 // 是否选中：0 未选中；1 选中
        fetchUpdateSmsChecked(this.currentCaseId, JSON.stringify(contactIds), smsChecked)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              console.log('更新联系人选中状态')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // ****************弹窗 增加联系人 ******************
      // 点击修改信息按钮
      openAddContact () {
        this.dialogAddContact = true
      },
      // 增加联系人 确认按钮
      dialogAddContactConfirm () {
        this.$refs['addContactForm'].validate((valid) => {
          if (valid) {
            this.addContactLoading = true
            let appendContactVO = {
              caseId: this.currentCaseId,
              contactName: this.addContactForm.contactName,
              phone: 	this.addContactForm.phone,
              relationId: this.addContactForm.relationId
            }
            fetchAppendContactor(JSON.stringify(appendContactVO))
              .then(response => {
                let res = response.data
                if (res.errorCode === 0) {
                  // 获取案件联系表格数据
                  this.getCallTableData()
                  // 催记记录更新
                  this.OTProps = {isUpdate: 'update1111'}
                  this.$message.success('新增联系人成功')
                }
                this.dialogAddContact = false
                this.addContactLoading = false
              })
              .catch(error => {
                console.log(error)
                this.addContactLoading = false
              })
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      // 增加联系人 取消按钮
      dialogAddContactCancel () {
        // 重置
        this.$refs['addContactForm'].resetFields()
        this.dialogAddContact = false
      },
      // 关闭弹窗回调
      dialogAddContactClose () {
        this.$refs['addContactForm'].resetFields()
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            console.log('submit!')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      // ****************弹窗 批量外呼 ******************
      batchCall () {
        this.PMProps = {
          dialogVisible: true,
          caseId: this.currentCaseId
        }
      },
      // 催记
      openCollectionRecord (val) {
        if (this.isSubmitted) {
          // 打开催记弹窗
          this.CRData = val
          this.CRProps = {dialogVisible: true}
          this.$store.dispatch('IsShowSmallBox', false)
          // 存储当前催记信息
          this.$store.dispatch('GetCurrentCRInfo', val)
          // 提交状态  变更为  未提交状态
          this.$store.dispatch('IsSubmitted', false)
        } else {
          if (val.id === this.currentCRInfo.id) {
            // this.CRData = val
            this.CRProps = {dialogVisible: true}
            this.$store.dispatch('IsShowSmallBox', false)
          } else {
            //            this.CRData = this.currentCRInfo
            //            this.CRProps = {
            //              dialogVisible: true
            //            }
            //            this.$store.dispatch('IsShowSmallBox', false)
            this.$message.warning('还有通话窗口未关闭！')
          }
        }
      },
      // 小按钮
      smallBtn () {
        if (this.currentCRInfo) {
          this.CRProps = {dialogVisible: true}
          this.$store.dispatch('IsShowSmallBox', false)
        }
      },
      // 监听单呼的提交-并拨打下一个
      // listenCallNext () {
      //   if (this.pauseOrContinue === 'continue' && this.currentCallingCount <= this.phoneList.length - 1) {
      //     this.singleCall(this.phoneList[this.currentCallingCount])
      //   } else {
      //     return false
      //   }
      // },
      // 监听暂停
      listenPauseOrContinue (data, phoneList, count) {
        this.pauseOrContinue = data
        // console.log('734--------------------')
        // console.log(phoneList)
        this.phoneList = phoneList
        this.currentCallingCount = count
      },
      listenResetBatch (data) {
        this.resetBatch = data
        // console.log(this.resetBatch)
      },
      // 监听系数
      listenCallRatio (data) {
        this.callRatio = data
      },
      // listenContinue (data) {
      //   console.log(data)
      //   console.log(this.isSubmitted)
      //   console.log(this.currentCallingCount <= this.phoneList.length - 1)
      //   if (data === 'continue' && this.isSubmitted && this.currentCallingCount <= this.phoneList.length - 1) {
      //     this.singleCall(this.phoneList[this.currentCallingCount])
      //   } else {
      //     return false
      //   }
      // },
      // 使用sockjs，替代原生的websocket
      initWebSocket () {
        // 建立websocket连接
        // todo
        socket.serviceNum = this.serviceNum
        // socket.serviceNum = 'S1003'
        if (socket.stompClient == null) {
          outbound.initWebSocket(this.socket.url, this.renderBcResult, this.renderP2pResult, this.successCallback, this.checkSocketClose)
          console.log('建立websocket连接')
        }
      },
      // 成功回调
      successCallback () {
        console.log('websocket连接成功')
      },
      // TCP链接断开，提醒用户，退出重新登录
      checkSocketClose () {
        this.$alert('websocket断开，请点击确定重连TGP', '提示', {
          confirmButtonText: '确定',
          callback: action => {
            console.log('重新连接TGP')
            socket.stompClient = null
            this.initWebSocket()
          }
        })
      },
      // 获取状态
      renderBcResult (data) {
        // console.log(data)
      },
      // 获取状态
      renderP2pResult (data) {
        if (data.body) {
          let data1 = JSON.parse(data.body)
          let type = data1.resonseType
          let res = data1.responseData
          if (res.status) {
            // 设置当前电话状态
            this.currentCallStatus = res.status
            this.currentCallData = res
            // 高亮增删Collection-CurrentCRInfo
            // if (res.status === 'STATUS_ON_RING') {
            //   let data = {}
            //   data.assignmentId = this.assignmentId
            //   data.phone = res.phone
            //   this.$set(this.ringAndCall, res.uuid, data)
            //   this.$set(this.$refs.benchDialog.ringAndCall, res.uuid, data)
            // }
            // if (res.status === 'STATUS_END_CALL') {
            //   this.ringAndCall[res.uuid] && this.$delete(this.ringAndCall, res.uuid)
            //   this.$refs.benchDialog.ringAndCall[res.uuid] && this.$delete(this.$refs.benchDialog.ringAndCall, res.uuid)
            // }
            // // 等待接听增删
            // if (Number(this.callRatio) > 1) {
            //   if (res.status === 'STATUS_ON_RING') {
            //     let data = JSON.parse(res.data)
            //     data.createTime = parseTime(new Date(), 'HH:mm:ss')
            //     this.$set(this.aiVoice, res.uuid, data)
            //     this.$set(this.$refs.benchDialog.aiVoice, res.uuid, data)
            //   }
            //   if (res.status === 'STATUS_ON_CALL' || res.status === 'STATUS_END_CALL') {
            //     this.aiVoice[res.uuid] && this.$delete(this.aiVoice, res.uuid)
            //     this.$refs.benchDialog.aiVoice[res.uuid] && this.$delete(this.$refs.benchDialog.aiVoice, res.uuid)
            //   }
            // }
            // 高亮增删
            // if (res.status === 'STATUS_ON_RING') {
            //   let data = {}
            //   data.assignmentId = this.assignmentId
            //   data.phone = res.phone
            //   this.$set(this.ringAndCall, res.uuid, data)
            //   this.$set(this.$refs.benchDialog.ringAndCall, res.uuid, data)
            // }
            // if (res.status === 'STATUS_END_CALL') {
            //   for (let i in this.ringAndCall) {
            //     if (res.uuid === i) {
            //       this.$delete(this.ringAndCall, res.uuid)
            //       this.$delete(this.$refs.benchDialog.ringAndCall, res.uuid)
            //     }
            //   }
            // }
            // 等待接听增删
            // if (res.status === 'STATUS_ON_RING' || res.status === 'STATUS_AI_VOICE') {
            // if (Number(this.callRatio) > 1) {
            //   if (res.status === 'STATUS_ON_RING') {
            //     let data = JSON.parse(res.data)
            //     data.createTime = parseTime(new Date(), 'HH:mm:ss')
            //     this.$set(this.aiVoice, res.uuid, data)
            //     this.$set(this.$refs.benchDialog.aiVoice, res.uuid, data)
            //   }
            //   if (res.status === 'STATUS_ON_CALL' || res.status === 'STATUS_END_CALL') {
            //     for (let i in this.aiVoice) {
            //       if (res.uuid === i) {
            //         this.$delete(this.aiVoice, res.uuid)
            //         this.$delete(this.$refs.benchDialog.aiVoice, res.uuid)
            //       }
            //     }
            //   }
            //   if (res.status === 'STATUS_END_CALL') {
            //     for (let i in this.ringAndCall) {
            //       if (res.uuid === i) {
            //         this.$delete(this.ringAndCall, res.uuid)
            //         this.$delete(this.$refs.benchDialog.ringAndCall, res.uuid)
            //       }
            //     }
            //   }
            // }
          }
          if (res.taskStatus) {
            this.taskStatus = res.taskStatus
            if (res.taskStatus === 'STATUS_END' && Number(this.callRatio) === 1 && this.currentCallingCount === this.phoneList.length) {
              console.log('系数1电话全部结束后，按钮变为开始，任务列表高亮清除，通讯录列表高亮清除')
              this.$message.success('当前批呼任务已结束')
              this.pauseOrContinue = ''
              this.currentCallingCount = 0
              this.phoneList = []
              this.$refs.benchDialog.setIsStart(0, this.currentCallingCount, this.callRatio)
            }
            if (res.taskStatus === 'STATUS_END' && Number(this.callRatio) > 1) {
              console.log('系数2及以上电话全部结束后，按钮变为开始，任务列表高亮清除，通讯录列表高亮清除')
              this.$message.success('当前批呼任务已结束')
              // console.log(this.resetBatch)
              this.currentCallingCount = 0
              this.phoneList = []
              this.$refs.benchDialog.setIsStart(0, this.currentCallingCount, this.callRatio)
            }
          }
          if (type === 'monitor') {
            this.$store.dispatch('GetCurrentTaskId', res.taskId)
            this.monitorData = res
          }

          // {"resonseType":"error","responseData":"ip :172.17.16.2 serviceNum: S1003 没有注册!"}
          if (type === 'error') {
            this.$message.error(res)
          }

          // call_result
          if (type === 'call_result') {
            if (Number(this.callRatio) === 1) {
              let data = JSON.parse(res)
              // 单呼，同时开启多个标签页，一个电话结束后，另一个标签页没发起单呼也收到了call_result状态，发送给后端的数据就不对了，所以做容错校验
              // 1、如果没发起单呼，currentUuid为null 2、如果发起单呼，currentUuid获取到，与websocket推过来的不一致
              if (this.currentUuid !== data.uuid) {
                return false
              }
              this.currentVoicePath = data.connect ? data.voicePath : '' // 当前通话录音地址
              this.currentConnect = data.connect // 是否接通
              let queryParams = {
                callProjectId: -1,
                executeId: -1,
                callRecordId: this.callRecordId,
                contactNum: JSON.parse(data.data).realPhone, // 传入当前电话，不然外地加0，后端没法处理
                caseId: JSON.parse(data.data).caseId,
                callCenterCallId: data.uuid,
                hangupType: data.hangUpType,
                callTime: data.chatDuration,
                ringingTime: data.ringDuration,
                ivrTime: data.ivrDuration,
                connected: data.connect,
                unAnswerType: data.unAnswerType,
                recordPath: data.voicePath
              }
              fetchUpdateExecuteRecord2(JSON.stringify(queryParams))
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0) {
                  }
                })
                .catch(error => {
                  console.log(error)
                })
            } else if (Number(this.callRatio) > 1) {
              let data = JSON.parse(res)
              // console.log(data)
              this.currentVoicePath = data.voicePath // 当前通话录音地址
              let queryParams = {
                // todo assignmentId
                // callProjectId: this.callProjectId,
                // executeId: this.executeId,
                callProjectId: this.assignmentId,
                executeId: this.assignmentId,
                // todo callRecordId推送过来的
                // callRecordId: this.callRecordMap[data.uuid].callRecordId,
                callRecordId: JSON.parse(data.data).callRecordId,
                contactNum: JSON.parse(data.data).realPhone, // 传入当前电话，不然外地加0，后端没法处理
                caseId: JSON.parse(data.data).caseId,
                callCenterCallId: data.uuid,
                hangupType: data.hangUpType,
                callTime: data.chatDuration,
                ringingTime: data.ringDuration,
                ivrTime: data.ivrDuration,
                connected: data.connect,
                unAnswerType: data.unAnswerType,
                recordPath: data.voicePath
              }
              fetchUpdateExecuteRecord2(JSON.stringify(queryParams))
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0) {
                  }
                })
                .catch(error => {
                  console.log(error)
                })
            }
          }
        }
      },
      singleCallDetail () {
        this.$message.warning('正在进行催收工作台任务，不能进行单呼操作！')
      },
      // 单呼
      singleCall (val) {
        if (this.isSubmitted) {
          console.log('开始创建单呼任务')
          this.checkCaseAndPhone(val)
        } else {
          // console.log(val)
          // console.log(this.currentCRInfo)
          if (val.id === this.currentCRInfo.id) {
            this.CRData = val
            this.CRProps = {dialogVisible: true}
            this.$store.dispatch('IsShowSmallBox', false)
          } else {
            //            this.CRData = this.currentCRInfo
            //            this.CRProps = {
            //              dialogVisible: true
            //            }
            //            this.$store.dispatch('IsShowSmallBox', false)
            this.$message.warning('还有通话窗口未关闭！')
          }
        }
      },
      // 检查手机号能否拨打
      checkCaseAndPhone (val) {
        // console.log(val)
        // let phone = base64decode(val.realPhone)
        let phone = val.realPhone
        fetchCheckCaseAndPhone(val.caseId, phone, this.assignmentId, val.order)
          .then(response => {
            let res = response.data
            // 只有0表示成功，只有0且data为true才表示能呼叫
            if (res.errorCode === 0 && res.data) {
              this.getUuidAndCallRecordId(val, phone)
            } else {
              // 当前手机号不能拨打 且 不是最后一通电话，直接进行下一通电话的拨打
              this.currentCallingCount += 1
              this.currentCallingCount <= this.phoneList.length - 1 && this.singleCall(this.phoneList[this.currentCallingCount])
              // 当前手机号不能拨打 且 是最后一通电话，直接结束任务
              if (this.currentCallingCount === this.phoneList.length) {
                console.log('系数1电话全部结束后，按钮变为开始，任务列表高亮清除，通讯录列表高亮清除')
                this.$message.success('当前批呼任务已结束')
                this.pauseOrContinue = ''
                this.currentCallingCount = 0
                this.phoneList = []
                this.$refs.benchDialog.setIsStart(0, this.currentCallingCount, this.callRatio)
              }
            }
          })
          .catch(error => {
            console.log(error)
            // this.timeLimit = true
            this.$store.dispatch('TimeLimit', true)
          })
      },
      // 单呼获取uuid及callRecordId
      getUuidAndCallRecordId (val, phone) {
        let calledName = val.name
        let caseId = val.caseId
        fetchGetSingleCallInfo(caseId, phone, calledName)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.callRecordId = res.data.callRecordId
              this.currentUuid = res.data.uuid
              this.createSingleTask(val, phone, caseId)
            } else {
              // this.timeLimit = true
              this.$store.dispatch('TimeLimit', true)
            }
          })
          .catch(error => {
            console.log(error)
            // this.timeLimit = true
            this.$store.dispatch('TimeLimit', true)
          })
      },
      // 创建单呼任务
      createSingleTask (val, phone, caseId) {
        if (!this.serviceNum) {
          this.$message.error('坐席为空，请填写完整')
          // this.timeLimit = true
          this.$store.dispatch('TimeLimit', true)
          return false
        }
        // this.currentPhone = phone
        // let userDTO = "{\"phone\":\"" + phone + "\",\"data\":\"\",\"uuid\":\"" + this.currentUuid +"\"}"
        let userDTO = "{\"phone\":\"" + phone + "\",\"data\":{\"caseId\":" + caseId + ",\"realPhone\":\"" + phone + "\",\"assignmentId\":" + this.assignmentId + "},\"uuid\":\"" + this.currentUuid +"\"}"
        let resultUrl = ''
        if (window.location.host.indexOf('localhost') > -1) {
          resultUrl = URL_SINGLE_CALL_CALL_BACK // 单呼回传地址
        } else {
          let host = window.location.host.indexOf('t') > -1 ? 'http://' : 'https://'
          resultUrl = host + window.location.host + URL_SINGLE_CALL_CALL_BACK // 单呼回传地址
        }
        fetchCreateSingleTask(JSON.stringify(userDTO), this.serviceNum, resultUrl, caseId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              console.log('创建单呼任务成功')
              // todo 解决上一通电话接通提交成功，当前电话网络波动，录音地址还是沿用上一次的记录，重置
              this.currentVoicePath = '' // 当前通话录音地址
              // this.currentConnect = false // 当前是否接通过
              // 打开催记弹窗
              this.CRData = val
              this.CRProps = {dialogVisible: true}
              this.$store.dispatch('IsShowSmallBox', false)
              // 存储当前催记信息
              this.$store.dispatch('GetCurrentCRInfo', val)
              // 提交状态  变更为  未提交状态
              this.$store.dispatch('IsSubmitted', false)
              // this.timeLimit = true
              this.$store.dispatch('TimeLimit', true)

              /****************todo*****************/
              // 拨打成功一次加一
              this.currentCallingCount += 1
              // Number(this.callRatio) === 1 && this.currentCallingCount === this.phoneList.length - 1
              this.$refs.benchDialog.setIsStart(1, this.currentCallingCount, this.callRatio) // 变更按钮
              // 获取当前案件id
              // this.currentCaseId = 5076796
              this.currentCaseId = val.caseId
              this.$nextTick(() => {
                this.$refs.focusPhone.getIsFocus(this.currentCaseId)
              })
              // this.currentVoicePath = val.voicePath
              // 电话接听后，获取uuid，然后得到对应的callRecordId
              // this.callRecordId = this.callRecordMap[val.uuid].callRecordId
              this.fullscreenLoading = false
              // 通过caseId获取用户信息
              this.getUserInfoByCaseId()
              // 获取案件联系表格数据
              this.getCallTableData()
              // 获取催记记录列表信息
              this.updateStr += 1
              this.OTProps = {isUpdate: 'update' + this.updateStr}
            } else {
              this.$message.error(res.errorMsg)
              // this.timeLimit = true
              this.$store.dispatch('TimeLimit', true)
            }
          })
          .catch(error => {
            console.log(error)
            // this.timeLimit = true
            this.$store.dispatch('TimeLimit', true)
          })
      },
      // 完成一次批呼项目
      overBatchCallProject () {
        // todo assignmentId
        // let callProjectId = this.callProjectId
        // let executedId = this.executeId
        let callProjectId = this.assignmentId
        let executedId = this.assignmentId
        fetchCallProjectCompleate(callProjectId, executedId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              console.log('完成一次批呼项目')
              // 任务结束 清除 map
              this.callRecordMap = {}
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 创建批呼任务
      async createSingleToBatchTask () {
        let users = []
        this.phoneList.forEach(item => {
          users.push({
            // phone: base64decode(item.realPhone),
            phone: item.realPhone,
            uuid: item.uuid,
            data: {
              caseId: item.caseId,
              calledName: item.name,
              phone: item.phone,
              pinyin: item.pinyin,
              order: item.order,
              // realPhone: base64decode(item.realPhone),
              realPhone: item.realPhone,
              assignmentId: this.assignmentId
            }
          })
        })
        let controlratio = this.callRatio // 任务系数
        let resultUrl = ''
        if (window.location.host.indexOf('localhost') > -1) {
          resultUrl = URL_BATCH_CALL_CALL_BACK // 批呼回传地址
        } else {
          let host = window.location.host.indexOf('t') > -1 ? 'http://' : 'https://'
          resultUrl = host + window.location.host + URL_BATCH_CALL_CALL_BACK // 批呼回传地址
        }
        let realTimeMonitor = true // 是否开启监控
        let assignmentId = this.assignmentId// 任务id
        const response = await fetchCreateMulBatchTask(JSON.stringify(users), this.serviceNum, controlratio, resultUrl, realTimeMonitor, assignmentId)
        const res = response.data
        if (res.errorCode === 0) {
          // 批呼成功后，websocket推送状态
          console.log('开始批呼')
          this.$refs.benchDialog.setIsStartBatch(1)
          // 从benchDialog移到这里，只有成功才能看到左下角浮窗的其他按钮
          this.listenResetBatch('start')
        } else {
          this.fullscreenLoading = false
        }
      },
      // 接听下一个
      answerNext () {
        fetchAnswerNext(this.assignmentId, this.serviceNum)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              console.log('接听下一个')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 单呼-暂停
      pauseTaskSingle () {
        this.$refs.benchDialog.handlePause(this.callRatio)
      },
      // 暂停-批呼
      pauseTask () {
        this.isPause = true
        this.$refs.benchDialog.handlePause(this.callRatio, 'from')
      },
      // 单呼-继续
      continueTaskSingle () {
        this.$refs.benchDialog.handleContinue(this.callRatio)
      },
      // 继续-批呼
      continueTask () {
        this.isPause = false
        this.$refs.benchDialog.handleContinue(this.callRatio, 'from')
      },
      // 停止-单呼
      stopTaskSingle () {
        this.$refs.benchDialog.handleStop(this.callRatio)
      },
      // 停止-批呼
      stopTask () {
        this.$refs.benchDialog.handleStop(this.callRatio, 'from')
      },
      // 打开工作台
      openBench () {
        this.$refs.benchDialog.dialogVisible = true
      },
      // 监听停催状态
      listenSuspendStatus (val) {
        this.suspendColl = val
        // 获取案件联系表格数据
        this.getCallTableData()
        // 更新操作记录
        this.updateStr += 1
        this.OTProps = {isUpdate: 'update' + this.updateStr}
        // 更新dom，table宽度、高度变化，canvas变化
        this.$nextTick(() => {
          this.$refs.callTable.style.width = this.$refs.callTableBox.clientWidth - 8 + 'px'
          this.callTableWidth = this.$refs.callTable.clientWidth - 8
          this.callTableHeight = this.$refs.callTable.clientHeight
          this.$refs.callTableBox.style.height = this.callTableHeight + 12 +'px'
        })
      },
      // 手动弹窗
      async handleManualTrigger () {
        if (Number(this.callRatio) > 1) { // 只有系数为2及以上才调用接口
          let that = this
          // 接口请求，获取数据判断是否弹窗
          // this.currentCallData = res
          // console.log(this.callRatio)
          // let data1 = "{\"success\":false,\"data\":null,\"errorCode\":\"4000\",\"errorMessage\":\"暂无通话中的呼叫！\"}"
          // console.log(JSON.parse(data1))
          const { data: res } = await fetchGetAnsweringResult(this.serviceNum)
          // console.log(res)
          const { success, data, errorMessage } = JSON.parse(res.data)
          if (success) {
            this.currentCallData = {
              status: 'STATUS_ON_CALL',
              data: JSON.parse(data).data,
              uuid: JSON.parse(data).uuid,
              voicePath: JSON.parse(data).voicePath,
              connect: JSON.parse(data).connect
            }
          } else {
            this.$message.warning(errorMessage)
          }
          // let data = {
          //   caseId: 505050,
          //   callRecordId: 1111,
          //   calledName: 'sunp'
          // }
          // this.currentCallData = {
          //   status: 'STATUS_ON_CALL',
          //   data: JSON.stringify(data),
          //   voicePath: ''
          // }
          that.isDisabledManualTrigger = true
          if (that.downCount > 0) {
            that.countDown = setInterval(function () {
              that.downCount--
            }, 1000)
          }
        }
      }
    },
    watch: {
      // callRatio (val) {
      //   console.log('1227')
      //   console.log(val)
      // },
      // phoneList (val) {
      //   console.log('1231')
      //   console.log(val)
      // },
      // 去呼叫下一个
      toCallNext (val) {
        // console.log('1217------------' + val)
        // console.log('1218------------')
        // console.log(this.phoneList)
        // console.log('1221------------' + this.currentCallingCount)
        const that = this
        if (val) {
          setTimeout(function () {
            that.singleCall(that.phoneList[that.currentCallingCount])
          }, 1000)
        }
      },
      'currentCallData' (val) {
        // console.log('1244------------val.status')
        // console.log(val.status)
        // console.log('1246--------------callRatio')
        // console.log(this.callRatio)
        // 单呼
        if (val.status === 'STATUS_ON_CALL' && Number(this.callRatio) === 1) {
          // console.log(val)
          this.currentConnect = val.connect
          this.currentVoicePath = val.voicePath
        }
        // 批呼
        if (val.status === 'STATUS_ON_CALL' && Number(this.callRatio) > 1) {
          // 获取当前案件id
          this.currentCaseId = JSON.parse(val.data).caseId
          this.$nextTick(() => {
            this.$refs.focusPhone.getIsFocus(this.currentCaseId)
          })
          this.currentVoicePath = val.voicePath
          // 电话接听后，获取uuid，然后得到对应的callRecordId
          // this.callRecordId = this.callRecordMap[val.uuid].callRecordId
          // todo callRecordId 从websocket推送过来
          this.callRecordId = JSON.parse(val.data).callRecordId
          this.fullscreenLoading = false
          // 通过caseId获取用户信息
          this.getUserInfoByCaseId()
          // 获取案件联系表格数据
          this.getCallTableData()
          // 获取催记记录列表信息
          this.updateStr += 1
          this.OTProps = {isUpdate: 'update' + this.updateStr}
          // 如果有data 那么就是批呼
          let data = JSON.parse(val.data)
          // data.name = data.calledName
          data.name = data.calledName
          // data.pinyin = this.callRecordMap[val.uuid].chinessPinYin
          // data.phone = this.displayUsers[val.uuid]
          // data.pinyin = this.phoneList[data.phone].pinyin
          // data.phone = data.phone
          this.CRData = data
          this.CRProps = {dialogVisible: true}
          this.$store.dispatch('IsShowSmallBox', false)
          // 存储当前催记信息
          this.$store.dispatch('GetCurrentCRInfo', data)
          // 提交状态  变更为  未提交状态
          this.$store.dispatch('IsSubmitted', false)
        }
      },
      taskStatus (val) {
        let _this = this
        // 任务结束 且  已提交状态
        if (val === 'STATUS_END' && _this.isSubmitted) {
          _this.fullscreenLoading = false
          // _this.overBatchCallProject() // 项目完成over
          // window.sessionStorage.removeItem('Collection-BatchCall')
          // $(window).unbind('beforeunload') // 解除绑定
        }
      },
      isSubmitted (val) {
        let _this = this
        // 任务结束 且  已提交状态
        if (_this.taskStatus === 'STATUS_END' && val) {
          _this.fullscreenLoading = false
          // _this.overBatchCallProject() // 项目完成over
          // window.sessionStorage.removeItem('Collection-BatchCall')
          // $(window).unbind('beforeunload') // 解除绑定
        }
        if (_this.taskStatus !== 'STATUS_END' && val) {
          _this.fullscreenLoading = true
        }
      },
      // 监听倒计时
      downCount (val) {
        if (val === 0) {
          clearInterval(this.countDown)
          this.isDisabledManualTrigger = false
          this.downCount = 3
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .case-detail-wrapper {
    .loading-mask {
      position: fixed;
      z-index: 1000!important;
      /*background-color: rgba(255,255,255,.9);*/
      margin: 0;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      -webkit-transition: opacity .3s;
      transition: opacity .3s;
    }
    background-color: #EBF0F3;
    .length-1 {
      width: 140px;
    }

    .form-block {
      .form-block-b {
        font-size: 14px;
      }
      .el-form-item {
        margin-bottom: 0;
      }
    }
    /* fileName */
    .file-name {
      color: #2fa4e7;
      cursor: pointer;
      &:hover {
        text-decoration: underline;
        color: #428bca;
      }
    }
    /* 小按钮 */
    .small-box {
      height: 22px;
      color: #fff;
      line-height: 14px;
      text-align: center;
      font-size: 12px;
      border-radius: 4px;
      padding: 4px;
      background: #e12b31;
      cursor: pointer;
      position: fixed;
      z-index: 3;
      bottom: 0;
      right: 200px;
    }

    /* 断开web socket */
    .close-session {
      position: fixed;
      z-index: 11111;
      bottom: 180px;
      left: 10px;
    }
    /*手动弹窗*/
    .manual-trigger {
      position: fixed;
      z-index: 11111;
      bottom: 120px;
      left: 10px;
      .el-button {
        width: 120px;
      }
    }

    .monitor-layer {
      width: 270px;
      height: 100px;
      position: fixed;
      /* fullscreenLoading的z-index 10000 */
      z-index: 11111;
      bottom: 0;
      left: 0;
      /*right: 0px;*/
      margin-left: auto;
      margin-right: auto;
      background: #bbb;
      border-radius: 4px;
      .call-btn {
        padding: 5px 10px;
      }
      .monitor-msg {
        text-align: center;
        font-size: 14px;
      }
      .monitor-msg-no {
        text-align: center;
        font-size: 14px;
        /*line-height: 60px;*/
      }
    }

    /*通讯录表格*/
    .call-table {
      font-size: 12px;
      color: #333;
      text-align: center;
      line-height: 20px;
      position: relative; // 为水印做的
      table, table tr th, table tr td {
        border: 1px solid #eee;
      }
      table {
        position: absolute;
        z-index: 2;
        min-height: 25px;
        line-height: 25px;
        text-align: center;
        border-collapse: collapse;
        /*padding: 2px;*/
      }
      input[type='checkbox'] {
        cursor: pointer;
      }
    }

    /*每日提醒*/
    .day-remind {
      height: 22px;
      color: #fff;
      line-height: 14px;
      text-align: center;
      font-size: 12px;
      border-radius: 2px;
      padding: 4px;
      background: #54b4eb;
      cursor: pointer;
      position: fixed;
      right: 60px;
      bottom: 0;
    }
  }
  .bg_red {
    background: rgb(181, 236, 218);
  }
</style>
