<!--投诉工单-->
<template>
  <div class="complain-wrapper">
    <el-form :inline="true" size="small" class="filter-form">
      <el-form-item label="投诉时间：">
        <el-date-picker
          v-model="date"
          class="length-2"
          type="daterange"
          :editable="false">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="投诉类型：">
        <el-form-item>
          <el-checkbox :indeterminate="isIndeterminateType" v-model="checkAllType" @change="handleCheckAllTypeChange">全选</el-checkbox>
        </el-form-item>
        <el-form-item>
          <el-checkbox-group v-model="checkedType" @change="handleCheckedTypeChange">
            <el-checkbox v-for="item in COMPLAIN_TYPE_LIST" :label="item.code" :key="item.code">{{ item.name }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-form-item>
      <el-form-item label="状态：">
        <el-form-item>
          <el-checkbox :indeterminate="isIndeterminateStatus" v-model="checkAllStatus" @change="handleCheckAllStatusChange">全选</el-checkbox>
        </el-form-item>
        <el-form-item>
          <el-checkbox-group v-model="checkedStatus" @change="handleCheckedStatusChange">
            <el-checkbox v-for="item in COMPLAIN_STATUS_LIST" :label="item.code" :key="item.code">{{ item.name }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn" :loading="searchLoading">搜索</el-button>
        <el-button type="primary" size="small" @click="exportBtn">导出</el-button>
      </el-form-item>
    </el-form>

    <el-table :data="tableData" border style="width: 100%" :row-class-name="tableRowClassName">
      <el-table-column align="center" prop="createAt" label="投诉时间" min-width="140"></el-table-column>
      <el-table-column align="center" label="案件" min-width="50">
        <template slot-scope="scope">
          <span class="imitate-a-label" @click="openCaseDetailById(scope.row)">{{scope.row.userName}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="content" label="投诉内容" min-width="140"></el-table-column>
      <el-table-column align="center" prop="typeName" label="投诉类型" min-width="50"></el-table-column>
      <el-table-column align="center" prop="statusName" label="状态" min-width="50">
        <template slot-scope="scope">
          <!--	待确认：该投诉有受理人，但未点击“确认认领”，用红色标识。-->
          <!--	待处理：该投诉有受理人，但最新的处理结果不是“已和客户沟通，并妥善处理投诉”，用红色标识。-->
          <span v-if="scope.row.status === 1 || scope.row.status === 2" style="color: red;">{{ scope.row.statusName }}</span>
          <span v-else>{{ scope.row.statusName }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="receivePersonName" label="受理人" min-width="50"></el-table-column>
      <el-table-column align="center" prop="receiveInstitutionName" label="机构" min-width="50"></el-table-column>
      <el-table-column align="center" prop="processDuration" label="处理时长" min-width="140">
        <template slot-scope="scope">
          <!--超过72小时，标红-->
          <span v-if="scope.row.processDurationStatus >= 3" style="color: red;">{{ scope.row.processDuration }}</span>
          <span v-else>{{ scope.row.processDuration }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="recentProcessDate" label="最近处理时间" min-width="140"></el-table-column>
      <el-table-column align="center" prop="recentProcessResult" label="最近处理结果" min-width="140">
        <template slot-scope="scope">
          <!--	最近处理结果默认只展示18个字，多余的以……代替。悬停时，气泡展示所有备注内容。-->
          <el-tooltip class="item" effect="dark" :content="scope.row.recentProcessResult" placement="top"
                      v-if="scope.row.recentProcessResult.length > 18">
            <span>{{ scope.row.recentProcessResult.substr(0, 18) + '......' }}</span>
          </el-tooltip>
          <span v-else>{{ scope.row.recentProcessResult }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="操作" min-width="100">
        <template slot-scope="scope">
          <!--	工单在待确认时，催收员展示“确认认领 + 详情”按钮。其他权限展示“变更受理人+ 详情”。-->
          <!--	工单在待处理时，催收员展示“详情”按钮。其他权限展示“变更受理人+ 详情”。-->
          <!--	工单在已处理，已结束时，所有权限展示“详情”按钮。-->
          <!--分配按钮权限 && status 小于 4-->
          <span class="imitate-a-label" @click="openDialogChange(scope.row)" v-if="showSelectObj.isShowReceivePerson && scope.row.status < 4">变更受理人</span>
          <!--不分配权限 && status 等于 1-->
          <span class="imitate-a-label" @click="confirmClaim(scope.row)" v-if="!showSelectObj.isShowReceivePerson && scope.row.status === 1">确认认领</span>
          <span class="imitate-a-label" @click="handleDetail(scope.row)">详情</span>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页开始-->
    <div class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

    <el-dialog title="变更受理人" :visible.sync="dialogChangeVisible" width="30%">
      <el-form :model="filterForm" ref="filterForm" label-width="80px">
        <!--<el-form-item v-if="showSelectObj.isShowManagerSelect">-->
          <!--<vue-el-select v-model="filterForm.managerIdList" filterable clearable placeholder="请选择催收经理" size="small"-->
                         <!--class="length-2" @visible-change="handleManagerVisibleChange">-->
            <!--<el-option-->
              <!--v-for="item in collectionManagerFilterList"-->
              <!--:key="item.id"-->
              <!--:label="item.displayName"-->
              <!--:value="item.id">-->
            <!--</el-option>-->
          <!--</vue-el-select>-->
        <!--</el-form-item>-->
        <!--<el-form-item v-if="showSelectObj.isShowGroupSelect">-->
          <!--<vue-el-select v-model="filterForm.groupIdList" filterable clearable placeholder="请选择催收组" size="small"-->
                         <!--class="length-2" @visible-change="handleGroupVisibleChange">-->
            <!--<el-option-->
              <!--v-for="item in collectionGroupFilterList"-->
              <!--:key="item.id"-->
              <!--:label="item.name"-->
              <!--:value="item.id">-->
            <!--</el-option>-->
          <!--</vue-el-select>-->
        <!--</el-form-item>-->
        <el-form-item v-if="showSelectObj.isShowPersonSelect" label="受理人" prop="collectorIdList"
                      :rules="[
                        { required: true, message: '请输入并选择受理人', trigger: 'change' }
                      ]">
          <vue-el-select v-model="filterForm.collectorIdList" filterable clearable remote placeholder="请输入并选择受理人"
                         class="length-2" @visible-change="handleCollectorVisibleChange" :remote-method="filterCollector"
                         size="small" :loading="collectorLoading">
            <el-option
              v-for="item in collectorFilterList"
              :key="item.id"
              :label="item.displayName"
              :value="item.id">
            </el-option>
          </vue-el-select>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="dialogChangeVisible = false">取 消</el-button>
        <el-button size="small" type="primary" @click="submitFilterForm">确 定</el-button>
      </span>
    </el-dialog>
    <!--投诉工单详情-->
    <complain-detail ref="complainDetail"></complain-detail>
  </div>
</template>

<script>
  import { parseTime } from '../../utils/formatDate'
  import VueElSelect from '../../components/VueElSelect'
  import complainDetail from './components/complainDetail'
  import { mapGetters } from 'vuex'
  import { COMPLAIN_TYPE, COMPLAIN_TYPE_LIST, COMPLAIN_STATUS, COMPLAIN_STATUS_LIST } from './caseConstant'
  import {
    fetchGetComplainData,
    URL_DOWNLOAD_COMPLAIN,
    fetchConfirmClaim,
    fetchChangeAddressee
  } from '../../api/case'
  import {
    fetchAllCollectorVOList,
    findAllGroupVOList,
    findAllManagerVOList,
    fetchAllMechanVOList
  } from '../../api/common'
  export default {
    name: 'complain',
    components: {
      VueElSelect, complainDetail
    },
    computed: {
      ...mapGetters([
        'showSelectObj',
        'userId'
      ])
    },
    data () {
      return {
        // 类型
        checkAllType: true,
        checkedType: [1, 2, 3, 4, 5, 6], // 默认全选
        COMPLAIN_TYPE,
        COMPLAIN_TYPE_LIST,
        isIndeterminateType: false,
        // 状态
        checkAllStatus: false,
        checkedStatus: [1, 2, 3, 4], // 默认查询除“已结束”外的所有工单
        COMPLAIN_STATUS,
        COMPLAIN_STATUS_LIST,
        isIndeterminateStatus: true,
        // 日期
        date: [],
        // 搜索
        searchLoading: false,
        tableData: [],
        // 分页对象
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [50, 100, 200],
        // 变更受理人弹窗
        dialogChangeVisible: false,
        dialogChangeForm: null,
        filterForm: {
          collectorIdList: [], // 催收员
          groupIdList: [], // 催收组
          managerIdList: [], // 催收经理
          mechanIdList: [] // 催收机构
        },
        // 催收员列表
        collectorList: [],
        collectorTempList: [], // 联动过滤后下拉列表
        collectorFilterList: [], // 过滤后下拉列表
        collectorLoading: false,
        // 催收经理列表
        collectionManagerList: [],
        collectionManagerFilterList: [], // 过滤后下拉列表
        // 催收组列表
        collectionGroupList: [],
        collectionGroupFilterList: [], // 过滤后下拉列表
        // 催收机构列表
        collectionAgenciesList: []
      }
    },
    mounted () {
      this.getTableData()
    },
    methods: {
      // 类型
      handleCheckAllTypeChange (val) {
        let arr = []
        COMPLAIN_TYPE_LIST.forEach(item => {
          arr.push(item.code)
        })
        this.checkedType = val ? arr : []
        this.isIndeterminateType = false
      },
      handleCheckedTypeChange (value) {
        let checkedCount = value.length
        this.checkAllType = checkedCount === COMPLAIN_TYPE_LIST.length
        this.isIndeterminateType = checkedCount > 0 && checkedCount < COMPLAIN_TYPE_LIST.length
      },
      // 状态
      handleCheckAllStatusChange (val) {
        let arr = []
        COMPLAIN_STATUS_LIST.forEach(item => {
          arr.push(item.code)
        })
        this.checkedStatus = val ? arr : []
        this.isIndeterminateStatus = false
      },
      handleCheckedStatusChange (value) {
        let checkedCount = value.length
        this.checkAllStatus = checkedCount === COMPLAIN_STATUS_LIST.length
        this.isIndeterminateStatus = checkedCount > 0 && checkedCount < COMPLAIN_STATUS_LIST.length
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 跳转到案件详情
      openCaseDetailById (val) {
        window.open('#/case-detail/' + val.caseId)
      },
      // 入参
      offerQueryForm () {
        let queryForm = {
          complainBeginDate: parseTime(this.date[0], 'YYYY-MM-DD'),
          complainEndDate: parseTime(this.date[1], 'YYYY-MM-DD'),
          pageIndex: this.pagData.pageNo,
          pageSize: this.pagData.pageSize,
          status: this.checkedStatus.toString(),
          type: this.checkedType.toString(),
          userId: this.userId
        }
        return queryForm
      },
      // 获取table数据
      async getTableData () {
        this.searchLoading = true
        try {
          let response = await fetchGetComplainData(this.offerQueryForm())
          let res = response.data
          // {"version":"1.0","errorCode":0,"errorMsg":null,"data":{"total":0,"data":[]}}
          if (res.errorCode === 0 && res.data) {
            this.tableData = res.data.data.map(item => {
              // 格式 3天1小时40分  或   1小时40分  或  399天1小时40分
              let l = item.processDuration.indexOf('天')
              item.processDurationStatus = l > -1 ? item.processDuration.substr(0, l) : 0
              return item
            })
            this.totalRecord = res.data.total
          } else {
            this.tableData = []
            this.totalRecord = 0
          }
          this.searchLoading = false
        } catch (e) {
          this.searchLoading = false
        }
      },
      tableRowClassName ({row, rowIndex}) {
        // 已结束 整行置灰
        if (row.status === 5) {
          return 'status-5-row'
        }
        return ''
      },
      // 搜索
      searchBtn () {
        this.getTableData()
      },
      // 导出
      exportBtn () {
        let date = parseTime(new Date(), 'YYYY-MM-DD HH：mm：ss')
        window.location.href = URL_DOWNLOAD_COMPLAIN +
          '?fileName=投诉工单' + date + '.csv' +
          '&complainBeginDate=' + this.offerQueryForm().complainBeginDate +
          '&complainEndDate=' + this.offerQueryForm().complainEndDate +
          '&pageIndex=' + this.offerQueryForm().pageIndex +
          '&pageSize=' + this.offerQueryForm().pageSize +
          '&status=' + this.offerQueryForm().status +
          '&type=' + this.offerQueryForm().type +
          '&userId=' + this.offerQueryForm().userId
      },
      // 确认认领
      async confirmClaim (row) {
        let response = await fetchConfirmClaim(row.customerBillId)
        let res = response.data
        if (res.errorCode === 0) {
          this.$message.success('确认认领成功')
          this.getTableData() // 认领成功获取表格数据
        }
      },
      // 打开变更受理人弹窗
      openDialogChange (row) {
        this.dialogChangeVisible = true
        this.dialogChangeForm = JSON.parse(JSON.stringify(row))
      },
      submitFilterForm () {
        this.$refs['filterForm'].validate((valid) => {
          if (valid) {
            this.changeAddressee()
          } else {
            return false
          }
        })
      },
      // 变更受理人
      async changeAddressee () {
        // receivePersonId
        let response = await fetchChangeAddressee(this.dialogChangeForm.customerBillId, this.filterForm.collectorIdList)
        let res = response.data
        if (res.errorCode === 0) {
          this.$message.success('变更受理人成功')
          this.dialogChangeVisible = false
        }
      },
      // 详情
      handleDetail (row) {
        this.$refs.complainDetail.dialogDetailVisible = true
        this.$refs.complainDetail.row = row
      },
      // 获取催收机构列表
      getAllMechanList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionAgenciesList && this.collectionAgenciesList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionOrganizationList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionAgenciesList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchAllMechanVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionAgenciesList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionOrganizationList', JSON.stringify(this.collectionAgenciesList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取催收经理列表
      getAllManagerList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionManagerList && this.collectionManagerList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionManagerList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionManagerList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              findAllManagerVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionManagerList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionManagerList', JSON.stringify(this.collectionManagerList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取催收组列表
      getAllGroupList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionGroupList && this.collectionGroupList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionGroupList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionGroupList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              findAllGroupVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionGroupList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionGroupList', JSON.stringify(this.collectionGroupList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取催收员列表
      getAllCollectorList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectorList && this.collectorList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionCollectorList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectorList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchAllCollectorVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectorList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionCollectorList', JSON.stringify(this.collectorList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },

      // 催收机构 下拉框出现/隐藏时触发
      handleMechanVisibleChange (visible) {
        if (visible) {
          // 用Promise保证执行顺序 先获取到数据再过滤
          // 先获取总数据
          this.getAllMechanList().then(() => {
            // 然后过滤数据
          })
        }
      },
      // 催收经理 下拉框出现/隐藏时触发
      handleManagerVisibleChange (visible) {
        if (visible) {
          this.getAllManagerList().then(() => {
            // 然后过滤数据 mechanismId
            // 机构下拉框没选 返回全部
            if (this.filterForm.mechanIdList.length === 0) {
              this.collectionManagerFilterList = JSON.parse(JSON.stringify(this.collectionManagerList))
            } else {
              this.collectionManagerFilterList = this.collectionManagerList.filter(item => {
                return this.filterForm.mechanIdList.join(',').indexOf(item.mechanismId) >= 0
              })
            }
          })
        }
      },
      // 催收组 下拉框出现/隐藏时触发
      handleGroupVisibleChange (visible) {
        if (visible) {
          this.getAllGroupList().then(() => {
            // 然后过滤数据
            // 机构、经理下拉框都没选 返回全部
            if (this.filterForm.mechanIdList.length === 0 && this.filterForm.managerIdList.length === 0) {
              this.collectionGroupFilterList = JSON.parse(JSON.stringify(this.collectionGroupList))
            } else {
              this.collectionGroupFilterList = this.collectionGroupList.filter(item => {
                // 机构、经理下拉框
                if (this.filterForm.managerIdList.length > 0) { // 经理选了 返回经理下面的组
                  return this.filterForm.managerIdList.join(',').indexOf(item.managerId) >= 0
                } else if (this.filterForm.mechanIdList.length > 0) { // 经理没选、机构选了 返回机构下面的组
                  return this.filterForm.mechanIdList.join(',').indexOf(item.mechanismId) >= 0
                } else {
                  return false
                }
              })
            }
          })
        }
      },
      // 催收员 下拉框出现/隐藏时触发
      handleCollectorVisibleChange (visible) {
        if (visible) {
          this.getAllCollectorList().then(() => {
            // 然后过滤数据 mechanismId groupId
            // 机构、经理、组下拉框都没选 返回全部
            if (this.filterForm.mechanIdList.length === 0 && this.filterForm.managerIdList.length === 0 &&
              this.filterForm.groupIdList.length === 0) {
              this.collectorTempList = JSON.parse(JSON.stringify(this.collectorList))
            } else {
              this.collectorTempList = this.collectorList.filter(item => {
                // 机构、经理、组下拉框
                if (this.filterForm.groupIdList.length > 0) { // 选了组 就取组下面的员
                  return this.filterForm.groupIdList.join(',').indexOf(item.groupId) >= 0
                } else if (this.filterForm.managerIdList.length > 0) { // 没选组 选了经理 就取经理下面的员
                  return this.filterForm.managerIdList.join(',').indexOf(item.managerId) >= 0
                } else if (this.filterForm.mechanIdList.length > 0) { // 没选组、经理，选了机构 就取机构下面的员
                  return this.filterForm.mechanIdList.join(',').indexOf(item.mechanismId) >= 0
                } else {
                  return false
                }
              })
            }
          })
        }
      },
      filterCollector (query) {
        if (query !== '') {
          this.collectorLoading = true
          this.collectorFilterList = this.collectorTempList.filter(item => {
            return item.displayName.trim().indexOf(query.trim()) > -1
          })
          this.collectorLoading = false
        } else {
          this.collectorFilterList = []
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .complain-wrapper {
    .filter-form {
      .el-form-item {
        margin-bottom: 0;
      }
      // 多选框
      .el-checkbox+.el-checkbox {
        margin-left: 14px;
      }
      /deep/ .el-checkbox__label {
        padding-left: 4px;
      }
    }
    .length-1 {
      width: 135px;
    }
    .length-2 {
      width: 240px;
    }
    /* 已结束状态，整行置灰 */
    /deep/ .el-table .status-5-row {
      background: #ddd;
    }
  }
</style>