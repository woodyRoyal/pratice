<template>
  <div class="history-case-query-wrapper">
    <!--查询条件-->
  <el-form class="filter-form" :inline="true">
    <el-form-item label="还清时间:">
      <el-date-picker
        size="small"
        v-model="datePay"
        class="length-2"
        type="daterange"
        :editable="false"
        :clearable="false"
      >
      </el-date-picker>
    </el-form-item>
    <el-form-item>
      <el-input size="small" placeholder="客户姓名" v-model="filterForm.debtorName"></el-input>
    </el-form-item>
    <el-form-item>
      <el-input size="small" placeholder="客户UID" v-model="filterForm.userId" @blur="blurLimit"></el-input>
    </el-form-item>
    <el-form-item>
      <el-input size="small" placeholder="客户手机号" v-model="filterForm.debtorPhone" @blur="blurLimit"></el-input>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" size="small" @click="searchBtn" :loading="searchLoading">搜索</el-button>
    </el-form-item>
  </el-form>

    <!--数据-->
    <el-table border stripe :max-height="tableHeight" :data="tableData" v-loading="listLoading">
      <el-table-column label="UID" align="center" prop="userId">
        <template slot-scope="scope">
           <span class="imitate-a-label" @click="openCaseDetailById(scope.row)">{{scope.row.userId}}</span>
        </template>
      </el-table-column>
      <el-table-column label="客户姓名" align="center" prop="debtorName">
        <template slot-scope="scope">
           <span class="imitate-a-label" @click="openCaseDetailById(scope.row)">{{scope.row.debtorName}}</span>
        </template>
      </el-table-column>
      <!--<el-table-column label="催收员" align="center" prop="collectorName"></el-table-column>-->
      <el-table-column label="入催日期" align="center" prop="assignDate"></el-table-column>
      <el-table-column label="还清时间" align="center" prop="repaymentDate"></el-table-column>
      <el-table-column label="入催天数" align="center" prop="assignDays"></el-table-column>
      <el-table-column label="催收次数" align="center" prop="collectTimes"></el-table-column>
      <el-table-column label="逾期产品" align="center" prop="productNames"></el-table-column>
      <el-table-column label="已还金额" align="center" prop="repaymentAmount"></el-table-column>
    </el-table>

    <!--分页对象-->
    <!-- 分页开始-->
    <div class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
  </div>
</template>

<script>
  import { fetchHistoryCaseQueryData } from '../../api/case'
  import { parseTime } from '../../utils/formatDate'
  export default {
    data () {
      return {
        searchLoading: false, // 搜索按钮防重复点击
        datePay: [new Date().getTime() - 69 * 24 * 3600 * 1000, new Date().getTime() - 62 * 24 * 3600 * 1000],
        filterForm: {
          debtorName: '',
          userId: null,
          debtorPhone: ''
        },
        // 分页对象
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [50, 100, 200],

        // 表格高度
        tableHeight: 600,
        listLoading: false,
        tableData: []
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let h = document.documentElement.clientHeight
          this.tableHeight = h - 200
        })
      },
      blurLimit () {
        if (isNaN(this.filterForm.userId)) { this.filterForm.userId = null }
        if (isNaN(this.filterForm.debtorPhone)) { this.filterForm.debtorPhone = '' }
      },
      // 搜索按钮
      searchBtn () {
        this.getTableData()
      },
      // 获取渲染数据
      getTableData () {
        this.listLoading = true // 数据加载loading
        this.searchLoading = true // 搜索按钮防重复点击loading
        let repaidCaseHisDTO = {
          userId: this.filterForm.userId || null,
          debtorName: this.filterForm.debtorName,
          endRepayDate: parseTime(this.datePay[1], 'YYYY-MM-DD'),
          startRepayDate: parseTime(this.datePay[0], 'YYYY-MM-DD'),
          debtorPhone: this.filterForm.debtorPhone
        }
        fetchHistoryCaseQueryData(JSON.stringify(repaidCaseHisDTO), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
            this.searchLoading = false
            this.listLoading = false
          })
          .catch(error => {
            this.searchLoading = false
            this.listLoading = false
            console.log(error)
          })
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 跳转到案件详情
      openCaseDetailById (val) {
        window.open('#/case-detail/' + val.caseId)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .history-case-query-wrapper {
       .length-2 {
          width:300px;
       }
   }
</style>