<!-- 案件详情 批呼 -->
<template>
  <div class="case-detail-wrapper">

    <!--停催居中div-->
    <suspend-layer v-show="suspendColl === 1" :caseId="currentCaseId" @listenSuspendStatus="listenSuspendStatus"></suspend-layer>

    <el-row v-show="!suspendColl">
      <!-- 左侧 -->
      <el-col :span="12">
        <!-- 用户基本信息展示 -->
        <el-form ref="userInfoForm" :model="userInfoForm" class="form-block" v-if="JSON.stringify(userInfoForm) !== '{}'">
          <el-form-item>
            <b class="form-block-b" style="font-size: 16px;">{{ userInfoForm.username }}</b>
            <span class="form-block-b">({{ userInfoForm.userId }}，{{ userInfoForm.gender }}，{{ userInfoForm.age }}，{{ userInfoForm.birthday }}，{{ userInfoForm.identityCard }})</span>
            <!--是v3.14只催月供，也是车贷王时，展示该样式-->
            <b class="form-block-b" style="float: right;" v-if="isMonthlyPayment && isCDW">
              <span style="display: block; line-height: 24px;">
                <span>合计欠款:</span>
                <span style="color: red;">{{ userInfoForm.totalDebt }}</span>
              </span>
              <span style="display: block; line-height: 16px; font-weight: normal; font-size: 12px;">
                <span>（{{ userInfoForm.totalDebtDesc }}）</span>
              </span>
            </b>
            <!--其他还展示之前样式-->
            <b class="form-block-b" style="float: right;"
               v-else>
              <span>合计欠款:</span>
              <span style="color: red;">{{ userInfoForm.totalDebt }}</span>
            </b>
          </el-form-item>
        </el-form>

        <!--多产品信息展示-->
        <user-info :userInfoProp="userInfoForm" :isMonthlyPayment="isMonthlyPayment" v-on:updateUserInfo="updateUserInfo" v-on:updateCaseDetail="updateCaseDetail"></user-info>

        <!--tab-->
        <tab-data class="form-block" :userInfoProp="userInfoForm"></tab-data>

        <!-- 操作信息-->
        <operate-table class="form-block" :OTProps="OTProps" :caseId="currentCaseId"></operate-table>
      </el-col>
      <!-- 右侧 -->
      <el-col :span="12">
        <!-- 按钮 start -->
        <el-form class="form-block">
          <el-form-item>
            <!--{1:'待确认'},{2:'待处理'},{3:'处理中'},{4:'已处理'},{5:'已结束'}-->
            <deal-complain style="float: left;" v-if="userInfoForm.complainBillStatus && userInfoForm.complainBillStatus < 5"
                           :complainBillStatus="userInfoForm.complainBillStatus" :customerBillId="userInfoForm.customerBillId"></deal-complain>
            <div style="float: right;">
              <!--重点关注本人手机号 重点关注本人+联系人-->
              <focus-phone ref="focusPhone"></focus-phone>
              <el-button type="primary" size="mini" @click="openAddContact">增加联系人</el-button>
              <span>已选择{{ multipleSelection.length }}人</span>
              <el-button type="primary" size="mini" @click="batchCall">批量外呼</el-button>
              <!--停催激活案件-->
              <active-suspend ref="activeSuspend" :caseId="currentCaseId" @listenSuspendStatus="listenSuspendStatus"></active-suspend>
            </div>
          </el-form-item>
        </el-form>
        <!-- 按钮 end -->

        <!-- 通讯录表格 start -->
        <div class="form-block call-table" ref="callTableBox">
          <water-mark :displayName="displayName" :userId="userId" :boxWidth="callTableWidth" :boxHeight="callTableHeight"></water-mark>
          <table ref="callTable" width="100%" min-height="100px" border="1" cellspacing="0" cellpadding="0" v-loading="callMsg.listLoading">
            <tr>
              <th width="30px">
                <input type="checkbox" :checked="isCheckedAll" @change="handleSelectAll">
              </th >
              <th width="30px">序号</th>
              <th width="100px">姓名</th>
              <th width="120px">手机</th>
              <!--<th width="60px" style="cursor: pointer;" @click="getCallTableData((timesOrder ++) % 2 === 1 ? 'times desc' : 'times asc')">-->
                <!--通话次数-->
                <!--<i class="el-icon-caret-top" v-show="timesOrder % 2 === 1"></i>-->
                <!--<i class="el-icon-caret-bottom" v-show="timesOrder % 2 === 0"></i>-->
              <!--</th>-->
              <!--<th width="80px">最近联系</th>-->
              <!--<th width="60px" style="cursor: pointer;" @click="getCallTableData((latestCallAtOrder ++) % 2 === 1 ? 'latestCallAt desc' : 'latestCallAt asc')">-->
                <!--接通次数/拨打次数-->
                <!--<i class="el-icon-caret-top" v-show="latestCallAtOrder % 2 === 1"></i>-->
                <!--<i class="el-icon-caret-bottom" v-show="latestCallAtOrder % 2 === 0"></i>-->
              <!--</th>-->
              <th style="cursor: pointer;" @click="getCallTableData((resultDescOrder ++) % 2 === 1 ? 'resultDesc desc' : 'resultDesc asc')">
                电话结果
                <i class="el-icon-caret-top" v-show="resultDescOrder % 2 === 1"></i>
                <i class="el-icon-caret-bottom" v-show="resultDescOrder % 2 === 0"></i>
              </th>
              <th>备注</th>
            </tr>
            <!--8 => 30-->
            <tr v-for="(item, index) in callTableData" :key="index" :class="{'bg_red': item.order === 30}">
              <td>
                <input type="checkbox" :checked="item.isChecked" @change="handleSelect(item, index)" :disabled="item.forbstatus === 1">
              </td>
              <td>{{ index + 1 }}</td>
              <td>{{ item.name }}</td>
              <td>
                <!--禁用 或者 停催-->
                <span v-if="item.forbstatus || suspendColl === 1" style="color: #999;">{{ item.phone }}</span>
                <span v-else class="file-name" @click="singleCall(item)">{{ item.phone }}</span>
                <span>（{{ item.location }}）</span>
              </td>
              <!--<td>{{ item.times }}</td>-->
              <!--<td>{{ item.latestCallAt }}</td>-->
              <!--<td>-->
                <!--<span v-if="item.callTimes">{{ item.connectedTimes || 0 }}</span>-->
                <!--<span v-if="item.callTimes">/</span>-->
                <!--<span>{{ item.callTimes }}</span>-->
              <!--</td>-->
              <td>{{ item.resultDesc }}</td>
              <td>
                <span class="file-name" v-if="!item.forbstatus" @click="openCollectionRecord(item)">催记</span>
                <span class="file-name" v-if="item.forbstatus && showSelectObj.isShowActive && !suspendColl" @click="activeMobilephone(item)">激活</span>
                {{ item.memo }}
              </td>
            </tr>
          </table>
        </div>
        <!-- 通讯录表格 end -->
      </el-col>
    </el-row>

    <!-- 增加联系人 弹窗 start -->
    <el-dialog title="增加联系人" :visible.sync="dialogAddContact" @close="dialogAddContactClose">
      <el-form :model="addContactForm" :rules="addContactRules" ref="addContactForm" label-width="120px">
        <el-form-item label="关系：" prop="relationId">
          <el-radio-group v-model="addContactForm.relationId">
            <el-radio :label="1">本人</el-radio>
            <el-radio :label="2">家人</el-radio>
            <el-radio :label="3">朋友</el-radio>
            <el-radio :label="4">同事</el-radio>
            <el-radio :label="5">公司</el-radio>
            <el-radio :label="99">其他</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="联系人姓名：" prop="contactName">
          <el-input v-model="addContactForm.contactName" auto-complete="off"></el-input>
        </el-form-item>

        <el-form-item label="联系号码：" prop="phone">
          <el-input v-model="addContactForm.phone" auto-complete="off"></el-input>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogAddContactCancel">取 消</el-button>
        <el-button type="primary" @click="dialogAddContactConfirm" :loading="addContactLoading">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 增加联系人 弹窗 end -->

    <!--批量外呼-->
    <add-project :PMProps="PMProps"></add-project>

    <!--催记弹窗-->
    <collection-record-batch :userName="userInfoForm.username" :productId="productId" :CRProps="CRProps" :CRData="CRData" :currentVoicePath="currentVoicePath"
                             :caseId="currentCaseId" :callRecordId="callRecordId" v-on:updateOT="updateOT"></collection-record-batch>

    <!--小按钮-->
    <div class="small-box" @click="smallBtn" v-show="isShowSmallBox">{{ currentCRInfo.name }}{{ currentCRInfo.phone }}</div>

    <!--批呼刚进来的遮罩层-->
    <div v-loading.fullscreen.lock="fullscreenLoading" element-loading-text="拼命拨打电话中"></div>


    <!--每日提醒-->
    <!--<div class="day-remind" @click="dayRemindBtn" v-show="!isShowDayRemind">
      <i class="el-icon-warning"></i>
      今日{{ currentRemindList.length }}个提醒
    </div>-->

    <!--<el-dialog title="今日提醒" :visible.sync="isShowDayRemind">
      <el-table :data="currentRemindList" style="width: 100%">
        <el-table-column align="center" label="联系人姓名">
          <template slot-scope="scope">
            <span class="imitate-a-label" @click="openCaseDetailById(scope.row)">{{ scope.row.contactName }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="remindTime" label="提醒时间"></el-table-column>
      </el-table>
    </el-dialog>-->

    <!--批呼控制模块-->
    <div class="monitor-layer">
      <div class="call-btn" v-show="isShowCallBtn">
        <el-button type="primary" size="mini" @click="answerNext">接听下一个</el-button>
        <el-button type="primary" size="mini" @click="pauseTask" v-show="!isPause">暂停</el-button>
        <el-button type="primary" size="mini" @click="continueTask" v-show="isPause">继续</el-button>
        <el-button type="primary" size="mini" @click="stopTask">停止</el-button>
      </div>
      <div :class="[ isShowCallBtn ? 'monitor-msg' : 'monitor-msg-no']">
        <span>总数:{{ monitorData.totalNum || 0 }}</span>
        <span>已呼叫:{{ monitorData.alreadyCallNum || 0 }}</span>
        <span>呼叫中:{{ monitorData.onCallNum || 0  }}</span>
        <span>等待接听:{{ monitorData.ivrCallNum || 0  }}</span>
      </div>
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { socket, outbound } from 'utils/outbound'
  import { parseTime } from 'utils/formatDate'
  // import { base64decode } from 'utils/index'
  import { CONST_OVERDUE_LEVEL_MAP } from './caseConstant'
  import userInfo from './components/userInfo'
  import tabData from './components/tabData'
  import operateTable from './components/operateTable'
  import addProject from './components/addProject'
  import collectionRecordBatch from './components/collectionRecordBatch'
  import WaterMark from '@/components/WaterMark' // 水印
  import dealComplain from './components/dealComplain' // 投诉
  import focusPhone from './components/focusPhone' // 重点关注
  import activeSuspend from './components/activeSuspend' // 激活停催案件
  import suspendLayer from './components/suspendLayer' // 停催层
  //  import isEmptyObject from 'utils/index'
  import {
    URL_WEBSOCKET_SERVER, // websocket地址
    fetchCreateSingleToBatchTask, // 批呼
    URL_BATCH_CALL_CALL_BACK, // 批呼回传地址
    fetchGetCaseInfo, // 获取用户信息 by caseId
    fetchGetCaseContactData, // 获取通讯录
    fetchAppendContactor, // 增加联系人
    fetchUpdateSmsChecked, // 更新联系人选中状态
    fetchSaveCallRecord, // 创建获取recordId
    fetchGetChinessPinyin, // 获取用户姓名拼音
    fetchUpdateExecuteRecord2, // 更新通话记录
    fetchAnswerNext, // 接听下一个
    fetchPauseTask, // 暂停
    fetchContinueTask, // 继续
    fetchStopTask, // 停止
    fetchGetCurrentRemindData // 今日提醒
  } from '../../api/case'
  import {
    fetchCallProjectCompleate // 完成一次批呼项目
  } from '../../api/call'


  export default {
    components: {
      userInfo, tabData, operateTable, addProject, collectionRecordBatch, WaterMark, dealComplain, focusPhone, activeSuspend, suspendLayer
    },
    computed: {
      ...mapGetters([
        'currentCRInfo', // 当前催记信息
        'isSubmitted', // 提交状态
        'isShowSmallBox', // 小按钮
        'serviceNum', // 坐席
        'displayName', // 显示中文名
        'userId', // userId
        'currentTaskId', // 当前任务ID
        'showSelectObj' // 是否显示
      ]),
      productId () {
        if (this.userInfoForm && this.userInfoForm.caseProductInfoList && this.userInfoForm.caseProductInfoList.length) {
          return this.userInfoForm.caseProductInfoList[0].productId
        } else {
          return null
        }
      },
      // 是否是车贷王
      isCDW () {
        return this.userInfoForm.caseProductInfoList[0] && this.userInfoForm.caseProductInfoList[0].productId === 6
      }
    },
    data () {
      return {
        isMonthlyPayment: true, // 催月供（本金+利息)，不催罚息 ：可配置（后端Apollo)通过接口更改
        parseTime,
        // 用户信息
        userInfoForm: {},
        mountedCount: 0, // mounted次数
        suspendColl: 2, // 0 null激活状态  1 停催状态 // 设置为大于1的值
        CONST_OVERDUE_LEVEL_MAP,

        // 勾选的人数
        multipleSelection: [],
        // 案件联系 通讯录 表格
        callTableData: [],
        callTableWidth: 0,
        callTableHeight: 0,
        callMsg: {
          listLoading: false
        },
        // 增加联系人 弹窗
        dialogAddContact: false,
        addContactLoading: false, // loading
        addContactForm: {
          relationId: '',
          contactName: '',
          phone: ''
        },
        addContactRules: {
          relationId: [
            { required: true, message: '请选择关系', trigger: 'change' }
          ],
          contactName: [
            { required: true, message: '请输入联系人名称', trigger: 'blur' }
          ],
          phone: [
            { required: true, message: '请输入联系号码', trigger: 'blur' }
          ]
        },
        // 批量外呼
        PMProps: {},
        // 催记
        CRProps: {},
        CRData: {},
        socket: {
          url: URL_WEBSOCKET_SERVER
        },
        currentCaseId: null,
        currentUuid: null, // 当前uuid
        currentCallStatus: '', // 当前通话状态
        currentCallData: '', // 当前通话信息
        currentVoicePath: '', // 当前通话录音地址
        fullscreenLoading: false,
        OTProps: {}, // 传入操作信息的数据
        updateStr: 0,
        callRecordId: null, // 催记弹开后的当前callRecordId
        taskStatus: '', // 当前任务状态
        isPause: false, // 是否暂停
        monitorData: {}, // 监控数据

        callProjectId: null, // 当前项目id
        executeId: null, // 当前执行id
        callRecordMap: {}, // callRecordId 和 uuid 一一映射
        displayUsers: {}, // 脱敏 name 和 phone 一一映射
        isShowCallBtn: true, // 是否显示接听下一个、暂停、继续、停止按钮

        isCheckedAll: false,
        timesOrder: 0, // 通话次数规则 "times desc"通话次数降序 "times asc" 通话次数升序
        latestCallAtOrder: 0, // 最后通话时间规则 "latestCallAt desc" 最后通话时间降序 "latestCallAt asc" 最后通话时间升序
        resultDescOrder: 0, // 电话结果规则 "resultDesc desc" 电话结果降序 "resultDesc asc" 电话结果升序

        isShowDayRemind: false,
        currentRemindList: [],
        // timeFun: null
      }
    },
    deactivated () {
      // clearInterval(this.timeFun)
      $(window).unbind('beforeunload')
      // window.removeEventListener('beforeunload')
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      // clearInterval(this.timeFun)
      $(window).unbind('beforeunload')
      // window.removeEventListener('beforeunload')
      window.removeEventListener('resize', this.handleResize)
    },
    created () {
      this.getWithoutOverdueFeeSwitch()
    },
    mounted () {
      window.addEventListener('resize', this.handleResize)

      if (window.location.href.indexOf('/case-detail') > -1) {
        document.title = '案件详情'
      }
      // 刷新、关闭页面提醒
      //      window.onbeforeunload = function (event) {
      //        window.sessionStorage.removeItem('Collection-BatchCall')
      //        event.returnValue = "确定离开当前页面吗？"
      //      }
      //      window.onbeforeunload = function () {
      //        let n = window.event.screenX - window.screenLeft
      //        let b = n > document.documentElement.scrollWidth - 20
      //        if (b && window.event.clientY < 0 || window.event.altKey) {
      //          window.event.returnValue = "是否关闭？"
      //          window.sessionStorage.removeItem('Collection-BatchCall')
      //        }else{
      //          window.sessionStorage.removeItem('Collection-BatchCall')
      //        }
      //      }
      //      window.addEventListener('beforeunload', function (event) {
      //        window.sessionStorage.removeItem('Collection-BatchCall')
      //        event.returnValue = "确定离开当前页面吗？"
      //      })
      $(window).bind('beforeunload', function () {
        window.sessionStorage.removeItem('Collection-BatchCall')
        return''
      })

      if (!window.sessionStorage.getItem('Collection-BatchCall')) {
        window.close()
      }
      this.fullscreenLoading = true
      // 建立websocket链接
      this.initWebSocket()

      // 每日提醒 3mins调一次
      // this.getCurrentRemindData()
      /* let _this = this
      _this.timeFun = setInterval(function () {
        _this.getCurrentRemindData()
      }, 180000) */
    },
    methods: {
      // 获取忽略逾期滞纳金开关（V3.14）
      async getWithoutOverdueFeeSwitch () {
        const { data } = await fetchGetWithoutOverdueFeeSwitch()
        if (data.errorCode === 0) {
          this.isMonthlyPayment = data.data
        }
      },
      handleResize () {
        this.$refs.callTable.style.width = this.$refs.callTableBox.clientWidth - 8 + 'px'
        this.callTableWidth = this.$refs.callTable.clientWidth - 8
        this.callTableHeight = this.$refs.callTable.clientHeight
        this.$refs.callTableBox.style.height = this.callTableHeight + 12 +'px'
      },
      // 每日提醒 3mins调一次
      getCurrentRemindData () {
        fetchGetCurrentRemindData()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.currentRemindList = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 每日提醒
      dayRemindBtn () {
        this.isShowDayRemind = true
      },
      // 跳转到案件详情
      openCaseDetailById (val) {
        window.open('#/case-detail/' + val.caseId)
      },
      // 获取用户信息 by caseId
      getUserInfoByCaseId () {
        fetchGetCaseInfo(this.currentCaseId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.userInfoForm = res.data
              this.suspendColl = this.userInfoForm.suspendColl
              // this.$refs.activeSuspend.status = this.userInfoForm.suspendColl
              document.title = this.userInfoForm.username + '-案件详情'
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 监听来自子组件的事件-更新用户信息
      updateUserInfo () {
        this.getUserInfoByCaseId()
      },
      // 监听来自子组件的事件-更新欠款信息
      updateCaseDetail () {
        this.getUserInfoByCaseId()
      },
      // 监听来自子组件的事件-催记记录更新
      updateOT () {
        let _this = this
        _this.updateStr += 1
        _this.OTProps = {isUpdate: 'update' + this.updateStr}
        // 同时更新通讯录
        _this.callMsg.listLoading = true
        setTimeout(function () {
          _this.getCallTableData()
        }, 1000)
      },
      // 激活手机号
      activeMobilephone(val) {
        let _this = this
        _this.callMsg.listLoading = true
        fetchActiveMobilephone(val.id, currentCaseId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              setTimeout(function () {
                _this.getCallTableData()
              }, 1000)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取通讯录表格数据
      getCallTableData (order) {
        this.callMsg.listLoading = true
        fetchGetCaseContactData(this.currentCaseId, order)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              let arr = []
              this.callTableData = res.data.map(item => {
                if (item.smsChecked) {
                  item.isChecked = true
                  arr.push(item)
                }
                return item
              })
              // 判断是否全勾选
              this.isCheckedAll = arr.length === this.callTableData.length
              // 计算勾选数
              this.multipleSelection = arr
            }
            this.callMsg.listLoading = false
            // 更新dom，table宽度、高度变化，canvas变化
            this.$nextTick(() => {
              this.$refs.callTable.style.width = this.$refs.callTableBox.clientWidth - 8 + 'px'
              this.callTableWidth = this.$refs.callTable.clientWidth - 8
              this.callTableHeight = this.$refs.callTable.clientHeight
              this.$refs.callTableBox.style.height = this.callTableHeight + 12 +'px'
            })
          })
          .catch(error => {
            console.log(error)
            this.callMsg.listLoading = false
          })
      },
      // 单选
      handleSelect (item, index) {
        // 切换是否勾选
        this.callTableData[index].isChecked = !this.callTableData[index].isChecked
        // 计算总的勾选项
        let arr = []
        this.callTableData.map(item => {
          if (item.isChecked) {
            arr.push(item)
          }
        })
        this.multipleSelection = arr
        // 判断是否全部勾选
        this.isCheckedAll = this.callTableData.length === arr.length
        // 请求
        let contactIds = item.id.toString().split(',')
        let smsChecked = item.isChecked ? 1 : 0 // 是否选中：0 未选中；1 选中
        fetchUpdateSmsChecked(this.currentCaseId, JSON.stringify(contactIds), smsChecked)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              console.log('更新联系人选中状态')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 全选
      handleSelectAll () {
        let contactIds = []
        // 切换是否勾选
        this.isCheckedAll = !this.isCheckedAll
        if (this.isCheckedAll) {
          // 计算勾选数
          this.multipleSelection = this.callTableData
          this.callTableData.map(item=> {
            item.isChecked = true
            contactIds.push(item.id)
            return item
          })
        } else {
          // 计算勾选数
          this.multipleSelection = []
          this.callTableData.map(item => {
            item.isChecked = false
            contactIds.push(item.id)
            return item
          })
        }
        let smsChecked = this.isCheckedAll ? 1 : 0 // 是否选中：0 未选中；1 选中
        fetchUpdateSmsChecked(this.currentCaseId, JSON.stringify(contactIds), smsChecked)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              console.log('更新联系人选中状态')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // ****************弹窗 增加联系人 ******************
      // 点击修改信息按钮
      openAddContact () {
        this.dialogAddContact = true
      },
      // 增加联系人 确认按钮
      dialogAddContactConfirm () {
        this.$refs['addContactForm'].validate((valid) => {
          if (valid) {
            this.addContactLoading = true
            let appendContactVO = {
              caseId: this.currentCaseId,
              contactName: this.addContactForm.contactName,
              phone: 	this.addContactForm.phone,
              relationId: this.addContactForm.relationId
            }
            fetchAppendContactor(JSON.stringify(appendContactVO))
              .then(response => {
                let res = response.data
                if (res.errorCode === 0) {
                  // 获取案件联系表格数据
                  this.getCallTableData()
                  // 催记记录更新
                  this.OTProps = {isUpdate: 'update1111'}
                  this.$message.success('新增联系人成功')
                }
                this.dialogAddContact = false
                this.addContactLoading = false
              })
              .catch(error => {
                console.log(error)
                this.addContactLoading = false
              })
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      // 增加联系人 取消按钮
      dialogAddContactCancel () {
        // 重置
        this.$refs['addContactForm'].resetFields()
        this.dialogAddContact = false
      },
      // 关闭弹窗回调
      dialogAddContactClose () {
        this.$refs['addContactForm'].resetFields()
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            console.log('submit!')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      // ****************弹窗 批量外呼 ******************
      batchCall () {
        this.PMProps = {
          dialogVisible: true,
          caseId: this.currentCaseId
        }
      },
      // 催记
      openCollectionRecord (val) {
        if (this.isSubmitted) {
          // 打开催记弹窗
          this.CRData = val
          this.CRProps = {dialogVisible: true}
          this.$store.dispatch('IsShowSmallBox', false)
          // 存储当前催记信息
          this.$store.dispatch('GetCurrentCRInfo', val)
          // 提交状态  变更为  未提交状态
          this.$store.dispatch('IsSubmitted', false)
        } else {
          if (val.id === this.currentCRInfo.id) {
            // this.CRData = val
            this.CRProps = {dialogVisible: true}
            this.$store.dispatch('IsShowSmallBox', false)
          } else {
            //            this.CRData = this.currentCRInfo
            //            this.CRProps = {
            //              dialogVisible: true
            //            }
            //            this.$store.dispatch('IsShowSmallBox', false)
            this.$message.warning('还有通话窗口未关闭！')
          }
        }
      },
      // 小按钮
      smallBtn () {
        if (this.currentCRInfo) {
          this.CRProps = {dialogVisible: true}
          this.$store.dispatch('IsShowSmallBox', false)
        }
      },
      // 使用sockjs，替代原生的websocket
      initWebSocket () {
        // 建立websocket连接
        socket.serviceNum = this.serviceNum
        // socket.serviceNum = 'S1003'
        if (socket.stompClient == null) {
          outbound.initWebSocket(this.socket.url, this.renderBcResult, this.renderP2pResult, this.successCallback, this.checkSocketClose)
          console.log('建立websocket连接')
        }
      },
      // 成功回调
      successCallback () {
        console.log('websocket连接成功')
        // 批呼 直接开始呼叫
        this.createSingleToBatchTask()
      },
      // TCP链接断开，提醒用户，退出重新登录
      checkSocketClose () {
        this.$alert('websocket断开，请点击确定重连TGP', '提示', {
          confirmButtonText: '确定',
          callback: action => {
            console.log('重新连接TGP')
            this.initWebSocket()
          }
        })
      },
      // 获取状态
      renderBcResult (data) {
        // console.log(data)
      },
      // 获取状态
      renderP2pResult (data) {
        if (data.body) {
          let data1 = JSON.parse(data.body)
          let type = data1.resonseType
          let res = data1.responseData
          if (res.status) {
            let status = res.status
            // 设置当前电话状态
            this.currentCallStatus = status
            this.currentCallData = res
          }
          if (res.taskStatus) {
            this.taskStatus = res.taskStatus
          }
          if (type === 'monitor') {
            this.$store.dispatch('GetCurrentTaskId', res.taskId)
            this.monitorData = res
          }

          // {"resonseType":"error","responseData":"ip :172.17.16.2 serviceNum: S1003 没有注册!"}
          if (type === 'error') {
            this.$message.error(res)
          }

          // call_result
          if (type === 'call_result') {
            let data = JSON.parse(res)
            this.currentVoicePath = data.voicePath // 当前通话录音地址
            let queryParams = {
              callProjectId: this.callProjectId,
              executeId: this.executeId,
              callRecordId: this.callRecordMap[data.uuid].callRecordId,
              contactNum: JSON.parse(data.data).realPhone, // 传入当前电话，不然外地加0，后端没法处理
              caseId: data.caseId,
              callCenterCallId: data.uuid,
              hangupType: data.hangUpType,
              callTime: data.chatDuration,
              ringingTime: data.ringDuration,
              ivrTime: data.ivrDuration,
              connected: data.connect,
              unAnswerType: data.unAnswerType,
              recordPath: data.voicePath
            }
            fetchUpdateExecuteRecord2(JSON.stringify(queryParams))
              .then(response => {
                let res = response.data
                if (res.errorCode === 0) {
                }
              })
              .catch(error => {
                console.log(error)
              })
          }
        }
      },
      // 单呼按钮
      singleCall (val) {
        if (this.isSubmitted) {
          console.log('开始创建单呼任务')
        } else {
          if (val.id === this.currentCRInfo.id) {
            this.CRData = val
            this.CRProps = {dialogVisible: true}
            this.$store.dispatch('IsShowSmallBox', false)
          } else {
            //            this.CRData = this.currentCRInfo
            //            this.CRProps = {
            //              dialogVisible: true
            //            }
            //            this.$store.dispatch('IsShowSmallBox', false)
            this.$message.warning('还有通话窗口未关闭！')
          }
        }
      },
      // 完成一次批呼项目
      overBatchCallProject () {
        let callProjectId = this.callProjectId
        let executedId = this.executeId
        fetchCallProjectCompleate(callProjectId, executedId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              console.log('完成一次批呼项目')
              // 任务结束 清除 map
              this.callRecordMap = {}
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 创建批呼任务
      createSingleToBatchTask () {
        let users = JSON.parse(window.sessionStorage.getItem('Collection-BatchCall')).arr // 传给批呼的
        this.displayUsers = JSON.parse(window.sessionStorage.getItem('Collection-BatchCall')).displayUsers // 脱敏电话
        let callRatio = JSON.parse(window.sessionStorage.getItem('Collection-BatchCall')).callRatio // 任务系数
        this.callProjectId = JSON.parse(window.sessionStorage.getItem('Collection-BatchCall')).callProjectId
        this.executeId = JSON.parse(window.sessionStorage.getItem('Collection-BatchCall')).executeId
        this.callRecordMap = JSON.parse(window.sessionStorage.getItem('Collection-BatchCall')).callRecordMap
        let controlratio = callRatio // 任务系数
        let resultUrl = ''
        if (window.location.host.indexOf('localhost') > -1) {
          resultUrl = URL_BATCH_CALL_CALL_BACK // 批呼回传地址
        } else {
          let host = window.location.host.indexOf('t') > -1 ? 'http://' : 'https://'
          resultUrl = host + window.location.host + URL_BATCH_CALL_CALL_BACK // 批呼回传地址
        }
        let realTimeMonitor = true // 是否开启监控
        fetchCreateSingleToBatchTask(JSON.stringify(users), this.serviceNum, controlratio, resultUrl, realTimeMonitor)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              console.log('开始批呼')
            } else {
              this.fullscreenLoading = false
              this.$alert(res.errorMsg + '该页面即将关闭', '提示', {
                confirmButtonText: '确定',
                callback: action => {
                  window.close()
                }})
              setTimeout(function () {
                window.close()
              }, 5000)
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 接听下一个
      answerNext () {
        fetchAnswerNext(this.currentTaskId, this.serviceNum)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              console.log('接听下一个')
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 暂停
      pauseTask () {
        let reason = null
        fetchPauseTask(this.currentTaskId, this.serviceNum, reason)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              console.log('暂停成功')
              this.isPause = true
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 继续
      continueTask () {
        let reason = null
        fetchContinueTask(this.currentTaskId, this.serviceNum, reason)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              console.log('继续成功')
              this.isPause = false
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 停止
      stopTask () {
        let reason = null
        fetchStopTask(this.currentTaskId, this.serviceNum, reason)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              console.log('停止成功')
              this.isShowCallBtn = false
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 监听停催状态
      listenSuspendStatus (val) {
        this.suspendColl = val
        // 获取案件联系表格数据
        this.getCallTableData()
        // 更新操作记录
        this.updateStr += 1
        this.OTProps = {isUpdate: 'update' + this.updateStr}
        // 更新dom，table宽度、高度变化，canvas变化
        this.$nextTick(() => {
          this.$refs.callTable.style.width = this.$refs.callTableBox.clientWidth - 8 + 'px'
          this.callTableWidth = this.$refs.callTable.clientWidth - 8
          this.callTableHeight = this.$refs.callTable.clientHeight
          this.$refs.callTableBox.style.height = this.callTableHeight + 12 +'px'
        })
      }
    },
    watch: {
      'currentCallData' (val) {
        if (val.status === 'STATUS_ON_CALL') {
          // 获取当前案件id
          this.currentCaseId = JSON.parse(val.data).caseId
          this.$refs.focusPhone.getIsFocus(this.currentCaseId)
          this.currentVoicePath = val.voicePath
          // 电话接听后，获取uuid，然后得到对应的callRecordId
          this.callRecordId = this.callRecordMap[val.uuid].callRecordId
          this.fullscreenLoading = false
          // 通过caseId获取用户信息
          this.getUserInfoByCaseId()
          // 获取案件联系表格数据
          this.getCallTableData()
          // 获取催记记录列表信息
          this.updateStr += 1
          this.OTProps = {isUpdate: 'update' + this.updateStr}
          // 如果有data 那么就是批呼
          let data = JSON.parse(val.data)
          // data.name = data.calledName
          data.name = data.calledName
          data.pinyin = this.callRecordMap[val.uuid].chinessPinYin
          // data.phone = this.displayUsers[val.uuid]
          this.CRData = data
          this.CRProps = {dialogVisible: true}
          this.$store.dispatch('IsShowSmallBox', false)
          // 存储当前催记信息
          this.$store.dispatch('GetCurrentCRInfo', data)
          // 提交状态  变更为  未提交状态
          this.$store.dispatch('IsSubmitted', false)
        }
      },
      taskStatus (val) {
        let _this = this
        // 任务结束 且  已提交状态
        if (val === 'STATUS_END' && _this.isSubmitted) {
          _this.fullscreenLoading = false
          _this.overBatchCallProject() // 项目完成over
          window.sessionStorage.removeItem('Collection-BatchCall')
          $(window).unbind('beforeunload') // 解除绑定
          _this.$alert('批呼已经结束，该页面即将关闭', '提示', {
            confirmButtonText: '确定',
            callback: action => {
              window.close()
            }})
          setTimeout(function () {
            window.close()
          }, 5000)
        }
      },
      isSubmitted (val) {
        let _this = this
        // 任务结束 且  已提交状态
        if (_this.taskStatus === 'STATUS_END' && val) {
          _this.fullscreenLoading = false
          _this.overBatchCallProject() // 项目完成over
          window.sessionStorage.removeItem('Collection-BatchCall')
          $(window).unbind('beforeunload') // 解除绑定
          _this.$alert('批呼已经结束，该页面即将关闭', '提示', {
            confirmButtonText: '确定',
            callback: action => {
              window.close()
            }})
          setTimeout(function () {
            window.close()
          }, 5000)
        }
        if (_this.taskStatus !== 'STATUS_END' && val) {
          _this.fullscreenLoading = true
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .case-detail-wrapper {
    background-color: #EBF0F3;
    .length-1 {
      width: 140px;
    }

    .form-block {
      .form-block-b {
        font-size: 14px;
      }
      .el-form-item {
        margin-bottom: 0;
      }
    }
    /* fileName */
    .file-name {
      color: #2fa4e7;
      cursor: pointer;
      &:hover {
        text-decoration: underline;
        color: #428bca;
      }
    }
    /* 小按钮 */
    .small-box {
      height: 22px;
      color: #fff;
      line-height: 14px;
      text-align: center;
      font-size: 12px;
      border-radius: 4px;
      padding: 4px;
      background: #e12b31;
      cursor: pointer;
      position: fixed;
      z-index: 3;
      bottom: 0;
      right: 200px;
    }

    .monitor-layer {
      width: 300px;
      height: 60px;
      position: fixed;
      /* fullscreenLoading的z-index 10000 */
      z-index: 11111;
      bottom: 0px;
      left: 0px;
      right: 0px;
      margin-left: auto;
      margin-right: auto;
      background: #bbb;
      border-radius: 4px;
      .call-btn {
        padding: 5px 30px;
      }
      .monitor-msg {
        text-align: center;
        font-size: 14px;
      }
      .monitor-msg-no {
        text-align: center;
        font-size: 14px;
        line-height: 60px;
      }
    }

    /*通讯录表格*/
    .call-table {
      font-size: 12px;
      color: #333;
      text-align: center;
      line-height: 20px;
      position: relative; // 为水印做的
      table, table tr th, table tr td {
        border: 1px solid #eee;
      }
      table {
        position: absolute;
        z-index: 2;
        min-height: 25px;
        line-height: 25px;
        text-align: center;
        border-collapse: collapse;
        /*padding: 2px;*/
      }
      input[type='checkbox'] {
        cursor: pointer;
      }
    }

    /*每日提醒*/
    .day-remind {
      height: 22px;
      color: #fff;
      line-height: 14px;
      text-align: center;
      font-size: 12px;
      border-radius: 2px;
      padding: 4px;
      background: #54b4eb;
      cursor: pointer;
      position: fixed;
      right: 60px;
      bottom: 0;
    }
  }
  .bg_red {
    background: rgb(181, 236, 218);
  }
</style>
