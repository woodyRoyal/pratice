<!-- 导入分案 -->
<template>
  <div class="import-case-wrapper">

    <!-- 导入文件开始 -->
    <el-form label-position="top" label-width="80px" class="upload-wrapper">
      <el-form-item label="导入csv文件说明">
        <div class="upload-file-explain">
          <li>请按照模板格式导入csv文件</li>
          <li>csv里面只有一个sheet，数据存放在A列，文本格式</li>
          <li>
            <span class="file-name" @click="downloadTemplate">点击下载</span>
            <span>文件模板（</span>
            <span class="file-name" @click="openResultDialog">查看</span>
            <span>最后一次导入结果）</span>
          </li>
        </div>
        <div class="upload-file-main">
          <!--上传组件 accept=".csv" application/vnd.ms-excel accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" -->
          <el-upload class="upload-user-defined" name="in" accept=".csv"
                     :action="uploadExcelUrl" :data="additionalData" :file-list="fileList" :show-file-list="false"
                     :with-credentials="true" :clearFiles="handleClearFiles"
                     :before-upload="handleUploadBefore" :on-success="handleUploadSuccess" :on-error="handleUploadError"
                     :on-progress="handleUploadProgress" :on-change="handleUploadChange" :disabled="isUploading">
            <el-button size="small" type="primary" :loading="isUploading">{{ uploadingText }}</el-button>
            <div slot="tip" class="el-upload__tip">
              <span>只能上传.csv格式的文件</span>
            </div>
          </el-upload>
        </div>
      </el-form-item>
    </el-form>
    <!-- 导入文件结束 -->

    <!-- 历史上传文档开始 -->
    <el-form label-position="top" label-width="80px" class="upload-wrapper">
      <el-form-item label="导入历史"></el-form-item>
    </el-form>
    <el-table :data="tableData" v-loading="listLoading" border stripe style="width: 100%" :max-height="tableHeight">
      <el-table-column align="center" prop="createAt" label="导入时间" min-width="120"></el-table-column>
      <el-table-column align="center" prop="operatorName" label="导入人" min-width="60"></el-table-column>
      <el-table-column align="center" prop="fileName" label="导入文件（点击可下载）" min-width="200">
        <template slot-scope="scope">
          <span class="file-name" @click="downloadFile(scope.row)">{{scope.row.fileName}}</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 历史上传文档结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
    <el-dialog title="数据处理结果" :visible.sync="dialogVisible">
      <span class="dialog-result">{{ returnResult }}</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog title="导入结果" :visible.sync="dialogVisibleResult">
      <p>导入时间：{{ importSuccessRes.importTime }}；导入总数：{{ importSuccessRes.totalNum }}条；导入成功：{{ importSuccessRes.successNum }}条</p>
      <p style="color: red;">导入失败：{{ tableDataResult.length }}条</p>
      <el-table :data="tableDataResult" v-loading="listLoadingResult" border stripe style="width: 100%" :max-height="tableHeightResult">
        <el-table-column align="center" prop="userId" label="失败UID" min-width="60"></el-table-column>
        <el-table-column align="center" prop="resultDesc" label="失败原因" min-width="60"></el-table-column>
      </el-table>

      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisibleResult = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  import {
    fetchGetImportHistoryList,
    URL_IMPORT_CASE_FILE, // 上传
    fetchGetLastImportResult,
    // URL_EXPORT_IMPORT_CASE_TEMPLATE, // 下载模板
    URL_EXPORT_LOAD_SIGNAGE // 导入案件的导入文件下载
  } from '../../api/case'
  // import { parseTime } from '../../utils/formatDate'

  export default {
    data () {
      return {
        uploadExcelUrl: URL_IMPORT_CASE_FILE, // 上传的地址
        additionalData: {}, // 上传时附带的额外参数
        fileName: '', // 文件名
        isUploading: false, // 文件上传中 按钮禁用提示
        uploadingText: '导入文件', // 上传按钮文字
        fileList: [],
        // 表格
        tableHeight: 600, // 表格高度
        listLoading: false, // 加载
        // 质检明细表格数据
        tableData: [], // 数据
        // 分页
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 25, 50, 100, 500, 1000],
        timer: null, // 定时器
        // 弹窗
        dialogVisible: false,
        returnResult: '', // 返回结果

        // 导入结果弹窗
        dialogVisibleResult: false,
        tableHeightResult: 300, // 表格高度
        listLoadingResult: false, // 加载
        // 数据
        importSuccessRes: {},
        tableDataResult: [] // 数据
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
      // 获取表格数据
      this.getTableData()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        let h = document.documentElement.clientHeight
        this.tableHeight = h - 310
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 获取表格列表数据
      getTableData () {
        // 列表开始加载
        this.listLoading = true
        fetchGetImportHistoryList(JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 下载文件
      downloadFile (value) {
        console.log(value)
        let url = URL_EXPORT_LOAD_SIGNAGE + '?fileName=' + value.fileName + '&fileId=' + value.id
        window.location.href = url
      },
      // 下载模板
      //      downloadTemplate () {
      //        window.location.href = URL_EXPORT_IMPORT_CASE_TEMPLATE
      //      },
      // 上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
      handleUploadBefore (file) {
        if (file.name && file.name.length > 0) {
          this.additionalData.fileName = file.name
          const ldot = file.name.lastIndexOf('.')
          const type = file.name.toLowerCase().substring(ldot)
          if (type !== '.csv') {
            this.$message.warning('目前只支持.csv格式的文件')
            return false
          }
        }
      },
      // 文件上传成功时的钩子
      handleUploadSuccess (response, file, fileList) {
        if (response.errorCode === 0) {
          if (response.data.status) {
            this.$message.success('上传成功!')
            this.getTableData()
          } else {
            this.$message.error(response.data.errorMsg)
            // 移除文件
            this.handleClearFiles()
          }
        } else {
          this.$message.error(response.errorMsg)
          // 移除文件
          this.handleClearFiles()
        }
      },
      // 文件上传失败时的钩子
      handleUploadError (err, file, fileList) {
        console.log(err)
        this.$message.error('上传失败!')
      },
      // 文件上传时的钩子
      handleUploadProgress (event, file, fileList) {
        this.isUploading = true // 开启提示
        this.fileList = fileList
        console.log('上传中...')
      },
      // 文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
      handleUploadChange (file, fileList) {
        this.isUploading = false // 关闭提示
        console.log('上传完成')
      },
      // 清空已上传的文件列表
      handleClearFiles () {
        this.fileList = []
      },
      // 打开导入结果弹窗
      openResultDialog (value) {
        this.getTableDataResult()
      },
      getTableDataResult () {
        this.listLoadingResult = true
        fetchGetLastImportResult()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              if (res.data.status === false) {
                this.$message.error(res.data.errorMsg)
              } else {
                this.tableDataResult = res.data.importFailRes
                this.importSuccessRes = res.data.importSuccessRes[0]
                this.dialogVisibleResult = true
              }
            }
            this.listLoadingResult = false
          })
          .catch(error => {
            console.log(error)
            this.listLoadingResult = false
          })
      },
      downloadTemplate () {
        let head = [[2100001], [2100002], [2100003]]
        let csvRows = []
        head.forEach((item, index) => {
          csvRows.push(head[index].join(','))
        })
        let csvString = csvRows.join('\n')
        // BOM的方式解决EXCEL乱码问题
        let BOM = '\uFEFF'
        csvString = BOM + csvString
        let a = document.createElement('a')
        a.href = 'data:attachment/csv,' + encodeURI(csvString)
        a.target = '_blank'
        a.download = '导入案件模板.csv'
        document.body.appendChild(a) // Firefox 中必须这么写，不然不会起效果
        a.click()
        document.body.removeChild(a)
      }
    },
    watch: {
      isUploading (val) {
        this.uploadingText = val ? '处理中' : '导入文件'
      }
    }
  }
</script>

<style lang="scss" scoped>
  .import-case-wrapper {
    .upload-wrapper {
      margin-bottom: 10px;
      .el-form-item {
        margin-bottom: 5px;
      }
      .el-form-item__label {
        color: #317eac;
      }
      li {
        font-size: 12px;
        line-height: 30px;
      }
      .el-upload-dragger {
        .el-upload__text {
          color: #97a8be;
          font-size: 12px;
          text-align: center;
        }
      }
      .upload-file-main,
      .upload-file-explain {
        float: left;
        margin-left: 10px;
        margin-right: 10px;
        /*.el-button {*/
        /*font-size: 12px;*/
        /*padding: 0;*/
        /*}*/
        /*.el-button {*/
        /*width: 68px;*/
        /*height: 28px;*/
        /*}*/
      }
    }

    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }

    /* fileName */
    .file-name {
      color: #2fa4e7;
      cursor: pointer;
      &:hover {
        text-decoration: underline;
        color: #428bca;
      }
    }
    /* dialog 强制换行 */
    .dialog-result {
      word-break: break-all;
      word-wrap: break-word;
    }
  }
</style>