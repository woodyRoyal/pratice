<!-- 催收员质检结果明细 -->
<template>
  <div class="collector-QC-detail-wrapper">
    <!-- 筛选条件开始 -->
    <el-form :inline="true" :model="filterForm" class="filter-form">
      <el-form-item label="日期">
        <el-date-picker
          v-model="date"
          type="daterange"
          size="small"
          :editable="false"
          :clearable="false"
          class="length-3"
          placeholder="选择日期范围"
          :picker-options="pickerOptions1">
        </el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-input v-model="filterForm.caseId" placeholder="请输入案件ID" size="small" class="length-1"></el-input>
      </el-form-item>
      <el-form-item v-if="showSelectObj.isShowCompanySelect">
        <vue-el-select v-model="filterForm.mechanIdList" multiple filterable placeholder="请选择催收机构" size="small"
                       class="length-2" @visible-change="handleMechanVisibleChange">
          <el-option
            v-for="item in collectionAgenciesList"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>

      <el-form-item v-if="showSelectObj.isShowGroupSelect">
        <vue-el-select v-model="filterForm.groupIdList" multiple filterable placeholder="请选择催收组" size="small"
                       class="length-2" @visible-change="handleGroupVisibleChange">
          <el-option
            v-for="item in collectionGroupFilterList"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>

      <el-form-item v-if="showSelectObj.isShowPersonSelect">
        <vue-el-select v-model="filterForm.collectorIdList" multiple filterable remote placeholder="请输入并选择催收员"
                       size="small"
                       class="length-2" @visible-change="handleCollectorVisibleChange" :remote-method="filterCollector"
                       :loading="collectorLoading">
          <el-option
            v-for="item in collectorFilterList"
            :key="item.id"
            :label="item.displayName"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn" :loading="searchLoading">搜索</el-button>
        <el-button type="success" size="small" @click="exportBtn">导出</el-button>
      </el-form-item>
    </el-form>
    <!-- 筛选条件结束 -->
    <!-- 催收员质检结果明细表格开始-->
    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
      <el-table-column fixed align="center" prop="checkingDate" label="质检日期" min-width="80"></el-table-column>
      <el-table-column fixed align="center" prop="checkingCollector" label="被质检催收员" min-width="80"></el-table-column>
      <el-table-column align="center" prop="positionStr" label="职位" min-width="60"></el-table-column>
      <el-table-column align="center" prop="groupType" label="组别" min-width="60"></el-table-column>
      <el-table-column align="center" label="逾期阶段" min-width="60">
        <template slot-scope="scope">
          <span>{{ overdueLevelMap[scope.row.overdueLevel] }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="managerName" label="所属经理" min-width="60"></el-table-column>
      <el-table-column align="center" prop="companyName" label="机构" min-width="60"></el-table-column>
      <el-table-column align="center" prop="recordTime" label="录音时间" width="70"></el-table-column>
      <el-table-column align="center" label="录音" min-width="60">
        <template slot-scope="scope">
          <el-button v-if="scope.row.isPlay === 0" type="primary" size="mini" @click="playBtn(scope.row)">播放</el-button>
          <el-button v-if="scope.row.isPlay === 1" type="danger" size="mini" @click="pauseBtn(scope.row)">停止</el-button>
          <el-button v-if="scope.row.isPlay === 2" type="success" size="mini" @click="continueBtn(scope.row)">继续
          </el-button>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="userName" label="用户姓名" width="60"></el-table-column>
      <el-table-column align="center" label="案件ID" min-width="60">
        <template slot-scope="scope">
          <span class="case-id" @click="openCaseDetail(scope.row.caseId)">{{scope.row.caseId}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="calledName" label="被叫" min-width="80"></el-table-column>
      <el-table-column align="center" prop="errorTypeStr" label="差错类型" min-width="200"></el-table-column>

      <el-table-column align="center" :render-header="renderHeader" prop="mistakeLevelStr" label="差错等级"
                       min-width="60"></el-table-column>

      <el-table-column align="center" prop="remark" label="备注" min-width="400"></el-table-column>
      <el-table-column align="center" label="质检复核结果">
        <template slot-scope="scope">
          <span v-if="scope.row.reviewerResult === 0">
            待复核
          </span>
          <span
            v-if="scope.row.reviewerResult === 1">{{ scope.row.reviewerDesc ? "已通过: " + scope.row.reviewerDesc : "已通过"
            }}</span>
          <span
            v-if="scope.row.reviewerResult === -1">{{ scope.row.reviewerDesc ? "未通过: " + scope.row.reviewerDesc : "未通过"
            }}</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 催收员质检结果明细表格结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

    <!-- 播放 -->
    <el-row class="footer-player" v-show="isShowPlayer">
      <i class="el-icon-close" title="关闭" @click="handleCloseAplayer"></i>
      <vue-aplayer autoplay mutex theme="#13CE66" mode="circulation"
                   @playing="handleAudioPlaying"
                   @play="handleAudioPlay"
                   @pause="handleAudioPause"
                   @error="handleAudioError"
                   :playOrPause="audioPlayer.playOrPause"
                   :music="music">
      </vue-aplayer>
    </el-row>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { parseTime } from '../../utils/formatDate'
  import { pickerOptions1 } from '../../utils/index'
  import VueAplayer from '../../components/AudioPlayer/index.vue'
  import {
    fetchGetCollectorQCDetailList,
    fetchGetCollectionMsg,
    fetchGetErrorTypeList,
    URL_EXPORT_COLLECTOR_QC_DETAIL_DATA
  } from '../../api/quality'
  import VueElSelect from '../../components/VueElSelect'
  import VueElTooltip from '../../components/VueElTooltip'
  import { CHECK_RESULT, POSITION_STATUS, TABLE_TITLE_TIP } from './qualityConstant'
  import { CONST_OVERDUE_LEVEL_MAP } from '../case/caseConstant'
  import {
    fetchAllCollectorVOList,
    findAllGroupVOList,
    fetchAllMechanVOList
  } from '../../api/common'

  import getFirstLetter from 'utils/chineseToPhoneticInitial'

  export default {
    components: {
      VueAplayer, VueElSelect, VueElTooltip
    },
    data () {
      return {
        searchLoading: false, // 搜索按钮
        testinput: '',
        date: [new Date().getTime() - 3600 * 1000 * 24, new Date().getTime()],
        pickerOptions1,
        // 筛选数据
        filterForm: {
          startDate: parseTime(new Date().getTime() - 3600 * 1000 * 24, 'YYYY-MM-DD'), // 开始时间
          endDate: parseTime(new Date().getTime(), 'YYYY-MM-DD'), // 结束时间
          caseId: null, // 案件ID
          collectorIdList: [], // 催收员
          groupIdList: [], // 催收组
          managerIdList: [], // 催收经理
          mechanIdList: [] // 催收机构
        },
        // 催收员列表
        collectorList: [],
        collectorTempList: [], // 联动过滤后下拉列表
        collectorFilterList: [], // 输入过滤后下拉列表
        collectorLoading: false,

        // 催收组列表
        collectionGroupList: [],
        collectionGroupFilterList: [], // 过滤后下拉列表
        // 催收机构列表
        collectionAgenciesList: [],
        // 质检明细表格高度
        tableHeight: 600,
        listLoading: false,
        // 质检明细表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: null, // 总记录数
        pageSizes: [10, 50, 100, 500],
        audioPlayer: {
          currentTime: 0,
          playOrPause: false
        },
        music: {
          title: 'audio', // 必填字段
          author: 'dev', // 必填字段
          url: 'http://devtest.qiniudn.com/Preparation.mp3' // 必填字段
        },
        id: null, // 播放索引（案件ID）
        recordStatus: false, // 播放状态
        errorTypeList: [], // 错误类型
        isShowPlayer: false, // 是否显示播放器
        aplayerObj: null, // 播放器对象
        overdueLevelMap: CONST_OVERDUE_LEVEL_MAP // 逾期阶段字符串映射
      }
    },
    computed: {
      ...mapGetters([
        'showSelectObj'
      ])
    },
    created () {
      this.getErrorTypeList()
      this.getAllMechanList()
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)

      // 获取表格数据
      // this.getTableData()
      // this.getCollectionMsg()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          let h = document.documentElement.clientHeight
          if (formHeight >= 90) {
            this.tableHeight = h - 235
          } else if (formHeight >= 45) {
            this.tableHeight = h - 195
          }
        })
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 获取差错类型
      getErrorTypeList () {
        fetchGetErrorTypeList()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.errorTypeList = res.data // 差错类型
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取催收信息数据
      getCollectionMsg () {
        fetchGetCollectionMsg()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.collectorList = res.data.collectorList
              this.collectionGroupList = res.data.groupIdList
              this.collectionAgenciesList = res.data.mechanIdList
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取表格数据
      getTableData () {
        this.searchLoading = true
        // 列表开始加载
        this.listLoading = true
        this.filterForm.startDate = parseTime(this.date[0], 'YYYY-MM-DD')
        this.filterForm.endDate = parseTime(this.date[1], 'YYYY-MM-DD')
        if (this.filterForm.caseId) {
          this.filterForm.caseId = this.filterForm.caseId.trim()
        }
        if (this.filterForm.mechanIdList && this.filterForm.mechanIdList.length === 0) {
          this.collectionAgenciesList.forEach(item => {
            this.filterForm.mechanIdList.push(item.id)
          })
        }
        fetchGetCollectorQCDetailList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              if (res.data.content) {
                res.data.content.map(item => {
                  // 差错等级
                  item.mistakeLevelStr = CHECK_RESULT[item.mistakeLevel]
                  // 职位
                  item.positionStr = POSITION_STATUS[item.position]
                  // 增加字段isplay  false暂停状态/true播放状态
                  if (item.id === this.id) {
                    if (this.recordStatus) {
                      item.isPlay = 1
                    } else {
                      item.isPlay = 2
                    }
                  } else {
                    item.isPlay = 0
                  }
                  item.errorTypeArr = []
                  if (item.mistakeType) {
                    let mistakeTypeList = item.mistakeType.split(',')
                    // 映射差错类型
                    this.errorTypeList.map(a => {
                      mistakeTypeList.map(b => {
                        if (a.code === b) {
                          item.errorTypeArr.push(a.value)
                        }
                      })
                      return a
                    })
                    item.errorTypeStr = item.errorTypeArr.join(',')
                  }
                  return item
                })
              }
              this.tableData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
            this.searchLoading = false
          })
          .catch(error => {
            console.log(error)
            this.searchLoading = false
            this.listLoading = false
          })
      },
      // 打开案件详情-新页面
      openCaseDetail (caseId) {
        window.open('#/case-detail/' + caseId)
      },
      // 搜索按钮
      searchBtn () {
        // 播放控件消失
        this.isShowPlayer = false
        if (this.filterForm.caseId === '') {
          this.filterForm.caseId = null
        }
        if (this.aplayerObj) {
          // 点击搜索，播放暂停
          this.audioPlayer.playOrPause = false
          // 播放索引（案件ID）
          this.id = null
          // 播放状态
          this.recordStatus = false
        }
        this.getTableData()
      },
      // 导出按钮
      exportBtn () {
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = ''
        if (this.filterForm.mechanIdList && this.filterForm.mechanIdList.length === 0) {
          this.collectionAgenciesList.forEach(item => {
            this.filterForm.mechanIdList.push(item.id)
          })
        }
        // 导出后端不识别null
        if (this.filterForm.caseId === null) {
          let caseId = ''
          url = `${URL_EXPORT_COLLECTOR_QC_DETAIL_DATA}?fileName=催收员质检明细-${date}.csv&startDate=${this.filterForm.startDate}
                    &endDate=${this.filterForm.endDate}&caseId=${caseId}&collectorIdList=${this.filterForm.collectorIdList}
                    &groupIdList=${this.filterForm.groupIdList}&managerIdList=${this.filterForm.managerIdList}&mechanIdList=${this.filterForm.mechanIdList}`
        } else {
          url = `${URL_EXPORT_COLLECTOR_QC_DETAIL_DATA}?fileName=催收员质检明细-${date}.csv&startDate=${this.filterForm.startDate}
                    &endDate=${this.filterForm.endDate}&caseId=${this.filterForm.caseId}&collectorIdList=${this.filterForm.collectorIdList}
                    &groupIdList=${this.filterForm.groupIdList}&managerIdList=${this.filterForm.managerIdList}&mechanIdList=${this.filterForm.mechanIdList}`
        }
        window.location.href = url
      },
      // 播放
      playBtn (value) {
        // 如果相同索引，不赋值music，不相同索引，就重新赋值music
        if (value.id !== this.id) {
          // 新建对象
          this.music = null
          this.music = {
            title: '案件ID：' + value.caseId, // 必填字段
            author: 'dev', // 必填字段
            url: value.recordPath // 必填字段
            // url: 'http://cdnringuc.shoujiduoduo.com/ringres/user/a24/949/34307949.aac' // 必填字段
          }
        }
        // 点击播放，所有都变为播放按钮
        this.tableData.map(item => {
          item.isPlay = 0
          return item
        })
        // 列表展示播放状态，暂停按钮
        value.isPlay = 1
        this.recordStatus = true
        this.id = value.id
        // 控件播放状态
        this.isShowPlayer = true
        this.audioPlayer.playOrPause = true
      },
      // 继续
      continueBtn (value) {
        // 当前点击的变为暂停按钮
        value.isPlay = 1
        this.recordStatus = true
        this.id = value.id
        // 显示控件播放状态
        this.isShowPlayer = true
        // 控件播放状态
        this.audioPlayer.playOrPause = true
      },
      // 暂停
      pauseBtn (value) {
        // 列表展示暂停状态，播放按钮
        value.isPlay = 2
        this.recordStatus = false
        // 控件暂停状态
        this.audioPlayer.playOrPause = false
      },
      // 监听播放器的播放事件
      handleAudioPlay () {
        this.tableData.map(item => {
          if (item.id === this.id) {
            item.isPlay = 1
          }
          return item
        })
      },
      // 监听播放器的暂停事件
      handleAudioPause () {
        this.tableData.map(item => {
          if (item.id === this.id) {
            item.isPlay = 2
          }
          return item
        })
      },
      // 监听播放中 以便获取 当前播放时间
      handleAudioPlaying (player) {
        // 播放对象
        this.aplayerObj = player
      },
      handleAudioError () {
        this.$message.error('获取录音文件资源失败')
      },
      // 关闭播放器
      handleCloseAplayer () {
        this.isShowPlayer = false
        if (this.aplayerObj) {
          // 点击搜索，播放暂停
          this.audioPlayer.playOrPause = false
          // 播放状态
          this.recordStatus = false
        }
      },

      // 表头
      renderHeader (createElement, {column}) {
        return createElement(VueElTooltip, {
          props: {
            label: column.label,
            content: TABLE_TITLE_TIP[column.property]
          }
        })
      },

      // 获取催收机构列表
      getAllMechanList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionAgenciesList && this.collectionAgenciesList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionOrganizationList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionAgenciesList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchAllMechanVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionAgenciesList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionOrganizationList', JSON.stringify(this.collectionAgenciesList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取催收组列表
      getAllGroupList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionGroupList && this.collectionGroupList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionGroupList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionGroupList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              findAllGroupVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionGroupList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionGroupList', JSON.stringify(this.collectionGroupList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取催收员列表
      getAllCollectorList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectorList && this.collectorList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionCollectorList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectorList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchAllCollectorVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectorList = res.data
                    let _this = this
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionCollectorList', JSON.stringify(this.collectorList))
                    // 中文转拼音首字母
                    setTimeout(() => {
                      _this.handleChineseToPhoneticInitial()
                    }, 100)
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },

      // 催收机构 下拉框出现/隐藏时触发
      handleMechanVisibleChange (visible) {
        if (visible) {
          // 用Promise保证执行顺序 先获取到数据再过滤
          // 先获取总数据
          this.getAllMechanList().then(() => {
            // 然后过滤数据
          })
        }
      },
      // 催收组 下拉框出现/隐藏时触发
      handleGroupVisibleChange (visible) {
        if (visible) {
          this.getAllGroupList().then(() => {
            // 然后过滤数据 mechanismId
            if (this.filterForm.mechanIdList.length === 0) {
              this.collectionGroupFilterList = JSON.parse(JSON.stringify(this.collectionGroupList))
            } else {
              this.collectionGroupFilterList = this.collectionGroupList.filter(item => {
                return this.filterForm.mechanIdList.join(',').indexOf(item.mechanismId) >= 0
              })
            }
          })
        }
      },
      // 催收员 下拉框出现/隐藏时触发
      handleCollectorVisibleChange (visible) {
        if (visible) {
          this.getAllCollectorList().then(() => {
            // 然后过滤数据 mechanismId groupId
            if (this.filterForm.mechanIdList.length === 0 && this.filterForm.groupIdList.length === 0) {
              this.collectorTempList = JSON.parse(JSON.stringify(this.collectorList))
            } else {
              this.collectorTempList = this.collectorList.filter(item => {
                // 机构、组下拉框
                if (this.filterForm.groupIdList.length > 0) { // 组选了 返回组下面的
                  return this.filterForm.groupIdList.join(',').indexOf(item.groupId) >= 0
                } else if (this.filterForm.mechanIdList.length > 0) { // 机构选了、组没选 返回机构下面的
                  return this.filterForm.mechanIdList.join(',').indexOf(item.mechanismId) >= 0
                } else {
                  return false
                }
              })
            }
          })
        }
      },
      // 根据输入过滤催收员列表
      filterCollector (query) {
        console.time('filterCollector')
        if (query !== '') {
          this.testinput = query
          this.collectorLoading = true
          this.collectorFilterList = []
          if (this.collectorTempList && this.collectorTempList.length > 0) {
            for (let i = 0, len = this.collectorTempList.length; i < len; i++) {
              if (this.collectorTempList[i].displayName.trim().indexOf(query.trim()) > -1 ||
                (this.collectorTempList[i].phoneticInitial && this.collectorTempList[i].phoneticInitial.indexOf(query.trim().toUpperCase()) > -1)) {
                this.collectorFilterList.push(this.collectorList[i])
              }
            }
          }
          this.collectorLoading = false
        } else {
          this.collectorFilterList = []
        }
        console.timeEnd('filterCollector')
      },
      handleChineseToPhoneticInitial () {
        console.time('handleChineseToPhoneticInitial')
        if (this.collectorList && this.collectorList.length > 0) {
          for (let index in this.collectorList) {
            this.collectorList[index].phoneticInitial = getFirstLetter(this.collectorList[index].displayName).join(',')
          }
          // 存入本地
          window.localStorage.setItem('Collection-CollectionCollectorList', JSON.stringify(this.collectorList))
        }
        console.timeEnd('handleChineseToPhoneticInitial')
      }
    }
  }
</script>

<style lang="scss" scoped>
  .collector-QC-detail-wrapper {
    .length-1 {
      width: 140px;
    }
    .length-2 {
      width: 200px;
    }
    .length-3 {
      width: 220px;
    }
    .el-form-item {
      margin-bottom: 5px;
    }

    .footer-player {
      position: absolute;
      width: calc(100% - 20px);
      bottom: 0;
      left: 10px;
      z-index: 100;
      .el-icon-close {
        color: #cdcdcd;
        font-size: 0;
        position: absolute;
        right: 7px;
        top: 7px;
        cursor: pointer;
      }
      &:hover {
        .el-icon-close {
          font-size: 20px;
        }
      }
    }

    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }
    .el-button {
      font-size: 12px;
    }
    // 案件ID
    .case-id {
      color: #20a0ff;
      cursor: pointer;
    }
  }
</style>
