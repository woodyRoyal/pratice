<!-- 质检员质检结果明细 -->
<template>
  <div class="quality-control-detail-wrapper">
    <!-- 筛选条件开始 -->
    <el-form :inline="true" :model="filterForm" class="filter-form">


      <el-form-item label="日期">
        <el-date-picker
          v-model="date"
          type="daterange"
          size="small"
          :editable="false"
          :clearable="false"
          class="length-3"
          placeholder="选择日期范围"
          :picker-options="pickerOptions1">
        </el-date-picker>
      </el-form-item>

      <el-form-item v-if="showSelectObj.isShowGroupSelect">
        <vue-el-select v-model="filterForm.leaderIdList" multiple filterable placeholder="请选择组长" size="small"
                       class="length-2" @visible-change="handleGroupLeaderVisibleChange">
          <el-option
            v-for="item in IQCLeaderList"
            :key="item.id"
            :label="item.displayName"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>
      <el-form-item v-if="showSelectObj.isShowPersonSelect">
        <vue-el-select v-model="filterForm.checkerIdList" multiple filterable placeholder="请选择质检员" size="small"
                       class="length-2" @visible-change="handleCheckerVisibleChange">
          <el-option
            v-for="item in checkerFilterList"
            :key="item.id"
            :label="item.displayName"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>
      <el-form-item>
        <vue-el-select v-model="filterForm.mistakeIdList" multiple filterable placeholder="请选择差错类型" size="small"
                       class="length-2" @visible-change="handleErrorTypeVisibleChange">
          <el-option
            v-for="item in errorTypeList"
            :key="item.code"
            :label="item.value"
            :value="item.code">
          </el-option>
        </vue-el-select>
      </el-form-item>
      <el-form-item>
        <el-input v-model="filterForm.caseId" placeholder="请输入案件ID" size="small" class="length-1"></el-input>
        <el-input v-model="filterForm.calledName" placeholder="请输入被叫人信息" size="small" class="length-1"></el-input>
      </el-form-item>

      <el-form-item>
        <el-form-item>
          <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选
          </el-checkbox>
        </el-form-item>
        <el-form-item>
          <el-checkbox-group v-model="filterForm.mistakeLevelIdList" @change="handleCheckedErrorLevelListChange">
            <el-checkbox v-for="item in errorLevelList" :label="item.code" :key="item.value">{{item.value}}
            </el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-form-item>

      <el-form-item>
        <el-form-item>
          <el-checkbox :indeterminate="isIndeterminateOperationStatus" v-model="checkAllOperationStatus"
                       @change="handleCheckAllOperationStatusChange">全选
          </el-checkbox>
        </el-form-item>
        <el-form-item>
          <el-checkbox-group v-model="filterForm.reviewStatusIdList" @change="handleCheckedOperationStatusListChange">
            <el-checkbox v-for="item in operationStatusList" :label="item.code" :key="item.value">{{item.value}}
            </el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn" :loading="searchLoading">搜索</el-button>
        <el-button type="success" size="small" @click="exportBtn">导出</el-button>
      </el-form-item>
    </el-form>
    <!-- 筛选条件结束 -->
    <!-- 质检结果明细表格开始-->
    <el-table :data="tableData" v-loading="listLoading" border stripe style="width: 100%" :max-height="tableHeight">
      <el-table-column fixed align="center" prop="createAt" label="质检日期" min-width="80"></el-table-column>
      <el-table-column fixed align="center" prop="checkerName" label="质检员" min-width="60"></el-table-column>
      <el-table-column align="center" prop="groupLeader" label="组长" min-width="60"></el-table-column>
      <el-table-column align="center" prop="recordAt" label="录音时间" width="70"></el-table-column>
      <el-table-column align="center" label="录音" min-width="60">
        <template slot-scope="scope">
          <el-button v-if="scope.row.isPlay === 0" type="primary" size="mini" @click="playBtn(scope.row)">播放</el-button>
          <el-button v-if="scope.row.isPlay === 1" type="danger" size="mini" @click="pauseBtn(scope.row)">停止</el-button>
          <el-button v-if="scope.row.isPlay === 2" type="success" size="mini" @click="continueBtn(scope.row)">继续
          </el-button>
        </template>
      </el-table-column>
      <el-table-column align="center" label="案件ID" min-width="60">
        <template slot-scope="scope">
          <span class="case-id" @click="openCaseDetail(scope.row.caseId)">{{scope.row.caseId}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="calledName" label="被叫" min-width="80"></el-table-column>
      <el-table-column align="center" label="第一次质检人" min-width="80">
        <template slot-scope="scope">
          <span>{{scope.row.precheckerName || '无'}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="paramName" label="差错类型" min-width="200"></el-table-column>
      <el-table-column align="center" prop="checkResultStr" label="差错等级" min-width="60"></el-table-column>
      <el-table-column align="center" prop="checkMemo" label="备注" min-width="370"></el-table-column>
      <el-table-column fixed='right' align="center" label="操作" min-width="140">
        <template slot-scope="scope">
          <div v-if="scope.row.checkerId !== userId && showSelectObj.isQCOperate && scope.row.reviewerResult === 0">
            <el-button type="success" size="mini" @click="passBtn(scope.row)">通过</el-button>
            <el-button type="danger" size="mini" @click="refuseBtn(scope.row)">不通过</el-button>
          </div>
          <div v-if="(scope.row.checkerId === userId || !showSelectObj.isQCOperate) && scope.row.reviewerResult === 0">
            <span>待复核</span>
          </div>
          <div v-if="scope.row.reviewerResult === 1">
            <span>{{ scope.row.reviewerDesc ? "已通过: " + scope.row.reviewerDesc : "已通过" }}</span>
          </div>
          <div v-if="scope.row.reviewerResult === -1">
            <span>{{ scope.row.reviewerDesc ? "未通过: " + scope.row.reviewerDesc : "未通过" }}</span>
          </div>
        </template>
      </el-table-column>
    </el-table>
    <!-- 质检结果明细表格结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

    <!-- 播放 -->
    <el-row class="footer-player" v-show="isShowPlayer">
      <i class="el-icon-close" title="关闭" @click="handleCloseAplayer"></i>
      <vue-aplayer autoplay mutex theme="#13CE66" mode="circulation"
                   @playing="handleAudioPlaying"
                   @play="handleAudioPlay"
                   @pause="handleAudioPause"
                   @error="handleAudioError"
                   :playOrPause="audioPlayer.playOrPause"
                   :music="music">
      </vue-aplayer>
    </el-row>

    <!-- 不通过复核弹窗 -->
    <el-dialog :title="'复核意见' + (isPassReview ? '（通过）':'（不通过）')" class="review-opinion-dialog"
               :visible.sync="reviewOpinionDialogVisible" size="tiny"
               @close="handleReviewOpinionDialogClose">
      <el-form>
        <el-form-item>
          <el-input type="textarea" :placeholder="'请输入复核意见'+ (isPassReview ? '（可选）':'（必填）')" :rows="5"
                    v-model.lazy="reviewOpinion"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleCancelReviewOpinion">取 消</el-button>
        <el-button type="primary" @click="handleConfirmReviewOpinion">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { parseTime } from '../../utils/formatDate'
  import { pickerOptions1 } from '../../utils/index'
  import VueAplayer from '../../components/AudioPlayer/index.vue'
  import {
    fetchGetQualityControlDetailList,
    fetchPassOrRejectQC,
    fetchGetErrorTypeList,
    URL_EXPORT_QC_DETAIL_DATA
  } from '../../api/quality'
  import {
    fetchQualitityCheckerList,
    fetchQualitityGroupList
  } from '../../api/common'
  import VueElSelect from '../../components/VueElSelect'
  import { CHECK_RESULT } from './qualityConstant'
  // import $ from 'jquery'

  export default {
    name: 'QualityDetail',
    components: {
      VueAplayer, VueElSelect
    },
    data () {
      return {
        searchLoading: false, // 搜索loading
        date: [new Date().getTime() - 3600 * 1000 * 24, new Date().getTime()],
        pickerOptions1,
        // 筛选数据
        filterForm: {
          startDate: parseTime(new Date().getTime() - 3600 * 1000 * 24, 'YYYY-MM-DD'), // 开始时间
          endDate: parseTime(new Date().getTime(), 'YYYY-MM-DD'), // 结束时间
          checkerIdList: [], // 质检员
          leaderIdList: [], // 质检组长
          mistakeIdList: [], // 差错类型
          caseId: null, // 案件ID
          calledName: '', // 被叫人
          mistakeLevelIdList: [], // 差错等级
          reviewStatusIdList: [] // 操作状态
        },
        // 质检员列表
        IQCList: [],
        checkerFilterList: [], // 联动过滤后列表
        // 质检组长列表
        IQCLeaderList: [],
        // 错误类型列表
        errorTypeList: [],
        // 错误等级列表
        errorLevelList: [
          {
            code: -1,
            value: '一般差错'
          },
          {
            code: -2,
            value: '严重差错'
          }
        ],
        operationStatusList: [
          {
            code: -1,
            value: '未通过'
          },
          {
            code: 0,
            value: '待复核'
          },
          {
            code: 1,
            value: '已通过'
          }
        ],
        // 选择全部
        checkAll: false,
        checkAllOperationStatus: false,
        isIndeterminate: false,
        isIndeterminateOperationStatus: false,
        // 质检明细表格高度
        tableHeight: 600,
        listLoading: false,
        // 质检明细表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: null, // 总记录数
        pageSizes: [10, 50, 100, 500],
        audioPlayer: {
          currentTime: 0,
          playOrPause: true
        },
        music: {
          title: 'audio', // 必填字段
          author: 'dev', // 必填字段
          url: '' // 必填字段
        },
        id: null, // 播放索引（案件ID）
        recordStatus: false, // 播放状态
        isShowPlayer: false, // 是否显示播放器
        aplayerObj: null, // 播放器对象

        isPassReview: true, // 通过还是不通过
        reviewOpinionDialogVisible: false, // 复核意见弹窗
        reviewOpinion: '', // 复核意见
        tempReviewOpinion: '', // 临时复核意见
        currentCase: '' // 当前选择的记录
      }
    },
    computed: {
      ...mapGetters([
        'showSelectObj',
        'userId'
      ])
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let h = document.documentElement.clientHeight
          this.tableHeight = h - 245
        })
      },
      // 全选 错误等级
      handleCheckAllChange (val) {
        let errorLevelList = []
        this.errorLevelList.map(item => {
          errorLevelList.push(item.code)
          return item
        })
        this.filterForm.mistakeLevelIdList = val ? errorLevelList : []
        this.isIndeterminate = false
      },
      handleCheckedErrorLevelListChange (value) {
        let checkedCount = value.length
        this.checkAll = checkedCount === this.errorLevelList.length
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.errorLevelList.length
      },
      // 全选 复核状态
      handleCheckAllOperationStatusChange (val) {
        let operationStatusList = []
        this.operationStatusList.map(item => {
          operationStatusList.push(item.code)
          return item
        })
        this.filterForm.reviewStatusIdList = val ? operationStatusList : []
        this.isIndeterminateOperationStatus = false
      },
      handleCheckedOperationStatusListChange (value) {
        let checkedCount = value.length
        this.checkAllOperationStatus = checkedCount === this.operationStatusList.length
        this.isIndeterminateOperationStatus = checkedCount > 0 && checkedCount < this.operationStatusList.length
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 获取差错类型
      getErrorTypeList () {
        if (this.errorTypeList && this.errorTypeList.length > 0) {
          return false
        }
        fetchGetErrorTypeList()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.errorTypeList = res.data // 差错类型
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取表格数据
      getTableData () {
        this.searchLoading = true
        // 列表开始加载
        this.listLoading = true
        this.filterForm.startDate = parseTime(this.date[0], 'YYYY-MM-DD')
        this.filterForm.endDate = parseTime(this.date[1], 'YYYY-MM-DD')
        if (this.filterForm.caseId) {
          this.filterForm.caseId = this.filterForm.caseId.trim()
        }
        if (this.filterForm.calledName) {
          this.filterForm.calledName = this.filterForm.calledName.trim()
        }
        fetchGetQualityControlDetailList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              res.data.content.map(item => {
                // 增加字段isplay  false暂停状态/true播放状态
                item.checkResultStr = CHECK_RESULT[item.checkResult]
                if (item.id === this.id) {
                  if (this.recordStatus) {
                    item.isPlay = 1
                  } else {
                    item.isPlay = 2
                  }
                } else {
                  item.isPlay = 0
                }
                // 处理下日期格式
                item.createAt = parseTime(item.createAt, 'YYYY-MM-DD')
                return item
              })
              this.tableData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
            this.searchLoading = false
          })
          .catch(error => {
            console.log(error)
            this.searchLoading = false
            this.listLoading = false
          })
      },
      // 搜索按钮
      searchBtn () {
        // 播放控件消失
        this.isShowPlayer = false
        if (this.filterForm.caseId === '') {
          this.filterForm.caseId = null
        }
        if (this.aplayerObj) {
          // 点击搜索，播放暂停
          this.audioPlayer.playOrPause = false
          // 播放索引（案件ID）
          this.id = null
          // 播放状态
          this.recordStatus = false
        }
        this.getTableData()
      },
      // 导出按钮
      exportBtn () {
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = ''
        // 导出get后端不识别null
        if (this.filterForm.caseId === null) {
          let caseId = ''
          url = `${URL_EXPORT_QC_DETAIL_DATA}?fileName=质检员质检结果明细-${date}.csv&startDate=${this.filterForm.startDate}
                    &endDate=${this.filterForm.endDate}&caseId=${caseId}&calledName=${this.filterForm.calledName}
                    &checkerIdList=${this.filterForm.checkerIdList}&leaderIdList=${this.filterForm.leaderIdList}&mistakeIdList=${this.filterForm.mistakeIdList}
                    &mistakeLevelIdList=${this.filterForm.mistakeLevelIdList}&reviewStatusIdList=${this.filterForm.reviewStatusIdList}`
        } else {
          url = `${URL_EXPORT_QC_DETAIL_DATA}?fileName=质检员质检结果明细-${date}.csv&startDate=${this.filterForm.startDate}
                    &endDate=${this.filterForm.endDate}&caseId=${this.filterForm.caseId}&calledName=${this.filterForm.calledName}
                    &checkerIdList=${this.filterForm.checkerIdList}&leaderIdList=${this.filterForm.leaderIdList}&mistakeIdList=${this.filterForm.mistakeIdList}
                    &mistakeLevelIdList=${this.filterForm.mistakeLevelIdList}&reviewStatusIdList=${this.filterForm.reviewStatusIdList}`
        }
        window.location.href = url
      },
      // 打开案件详情-新页面
      openCaseDetail (caseId) {
        window.open('#/case-detail/' + caseId)
      },
      // 播放
      playBtn (value) {
        // 如果相同索引，不赋值music，不相同索引，就重新赋值music
        if (value.id !== this.id) {
          // 新建对象
          this.music = null
          this.music = {
            title: '案件ID：' + value.caseId, // 必填字段
            author: 'dev', // 必填字段
            url: value.recordPath // 必填字段
            // url: 'http://cdnringuc.shoujiduoduo.com/ringres/user/a24/949/34307949.aac' // 必填字段
          }
        }
        // 点击播放，所有都变为播放按钮
        this.tableData.map(item => {
          item.isPlay = 0
          return item
        })
        // 当前点击的变为暂停按钮
        value.isPlay = 1
        this.recordStatus = true
        this.id = value.id
        // 显示控件播放状态
        this.isShowPlayer = true
        this.audioPlayer.playOrPause = true
      },
      // 继续
      continueBtn (value) {
        // 当前点击的变为暂停按钮
        value.isPlay = 1
        this.recordStatus = true
        this.id = value.id
        // 显示控件播放状态
        this.isShowPlayer = true
        // 控件播放状态
        this.audioPlayer.playOrPause = true
      },
      // 暂停
      pauseBtn (value) {
        // 列表展示暂停状态，播放按钮
        value.isPlay = 2
        this.recordStatus = false
        // value.isPlay = false
        // 控件暂停状态
        this.audioPlayer.playOrPause = false
      },
      // 通过或不通过
      passOrRejectQC (value) {
        let checkingRecordId = value.id
        let callRecordId = value.callRecordId
        let statusCode = this.isPassReview ? 1 : -1
        fetchPassOrRejectQC(checkingRecordId, callRecordId, statusCode, this.reviewOpinion)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              if (statusCode === 1) {
                this.$message({
                  type: 'success',
                  message: '通过成功!'
                })
              } else if (statusCode === -1) {
                this.$message({
                  type: 'success',
                  message: '不通过成功!'
                })
              }
              value.reviewerResult = statusCode
              value.reviewerDesc = this.reviewOpinion
              this.reviewOpinionDialogVisible = false
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 通过
      passBtn (value) {
        this.isPassReview = true
        this.currentCase = value
        this.reviewOpinionDialogVisible = true
      },
      // 不通过
      refuseBtn (value) {
        this.isPassReview = false
        this.currentCase = value
        this.reviewOpinionDialogVisible = true
      },
      // 监听播放器的播放事件
      handleAudioPlay () {
        this.tableData.map(item => {
          if (item.id === this.id) {
            item.isPlay = 1
          }
          return item
        })
      },
      // 监听播放器的暂停事件
      handleAudioPause () {
        this.tableData.map(item => {
          if (item.id === this.id) {
            item.isPlay = 2
          }
          return item
        })
      },
      // 监听播放中 以便获取 当前播放时间
      handleAudioPlaying (player) {
        // 播放对象
        this.aplayerObj = player
      },
      handleAudioError () {
        this.$message.error('获取录音文件资源失败')
      },
      // 关闭播放器
      handleCloseAplayer () {
        this.isShowPlayer = false
        if (this.aplayerObj) {
          // 点击搜索，播放暂停
          this.audioPlayer.playOrPause = false
          // 播放状态
          this.recordStatus = false
        }
      },

      // 获取质检组列表
      getAllGroupList () {
        let promise = new Promise((resolve, reject) => {
          if (this.IQCLeaderList && this.IQCLeaderList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-QualityGroupList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.IQCLeaderList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchQualitityGroupList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.IQCLeaderList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-QualityGroupList', JSON.stringify(this.IQCLeaderList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取质检员列表
      getAllQualityCheckerList () {
        let promise = new Promise((resolve, reject) => {
          if (this.IQCList && this.IQCList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-QualityCheckerList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.IQCList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchQualitityCheckerList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.IQCList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-QualityCheckerList', JSON.stringify(this.IQCList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 质检组 下拉框出现/隐藏时触发
      handleGroupLeaderVisibleChange (visible) {
        if (visible) {
          this.getAllGroupList()
        }
      },
      // 质检员 下拉框出现/隐藏时触发
      handleCheckerVisibleChange (visible) {
        if (visible) {
          this.getAllQualityCheckerList().then(() => {
            // 然后过滤数据
            if (this.filterForm.leaderIdList.length === 0) {
              this.checkerFilterList = JSON.parse(JSON.stringify(this.IQCList))
            } else {
              this.checkerFilterList = this.IQCList.filter(item => {
                // 组选了 返回组下面的
                return this.filterForm.leaderIdList.join(',').indexOf(item.groupLeaderId) >= 0
              })
            }
          })
        }
      },
      // 差错类型 下拉框出现/隐藏时触发
      handleErrorTypeVisibleChange (visible) {
        if (visible) {
          // 获取差错类型
          this.getErrorTypeList()
        }
      },
      // 确认输入
      handleConfirmReviewOpinion () {
        if (!this.isPassReview && !this.reviewOpinion) {
          this.$message.warning('请输入复核意见')
          return false
        }

        this.$confirm('此操作将' + (this.isPassReview ? '通过' : '不通过') + '案件ID：' + this.currentCase.caseId + ', 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(() => {
          this.passOrRejectQC(this.currentCase)
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消操作'
          })
        })
      },
      // 取消输入
      handleCancelReviewOpinion () {
        this.reviewOpinionDialogVisible = false
      },
      // 弹窗关闭
      handleReviewOpinionDialogClose () {
        this.reviewOpinion = '' // 重置输入框
      }
    }
  }
</script>

<style lang="scss" scoped>
  .quality-control-detail-wrapper {
    .length-1 {
      width: 140px;
    }
    .length-2 {
      width: 200px;
    }
    .length-3 {
      width: 220px;
    }
    .el-form-item {
      margin-bottom: 5px;
    }

    .footer-player {
      position: absolute;
      width: calc(100% - 20px);
      bottom: 0;
      left: 10px;
      z-index: 100;
      .el-icon-close {
        color: #cdcdcd;
        font-size: 0;
        position: absolute;
        right: 7px;
        top: 7px;
        cursor: pointer;
      }
      &:hover {
        .el-icon-close {
          font-size: 20px;
        }
      }
    }
    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }
    .el-button {
      font-size: 12px;
    }
    .cell {
      .is-active-header {
        cursor: pointer;
      }
    }
    // 案件ID
    .case-id {
      color: #20a0ff;
      cursor: pointer;
    }
  }

  .review-opinion-dialog {
    .el-form-item {
      margin-bottom: 0;
    }
  }
</style>
