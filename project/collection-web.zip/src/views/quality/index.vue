<!--质检 quality Control -->
<template>
  <div>
    <!-- 表格 表单 -->
    <el-row :gutter="20" class="main-area">
      <el-col :span="14">
        <div class="debtor-info">
          <span @click="openCaseDetailById" style="color:blue">{{ caseInfo.customerName }}</span>
          <div>欠款：{{ caseInfo.debtAmount }}元&nbsp;&nbsp;逾期：{{ caseInfo.overdueDays }}天（{{ caseInfo.overdueLevel }}）
            <!--资金方：{{ caseInfo.fund }}-->
          </div>
        </div>
        <!--表格-->
        <div class="qc-operation-table">
          <div
            class="el-table el-table--fit el-table--border el-table--fluid-height el-table--enable-row-hover el-table--enable-row-transition"
            style="width: 100%;">
            <div class="el-table__header-wrapper" style="width: calc(100% - 15px);">
              <table cellspacing="0" cellpadding="0" border="0" class="el-table__header" style="width: 100%;">
                <thead>
                <tr>
                  <th class="is-center is-leaf" width="20%">
                    <div class="cell">
                      操作时间
                    </div>
                  </th>
                  <th class="is-center is-leaf" width="25%">
                    <div class="cell">
                      操作行为
                    </div>
                  </th>
                  <th class="is-center is-leaf" width="20%">
                    <div class="cell">
                      电话结果
                    </div>
                  </th>
                  <th class="is-center is-leaf" width="25%">
                    <div class="cell">
                      备注
                    </div>
                  </th>
                  <th class="is-center is-leaf" style="border-right: none;">
                    <div class="cell">
                      录音
                    </div>
                  </th>
                  <th class="gutter" style="width: 0;"></th>
                </tr>
                </thead>
              </table>
            </div>
            <div class="back-top" title="回到顶部" @click="handleBackToTop">
            </div>
            <div class="el-table__body-wrapper" id="recordTableBody" :style="{ maxHeight: tableBodyMaxHeight + 'px' }"
                 @scroll="handleTableScroll($event)">
              <table cellspacing="0" cellpadding="0" border="0" class="el-table__body" style="width: 100%;">
                <tbody>
                <tr class="el-table__row"
                    v-for="(item, index) in tableData"
                    :key="index"
                    :class="{'same-contact':item.isSameContact, 'is-selected': caseInfo.callRecordId === item.callRecordId, 'is-playing':item.playing}">
                  <td class="is-center" width="20%">
                    <div class="cell">
                      <span>{{ item.operateAt }}</span>
                    </div>
                  </td>
                  <td class="is-center" width="25%">
                    <div class="cell">
                      <span>{{ item.operationDesc }}</span>
                    </div>
                  </td>
                  <td class="is-center" width="20%">
                    <div class="cell">
                      <span>{{ item.resultDesc }}</span>
                    </div>
                  </td>
                  <td class="is-center" width="25%">
                    <div class="cell">
                      <span>{{ item.memo }}</span>
                    </div>
                  </td>
                  <td class="is-center">
                    <div class="cell">
                      <span class="link-type red-color" v-if="item.playing"
                            @click="handlePauseAudio(item)">暂停</span>
                      <span class="link-type" v-else @click="handlePlayAudio(item)">播放</span>
                    </div>
                  </td>
                  <td class="gutter"></td>
                </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="back-top2" title="回到顶部" @click="handleBackToTop" v-if="tableBodyScrollTop > 40">
          <i class="iconfont icon-huidaotop"></i>
        </div>
      </el-col>
      <el-col :span="10">
        <div class="btn-count">
          <el-button size="small" type="primary" title="回到首页" @click="handleExitQC">退出质检</el-button>
          <!--<el-button size="small">跳过当前件</el-button>-->
          <el-button size="small" type="primary" @click="handleScreenfull">{{ !isFullscreen ? "进入全屏" : "退出全屏" }}
          </el-button>
          <div>今日我已质检：{{caseInfo.checkedCaseCount}}<span>质检池剩余：{{caseInfo.remainCaseCount}}</span></div>
        </div>
        <!--表单-->
        <el-form :model="formData" class="form-user-defined" :rules="qualityFormRules" ref="qualityForm"
                 :style="{ height: (tableBodyMaxHeight + 20) + 'px' }">
          <!--差错类型-->
          <el-row :style="{height: (isFullscreen ? 70 : 65) + '%'}" style="overflow: auto; margin-bottom: 20px;">
            <el-checkbox-group v-model="formData.mistakeCodes" class="mistake-checkboxs">
              <el-checkbox v-for="(item, index) in mistakeList"
                           :style="{marginTop: (isFullscreen ? 10 : 5) + 'px', marginBottom: (isFullscreen ? 10 : 5) + 'px'}"
                           :label="item.code"
                           :key="item.code"
                           :title="item.value"
                           :class="{'important-mark': item.showType==1}"
                           name="mistake">{{ item.value }}
              </el-checkbox>
            </el-checkbox-group>
          </el-row>
          <!--备注-->
          <el-row style="height: 20%;">
            <el-form-item prop="memo" style="margin: 0;">
              <el-input type="textarea" :rows="3" placeholder="备注" v-model="formData.memo" resize="none">
              </el-input>
            </el-form-item>
          </el-row>
          <!--控制按钮-->
          <el-row class="control-btns">
            <el-col :span="16" class="play-btns">
              <el-col :span="24">
                <el-button size="small" @click="handleInsertPlayTime(0)">插入当前播放时刻</el-button>
                <el-button size="small" @click="handleInsertPlayTime(10)">插入当前播放时刻前10秒</el-button>
              </el-col>
            </el-col>

          </el-row>
        </el-form>
      </el-col>
    </el-row>

    <!-- 播放 -->
    <el-row class="footer-player">
      <vue-aplayer autoplay mutex theme="#13CE66" mode="circulation"
                   @playing="handleAudioPlaying"
                   @play="handleAudioPlayed"
                   @pause="handleAudioPaused"
                   @error="handleAudioError"
                   :playOrPause="audioPlayer.playOrPause"
                   :music="music">
      </vue-aplayer>
    </el-row>
    <el-row class="next-btn"
            :class="{'next-btn-back' : formData.mistakeCodes && formData.mistakeCodes.length > 0 }">
      <div class="next-btn-text" @click="handleNextCase" v-loading="QCLoading" v-show="!QCLoading">
        <span>质检{{ formData.mistakeCodes && formData.mistakeCodes.length > 0 ? "不通过" : "通过" }}</span><br>
        下一件
      </div>
      <div class="next-btn-text" v-loading="QCLoading" v-show="QCLoading">
        <span>质检{{ formData.mistakeCodes && formData.mistakeCodes.length > 0 ? "不通过" : "通过" }}</span><br>
        下一件
      </div>
    </el-row>
    <!--无件提示-->
    <el-dialog
      title="提示"
      :visible.sync="dialogVisible"
      size="tiny"
      @close="handleDialogClose">
      <span>暂无质检件</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters } from 'vuex'
  import screenfull from 'screenfull'
  import VueAplayer from '../../components/AudioPlayer/index.vue'
  import {
    fetchCallRecordList,
    fetchMistakeList,
    fetchCaseInfo,
    fetchCommitQCResult
  } from '../../api/quality'
  import { formatSecondEn } from '../../utils/formatDate'

  export default {
    name: 'QualityIndex',
    components: {
      VueAplayer
    },
    computed: {
      ...mapGetters([
        'isFullscreen',
        'userId'
      ])
    },
    data () {
      const validateMemo = (rule, value, callback) => {
        if (this.formData.mistakeCodes && this.formData.mistakeCodes.length > 0) {
          if (!value) {
            callback(new Error('有勾选差错类型时 备注不能为空'))
          }
          callback()
        } else {
          callback()
        }
      }
      return {
        QCLoading: false, // 质检按钮loading
        // 案件信息
        caseInfo: {
          caseId: '',
          customerName: '',
          debtAmount: 0,
          overdueDays: 0,
          overdueLevel: '',
          fund: '',
          checkedCaseCount: '',
          remainCaseCount: '',
          callRecordId: '' // 被选中质检的录音id
        },
        // 差错类型列表
        mistakeList: [],
        // 表单数据
        formData: {
          mistakeCodes: [], // 差错类型
          memo: '', // 备注
          caseId: '', // 案件id
          customerName: '', // 案件欠款人姓名
          checkerId: '', // 质检员id
          callRecordId: '', // 通话记录id
          calledName: '', // 被叫人
          recordPath: '' // 录音存放路径
        },
        qualityFormRules: {
          memo: [
            {trigger: 'blur', validator: validateMemo}
          ]
        },
        // 表格数据
        tableData: null, // 表数据
        totalRecord: 0, // 总记录数
        totalPage: 0, // 总页数
        // 分页参数
        queryPage: {
          pageNo: 1, // 页码
          pageSize: 100 // 每页显示的记录数
        },
        tableListLoading: false, // 表格加载中
        tableBodyScrollTop: 0, // 表格当前滚动高度

        tableBodyMaxHeight: 600, // 表格最大高度
        // 播放组件参数
        audioPlayer: {
          currentTime: 0, // 当前播放位置 秒
          playOrPause: true
        },
        // 播放的音频对象
        music: {
          title: '-', // 必填字段
          author: '', // 必填字段
          url: '' // 必填字段
        },
        aplayerObj: null, // 播放器对象
        aplayerPaused: true, // 是否暂停
        dialogVisible: false // 无件提示框
      }
    },
    mounted () {
      // 监听页面大小变化
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
      // 获取差错类型
      this.getMistakeList()
      // 获取案件信息
      this.getCaseInfo()
      // this.getTableData()
    },
    methods: {
      // 跳转到案件详情
      openCaseDetailById () {
        window.open('#/case-detail/' + this.caseInfo.caseId)
      },
      // resize回调修改表格高度
      handleResize () {
        // 调整表格高度
        this.tableBodyMaxHeight = document.documentElement.clientHeight - 190

        // 全屏处理
        let explorer = window.navigator.userAgent.toLowerCase()
        // chrome
        if (explorer.indexOf('chrome') > 0) {
          if (document.body.scrollHeight === window.screen.height && document.body.scrollWidth === window.screen.width) {
            this.$store.dispatch('ToggleFullscreen', false) // 已经全屏
          } else {
            this.$store.dispatch('ToggleFullscreen', true) // 未全屏
          }
        } else { // IE 9+  fireFox
          if (window.outerHeight === window.screen.height && window.outerWidth === window.screen.width) {
            this.$store.dispatch('ToggleFullscreen', false)
          } else {
            this.$store.dispatch('ToggleFullscreen', true)
          }
        }
      },
      // 获取表数据
      getTableData () {
        this.tableListLoading = true
        fetchCallRecordList(this.caseInfo.caseId, this.caseInfo.callRecordId, JSON.stringify(this.queryPage))
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              // 遍历处理数据
              let tempTableData = response.data.data.content.map(item => {
                // 给每一行增加字段
                item.playing = false // 是否正在播放
                if (!this.formData.callRecordId) { // 没有质检人
                  if (item.callRecordId === this.caseInfo.callRecordId) { // 是质检人
                    this.formData.callRecordId = item.callRecordId // 通话记录id
                    this.formData.calledName = item.calledName // 被叫人
                    this.formData.recordPath = item.recordPath // 录音存放路径
                    item.playing = true
                    this.handlePlayAudio(item) // 开始播放
                  }
                } else {
                  if (item.calledName === this.formData.calledName) {
                    item.isSameContact = true // 是否与选中的是同一联系人
                  }
                }
                return item
              })
              if (this.tableData) { // 如果表数据已经存在 就连接在后面
                this.tableData = this.tableData.concat(tempTableData)
              } else {
                this.tableData = tempTableData
              }

              this.queryPage.pageNo = response.data.data.pageNo
              this.totalRecord = response.data.data.totalRecord
              this.totalPage = response.data.data.totalPage
            }
            this.tableListLoading = false
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取差错类型列表
      getMistakeList () {
        fetchMistakeList()
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              this.mistakeList = response.data.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 获取案件信息
      getCaseInfo () {
        fetchCaseInfo()
          .then(response => {
            if (response.data.errorCode === 0) {
              if (!response.data.data) {
                this.dialogVisible = true
              } else {
                this.caseInfo = response.data.data
                // 分页获取活动表数据
                this.getTableData()
                // 金额处理 例 3,125.40元
                //                this.caseInfo.debtAmount = (this.caseInfo.debtAmount / 100).toLocaleString() // 小数点前每三位以逗号分隔
                //                // 如果小数点后位数不足 补零
                //                if (!this.caseInfo.debtAmount.split('.')[1] || this.caseInfo.debtAmount.split('.')[1].length === 0) {
                //                  this.caseInfo.debtAmount = this.caseInfo.debtAmount + '.00'
                //                } else if (this.caseInfo.debtAmount.split('.')[1].length === 1) {
                //                  this.caseInfo.debtAmount = this.caseInfo.debtAmount + '0'
                //                }
              }
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 监听滚动条
      handleTableScroll (event) {
        this.tableBodyScrollTop = event.target.scrollTop // 滚动高度
        let scrollHeight = event.target.scrollHeight // 内容高度
        let clientHeight = event.target.clientHeight // div高度
        if (scrollHeight - clientHeight - this.tableBodyScrollTop <= 0) {
          if (this.queryPage.pageNo + 1 > this.totalPage) {
            console.log('滚到底了, 没有数据了')
          } else {
            console.log('滚到底了，继续获取数据')
            // 页码加一 查询数据
            this.queryPage.pageNo += 1
            this.getTableData()
          }
        }
      },
      // 回到滚动条顶部
      handleBackToTop () {
        document.getElementById('recordTableBody').scrollTop = 0
      },
      // 下一件
      handleNextCase () {
        // 表单验证
        this.$refs['qualityForm'].validate((valid) => {
          if (valid) {
            // 处理数据
            this.formData.caseId = this.caseInfo.caseId === '' ? null : this.caseInfo.caseId // 案件id
            this.formData.customerName = this.caseInfo.customerName // 案件欠款人姓名
            this.formData.checkerId = this.userId // 质检员id
            this.formData.callRecordId = this.formData.callRecordId === '' ? null : this.formData.callRecordId
            // 质检按钮loading点击一次延时一秒才可再点击
            this.QCLoading = true
            setTimeout(() => {
              this.QCLoading = false
            }, 1000)
            // 提交
            fetchCommitQCResult(JSON.stringify(this.formData))
              .then(res => {
                if (res.data.errorCode === 0) {
                  // 重置页面
                  this.resetData()
                  // 获取下一件数据
                  // 获取案件信息
                  this.getCaseInfo()
                }
              })
              .catch(e => {
                console.log(e)
              })
          } else {
            return false
          }
        })
      },
      // 重置数据
      resetData (formName) {
        this.caseInfo = {
          caseId: '',
          customerName: '',
          debtAmount: 0,
          overdueDays: 0,
          overdueLevel: '',
          fund: '',
          checkedCaseCount: '',
          remainCaseCount: '',
          callRecordId: '' // 被选中质检的录音id
        }
        // 表单数据
        this.formData = {
          mistakeCodes: [], // 差错类型
          memo: '', // 备注
          caseId: '', // 案件id
          customerName: '', // 案件欠款人姓名
          checkerId: '', // 质检员id
          callRecordId: '', // 通话记录id
          calledName: '', // 被叫人
          recordPath: '' // 录音存放路径
        }
        this.handleDestroyPlayer()
        // 表格数据
        this.tableData = null // 表数据
        this.totalRecord = 0 // 总记录数
        this.totalPage = 0 // 总页数
      },
      // 退出质检
      handleExitQC () {
        // 退出全屏
        if (this.checkFull()) {
          screenfull.exit()
          this.$store.dispatch('ToggleFullscreen', true)
        }
        // 直接跳转到质检明细页面
        this.$router.push({path: '/home/index'})
      },
      // 检查当前是否为全屏 返回 boolean
      checkFull () {
        let isFull = document.fullscreenEnabled || window.fullScreen || document.webkitIsFullScreen || document.msFullscreenEnabled
        if (isFull === undefined) isFull = false
        return isFull
      },
      // 触发全屏事件
      handleScreenfull () {
        if (!screenfull.enabled) {
          this.$message.warning('you browser can not support fullscreen')
          return false
        }
        // 全屏时隐藏顶部导航栏与侧边菜单栏
        this.$store.dispatch('ToggleFullscreen', this.checkFull())
        screenfull.toggle()
      },
      // 插入播放时间
      handleInsertPlayTime (beforeTime) {
        if (beforeTime === 0) {
          this.formData.memo = this.formData.memo + '"' + formatSecondEn(this.audioPlayer.currentTime) + '" '
        } else {
          let tmpTime = this.audioPlayer.currentTime - beforeTime
          this.formData.memo = this.formData.memo + '"' + formatSecondEn(tmpTime <= 0 ? 0 : tmpTime) + '" '
        }
        // 插入时间后再次校验表单
        this.$refs['qualityForm'].validate()
      },
      // 监听播放中 以便获取 当前播放时间
      handleAudioPlaying (player) {
        // 当前播放的位置
        this.audioPlayer.currentTime = player.audio.currentTime
        // 播放对象
        this.aplayerObj = player
        this.aplayerPaused = player.audio.paused
      },
      // 监听播放
      handleAudioPlayed () {
        this.audioPlayer.playOrPause = true
        // 遍历表数据
        if (this.tableData) {
          for (let j = 0, len = this.tableData.length; j < len; j++) {
            if (this.music.author === this.tableData[j].callRecordId) {
              this.tableData[j].playing = true
            } else {
              this.tableData[j].playing = false
            }
          }
        }
      },
      // 监听暂停
      handleAudioPaused () {
        this.audioPlayer.playOrPause = false
        // 遍历表数据
        if (this.tableData) {
          for (let j = 0, len = this.tableData.length; j < len; j++) {
            if (this.music.author === this.tableData[j].callRecordId) {
              this.tableData[j].playing = false
              break
            }
          }
        }
      },
      // 监听播放错误
      handleAudioError () {
        this.$message.error('获取录音文件资源失败')
      },
      // 点击播放按钮
      handlePlayAudio (operation) {
        // 新建对象 如果是当前对象不用新建
        if (this.music.author !== operation.callRecordId) {
          this.music = null
          this.music = {
            title: operation.operationDesc, // 必填字段
            author: operation.callRecordId, // 必填字段
            url: operation.recordPath // 必填字段
          }
        }
        this.audioPlayer.playOrPause = true
      },
      // 点击暂停按钮
      handlePauseAudio (operation) {
        this.audioPlayer.playOrPause = false
        // 遍历表数据
        for (let j = 0, len = this.tableData.length; j < len; j++) {
          if (operation.callRecordId === this.tableData[j].callRecordId) {
            this.tableData[j].playing = false
            break
          }
        }
      },
      // 关闭播放器
      handleDestroyPlayer () {
        if (this.aplayerObj) {
          this.aplayerObj.destroy()
        }
      },
      // Dialog 关闭的回调
      handleDialogClose () {
        this.$router.push({path: '/home/index'})
      }
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    }
  }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  .main-area {
    height: calc(100% - 100px);
    .debtor-info {
      font-size: 16px;
      font-weight: 700;
      padding: 0 10px 10px;
      height: 30px;
      div {
        float: right;
        font-weight: normal;
        font-size: 15px;
      }
    }
    .btn-count {
      padding: 0 10px 10px;
      height: 40px;
      div {
        float: right;
        span {
          margin-left: 20px;
        }
      }
    }
  }

  .back-top {
    height: 30px;
    width: 15px;
    background-color: #eef1f6;
    position: absolute;
    top: 0;
    right: 0;
    z-index: 9;
    cursor: pointer;
  }

  .back-top:hover {
    background-color: #8492A6;
  }

  .back-top2 {
    float: right;
    margin-right: -3px;
    z-index: 9;
    cursor: pointer;
    color: #D3DCE6;
    i {
      font-size: 22px;

    }
  }

  .back-top2:hover {
    color: #8492A6;
  }

  .form-user-defined {
    .el-form-item {
      margin-right: 20px;
      margin-bottom: 10px;
    }
    .mistake-checkboxs {
      .el-checkbox + .el-checkbox {
        margin-left: 0;
      }
      .el-checkbox {
        width: 210px;
        /*overflow: hidden;*/
        /*text-overflow: ellipsis;*/
        /*white-space: nowrap;*/
      }
      .el-checkbox__label {
        font-size: 18px;
      }
    }
    .control-btns {
      height: 80px;
      .play-btns {
        line-height: 40px;
      }

    }
  }

  .red-color {
    color: red;
  }

  .qc-operation-table {
    .el-table__body-wrapper {
      overflow-y: scroll;
    }
    tr.is-selected > td {
      background-color: #475669;
      .cell {
        color: #fff;
      }
    }
    .el-table .cell, .el-table th > div {
      padding-left: 5px;
      padding-right: 5px;
    }
    .same-contact > td {
      background-color: #D3DCE6;
    }
    .is-playing > td {
      background-color: #8492A6;
    }
  }

  .footer-player {
    position: absolute;
    bottom: 0;
    left: 10px;
    width: 84%;
  }

  .next-btn {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 14%;
    height: 24%;
    text-align: center;
    background-color: #58B7FF;
    color: #fff;
    font-size: 22px;
    cursor: pointer;
    display: table;
    .next-btn-text {
      display: table-cell;
      vertical-align: middle;
      span {
        font-size: 16px;
      }
    }
  }

  .next-btn:hover {
    background-color: #20A0FF;
  }

  .next-btn-back {
    background-color: #F77474;
  }

  .next-btn-back:hover {
    background-color: #FF4949;
  }
</style>
