<!-- 质检员质检汇总 -->
<template>
  <div class="quality-inspection-summary-wrapper">
    <!-- 筛选条件开始 -->
    <el-form :inline="true" :model="filterForm" class="filter-form">

      <el-form-item label="日期">
        <el-date-picker
          v-model="date"
          type="daterange"
          size="small"
          :editable="false"
          :clearable="false"
          class="length-3"
          placeholder="选择日期范围"
          :picker-options="pickerOptions1">
        </el-date-picker>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn" :loading="searchLoading">搜索</el-button>
        <el-button type="success" size="small" @click="exportBtn">导出</el-button>
      </el-form-item>
    </el-form>
    <!-- 筛选条件结束 -->
    <!-- 质检员质检汇总表格开始-->
    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
      <el-table-column fixed align="center" prop="checkingDate" label="日期" min-width="80"></el-table-column>

      <el-table-column align="center" :render-header="renderHeader" prop="dayCheckingNewCount" label="当日生成质检量"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="dayInspectorCount" label="当日工作质检员数"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="dayCheckingCount" label="当日质检量"></el-table-column>

      <el-table-column align="center" prop="dayCheckingMistakeCount" label="当日复核前差错量"></el-table-column>
      <el-table-column align="center" prop="dayCheckingPassCount" label="当日复核通过量"></el-table-column>
      <el-table-column align="center" prop="commonCount" label="一般差错数量"></el-table-column>
      <el-table-column align="center" prop="seriousCount" label="严重差错数量"></el-table-column>
      <el-table-column align="center" prop="sumCount" label="差错合计"></el-table-column>

      <el-table-column v-for="(item, index) in mistakeList" :key="index"
                       align="center" :label="item.value">
        <template slot-scope="scope">
          <span>{{ scope.row.qualityCheckingObj[item.code] }}</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 质检员质检汇总表格结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
  </div>
</template>

<script>
  import { parseTime } from '../../utils/formatDate'
  import { pickerOptions1 } from '../../utils/index'
  import { TABLE_TITLE_TIP } from './qualityConstant'
  import {
    fetchGetQualityInspectionSummaryList,
    fetchMistakeList,
    URL_EXPORT_IQC_SUMMARY_DATA
  } from '../../api/quality'
  import VueElSelect from '../../components/VueElSelect'
  import VueElTooltip from '../../components/VueElTooltip'

  export default {
    components: {
      VueElSelect, VueElTooltip
    },
    data () {
      return {
        searchLoading: false, // 搜索按钮
        date: [new Date().getTime() - 3600 * 1000 * 24, new Date().getTime()],
        pickerOptions1,
        // 筛选数据
        filterForm: {
          startDate: parseTime(new Date().getTime() - 3600 * 1000 * 24, 'YYYY-MM-DD'), // 开始时间
          endDate: parseTime(new Date().getTime(), 'YYYY-MM-DD'), // 结束时间
          checkerIdList: [], // 质检员
          leaderIdList: [], // 组长
          mistakeIdList: [], // 差错类型
          mistakeLevelIdList: [], // 差错等级
          reviewStatusIdList: [], // 复核状态
          caseId: null, // 案件ID
          calledName: '' // 被叫人
        },
        // 差错类型列表
        mistakeList: [],
        // 质检明细表格高度
        tableHeight: 600,
        listLoading: false,
        // 质检明细表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: null, // 总记录数
        pageSizes: [10, 50, 100, 500]
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)

      // 获取表格数据
      // this.getTableData()
      // 获取差错类型
      this.getMistakeList()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          let h = document.documentElement.clientHeight
          if (formHeight >= 90) {
            this.tableHeight = h - 189
          } else if (formHeight >= 45) {
            this.tableHeight = h - 144
          }
        })
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        // 获取表格数据
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        // 获取表格数据
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        this.searchLoading = true
        // 列表开始加载
        this.listLoading = true
        this.filterForm.startDate = parseTime(this.date[0], 'YYYY-MM-DD')
        this.filterForm.endDate = parseTime(this.date[1], 'YYYY-MM-DD')
        fetchGetQualityInspectionSummaryList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content.map(item => {
                // 差错
                item.qualityCheckingObj = JSON.parse(item.qualityChecking)
                return item
              })
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
            this.searchLoading = false
          })
          .catch(error => {
            console.log(error)
            this.searchLoading = false
            this.listLoading = false
          })
      },
      // 获取差错类型列表
      getMistakeList () {
        fetchMistakeList()
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              this.mistakeList = response.data.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 搜索按钮
      searchBtn () {
        this.getTableData()
      },
      // 导出按钮
      exportBtn () {
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = ''
        // 导出后端不识别null
        if (this.filterForm.caseId === null) {
          let caseId = ''
          url = `${URL_EXPORT_IQC_SUMMARY_DATA}?fileName=质检员质检汇总-${date}.csv&startDate=${this.filterForm.startDate}
                    &endDate=${this.filterForm.endDate}&caseId=${caseId}&calledName=${this.filterForm.calledName}
                    &checkerIdList=${this.filterForm.checkerIdList}&leaderIdList=${this.filterForm.leaderIdList}
                    &mistakeIdList=${this.filterForm.mistakeIdList}&mistakeLevelIdList=${this.filterForm.mistakeLevelIdList}&reviewStatusIdList=${this.filterForm.reviewStatusIdList}`
        } else {
          url = `${URL_EXPORT_IQC_SUMMARY_DATA}?fileName=质检员质检汇总-${date}.csv&startDate=${this.filterForm.startDate}
                    &endDate=${this.filterForm.endDate}&caseId=${this.filterForm.caseId}&calledName=${this.filterForm.calledName}
                    &checkerIdList=${this.filterForm.checkerIdList}&leaderIdList=${this.filterForm.leaderIdList}
                    &mistakeIdList=${this.filterForm.mistakeIdList}&mistakeLevelIdList=${this.filterForm.mistakeLevelIdList}&reviewStatusIdList=${this.filterForm.reviewStatusIdList}`
        }
        window.location.href = url
      },
      // 表头
      renderHeader (createElement, {column}) {
        return createElement(VueElTooltip, {
          props: {
            label: column.label,
            content: TABLE_TITLE_TIP[column.property]
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .quality-inspection-summary-wrapper {
    .length-1 {
      width: 140px;
    }
    .length-3 {
      width: 220px;
    }
    .el-form-item {
      margin-bottom: 5px;
    }
    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }
  }
</style>
