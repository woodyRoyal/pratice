<!-- 催收员质检结果汇总 -->
<template>
  <div class="collector-QC-summary-wrapper">
    <!-- 筛选条件开始 -->
    <collection-query-terms @search="searchBtn" @export="exportBtn">
    </collection-query-terms>
    <!-- 筛选条件结束 -->
    <!-- 催收员质检结果汇总表格开始-->
    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
      <el-table-column fixed align="center" prop="checkingDate" label="质检日期" min-width="80"></el-table-column>
      <el-table-column align="center" prop="checkingCollector" label="被质检催收员"></el-table-column>
      <el-table-column align="center" prop="positionStr" label="职位"></el-table-column>
      <el-table-column align="center" prop="groupType" label="组别"></el-table-column>
      <el-table-column align="center" label="逾期阶段">
        <template slot-scope="scope">
          <span>{{ overdueLevelMap[scope.row.overdueLevel] }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="managerName" label="所属经理"></el-table-column>
      <el-table-column align="center" prop="companyName" label="机构"></el-table-column>
      <el-table-column align="center" prop="productSum" label="产品">
        <template slot-scope="scope">
          <!--<div v-for="(val, key) in JSON.parse(scope.row.productSum)">{{ key === 'DKW_APP' ? '单月贷' : '双周贷' }} - {{ val }}</div>-->
          <div v-for="(val, key) in scope.row.productSum">{{ val.productName }}-{{ val.checkingErrorSum }}</div>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="dayCheckingCount" label="质检数量"></el-table-column>

      <el-table-column align="center" :render-header="renderHeader" prop="commonCount" label="一般差错数量"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="seriousCount"
                       label="严重差错数量"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="sumCount" label="差错合计"></el-table-column>

      <el-table-column v-for="(item, index) in mistakeList" :key="index"
                       align="center" :label="item.value">
        <template slot-scope="scope">
          <span>{{ scope.row.qualityCheckingObj[item.code] }}</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 催收员质检结果汇总表格结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
  </div>
</template>

<script>
  import { parseTime } from '../../utils/formatDate'
  import {
    fetchGetCollectorQCSummaryList,
    fetchMistakeList,
    URL_EXPORT_COLLECTOR_QC_SUMMARY_DATA
  } from '../../api/quality'
  import { TABLE_TITLE_TIP, POSITION_STATUS } from './qualityConstant'
  import CollectionQueryTerms from '../components/CollectionQueryTerms'
  import VueElTooltip from '../../components/VueElTooltip'
  import { CONST_OVERDUE_LEVEL_MAP } from '../case/caseConstant'

  export default {
    components: {
      CollectionQueryTerms, VueElTooltip
    },
    data () {
      return {
        // 筛选数据
        filterForm: {},
        // 差错类型列表
        mistakeList: [],
        // 质检明细表格高度
        tableHeight: 600,
        listLoading: false,
        // 质检明细表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: null, // 总记录数
        pageSizes: [10, 50, 100, 500],
        overdueLevelMap: CONST_OVERDUE_LEVEL_MAP // 逾期阶段字符串映射
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)

      // 获取差错类型
      this.getMistakeList()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          let h = document.documentElement.clientHeight
          if (formHeight >= 90) {
            this.tableHeight = h - 189
          } else if (formHeight >= 45) {
            this.tableHeight = h - 144
          }
        })
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        // 列表开始加载
        this.listLoading = true
        fetchGetCollectorQCSummaryList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content.map(item => {
                // 职位
                item.positionStr = POSITION_STATUS[item.position]
                // 差错
                item.qualityCheckingObj = JSON.parse(item.qualityChecking)
                return item
              })
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 获取差错类型列表
      getMistakeList () {
        fetchMistakeList()
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              this.mistakeList = response.data.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 搜索按钮
      searchBtn (queryData) {
        this.filterForm = queryData
        this.getTableData()
      },
      // 导出按钮
      exportBtn (queryData) {
        this.filterForm = queryData
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = ''
        // 导出后端不识别null
        url = `${URL_EXPORT_COLLECTOR_QC_SUMMARY_DATA}?fileName=催收员汇总-${date}.csv&startDate=${this.filterForm.startDate}
                    &endDate=${this.filterForm.endDate}&caseId=''&collectorIdList=${this.filterForm.collectorIdList}
                    &groupIdList=${this.filterForm.groupIdList}&managerIdList=${this.filterForm.managerIdList}&mechanIdList=${this.filterForm.mechanIdList}`

        window.location.href = url
      },
      // 表头
      renderHeader (createElement, {column}) {
        return createElement(VueElTooltip, {
          props: {
            label: column.label,
            content: TABLE_TITLE_TIP[column.property]
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .collector-QC-summary-wrapper {
    .el-form-item {
      margin-bottom: 5px;
    }
    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }
  }
</style>
