/* 质检和催收管理相关 常量 */

// 质检权限角色控制 目前分为五个等级
export const PERMISSION_ROLE = {
  // 1 所有权限
  sadmin: '10000', // 超级管理员
  padmin: '10010', // 普通管理员
  cadmin: '10037', // 管理查询岗
  // 2 不能选机构
  organization: '10036', // 机构主管
  // 3 不能选催收经理
  collManager: '10029', // 催收经理
  qcManager: '10032', // 质检经理
  // 4 不能选机构和组
  colGroupLeader: '10031', // 催收组长
  qcGroupLeader: '10044', // 质检组长
  // 5 不能选机构和组、员, 只能看自己
  collector: '10030', // 催收员
  checker: '10033' // 质检员
}

// 差错等级
export const CHECK_RESULT = {
  '0': '无',
  '-1': '一般差错',
  '-2': '严重差错'
}

export const TABLE_TITLE_TIP = {
  // 质检员工作统计页面
  checkingCount: '当日该质检员质检的总件数',
  checkingMistakeCount: '当日该质检员操作“质检不通过”的件数',
  checkingPassCount: '当日该质检员操作“质检不通过”的质检件中最终通过经理复核的件数',
  monthCheckingCount: '本月截止当日，每天的“当日质检量”之和',
  monthCheckingMistakeCount: '本月截止当日，“当日质检差错量”之和',
  monthCheckingPassCount: '本月截止当日，“当日复核通过量”之和',
  dayCommonCount: '当日复核通过的一般差错件数',
  daySeriousCount: '当日复核通过的严重差错件数',
  // 质检员质检汇总页面
  dayCheckingNewCount: '当日被抽进待质检池子的总件数',
  dayInspectorCount: '当日有质检操作的质检员数',
  dayCheckingCount: '当日所有质检员的“当日质检量”之和',
  // 催收员质检结果明细
  mistakeLevelStr: '质检时勾选项中包括“违反催收作业基本守则”的质检件定为严重差错，不包含这一项但有勾选其它选项的为一般差错',
  // 催收员质检结果汇总
  commonCount: '通过复核的一般差错数量',
  seriousCount: '通过复核的严重差错数量',
  sumCount: '一般差错数量+严重差错数量',
  qualityChecking1: '通过复核的质检件中勾选了“违反催收作业基本守则”的件数',
  qualityChecking2: '通过复核的质检件中勾选“威胁”的件数',
  // 催收组质检汇总
  checkingCollectors: '当日该催收组被质检的催收员数量',
  collectionGroupCommonCount: '当日该催收组复核后的质检结果为一般差错的件数',
  collectionGroupSeriousCount: '当日该催收组复核后的质检结果为严重差错的件数',
  collectionGroupQualityChecking1: '当日该催收组被复核通过的质检件中被勾选了“违反催收作业基本守则”的件数'
}

// 所属职位: 0机构主管 1 催收经理 2 催收组长 3 催收员 4 质检经理 5质检组长 6质检员;
export const POSITION_STATUS = {
  0: '机构主管',
  1: '催收经理',
  2: '催收组长',
  3: '催收员',
  4: '质检经理',
  5: '质检组长',
  6: '质检员'
}
