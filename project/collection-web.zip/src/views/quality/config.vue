<!-- 质检配置 -->
<template>
  <div class="quality-control-config-wrapper">

    <div style="width: 50%; margin-bottom: 20px;">
      <span style="font-size: 12px;">说明：可按照机构，逾期阶段配置人均进件数量，保存之后第二天生效</span>
    </div>

    <!-- 质检配置表格开始-->
    <el-table :data="tableData" v-loading="listLoading" border stripe style="width: 100%" :max-height="tableHeight">
      <el-table-column align="center" prop="mechanName" label="机构" min-width="80"></el-table-column>
      <el-table-column align="center" prop="overdueLevel" label="逾期阶段" min-width="80">
        <template slot-scope="scope">
          <span>{{ overdueLevelMap[scope.row.overdueLevel] }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="extractNo" label="人均进件数量" min-width="80">
        <template slot-scope="scope">
          <el-input placeholder="请输入人均进件数量" size="small" v-model="scope.row.extractNo"
                    @blur="handleCheckInput(scope.row)">
          </el-input>
        </template>
      </el-table-column>
      <el-table-column align="center" label="操作" min-width="80">
        <template slot-scope="scope">
          <el-button type="primary" size="mini" @click="saveBtn(scope.row)">保存</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 质检结果明细表格结束-->

  </div>
</template>

<script>
  import { CONST_OVERDUE_LEVEL_MAP } from '../case/caseConstant'
  import { getIntger } from '../../utils/index'
  import {
    fetchGetCheckingPoolParam,
    fetchSaveCheckingPoolParam
  } from '../../api/quality'

  export default {
    data () {
      return {
        tableHeight: 600,
        listLoading: false,
        tableData: [],
        overdueLevelMap: CONST_OVERDUE_LEVEL_MAP // 逾期阶段字符串映射
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
      this.getTableData()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        let h = document.documentElement.clientHeight
        this.tableHeight = h - 100
      },
      getTableData () {
        // 列表开始加载
        this.listLoading = true
        fetchGetCheckingPoolParam()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 输入校验
      handleCheckInput (obj) {
        let extractNo = (obj && obj.extractNo).toString()
        if (extractNo !== '') { // 只能输入数字
          obj.extractNo = getIntger(extractNo)
          if (parseInt(obj.extractNo) > 50) {
            this.$message.warning('系统规定不能大于50，请重新设置')
            obj.extractNo = ''
          }
        }
      },
      // 保存按钮
      saveBtn (value) {
        console.log(value)
        if (!value.extractNo) {
          this.$message.warning('请输入人均进件数量')
          return false
        }
        // value.extractNo = parseInt(value.extractNo)
        // value.remark = value.remark === null ? '' : value.remark
        fetchSaveCheckingPoolParam(JSON.stringify(value))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.$message.success('保存成功')
            }
          })
          .catch(error => {
            console.log(error)
          })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .quality-control-config-wrapper {

  }
</style>
