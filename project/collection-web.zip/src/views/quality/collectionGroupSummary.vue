<!-- 催收组质检汇总 -->
<template>
  <div class="collector-group-QC-summary-wrapper">
    <!-- 筛选条件开始 -->
    <el-form :inline="true" :model="filterForm" class="filter-form">
      <el-form-item label="日期">
        <el-date-picker
          v-model="date"
          type="daterange"
          size="small"
          :editable="false"
          :clearable="false"
          class="length-3"
          placeholder="选择日期范围"
          :picker-options="pickerOptions1">
        </el-date-picker>
      </el-form-item>

      <el-form-item v-if="showSelectObj.isShowManagerSelect">
        <vue-el-select v-model="filterForm.managerIdList" multiple filterable placeholder="请选择催收经理" size="small"
                       class="length-2" @visible-change="handleManagerVisibleChange">
          <el-option
            v-for="item in collectionManagerList"
            :key="item.id"
            :label="item.displayName"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>
      <el-form-item v-if="showSelectObj.isShowGroupSelect">
        <vue-el-select v-model="filterForm.groupIdList" multiple filterable placeholder="请选择催收组" size="small"
                       class="length-2" @visible-change="handleGroupVisibleChange">
          <el-option
            v-for="item in collectionGroupFilterList"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn" :loading="searchLoading">搜索</el-button>
        <el-button type="success" size="small" @click="exportBtn">导出</el-button>
      </el-form-item>
    </el-form>
    <!-- 筛选条件结束 -->
    <!-- 催收组质检汇总表格开始-->
    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
      <el-table-column fixed align="center" prop="checkingDate" label="日期" min-width="80"></el-table-column>
      <el-table-column fixed align="center" prop="groupType" label="组别"></el-table-column>
      <el-table-column fixed align="center" prop="groupLeader" label="组长"></el-table-column>
      <el-table-column align="center" label="逾期阶段">
        <template slot-scope="scope">
          <span>{{ overdueLevelMap[scope.row.overdueLevel] }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="managerName" label="所属经理"></el-table-column>
      <el-table-column align="center" prop="companyName" label="机构"></el-table-column>

      <el-table-column align="center" :render-header="renderHeader" prop="checkingCollectors"
                       label="被质检催收员数"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="collectionGroupCommonCount"
                       label="一般差错数量"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="collectionGroupSeriousCount"
                       label="严重差错数量"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="sumCount" label="差错合计"></el-table-column>


      <el-table-column v-for="(item, index) in mistakeList" :key="index"
                       align="center" :label="item.value">
        <template slot-scope="scope">
          <span>{{ scope.row.qualityCheckingObj[item.code] }}</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 催收组质检汇总表格结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

  </div>
</template>

<script>
  import { parseTime } from '../../utils/formatDate'
  import { pickerOptions1 } from '../../utils/index'
  import {
    fetchGetCollectionGroupQCSummaryList,
    fetchMistakeList,
    URL_EXPORT_COLLECTION_GROUP_QC_SUMMARY_DATA
  } from '../../api/quality'
  import VueElSelect from '../../components/VueElSelect'
  import { mapGetters } from 'vuex'
  import { TABLE_TITLE_TIP } from './qualityConstant'
  import VueElTooltip from '../../components/VueElTooltip'
  import { CONST_OVERDUE_LEVEL_MAP } from '../case/caseConstant'
  import {
    findAllGroupVOList,
    findAllManagerVOList
  } from '../../api/common'

  export default {
    components: {
      VueElSelect, VueElTooltip
    },
    data () {
      return {
        searchLoading: false, // 搜索按钮
        date: [new Date().getTime() - 3600 * 1000 * 24, new Date().getTime()],
        pickerOptions1,
        // 筛选数据
        filterForm: {
          startDate: parseTime(new Date().getTime() - 3600 * 1000 * 24, 'YYYY-MM-DD'), // 开始时间
          endDate: parseTime(new Date().getTime(), 'YYYY-MM-DD'), // 结束时间
          caseId: null, // 案件ID
          collectorIdList: [], // 催收员
          groupIdList: [], // 催收组
          managerIdList: [], // 催收经理
          mechanIdList: [] // 催收机构
        },
        // 差错类型列表
        mistakeList: [],
        // 催收组列表
        collectionGroupList: [],
        collectionGroupFilterList: [], // 联动过滤
        // 催收经理列表
        collectionManagerList: [],
        // 表格高度
        tableHeight: 600,
        listLoading: false,
        // 表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: null, // 总记录数
        pageSizes: [10, 50, 100, 500],
        overdueLevelMap: CONST_OVERDUE_LEVEL_MAP // 逾期阶段字符串映射
      }
    },
    computed: {
      ...mapGetters([
        'showSelectObj'
      ])
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)

      // 获取差错类型
      this.getMistakeList()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          let h = document.documentElement.clientHeight
          if (formHeight >= 90) {
            this.tableHeight = h - 189
          } else if (formHeight >= 45) {
            this.tableHeight = h - 144
          }
        })
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        this.searchLoading = true
        // 列表开始加载
        this.listLoading = true
        this.filterForm.startDate = parseTime(this.date[0], 'YYYY-MM-DD')
        this.filterForm.endDate = parseTime(this.date[1], 'YYYY-MM-DD')
        fetchGetCollectionGroupQCSummaryList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content.map(item => {
                // 表头render需要，因与其他页面字段重复，所以修改字段，区分
                item.collectionGroupCommonCount = item.commonCount
                item.collectionGroupSeriousCount = item.seriousCount
                item.collectionGroupQualityChecking1 = item.qualityChecking1
                // 逾期阶段
                if (item.overdueLevel) {
                  item.overdueLevelStr = 'M' + item.overdueLevel
                }
                // 差错
                item.qualityCheckingObj = JSON.parse(item.qualityChecking)
                return item
              })
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
            this.searchLoading = false
          })
          .catch(error => {
            console.log(error)
            this.searchLoading = false
            this.listLoading = false
            this.tableData = []
          })
      },
      // 获取差错类型列表
      getMistakeList () {
        fetchMistakeList()
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              this.mistakeList = response.data.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 搜索按钮
      searchBtn () {
        this.getTableData()
      },
      // 导出按钮
      exportBtn () {
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = ''
        // 导出后端不识别null
        if (this.filterForm.caseId === null) {
          let caseId = ''
          url = `${URL_EXPORT_COLLECTION_GROUP_QC_SUMMARY_DATA}?fileName=催收组汇总-${date}.csv&startDate=${this.filterForm.startDate}
                    &endDate=${this.filterForm.endDate}&caseId=${caseId}&collectorIdList=${this.filterForm.collectorIdList}
                    &groupIdList=${this.filterForm.groupIdList}&managerIdList=${this.filterForm.managerIdList}&mechanIdList=${this.filterForm.mechanIdList}`
        } else {
          url = `${URL_EXPORT_COLLECTION_GROUP_QC_SUMMARY_DATA}?fileName=催收组汇总-${date}.csv&startDate=${this.filterForm.startDate}
                    &endDate=${this.filterForm.endDate}&caseId=${this.filterForm.caseId}&collectorIdList=${this.filterForm.collectorIdList}
                    &groupIdList=${this.filterForm.groupIdList}&managerIdList=${this.filterForm.managerIdList}&mechanIdList=${this.filterForm.mechanIdList}`
        }
        window.location.href = url
      },
      // 表头
      renderHeader (createElement, {column}) {
        return createElement(VueElTooltip, {
          props: {
            label: column.label,
            content: TABLE_TITLE_TIP[column.property]
          }
        })
      },

      // 获取催收经理列表
      getAllManagerList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionManagerList && this.collectionManagerList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionManagerList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionManagerList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              findAllManagerVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionManagerList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionManagerList', JSON.stringify(this.collectionManagerList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取催收组列表
      getAllGroupList () {
        let promise = new Promise((resolve, reject) => {
          if (this.collectionGroupList && this.collectionGroupList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-CollectionGroupList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.collectionGroupList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              findAllGroupVOList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.collectionGroupList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-CollectionGroupList', JSON.stringify(this.collectionGroupList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },

      // 催收经理 下拉框出现/隐藏时触发
      handleManagerVisibleChange (visible) {
        if (visible) {
          this.getAllManagerList()
        }
      },
      // 催收组 下拉框出现/隐藏时触发
      handleGroupVisibleChange (visible) {
        if (visible) {
          this.getAllGroupList().then(() => {
            // 然后过滤数据
            // 经理下拉框没选 返回全部
            if (this.filterForm.managerIdList.length === 0) {
              this.collectionGroupFilterList = JSON.parse(JSON.stringify(this.collectionGroupList))
            } else {
              this.collectionGroupFilterList = this.collectionGroupList.filter(item => {
                return this.filterForm.managerIdList.join(',').indexOf(item.managerId) >= 0
              })
            }
          })
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .collector-group-QC-summary-wrapper {
    .length-1 {
      width: 140px;
    }
    .length-2 {
      width: 200px;
    }
    .length-3 {
      width: 220px;
    }
    .el-form-item {
      margin-bottom: 5px;
    }
    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }
  }
</style>
