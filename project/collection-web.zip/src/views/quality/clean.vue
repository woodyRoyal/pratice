<!-- 质检池清理 -->
<template>
  <div class="quality-control-clean-wrapper">

    <!-- 质检池清理表格开始-->
    <el-table :data="tableData" v-loading="listLoading" border stripe style="width: 100%" :max-height="tableHeight">
      <el-table-column align="center" prop="checkDate" label="抽检案件所属日期" min-width="80"></el-table-column>
      <el-table-column align="center" prop="checkingCases" label="录音总数" min-width="80"></el-table-column>
      <el-table-column align="center" prop="restCheckingCase" label="剩余未质检录音数" min-width="80"></el-table-column>
      <el-table-column align="center" label="操作" min-width="80">
        <template slot-scope="scope">
          <el-button v-if="scope.row.id" type="danger" size="mini" @click="cleanBtn(scope.row)">清除剩余</el-button>
          <span v-else>--</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 质检池清理表格结束-->

  </div>
</template>

<script>
  import {
    fetchGetCheckingPoolList,
    fetchDeleteCheckingPool
  } from '../../api/quality'

  export default {
    data () {
      return {
        tableHeight: 600,
        listLoading: false,
        tableData: []
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
      this.getTableData()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        let h = document.documentElement.clientHeight
        this.tableHeight = h - 230
      },
      getTableData () {
        // 列表开始加载
        this.listLoading = true
        fetchGetCheckingPoolList()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 清除按钮
      cleanBtn (value) {
        this.$confirm('此操作将清空' + value.checkDate + '剩余录音, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          fetchDeleteCheckingPool(JSON.stringify(value.id))
            .then(response => {
              let res = response.data
              if (res.errorCode === 0) {
                this.$message({
                  type: 'success',
                  message: '清除成功!'
                })
                this.getTableData()
              }
            })
            .catch(error => {
              console.log(error)
            })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消清除'
          })
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .quality-control-clean-wrapper {

  }
</style>
