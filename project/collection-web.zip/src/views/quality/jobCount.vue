<!-- 质检员工作统计 -->
<template>
  <div class="quality-control-job-account-wrapper">
    <!-- 筛选条件开始 -->
    <el-form :inline="true" :model="filterForm" class="filter-form">

      <el-form-item label="日期">
        <el-date-picker
          v-model="date"
          type="daterange"
          size="small"
          :editable="false"
          :clearable="false"
          class="length-3"
          placeholder="选择日期范围"
          :picker-options="pickerOptions1">
        </el-date-picker>
      </el-form-item>

      <el-form-item v-if="showSelectObj.isShowGroupSelect">
        <vue-el-select v-model="filterForm.leaderIdList" multiple filterable placeholder="请选择组长" size="small"
                       class="length-2" @visible-change="handleGroupLeaderVisibleChange">
          <el-option
            v-for="item in IQCLeaderList"
            :key="item.id"
            :label="item.displayName"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>
      <el-form-item v-if="showSelectObj.isShowPersonSelect">
        <vue-el-select v-model="filterForm.checkerIdList" multiple filterable placeholder="请选择质检员" size="small"
                       class="length-2" @visible-change="handleCheckerVisibleChange">
          <el-option
            v-for="item in checkerFilterList"
            :key="item.id"
            :label="item.displayName"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn" :loading="searchLoading">搜索</el-button>
        <el-button type="success" size="small" @click="exportBtn">导出</el-button>
      </el-form-item>
    </el-form>
    <!-- 筛选条件结束 -->
    <!-- 质检员工作统计表格开始-->
    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
      <el-table-column fixed align="center" prop="checkingDate" label="日期" min-width="80"></el-table-column>
      <el-table-column fixed align="center" prop="inspectorName" label="质检员" min-width="60"></el-table-column>
      <el-table-column fixed align="center" prop="groupLeader" label="组长" min-width="60"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="checkingCount"
                       label="当日质检量"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="checkingMistakeCount"
                       label="当日质检差错量"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="checkingPassCount"
                       label="当日复核通过量"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="monthCheckingCount"
                       label="本月累计质检量"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="monthCheckingMistakeCount"
                       label="本月累计质检差错量"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="monthCheckingPassCount"
                       label="本月累计复核通过量"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="dayCommonCount"
                       label="当日一般差错数量"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="daySeriousCount"
                       label="当日严重差错数量"></el-table-column>
      <el-table-column align="center" prop="sumCount" label="差错合计"></el-table-column>

      <el-table-column v-for="(item, index) in mistakeList" :key="index"
                       align="center" :label="item.value">
        <template slot-scope="scope">
          <span>{{ scope.row.qualityCheckingObj[item.code] }}</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 质检员工作统计结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { TABLE_TITLE_TIP } from './qualityConstant'
  import { parseTime } from '../../utils/formatDate'
  import { pickerOptions1 } from '../../utils/index'
  import {
    fetchGetQualityControlJobAccountList,
    fetchMistakeList,
    URL_EXPORT_IQC_JOB_ACCOUNT_DATA
  } from '../../api/quality'
  import {
    fetchQualitityCheckerList,
    fetchQualitityGroupList
  } from '../../api/common'
  import VueElSelect from '../../components/VueElSelect'
  import VueElTooltip from '../../components/VueElTooltip'

  export default {
    components: {
      VueElSelect, VueElTooltip
    },
    data () {
      return {
        searchLoading: false, // 搜索loading
        date: [new Date().getTime() - 3600 * 1000 * 24, new Date().getTime()],
        pickerOptions1,
        // 筛选数据
        filterForm: {
          startDate: parseTime(new Date().getTime() - 3600 * 1000 * 24, 'YYYY-MM-DD'), // 开始时间
          endDate: parseTime(new Date().getTime(), 'YYYY-MM-DD'), // 结束时间
          checkerIdList: [], // 质检员
          leaderIdList: [], // 组长
          mistakeIdList: [], // 差错类型
          mistakeLevelIdList: [], // 差错等级
          reviewStatusIdList: [], // 复核状态
          caseId: null, // 案件ID
          calledName: '' // 被叫人
        },
        // 差错类型列表
        mistakeList: [],
        // 质检员列表
        IQCList: [],
        checkerFilterList: [], // 联动过滤后列表
        // 质检组长列表
        IQCLeaderList: [],
        // 质检明细表格高度
        tableHeight: 600,
        listLoading: false,
        // 质检明细表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: null, // 总记录数
        pageSizes: [10, 50, 100, 500]
      }
    },
    computed: {
      ...mapGetters([
        'showSelectObj'
      ])
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)

      // 获取表格数据
      // this.getTableData()
      // 获取质检员和质检组信息
      // this.getQCMsg()
      // 获取差错类型
      this.getMistakeList()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        this.$nextTick(() => {
          let formHeight = document.getElementsByClassName('filter-form')[0].offsetHeight
          let h = document.documentElement.clientHeight
          if (formHeight >= 90) {
            this.tableHeight = h - 189
          } else if (formHeight >= 45) {
            this.tableHeight = h - 144
          }
        })
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        // 获取表格数据
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        // 获取表格数据
        this.getTableData()
      },
      // 获取表格数据
      getTableData () {
        this.searchLoading = true
        // 列表开始加载
        this.listLoading = true
        this.filterForm.startDate = parseTime(this.date[0], 'YYYY-MM-DD')
        this.filterForm.endDate = parseTime(this.date[1], 'YYYY-MM-DD')
        fetchGetQualityControlJobAccountList(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content.map(item => {
                // 表头render需要，因与其他页面字段重复，所以修改字段，区分
                item.dayCommonCount = item.commonCount
                item.daySeriousCount = item.seriousCount
                // 差错
                item.qualityCheckingObj = JSON.parse(item.qualityChecking)
                return item
              })
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
            this.searchLoading = false
          })
          .catch(error => {
            console.log(error)
            this.searchLoading = false
            this.listLoading = false
          })
      },
      // 获取差错类型列表
      getMistakeList () {
        fetchMistakeList()
          .then(response => {
            if (response.data.errorCode === 0 && response.data.data) {
              this.mistakeList = response.data.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 搜索按钮
      searchBtn () {
        this.getTableData()
      },
      // 导出按钮
      exportBtn () {
        let date = parseTime(new Date(), 'YYYYMMDDHHmmss')
        let url = ''
        // 导出后端不识别null
        if (this.filterForm.caseId === null) {
          let caseId = ''
          url = `${URL_EXPORT_IQC_JOB_ACCOUNT_DATA}?fileName=质检员工作统计-${date}.csv&startDate=${this.filterForm.startDate}
                    &endDate=${this.filterForm.endDate}&caseId=${caseId}&calledName=${this.filterForm.calledName}
                    &checkerIdList=${this.filterForm.checkerIdList}&leaderIdList=${this.filterForm.leaderIdList}
                    &mistakeIdList=${this.filterForm.mistakeIdList}&mistakeLevelIdList=${this.filterForm.mistakeLevelIdList}&reviewStatusIdList=${this.filterForm.reviewStatusIdList}`
        } else {
          url = `${URL_EXPORT_IQC_JOB_ACCOUNT_DATA}?fileName=质检员工作统计-${date}.csv&startDate=${this.filterForm.startDate}
                    &endDate=${this.filterForm.endDate}&caseId=${this.filterForm.caseId}&calledName=${this.filterForm.calledName}
                    &checkerIdList=${this.filterForm.checkerIdList}&leaderIdList=${this.filterForm.leaderIdList}
                    &mistakeIdList=${this.filterForm.mistakeIdList}&mistakeLevelIdList=${this.filterForm.mistakeLevelIdList}&reviewStatusIdList=${this.filterForm.reviewStatusIdList}`
        }
        window.location.href = url
      },
      // 表头
      renderHeader (createElement, {column}) {
        return createElement(VueElTooltip, {
          props: {
            label: column.label,
            content: TABLE_TITLE_TIP[column.property]
          }
        })
      },

      // 获取质检组列表
      getAllGroupList () {
        let promise = new Promise((resolve, reject) => {
          if (this.IQCLeaderList && this.IQCLeaderList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-QualityGroupList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.IQCLeaderList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchQualitityGroupList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.IQCLeaderList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-QualityGroupList', JSON.stringify(this.IQCLeaderList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 获取质检员列表
      getAllQualityCheckerList () {
        let promise = new Promise((resolve, reject) => {
          if (this.IQCList && this.IQCList.length > 0) {
            resolve()
          } else {
            // 先从本地读取
            const cacheList = window.localStorage.getItem('Collection-QualityCheckerList')
            if (cacheList && JSON.parse(cacheList) && JSON.parse(cacheList).length > 0) {
              this.IQCList = JSON.parse(cacheList)
              resolve()
            } else {
              // 本地没有数据 请求查询
              fetchQualitityCheckerList()
                .then(response => {
                  let res = response.data
                  if (res.errorCode === 0 && res.data) {
                    this.IQCList = res.data
                    // 存入本地
                    window.localStorage.setItem('Collection-QualityCheckerList', JSON.stringify(this.IQCList))
                  }
                  resolve()
                })
                .catch(error => {
                  console.log(error)
                  reject(error)
                })
            }
          }
        })
        return promise
      },
      // 催收组 下拉框出现/隐藏时触发
      handleGroupLeaderVisibleChange (visible) {
        if (visible) {
          this.getAllGroupList()
        }
      },
      // 催收员 下拉框出现/隐藏时触发
      handleCheckerVisibleChange (visible) {
        if (visible) {
          this.getAllQualityCheckerList().then(() => {
            // 然后过滤数据
            if (this.filterForm.leaderIdList.length === 0) {
              this.checkerFilterList = JSON.parse(JSON.stringify(this.IQCList))
            } else {
              this.checkerFilterList = this.IQCList.filter(item => {
                // 组选了 返回组下面的
                return this.filterForm.leaderIdList.join(',').indexOf(item.groupLeaderId) >= 0
              })
            }
          })
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .quality-control-job-account-wrapper {
    .length-1 {
      width: 140px;
    }
    .length-2 {
      width: 200px;
    }
    .length-3 {
      width: 220px;
    }
    .el-form-item {
      margin-bottom: 5px;
    }

    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }
  }
</style>
