/**
* Created by zuo on 2017/9/14.
*/

<template>
  <div class="home-content">欢迎使用 {{currentSysName}} v{{version}}</div>
</template>

<script type="text/ecmascript-6">
  import packageConfig from 'package'

  export default {
    computed: {
    },
    data () {
      return {
        currentSysName: packageConfig.sysname, // 当前系统名称
        version: packageConfig.version // 当前系统名称
      }
    }
  }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  .home-content {
    margin: 0 auto;
    color: #99A9BF;
    width: 340px;
    position: relative;
    top: 30%;
    font-size: 18px;
  }
</style>
