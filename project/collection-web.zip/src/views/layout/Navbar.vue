<template>
  <div class="navbar-wrapper">
    <div class="logo" :class="!sidebar.opened ? 'logo-collapse-width' : 'logo-width'">
      <img class="logo-img-title" src="../../assets/img/slogan.png" v-if="sidebar.opened" />
      <img class="logo-img" src="../../assets/img/logo.png" v-else />
    </div>
    <div class="sys-list">
      <ul ref="systemListUl">
        <li
            v-for="(item, index) in systemList"
            class="system-list-li"
            :key="index"
            v-if="item.sysCode !== 'ucenter'"
            :class="{'is-active': item.sysCode === currentSysName}"
            @click="handleChooseSys(item)">
          {{item.sysName}}
        </li>
      </ul>
    </div>
    <div class="arrow">
      <div class="arrow-left arrow-left-active" @click="handleSwitchSystem('left')" v-if="isShowLeft"><i class="el-icon-arrow-left"></i></div>
      <div class="arrow-left arrow-left-inactive" v-else><i class="el-icon-arrow-left"></i></div>
      <div class="arrow-right arrow-right-active" @click="handleSwitchSystem('right')" v-if="isShowRight"><i class="el-icon-arrow-right"></i></div>
      <div class="arrow-right arrow-right-inactive" v-else><i class="el-icon-arrow-right"></i></div>
    </div>
    <div class="user-info">
      <a title="退出" @click="logout">[退出]</a>
      <span>{{displayName}}</span>
      <a title="未结束的投诉数量" @click="openComplain">投诉（{{ complainNum }}）</a>
      <set-test v-if="isShowSetTest"></set-test>
    </div>
  </div>
</template>

<script>
  import { MESSAGEICON } from './layoutPic'
  import Push from 'push.js'
  import { mapGetters } from 'vuex'
  import packageConfig from 'package'
  import {UCENTER_LOGIN_URL} from 'api/login'
  import SetTest from './SetTest'
  import {
    fetchSaveOverdueActiveOperate,
    fetchHandleCurrentRemind,
    fetchCurrentRemindEvery5Minutes, // 今日提醒轮询接口
    fetchOverdueUserActiveInfoRemind, // 逾期激活用户轮询接口
    fetchFindComplainBillRemind, // 投诉轮询接口
    fetchGetComplainNum // 投诉数量
  } from '../../api/home'
  export default {
    data () {
      return {
        complainNum: 0, // 投诉数量
        lateLoginNum: null, // 逾期用户登录数
        todayRemindNo: {},
        lateLoginNo: {},
        complainNo: {},
        todayRemindData: [], // 今日提醒数据
        lateLoginData: [], // 近5天登录的用户
        complainData: [], // 投诉
        timeFunToday: null, // 定时器
        timeFunLate: null, // 定时器
        timeFunComplain: null, // 投诉定时器
        timeFunComplainNum: null, // 投诉数量定时器
        currentSysName: packageConfig.name, // 当前系统名称
        totalSysMenuWidth: 0, // 导航菜单总宽度
        boxClientWidth: 0, // 导航菜单最大宽度
        isShowLeft: false, // 是否显示左箭头
        isShowRight: false, // 是否显示右箭头
        moveValue: 100,
        dialogVisible: false,
        sortableObj: null,
        sysIdList: [], // 排序后的系统code
        pollingmark: '' // 投诉工单通知接口传输的唯一标识
      }
    },
    computed: {
      ...mapGetters([
        'sidebar',
        'displayName',
        'systemList',
        'username',
        'token'
      ]),
      // 是否展示SetTest组件
      isShowSetTest () {
        return window.location.origin !== 'https://managerdaikuan.2345.com'
      }
    },
    components: {SetTest},
    created () {
      // 获取生命周期开始时的时间戳
      this.pollingmark = new Date().getTime().toString()
      this.$store.dispatch('GetApplicationInfo')
    },
    mounted () {
      let _this = this

      // 获取通知以及今日提醒信息 每3分钟调取一次
      this.getNoticeInfoToday()
      _this.timeFunToday = setInterval(function () {
        this.todayRemindNo = {}
        _this.getNoticeInfoToday()
      }, 1000 * 60 * 3)

      // 获取最近激活用户信息
      // _this.getNoticeInfolate()
      // _this.timeFunLate = setInterval(function () {
      //   this.lateLoginNo = {}
      //   _this.getNoticeInfolate()
      // }, 1000 * 60 * 3)

      // 获取投诉通知
      _this.getNoticeInfoComplain()
      _this.timeFunComplain = setInterval(function () {
        this.complainNo = {}
        _this.getNoticeInfoComplain()
      }, 1000 * 60 * 3)

      // 获取投诉数量
      _this.getComplainNum()
      _this.timeFunComplainNum = setInterval(function () {
        _this.getComplainNum()
      }, 1000 * 60 * 3)

      this.$nextTick(() => {
        this.initSystemMenu()
      })
      window.addEventListener('resize', this.initSystemMenu)
    },
    deactivated () {
      window.removeEventListener('resize', this.initSystemMenu)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.initSystemMenu)
    },
    methods: {
      toggleSideBar () {
        this.$store.dispatch('ToggleSideBar')
      },
      logout () {
        Push.clear()
        clearInterval(this.timeFunToday)
        clearInterval(this.timeFunLate)
        if (!process.env.IS_NOT_SSO) { // 单点登录
          this.$store.dispatch('LogoutUcenter').then((val) => {
            if (val) {
              console.log('logout error!!!' + val)
              this.$message.warning(val)
            } else {
              // 返回到登录页
              if (window.location.host.indexOf('managerdaikuan.2345.com') > -1) {
                window.location.href = 'https://hjbackoffice.2345.com/ucenter/#/login'
              } else {
                window.location.href = UCENTER_LOGIN_URL
              }
            }
          })
        } else {
          this.$store.dispatch('Logout').then((val) => {
            if (val) {
              console.log('logout error!!!' + val)
              this.$message.warning(val)
            } else {
              this.$router.push({path: '/login'})
            }
          })
        }
      },
      // 处理跳转系统
      handleChooseSys (sys) {
        // 当前系统不跳转 非当前才跳转
        if (sys.sysCode !== this.currentSysName) {
          window.open(sys.defaultUrl + '?username=' + this.username + '&token=' + this.token) // 打开新窗口
        }
      },
      // 初始 计算是否需要左右切换箭头
      initSystemMenu () {
        this.boxClientWidth = this.$refs.systemListUl.clientWidth // 外面的容器
        let list = document.getElementsByClassName('system-list-li') // 所有列表元素
        this.totalSysMenuWidth = 0
        for (let i = 0; i < list.length; i++) {
          this.totalSysMenuWidth += list[i].offsetWidth // 所有列表元素的总宽度
        }
        let listBox = this.$refs.systemListUl // ul列表 主要是移动它的left值
        let listLeft = listBox.style.left ? listBox.style.left : '0px' // 当前位置
        let leftNum = parseInt(listLeft.substring(0, listLeft.indexOf('px'))) // 当前位置
        // 显示箭头
        if (this.totalSysMenuWidth > this.boxClientWidth) {
          if (leftNum === 0) {
            this.isShowLeft = false
            this.isShowRight = true
          } else {
            this.isShowLeft = true
            this.isShowRight = true
          }
        } else {
          this.isShowLeft = false
          this.isShowRight = false
          listBox.style.left = 0
        }
      },
      // 处理左右滑动导航菜单
      handleSwitchSystem (direction) {
        let listBox = this.$refs.systemListUl // ul列表 主要是移动它的left值
        let listLeft = listBox.style.left ? listBox.style.left : '0px' // 当前位置
        let leftNum = parseInt(listLeft.substring(0, listLeft.indexOf('px'))) // 当前位置
        let _offset = this.totalSysMenuWidth - this.boxClientWidth // 右边的偏移量 总共可以移动的距离

        if (direction === 'left') { // 向左
          if (leftNum >= -this.moveValue) { // 左边界 左不可点 右可点
            listBox.style.left = 0
            this.isShowLeft = false
            this.isShowRight = true
          } else { // 左可点 右可点
            listBox.style.left = (leftNum + this.moveValue) + 'px'
            this.isShowLeft = true
            this.isShowRight = true
          }
        } else { // 向右
          if (Math.abs(leftNum) - _offset >= 0) { // 右边界 左可点 右不可点
            listBox.style.left = -Math.abs(leftNum) + 'px'
            this.isShowLeft = true
            this.isShowRight = false
          } else {
            listBox.style.left = (leftNum - this.moveValue) + 'px'
            listBox = this.$refs.systemListUl // ul列表 主要是移动它的left值
            listLeft = listBox.style.left ? listBox.style.left : '0px' // 当前位置
            leftNum = parseInt(listLeft.substring(0, listLeft.indexOf('px'))) // 当前位置
            _offset = this.totalSysMenuWidth - this.boxClientWidth // 右边的偏移量 总共可以移动的距离
            if (Math.abs(leftNum) - _offset >= 0) { // 右边界
              this.isShowLeft = true
              this.isShowRight = false
            } else {
              if (leftNum === 0) {
                this.isShowLeft = false
                this.isShowRight = true
              } else {
                this.isShowLeft = true
                this.isShowRight = true
              }
            }
          }
        }
      },
      gotoUcenter () {
        window.location.href = process.env.UCENTER_API
      },
      // 轮询今日提醒接口
      getNoticeInfoToday () {
        fetchCurrentRemindEvery5Minutes()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.todayRemindData = res.data
              this.todayRemindNotice() // 调用提醒接口
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 轮询逾期用户激活接口待定
      getNoticeInfolate () {
        fetchOverdueUserActiveInfoRemind()
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              this.lateLoginData = res.data
              this.lateLoginNum = this.lateLoginData.length // 逾期用户登录数
              // 如果在首页则不跳转
              if (this.lateLoginData.length > 3) {
                this.getSpecialRemind() // 逾期用户过多时的提醒
              } else {
                this.lateLoginNotice()
              }
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 轮询投诉
      async getNoticeInfoComplain () {
        let response = await fetchFindComplainBillRemind(this.pollingmark)
        let res = response.data
        if (res.errorCode === 0) {
          this.complainData = res.data
          this.complainNotice()
        }
      },
      todayRemindNotice () {
        // 今日提醒通知
        this.todayRemindData.forEach((item, index) => {
          this.todayRemind(item, index)
        })
      },
      lateLoginNotice () {
        // 最近登录通知
        this.lateLoginData.forEach((item, index) => {
          this.lateLogin(item, index)
        })
      },
      complainNotice () {
        // 投诉通知
        this.complainData.forEach((item, index) => {
          this.complain(item, index)
        })
      },
      // 最近登录
      lateLogin (item, index) {
        let that = this
        that.lateLoginNo[index] = Push.create('用户打开App提醒', {
          body: item.userName + '打开了App',
          icon: MESSAGEICON,
          timeout: 30000,
          onClick: function () {
            window.focus()
            this.close()
            window.open('#/case-detail/' + item.caseId) // 跳转至案件详情页
            that.lateLoginLabel(item) // 操作变红
          }
        })
      },
      // 今日提醒
      todayRemind (item, index) {
        let that = this
        that.todayRemindNo[index] = Push.create('今日提醒', {
          body: item.contactName + ',' + item.callResultValue + ',' + item.memo,
          icon: MESSAGEICON,
          timeout: 30000,
          onClick: function () {
            window.focus()
            this.close()
            window.open('#/case-detail/' + item.caseId)
            that.todayRemindLabel(item) // 操作变红
          }
        })
      },
      // 投诉
      complain (item, index) {
        let that = this
        that.complainNo[index] = Push.create('催收投诉', {
          body: item.content,
          icon: MESSAGEICON,
          timeout: 30000,
          onClick: function () {
            window.focus()
            this.close()
            window.open('#/case/complain')
          }
        })
      },
      // 最近登录操作过的人变红
      lateLoginLabel (item) {
        // 先请求接口
        fetchSaveOverdueActiveOperate(item.caseId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              // 不管在哪个页面都请求接口，如果在首页则更新试图
              if (window.location.href.indexOf('/first/remind') > -1) {
                this.$store.dispatch('lateLoginSaveStatus', item.caseId)
              }
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      // 今日提醒操作过变红
      todayRemindLabel (item) {
        // 请求接口
        fetchHandleCurrentRemind(item.caseId)
          .then(response => {
            let res = response.data
            if (res.errorCode === 0) {
              // 如果在首页则更新试图
              if (window.location.href.indexOf('/first/remind') > -1) {
                this.$store.dispatch('todayRemindSaveStatus', item.caseId)
              }
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      getSpecialRemind () {
        let that = this
        Push.create('刚刚有' + this.lateLoginNum + '位用户打开App', {
          body: '打开了App',
          icon: MESSAGEICON,
          timeout: 30000,
          onClick: function () {
            window.focus()
            this.close()
            if (window.location.href.indexOf('/first/remind') === -1) {
              that.$router.push({path: '/first/remind'})
            }
          }
        })
      },
      // 投诉数量
      async getComplainNum () {
        let response = await fetchGetComplainNum()
        let res = response.data
        if (res.errorCode === 0) {
          this.complainNum = res.data
        }
      },
      // 打开投诉工单页
      openComplain () {
        window.open('#/case/complain')
      }
    }
  }
</script>
<style lang="scss" scoped>
  .navbar-wrapper {
    background-color: #324157;
    display: flex;
    /*左侧logo*/
    .logo {
      cursor: pointer;
      height: 40px;
      .logo-img-title {
        margin: 8px 24px;
      }
      .logo-img {
        margin: 8px 12px;
      }
    }
    /*长*/
    .logo-width {
      width: 180px;
    }
    /*短*/
    .logo-collapse-width {
      width: 50px
    }
    /*中间各个系统*/
    .sys-list {
      flex: 1;
      height: 40px;
      overflow: hidden; // 超出隐藏
      ul {
        position: relative; // 可以移动
        white-space: nowrap; // 不换行
        li {
          display: inline-block;
          color: #bfcbd9;
          cursor: pointer;
          font-size: 14px;
          padding: 0 10px;
          line-height: 40px;
          height: 40px;
          border-bottom: none;
          &:hover {
            color: #fff;
            border-bottom: 4px solid #2fc0ff;
          }
        }
        .is-active {
          color: #20a0ff;
          border-bottom: 4px solid #2fc0ff;
        }
      }
    }
    /* 箭头 */
    .arrow {
      display: flex;
      width: 80px;
      height: 40px;
      .arrow-left, .arrow-right {
        width: 40px;
        line-height: 40px;
        font-size: 14px;
        text-align: center;
        &:hover {
          background-color: #475669;
        }
      }

      .arrow-left-active, .arrow-right-active {
        cursor: pointer;
        color: #fff;
      }
      .arrow-left-inactive, .arrow-right-inactive {
        color: #333;
        &:hover {
          background-color: transparent;
        }
      }
    }
    /*设置*/
    .settings {
      width: 40px;
      height: 40px;
      line-height: 40px;
      color: #bfcbd9;
      cursor: pointer;
      text-align: center;
      &:hover {
        background-color: #475669;
        color: #fff;
      }
    }
    /*右侧登录用户信息*/
    .user-info {
      /*width: 160px;*/
      height: 40px;
      font-size: 12px;
      color: #bfcbd9;
      line-height: 40px;
      padding-right: 10px;
      display: flex;
      flex-direction: row-reverse;
      span {
        padding: 0 10px;
      }
      a {
        color: #95A5B4;
        &:hover {
          color: #20a0ff;
        }
      }
    }
    /*自定义dialog*/
    .defined-control-dialog-wrapper {
      position: fixed;
      z-index: 9999;
      left: 0;
      right: 0;
      top: 0;
      bottom: 0;
      margin: auto;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, .5);
      .defined-control-dialog {
        width: 80%;
        height: 240px;
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        margin: auto;
        border-radius: 2px;
        box-shadow: 0 1px 3px rgba(0,0,0,.3);
        border: 8px solid #666;
        border-color: rgba(0,0,0,.25);
        z-index: 99999;
        background-color: #fff;
        .dialog-header {
          padding: 0 20px;
        }
        .sys-list-wrapper {
          padding: 0 20px;
          height: 120px;
          ul {
            background-color: #324157;
            li {
              display: inline-block;
              color: #bfcbd9;
              cursor: move;
              font-size: 14px;
              padding: 0 10px;
              line-height: 40px;
              height: 40px;
              border-bottom: none;
              /*&:hover {*/
              /*color: #fff;*/
              /*border-bottom: 4px solid #2fc0ff;*/
              /*}*/
            }
            /*拖动的样式*/
            .sortable-ghost {
              background-color: #20a0ff;
            }
          }
        }
        .dialog-footer {
          padding: 0 20px;
          float: right;
        }
      }
    }
  }

</style>
