<template>
  <main class="content-container"
        :class="{'left-collapsed' :!sidebar.opened, 'left-expanded':sidebar.opened, 'is-fullscreen':isFullscreen}">
    <transition name="fade" mode="out-in">
      <keep-alive>
        <router-view :key="key"></router-view>
      </keep-alive>
    </transition>
  </main>
</template>

<script>
  import { mapGetters } from 'vuex'

  export default {
    name: 'AppMain',
    computed: {
      ...mapGetters([
        'sidebar',
        'isFullscreen'
      ]),
      key () {
        return this.$route.name !== undefined
          ? this.$route.name + +new Date()
          : this.$route + +new Date()
      }
    },
    created () {
      console.log('loading..........')
      this.refreshLoad()
    },
    methods: {
      refreshLoad () {
        if (!process.env.IS_NOT_SSO) { // 单点登录
          this.$store.dispatch('RefreshLoad').then(res => {
            console.log('refresh loaded sso...' + res)
          }).catch(err => {
            console.log(err)
          })
        }
      }
    }
  }
</script>

<style lang="scss">
  .content-container {
    position: absolute;
    height: calc(100% - 40px);
    overflow: auto;
    background: #fff;
    flex: 1;
    padding: 10px;
  }

  .left-collapsed {
    left: 50px;
    width: calc(100% - 50px);
  }

  .left-expanded {
    left: 180px;
    width: calc(100% - 180px);
  }

  .is-fullscreen {
    height: 100%;
    width: 100%;
    left: 0;
  }
</style>
