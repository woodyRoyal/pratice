<template>
  <aside class="sidebar-container" :class="!sidebar.opened ? 'menu-collapsed' : 'menu-expanded'">
    <!--导航菜单-->
    <el-menu :default-active="$route.path" mode="vertical" class="expanded-menu"
             @open="handleopen" @close="handleclose" @select="handleselect"
             unique-opened router v-show="sidebar.opened">
      <template v-for="(item, index) in permissionRouters" v-if="!item.hidden">
        <el-submenu :index="item.name" v-if="!item.noDropdown" :key="index">
          <template slot="title">
            <i :class="item.icon" aria-hidden="true"></i>
            {{item.name}}
          </template>
          <el-menu-item class="submenu-user-defined" v-for="child in item.children"
                        :index="item.path + '/' + child.path" :key="child.path"
                        v-if="!child.hidden">
            <i :class="child.icon" aria-hidden="true"></i>
            {{child.name}}
          </el-menu-item>
        </el-submenu>
        <el-menu-item v-if="item.noDropdown && item.children.length > 0"
                      :index="item.path + '/' + item.children[0].path"
                      :key="index">
          <i :class="item.children[0].icon" aria-hidden="true"></i>
          {{item.children[0].name}}
        </el-menu-item>
      </template>
    </el-menu>
    <!--导航菜单-折叠后-->
    <ul class="el-menu collapsed" v-show="!sidebar.opened" ref="menuCollapsed">
      <li v-for="(item, index) in permissionRouters" v-if="!item.hidden" class="el-submenu item" :key="index">
        <template v-if="!item.noDropdown">
          <div class="el-submenu__title" @mouseover="showMenu(index, true)" @mouseout="showMenu(index, false)">
            <i :class="item.icon" aria-hidden="true"></i>
          </div>
          <ul class="el-menu submenu" :class="'submenu-hook-'+index" @mouseover="showMenu(index, true)"
              @mouseout="showMenu(index, false)">
            <li v-for="child in item.children" v-if="!child.hidden" :key="child.path" class="el-menu-item"
                :class="{'is-active' : $route.path == item.path + '/' + child.path}"
                @click="$router.push(item.path + '/' + child.path)">
              {{child.name}}
            </li>
          </ul>
        </template>
        <template v-else>
          <div class="el-menu el-submenu" @mouseover="showMenu(index, true)" @mouseout="showMenu(index, false)">
            <div class="el-submenu__title el-menu-item" :class="{'is-active' :$route.path == item.children[0].path}"
                 @click="$router.push(item.path + '/' + item.children[0].path)">
              <i :class="item.children[0].icon" aria-hidden="true"></i>
            </div>
            <ul class="el-menu submenu" :class="'submenu-hook-'+index" @mouseover="showMenu(index, true)"
                @mouseout="showMenu(index, false)">
              <li class="el-menu-item"
                  :class="{'is-active' : $route.path == item.path + '/' + item.children[0].path}"
                  @click="$router.push(item.path + '/' + item.children[0].path)">
                {{item.children[0].name}}
              </li>
            </ul>
          </div>
        </template>
      </li>
    </ul>
    <div class="toggle-menu-collapsed" :title="sidebar.opened ? '收起':'展开'">
      <a @click="toggleSideBar" :class="[sidebar.opened ? 'menu-expanded':'menu-collapsed']">
        <i class="iconfont" :class="[sidebar.opened ? 'icon-arrow-left':'icon-arrow-right']"></i>
      </a>
    </div>
  </aside>
</template>

<script>
  import { mapGetters } from 'vuex'

  export default {
    name: 'Sidebar',
    data () {
      return {}
    },
    computed: {
      ...mapGetters([
        'sidebar',
        'permissionRouters'
      ])
    },
    created () {
      console.log(this.permissionRouters)
    },
    methods: {
      onSubmit () {
        console.log('submit!')
      },
      handleopen () {
        // console.log('handleopen');
      },
      handleclose () {
        // console.log('handleclose');
      },
      handleselect (path) {
        if (path === '/bench/batch') {
          window.open('#/case-detail-bench/')
        }
      },
      showMenu (i, status) {
        this.$refs.menuCollapsed.getElementsByClassName('submenu-hook-' + i)[0].style.display = status ? 'block' : 'none'
      },
      toggleSideBar () {
        this.$store.dispatch('ToggleSideBar')
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .sidebar-container {
    position: absolute;
    width: 180px;
    height: calc(100% - 40px);
    .iconfont {
      margin-right: 10px;
      font-size: 18px;
    }
    .expanded-menu {
      width: auto !important;
      overflow-y: auto !important;
    }
    .el-menu {
      height: calc(100% - 40px);
      border-radius: 0;
      background-color: #eef1f6;
      .el-submenu .el-menu-item {
        min-width: 0;
      }
      .el-menu-item, .el-submenu__title {
        height: 50px;
        line-height: 50px;
      }
      .el-menu-item:focus {
        background-color: #fff;
      }
      .el-menu-item:hover {
        background-color: #d1dbe5;
      }
    }
    .collapsed {
      width: 50px;
      .item {
        position: relative;
      }
      .submenu {
        position: absolute;
        top: 0px;
        left: 50px;
        z-index: 99999;
        height: auto;
        display: none;
      }
    }
    .el-menu-item, .el-submenu__title {
      padding: 0 16px;
    }
    .el-submenu {
      background: none;
    }
    .submenu-user-defined {
      padding-left: 35px !important;
    }
  }

  .menu-collapsed {
    width: 50px;
  }

  .menu-expanded {
    width: 180px;
  }

  .toggle-menu-collapsed a {
    position: fixed;
    bottom: 0;
    left: 0;
    font-size: 13px;
    height: 40px;
    text-align: center;
    line-height: 40px;
    transition-duration: .3s;
    outline: none;
    color: #48576a;
    background: #e4e8f1;
    .iconfont {
      margin: 0;
    }
  }

  /*滚动条整体部分 定义滚动条高宽及背景*/
  ::-webkit-scrollbar {
    width: 6px;
    height: 8px;
    background: none;
  }

  /*!*滚动条的轨道 内阴影+圆角*!*/
  ::-webkit-scrollbar-track-piece {
    background: none;
  }

  /*!*滚动条里面的滑块 内阴影+圆角*!*/
  ::-webkit-scrollbar-thumb {
    background-color: #8492A6;
    border-radius: 1px;
  }
</style>
