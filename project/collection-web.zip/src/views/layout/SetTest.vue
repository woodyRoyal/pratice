/*
* @Title: 切换电呼测试环境
* @Author: sunp
* @Date: 2019/4/16 19:40
*/
<template>
  <el-dropdown @command="handleCommand" style="margin-right: 10px;">
    <el-button type="text" style="font-size: 12px; color: #fff;">电呼接入：{{ currentTest }}</el-button>
    <el-dropdown-menu slot="dropdown">
      <el-dropdown-item command="T1">T1</el-dropdown-item>
      <el-dropdown-item command="T2">T2</el-dropdown-item>
      <el-dropdown-item command="T3">T3</el-dropdown-item>
    </el-dropdown-menu>
  </el-dropdown>
</template>

<script>
  import { mapGetters } from 'vuex'
  export default {
    name: 'SetTest',
    computed: {
      ...mapGetters([
        'currentTest'
      ])
    },
    methods: {
      handleCommand (command) {
        this.$store.dispatch('setCurrentTest', command)
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

</style>
