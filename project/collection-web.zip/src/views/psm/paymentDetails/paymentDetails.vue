<!-- 还款详情 -->
<template>
  <div class="payment-details-wrapper">

    <!-- tabs -->
    <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
      <el-tab-pane :disabled="productDisabled" label="产品" name="product">
        <pay-product></pay-product>
      </el-tab-pane>
      <el-tab-pane :disabled="companyDisabled" label="机构" name="company">
        <pay-company></pay-company>
      </el-tab-pane>
      <el-tab-pane :disabled="groupDisabled" label="组别" name="group">
        <pay-group></pay-group>
      </el-tab-pane>
      <el-tab-pane :disabled="personDisabled" label="个人" name="person">
        <pay-person></pay-person>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
  import payProduct from './components/payProduct'
  import payCompany from './components/payCompany'
  import payGroup from './components/payGroup'
  import payPerson from './components/payPerson'
  import { mapGetters } from 'vuex'

  export default {
    components: {
      payCompany, payGroup, payPerson, payProduct
    },
    computed: {
      ...mapGetters([
        'permissionList'
      ])
    },
    data () {
      return {
        activeName: 'product',
        companyDisabled: true,
        groupDisabled: true,
        personDisabled: true,
        productDisabled: true
      }
    },
    created () {
    },
    mounted () {
      this.permissionList.map(item => {
        if (item) {
          if (item === '*.*') {
            console.log('超级管理员')
            this.productDisabled = this.companyDisabled = this.groupDisabled = this.personDisabled = false
          } else {
            if (item.indexOf('repaymentDetailService.findRepaymentDetaiVolist') !== -1) {
              this.productDisabled = false
            }
            if (item.indexOf('repaymentDetailService.findRepaymentMachievSummaryVoList') !== -1) {
              this.companyDisabled = false
            }
            if (item.indexOf('repaymentDetailService.findRepaymentTeamSummaryVoList') !== -1) {
              this.groupDisabled = false
            }
            if (item.indexOf('repaymentDetailService.findRepaymentCollectorSummaryVoList') !== -1) {
              this.personDisabled = false
            }
          }
        }
      })
      if (!this.productDisabled) {
        this.activeName = 'product'
      } else {
        if (!this.companyDisabled) {
          this.activeName = 'company'
        } else {
          if (!this.groupDisabled) {
            this.activeName = 'group'
          } else {
            this.activeName = 'person'
          }
        }
      }
    },
    methods: {
      handleClick (tab, event) {
      }
    }
  }
</script>

<style lang="scss" scoped>
  .payment-details-wrapper {

  }
</style>
