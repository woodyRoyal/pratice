<!-- 还款详情-机构 -->
<template>
  <div class="pay-company-wrapper">

    <!-- 筛选条件 -->
    <el-form :inline="true" :model="filterForm" class="filter-form">

      <el-form-item label="还款日期">
        <el-date-picker
          v-model="assignCaseDate"
          format="yyyy-MM-dd"
          type="daterange"
          size="small"
          :editable="false"
          :clearable="false"
          class="length-3"
          placeholder="选择日期范围"
          :picker-options="pickerOptions">
        </el-date-picker>
      </el-form-item>

      <el-form-item label="" v-if="showSelectObj.isShowCompanySelect">
        <vue-el-select v-model="filterForm.companyList" multiple filterable placeholder="请选择机构" size="small"
                       @visible-change="getAllMechanList">
          <el-option
            v-for="item in collectionAgenciesList"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </vue-el-select>
      </el-form-item>

      <el-form-item label="">
        <vue-el-select v-model="filterForm.overDueList" multiple filterable placeholder="请选择逾期阶段" size="small">
          <el-option
            v-for="item in overdueLevelList"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </vue-el-select>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn">搜索</el-button>
        <el-button type="success" size="small" @click="exportBtn">导出</el-button>
      </el-form-item>

    </el-form>

    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
      <el-table-column align="center" prop="statictisDate" label="统计日期" min-width="80">
        <template slot-scope="scope">
          <span v-show="scope.row.weekNo === 6" style="color: green;">{{ scope.row.statictisDate }}</span>
          <span v-show="scope.row.weekNo === 0" style="color: red;">{{ scope.row.statictisDate }}</span>
          <span v-show="scope.row.weekNo >= 1 && scope.row.weekNo <= 5">{{ scope.row.statictisDate }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="machievName" label="机构" min-width="80"></el-table-column>
      <el-table-column align="center" prop="overdueLevel" label="逾期阶段" min-width="80"></el-table-column>
      <el-table-column align="center" prop="assignCollectorCount" label="分案人数" min-width="80"></el-table-column>
      <el-table-column align="center" prop="currCycleCasecount" label="当天回款件数" min-width="80"></el-table-column>
      <el-table-column align="center" prop="currCycleAmount" label="当天回款金额" min-width="80"></el-table-column>
      <el-table-column align="center" prop="avgPerCycleCount" label="人均回款件数" min-width="80"></el-table-column>
      <el-table-column align="center" prop="avgPerCycleAmount" label="人均回款金额" min-width="80"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="cycleCaseRate" label="回款率（件数）" min-width="80"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="cycleAmountRateStr" label="回款率（金额）" min-width="80"></el-table-column>
    </el-table>

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

  </div>
</template>

<script>
  import { pickerOptions3 } from '../../../../utils/index'
  import { parseTime, getWeekNo, lastMonthFirstDayToLastDay } from '../../../../utils/formatDate'
  import VueElSelect from '../../../../components/VueElSelect/index'
  import { CONST_OVERDUE_LEVEL_MAP } from '../../../case/caseConstant'
  import { fetchAllMechanList, fetchGetPayCompanyData, URL_EXPORT_PAY_COMPANY_DATA } from '../../../../api/psm'
  import VueElTooltip from '../../../../components/VueElTooltip'
  import { TABLE_TITLE_TIP } from '../../psmConstant'
  import { mapGetters } from 'vuex'

  export default {
    components: {
      VueElSelect, VueElTooltip
    },
    computed: {
      ...mapGetters([
        'showSelectObj'
      ])
    },
    data () {
      return {
        pickerOptions: pickerOptions3,
        // 当月1号-昨天
        assignCaseDate: [
          parseTime(new Date().setDate(1), 'YYYY-MM-DD'),
          parseTime(new Date().getTime() - 3600 * 1000 * 24, 'YYYY-MM-DD')
        ],
        filterForm: {
          startDate: null,
          endDate: null,
          companyList: [], // 机构列表
          overDueList: [], // 逾期阶段列表
          oderBy: '' // 排序
        },
        collectionAgenciesList: [], // 机构列表
        overdueLevelList: [
          { label: 'M1', value: 'M1' },
          { label: 'M2', value: 'M2' },
          { label: 'M3', value: 'M3' }
        ], // 逾期阶段列表
        // 表格
        tableHeight: 600,
        listLoading: false,
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: null, // 总记录数
        pageSizes: [10, 50, 100, 500],
        overdueLevelMap: CONST_OVERDUE_LEVEL_MAP // 逾期阶段字符串映射
      }
    },
    mounted () {
      this.dateJudge()
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
      // 获取表格数据
      // this.getTableData()
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        let h = document.documentElement.clientHeight
        this.tableHeight = h - 198
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 获取催收机构列表-公司
      getAllMechanList () {
        if (this.collectionAgenciesList && this.collectionAgenciesList.length > 0) {
          return false
        }
        let name = ''
        fetchAllMechanList(JSON.stringify(name))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.collectionAgenciesList = res.data
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      searchBtn () {
        this.getTableData()
      },
      dateJudge () {
        // 今天
        let today = parseTime(new Date(), 'YYYY-MM-DD')
        // 当月1号
        let date01 = parseTime(new Date().setDate(1), 'YYYY-MM-DD')
        // 如果当天时间是1号，则查询上月第一天之最后一天
        if (today === date01) {
          this.assignCaseDate = [
            lastMonthFirstDayToLastDay().firstDay,
            lastMonthFirstDayToLastDay().lastDay
          ]
        }
      },
      getTableData () {
        this.listLoading = true
        this.filterForm.startDate = parseTime(this.assignCaseDate[0], 'YYYY-MM-DD')
        this.filterForm.endDate = parseTime(this.assignCaseDate[1], 'YYYY-MM-DD')
        fetchGetPayCompanyData(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content.map(item => {
                // 表头字段注释
                item.cycleAmountRateStr = item.cycleAmountRate
                // 周几（增加字段）
                item.weekNo = getWeekNo(item.statictisDate)
                // item.weekNo = getWeekNo(item.statictisDateDisplay)
                return item
              })
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 导出按钮
      exportBtn () {
        this.filterForm.startDate = parseTime(this.assignCaseDate[0], 'YYYY-MM-DD')
        this.filterForm.endDate = parseTime(this.assignCaseDate[1], 'YYYY-MM-DD')
        let date = parseTime(new Date(), 'YYYY-MM-DD HH：mm：ss')
        let url = URL_EXPORT_PAY_COMPANY_DATA + '?fileName=机构还款情况表-' + date + '.csv&bo=' + encodeURI(JSON.stringify(this.filterForm))
        window.location.href = url
      },
      // 表头
      renderHeader (createElement, {column}) {
        return createElement(VueElTooltip, {
          props: {
            label: column.label,
            content: TABLE_TITLE_TIP[column.property]
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .pay-company-wrapper {

    .length-3 {
      width: 220px;
    }

    .el-form-item {
      margin-bottom: 5px;
    }

    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }

  }
</style>
