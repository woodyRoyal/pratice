<!-- 还款详情-个人 -->
<template>
  <div class="pay-person-wrapper">

    <!-- 筛选条件 -->
    <collection-psm-query-terms @search="searchBtn" @export="exportBtn" :dateRangeDefault="dateRange"
                                :pickerOptions="pickerOptions" dateLabel="还款日期">
    </collection-psm-query-terms>

    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
      <el-table-column align="center" prop="statictisDate" label="统计日期" min-width="80">
        <template slot-scope="scope">
          <span v-show="scope.row.weekNo === 6" style="color: green;">{{ scope.row.statictisDate }}</span>
          <span v-show="scope.row.weekNo === 0" style="color: red;">{{ scope.row.statictisDate }}</span>
          <span v-show="scope.row.weekNo >= 1 && scope.row.weekNo <= 5">{{ scope.row.statictisDate }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="collectorName" label="催收员" min-width="80"></el-table-column>
      <el-table-column align="center" prop="machievName" label="机构" min-width="80"></el-table-column>
      <el-table-column align="center" prop="managerName" label="催收经理" min-width="80"></el-table-column>
      <el-table-column align="center" prop="teamName" label="组别" min-width="80"></el-table-column>
      <el-table-column align="center" prop="currCycleCasecount" label="当天回款件数" min-width="80"></el-table-column>
      <el-table-column align="center" prop="currCycleAmount" label="当天回款金额" min-width="80"></el-table-column>
      <el-table-column align="center" prop="cycleCaseRate" label="回款率（件数）" min-width="80"></el-table-column>
      <el-table-column align="center" prop="cycleAmountRate" label="回款率（金额）" min-width="80"></el-table-column>
    </el-table>

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

  </div>
</template>

<script>
  import { pickerOptions3 } from '../../../../utils/index'
  import { parseTime, getWeekNo } from '../../../../utils/formatDate'
  import CollectionPsmQueryTerms from '../../../components/CollectionPsmQueryTerms.vue'
  import { fetchGetPayPersonData, URL_EXPORT_PAY_PERSON_DATA } from '../../../../api/psm'

  export default {
    components: {
      CollectionPsmQueryTerms
    },
    data () {
      return {
        pickerOptions: pickerOptions3,
        // 当月1号-昨天
        dateRange: [
          parseTime(new Date().getTime() - 3600 * 1000 * 24 * 30, 'YYYY-MM-DD'),
          parseTime(new Date().getTime() - 3600 * 1000 * 24, 'YYYY-MM-DD')
        ],
        filterForm: {},
        // 表格
        tableHeight: 600,
        listLoading: false,
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: null, // 总记录数
        pageSizes: [10, 50, 100, 500]
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        let h = document.documentElement.clientHeight
        this.tableHeight = h - 244
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      // 搜索按钮
      searchBtn (queryData) {
        this.filterForm = {
          startDate: queryData.startDate, // 开始时间
          endDate: queryData.endDate, // 结束时间
          collectorList: queryData.collectorIdList, // 催收员
          teamList: queryData.groupIdList, // 催收组
          managerlist: queryData.managerIdList, // 催收经理
          companyList: queryData.mechanIdList // 催收机构
        }

        this.getTableData()
      },
      getTableData () {
        this.listLoading = true
        fetchGetPayPersonData(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content.map(item => {
                // 周几（增加字段）
                item.weekNo = getWeekNo(item.statictisDate)
                return item
              })
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 导出按钮
      exportBtn (queryData) {
        this.filterForm = {
          startDate: queryData.startDate, // 开始时间
          endDate: queryData.endDate, // 结束时间
          collectorList: queryData.collectorIdList, // 催收员
          teamList: queryData.groupIdList, // 催收组
          managerlist: queryData.managerIdList, // 催收经理
          companyList: queryData.mechanIdList // 催收机构
        }

        let date = parseTime(new Date(), 'YYYY-MM-DD HH：mm：ss')
        let url = URL_EXPORT_PAY_PERSON_DATA + '?fileName=个人还款情况表-' + date + '.csv&bo=' + encodeURI(JSON.stringify(this.filterForm))
        window.location.href = url
      }
    }
  }
</script>

<style lang="scss" scoped>
  .pay-person-wrapper {
    .el-form-item {
      margin-bottom: 5px;
    }
    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }
  }
</style>
