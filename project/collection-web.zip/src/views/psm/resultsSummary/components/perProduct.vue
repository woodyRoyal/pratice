<!-- 业绩汇总-产品 -->
<template>
  <div class="per-product-wrapper">

    <!-- 筛选条件 -->
    <el-form :inline="true" :model="filterForm" class="filter-form">

      <el-form-item label="分案日期">
        <el-date-picker
          v-model="assignCaseDate"
          format="yyyy-MM-dd"
          type="daterange"
          size="small"
          :editable="false"
          :clearable="false"
          class="length-3"
          placeholder="选择日期范围"
          :picker-options="pickerOptions">
        </el-date-picker>
      </el-form-item>

      <el-form-item label="统计维度">
        <el-select v-model="filterForm.type" size="small"
                   class="length-1" @change="handleValueChange">
          <el-option
            v-for="item in options"
            :key="item.id"
            :label="item.label"
            :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn">搜索</el-button>
        <el-button type="success" size="small" @click="exportBtn">导出</el-button>
      </el-form-item>

    </el-form>

    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%"
              :max-height="tableHeight" v-show="filterForm.type === 2">
      <el-table-column align="center" prop="productName" label="产品类型" min-width="80"></el-table-column>
      <el-table-column align="center" prop="assignDiff" label="分案天数" min-width="80"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="overDueCaseAmount" label="该入催案件总金额（万元）"
                       min-width="80"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="assignCaseAmount" label="分案金额（万元）"
                       min-width="80"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="unAssignCaseAmount" label="未分配案件金额（万元）"
                       min-width="80"></el-table-column>
      <el-table-column align="center" prop="avgCollectorCount" label="日均分案人数" min-width="80"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="cycleAmount" label="回款金额（万元）"
                       min-width="80"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="cycleAmountRate" label="回款率（金额）"
                       min-width="80"></el-table-column>
      <el-table-column align="center" prop="unAssignCycleAmount" label="未分配案件回款（金额）（万元）"
                       min-width="80"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="unAssignCycleAmountRate" label="未分配案件回款率（金额）"
                       min-width="80"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="avgPerAmount" label="人均回款（金额）（万元）"
                       min-width="80"></el-table-column>
    </el-table>

    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%"
              :max-height="tableHeight" v-show="filterForm.type === 1">
      <el-table-column align="center" prop="productName" label="产品类型" min-width="80"></el-table-column>
      <el-table-column align="center" prop="assignDiff" label="分案天数" min-width="80"></el-table-column>
      <el-table-column align="center" prop="overDueCaseTotal" label="该入催案件数" min-width="80"></el-table-column>
      <el-table-column align="center" prop="assignCaseTotal" label="分案件数" min-width="80"></el-table-column>
      <el-table-column align="center" prop="unAssignCaseTotal" label="未分配案件数" min-width="80"></el-table-column>
      <el-table-column align="center" prop="avgCollectorCount" label="日均分案人数" min-width="80"></el-table-column>
      <el-table-column align="center" prop="cycleTotal" label="回款件数" min-width="80"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="cycleCaseCountRate" label="回款率（件数）"
                       min-width="80"></el-table-column>
      <el-table-column align="center" prop="unAssignCycleTotal" label="未分配案件回款（件数）" min-width="80"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="unAssignCycleTotalRate" label="未分配案件回款率（件数）"
                       min-width="80"></el-table-column>
      <el-table-column align="center" :render-header="renderHeader" prop="avgPerCaseTotal" label="人均回款（件数）"
                       min-width="80"></el-table-column>
    </el-table>
    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

  </div>
</template>

<script>
  import { pickerOptions3 } from '../../../../utils/index'
  import { parseTime, lastMonthFirstDayToLastDay } from '../../../../utils/formatDate'
  import VueElSelect from '../../../../components/VueElSelect/index'
  import { fetchGetPerProductData, URL_EXPORT_PER_PRODUCT_DATA } from '../../../../api/psm'
  import VueElTooltip from '../../../../components/VueElTooltip'
  import { TABLE_TITLE_TIP } from '../../psmConstant'

  export default {
    components: {
      VueElSelect, VueElTooltip
    },
    data () {
      return {
        pickerOptions: pickerOptions3,
        // 当月1号-昨天
        assignCaseDate: [
          parseTime(new Date().setDate(1), 'YYYY-MM-DD'),
          parseTime(new Date().getTime() - 3600 * 1000 * 24, 'YYYY-MM-DD')
        ],
        filterForm: {
          startDate: null,
          endDate: null,
          type: 2 // 1 件数 / 2 金额
        },
        options: [
          {id: 2, label: '金额'},
          {id: 1, label: '件数'}
        ],
        // 表格
        tableHeight: 600,
        listLoading: false,
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: null, // 总记录数
        pageSizes: [10, 50, 100, 500]
      }
    },
    mounted () {
      this.dateJudge()
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
      // 获取表格数据
      // this.getTableData()
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        let h = document.documentElement.clientHeight
        this.tableHeight = h - 198
      },
      deactivated () {
        window.removeEventListener('resize', this.handleResize)
      },
      beforeDestroy () {
        window.removeEventListener('resize', this.handleResize)
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },
      searchBtn () {
        this.getTableData()
      },
      dateJudge () {
        // 今天
        let today = parseTime(new Date(), 'YYYY-MM-DD')
        // 当月1号
        let date01 = parseTime(new Date().setDate(1), 'YYYY-MM-DD')
        // 如果当天时间是1号，则查询上月第一天之最后一天
        if (today === date01) {
          this.assignCaseDate = [
            lastMonthFirstDayToLastDay().firstDay,
            lastMonthFirstDayToLastDay().lastDay
          ]
        }
      },
      getTableData () {
        this.listLoading = true
        // this.dateJudge()
        this.filterForm.startDate = parseTime(this.assignCaseDate[0], 'YYYY-MM-DD')
        this.filterForm.endDate = parseTime(this.assignCaseDate[1], 'YYYY-MM-DD')
        let query = {
          assginStartDate: this.filterForm.startDate,
          assginEndDate: this.filterForm.endDate,
          type: this.filterForm.type
        }
        fetchGetPerProductData(JSON.stringify(query), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 改变金额、件数
      handleValueChange () {
        this.getTableData()
      },
      // 导出按钮
      exportBtn () {
        this.filterForm.startDate = parseTime(this.assignCaseDate[0], 'YYYY-MM-DD')
        this.filterForm.endDate = parseTime(this.assignCaseDate[1], 'YYYY-MM-DD')
        let query = {
          assginStartDate: this.filterForm.startDate,
          assginEndDate: this.filterForm.endDate,
          type: this.filterForm.type
        }
        let date = parseTime(new Date(), 'YYYY-MM-DD HH：mm：ss')
        let url = URL_EXPORT_PER_PRODUCT_DATA + '?fileName=产品业绩汇总表-' + date + '.csv&bo=' + encodeURI(JSON.stringify(query))
        window.location.href = url
      },
      // 表头
      renderHeader (createElement, {column}) {
        return createElement(VueElTooltip, {
          props: {
            label: column.label,
            content: TABLE_TITLE_TIP[column.property]
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .per-product-wrapper {

    .length-3 {
      width: 220px;
    }

    .el-form-item {
      margin-bottom: 5px;
    }

    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }

  }
</style>
