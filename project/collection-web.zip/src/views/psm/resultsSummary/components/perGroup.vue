<!-- 业绩汇总-组别 -->
<template>
  <div class="per-group-wrapper">

    <!-- 筛选条件 -->
    <collection-psm-query-terms @search="searchBtn" @export="exportBtn" :dateRangeDefault="dateRange"
                                :pickerOptions="pickerOptions" :level="3" dateLabel="分案日期">
    </collection-psm-query-terms>

    <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight"
              @sort-change="sortChange">
      <el-table-column align="center" prop="teamName" label="组别" min-width="80"></el-table-column>
      <el-table-column align="center" prop="teamLeader" label="组长" min-width="80"></el-table-column>
      <el-table-column align="center" prop="managerName" label="催收经理" min-width="80"></el-table-column>
      <el-table-column sortable="custom" align="center" prop="mechainName" label="机构" min-width="80"></el-table-column>
      <el-table-column sortable="custom" align="center" :render-header="renderHeader" prop="avgPerson" label="日均分案人数"
                       min-width="80"></el-table-column>
      <el-table-column sortable="custom" align="center" prop="caseCountTotal" label="分案件数"
                       min-width="80"></el-table-column>
      <el-table-column sortable="custom" align="center" :render-header="renderHeader" prop="caseAmountTotalStr"
                       label="分案金额" min-width="80"></el-table-column>
      <el-table-column sortable="custom" align="center" prop="cycleCaseTotal" label="回款件数"
                       min-width="80"></el-table-column>
      <el-table-column sortable="custom" align="center" prop="cycleAmountTotal" label="回款金额"
                       min-width="80"></el-table-column>
      <el-table-column sortable="custom" align="center" prop="cycleCountRate" label="回款率（件数）"
                       min-width="80"></el-table-column>
      <el-table-column sortable="custom" align="center" prop="cycleAmountRate" label="回款率（金额）"
                       min-width="80"></el-table-column>
    </el-table>

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->

  </div>
</template>

<script>
  import { pickerOptions3 } from '../../../../utils/index'
  import { parseTime, lastMonthFirstDayToLastDay } from '../../../../utils/formatDate'
  import CollectionPsmQueryTerms from '../../../components/CollectionPsmQueryTerms.vue'
  import { fetchGetPerGroupData, URL_EXPORT_PER_GROUP_DATA } from '../../../../api/psm'
  import VueElTooltip from '../../../../components/VueElTooltip'
  import { TABLE_TITLE_TIP } from '../../psmConstant'

  export default {
    components: {
      CollectionPsmQueryTerms, VueElTooltip
    },
    data () {
      return {
        pickerOptions: pickerOptions3,
        // 当月1号-昨天
        dateRange: [
          parseTime(new Date().setDate(1), 'YYYY-MM-DD'),
          parseTime(new Date().getTime() - 3600 * 1000 * 24, 'YYYY-MM-DD')
        ],
        filterForm: {},
        oderBy: '', // 排序
        tableHeight: 600,
        listLoading: false,
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: null, // 总记录数
        pageSizes: [10, 50, 100, 500]
      }
    },
    mounted () {
      this.dateJudge()
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        let h = document.documentElement.clientHeight
        this.tableHeight = h - 198
      },
      deactivated () {
        window.removeEventListener('resize', this.handleResize)
      },
      beforeDestroy () {
        window.removeEventListener('resize', this.handleResize)
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        this.getTableData()
      },

      // 搜索按钮
      searchBtn (queryData) {
        this.filterForm = {
          startDate: queryData.startDate, // 开始时间
          endDate: queryData.endDate, // 结束时间
          collectorList: queryData.collectorIdList, // 催收员
          teamList: queryData.groupIdList, // 催收组
          managerlist: queryData.managerIdList, // 催收经理
          companyList: queryData.mechanIdList, // 催收机构
          oderBy: this.oderBy
        }

        this.getTableData()
      },
      dateJudge () {
        // 今天
        let today = parseTime(new Date(), 'YYYY-MM-DD')
        // 当月1号
        let date01 = parseTime(new Date().setDate(1), 'YYYY-MM-DD')
        // 如果当天时间是1号，则查询上月第一天之最后一天
        if (today === date01) {
          this.assignCaseDate = [
            lastMonthFirstDayToLastDay().firstDay,
            lastMonthFirstDayToLastDay().lastDay
          ]
        }
      },
      getTableData () {
        this.listLoading = true
        // this.dateJudge()
        fetchGetPerGroupData(JSON.stringify(this.filterForm), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content.map(item => {
                // 表头字段注释
                item.caseAmountTotalStr = item.caseAmountTotal
                return item
              })
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 导出按钮
      exportBtn (queryData) {
        this.filterForm = {
          startDate: queryData.startDate, // 开始时间
          endDate: queryData.endDate, // 结束时间
          collectorList: queryData.collectorIdList, // 催收员
          teamList: queryData.groupIdList, // 催收组
          managerlist: queryData.managerIdList, // 催收经理
          companyList: queryData.mechanIdList, // 催收机构
          oderBy: this.oderBy
        }

        let date = parseTime(new Date(), 'YYYY-MM-DD HH：mm：ss')
        let url = URL_EXPORT_PER_GROUP_DATA + '?fileName=组别业绩汇总表-' + date + '.csv&bo=' + encodeURI(JSON.stringify(this.filterForm))
        window.location.href = url
      },
      // 排序
      sortChange (obj) {
        if (obj.order === 'ascending') {
          this.oderBy = `order by ${obj.prop} asc`
        } else if (obj.order === 'descending') {
          this.oderBy = `order by ${obj.prop} desc`
        }
        this.getTableData()
      },
      // 表头
      renderHeader (createElement, {column}) {
        return createElement(VueElTooltip, {
          props: {
            label: column.label,
            content: TABLE_TITLE_TIP[column.property]
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .per-group-wrapper {

    .el-form-item {
      margin-bottom: 5px;
    }

    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }
  }
</style>
