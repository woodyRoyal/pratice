<!-- 业绩汇总 -->
<template>
  <div class="results-summary-wrapper">

    <!-- tabs -->
    <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
      <el-tab-pane :disabled="companyDisabled" label="机构" name="company">
        <per-company></per-company>
      </el-tab-pane>
      <el-tab-pane :disabled="groupDisabled" label="组别" name="group">
        <per-group></per-group>
      </el-tab-pane>
      <el-tab-pane :disabled="personDisabled" label="个人" name="person">
        <per-person></per-person>
      </el-tab-pane>
      <el-tab-pane :disabled="productDisabled" label="产品" name="product">
        <per-product></per-product>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
  import perCompany from './components/perCompany'
  import perGroup from './components/perGroup'
  import perPerson from './components/perPerson'
  import perProduct from './components/perProduct'
  import { mapGetters } from 'vuex'

  export default {
    components: {
      perCompany, perGroup, perPerson, perProduct
    },
    computed: {
      ...mapGetters([
        'permissionList'
      ])
    },
    data () {
      return {
        activeName: 'company',
        companyDisabled: true,
        groupDisabled: true,
        personDisabled: true,
        productDisabled: true
      }
    },
    created () {
    },
    mounted () {
      this.permissionList.map(item => {
        if (item) {
          if (item === '*.*') {
            console.log('超级管理员')
            this.productDisabled = this.companyDisabled = this.groupDisabled = this.personDisabled = false
          } else {
            if (item.indexOf('achievSummaryDetailService.findAchievProductSumlList') !== -1) {
              this.productDisabled = false
            }
            if (item.indexOf('achievSummaryDetailService.findMechanSummaryDetailList') !== -1) {
              this.companyDisabled = false
            }
            if (item.indexOf('achievSummaryDetailService.findTeamSummaryDetailList') !== -1) {
              this.groupDisabled = false
            }
            if (item.indexOf('achievSummaryDetailService.findCollectorSummaryDetailList') !== -1) {
              this.personDisabled = false
            }
          }
        }
      })
      if (!this.companyDisabled) {
        this.activeName = 'company'
      } else {
        if (!this.groupDisabled) {
          this.activeName = 'group'
        } else {
          if (!this.personDisabled) {
            this.activeName = 'person'
          } else {
            this.activeName = 'product'
          }
        }
      }
      //      if (this.roleLevel === 5) {
      //        this.companyDisabled = this.groupDisabled = this.productDisabled = true
      //        this.activeName = 'person'
      //      } else if (this.roleLevel === 4) {
      //        this.companyDisabled = this.productDisabled = true
      //        this.activeName = 'group'
      //      } else if (this.roleLevel === 3 || this.roleLevel === 2) {
      //        this.productDisabled = true
      //        this.activeName = 'company'
      //      }
    },
    methods: {
      handleClick (tab, event) {
      }
    }
  }
</script>

<style lang="scss" scoped>
  .results-summary-wrapper {

  }
</style>
