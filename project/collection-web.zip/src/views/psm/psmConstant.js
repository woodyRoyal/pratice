/* psm 常量 */

// 阶段变化   phaseChange
export const CONST_PHASE_CHANGE_MAP = {
  1: 'phase_01',
  2: 'phase_02',
  3: 'phase_03'
}

// 按金额，按件数   transferType
export const CONST_TRANSFER_TYPE_MAP = {
  1: 'type_money',
  2: 'type_case'
}

// 产品
export const CONST_PRODUCT_MAP = {
  JKD_APP: '双周贷',
  DKW_APP: '单月贷'
}

// 表头注释
export const TABLE_TITLE_TIP = {
  // 业绩汇总-机构
  avgPerson: '每天人数求和/分案天数，取整',
  caseAmountTotal: '公司级数据，单位万元，保留两位小数',
  cycleCaseTotal: '截止换阶段或昨日的求和',
  cycleAmountTotal: '截止换阶段或昨日的求和',
  perPersonCapacity: '分案件数/日均分案人数',
  cycleCountRate: '回款件数/分案件数',
  cycleAmountRate: '回款金额/分案金额',
  // 业绩汇总-组别
  // avgPerson: '每天人数求和/分案天数，取整',
  caseAmountTotalStr: '组级数据，单位万元，保留两位小数',
  // 业绩汇总-个人
  assginAmount: '个人级数据，单位元，保留两位小数',
  // 业绩汇总-产品-金额
  overDueCaseAmount: '导入催收库的时间开始计算；转换阶段的案件需要去重',
  assignCaseAmount: '转换阶段的案件需要去重；手动重分也去重，历史分案数据会变更；所选日期范围内的案件，在所选日期的分案量',
  unAssignCaseAmount: '所选日期范围内的案件，在所选日期的未分案量',
  cycleAmount: '根据分案数据计算回款金额',
  // cycleAmountRate: '回款金额/分案金额',
  unAssignCycleAmountRate: '未分配案件回款金额/未分配案件金额',
  avgPerAmount: '回款金额/分案人数',
  // 业绩汇总-产品-件数
  cycleCaseCountRate: '回款件数/分案件数',
  unAssignCycleTotalRate: '未分配案件回款件数/未分配案件件数',
  avgPerCaseTotal: '回款件数/分案人数',
  // 还款详情-产品
  currentRepaymentAmount: '日期当天的还款金额',
  currMonthCumulation: '本月截止日期当天的还款金额',
  lastMonthCumulation: '上月同期累计还款金额（万）',
  currentCollector: '日期当天参与分案的人力',
  avgCurrentCycleamount: '当天还款金额(万)/在职人力',
  avgdayIncrease: '(人均回款金额(万)-日期前一天的人均回款金额(万)) / 日期前一天的人均回款金额(万)；正数用红色,负数用绿色,百分比显示,2位小数',
  // 还款详情-机构
  cycleCaseRate: '当天回款件数/本月累计分案件数；组别、个人表同理',
  cycleAmountRateStr: '当天回款金额/本月累计分案金额；组别、个人表同理'
  // 还款详情-组别
  // 还款详情-个人
}
