/**
* 迁移率
* Created on 2017/10/11.
*/

<template>
  <div class="mobility-wrapper">
    <!-- 筛选条件开始 -->
    <el-form :inline="true" :model="filterForm" class="filter-form">
      <el-form-item>
        <el-select v-model="filterForm.overdueRange" size="small"
                   class="length-1" @change="overdueRangeChange">
          <el-option
            v-for="item in overdueRangeList"
            :key="item.id"
            :label="item.label"
            :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-select v-model="filterForm.amountOrCount" size="small"
                   class="length-1" @change="amountOrCountChange">
          <el-option
            v-for="item in amountOrCountList"
            :key="item.id"
            :label="item.label"
            :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-select v-model="filterForm.productIds" placeholder="请选择产品" size="small"
                   class="length-2" clearable>
          <el-option
            v-for="item in productInfoList"
            :key="item.productId"
            :label="item.name"
            :value="item.productId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" size="small" @click="searchBtn">搜索</el-button>
        <el-button type="success" size="small" @click="exportBtn">导出</el-button>
      </el-form-item>
    </el-form>
    <!-- 筛选条件结束 -->

    <!-- 表格数据开始-->
    <div v-show="filterForm.overdueRange === 1">
      <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
        <el-table-column align="center" prop="borrowDate" label="借款日期" min-width="50">
          <template slot-scope="scope">
            <span v-if="scope.row.weekNo === 6" style="color: green;">{{ scope.row.borrowDate }}</span>
            <span v-else-if="scope.row.weekNo === 0" style="color: red;">{{ scope.row.borrowDate }}</span>
            <span v-else>{{ scope.row.borrowDate }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="productName" label="产品" min-width="40"></el-table-column>

        <el-table-column align="center" prop="borrowAmount" :label="filterForm.amountOrCount === 1 ? '借款金额' : '借款件数'"
                         min-width="50">
          <template slot-scope="scope">
            <span>{{ scope.row.borrowAmount }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="M1逾期率" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m1OverdualRate ? Math.round(scope.row.m1OverdualRate * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="M2逾期率" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m2OverdualRate ? Math.round(scope.row.m2OverdualRate * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="m1M2" label="M1~M2" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m1M2 ? Math.round(scope.row.m1M2 * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div v-show="filterForm.overdueRange === 2">
      <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
        <el-table-column align="center" prop="borrowDate" label="借款日期" min-width="50">
          <template slot-scope="scope">
            <span v-if="scope.row.weekNo === 6" style="color: green;">{{ scope.row.borrowDate }}</span>
            <span v-else-if="scope.row.weekNo === 0" style="color: red;">{{ scope.row.borrowDate }}</span>
            <span v-else>{{ scope.row.borrowDate }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="productName" label="产品" min-width="40"></el-table-column>

        <el-table-column align="center" prop="borrowAmount" :label="filterForm.amountOrCount === 1 ? '借款金额' : '借款件数'"
                         min-width="50">
          <template slot-scope="scope">
            <span v-if="filterForm.amountOrCount === 1">{{ scope.row.borrowAmount }}</span>
            <span v-else>{{ scope.row.borrowAmount }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="M1逾期率" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m1OverdualRate ? Math.round(scope.row.m1OverdualRate * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="M2逾期率" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m2OverdualRate ? Math.round(scope.row.m2OverdualRate * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="M3逾期率" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m3OverdualRate ? Math.round(scope.row.m3OverdualRate * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="m1M2" label="M1~M2" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m1M2 ? Math.round(scope.row.m1M2 * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="m2M3" label="M2~M3" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m2M3 ? Math.round(scope.row.m2M3 * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="m1M3" label="M1~M3" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m1M3 ? Math.round(scope.row.m1M3 * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>

      </el-table>
    </div>
    <div v-show="filterForm.overdueRange === 3">
      <el-table :data="tableData" v-loading="listLoading" stripe border style="width: 100%" :max-height="tableHeight">
        <el-table-column align="center" prop="borrowDate" label="借款日期" min-width="50">
          <template slot-scope="scope">
            <span v-if="scope.row.weekNo === 6" style="color: green;">{{ scope.row.borrowDate }}</span>
            <span v-else-if="scope.row.weekNo === 0" style="color: red;">{{ scope.row.borrowDate }}</span>
            <span v-else>{{ scope.row.borrowDate }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="productName" label="产品" min-width="40"></el-table-column>

        <el-table-column align="center" prop="borrowAmount" :label="filterForm.amountOrCount === 1 ? '借款金额' : '借款件数'"
                         min-width="50">
          <template slot-scope="scope">
            <span v-if="filterForm.amountOrCount === 1">{{ scope.row.borrowAmount }}</span>
            <span v-else>{{ scope.row.borrowAmount }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="M1逾期率" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m1OverdualRate ? Math.round(scope.row.m1OverdualRate * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="M2逾期率" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m2OverdualRate ? Math.round(scope.row.m2OverdualRate * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="M3逾期率" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m3OverdualRate ? Math.round(scope.row.m3OverdualRate * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" prop="m4OverdualRate" label="M4逾期率" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m4OverdualRate ? Math.round(scope.row.m4OverdualRate * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" prop="m1M2" label="M1~M2" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m1M2 ? Math.round(scope.row.m1M2 * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="m2M3" label="M2~M3" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m2M3 ? Math.round(scope.row.m2M3 * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="m3M4" label="M3~M4" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m3M4 ? Math.round(scope.row.m3M4 * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="m1M4" label="M1~M4" min-width="40">
          <template slot-scope="scope">
            <span>{{ scope.row.m1M4 ? Math.round(scope.row.m1M4 * 10000, 10) / 100 + '%' : 0 }}</span>
          </template>
        </el-table-column>

      </el-table>
    </div>

    <!-- 表格数据结束-->

    <!-- 分页开始-->
    <div v-show="!listLoading" class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagData.pageNo" :page-sizes="pageSizes"
                     :page-size="pagData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord">
      </el-pagination>
    </div>
    <!-- 分页结束-->
  </div>
</template>

<script>
  import { parseTime, getWeekNo } from '../../utils/formatDate'
  import VueElSelect from '../../components/VueElSelect'
  import {
    fetchGetTransferAmountData,
    URL_EXPORT_TRANSFER_AMOUNT_DATA
  } from '../../api/psm'
  import { CONST_PHASE_CHANGE_MAP, CONST_TRANSFER_TYPE_MAP } from './psmConstant'
  import { getFenToYuanCurrency } from '../../utils/index'

  export default {
    components: {
      VueElSelect
    },
    data () {
      return {
        // 筛选数据
        filterForm: {
          overdueRange: 1, // 逾期阶段
          amountOrCount: 1, // 金额或件数
          productIds: '' // 产品信息
        },
        overdueRangeList: [ // 阶段变化
          {id: 1, label: 'M1~M2'},
          {id: 2, label: 'M1~M3'},
          {id: 3, label: 'M1~M4'}
        ],
        amountOrCountList: [ // 金额、件数
          {id: 1, label: '金额'},
          {id: 2, label: '件数'}
        ],
        productInfoList: [], // 产品信息列表
        // 质检明细表格高度
        tableHeight: 600,
        listLoading: false,
        // 质检明细表格数据
        tableData: [],
        pagData: {
          pageSize: 100, // 每页条数
          pageNo: 1 // 页码
        },
        totalRecord: 0, // 总记录数
        pageSizes: [10, 50, 100, 500]
      }
    },
    mounted () {
      // 表格高度
      this.handleResize()
      window.addEventListener('resize', this.handleResize)

      // 获取产品
      this.getAllProductList()
    },
    methods: {
      // resize回调修改表格高度
      handleResize (event) {
        let h = document.documentElement.clientHeight
        this.tableHeight = h - 140
      },
      deactivated () {
        window.removeEventListener('resize', this.handleResize)
      },
      beforeDestroy () {
        window.removeEventListener('resize', this.handleResize)
      },
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.pagData.pageSize = val
        // 获取表格数据
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.pagData.pageNo = val
        // 获取表格数据
        this.getTableData()
      },
      // 获取产品列表
      getAllProductList () {
        this.productInfoList = [
          {productId: '1001', name: '单月贷'},
          {productId: '1002', name: '双周贷'}
        ]
      },
      // 阶段 迁移率 变化
      overdueRangeChange () {
        this.getTableData()
        // this.tableData = []
      },
      // 金额 件数 变化
      amountOrCountChange () {
        this.getTableData()
        // this.tableData = []
      },
      // 获取表格数据
      getTableData () {
        // 列表开始加载
        this.listLoading = true
        let query = {
          phaseChange: CONST_PHASE_CHANGE_MAP[this.filterForm.overdueRange],
          transferType: CONST_TRANSFER_TYPE_MAP[this.filterForm.amountOrCount],
          productType: this.filterForm.productIds
        }
        fetchGetTransferAmountData(JSON.stringify(query), JSON.stringify(this.pagData))
          .then(response => {
            let res = response.data
            if (res.errorCode === 0 && res.data) {
              this.tableData = res.data.content.map(item => {
                if (this.filterForm.amountOrCount === 1) {
                  item.borrowAmount = getFenToYuanCurrency(item.borrowAmount)
                }
                // 周几（增加字段）
                item.weekNo = getWeekNo(item.borrowDate)
                return item
              })
              this.totalRecord = res.data.totalRecord
            }
            this.listLoading = false
          })
          .catch(error => {
            console.log(error)
            this.listLoading = false
          })
      },
      // 搜索按钮
      searchBtn () {
        this.getTableData()
      },
      // 导出按钮
      exportBtn () {
        let query = {
          phaseChange: CONST_PHASE_CHANGE_MAP[this.filterForm.overdueRange],
          transferType: CONST_TRANSFER_TYPE_MAP[this.filterForm.amountOrCount],
          productType: this.filterForm.productIds
        }
        console.log(query)
        let date = parseTime(new Date(), 'YYYY-MM-DD HH：mm：ss')
        let url = URL_EXPORT_TRANSFER_AMOUNT_DATA + '?fileName=迁移率表' + date + '.csv&param=' + encodeURI(JSON.stringify(query))
        window.location.href = url
      }
    }
  }
</script>

<style lang="scss" scoped>
  .mobility-wrapper {
    .length-1 {
      width: 100px;
    }
    .length-2 {
      width: 180px;
    }
    .el-form-item {
      margin-bottom: 5px;
    }

    .pagination-container {
      margin-top: 5px;
      margin-bottom: 0;
    }
  }
</style>
