<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
  export default {
    name: 'APP'
  }
</script>
<style lang="scss">
  /* 信用修复系统图标 */
  @import url(//at.alicdn.com/t/font_394168_6cje5uhux8u.css);
  /*滚动条整体部分 定义滚动条高宽及背景*/
  ::-webkit-scrollbar {
    width: 15px;
    height: 15px;
    background: none;
  }

  /*!*滚动条的轨道 内阴影+圆角*!*/
  ::-webkit-scrollbar-track-piece {
    background: none;
  }

  /*!*滚动条里面的滑块 内阴影+圆角*!*/
  ::-webkit-scrollbar-thumb {
    background-color: #8492A6;
    border-radius: 1px;
  }
</style>
