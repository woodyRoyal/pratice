import Vue from 'vue'
import Router from 'vue-router'

/* layout */
import Layout from '../views/layout/Layout'

/* login */
import Login from '../views/login/'
import authRedirect from '../views/login/authredirect'
import sendPWD from '../views/login/sendpwd'
import reset from '../views/login/reset'
import packageConfig from 'package'

/* error page */
const Err404 = resolve => require(['../views/error/404'], resolve)
const Err401 = resolve => require(['../views/error/401'], resolve)
const Home = resolve => require(['../views/layout/Home'], resolve)

/* home first */
const First = resolve => require(['../views/home/index'], resolve)

/* case manage */
const CaseAssignImport = resolve => require(['../views/case/assignImport'], resolve)
const CaseUpperLimit = resolve => require(['../views/case/upperLimit'], resolve)
const CaseAssignableConfig = resolve => require(['../views/case/assignableConfig'], resolve)
const CaseUnassignedExport = resolve => require(['../views/case/unassignedExport.vue'], resolve)
const ImportCase = resolve => require(['../views/case/importCase.vue'], resolve)
const AssignCase = resolve => require(['../views/case/assignCase.vue'], resolve)
const CaseQuery = resolve => require(['../views/case/caseQuery.vue'], resolve)
const CaseDetail = resolve => require(['../views/case/caseDetail.vue'], resolve)
const CaseDetailBatch = resolve => require(['../views/case/caseDetailBatch.vue'], resolve)
const CaseDetailBench = resolve => require(['../views/case/caseDetailBench.vue'], resolve)
const CaseDetailImage = resolve => require(['../views/case/caseDetailImage.vue'], resolve)
const HistoryCaseQuery = resolve => require(['../views/case/historyCaseQuery.vue'], resolve)
const CaseComplain = resolve => require(['../views/case/complain.vue'], resolve)

/* sms */
const SmsTemplate = resolve => require(['../views/sms/smsTemplate'], resolve)
const SmsHistory = resolve => require(['../views/sms/smsHistory'], resolve)
const SmsAudit = resolve => require(['../views/sms/smsAudit'], resolve)

/* quality Control */
const QualityIndex = resolve => require(['../views/quality/index'], resolve)
const QualityDetail = resolve => require(['../views/quality/detail'], resolve)
const QualityConfig = resolve => require(['../views/quality/config'], resolve)
const QualityClean = resolve => require(['../views/quality/clean'], resolve)
const QualityJobCount = resolve => require(['../views/quality/jobCount'], resolve)
const QualitySummary = resolve => require(['../views/quality/summary'], resolve)
const CollectorDetail = resolve => require(['../views/quality/collectorDetail'], resolve)
const CollectorSummary = resolve => require(['../views/quality/collectorSummary'], resolve)
const CollectionGroupSummary = resolve => require(['../views/quality/collectionGroupSummary'], resolve)

/* Collection statistics management */
const CollectorDaily = resolve => require(['../views/csm/collectorDaily'], resolve)
const CollectorMonthly = resolve => require(['../views/csm/collectorMonthly'], resolve)
const LateStageDaily = resolve => require(['../views/csm/lateStageDaily'], resolve)
const LateStageMonthly = resolve => require(['../views/csm/lateStageMonthly'], resolve)
const DataExport = resolve => require(['../views/csm/dataExport'], resolve)
const AssignCaseCount = resolve => require(['../views/csm/assignCaseCount'], resolve)
const BenchData = resolve => require(['../views/csm/benchData'], resolve)

/* Performance statistics management */
const ResultsSummary = resolve => require(['../views/psm/resultsSummary/resultsSummary'], resolve)
const PaymentDetails = resolve => require(['../views/psm/paymentDetails/paymentDetails'], resolve)
const PerformanceMobility = resolve => require(['../views/psm/mobility'], resolve)

/* system */
const SystemMenu = resolve => require(['../views/system/menu'], resolve)
const SystemPermission = resolve => require(['../views/system/permission'], resolve)
// const SystemGroup = resolve => require(['../views/system/group'], resolve)
const SystemRole = resolve => require(['../views/system/role'], resolve)
const SystemUser = resolve => require(['../views/system/user'], resolve)
const SystemSchedule = resolve => require(['../views/system/schedule'], resolve)
const SystemParameter = resolve => require(['../views/system/parameter'], resolve)
const SystemProductSettings = resolve => require(['../views/system/productSettings'], resolve)
const FrequencyRestriction = resolve => require(['../views/system/frequencyRestriction'], resolve)
const SystemGroup = resolve => require(['../views/system/group'], resolve)
/* callrecord */
const CallProject = resolve => require(['../views/call/callProject'], resolve)
const CallRecord = resolve => require(['../views/call/callRecord'], resolve)
const CallRecordAll = resolve => require(['../views/call/callRecordAll'], resolve)
// 催收函
const createLetter = resolve => require(['../views/letter/create-letter.vue'], resolve)
const exportLetter = resolve => require(['../views/letter/export-letter.vue'], resolve)

Vue.use(Router)

/**
 * icon : the icon show in the sidebar
 * hidden : if hidden:true will not show in the sidebar
 * redirect : if redirect:noredirect will not redirct in the levelbar
 * noDropdown : if noDropdown:true will not has submenu
 * meta : { role: ['admin'] }  will control the page role
 */

export const constantRouterMap = [
  { path: '/', redirect: '/home/index', hidden: true },
  { path: '/login', component: Login, hidden: true },
  { path: '/authredirect', component: authRedirect, hidden: true },
  { path: '/sendpwd', component: sendPWD, hidden: true },
  { path: '/reset', component: reset, hidden: true },
  { path: '/404', component: Err404, hidden: true },
  { path: '/401', component: Err401, hidden: true },
  { path: '/case-detail/:id', component: CaseDetail, hidden: true },
  { path: '/case-detail-image/:orderId', component: CaseDetailImage, hidden: true },
  { name: 'caseDetailBatch', path: '/case-detail-batch/', component: CaseDetailBatch, hidden: true },
  { name: 'caseDetailBench', path: '/case-detail-bench/', component: CaseDetailBench, hidden: true },
  { path: '/home', component: Layout, hidden: true, children: [{ path: 'index', component: Home, name: '首页' }] }
]

export default new Router({
  mode: 'hash',
  // mode: 'history', //后端支持可开
  scrollBehavior: () => ({ y: 0 }),
  base: '/' + packageConfig.name,
  routes: constantRouterMap
})

// 路由菜单树
export const asyncRouterMapTree = [
  {
    path: '/first',
    component: Layout,
    noDropdown: true,
    children: [
      { path: 'remind', component: First, name: '首页', icon: 'iconfont icon-daoru1' }
    ]
  },
  {
    path: '/bench',
    component: Layout,
    noDropdown: true,
    children: [
      { path: 'batch', name: '催收工作台', icon: 'iconfont icon-gongzuotai' }
    ]
  },
  {
    path: '/case',
    component: Layout,
    name: '案件管理',
    icon: 'iconfont icon-anjianguanli',
    children: [
      { path: 'assign-import', component: CaseAssignImport, name: '分案导入', icon: 'iconfont icon-daoru1' },
      { path: 'upper-limit', component: CaseUpperLimit, name: '分案上限', icon: 'iconfont icon-chaxun' },
      { path: 'assignable-config', component: CaseAssignableConfig, name: '可分案配置', icon: 'iconfont icon-canshushezhi' },
      { path: 'unassigned-export', component: CaseUnassignedExport, name: '未分配案件导出', icon: 'iconfont icon-shujudaochu' },
      { path: 'import-case', component: ImportCase, name: '导入案件', icon: 'iconfont icon-daoru' },
      { path: 'assign-case', component: AssignCase, name: '分配案件', icon: 'iconfont icon-fenpeianjian' },
      { path: 'case-query', component: CaseQuery, name: '案件查询', icon: 'iconfont icon-query1' },
      { path: 'history-case-query', component: HistoryCaseQuery, name: '历史结清案件', icon: 'iconfont icon-query1' },
      { path: 'complain', component: CaseComplain, name: '投诉工单', icon: 'iconfont icon-gongdan' }
    ]
  },
  {
    path: '/qcm',
    component: Layout,
    name: '质检管理',
    icon: 'iconfont icon-zhijian',
    children: [
      { path: 'index', component: QualityIndex, name: '人工质检', icon: 'iconfont icon-rengongzhijian' },
      { path: 'detail', component: QualityDetail, name: '质检明细', icon: 'iconfont icon-qcmingxi' },
      { path: 'config', component: QualityConfig, name: '质检配置', icon: 'iconfont icon-peizhi' },
      { path: 'clean', component: QualityClean, name: '质检池清理', icon: 'iconfont icon-qingli' },
      { path: 'job-count', component: QualityJobCount, name: '质检工作统计', icon: 'iconfont icon-tongji' },
      { path: 'summary', component: QualitySummary, name: '质检工作汇总', icon: 'iconfont icon-tongji' },
      { path: 'collector-detail', component: CollectorDetail, name: '催收员质检结果明细', icon: 'iconfont icon-tongji' },
      { path: 'collector-summary', component: CollectorSummary, name: '催收员质检结果汇总', icon: 'iconfont icon-tongji' },
      {
        path: 'collection-group-summary',
        component: CollectionGroupSummary,
        name: '催收组质检结果汇总',
        icon: 'iconfont icon-tongji'
      }
    ]
  },
  {
    path: '/letter',
    component: Layout,
    name: '催收函管理',
    icon: 'iconfont icon-anjianguanli',
    children: [
      { path: 'createLetter', component: createLetter, name: '生成催收函', icon: 'iconfont icon-rengongzhijian' },
      { path: 'exportLetter', component: exportLetter, name: '导出历史', icon: 'iconfont icon-rengongzhijian' }
    ]
  },
  {
    path: '/system',
    component: Layout,
    name: '系统管理',
    icon: 'iconfont icon-xitongguanli',
    children: [
      { path: 'menu', component: SystemMenu, name: '菜单管理', icon: 'iconfont icon-caidanguanli' },
      { path: 'permission', component: SystemPermission, name: '权限管理', icon: 'iconfont icon-quanxianguanli' },
      // {path: 'group', component: SystemGroup, name: '分组管理', icon: 'iconfont icon-fenzu'},
      { path: 'role', component: SystemRole, name: '角色管理', icon: 'iconfont icon-jueseguanli' },
      { path: 'user', component: SystemUser, name: '用户管理', icon: 'iconfont icon-yonghuguanli' },
      { path: 'schedule', component: SystemSchedule, name: '定时任务', icon: 'iconfont icon-dingshirenwu' },
      { path: 'parameter', component: SystemParameter, name: '参数设置', icon: 'iconfont icon-Commonparameter' },
      { path: 'product-settings', component: SystemProductSettings, name: '产品设置', icon: 'iconfont icon-weibiaoti35' },
      { path: 'frequency-restriction', component: FrequencyRestriction, name: '催收频率限制', icon: 'iconfont icon-pinci' },
      { path: 'group', component: SystemGroup, name: '分组管理', icon: 'iconfont icon-Grouping' }
    ]
  },
  {
    path: '/csm',
    component: Layout,
    name: '催收统计',
    icon: 'iconfont icon-tongji',
    children: [
      { path: 'collector-daily', component: CollectorDaily, name: '催收员工作量日报', icon: 'iconfont icon-baobiao' },
      { path: 'collector-monthly', component: CollectorMonthly, name: '催收员工作量月报', icon: 'iconfont icon-baobiao2' },
      { path: 'late-stage-daily', component: LateStageDaily, name: '逾期阶段工作量日报', icon: 'iconfont icon-baobiao1' },
      { path: 'late-stage-monthly', component: LateStageMonthly, name: '逾期阶段工作量月报', icon: 'iconfont icon-msnui-pie-chart' },
      { path: 'data-export', component: DataExport, name: '对公数据导出', icon: 'iconfont icon-shujudaochu' },
      { path: 'assign-case-count', component: AssignCaseCount, name: '分案结果统计', icon: 'iconfont icon-shujudaochu' },
      { path: 'bench-data', component: BenchData, name: '工作台数据', icon: 'iconfont icon-shujudaochu' }
    ]
  },
  {
    path: '/psm',
    component: Layout,
    name: '业绩统计',
    icon: 'iconfont icon-yejitongji',
    children: [
      { path: 'results-summary', component: ResultsSummary, name: '业绩汇总', icon: 'iconfont icon-yejihuizong' },
      { path: 'payment-details', component: PaymentDetails, name: '还款详情', icon: 'iconfont icon-huankuanxiangqing' },
      { path: 'mobility', component: PerformanceMobility, name: '迁移率', icon: 'iconfont icon-qianyilv' }
    ]
  },
  {
    path: '/sms',
    component: Layout,
    name: '短信管理',
    icon: 'iconfont icon-ziyuan',
    children: [
      { path: 'sms-template', component: SmsTemplate, name: '短信模板', icon: 'iconfont icon-moban' },
      { path: 'sms-history', component: SmsHistory, name: '短信历史', icon: 'iconfont icon-lishihistory2' },
      { path: 'sms-audit', component: SmsAudit, name: '短信审核', icon: 'iconfont icon-shenhe' }
    ]
  },
  {
    path: '/call',
    component: Layout,
    name: '批量外呼',
    icon: 'iconfont icon-hujiaozhuanyi',
    children: [
      { path: 'call-project', component: CallProject, name: '项目管理', icon: 'iconfont icon-xiangmuguanli' },
      { path: 'call-record', component: CallRecord, name: '通话记录', icon: 'iconfont icon-tonghuajilu2' },
      { path: 'call-record-all', component: CallRecordAll, name: '全部通话记录', icon: 'iconfont icon-tonghuajilu1' }
    ]
  }
]

// 路由树转换为键值对对象 path为key
function routerTreeListToMapObj (treeList) {
  let mapObj = {}
  treeList.map(item => transObj(item, mapObj))
  return mapObj
}

// 转换对象
function transObj (source, target) {
  if (!source.path) {
    return
  }
  target[source.path] = {}
  if (source.name) {
    target[source.path].name = source.name
  }
  if (source.component) {
    target[source.path].component = source.component
  }
  if (source.icon) {
    target[source.path].icon = source.icon
  }
  if (source.noDropdown) {
    target[source.path].noDropdown = source.noDropdown
  }
  if (source.hidden) {
    target[source.path].hidden = source.hidden
  }
  // 递归处理子菜单
  if (source.children && source.children.length > 0) {
    source.children.map(item => transObj(item, target))
  }
  return target
}

// 输出路由映射对象
export const asyncRouterMapObj = routerTreeListToMapObj(asyncRouterMapTree)

// “*” 匿名路由须放在最后
export const lastRouterConst = [
  { path: '*', redirect: '/home/index', hidden: true }
]
