/**
* 水印
* 2018/04/28
*/

<template>
  <div ref="watermarkBox" id="watermarkBox">
    <canvas id="watermarkRepeat" ref="watermarkRepeat"></canvas>
    <canvas ref="watermark" width="100px" height="100px"></canvas>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'WaterMark',
    props: {
      displayName: {
        type: String,
        default: ''
      },
      userId: {
        type: Number,
        default: 0
      },
      boxWidth: {
        type: Number,
        default: 0
      },
      boxHeight: {
        type: Number,
        default: 0
      }
    },
    watch: {
      'boxWidth' (val) {
        if (val) {
          this.watermark()
        }
      },
      'boxHeight' (val) {
        if (val) {
          this.watermark()
        }
      }
    },
    mounted () {
      this.watermark()
    },
    methods: {
      watermark () {
        let msg = `${this.displayName}${this.userId}` // 要展示的信息
        // 小模板
        let cw = this.$refs.watermark
        let ctx = cw.getContext('2d') // 返回一个用于在画布上绘图的环境
        ctx.clearRect(0, 0, 100, 100) // 绘制之前画布清除
        ctx.font = '14px 黑体'
        ctx.rotate(-40 * Math.PI / 180)
        ctx.fillStyle = 'rgba(100, 100, 100, 0.2)'
        ctx.fillText(msg, -20, 80)
        ctx.rotate(40 * Math.PI / 180) // 坐标系还原

        // 区域
        let crw = this.$refs.watermarkRepeat
        crw.width = this.boxWidth
        crw.height = this.boxHeight
        let ctxr = crw.getContext('2d')
        ctxr.clearRect(0, 0, this.boxWidth, this.boxHeight) // 清除整个画布
        let pat = ctxr.createPattern(cw, 'repeat') // 在指定的方向上重复指定的元素
        ctxr.fillStyle = pat
        ctxr.fillRect(0, 0, this.boxWidth, this.boxHeight)

        // 隐藏小模板
        cw.style.display = 'none'
      }
    }
  }

</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  #watermarkBox {
    position: absolute;
    z-index: 0;
    // top: 0;
    background-color: #fff;
  }
</style>
