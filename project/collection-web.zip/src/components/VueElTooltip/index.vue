/**
* 创建table表头的tooltip
* 增加感叹号的icon - 2017/11/01
*/

<template>
  <el-tooltip :content="content" placement="bottom" effect="light">
    <div><i class="el-icon-info"></i> {{ label }}</div>
  </el-tooltip>
</template>

<script type="text/ecmascript-6">
  export default {
    props: {
      content: {
        type: String,
        default: ''
      },
      label: {
        type: String,
        default: ''
      }
    }
  }

</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  // 增加icon
  .el-table__footer-wrapper thead div, .el-table__header-wrapper thead div {
    display: inline;
  }
</style>
