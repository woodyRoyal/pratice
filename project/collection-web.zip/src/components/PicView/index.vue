/*
* @Author: sunp
* @Date: 2019/1/15 14:13
*/
<template>
  <div class="pic-wrap-all" @mouseenter="showOr" @mouseleave="showOr" v-if="url">
    <div class="pic-box">
      <div class="pic-box-tb">
        <div ref="imgParent" class="positive-pic">
          <img ref="imgObj" :src="url" @click="fullScreen(url)" :onerror="imgError" />
        </div>
      </div>
    </div>
    <div class="operation-wrapper" v-show="show">
      <a class="left-rotate" title="左旋转" href="javascript:" @click="imgRotate('left')"></a>
      <a class="right-rotate" title="右旋转" href="javascript:" @click="imgRotate('right')"></a>
      <a class="full-screen" title="全屏" href="javascript:" @click="fullScreen(url)"></a>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'PicView',
    props: {
      url: { // 图片路径
        required: true
      }
    },
    computed: {
      // 图片路径无效 或 图片无效时触发
      imgError () {
        let src = require('assets/imgerror.png')
        console.log(src)
        console.log(this.url)
        // img 使用 onerror 以后，如果 onerror 指定的图片也是不存在的话，会出现无限死循环 404。 解决办法this.onerror=null
        return `javascript:this.src="${src}";this.onerror=null`
      }
    },
    data () {
      return {
        rotate: 0,
        show: false
      }
    },
    methods: {
      // 单击图片放大
      fullScreen (imgUrl) {
        this.$emit('fullScreen', imgUrl)
      },
      // 显示或隐藏4个操作项
      showOr () {
        this.show = !this.show
      },
      // 图片左右旋转
      imgRotate (direction) {
        let imgObj = this.$refs.imgObj
        let imgParent = this.$refs.imgParent
        let rotate = (direction === 'right') ? this.rotate += 90 : this.rotate -= 90
        this.rotateAnimate(direction, imgObj, imgParent, rotate)
      },
      // 旋转动画
      rotateAnimate (direction, imgObj, imgParent, rotate) {
        let wi = imgParent.offsetWidth
        let he = imgParent.offsetHeight

        if (Math.abs((rotate / 90) % 2) === 1) {
          imgObj.style.maxWidth = he + 'px'
          imgObj.style.maxHeight = wi + 'px'
        } else if (Math.abs((rotate / 90) % 2) === 0) {
          imgObj.style.maxWidth = wi + 'px'
          imgObj.style.maxHeight = he + 'px'
        }
        imgObj.style.webkitTransform = 'rotate(' + (rotate) + 'deg)'
        imgObj.style.Transform = 'rotate(' + (rotate) + 'deg)'
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .pic-wrap-all {
    height: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    /*padding: 10px 0;*/
    /*margin-right: 137px;*/
    overflow: hidden;
    position: relative;
  }

  .pic-box {
    width: 100%;
    height: 100%;
    overflow: hidden;
  }

  .pic-box-tb {
    height: 100%;
    width: 100%;
    text-align: center;
    overflow: hidden;
  }

  .positive-pic {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .positive-pic img {
    max-height: 100%;
    max-width: 100%;
    display: block;
    transition: all 0.8s;
    user-select: none;
  }

  .operation-wrapper {
    height: 36px;
    text-align: center;
    position: absolute;
    left: 0;
    right: 0;
    bottom: 10px;
    font-size: 0;
    line-height: 0;
    z-index: 20;
  }

  .operation-wrapper a {
    width: 36px;
    height: 36px;
    display: inline-block;
    margin-left: 10px;
    background-image: url(../../assets/img/icon.png);
    background-repeat: no-repeat;
  }

  .left-rotate {
    background-position: left -46px;
  }

  .right-rotate {
    background-position: -46px -46px;
  }

  .full-screen {
    background-position: -92px -46px;
  }

  .newPage {
    background-position: -138px -46px;
  }

  .left-rotate:hover {
    background-position: left top;
  }

  .right-rotate:hover {
    background-position: -46px top;
  }

  .full-screen:hover {
    background-position: -92px top;
  }

  .newPage:hover {
    background-position: -138px top;
  }
</style>
