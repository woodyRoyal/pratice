export default {
  toFixed (num, s) {
    let times = Math.pow(10, s)
    let des = num * times + 0.5
    des = parseInt(des, 10) / times
    return des + ''
  }
}
