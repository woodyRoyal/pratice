import Moment from 'moment'

// 日期格式化
export function parseTime (date, pattern) {
  if (!date) {
    return ''
  }
  if (typeof date === 'string') {
    date = new Date(date)
  }
  pattern = pattern || 'YYYY-MM-DD HH:mm:ss'
  return Moment(date).format(pattern)
}

/**
 * 秒转为 天小时分秒 以中文分隔
 * @param sec
 * @return
 */
export function formatSecond (seconds) {
  if (seconds === 0) {
    return '0秒'
  }
  if (!seconds) {
    return '-'
  }
  if (isNaN(seconds)) {
    return '-'
  }
  let sec = parseInt(seconds)
  let timeStr = sec + '秒'
  if (sec > 60) {
    let second = sec % 60
    let min = parseInt(sec / 60)
    timeStr = min + '分' + second + '秒'
    if (min > 60) {
      min = parseInt(sec / 60) % 60
      let hour = parseInt(sec / 3600)
      timeStr = hour + '小时' + min + '分' + second + '秒'
      if (hour > 24) {
        hour = parseInt(sec / 3600) % 24
        let day = parseInt(sec / 3600 / 24)
        timeStr = day + '天' + hour + '小时' + min + '分' + second + '秒'
      }
    }
  }
  return timeStr
}

/**
 * 秒转为 分秒 以冒号分隔
 * @param sec
 * @return
 */
export function formatSecondEn (seconds) {
  return [
    // parseInt(seconds / 60 / 60), // 时
    parseInt(seconds / 60 % 60), // 分
    parseInt(seconds % 60) // 秒
  ]
    .join(':')
    .replace(/\b(\d)\b/g, '0$1')
}

/**
 * 毫秒转为 天小时分秒
 * @param millisecond
 * @return
 */
export function formatMillisecond (millisecond) {
  if (millisecond === 0) {
    return '0秒'
  }
  if (!millisecond) {
    return '-'
  }
  if (isNaN(millisecond)) {
    return '-'
  }
  let sec = parseInt(millisecond / 1000)
  let timeStr = sec + '秒'
  if (sec > 60) {
    let second = sec % 60
    let min = parseInt(sec / 60)
    timeStr = min + '分' + second + '秒'
    if (min > 60) {
      min = parseInt(sec / 60) % 60
      let hour = parseInt(sec / 3600)
      timeStr = hour + '小时' + min + '分' + second + '秒'
      if (hour > 24) {
        hour = parseInt(sec / 3600) % 24
        let day = parseInt(sec / 3600 / 24)
        timeStr = day + '天' + hour + '小时' + min + '分' + second + '秒'
      }
    }
  }
  return timeStr
}

/**
 * 毫秒转为 天小时分秒
 * @param millisecond
 * @return
 */
export function formatMillisecondTo (millisecond) {
  if (millisecond === 0) {
    return '00:00:00'
  }
  if (!millisecond) {
    return '-'
  }
  if (isNaN(millisecond)) {
    return '-'
  }
  let hour = parseInt(millisecond / 1000 / 60 / 60)
  let minute = parseInt(millisecond / 1000 / 60 % 60)
  let second = parseInt(millisecond / 1000 % 60)
  if (hour < 10) {
    hour = '0' + hour
  }
  if (minute < 10) {
    minute = '0' + minute
  }
  if (second < 10) {
    second = '0' + second
  }
  return hour + ':' + minute + ':' + second
}

export function formatTime (time, option) {
  time = +time * 1000
  const d = new Date(time)
  const now = Date.now()

  const diff = (now - d) / 1000

  if (diff < 30) {
    return '刚刚'
  } else if (diff < 3600) { // less 1 hour
    return Math.ceil(diff / 60) + '分钟前'
  } else if (diff < 3600 * 24) {
    return Math.ceil(diff / 3600) + '小时前'
  } else if (diff < 3600 * 24 * 2) {
    return '1天前'
  }
  if (option) {
    return parseTime(time, option)
  } else {
    return d.getMonth() + 1 + '月' + d.getDate() + '日' + d.getHours() + '时' + d.getMinutes() + '分'
  }
}

/**
 * 获取一个月前的日期
 * @param millisecond
 * @return
 */
export function getMonthBefore (date, pattern) {
  pattern = pattern || 'YYYY-MM-DD HH:mm:ss'
  if (!date) {
    return Moment().subtract(1, 'months').format(pattern)
  } else {
    return Moment(date).subtract(1, 'months').format(pattern)
  }
}

/**
 * '2017-9-14'转换为周几
 * @param value
 * @return
 */
export function getWeekNo (value) {
  let arys1 = value.split('-') // 日期为输入日期，格式为 2013-3-10
  let ssdate = new Date(arys1[0], parseInt(arys1[1] - 1), arys1[2])
  let weekNo = ssdate.getDay()
  return weekNo
}
