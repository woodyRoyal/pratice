import Moment from 'moment'
export function computeTimeScope (day, time) {
  if (!/^[0-9]+$/.test(day) || !time) { return '' }
  // 获取今天的起始日期
  let nowStart = Moment(time).format('YYYY-MM-DD') + ' 00:00'
  let now = time
  // 获取 day - 1 之前的日期
  let start = Moment(time).subtract(day - 1, 'days').format('YYYY-MM-DD') + ' 00:00';
  if (day < 2) {
    return nowStart + "~" + now
  } else {
    return start + "~" + now
  }
}
// 计算 差几分钟
export function calculateDiffTime (selectTime) {
  let now = new Date().getTime()
  let timeDiff = selectTime - now
  let minute = timeDiff / 1000 / 60
  minute = minute || ''
  return minute
}

// 转换url参数 
function queryParams (data) {
  var _result = [];
  for (var key in data) {
    var value = data[key];
    if (value.constructor === Array) {
      value.forEach(function (_value) {
        _result.push(key + "=" + _value);
      });
    } else {
      _result.push(key + '=' + value);
    }
  }
  return _result.join('&');
}
// 下载文件
export function downLoad (URL, data) {
  let params = ''
  if (data) {
    params = '?' + queryParams(data)
  }
  window.location.href = URL + params
}

export function GetPercent (num, total) {
  /// <summary>
  /// 求百分比
  /// </summary>
  /// <param name="num">当前数</param>
  /// <param name="total">总数</param>
  num = parseFloat(num)
  total = parseFloat(total)
  if (isNaN(num) || isNaN(total)) {
    return '-'
  }
  return total <= 0 ? '0%' : (Math.round(num / total * 10000) / 100.00) + '%'
}
// 处理精度的乘法  
export function accMul (arg1, arg2, fix) {
  if (!parseInt(fix) === fix) {
    return;
  }
  let argStart = arg1 === null ? 0 : arg1
  let argEnd = arg2 === null ? 0 : arg2
  var m = 0, s1 = argStart.toString(), s2 = argEnd.toString();
  try { m += s1.split(".")[1].length } catch (e) { }
  try { m += s2.split(".")[1].length } catch (e) { }
  if (m > fix) {
    return (Math.round(Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m - fix)) / Math.pow(10, fix));
  } else if (m <= fix) {
    return (Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m)).toFixed(fix);
  } else {
    return (argStart * argEnd).toFixed(fix);
  }
}

// 处理精度的除法  
export function accDiv (arg1, arg2, fix) {
  let argStart = arg1 === null ? 0 : arg1
  let argEnd = arg2 === null ? 0 : arg2
  if (!argEnd) return "0.00"
  let t1 = 0, t2 = 0, r1, r2;
  try { t1 = argStart.toString().split(".")[1].length } catch (e) { }
  try { t2 = argEnd.toString().split(".")[1].length } catch (e) { }
  r1 = Number(argStart.toString().replace(".", ""))
  r2 = Number(argEnd.toString().replace(".", ""))
  let temp = (r1 / r2) * Math.pow(10, t2 - t1);
  return temp.toFixed(fix)
}