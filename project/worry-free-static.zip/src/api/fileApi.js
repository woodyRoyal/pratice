import fetch from 'utils/fetchJson'
export default {
  // 文件上传 接口地址
  uploadApi: process.env.BASE_API + '/upload/fileImportService/decryptFile',
  // 查询已加密文件
  queryDecryptedFile (data) {
    return fetch({
      url: '/restfulservice/encryptedDataService/queryDecryptedFile',
      method: 'post',
      data
    })
  },
  downLoadApi: process.env.BASE_API + '/download/encryptedDataService/downloadDecryptedFile',
  // 校验密码是否有效功能
  expirePwdApi (data) {
    return fetch({
      url: '/decrypt/expire/pwd',
      method: 'post',
      data
    })
  },
  // 校验密码功能
  checkPwdApi (data) {
    return fetch({
      url: '/decrypt/check/pwd',
      method: 'post',
      data
    })
  },
  // 修改密码功能
  modifyPwdApi (data) {
    return fetch({
      url: '/decrypt/modify/pwd',
      method: 'post',
      data
    })
  }
}
