import fetchJson from 'utils/fetchJson'

export default {
  getAll (data) {
    return fetchJson({
      url: 'diversion/switch/getAll',
      method: 'post',
      data
    })
  },
  getDiversionSwitchById (data) {
    return fetchJson({
      url: 'diversion/switch/getDiversionSwitchById',
      method: 'post',
      data
    })
  },
  saveOrUpdateDiversionSwitch (data) {
    return fetchJson({
      url: `/diversion/switch/saveOrUpdateDiversionSwitch`,
      method: 'post',
      data
    })
  },
  deleteDiversionSwitchById (data) {
    return fetchJson({
      url: `diversion/switch/deleteDiversionSwitchById?id=${data}`,
      method: 'post'
    })
  }
}

// [{key: 1}, {key: 2}, {key: 3, del: true}]

// [{key: 1}, {key: 2}]

// [1, 2, 3]
