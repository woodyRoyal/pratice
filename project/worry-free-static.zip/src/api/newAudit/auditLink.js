import fetchJson from 'utils/fetchJson'
export default {
  // 获取过审产品信息列表/详情
  getProductInfo (productId, id) {
    return fetchJson({
      url: `diversion/link/getLinkByProductId?productId=${productId}&id=${id}`,
      method: 'post'
    })
  },
  // 列表
  getAll (data) {
    return fetchJson({
      url: 'diversion/link/getAll',
      method: 'post',
      data
    })
  },
  // 列表
  delete (data) {
    return fetchJson({
      url: `diversion/link/delete?id=${data}`,
      method: 'post'
    })
  },
  // 列表
  saveOrUpdate (data) {
    return fetchJson({
      url: 'diversion/link/saveOrUpdate',
      method: 'post',
      data
    })
  },
  // 列表
  getLinkById (data) {
    return fetchJson({
      url: `diversion/link/getLinkById?id=${data}`,
      method: 'post'
    })
  }
}
