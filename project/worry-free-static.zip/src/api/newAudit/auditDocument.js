import fetchJson from 'utils/fetchJson'

export default {
  delete (data) {
    return fetchJson({
      url: `diversion/copyWriting/delete?id=${data}`,
      method: 'post'
    })
  },
  saveOrUpdate (data) {
    return fetchJson({
      url: 'diversion/copyWriting/saveOrUpdate',
      method: 'post',
      data
    })
  },
  getCopyWritingAll (data) {
    return fetchJson({
      url: 'diversion/copyWriting/getCopyWritingAll',
      method: 'post',
      data
    })
  }
}
