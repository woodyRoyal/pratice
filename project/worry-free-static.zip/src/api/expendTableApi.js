import fetchJson from 'utils/fetchJson'
// 支出报表
export default {
  // 日表表数据查询
  dayList (data) {
    return fetchJson({
      url: '/reprot/list/search/daily',
      method: 'post',
      data
    })
  },
  // 日表表数据查询
  monthList (data) {
    return fetchJson({
      url: '/reprot/list/search/month',
      method: 'post',
      data
    })
  },
  // 获取渠道推广明细（按小时）列表
  detailHour (data) {
    return fetchJson({
      url: '/promotion/detail/list/search/hour',
      method: 'post',
      data
    })
  },
  // 渠道类型
  type (data) {
    return fetchJson({
      url: '/channel/type/findAll',
      method: 'post',
      data
    })
  },
  // 渠道服务商
  facilitator (data) {
    return fetchJson({
      url: '/channel/facilitator/findAll',
      method: 'post',
      data
    })
  },
  // 渠道负责人
  principal (data) {
    return fetchJson({
      url: '/channel/principal/findAll',
      method: 'post',
      data
    })
  },
  // hvoer弹窗数据
  hover (name) {
    return fetchJson({
      url: `/channel/queryChannelByName?name=${name}`,
      method: 'post'
    })
  },
  dayStartDown (data) {
    return fetchJson({
      url: `/reprot/daily/export`,
      method: 'post',
      data
    })
  },
  monthStartDown (data) {
    return fetchJson({
      url: `/reprot/month/export`,
      method: 'post',
      data
    })
  }
}
