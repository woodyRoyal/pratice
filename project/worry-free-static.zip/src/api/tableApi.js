import fetchJson from 'utils/fetchJson'

export default {
  // 渠道日报表list
  reprotDaily (data) {
    return fetchJson({
      url: '/reprot/list/search/daily',
      method: 'post',
      data
    })
  },
  exportDaily (data) {
    return fetchJson({
      url: '/reprot/daily/export',
      method: 'post',
      data
    })
  },
  // 渠道月报表list
  reprotMonth (data) {
    return fetchJson({
      url: '/reprot/list/search/month',
      method: 'post',
      data
    })
  },
  exportMonth (data) {
    return fetchJson({
      url: '/reprot/month/export',
      method: 'post',
      data
    })
  },
  lock (data) {
    return fetchJson({
      url: '/reprot/month/lock',
      method: 'post',
      data
    })
  },
  update (data) {
    return fetchJson({
      url: '/reprot/month/update',
      method: 'post',
      data
    })
  }
}
