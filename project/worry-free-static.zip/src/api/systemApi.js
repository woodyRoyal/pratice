import fetchJson from 'utils/fetchJson'

export default {
  // 全量用户查询
  allUser () {
    return fetchJson({
      url: '/mc/intserv/manage/allUser',
      method: 'get'
    })
  },
  // 分页用户查询
  findUserByPage (data) {
    return fetchJson({
      url: '/intserv/manage/findUserByPage',
      method: 'post',
      data
    })
  },
  // 推广端 新增用户
  addUser (data) {
    return fetchJson({
      url: '/intserv/manage/addUser',
      method: 'post',
      data
    })
  },
  // 推广端 新增用户
  deleteUser (id) {
    return fetchJson({
      url: `/intserv/manage/deleteUser?userId=${id}`,
      method: 'post'
    })
  },
  // 全量查询角色列表
  roleList (data) {
    return fetchJson({
      url: '/intserv/manage/allPost',
      method: 'get',
      data
    })
  },
  // 推广端 分配角色
  associatedUserPost (data) {
    return fetchJson({
      url: '/intserv/manage/associatedUserPost',
      method: 'post',
      data
    })
  },

  // 角色分页查询
  rolePage (data) {
    return fetchJson({
      url: '/intserv/manage/findPostByPage',
      method: 'post',
      data
    })
  },
  // 删除
  delRole (data) {
    return fetchJson({
      url: '/intserv/manage/deletePost',
      method: 'post',
      data
    })
  },
  // 新增角色
  addRole (data) {
    return fetchJson({
      url: '/intserv/manage/addPost',
      method: 'post',
      data
    })
  },
  // 编辑角色
  editRole (data) {
    return fetchJson({
      url: '/intserv/manage/updatePost',
      method: 'post',
      data
    })
  },
  // 全量查询权限树
  allResourceTree () {
    return fetchJson({
      url: '/intserv/manage/allResourceTree',
      method: 'get'
    })
  },
  // 新增权限
  addResource (data) {
    return fetchJson({
      url: '/intserv/manage/addResource',
      method: 'post',
      data
    })
  },
  // 编辑权限
  updateResource (data) {
    return fetchJson({
      url: '/intserv/manage/updateResource',
      method: 'post',
      data
    })
  },
  // 删除权限
  deleteResource (data) {
    return fetchJson({
      url: '/intserv/manage/deleteResource',
      method: 'post',
      data
    })
  }
}
