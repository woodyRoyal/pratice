import fetchJson from 'utils/fetchJson'

export default {
  // 获取渠道推广明细（按天）列表
  detailDaily (data) {
    return fetchJson({
      url: '/promotion/detail/list/search/daily',
      method: 'post',
      data
    })
  },
  // 获取渠道推广明细（按小时）列表
  detailHour (data) {
    return fetchJson({
      url: '/promotion/detail/list/search/hour',
      method: 'post',
      data
    })
  },
  // 渠道类型
  type (data) {
    return fetchJson({
      url: '/channel/type/findAll',
      method: 'post',
      data
    })
  },
  // 渠道服务商
  facilitator (data) {
    return fetchJson({
      url: '/channel/facilitator/findAll',
      method: 'post',
      data
    })
  },
  // 渠道负责人
  principal (data) {
    return fetchJson({
      url: '/channel/principal/findAll',
      method: 'post',
      data
    })
  },
  // hvoer弹窗数据
  hover (name) {
    return fetchJson({
      url: `/channel/queryChannelByName?name=${name}`,
      method: 'post'
    })
  },
  // 点击下载按钮
  startDown (data) {
    return fetchJson({
      url: `/promotion/detail/downloadDetailListHour?channelName=${data.channelName}&hour=${data.hour}` +
      `&facilitatorId=${data.facilitatorId}&principalId=${data.principalId}` + `&platform=${data.platform}` +
      `&typeId=${data.typeId === 0 ? '' : data.typeId}&pageNum=${data.pageNum}&pageSize=${data.pageSize}&queryType=${data.queryType}&countDateHour=${data.countDateHour}`,
      method: 'get'
    })
  },
  dayStartDown (data) {
    return fetchJson({
      url: `/promotion/detail/downloadDetailData?channelName=${data.channelName}&countDateStart=${data.countDateStart}` +
      `&facilitatorId=${data.facilitatorId}&principalId=${data.principalId}` + `&platform=${data.platform}` +
      `&typeId=${data.typeId === 0 ? '' : data.typeId}&pageNum=${data.pageNum}&pageSize=${data.pageSize}&queryType=${data.queryType}&countDateEnd=${data.countDateEnd}`,
      method: 'get'
    })
  }
}
