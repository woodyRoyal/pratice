import fetch from 'utils/fetch'
import fetchJson from 'utils/fetchJson'
import fethchFile from 'utils/fethchFile'

export default {
  commonTaglist (data) {
    return fetchJson({
      url: '/product/commonTag/list',
      method: 'post',
      data
    })
  },
  commonTagSaveOrUpdate (data) {
    return fetchJson({
      url: 'product/commonTag/saveOrUpdate',
      method: 'post',
      data
    })
  },
  commonTagUpdateStatus (data) {
    return fetchJson({
      url: 'product/commonTag/updateStatus',
      method: 'post',
      data
    })
  },
  commonTagActiveList (data) {
    return fetchJson({
      url: '/product/commonTag/activeList',
      method: 'post',
      data
    })
  },
  /* 产品管理 */
  // 请求表格数据
  fetchTableData (data) {
    return fetchJson({
      url: '/product/getProductList',
      method: 'post',
      data
    })
  },
  // 新增产品
  fetchAddProduct (data) {
    return fetchJson({
      url: '/product/insertOrEdit',
      method: 'post',
      data
    })
  },
  // 编辑产品
  fetchEditProduct (data) {
    return fetchJson({
      url: '/product/insertOrEdit',
      method: 'post',
      data
    })
  },
  // 编辑用户定向
  fetchEditUserDirect (data) {
    return fetchJson({
      url: '/product/editUserDirect',
      method: 'post',
      data
    })
  },
  // 编辑广告图片 editMaterial
  fetchEditAdPic (data) {
    return fetchJson({
      url: '/product/editMaterial',
      method: 'post',
      data
    })
  },
  // 停用启用接口
  fetchEnableOrDisable (data) {
    return fetch({
      url: '/product/enableOrDisable',
      method: 'post',
      data
    })
  },
  // 是否可以停用
  fetchIsEnableOrDisable (data) {
    return fetch({
      url: '/product/checkDisable',
      method: 'post',
      data
    })
  },
  // 检测是否重名
  fetchIsRepeatName (data) {
    return fetch({
      url: '/product/duplicationName',
      method: 'post',
      data
    })
  },
  'URL_UPLOAD': process.env.BASE_API + '/upload/uploadImgFile',
  disableCheck (data) {
    return fetchJson({
      url: `/product/disableCheck?productId=${data.productId}`,
      method: 'post'
    })
  },
  isDisable (data) {
    return fetchJson({
      url: `/product/disableOptimization?isDisable=${data}`,
      method: 'post'
    })
  },
  searchLinks (data) {
    return fetchJson({
      url: `/product/searchLinks?productId=${data}`,
      method: 'post'
    })
  },
  // 链接启用停用
  LinkEnableDisable (data) {
    return fetchJson({
      url: `product/LinkEnableDisable?id=${data.id}&status=${data.status}`,
      method: 'post'
    })
  },
  // 添加、编辑链接
  addOrEditLink (data) {
    return fetchJson({
      url: `product/addOrEditLink`,
      method: 'post',
      data
    })
  },
  // 添加、编辑链接
  resetLink (data) {
    return fetchJson({
      url: `product/adLock/links/reset`,
      method: 'post',
      data
    })
  },
  // ARPU上传
  productArpuImport (data) {
    return fethchFile({
      url: `product/productArpuImport`,
      method: 'post',
      data
    })
  },
  // 产品链接导入
  productUvClickLimitImport (data) {
    return fethchFile({
      url: `product/productUvClickLimitImport`,
      method: 'post',
      data
    })
  },
  // 判断产品是否对接联合登陆
  isJointLoginProduct (data) {
    return fethchFile({
      url: `product/isJointLoginProduct?productId=${data}`,
      method: 'get'
    })
  },
  // 判断产品是否对接联合登陆
  isApiProduct (data) {
    return fethchFile({
      url: `product/isApiProduct?productId=${data}`,
      method: 'get'
    })
  },
  // 保存api产品预筛规则
  productLimitSave (data) {
    return fetchJson({
      url: `/product/api/productLimit/save`,
      method: 'post',
      data
    })
  },
  // 保存api产品预筛规则
  productLimitUpdate (data) {
    return fetchJson({
      url: `/product/api/productLimit/selectByProductId`,
      method: 'post',
      data
    })
  },
  // 保存api产品预筛规则
  selectByProductId (data) {
    return fetchJson({
      url: `/product/api/productLimit/selectByProductId`,
      method: 'post',
      data
    })
  },
  json () {
    return {
      body: {
        canAutoDrop: true, // 是否能停用
        // 上架情况
        infoList: [],
        // 一下位置需要手动下架该产品
        failList: [],
        // 以下位置已完成下架
        successList: [],
        respCode: '1000',
        respMsg: ''
      }
    }
  }

}
