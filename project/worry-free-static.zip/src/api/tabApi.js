import fetchJson from 'utils/fetchJson'

export default {
  // 渠道媒体查询
  media (data) {
    return fetchJson({
      url: '/channel/media/findAll',
      method: 'post',
      data
    })
  },
  // 渠道服务商
  facilitator (data) {
    return fetchJson({
      url: 'channel/facilitator/findAll',
      method: 'post',
      data
    })
  },
  // 渠道类型
  type (data) {
    return fetchJson({
      url: 'channel/type/findAll',
      method: 'post',
      data
    })
  },
  // 渠道负责人
  principal (data) {
    return fetchJson({
      url: 'channel/principal/findAll',
      method: 'post',
      data
    })
  }
}
