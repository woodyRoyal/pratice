import fetch from 'utils/fetch'

/* ----------菜单管理---------- */

// 获取菜单树
export function fetchMenuTree () {
  return fetch({
    url: 'rbacMenu/findRbacMenuTree',
    method: 'get'
  })
}

// 新增或修改菜单
export function fetchSaveOrUpdateMenu (rbacMenu) {
  const data = rbacMenu
  return fetch({
    url: 'rbacMenu/saveOrUpdate',
    method: 'post',
    data
  })
}

// 批量删除菜单
export function fetchDeleteMenuByIdList (idList) {
  const data = {
    idList
  }
  return fetch({
    url: 'rbacMenu/deleteByIdList',
    method: 'post',
    data
  })
}

/* ----------用户管理---------- */

// 获取用户列表
export function fetchUserList (username, displayName, pageNum, pageSize) {
  return fetch({
    url: 'rbacUser/findrbacUserServiceTree',
    method: 'get',
    params: {username, displayName, pageNum, pageSize}
  })
}

// 获取用户名是否已存在 true存在 false不存在
export function fetchUsernameIsExists (username) {
  return fetch({
    url: 'rbacUser/findByUserId',
    method: 'get',
    params: {username}
  })
}

// 新增或修改用户
export function fetchSaveOrUpdateUser (rbacUser) {
  const data = rbacUser
  return fetch({
    url: 'rbacUser/saveOrUpdate',
    method: 'post',
    data
  })
}

// 重置密码
export function fetchResetPassword (id) {
  const data = {
    id
  }
  return fetch({
    url: 'rbacUser/resetPassword',
    method: 'post',
    data
  })
}

// 禁用
export function fetchDisableUser (id) {
  const data = {
    id
  }
  return fetch({
    url: 'rbacUser/disable',
    method: 'post',
    data
  })
}

// 启用
export function fetchEnableUser (id) {
  const data = {
    id
  }
  return fetch({
    url: 'rbacUser/enable',
    method: 'post',
    data
  })
}

// 锁定
export function fetchLockUser (id) {
  const data = {
    id
  }
  return fetch({
    url: 'rbacUser/lock',
    method: 'post',
    data
  })
}

// 解锁
export function fetchUnlockUser (id) {
  const data = {
    id
  }
  return fetch({
    url: 'rbacUser/unLock',
    method: 'post',
    data
  })
}

// 修改密码
export function fetchUpdatePassword (oldPassword, newPassword) {
  const data = {
    oldPassword, newPassword
  }
  return fetch({
    url: 'rbacUser/updatePassword',
    method: 'post',
    data
  })
}

/* ----------分组管理---------- */

// 获取分组树
export function fetchGroupTree () {
  return fetch({
    url: 'rbacGroup/findRbacGroupTree',
    method: 'get'
  })
}

// 获取分组列表
export function fetchGroupList (code, name, pageable) {
  return fetch({
    url: 'rbacGroup/findRbacGroup',
    method: 'get',
    params: {code, name, pageable}
  })
}

// 新增或修改分组
export function fetchSaveOrUpdateGroup (data) {
  return fetch({
    url: 'rbacGroup/saveOrUpdate',
    method: 'post',
    data
  })
}

// 批量删除分组
export function fetchDeleteGroupByIdList (idList) {
  const data = {
    idList
  }
  return fetch({
    url: 'rbacGroup/deleteByIdList',
    method: 'post',
    data
  })
}

/* ----------角色管理---------- */

// 获取角色列表
export function fetchRoleList (rolename, pageNum, pageSize) {
  return fetch({
    url: 'rbacRole/findRbacRoleTree',
    method: 'get',
    params: {rolename, pageNum, pageSize}
  })
}

// 新增或修改角色
export function fetchSaveOrUpdateRole (rbacRole) {
  const data = rbacRole
  return fetch({
    url: 'rbacRole/saveOrUpdate',
    method: 'post',
    data
  })
}

// 批量删除角色
export function fetchDeleteRoleByIdList (idList) {
  const data = {
    idList
  }
  return fetch({
    url: 'rbacRole/deleteByIdList',
    method: 'post',
    data
  })
}

/* ----------权限管理---------- */

// 获取权限树
export function fetchPermissionTree () {
  return fetch({
    url: 'rbacPermission/findRbacPermissionTreeTree',
    method: 'get'
  })
}

// 获取权限列表
export function fetchPermissionList (name, pageable) {
  return fetch({
    url: 'rbacPermission/findRbacPermissionTree',
    method: 'get',
    params: {name, pageable}
  })
}

// 新增或修改权限
export function fetchSaveOrUpdatePermission (rbacPermission) {
  const data = rbacPermission
  return fetch({
    url: 'rbacPermission/saveOrUpdate',
    method: 'post',
    data
  })
}

// 批量删除权限
export function fetchDeletePermissionByIdList (idList) {
  const data = {
    idList
  }
  return fetch({
    url: 'rbacPermission/deleteByIdList',
    method: 'post',
    data
  })
}

/* ----------定时任务---------- */

// 获取所有任务列表/batch/getAllTask
export function fetchScheduleList () {
  return fetch({
    url: 'batch/getAllTask',
    method: 'get'
  })
}

// 新增或修改任务
export function fetchSaveOrUpdateSchedule (data) {
  return fetch({
    url: 'batch/saveTask',
    method: 'post',
    data
  })
}

// 删除任务
export function fetchDeleteScheduleById (taskId) {
  const data = {
    taskId
  }
  return fetch({
    url: 'batch/deleteTask',
    method: 'post',
    data
  })
}

// 暂停任务
export function fetchPauseScheduleById (taskId) {
  const data = {
    taskId
  }
  return fetch({
    url: 'restfulservice/scheduleTaskService/pauseTask',
    method: 'post',
    data
  })
}

// 重启任务
export function fetchResumeScheduleById (taskId) {
  const data = {
    taskId
  }
  return fetch({
    url: 'restfulservice/scheduleTaskService/resumeTask',
    method: 'post',
    data
  })
}

// 执行一次任务
export function fetchRunOnceScheduleById (taskId) {
  const data = {
    taskId
  }
  return fetch({
    url: 'restfulservice/scheduleTaskService/runOnceTask',
    method: 'post',
    data
  })
}

// 启动任务
export function fetchStartScheduleById (taskId) {
  const data = {
    taskId
  }
  return fetch({
    url: 'restfulservice/scheduleTaskService/startTask',
    method: 'post',
    data
  })
}

// 停止任务
export function fetchStopScheduleById (taskId) {
  const data = {
    taskId
  }
  return fetch({
    url: 'restfulservice/scheduleTaskService/stopTask',
    method: 'post',
    data
  })
}

/* ----------参数设置---------- */
/* 参数分类 */

// 获取参数分类列表
export function fetchParamClassList (classCode, className, pageNum, pageSize) {
  return fetch({
    url: 'param/findParamClass',
    method: 'get',
    params: {classCode, className, pageNum, pageSize}
  })
}

// 获取所有参数分类
export function fetchAllParamClass () {
  return fetch({
    url: '/param/findAllParamClass',
    method: 'get'
  })
}

// 删除参数分类
export function fetchDeleteParamClassById (ids) {
  const data = {
    ids
  }
  return fetch({
    url: 'param/deleteByIdsClass',
    method: 'post',
    data
  })
}

// 新增或修改参数分类
export function fetchSaveOrUpdateParamClass (paramClass) {
  const data = paramClass
  return fetch({
    url: 'param/saveOrUpdateClass',
    method: 'post',
    data
  })
}

/* 参数 */

// 获取参数列表
export function fetchParamList (classIdList, pageNum, pageSize) {
  return fetch({
    url: 'param/findParamParam',
    method: 'get',
    params: {classIdList, pageNum, pageSize}
  })
}

// 删除参数
export function fetchDeleteParamById (id) {
  const data = {
    id
  }
  return fetch({
    url: 'param/deleteById',
    method: 'post',
    data
  })
}

// 新增或修改参数
export function fetchSaveOrUpdateParam (paramParam) {
  const data = paramParam
  return fetch({
    url: 'param/saveOrUpdateParam',
    method: 'post',
    data
  })
}
