import fetchJson from 'utils/fetchJson'
// let base = 'http://rap.2345intra.com/mockjs/444/'
let base = ''
export default {
  sendRecordList (data) {
    return fetchJson({
      url: base + 'auto/sms/sendRecord/query',
      method: 'post',
      data
    })
  }
}
