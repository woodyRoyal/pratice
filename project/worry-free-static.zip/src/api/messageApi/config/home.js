import fetchJson from 'utils/fetchJson'
import fetch from 'utils/fetch'
// let base = 'http://rap.2345intra.com/mockjs/444/'
let base = ''
export default {
  // 自动短信配置列表页/详情页
  configList (data) {
    return fetchJson({
      url: base + 'auto/sms/config/info',
      method: 'post',
      data
    })
  },
  operateRecord (data) {
    return fetch({
      url: base + `auto/sms/config/operateRecord`,
      method: 'post',
      data
    })
  },
  // 自动短信配置列表页/详情页
  update (data) {
    return fetchJson({
      url: base + 'auto/sms/config/update',
      method: 'post',
      data
    })
  },
  // 删除短信配置
  delete (data) {
    return fetchJson({
      url: base + 'auto/sms/config/delete',
      method: 'post',
      data
    })
  },
  // 检查可选择运营商
  ispCheck (data) {
    return fetchJson({
      url: base + 'auto/sms/config/check',
      method: 'post',
      data
    })
  },
  // 添加和修改短信配置
  saveOrUpdate (data) {
    return fetchJson({
      url: base + 'auto/sms/config/saveOrUpdate',
      method: 'post',
      data
    })
  }
}
