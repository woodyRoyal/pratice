import fetchJson from 'utils/fetchJson'
// let base = 'http://rap.2345intra.com/mockjs/444/'
let base = ''
export default {
  dataReport (data) {
    return fetchJson({
      url: base + 'auto/sms/dataReport/query',
      method: 'post',
      data
    })
  }
}
