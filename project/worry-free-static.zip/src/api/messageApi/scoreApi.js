import fetchJson from 'utils/fetchJson'
// import fetch from 'utils/fetch'
export default {
  innerSearch (data) {
    return fetchJson({
      url: 'sms/service/mobile/innerSearch',
      method: 'post',
      data
    })
  },
  select (data) {
    return fetchJson({
      url: 'score/service/select',
      method: 'post',
      data
    })
  },
  doQuery (data) {
    return fetchJson({
      url: '/score/service/doQuery',
      method: 'post',
      data
    })
  },
  doDelete (data) {
    return fetchJson({
      url: '/score/service/doDelete',
      method: 'post',
      data
    })
  },
  getList (data) {
    return fetchJson({
      url: `/score/service/getList`,
      method: 'post',
      data
    })
  }
}
