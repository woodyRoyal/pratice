import fetchJson from 'utils/fetchJson'
import fetch from 'utils/fetch'
export default {
  innerSearch (data) {
    return fetchJson({
      url: 'sms/service/mobile/innerSearch',
      method: 'post',
      data
    })
  },
  create (params) {
    return fetch({
      url: `/sms/service/postTask/create`,
      method: 'get',
      params
    })
  },
  getTaskNoList (data) {
    return fetchJson({
      url: `/sms/service/getTaskNoList`,
      method: 'post',
      data
    })
  }
}
