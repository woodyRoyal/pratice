import fetchJson from 'utils/fetchJson'
// import fetch from 'utils/fetch'
export default {
  getList (data) {
    return fetchJson({
      url: '/score/service/report/getList',
      method: 'post',
      data
    })
  }
}
