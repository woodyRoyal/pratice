import fetchJson from 'utils/fetchJson'
import fetchFile from 'utils/fethchFile'
export default {
  // 分页查询广告主列表advertiser/batchUpdateBusinessPrincipal
  getList (data) {
    return fetchJson({
      url: 'sms/service/unsubscribe/page',
      method: 'post',
      data
    })
  },
  import (data, id) {
    return fetchFile({
      url: `sms/service/unsubscribe/import?userId=${id}`,
      method: 'post',
      data
    })
  },
  down (params) {
    return fetchJson({
      url: `sms/service/unsubscribe/export`,
      method: 'get',
      params
    })
  }
}
