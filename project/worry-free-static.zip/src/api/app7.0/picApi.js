import fetchJson from 'utils/fetchJson'
// import fethchFile from 'utils/fethchFile'
export default {
   //新增的图片管理模块接口
  // 新增保存图片
  saveOrUpdate (data) {
    return fetchJson({
      url: `/defaultImgInfo/saveOrUpdate`,
      method: 'post',
      data,
    })
  },
  // 查询默认图片详情信息
  detail (data) {
    return fetchJson({
      url: `/defaultImgInfo/detail`,
      method: 'post',
      data,
    })
  },
  // 查询默认图片详情信息
  list (data) {
    return fetchJson({
      url: `/defaultImgInfo/list`,
      method: 'post',
      data,
    })
  },
  // 保存排序
  saveSeqAndStatus (data) {
    return fetchJson({
      url: `/defaultImgInfo/saveSeqAndStatus`,
      method: 'post',
      data,
    })
  },
}
