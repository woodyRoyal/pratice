import fetchJson from 'utils/fetchJson'
// import fethchFile from 'utils/fethchFile'
export default {
  // 批量更新
  batchUpdateStatus (data) {
    return fetchJson({
      url: 'hardAdvertisement/batchUpdateStatus',
      method: 'post',
      data,
    })
  },
  // 更新硬广位启用状态
  updateStatus (data) {
    return fetchJson({
      url: 'hardAdvertisement/updateStatus',
      method: 'post',
      data,
    })
  },
  updateLinkAndAdvertisementStatus (data) {
    return fetchJson({
      url: 'hardAdvertisement/updateLinkAndAdvertisementStatus',
      method: 'post',
      data,
    })
  },
  updateSeqAndStatus (data) {
    return fetchJson({
      url: 'hardAdvertisement/updateSeqAndStatus',
      method: 'post',
      data,
    })
  },
  // 开屏广告
  list (data) {
    return fetchJson({
      url: 'hardAdvertisement/list',
      method: 'post',
      data,
    })
  },
  // 获取所有链接
  getAllValidLinks (data) {
    return fetchJson({
      url: '/advertsLink/getAllValidLinks',
      method: 'post',
      data,
    })
  },
  // 添加编辑
  saveOrUpdateAD (data) {
    return fetchJson({
      url: '/hardAdvertisement/saveOrUpdate',
      method: 'post',
      data,
    })
  },
  // 根据linkID查链接信息
  getAdvertsLinkById (data) {
    return fetchJson({
      url: `/advertsLink/getAdvertsLinkById?id=${data}`,
      method: 'post',
    })
  },
}
