import fetch from 'utils/fetch'
import fetchJson from 'utils/fetchJson'
import fetchFile from '../utils/fethchFile'

export default {
  // 批量更新
  batchUpdateSeqAndStatus (data) {
    return fetchJson({
      url: '/customizedBanner/batchUpdateSeqAndStatus',
      method: 'post',
      data
    })
  },
  // 停用转启用时要先调这个接口
  bannerUpdateStatus (data) {
    return fetchJson({
      url: '/customizedBanner/updateStatus',
      method: 'post',
      data
    })
  },
  // 再调用这个接口
  updateLinkAndBannerStatus (data) {
    return fetchJson({
      url: '/customizedBanner/updateLinkAndBannerStatus',
      method: 'post',
      data
    })
  },
  // 添加编辑自定义banner
  saveOrUpdateBanner (data) {
    return fetchJson({
      url: '/customizedBanner/saveOrUpdate',
      method: 'post',
      data
    })
  },
  // 获取所有链接
  getAllValidLinks (data) {
    return fetchJson({
      url: '/advertsLink/getAllValidLinks',
      method: 'post',
      data
    })
  },
  // 请求banner数据
  bannerList (data) {
    return fetchJson({
      url: '/customizedBanner/list',
      method: 'post',
      data
    })
  },
  // 请求app数据
  fetchTableData (data) {
    return fetchJson({
      url: '/product/classify/search',
      method: 'post',
      data
    })
  },
  // 提交排序
  fetchSubmitData (listString) {
    const data = {
      listString
    }
    return fetch({
      url: '/product/classify/order/update',
      method: 'post',
      data
    })
  },
  // 提交点击去向编辑
  fetchEditDirectionForm (data) {
    return fetchJson({
      url: '/product/editDestination',
      method: 'post',
      data
    })
  },
  importValidation (data, pra) {
    return fetchFile({
      url: `/product/importValidation?channelId=${pra.channelId}&classifyCode=${pra.classifyCode}&name=${pra.name}&productId=${pra.productId}&tag=${pra.tag}`,
      method: 'post',
      data
    })
  },
  importSort (pra) {
    return fetchFile({
      url: `/product/importSort?isImport=${pra}`,
      method: 'post'
    })
  },
  lockFalgEdit (data) {
    return fetch({
      url: `/product/lockFalg/edit`,
      method: 'post',
      data
    })
  },
  // api banner
  switchApiBannerShow (data) {
    return fetchJson({
      url: '/product/switchApiBannerShow',
      method: 'post',
      data
    })
  },
  // 根据linkID查链接信息
  getAdvertsLinkById (data) {
    return fetchJson({
      url: `/advertsLink/getAdvertsLinkById?id=${data}`,
      method: 'post'
    })
  }
}
