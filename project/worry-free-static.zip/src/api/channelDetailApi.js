import fetchJson from 'utils/fetchJson'

export default {
  // 获取渠道推广明细按天
  fetchDayTable (data) {
    return fetchJson({
      url: '/promotion/detail/list/search',
      method: 'post',
      data
    })
  }
}
