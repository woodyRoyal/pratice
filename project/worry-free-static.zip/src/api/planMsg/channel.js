import fetchJson from 'utils/fetchJson'

export default {
  // 通道列表
  getConfigList (data) {
    return fetchJson({
      url: '/sms/passage/getConfigList',
      method: 'post',
      data,
    })
  },
// 通道列表
editConfig (data) {
  return fetchJson({
    url: '/sms/passage/editConfig',
    method: 'post',
    data,
  })
},
// 通道列表
getOperateRecord (id) {
  return fetchJson({
    url: `/sms/passage/getOperateRecord?id=${id}`,
    method: 'post',
  })
},
}
