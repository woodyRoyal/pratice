
import fetchJson from 'utils/fetchJson'
import fetch from 'utils/fetch'
// import fethchFile from 'utils/fethchFile'
export default {
  // 推送统计查询
  query (data) {
    return fetchJson({
      url: '/smsPushCount/query',
      method: 'post',
      data:{
        ...data,
        planType:3,
      },
    })
  },
}
