import fetchJson from 'utils/fetchJson'
// import fethchFile from 'utils/fethchFile'
export default {
  // 推送统计查询
  query (data) {
    return fetchJson({
      url: 'pushConfig/query',
      method: 'post',
      data:{
        ...data,
        planType:3,
      },
    })
  },
  // 推送统计查询
  updateStatus (data) {
    return fetchJson({
      url: 'pushConfig/updateStatus',
      method: 'post',
      data:{
        ...data,
        planType:3,
      },
    })
  },
}

