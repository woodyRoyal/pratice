import fetch from 'utils/fetch'
import fetchJson from 'utils/fetchJson'
export default{
  // 上传图片
  uploadImgFile (formData) {
    const data = formData
    return fetch({
      url: '/upload/uploadImgFile',
      method: 'post',
      data
    })
  },
  // 产品停用/启用
  enableOrDisable (data) {
    return fetch({
      url: '/product/enableOrDisable',
      method: 'post',
      data
    })
  },
  // 产品展示
  getProducts () {
    return fetch({
      url: '/product/list/search',
      method: 'get'
    })
  },
  // 产品限制编辑
  limitEdit (data) {
    return fetch({
      url: '/product/limitEdit',
      method: 'post',
      data
    })
  },
  // 分类产品展示
  listClassifyProduct (data) {
    return fetch({
      url: '/product/classify/list/search',
      method: 'post',
      data
    })
  },
  // 分类排序修改
  saveClassifyProduct (data) {
    return fetch({
      url: '/product/classify/order/update',
      method: 'post',
      data
    })
  },
  // 添加产品
  addProduct (data) {
    return fetchJson({
      url: '/product/insert',
      method: 'post',
      data
    })
  },
  // 编辑产品
  update (data) {
    return fetchJson({
      url: '/product/update',
      method: 'post',
      data
    })
  },
  'URL_UPLOAD': process.env.BASE_API + '/upload/uploadImgFile',
  // 编辑产品
  disableCheck (data) {
    return fetchJson({
      url: `/product/disableCheck?productId=${data}`,
      method: 'post'
    })
  }
}
