import fetchJson from 'utils/fetchJson'
import fethchFile from 'utils/fethchFile'
// 推广支出录入
export default {
  // 列表数据查询
  expendList (data) {
    return fetchJson({
      url: '/promotion/fee/list/search',
      method: 'post',
      data
    })
  },
  edit (data) {
    return fetchJson({
      url: `/promotion/fee/list/edit`,
      method: 'post',
      data
    })
  },
  upload (data, type, userId) {
    return fethchFile({
      url: `/promotion/fee/list/batchImport?type=${type}&userId=${userId}`,
      method: 'post',
      data
    })
  },
  lock (data) {
    return fetchJson({
      url: `/promotion/fee/list/lock`,
      method: 'post',
      data
    })
  },
  // 渠道服务商
  facilitator (data) {
    return fetchJson({
      url: '/channel/facilitator/findAll',
      method: 'post',
      data
    })
  },
  // 渠道负责人
  principal (data) {
    return fetchJson({
      url: '/channel/principal/findAll',
      method: 'post',
      data
    })
  },
  // hvoer弹窗数据
  hover (name) {
    return fetchJson({
      url: `/channel/queryChannelByName?name=${name}`,
      method: 'post'
    })
  },
  dayStartDown (data) {
    return fetchJson({
      url: `/promotion/fee/export`,
      method: 'post',
      data
    })
  }
}
