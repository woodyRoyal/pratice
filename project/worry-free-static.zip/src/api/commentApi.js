import fetchJson from 'utils/fetchJson'

export default {
  // 添加
  facilitatorSave (data) {
    return fetchJson({
      url: '/channel/facilitator/save',
      method: 'post',
      data
    })
  },
  // 添加
  mediaSave (data) {
    return fetchJson({
      url: `/channel/media/save?userId=${data.userId}`,
      method: 'post',
      data
    })
  },
  // 添加
  typeSave (data) {
    return fetchJson({
      url: `/channel/type/save?userId=${data.userId}`,
      method: 'post',
      data
    })
  },
  // 添加
  principalSave (data) {
    return fetchJson({
      url: `/channel/principal/save?userId=${data.userId}`,
      method: 'post',
      data
    })
  }

}
