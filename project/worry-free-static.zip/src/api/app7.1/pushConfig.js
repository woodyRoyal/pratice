import fetchJson from 'utils/fetchJson'
import fetch from 'utils/fetch.js'
// import fethchFile from 'utils/fethchFile'
export default {
  // 推送配置保存
  saveOrUpdate (data) {
    return fetchJson({
      url: 'pushConfig/saveOrUpdate',
      method: 'post',
      data,
    })
  },
  // 产品列表
  getProductList (data) {
    return fetchJson({
      url: '/product/getProductList',
      method: 'post',
      data,
    })
  },
  // 搜索链接id
  searchLinks (data) {
    return fetch({
      url: `/product/searchLinksWithProductLine`,
      method: 'post',
      data,
    })
  },
  // 获取渠道汇总table
  queryChannel (data) {
    return fetchJson({
      url: '/channel/queryChannel',
      method: 'post',
      data,
    })
  },
  // 搜索
  queryByPlanCode (data) {
    return fetchJson({
      url: `pushConfig/queryByPlanCode`,
      method: 'post',
      data,
    })
  },
  'URL_UPLOAD': process.env.BASE_API + '/pushConfig/importUser',
}
