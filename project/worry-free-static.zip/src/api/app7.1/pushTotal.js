
import fetchJson from 'utils/fetchJson'
import fetch from 'utils/fetch'
// import fethchFile from 'utils/fethchFile'
export default {
  // 推送统计查询
  query (data) {
    return fetchJson({
      url: 'pushOnTimeConfig/queryCount',
      method: 'post',
      data:{
        ...data,
        planType:2,
      },
    })
  },
  queryByPlanCode (data) {
    return fetchJson({
      url: `pushOnTimeConfig/queryByPlanCode`,
      method: 'post',
      data:{
        ...data,
        planType:2,
      },
    })
  },
  // 产品列表
  getProductList (data) {
    return fetchJson({
      url: '/product/getProductList',
      method: 'post',
      data:{
        ...data,
        planType:2,
      },
    })
  },
  // 搜索链接id
  searchLinks (data) {
    return fetch({
      url: `/product/searchLinksWithProductLine`,
      method: 'post',
      data:{
        ...data,
        planType:2,
      },
    })
  },
}
