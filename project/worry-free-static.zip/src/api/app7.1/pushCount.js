
import fetchJson from 'utils/fetchJson'
// import fethchFile from 'utils/fethchFile'
export default {
  // 推送统计查询
  query (data) {
    return fetchJson({
      url: 'pushCount/query',
      method: 'post',
      data:{
        ...data,
        planType:1,
      },
    })
  },
}
