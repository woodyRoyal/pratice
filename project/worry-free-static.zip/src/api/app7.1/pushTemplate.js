
import fetchJson from 'utils/fetchJson'
import fetch from 'utils/fetch.js'
export default {
  // 推送模板列表
  query (data) {
    return fetchJson({
      url: 'pushOnTimeConfig/query',
      method: 'post',
      data:{
        ...data,
        planType:2,
      },
    })
  },
  operateRecord (data) {
    return fetchJson({
      url: `auto/sms/config/operateRecord?id=${data}`,
      method: 'post',
    })
  },
  updateStatus (data) {
    return fetchJson({
      url: `pushOnTimeConfig/updateStatus`,
      method: 'post',
      data:{
        ...data,
        planType:2,
      },
    })
  },
  saveOrUpdate (data) {
    return fetchJson({
      url: `pushOnTimeConfig/saveOrUpdate`,
      method: 'post',
      data:{
        ...data,
        planType:2,
      },
    })
  },
  queryByPlanCode (data) {
    return fetchJson({
      url: `pushOnTimeConfig/queryByPlanCode`,
      method: 'post',
      data:{
        ...data,
        planType:2,
      },
    })
  },
  // 产品列表
  getProductList (data) {
    return fetchJson({
      url: '/product/getProductList',
      method: 'post',
      data:{
        ...data,
        planType:2,
      },
    })
  },
  // 搜索链接id
  searchLinks (data) {
    return fetch({
      url: `/product/searchLinksWithProductLine`,
      method: 'post',
      data:{
        ...data,
        planType:2,
      },
    })
  },
}
