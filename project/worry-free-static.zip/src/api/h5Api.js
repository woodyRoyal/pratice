import fetchJson from 'utils/fetchJson'

export default {
  // 获取H5落地页table
  fetchTableData (data) {
    return fetchJson({
      url: '/promotion/pageList/search',
      method: 'post',
      data
    })
  },
  // 添加
  insert (data) {
    return fetchJson({
      url: '/promotion/h5/insert',
      method: 'post',
      data
    })
  },
  // 编辑
  edit (data) {
    return fetchJson({
      url: '/promotion/page/edit',
      method: 'post',
      data
    })
  }
}
