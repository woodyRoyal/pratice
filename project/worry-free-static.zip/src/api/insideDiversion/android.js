import fetchJson from 'utils/fetchJson'
// let mock = `http://rap.2345intra.com/mockjs/269/`
let mock = ``
export default {
  // 获取过审产品信息列表/详情
  getProductInfo (productId, operateType) {
    return fetchJson({
      url: mock + `product/review/getProductInfo?productId=${productId}&operateType=${operateType}`,
      method: 'post'
    })
  },
  // 新增/更新过审产品
  addOrUpdateProduct (data) {
    return fetchJson({
      url: mock + 'product/review/addOrUpdateProduct',
      method: 'post',
      data
    })
  },
  // productAddress string
  // productId number
  // productName
  deleteProduct (productId) {
    return fetchJson({
      url: mock + `product/review/deleteProduct?productId=${productId}`,
      method: 'post'
    })
  }
}
