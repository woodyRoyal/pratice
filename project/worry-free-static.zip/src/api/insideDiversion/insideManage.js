import fetchJson from 'utils/fetchJson'

export default {
  // 获取内部导流方案列表/详情
  getInsideDiversions (data) {
    return fetchJson({
      url: 'diversion/getInsideDiversions',
      method: 'post',
      data
    })
  },
  // 新增/更新内部导流方案
  saveOrUpdateInsideDiversion (data) {
    return fetchJson({
      url: 'diversion/saveOrUpdateInsideDiversion',
      method: 'post',
      data
    })
  },
  deleteInsideDiversion (data) {
    return fetchJson({
      url: `/diversion/deleteInsideDiversion?id=${data}`,
      method: 'post'
    })
  },
  // 判断产品名称是否有效
  getInnerDiversionProducts (data) {
    return fetchJson({
      url: 'diversion/getInnerDiversionProducts',
      method: 'post',
      data
    })
  }
}
