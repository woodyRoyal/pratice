import fetchJson from 'utils/fetchJson'
import fethchFile from 'utils/fethchFile'

export default {
  // 获取内部导流产品列表/详情
  getInnerDiversionProducts (data) {
    return fetchJson({
      url: 'diversion/getInnerDiversionProducts',
      method: 'post',
      data
    })
  },
  // 新增/更新内部导流产品
  saveInnerDiversionProduct (data) {
    return fetchJson({
      url: 'diversion/saveInnerDiversionProduct',
      method: 'post',
      data
    })
  },
  // 判断产品名称是否有效
  checkInnerDiversionProduct (data) {
    return fetchJson({
      url: 'diversion/checkInnerDiversionProduct',
      method: 'post',
      data
    })
  },
  // 删除内部导流产品
  deleteInnerDiversionProduct (data) {
    return fetchJson({
      url: `diversion/deleteInnerDiversionProduct?productId=${data}`,
      method: 'post'
    })
  },
  upload (data) {
    return fethchFile({
      url: `upload/uploadImgFile`,
      method: 'post',
      data
    })
  },
  'URL_UPLOAD': process.env.BASE_API + '/upload/uploadImgFile'
}
