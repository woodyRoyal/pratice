import fetchJson from 'utils/fetch'

export default {
  // 列表查商务
  getBusinessPrincipalList (params) {
    return fetchJson({
      url: `businessPrincipal/getBusinessPrincipalList`,
      method: 'get',
      params
    })
  },
  // 商务负责人商务
  saveOrUpdateBusinessPrincipal (data) {
    return fetchJson({
      url: `businessPrincipal/saveOrUpdateBusinessPrincipal`,
      method: 'post',
      data
    })
  }
}
