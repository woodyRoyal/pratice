import fetch from 'utils/fetch'
import fetchJson from 'utils/fetchJson'

export default {
  // 列表
  getList (data) {
    return fetchJson({
      url: `incomeStatement/getList`,
      method: 'post',
      data
    })
  },
  // 更新计算相关属性
  updateCalcProperties (data) {
    return fetch({
      url: `incomeStatement/updateCalcProperties`,
      method: 'post',
      data
    })
  },
  // 更新备注字段
  updateProperties (data) {
    return fetch({
      url: `incomeStatement/updateProperties`,
      method: 'post',
      data
    })
  },
  // 提报接口
  raiseReport (data) {
    return fetchJson({
      url: `incomeStatement/raiseReport`,
      method: 'post',
      data
    })
  }
}
