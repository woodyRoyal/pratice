import fetchJson from 'utils/fetch'
import fethchFile from 'utils/fethchFile'
export default {
  // 数据字典
  getDic (data) {
    return fetchJson({
      url: `dic/getDic?dicType=${data}`,
      method: 'get'
    })
  },
  // 上传图片
  upload (data) {
    return fethchFile({
      url: `upload/uploadImgFile`,
      method: 'post',
      data
    })
  }
}
