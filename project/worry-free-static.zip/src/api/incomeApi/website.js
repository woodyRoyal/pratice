import fetchJson from 'utils/fetchJson'
export default {
  // 查询官网首页信息(网站查询)
  getWebConfigApi (data) {
    return fetchJson({
      url: 'web/getWebConfig',
      method: 'post',
      data
    })
  },
  // 保存/更新官网首页信息
  saveOrUpdateWebConfigApi (data) {
    return fetchJson({
      url: 'web/saveOrUpdateWebConfig',
      method: 'post',
      data
    })
  },
  // 发布官网首页信息
  publishWebConfigApi (data) {
    return fetchJson({
      url: 'web/publishWebConfig',
      method: 'post',
      data
    })
  },
  // 删除官网首页信息
  deleteWebConfigApi (data) {
    return fetchJson({
      url: 'web/deleteWebConfig',
      method: 'post',
      data
    })
  },
  // 查询公告链接
  getNoticeLinkApi (data) {
    return fetchJson({
      url: 'notice/getNoticeLink',
      method: 'post',
      data
    })
  }
}
