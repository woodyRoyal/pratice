import fetchJson from 'utils/fetchJson'
export default {
  // 分页查询
  //   adBlockId广告版块IDstring
  // cellSystem手机系统，1-android,2-iosnumber
  // productLine产品线,1-花钱无忧,2-贷款王
  list (data) {
    return fetchJson({
      url: 'advertsLink/getAll',
      method: 'post',
      data
    })
  },
  // 修改状态
  updateAdvertsLinkStatus (data) {
    return fetchJson({
      url: 'advertsLink/updateAdvertsLinkStatus',
      method: 'post',
      data
    })
  },
  // 修改状态
  insertOrUpdateAdvertsLink (data) {
    return fetchJson({
      url: 'advertsLink/insertOrUpdateAdvertsLink',
      method: 'post',
      data
    })
  },
  // 查询公告链接
  getNoticeLink (data) {
    return fetchJson({
      url: 'notice/getNoticeLink',
      method: 'post',
      data
    })
  },
  // 查询公告链接
  updateNoticeLink (data) {
    return fetchJson({
      url: 'notice/updateNoticeLinkDetail',
      method: 'post',
      data
    })
  }
}
