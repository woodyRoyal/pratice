import fetchJson from 'utils/fetch'
export default {
  // 分页查询广告主列表advertiser/batchUpdateBusinessPrincipal
  getAdvertiserList (params) {
    return fetchJson({
      url: 'advertiser/getAdvertiserList',
      method: 'get',
      params
    })
  },
  getAdvertiserPaymentList (params) {
    return fetchJson({
      url: `advertiserPayment/getAdvertiserPaymentList?advertiserId=${params}`,
      method: 'get'
    })
  },
  batchUpdateBusinessPrincipal (data) {
    return fetchJson({
      url: 'advertiser/batchUpdateBusinessPrincipal',
      method: 'post',
      data
    })
  },
  saveOrUpdatePayment (data) {
    return fetchJson({
      url: 'advertiserPayment/saveOrUpdatePayment',
      method: 'post',
      data
    })
  },
  updateIndividual (data) {
    return fetchJson({
      url: 'advertiser/updateIndividual',
      method: 'post',
      data
    })
  },
  saveOrUpdate (data) {
    return fetchJson({
      url: 'advertiser/saveOrUpdate',
      method: 'post',
      data
    })
  },
  getAdvertiserMonitor (params) {
    return fetchJson({
      url: `advertiser/getAdvertiserMonitor?advertiserId=${params}`,
      method: 'get'
    })
  },
  // 更新记录
  updateAdvertiserMonitor (data) {
    return fetchJson({
      url: `advertiser/updateAdvertiserMonitor`,
      method: 'post',
      data
    })
  }
}
