import fetchJson from 'utils/fetchJson'
import fethchFile from 'utils/fethchFile'
export default {
  // 分页查询
//   adBlockId广告版块IDstring
// cellSystem手机系统，1-android,2-iosnumber
// productLine产品线,1-花钱无忧,2-贷款王
  list (data) {
    return fetchJson({
      url: 'adBlock/list',
      method: 'post',
      data
    })
  },
  adjustPriority (data) {
    return fetchJson({
      url: 'adBlock/adjustPriority',
      method: 'post',
      data
    })
  },
  updateAdBlock (data) {
    return fetchJson({
      url: 'adBlock/updateAdBlock',
      method: 'post',
      data
    })
  },
  fethchFile (data) {
    return fethchFile({
      url: `adBlock/upload`,
      method: 'post',
      data
    })
  }
}
