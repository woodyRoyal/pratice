import fetchJson from 'utils/fetchJson'
import fetch from 'utils/fetch'

export default {
  // 获取apptable
  getDataList (data) {
    return fetchJson({
      url: '/diversion/getOutDiversions',
      method: 'post',
      data
    })
  },
  // 编辑
  editData (data) {
    return fetchJson({
      url: '/diversion/saveOutDiversion',
      method: 'post',
      data
    })
  },
  // 删除
  deleteData (data) {
    return fetch({
      url: '/diversion/delOutDiversion',
      method: 'post',
      data
    })
  }
}
