import fetchJson from 'utils/fetchJson'
export default {
  // 获取渠道汇总table
  fetchTableData (data) {
    return fetchJson({
      url: '/channel/queryChannel',
      method: 'post',
      data
    })
  },
  // 添加编辑渠道
  save (data) {
    return fetchJson({
      url: `/channel/save?userId=${data.userId}`,
      method: 'post',
      data
    })
  },
  // 域名查询
  getDomain () {
    return fetchJson({
      url: '/channel/link/getDomain',
      method: 'post'
    })
  },
  // 批量更新负责人
  batchUpdate (data) {
    return fetchJson({
      url: `/channel/principal/batchUpdate?channels=${data.channels}&channelsType=${data.channelsType}&principalIdNew=${data.principalIdNew}&principalIdOld=${data.principalIdOld}&idOld=${data.idOld}`,
      method: 'post'
      // data
    })
  },
  // 推广链接拼接接口
  assemble (data) {
    return fetchJson({
      url: `/channel/link/assemble?channel=${data.channel}&domainName=${data.domainName}&httpsFlag=${data.httpsFlag}&linkType=${data.linkType}&platform=${data.platform}`,
      method: 'post'
    })
  },
  // 渠道唯一性验证
  unique (data) {
    return fetchJson({
      url: `/channel/check/unique?channel=${data}`,
      method: 'post'
    })
  },
  // 渠道媒体查询
  media (data) {
    return fetchJson({
      url: '/channel/media/findAll',
      method: 'post',
      data
    })
  },
  // 渠道服务商
  facilitator (data) {
    return fetchJson({
      url: 'channel/facilitator/findAll',
      method: 'post',
      data
    })
  },
  // 渠道类型
  type (data) {
    return fetchJson({
      url: 'channel/type/findAll',
      method: 'post',
      data
    })
  },
  // 渠道负责人
  principal (data) {
    return fetchJson({
      url: 'channel/principal/findAll',
      method: 'post',
      data
    })
  },
  // 唯一性校验
  checkChannelName (data) {
    return fetchJson({
      url: '/channel/checkChannelName',
      method: 'post',
      data
    })
  },
  // 批量拼接链接
  batchAssembleLink (data) {
    return fetchJson({
      url: '/channel/batchAssembleLink',
      method: 'post',
      data
    })
  },
  // 批量
  batchSave (data) {
    return fetchJson({
      url: `/channel/batchSave?userId=${data.userId}`,
      method: 'post',
      data
    })
  }
}
