import fetch from 'utils/fetch'
import fetchJson from 'utils/fetchJson'
export default{
  // 上传图片
  uploadImgFile (formData) {
    const data = formData
    return fetch({
      url: '/upload/uploadImgFile',
      method: 'post',
      data
    })
  },
  // 产品停用/启用
  enableOrDisable (data) {
    return fetchJson({
      url: '/product/enableOrDisable',
      method: 'post',
      data
    })
  }
}
