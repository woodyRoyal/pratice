import fetch from 'utils/fetch'
import fetchJson from 'utils/fetchJson'
export default {
  // 后台操作记录
  fetchTableData (data) {
    return fetchJson({
      url: '/operatehistory/queryByCondition',
      method: 'post',
      data
    })
  },
  operateType (data) {
    return fetchJson({
      url: '/operatehistory/query/operateType',
      method: 'post',
      data
    })
  },
  // 添加
  insert (data) {
    return fetch({
      url: '/operateHistory/add',
      method: 'post',
      data
    })
  },
  // 编辑
  edit (data) {
    return fetch({
      url: '/promotion/page/edit',
      method: 'post',
      data
    })
  }
}
