import fetchJson from 'utils/fetchJson'

export default {
  // 获取apptable
  fetchTableData (data) {
    return fetchJson({
      url: '/app/review/list/search',
      method: 'get',
      data
    })
  },
  // 添加 App
  addApp (data) {
    return fetchJson({
      url: '/app/review/one/add',
      method: 'post',
      data
    })
  },
  // 编辑 App
  appEdit (data) {
    return fetchJson({
      url: '/app/review/one/edit',
      method: 'post',
      data
    })
  },
  // 编辑 App
  channelEdit (data) {
    return fetchJson({
      url: '/app/review/channel/edit',
      method: 'post',
      data
    })
  }
}
