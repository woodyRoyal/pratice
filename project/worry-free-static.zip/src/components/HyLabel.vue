<template>
  <div v-if="title"
       class="hy-label"
       :class="type"
       :style="{backgroundColor: colorRgb(color), color: color}"
       v-text="title"></div>
</template>

<script>
export default {
  name: 'HyLabel',
  props: {
    title: { // 标签展示文言
      type: [String, Number],
      default: '',
    },
    color: { // 标签文字颜色
      type: String,
      default: '#bbb',
    },
    type: { // 自定义class
      type: String,
      default: '',
    },
  },
  methods: {
    // HEX 与 rgb/rgba之间的相互转换
    colorRgb (color, opacity = 0.05) {
      let reg = /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/
      if (color && reg.test(color)) {
        let sColor = color.toLowerCase()
        if (sColor.length === 4) {
          var sColorNew = "#"
          for (let i = 1; i < 4; i++) {
            sColorNew += sColor.slice(i, i + 1).concat(sColor.slice(i, i + 1))
          }
          sColor = sColorNew
        }
        // 处理六位的颜色值
        let sColorChange = []
        for (var i = 1; i < 7; i += 2) {
          sColorChange.push(parseInt("0x" + sColor.slice(i, i + 2), 16));
        }
        // 转换为rgba，透明度为传递的参数opacity
        return "rgba(" + sColorChange.join(",") + "," + opacity + ")"
      } else {
        return color
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.hy-label {
  display: flex;
  align-items: center;
  margin-right: 12px;
  height: 34px;
  line-height: normal;
  padding: 0 13px;
  // padding-top: rc(4);
  box-sizing: border-box;
  font-size: 20px;
  border-radius: 6px;
  white-space: nowrap;
}
</style>

