/**
* Created by zuo on 2017/8/18.
* APlayer：https://www.npmjs.com/package/aplayer  https://aplayer.js.org/docs/#/
*/

<template>
  <div>
    <div id="recordPlayer" class="aplayer"></div>
    <div class="aplayer-play-speed">
      <span class="speed-title" title="播放速度">倍速:</span>
      <el-radio-group size="small" v-model="playSpeed">
        <el-radio-button v-for="(val, index) in playSpeedList" :label="val" :key="index">{{ val }}</el-radio-button>
      </el-radio-group>
      <div class="download-btn" title="下载录音文件">
        <a :href="music.url" download><i class="iconfont icon-xiazai"></i></a>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import APlayer from './MoePlayer-APlayer/APlayer.js'

  export default {
    name: 'VueAudioPlayer',
    props: {
      narrow: { // 进度条
        type: Boolean,
        default: false
      },
      autoplay: { // 自动播放
        type: Boolean,
        default: false
      },
      showlrc: { // 显示歌词
        type: Number,
        default: 0
      },
      mutex: { // 互斥 同时只有一个播放器播放
        type: Boolean,
        default: false
      },
      theme: { // 主题色
        type: String,
        default: '#333'
      },
      mode: { // 模式 `random` `single` `circulation`(loop) `order`(no loop), default: `circulation`
        type: String,
        default: 'circulation'
      },
      preload: { // 预加载
        type: String,
        default: 'auto'
      },
      /* speed: { // 播放速度
        type: Number,
        default: 1
      }, */
      listmaxheight: String, // 列表最大高度
      playOrPause: { // 播放或暂停
        type: Boolean,
        default: false
      },
      music: {
        type: [Object, Array],
        required: true
      }
    },
    data () {
      return {
        control: null,
        playSpeed: 1.2, // 默认播放倍速
        playSpeedList: [0.8, 0.9, 1, 1.1, 1.2, 1.3, 1.4] // 播放倍速列表
      }
    },
    watch: {
      music (val) {
        // 销毁APlayer对象
        if (this.control && this.control.audio) {
          this.control.destroy()
        }
        // 创建新的APlayer对象
        this.createPlayer()
        this.$emit('change', val)
      },
      playSpeed (val) {
        this.handleChangeSpeed(val)
      },
      playOrPause (val) {
        if (val) {
          this.handleAudioPlay()
        } else {
          this.handleAudioPause()
        }
      }
    },
    mounted () {
//      this.createPlayer()
    },
    methods: {
      // 创建APlayer对象 并开启事件监听
      createPlayer () {
        let player = new APlayer({
          element: document.getElementById('recordPlayer'),
          narrow: this.narrow,
          autoplay: this.autoplay,
          showlrc: this.showlrc,
          mutex: this.mutex,
          theme: this.theme,
          preload: this.preload,
          mode: this.mode,
          listmaxheight: this.listmaxheight,
          music: this.music
        })

        this.control = player

        // 事件监听
        player.on('play', () => { // 播放
          this.$emit('play')
        })
        player.on('pause', () => { // 暂停
          this.$emit('pause')
        })
        player.on('canplay', () => { // 可播放
          this.$emit('canplay')
        })
        player.on('playing', () => { // 播放中
          this.$emit('playing', player)
        })
        player.on('ended', () => { // 播放结束
          this.$emit('ended')
        })
        player.on('error', () => { // 播放错误
          this.$emit('error')
        })
      },
      // 改变播放速度
      handleChangeSpeed (speed) {
        this.control.audio.playbackRate = speed
        console.log('the audio playbackRate: ' + this.control.audio.playbackRate)
      },
      // 触发播放
      handleAudioPlay () {
        this.control.play()
      },
      // 触发暂停
      handleAudioPause () {
        this.control.pause()
      }
    },
    deactivated () {
      console.log('deactivated VueAudioPlayer ......')
      if (this.control) {
        this.handleAudioPause()
        this.control.destroy()
      }
    },
    beforeDestroy () {
      console.log('destroy VueAudioPlayer ......')
      if (this.control) {
        this.handleAudioPause()
        this.control.destroy()
      }
    }
  }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  .aplayer {
    background-color: #1F2D3D;
    margin: 0;
  }

  .aplayer-play-speed {
    position: absolute;
    top: 3px;
    right: 15px;
    font-size: 14px;
    .link-type {
      margin-left: 10px;
      color: #fff;
    }
    .speed-title {
      color: #bfcbd9;
    }
    .download-btn {
      color: #cdcdcd;
      float: right;
      margin-left: 10px;
      width: 38px;
      height: 25px;
      line-height: 22px;
      cursor: pointer;
      text-align: center;
    }
    .download-btn:hover {
      color: #fff;
    }
  }
</style>
