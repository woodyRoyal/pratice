<!--折叠板-->
<template>
  <el-card class="box-card box-user-defined">
    <div class="box-header">
      <div class="box-control" @click="expandOrCollapseCampaignBox">
        <span v-text="titleText" v-if="titleText"></span>
        <i :class="[isExpandCampaignBox ? 'el-icon-arrow-up' : 'el-icon-arrow-down']"></i>
      </div>
    </div>
    <div v-show="isExpandCampaignBox" class="box-body">
      <slot name="body">
      </slot>
    </div>
  </el-card>
</template>
<script>
  export default {
    name: 'CollapseBox',
    props: {
      titleText: {
        type: String,
        default: ''
      }
    },
    data () {
      return {
        isExpandCampaignBox: true
      }
    },
    methods: {
      expandOrCollapseCampaignBox () {
        this.isExpandCampaignBox = !this.isExpandCampaignBox
      }
    }
  }
</script>
<style lang="scss" scoped>
  .box-header {
    height: 30px;
    .box-control {
      color: #d3dce6;
      cursor: pointer;
      transition: .2s;
      line-height: 30px;
      padding-left: 15px;
      font-size: 14px;
    }

    .box-control:hover {
      color: #20a0ff;
    }

    .box-control i {
      font-size: 12px;
      transition: .3s;
    }
  }

  .box-body {
    padding: 15px;
  }

</style>
