import Vue from 'vue'
import Router from 'vue-router'

/* layout */
import Layout from '../views/layout/Layout'

/* login */
import Login from '../views/login/'
import authRedirect from '../views/login/authredirect'
import sendPWD from '../views/login/sendpwd'
import reset from '../views/login/reset'
import packageConfig from 'package'

/* error page */
const Err404 = (resolve) => require(['../views/error/404'], resolve)
const Err401 = (resolve) => require(['../views/error/401'], resolve)
const Home = (resolve) => require(['../views/layout/Home'], resolve)
const previewData = (resolve) => require(['../views/app/preview'], resolve)
/* system */
// const Parameter = resolve => require(['../views/system/parameter'], resolve)
// const Schedule = resolve => require(['../views/system/schedule'], resolve)
// const SystemMenu = resolve => require(['../views/system/menu'], resolve)
const SystemPermission = (resolve) => require(['../views/system/permission'], resolve)
// const SystemGroup = resolve => require(['../views/system/group'], resolve)
const SystemRole = (resolve) => require(['../views/system/role'], resolve)
const SystemUser = (resolve) => require(['../views/system/user'], resolve)
// const Page = resolve => require(['../views/product/page'], resolve)
// const Product = resolve => require(['../views/product/product'], resolve)
const App = (resolve) => require(['../views/app/index'], resolve)
const Production = (resolve) => require(['../views/production/production'], resolve)
const ChannelManage = (resolve) => require(['../views/marketing/channel-manage.vue'], resolve)
const ChannelDatabase = (resolve) => require(['../views/marketing/channel-database.vue'], resolve)
const ChannelTotal = (resolve) => require(['../views/marketing/channel-tag/channel-total.vue'], resolve)
const ChannelService = (resolve) => require(['../views/marketing/channel-tag/channel-service.vue'], resolve)
const ChannelType = (resolve) => require(['../views/marketing/channel-tag/channel-type.vue'], resolve)
const ChannelMedia = (resolve) => require(['../views/marketing/channel-tag/channel-media.vue'], resolve)
const ChannelPrincipal = (resolve) => require(['../views/marketing/channel-tag/channel-principal.vue'], resolve)
const ChannelH5 = (resolve) => require(['../views/marketing/channel-tag/channel-H5.vue'], resolve)
const channelDetail = (resolve) => require(['../views/marketing/channel-database/channel-detail.vue'], resolve)
const channelDetailHour = (resolve) => require(['../views/marketing/channel-database/channel-detail-hour.vue'], resolve)
// 推广支出录入
const expend = (resolve) => require(['../views/marketing/channel-database/expend.vue'], resolve)
const quality = (resolve) => require(['../views/marketing/channel-database/quality.vue'], resolve)
// 渠道回调
// const callback = resolve => require(['../views/marketing/callback.vue'], resolve)
// 统计报表
const expendTable = (resolve) => require(['../views/table/expend-table.vue'], resolve)
const dayTable = (resolve) => require(['../views/table/expend/day-table.vue'], resolve)
const monthTable = (resolve) => require(['../views/table/expend/month-table.vue'], resolve)
// 监控预警
const record = (resolve) => require(['../views/monitor/record.vue'], resolve)
// 过审管理
const auditApp = (resolve) => require(['../views/auditManage/app.vue'], resolve)
const auditManage = (resolve) => require(['../views/auditManage/auditManage.vue'], resolve)
const android = (resolve) => require(['../views/auditManage/android.vue'], resolve)
const audit = (resolve) => require(['../views/auditManage/audit.vue'], resolve)
const diversion = (resolve) => require(['../views/auditManage/diversion.vue'], resolve)
const insideManage = (resolve) => require(['../views/auditManage/insideManage.vue'], resolve)
const insideProduct = (resolve) => require(['../views/auditManage/insideProduct.vue'], resolve)
// 新导流平台
const auditSwitch = (resolve) => require(['../views/auditManage/newAudit/auditSwitch.vue'], resolve)
const auditDocument = (resolve) => require(['../views/auditManage/newAudit/auditDocument.vue'], resolve)
const auditLink = (resolve) => require(['../views/auditManage/newAudit/auditLink.vue'], resolve)
// 广告主管理
const advertiser = (resolve) => require(['../views/income/advertiser.vue'], resolve)
// 商务负责人
const person = (resolve) => require(['../views/income/person.vue'], resolve)
// 收入详细
const incomeDetail = (resolve) => require(['../views/income/detail.vue'], resolve)
// 短信模块页面
const filtering = (resolve) => require(['../views/message/filtering.vue'], resolve)
const unsubscribe = (resolve) => require(['../views/message/unsubscribe.vue'], resolve)
const score = (resolve) => require(['../views/message/score.vue'], resolve)
const result = (resolve) => require(['../views/message/result.vue'], resolve)
const MsgConfig = (resolve) => require(['../views/message/message-config.vue'], resolve)
const autoMsg = (resolve) => require(['../views/message/config/autoMsg.vue'], resolve)
const MsgRecord = (resolve) => require(['../views/message/config/record.vue'], resolve)
const report = (resolve) => require(['../views/message/config/report.vue'], resolve)
const scoreManage =  (resolve) => require(['../views/message/score-manage.vue'], resolve)
// 计划短信
const planMsgConfig =  (resolve) => require(['../views/message/planMsg/planMsgConfig.vue'], resolve)
// 短信通道配置
const planMsgChannel =  (resolve) => require(['../views/message/planMsg/channel .vue'], resolve)
// 短信计划管理
const planManage =  (resolve) => require(['../views/message/planMsg/planManage.vue'], resolve)
// 计划短信统计
const planMsgTotal =  (resolve) => require(['../views/message/planMsg/planMsgTotal.vue'], resolve)
// app7.0
const adplace = (resolve) => require(['../views/income/adplace.vue'], resolve)
const adlinks = (resolve) => require(['../views/income/adlinks.vue'], resolve)
// 官网管理
const websiteManage = (resolve) => require(['../views/income/website.vue'], resolve)
// 用户数据解密
const decryption = (resolve) => require(['../views/decryption/index.vue'], resolve)
// app推送运营
// 推送配置
const pushConfig = (resolve) => require(['../views/pushService/push-config.vue'], resolve)
// 推送计划
const pushPlan = (resolve) => require(['../views/pushService/push-plan.vue'], resolve)
// 计划推送统计
const pushPlanTotal = (resolve) => require(['../views/pushService/pushPlan-total.vue'], resolve)
// 即时推送模板
const pushTemplate = (resolve) => require(['../views/pushService/push-template.vue'], resolve)
// 即时推送统计
const pushTotal = (resolve) => require(['../views/pushService/push-total.vue'], resolve)
Vue.use(Router)
/**
 * icon : the icon show in the sidebar
 * hidden : if hidden:true will not show in the sidebar
 * redirect : if redirect:noredirect will not redirct in the levelbar
 * noDropdown : if noDropdown:true will not has submenu
 * meta : { role: ['admin'] }  will control the page role
 */

export const constantRouterMap = [
  { path: '/', redirect: '/home/index', hidden: true, name: '首页' },
  { path: '/login', component: Login, hidden: true },
  { path: '/authredirect', component: authRedirect, hidden: true },
  { path: '/sendpwd', component: sendPWD, hidden: true },
  { path: '/reset', component: reset, hidden: true },
  { path: '/404', component: Err404, hidden: true },
  { path: '/marketing/channelDatabase/channelDetail/:channelName', component: channelDetail, hidden: true },
  { path: '/401', component: Err401, hidden: true },
  { path: '/preview-data/:classifyCode', component: previewData, hidden: true },
  {
    path: '/home',
    component: Layout,
    hidden: true,
    children: [{ path: 'index', component: Home, name: '花钱无忧后台' }],
  },
  {
    path: '/APP',
    component: Layout,
    name: 'APP推送运营',
    hidden: true,
    noDropdown: true,
    icon: 'iconfont icon-chanpin',
    children: [
      { path: 'pushConfig/:planCode', component: pushConfig, name: '推送配置', noDropdown: true },
    ],
  },
  {
    path: '/message',
    component: Layout,
    name: '短信运营',
    noDropdown: true,
    hidden: true,
    icon: 'iconfont icon-shouru',
    children: [
      { path: 'planMsgConfig/:planCode', component: planMsgConfig, name: '计划短信配置', noDropdown: true },
    ],
  },
]

export default new Router({
  mode: 'hash',
  // mode: 'history', //后端支持可开
  scrollBehavior: () => ({ y: 0 }),
  base: '/' + packageConfig.name,
  routes: constantRouterMap,
})
// 路由菜单树
export const asyncRouterMapTree = [
  {
    path: '/income',
    component: Layout,
    name: '收入运营',
    noDropdown: false,
    icon: 'iconfont icon-shouru',
    children: [
      { path: 'productionList', component: Production, name: '产品管理', icon: 'iconfont icon-chanpin', noDropdown: true },
      { path: 'appList', component: App, name: 'APP管理', icon: 'iconfont icon-app', noDropdown: true },
      { path: 'advertiser', component: advertiser, name: '广告主管理', icon: 'iconfont icon-tubiao-', noDropdown: true },
      { path: 'adplace', component: adplace, name: '广告位配置', icon: 'iconfont icon-tubiao-', noDropdown: true },
      { path: 'adlinks', component: adlinks, name: '链接管理', icon: 'iconfont icon-tubiao-', noDropdown: true },
      { path: 'person', component: person, name: '商务负责人', icon: 'iconfont icon-xuanti-fuzeren', noDropdown: true },
      { path: 'detail', component: incomeDetail, name: '收入明细', icon: 'iconfont icon-shourumingxi', noDropdown: true },
      { path: 'website', component: websiteManage, name: '官网管理', icon: 'iconfont icon-jilu', noDropdown: true },
    ],
  },
  {
    path: '/message',
    component: Layout,
    name: '短信运营',
    noDropdown: false,
    icon: 'iconfont icon-shouru',
    children: [
      { path: 'planMsgConfig', component: planMsgConfig, name: '计划短信配置', icon: 'iconfont icon-chanpin', noDropdown: true },
      { path: 'planMsgTotal', component: planMsgTotal, name: '计划短信统计', icon: 'iconfont icon-chanpin', noDropdown: true },
      { path: 'planManage', component: planManage, name: '短信计划管理', icon: 'iconfont icon-chanpin', noDropdown: true },
      { path: 'planMsgChannel', component: planMsgChannel, name: '短信通道配置', icon: 'iconfont icon-chanpin', noDropdown: true },
      { path: 'filtering', component: filtering, name: '手动筛选用户', icon: 'iconfont icon-chanpin', noDropdown: true },
      { path: 'unsubscribe', component: unsubscribe, name: '短信退订管理', icon: 'iconfont icon-chanpin', noDropdown: true },
      {
        path: 'MsgConfig',
        component: MsgConfig,
        name: '即时短信管理”',
        icon: 'iconfont icon-chanpin',
        noDropdown: true,
        children: [
        { path: 'autoMsg', component: autoMsg, name: '自动短信设置', icon: 'iconfont icon-chanpin', noDropdown: true, meta: { active: '/message/MsgConfig' } }, 
        { path: 'MsgRecord', component: MsgRecord, name: '发送记录', icon: 'iconfont icon-chanpin', noDropdown: true, meta: { active: '/message/MsgConfig' } }, 
        { path: 'report', component: report, name: '数据报表', icon: 'iconfont icon-chanpin', noDropdown: true, meta: { active: '/message/MsgConfig' } }],
      },
      {
        path: 'scoreManage',
        component:scoreManage,
        name:'客户分值管理',
        icon: 'iconfont icon-chanpin',
        noDropdown: true,
        children:[
          { path: 'score', component: score, name: '客户分值查询', icon: 'iconfont icon-chanpin', noDropdown: true, meta: { active: '/message/scoreManage' } },
          { path: 'result', component: result, name: '查询结果统计', icon: 'iconfont icon-chanpin', noDropdown: true, meta: { active: '/message/scoreManage' } },
        ],
      },
    ],
  },
  {
    path: '/APP',
    component: Layout,
    name: 'APP推送运营',
    noDropdown: false,
    icon: 'iconfont icon-chanpin',
    children: [
      { path: 'pushConfig', component: pushConfig, name: '推送配置', icon: 'iconfont icon-quanxianguanli', noDropdown: true },
      { path: 'pushPlan', component: pushPlan, name: '推送计划', icon: 'iconfont icon-jilu', noDropdown: true },
      { path: 'pushPlanTotal', component: pushPlanTotal, name: '计划推送统计', icon: 'iconfont icon-genzong', noDropdown: true },
      { path: 'pushTemplate', component: pushTemplate, name: '即时推送模板', icon: 'iconfont icon-chanpin', noDropdown: true },
      { path: 'pushTotal', component: pushTotal, name: '即时推送统计', icon: 'iconfont icon-chanpin', noDropdown: true },
    ],
  },
  {
    path: '/marketing',
    component: Layout,
    name: '市场推广',
    noDropdown: false,
    icon: 'iconfont icon-shichangtuiguang',
    children: [
      {
        path: 'channelManage',
        noDropdown: true,
        icon: 'iconfont icon-qudaoguanli',
        component: ChannelManage,
        name: '渠道管理',
        children: [
          { path: 'channelTotal', component: ChannelTotal, name: '渠道汇总', icon: 'iconfont icon-canshushezhi', meta: { active: '/marketing/channelManage' } },
          { path: 'channelService', component: ChannelService, name: '渠道服务商', icon: 'iconfont icon-canshushezhi', meta: { active: '/marketing/channelManage' } },
          { path: 'channelType', component: ChannelType, name: '渠道类型', icon: 'iconfont icon-canshushezhi', meta: { active: '/marketing/channelManage' } },
          { path: 'channelMedia', component: ChannelMedia, name: '投放媒体', icon: 'iconfont icon-canshushezhi', meta: { active: '/marketing/channelManage' } },
          { path: 'channelPrincipal', component: ChannelPrincipal, name: '渠道负责人', icon: 'iconfont icon-canshushezhi', meta: { active: '/marketing/channelManage' } },
          { path: 'channelH5', component: ChannelH5, name: 'H5落地页', icon: 'iconfont icon-canshushezhi', meta: { active: '/marketing/channelManage' } },
        ],
      },
      {
        path: 'channelDatabase',
        noDropdown: true,
        icon: 'iconfont icon-genzong',
        component: ChannelDatabase,
        name: '渠道数据跟踪',
        // redirect: '/marketing/channelDatabase/channelDetail',
        children: [
          { path: 'channelDetail', component: channelDetail, name: '渠道推广明细（按天）', icon: 'iconfont icon-canshushezhi', meta: { active: '/marketing/channelDatabase' } },
          { path: 'channelDetailHour', component: channelDetailHour, name: '渠道推广明细（按小时）', icon: 'iconfont icon-canshushezhi', meta: { active: '/marketing/channelDatabase' } },
          { path: 'expend', component: expend, name: '推广支出录入', icon: 'iconfont icon-canshushezhi', meta: { active: '/marketing/channelDatabase' } },
          { path: 'quality', component: quality, name: '渠道质量数据', icon: 'iconfont icon-canshushezhi', meta: { active: '/marketing/channelDatabase' } },
        ],
      },
    ],
  },
  {
    path: '/audit',
    component: Layout,
    name: '过审&导流平台模块',
    noDropdown: true,
    icon: 'iconfont icon-jiankong',
    children: [
      {
        path: 'auditManage',
        component: auditManage,
        name: '过审&导流平台',
        icon: 'iconfont icon-jiankong',
        children: [
          { path: 'auditApp', noDropdown: true, component: auditApp, name: 'app包名管理', icon: 'iconfont icon-canshushezhi', meta: { active: '/audit/auditManage' } },
          { path: 'audit', noDropdown: true, component: audit, name: '过审管理', icon: 'iconfont icon-canshushezhi', meta: { active: '/audit/auditManage' } },
          { path: 'diversion', noDropdown: true, component: diversion, name: '外部导流管理(旧)', icon: 'iconfont icon-canshushezhi', meta: { active: '/audit/auditManage' } },
          { path: 'android', noDropdown: true, component: android, name: '安卓过审产品管理', icon: 'iconfont icon-canshushezhi', meta: { active: '/audit/auditManage' } },
          { path: 'insideManage', noDropdown: true, component: insideManage, name: '内部导流管理(旧)', icon: 'iconfont icon-canshushezhi', meta: { active: '/audit/auditManage' } },
          { path: 'insideProduct', noDropdown: true, component: insideProduct, name: '内部导流产品管理(旧)', icon: 'iconfont icon-canshushezhi', meta: { active: '/audit/auditManage' } },
          { path: 'auditSwitch', noDropdown: true, component: auditSwitch, name: '导流开关管理', icon: 'iconfont icon-canshushezhi', meta: { active: '/audit/auditManage' } },
          { path: 'auditDocument', noDropdown: true, component: auditDocument, name: '导流文案管理', icon: 'iconfont icon-canshushezhi', meta: { active: '/audit/auditManage' } },
          { path: 'auditLink', noDropdown: true, component: auditLink, name: '导流链接管理', icon: 'iconfont icon-canshushezhi', meta: { active: '/audit/auditManage' } },
        ],
      },
    ],
  },
  {
    path: '/report',
    component: Layout,
    name: '统计报表',
    noDropdown: false,
    icon: 'iconfont icon-shichangtuiguang',
    children: [
      {
        path: 'expendTable',
        noDropdown: true,
        icon: 'iconfont icon-qudaoguanli',
        component: expendTable,
        name: '支出报表',
        children: [{ path: 'dayTable', noDropdown: true, component: dayTable, name: '支出日报表', icon: 'iconfont icon-canshushezhi', meta: { active: '/report/expendTable' } }, { path: 'monthTable', noDropdown: true, component: monthTable, name: '月报表(对账单)', icon: 'iconfont icon-canshushezhi', meta: { active: '/report/expendTable' } }],
      },
    ],
  },
  {
    path: '/monitor',
    component: Layout,
    name: '监控预警',
    icon: 'iconfont icon-xitongguanli',
    children: [{ path: 'record', noDropdown: true, component: record, name: '操作记录', icon: 'iconfont icon-jilu' }],
  },
  {
    path: '/decryption',
    component: Layout,
    name: '用户数据解密',
    noDropdown: true,
    icon: 'iconfont icon-jilu',
    children: [
      { path: 'decryptionPage', component: decryption, name: '数据解密', icon: 'iconfont icon-jilu' },
    ],
  },
  {
    path: '/system',
    component: Layout,
    name: '系统管理',
    icon: 'iconfont icon-xitongguanli',
    children: [
      // {path: 'param', component: Parameter, name: '参数设置', icon: 'iconfont icon-canshushezhi'},
      // {path: 'schedule', component: Schedule, name: '定时任务', icon: 'iconfont icon-dingshirenwu'},
      // {path: 'menu', noDropdown: true, component: SystemMenu, name: '菜单管理', icon: 'iconfont icon-caidanguanli'},
      { path: 'permission', noDropdown: true, component: SystemPermission, name: '权限管理', icon: 'iconfont icon-quanxianguanli' },
      // {path: 'group', component: SystemGroup, name: '分组管理', icon: 'iconfont icon-fenzu'},
      { path: 'role', noDropdown: true, component: SystemRole, name: '角色管理', icon: 'iconfont icon-jueseguanli' },
      { path: 'user', noDropdown: true, component: SystemUser, name: '用户管理', icon: 'iconfont icon-yonghuguanli' },
    ],
  },
]

// 路由树转换为键值对对象 path为key
function routerTreeListToMapObj (treeList) {
  let mapObj = {}
  treeList.map((item) => transObj(item, mapObj))
  return mapObj
}

// 转换对象
function transObj (source, target) {
  if (!source.path) {
    return
  }
  target[source.path] = {}
  if (source.name) {
    target[source.path].name = source.name
  }
  if (source.component) {
    target[source.path].component = source.component
  }
  if (source.icon) {
    target[source.path].icon = source.icon
  }
  if (source.noDropdown) {
    target[source.path].noDropdown = source.noDropdown
  }
  if (source.redirect) {
    target[source.path].redirect = source.redirect
  }
  if (source.meta) {
    target[source.path].meta = source.meta
  }
  // 递归处理子菜单
  if (source.children && source.children.length > 0) {
    source.children.map((item) => transObj(item, target))
  }
  return target
}
// 输出路由映射对象
export const asyncRouterMapObj = routerTreeListToMapObj(asyncRouterMapTree)

// “*” 匿名路由须放在最后
export const lastRouterConst = [{ path: '*', redirect: '/home/index', hidden: true }]
