<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'APP',

}
</script>
<style lang="scss">
/* 监控预警系统图标 */
@import url(//at.alicdn.com/t/font_808089_iouq02p1abk.css);
// @import url(//at.alicdn.com/t/font_719944_de5cmvrgx4j.css);
/*滚动条*/
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
  background: none;
}
/*滚动条的轨道 内阴影+圆角*/
::-webkit-scrollbar-track-piece {
  background: none;
}
/*滚动条里面的滑块 内阴影+圆角*/
::-webkit-scrollbar-thumb {
  background-color: #ccc;
  border-radius: 1px;
}
</style>
