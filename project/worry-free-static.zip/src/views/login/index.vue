<template>
  <div class="login-container">
    <div class="slogan"><h1></h1></div>
    <el-form autoComplete="on" :model="loginForm" :rules="loginRules" ref="loginForm" label-position="left"
             label-width="0px"
             class="card-box login-form">
      <h3 class="title">登 录</h3>
      <div class="error-msg">{{errorMsg}}</div>
      <el-form-item class="form-input" prop="username">
        <span class="svg-container">
          <i class="iconfont icon-yonghuming" aria-hidden="true"></i>
        </span>
        <el-input name="username" type="text" v-model="loginForm.username" autoComplete="off"
                  @keyup.enter.native="handleLogin"
                  placeholder="用户名"></el-input>
      </el-form-item>
      <el-form-item class="form-input" prop="password">
        <span class="svg-container">
          <i class="iconfont icon-mima" aria-hidden="true"></i>
        </span>
        <el-input name="password" type="password" @keyup.enter.native="handleLogin" v-model="loginForm.password"
                  autoComplete="off" placeholder="密码"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" class="login-btn" :loading="loading" @click.native.prevent="handleLogin">
          登 录
        </el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  export default {
    name: 'login',
    data () {
      const validateUsername = (rule, value, callback) => {
        this.errorMsg = ''
        if (!value) {
          callback(new Error('用户名不能为空'))
        } else {
          callback()
        }
      }
      const validatePass = (rule, value, callback) => {
        this.errorMsg = ''
        if (!value) {
          callback(new Error('密码不能为空'))
        } else {
          callback()
        }
      }
      return {
        loginForm: {
          username: '',
          password: ''
        },
        loginRules: {
          username: [
            {required: true, trigger: 'blur', validator: validateUsername}
          ],
          password: [
            {required: true, trigger: 'blur', validator: validatePass}
          ]
        },
        loading: false,
        showDialog: false,
        errorMsg: ''
      }
    },
    methods: {
      handleLogin () {
        this.$refs.loginForm.validate(valid => {
          if (valid) {
            this.loading = true
            this.$store.dispatch('LoginByUsername', this.loginForm).then(res => {
              this.loading = false
              if (res) {
                this.errorMsg = res
                return false
              }
              // 登录前页面没有就默认跳转到短信管理页面
              let redirect = this.$route.query.redirect
              if (!redirect || redirect === '/' || redirect.indexOf('/login') >= 0) {
                redirect = '/qcm/detail'
              }
              this.$router.push({path: redirect})
            }).catch(err => {
              console.log('error submit!!' + err)
              this.loading = false
            })
          } else {
            console.log('error submit!!')
            return false
          }
        })
      }
    },
    created () {
    },
    destroyed () {
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss">
  @import "src/styles/mixin.scss";

  .login-container {
    @include relative;
    width: 100%;
    height: 400px;
    background: url("../../assets/img/loginbg.png");
    background-size: cover;
    .slogan {
      text-align: center;
      padding-top: 80px;
      h1 {
        /*color: #58B7FF;*/
        height: 55px;
        background: url("../../assets/img/logintitle.png") center center no-repeat;
        -webkit-background-size: 595px 55px;
        background-size: 595px 55px;
      }
    }
    input {
      border: 0px;
      -webkit-appearance: none;
      padding: 5px;
      height: 44px;
    }
    .el-input {
      display: inline-block;
      height: 44px;
      width: 85%;
    }
    .svg-container {
      padding: 6px 5px 6px 15px;
      color: #889aa4;
    }

    .title {
      font-size: 20px;
      font-weight: 400;
      margin: 0 auto;
      text-align: center;
      color: #333;
    }
    .error-msg {
      color: #ff4949;
      font-size: 12px;
      line-height: 22px;
      min-height: 22px;
    }
    .login-form {
      box-shadow: 0 0px 10px 5px rgba(32, 160, 255, 0.4), 0 1px 10px 5px rgba(0, 0, 0, 0.02);
      background-clip: padding-box;
      margin: 80px auto;
      margin-bottom: 0;
      width: 400px;
      padding: 20px 50px;
      background: #fff;
      border: 1px solid #eaeaea;
      border-radius: 4px;
    }

    .form-input {
      border: 1px solid #bfcbd9;
      border-radius: 4px;
      color: #454545;
    }

    .login-btn {
      width: 100%;
      height: 44px;
      font-size: 18px;
      border-radius: 4px;
    }
  }

  /* autocomplete属性 导致输入框背景色变黄 设置内置阴影或autocomplete="off" */
  input:-webkit-autofill,
  textarea:-webkit-autofill,
  select:-webkit-autofill {
    -webkit-box-shadow: 0 0 0 1000px #fff inset;
  }

</style>
