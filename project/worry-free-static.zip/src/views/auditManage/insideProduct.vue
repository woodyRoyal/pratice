<!--定时任务-->
<template>
  <div>
    <el-form :inline="true"  size="mini">
       <!-- <el-form-item label="操作事项类:">
         <el-select v-model="queryForm.operation" clearable>
           <el-option
           v-for="(item,index) in typeList"
           :key="index"
           :value="item.id"
           :label="item.operateTypeName"
           >
           </el-option>
         </el-select>
       </el-form-item>
      <el-form-item label="日期范围" prop="">
        <el-date-picker
            v-model="time"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            value-format="yyyy-MM-dd"
            end-placeholder="结束日期">
          </el-date-picker>
      </el-form-item> -->
      <el-form-item>
        <el-button type="primary" size="small" @click="add">添加产品</el-button>
      </el-form-item>
    </el-form>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row   stripe  :max-height="tableMaxHeight" style="width: 100%">
      <el-table-column
        prop="productId"
        fixed
        label="产品id"
        >
      </el-table-column>

      <el-table-column
        prop="productName"
        label="导流产品名"
      >
      </el-table-column>

      <el-table-column
        prop="logo"
        label="导流产品logo"
        >
        <template slot-scope="scope">
          <div>
            <img :src="scope.row.logo" style="width:90px;height:90px">
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop=""
        label="操作"
      >
      <template slot-scope="scope">
        <el-button type="text" size="mini" @click="edit(scope.row)">编辑</el-button>
        <el-button type="text" size="mini" @click="del(scope.row)">删除</el-button>
      </template>
      </el-table-column>
    </el-table>
    <!-- <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div> -->
    <el-dialog :title="title" size="mini" :visible.sync="addDialog" @close="closeFile">
      <el-form size="mini" :model="addForm" ref='addForm' :rules="addRules">        
        <el-form-item label="导流产品名:"  label-width="130px" prop="productName">
          <el-input v-model="addForm.productName"></el-input>
        </el-form-item>
        <el-form-item label="导流产品LOGO:"  label-width="130px" prop="logo">
          <el-upload class="upload-user-defined" name="in" :auto-upload='false'
                   action="url" :file-list="fileList" :show-file-list="true"
                   :with-credentials="true" ref = "uploadFile"
                   :before-upload="handleUploadBefore" :on-remove="removeLogo"
                   :on-change="handleUploadChange" :disabled="uploading">
              <el-button size="mini" type="primary" :loading="uploading">选择文件
              </el-button>
            </el-upload>
          <span class="font">logo图片尺寸90*90px</span>
        </el-form-item>
        <el-form-item label-width="130px" v-if="isShow">
              <img :src="addForm.logo"  style="width:90px;height:90px;">
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="addDialog = false">取消</el-button>
          <el-button type="primary" @click="submit">确认</el-button>
        </div>
    </el-dialog>
  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'
import insideProductApi from '../../api/insideDiversion/insideProduct.js'
export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      uploading: false,
      fileList: [],
      file: '',
      isShow: false,
      uploadUrl: insideProductApi.URL_UPLOAD,
      phoneList: [
        {key: 1, value: 'Android'},
        {key: 2, value: 'iOS'}
      ],
      addDialog: false,
      addForm: {
        productName: '',
        logo: ''
      },
      addRules: {
        productName: [{ required: true, message: '产品名不能为空', trigger: 'blur' }],
        logo: [{ required: true, message: '产品logo不能为空', trigger: 'blur' }]
        // os: [{ required: true, message: '请选择', trigger: 'change' }]
        // \d+(\.\d+){0,2}
        // /^[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2}$/
      },
      title: '添加',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [10, 50, 100],
        pageSize: 10, // pageSize
        total: 10 // totalRecordNum
      },
      tableData: [
      ],
      listLoading: false
    }
  },
  created () {
    console.log(insideProductApi)
    this.fetchData()
    // this.operateType()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {

  },
  methods: {
    handleClearFiles () {
      this.ARPUfileList = []
      this.file = null
      this.addForm.logo = ''
      this.isShow = false
    },
    // 批量修改-上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
    handleUploadBefore (file) {
      // if (file.name && file.name.length > 0) {
      //   const ldot = file.name.lastIndexOf('.')
      //   const type = file.name.toLowerCase().substring(ldot)
      //   if (type !== '.csv') {
      //     this.$_message.warning('目前只支持.csv格式的文件')
      //     return false
      //   }
      //   this.uploadFileName = file.name
      //   console.log(this.uploadFileName)
      // }

    },
    async handleUploadChange (file, fileList) {
      this.fileList = [file]
      this.file = file.raw
      this.uploading = true
      let param = new window.FormData()
      param.append('file', this.file)
      let res = await insideProductApi.upload(param)
      this.uploading = false
      if (res.data.respCode === '1000') {
        let timestamp = (new Date()).getTime()
        this.isShow = true
        this.addForm.logo = res.data.body + `?temo=${timestamp}`
      } else {
        this.$_message.error(res.data.respMsg)
      }
    },
    removeLogo () {
      this.handleClearFiles()
    },
    closeFile () {
      this.$refs.addForm.resetFields()
      this.$refs.uploadFile && this.$refs.uploadFile.clearFiles()
    },
    async del (row) {
      try {
        let confirm = await this.$confirm(`确认删除该产品？`, '提示', { type: 'warning' })
        if (confirm) {
          let res = await insideProductApi.deleteInnerDiversionProduct(row.productId)
          if (res.data.respCode === '1000') {
            this.$message.success('删除成功')
            this.fetchData()
          } else {
            this.$message.error(res.data.respMsg)
          }
        }
      } catch (error) {
        console.log(error)
      }
    },
    // uploadLogoSuccess (response, file, fileList) {
    //   if (response.respCode === '1000') {
    //     this.addForm.logo = response.body
    //   } else {
    //     this.$message.error(response.respMsg)
    //   }
    // },
    add () {
      this.title = '添加'
      this.isShow = false
      this.addForm = {
        productName: '',
        logo: ''
      }
      this.addDialog = true
    },

    edit (row) {
      this.title = '编辑'
      this.isShow = true
      this.addForm = {
        productId: row.productId,
        logo: row.logo,
        productName: row.productName
      }
      this.addDialog = true
    },
    submit () {
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        try {
          let confirm = await this.$confirm(`确认${this.title}产品?`, '提示', { type: 'warning' })
          if (confirm) {
            let res = await insideProductApi.saveInnerDiversionProduct(this.addForm)
            if (res.data.respCode === '1000') {
              this.fetchData()
              this.addDialog = false
              this.$message.success('操作成功')
            } else {
              this.$message({
                type: 'error',
                message: res.data.respMsg || '操作失败'
              })
            }
          }
        } catch (error) {
          console.log('cancel')
        }
      })
    },
    // async submitAdd () {
    //   let res = await auditApi.saveInnerDiversionProduct(this.addForm)
    //   if (res.data.respCode === '1000') {
    //     this.fetchData()
    //     this.addDialog = false
    //     this.$message.success('操作成功')
    //   } else {
    //     this.$message({
    //       type: 'error',
    //       message: res.data.respMsg || '操作失败'
    //     })
    //   }
    // },
    // async submitEdit () {
    //   let res = await auditApi.appEdit(this.addForm)
    //   if (res.data.respCode === '1000') {
    //     this.fetchData()
    //     this.addDialog = false
    //     this.$message.success('操作成功')
    //   } else {
    //     this.$message({
    //       type: 'error',
    //       message: res.data.respMsg || '操作失败'
    //     })
    //   }
    // },
    async fetchData () {
      let res = await insideProductApi.getInnerDiversionProducts()
      if (res.data.respCode === '1000') {
        this.tableData = res.data.body
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    openAddDialog () {
      this.addDialog = true
    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: '这是一段对标题的说明'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 150
      })
    },
    handleClose () {
      this.$refs.addForm && this.$refs.addForm.resetFields()
    },
    handleSizeChange () {

    },
    handleCurrentChange () {

    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .logoImg {
      display: inline-block;
      width: 90px;
      height: 90px;
      border: 1px dashed #c0ccda;
    }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
