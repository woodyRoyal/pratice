<!--定时任务-->
<template>
  <div>
    <div class="topBox">
      <!-- 父tab -->
      <el-radio-group v-model="bigID" style="margin-top:0px;" size="small" @change="changeTab">
        <el-radio-button :label="item.value" v-for="(item,index) in bigTagList" :key="index">{{item.value}}</el-radio-button>
      </el-radio-group>
    </div>
    <keep-alive>
    <router-view ></router-view>
    </keep-alive>
  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'

export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      permissionList: [],
      bigID: '渠道推广明细',
      allListL: [
        {key: '/audit/auditManage/auditApp', value: 'app包名管理'},
        {key: '/audit/auditManage/audit', value: '过审管理'},
        {key: '/audit/auditManage/android', value: '安卓过审产品管理'},
        {key: '/audit/auditManage/diversion', value: '外部导流管理(旧)'},
        {key: '/audit/auditManage/insideManage', value: '内部导流管理(旧)'},
        {key: '/audit/auditManage/insideProduct', value: '内部导流产品管理(旧)'},
        {key: '/audit/auditManage/auditSwitch', value: '导流开关管理'},
        {key: '/audit/auditManage/auditDocument', value: '导流文案管理'},
        {key: '/audit/auditManage/auditLink', value: '导流链接管理'}
      ],
      bigTagList: [
        // {key: 1, value: '渠道推广明细（按天）'},
        // {key: 2, value: '渠道推广明细（按小时）'}
        // {key: 3, value: '推广支出录入'},
        // {key: 4, value: '渠道质量数据'}
      ]
    }
  },
  created () {
    this.permissionList = this.$store.state.permission.menuPathList
    this.allListL.forEach(t => {
      this.permissionList.forEach(j => {
        if (t.key === j) {
          this.bigTagList.push(t)
        }
      })
    })
    if (this.bigTagList.length === 0) {
      this.$message.error('该模块没有授权页面！')
      this.$router.push({name: '花钱无忧后台'})
    }
    if (this.$route.path === '/audit/auditManage') {
      this.$router.push({name: this.bigTagList[0].value})
    }
    this.bigID = this.$route.name
  },
  mounted () {
  },
  watch: {
    '$route'(){
      this.bigID = this.$route.name
    }
  },
  computed: {
    key () {
      return this.$route.name !== undefined
        ? this.$route.name + +new Date()
        : this.$route + +new Date()
    }
  },
  methods: {
    changeTab (val) {
      this.$router.push({name: this.bigID})
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
