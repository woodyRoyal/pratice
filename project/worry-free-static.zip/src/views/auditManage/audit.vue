<!--定时任务-->
<template>
  <div>
    <!--表格-->
    <el-table v-loading="listLoading"
              :data="tableData"
              border
              fit
              highlight-current-row
              stripe
              :max-height="tableMaxHeight"
              style="width: 100%">
      <el-table-column
        prop="appId"
        sortable
        fixed
        label="appid"
      >
      </el-table-column>

      <el-table-column
        prop="appName"
        label="app名"
      >
      </el-table-column>

      <el-table-column
        prop="channelReview"
        label="需过审处理渠道"
        align="left"
      >
        <template slot-scope="scope">
          <el-row>
            <el-col :push="2"
                    :span="22">
              <span v-html="scope.row.view"></span>
            </el-col>
          </el-row>
        </template>
      </el-table-column>
      <el-table-column
        prop="channelEdition"
        label="过审基准版本"
      >
      </el-table-column>
      
      <el-table-column
        prop=""
        label="操作"
      >
        <template slot-scope="scope">
          <el-button type="text"
                     size="mini"
                     @click="edit(scope.row)">
            编辑
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div> -->
    <el-dialog title="编辑方案"
               size="mini"
               :visible.sync="addDialog"
               @close="handleClose">
      <el-form ref="addForm"
               size="mini"
               :model="addForm"
               :rules="addRules">
        <el-form-item label="app名:"
                      label-width="130px"
                      prop="appName">
          <el-input v-model="addForm.appName"
                    disabled></el-input>
        </el-form-item>
        <el-form-item label="提审需处理渠道:"
                      label-width="130px"
                      prop="channelReview">
          <el-input ref="urlInput" 
                    v-model="addForm.channelReview" 
                    type="textarea"
                    :disabled="!IOS" 
                    :placeholder="isPlaceholder"
                    :maxlength="255"  
                    :autosize="{ minRows: 2, maxRows: 6}"></el-input>
        </el-form-item>
        <el-form-item style="color:red" label=" "  label-width="130px">
          注意事项：【提审需处理渠道】为空时，则表示未过审版本（APP版本>基准版本）的所有渠道均为未过审版的APP。
        </el-form-item>
        <el-form-item label="过审基准版本:"  label-width="130px" prop="channelEdition">
          <el-input v-model="addForm.channelEdition" placeholder="示例：1.1.1"></el-input>
        </el-form-item>
        <el-form-item label="备注:"
                      prop=""
                      label-width="130px">
          <span>已过审：APP版本＜=基准版本。未过审：APP版本＞基准版本。</span>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button type="primary"
                   @click="addDialog = false">
          取消
        </el-button>
        <el-button type="primary"
                   @click="submit">
          确认
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import auditApi from '../../api/auditApi.js'
export default {
  data () {
    return {
      row: {

      },
      phoneList: [
        {key: 1, value: 'Android'},
        {key: 2, value: 'iOS'},
      ],
      addDialog: false,
      addForm: {
        'appName': '',
        'appId': '',
        'channelReview': '',
        'channelEdition': '',
      },
      addRules: {
        // channelReview: [{ message: '请填写', trigger: 'blur' }],
        channelEdition: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              // let lastIndex = value.lastIndexOf('.')
              let length = this.getPlaceholderCount(value)
              if (value === '') {
                callback(new Error('请输入'))
              } else if (/\d+(\.\d+){2}/.test(value) && length === 2) {
                callback()
              } else {
                callback(new Error('过审基准版本格式不对'))
              }
            },
          },
        ],
        // os: [{ required: true, message: '请选择', trigger: 'change' }]
        // \d+(\.\d+){0,2}
        // /^[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2}$/
      },
      title: '添加',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [10, 50, 100],
        pageSize: 10, // pageSize
        total: 10, // totalRecordNum
      },
      tableData: [
      ],
      listLoading: false,
    }
  },
  computed: {
    IOS () {
      if (this.row.os === 'iOS') return false
      return true
    },
    isPlaceholder () {
      if (this.row.os === 'iOS') return ''
      return '每一行视为一个渠道，空行不算'
    },
  },
  created () {
    this.fetchData()
    // this.operateType()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    getPlaceholderCount (strSource) {
      let thisCount = 0
      strSource.replace(/\./g, function (m, i) {
        thisCount++
      })
      return thisCount
    },
    edit (row) {
      this.row = row
      this.title = '编辑'
      let channelReview = null
      if (row.os === 'iOS') {
        channelReview = ''
      } else {
        channelReview = row.channelReview.join('\n')
      }
      this.addForm = {
        appId: row.appId,
        'appName': row.appName,
        'packageName': row.packageName,
        'channelEdition': row.channelEdition,
        channelReview: channelReview,
      }
      this.addDialog = true
    },
    submit () {
      // let arr = []
      // arr = this.addForm.channelReview.split('\n')
      // console.log(arr)
      // console.log(JSON.stringify(this.addForm.channelReview))
      this.$refs['addForm'].validate(async (valid) => {
        if (!valid) {
          return false
        }
        try {
          let confirm = await this.$confirm(`请注意：过审基准版本从${this.row.channelEdition}修改为${this.addForm.channelEdition}`, '提示', { type: 'warning' })
          if (confirm) {
            let data = {
              // appName: this.addForm.appName,
              appId: this.addForm.appId,
              // 'packageName': this.addForm.packageName,
              channelEdition: this.addForm.channelEdition,
              channelReview: this.addForm.channelReview.split('\n'),
            }
            this.channelEdit(data)
          }
        } catch (error) {
          console.log('cancel')
        }
      })
    },
    async channelEdit (data) {
      let res = await auditApi.channelEdit(data)
      if (res.data.respCode === '1000') {
        this.fetchData()
        this.addDialog = false
        this.$message.success('操作成功')
      } else {
        this.$message({
          type: 'error',
          message: res.data.respMsg || '操作失败',
        })
      }
    },
    async fetchData () {
      let res = await auditApi.fetchTableData()
      if (res.data.respCode === '1000') {
        res.data.body.forEach((t) => {
          t.view = t.channelReview.join('<br>')
          if (t.os === 'iOS') {
            t.view = '--'
          }
        })
        this.tableData = res.data.body
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    openAddDialog () {
      this.addDialog = true
    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: '这是一段对标题的说明',
        },
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 150
      })
    },
    handleClose () {
      this.$refs.addForm && this.$refs.addForm.clearValidate()
    },
    handleSizeChange () {

    },
    handleCurrentChange () {

    },
  },
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
