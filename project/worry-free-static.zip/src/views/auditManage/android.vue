<!--定时任务-->
<template>
  <div>
    <el-form size="mini">
      <el-form-item style="margin-bottom:5px;">
        <el-button type="primary"
                   size="small"
                   @click="add">添加产品</el-button>
      </el-form-item>
      <el-form-item style="margin-bottom:5px;">
        <p style="color:red">*为保证顺利过审，请添加至少5款H5全流程的产品</p>
      </el-form-item>
    </el-form>
    <!--表格-->
    <el-table :data="tableData"
              v-loading="listLoading"
              border
              fit
              highlight-current-row
              stripe
              :max-height="tableMaxHeight"
              style="width: 100%">
      <el-table-column prop="productId"
                       fixed
                       width="100px"
                       label="产品id">
      </el-table-column>

      <el-table-column prop="productName"
                       label="产品名称"
                       width="200px">
      </el-table-column>

      <el-table-column prop="productType"
                       width="100px"
                       label="产品类型">
        <template slot-scope="scope">
          {{scope.row.productType===1?'H5':scope.row.productType===2?'非H5':''}}
        </template>
      </el-table-column>

      <el-table-column prop="selectedLink"
                       label="产品链接">
        <template slot-scope="scope">
          {{scope.row.selectedLink.address}}
        </template>
      </el-table-column>

      <el-table-column prop=""
                       label="操作"
                       width="150px">
        <template slot-scope="scope">
          <el-button type="text"
                     size="mini"
                     @click="edit(scope.row)">编辑</el-button>
          <el-button type="text"
                     size="mini"
                     @click="del(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div> -->
    <el-dialog :title="title + '产品'"
               size="mini"
               :visible.sync="addDialog"
               @close="handleClose">
      <el-form size="mini"
               :model="addForm"
               ref='addForm'
               :rules="addRules">
        <el-form-item style="color:red">*请确保该产品在所有产品线均有已上架的链接，若某个产品线的链接已停用或不存在，请重新开启或添加，并设置该链接的UV上限=1，严格控量，且足量后隐藏。（若产品类型为“非H5”，也需确认该产品在所有产品线均有已上架的链接）</el-form-item>
        <el-form-item label="产品id:"
                      label-width="130px"
                      prop="productId">
          <el-input v-model="addForm.productId"
                    @keyup.native.enter="fetchForm()"
                    :disabled="title === '编辑'"></el-input>
        </el-form-item>
        <el-form-item v-if="title === '添加'">
          <span style="padding-left:60px;color:#97a8be">提示:请输入已添加产品的id，输入完成按'enter'键显示对应的产品名称&链接</span>
        </el-form-item>
        <el-form-item label="产品名称:"
                      label-width="130px"
                      prop="productName">
          <el-input v-model="addForm.productName"
                    disabled></el-input>
        </el-form-item>
        <el-form-item label="产品类型"
                      label-width="130px"
                      prop="productType">
          <el-select v-model="addForm.productType"
                     placeholder="请选择">
            <el-option v-for="item in productType"
                       :key="item.value"
                       :label="item.key"
                       :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="产品链接："
                      label-width="130px"
                      prop="seqId"
                      v-if="addForm.productType===1">
          <div v-for="(item, index) in temp"
               :key="index">
            <el-radio :label="item.seqId"
                      v-model="addForm.seqId">
              {{`链接${item.seqId}--${addForm.productName}`}}
              <span style="color:#f56c6c"
                    v-if="item.status===0">【已停用】</span>
              <span style="color:#67c23a"
                    v-else>【已启用】</span>
            </el-radio>
            <div style="line-height: 20px;">{{item.address}}</div>
          </div>
        </el-form-item>
        <el-form-item v-if="addForm.productType===1">
          <div style="padding-left:60px;color:#97a8be">提示:请选择H5全流程的链接</div>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button type="primary"
                   @click="addDialog = false">取消</el-button>
        <el-button type="primary"
                   @click="submit"
                   :disabled="addForm.productId === ''">确认</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'
import androidApi from '../../api/insideDiversion/android.js'
export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      productType: [{ value: 1, key: 'H5' }, { value: 2, key: '非H5' }],
      phoneList: [
        { key: 1, value: 'Android' },
        { key: 2, value: 'iOS' }
      ],
      temp: [],
      addDialog: false,
      addForm: {
        'productName': '百度有钱花',
        'productId': '',
        'address': '',
        'productLine': '',
        'seqId': '',
        operateType: ''
      },
      addRules: {
        productId: [{
          required: true,
          trigger: 'blur',
          validator: (rule, value, callback) => {
            console.log(value)
            if (value === '') {
              callback(new Error("请输入已添加产品的id，输入完成按'enter'键显示对应的产品名称&链接"))
            } else if (/^[0-9]*$/.test(value)) {
              callback()
            } else {
              callback(new Error('产品ID为数字！'))
            }
          }
        }],
        productType: [{ required: true, message: '请选择产品类型', trigger: 'change' }],
        seqId: [{ required: true, message: '请选择H5全流程的链接', trigger: 'blur' }]
        // productName: [{ required: true, message: '产品名不能为空', trigger: 'blur' }]
        // os: [{ required: true, message: '请选择', trigger: 'change' }]
        // \d+(\.\d+){0,2}
        // /^[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2}$/
      },
      title: '添加',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [10, 50, 100],
        pageSize: 10, // pageSize
        total: 10 // totalRecordNum
      },
      tableData: [],
      listLoading: false
    }
  },
  created () {
    this.fetchData()
    // this.operateType()
    console.log(androidApi)
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {

  },
  methods: {
    async fetchForm () {
      let res = await androidApi.getProductInfo(this.addForm.productId, 1)
      if (res.data.respCode === '1000') {
        this.addForm.productName = res.data.body[0].productName
        this.temp = res.data.body[0].allLinks
      } else {
        this.$message.error(res.data.respMsg)
        this.addForm.productName = ''
        this.addForm.seqId = ''
        this.temp = []
      }
    },
    async del (row) {
      try {
        let confirm = await this.$confirm(`确认删除该产品？`, '提示', { type: 'warning' })
        if (confirm) {
          let res = await androidApi.deleteProduct(row.productId)
          if (res.data.respCode === '1000') {
            this.$message.success('删除成功')
            this.fetchData()
          } else {
            this.$message.error(res.data.respMsg)
          }
        }
      } catch (error) {
        console.log(error)
      }
    },
    add () {
      this.title = '添加'
      this.temp = []
      this.addDialog = true
      this.addForm = {
        'productName': '',
        'productId': '',
        'address': '',
        'productLine': '',
        'seqId': '',
        operateType: 1
      }
    },

    async edit (row) {
      this.title = '编辑'
      this.addForm.productId = row.productId
      this.addForm.operateType = 2
      let res = await androidApi.getProductInfo(row.productId, 2)
      if (res.data.respCode === '1000') {
        // this.addForm.productName = res.data.body[0].productName
        this.temp = res.data.body[0].allLinks
        this.addForm.seqId = res.data.body[0].selectedLink.seqId
        this.addForm = {
          ...this.addForm,
          ...res.data.body[0]
        }
      } else {
        this.$message.error(res.data.respMsg)
        this.addForm.productName = ''
        this.addForm.seqId = ''
      }
      this.addDialog = true
    },
    submit () {
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        try {
          let confirm = await this.$confirm(`确认${this.title}该产品?`, '提示', { type: 'warning' })
          if (confirm) {
            if (this.title === '添加') {
              this.submitAdd()
            } else {
              this.submitEdit()
            }
          }
        } catch (error) {
          console.log('cancel')
        }
      })
    },
    async submitAdd () {
      let data = {
        ...this.addForm
      }
      this.temp.forEach(t => {
        if (t.seqId === data.seqId) {
          data.address = t.address
          data.productLine = t.productLine
        }
      })
      let res = await androidApi.addOrUpdateProduct(data)
      if (res.data.respCode === '1000') {
        this.fetchData()
        this.addDialog = false
        this.$message.success('操作成功')
      } else {
        this.$message({
          type: 'error',
          message: res.data.respMsg || '操作失败'
        })
        this.addForm.productName = ''
        this.addForm.seqId = ''
        this.temp = []
      }
    },
    async submitEdit () {
      let data = {
        ...this.addForm
      }
      this.temp.forEach(t => {
        if (t.seqId === data.seqId) {
          data.address = t.address
          data.productLine = t.productLine
        }
      })
      let res = await androidApi.addOrUpdateProduct(data)
      if (res.data.respCode === '1000') {
        this.fetchData()
        this.addDialog = false
        this.$message.success('操作成功')
      } else {
        this.$message({
          type: 'error',
          message: res.data.respMsg || '操作失败'
        })
      }
    },
    async fetchData () {
      let res = await androidApi.getProductInfo('', '')
      if (res.data.respCode === '1000') {
        this.tableData = res.data.body
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    openAddDialog () {
      this.addDialog = true
    },
    renderHeader (createElement, { column }) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: '这是一段对标题的说明'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 150
      })
    },
    handleClose () {
      this.$refs.addForm && this.$refs.addForm.resetFields()
    },
    handleSizeChange () {

    },
    handleCurrentChange () {

    }
  }
}
</script>

<style lang="scss" scoped>
.topBox {
  margin-bottom: 10px;
}
.add-btn {
  margin-bottom: 10px;
}

.el-table {
  .el-input-number--small {
    width: 100px;
  }
}

// td超出省略
.name-wrapper {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
