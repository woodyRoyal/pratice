<!--定时任务-->
<template>
  <div>
    <el-form :inline="true"  size="mini">
       <!-- <el-form-item label="操作事项类:">
         <el-select v-model="queryForm.operation" clearable>
           <el-option
           v-for="(item,index) in typeList"
           :key="index"
           :value="item.id"
           :label="item.operateTypeName"
           >
           </el-option>
         </el-select>
       </el-form-item>
      <el-form-item label="日期范围" prop="">
        <el-date-picker
            v-model="time"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            value-format="yyyy-MM-dd"
            end-placeholder="结束日期">
          </el-date-picker>
      </el-form-item> -->
      <el-form-item>
        <el-button type="primary" size="small" @click="add">添加app</el-button>
      </el-form-item>
    </el-form>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row   stripe  :max-height="tableMaxHeight" style="width: 100%">
      <el-table-column
        prop="appId"
        sortable fixed
        label="appid"
        >
      </el-table-column>

      <el-table-column
        prop="appName"
        label="app名"
      >
      </el-table-column>

      <el-table-column
        prop="packageName"
        label="包名"
        >
      </el-table-column>
      <el-table-column
        prop="os"
        label="系统"
        >
      </el-table-column>
      
      <el-table-column
        prop=""
        label="操作"
      >
      <template slot-scope="scope">
        <el-button type="text" size="mini" @click="edit(scope.row)">编辑</el-button>
      </template>
      </el-table-column>
    </el-table>
    <!-- <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div> -->
    <el-dialog :title="title + 'APP'" size="mini" :visible.sync="addDialog" @close="handleClose">
      <el-form size="mini" :model="addForm" ref='addForm' :rules="addRules">        
        <el-form-item label="app名:"  label-width="130px" prop="appName">
          <el-input v-model="addForm.appName"></el-input>
        </el-form-item>
        <el-form-item label="包名:"  label-width="130px" prop="packageName">
          <el-input  v-model="addForm.packageName"></el-input>
        </el-form-item>
        <el-form-item label="系统:"  label-width="130px" prop="remark">
          <el-select style="width:100%" v-model="addForm.os">
            <el-option
            v-for="(item,index) in phoneList"
            :key="index"
            :value="item.value"
            :label="item.value"
            >
            {{item.value}}
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="addDialog = false">取消</el-button>
          <el-button type="primary" @click="submit">确认</el-button>
        </div>
    </el-dialog>
  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'
import auditApi from '../../api/auditApi.js'
export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      phoneList: [
        {key: 1, value: 'Android'},
        {key: 2, value: 'iOS'}
      ],
      addDialog: false,
      addForm: {
        'appName': '',
        'packageName': '',
        'os': 'Android'
      },
      addRules: {
        appName: [{ required: true, message: 'app名不能为空', trigger: 'blur' }],
        packageName: [{ required: true, message: '包名不能为空', trigger: 'blur' }]
        // os: [{ required: true, message: '请选择', trigger: 'change' }]
        // \d+(\.\d+){0,2}
        // /^[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2}$/
      },
      title: '添加',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [10, 50, 100],
        pageSize: 10, // pageSize
        total: 10 // totalRecordNum
      },
      tableData: [],
      listLoading: false
    }
  },
  created () {
    this.fetchData()
    // this.operateType()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {

  },
  methods: {
    add () {
      this.title = '添加'
      this.addForm = {
        'appName': '',
        'packageName': '',
        'os': 'Android'
      }
      this.addDialog = true
    },

    edit (row) {
      this.title = '编辑'
      this.addForm = {
        appId: row.appId,
        'appName': row.appName,
        'packageName': row.packageName,
        'os': row.os
      }
      this.addDialog = true
    },
    submit () {
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        try {
          let confirm = await this.$confirm(`确认${this.title}app?`, '提示', { type: 'warning' })
          if (confirm) {
            if (this.title === '添加') {
              this.submitAdd()
            } else {
              this.submitEdit()
            }
          }
        } catch (error) {
          console.log('cancel')
        }
      })
    },
    async submitAdd () {
      let res = await auditApi.addApp(this.addForm)
      if (res.data.respCode === '1000') {
        this.fetchData()
        this.addDialog = false
        this.$message.success('操作成功')
      } else {
        this.$message({
          type: 'error',
          message: res.data.respMsg || '操作失败'
        })
      }
    },
    async submitEdit () {
      let res = await auditApi.appEdit(this.addForm)
      if (res.data.respCode === '1000') {
        this.fetchData()
        this.addDialog = false
        this.$message.success('操作成功')
      } else {
        this.$message({
          type: 'error',
          message: res.data.respMsg || '操作失败'
        })
      }
    },
    async fetchData () {
      let res = await auditApi.fetchTableData()
      if (res.data.respCode === '1000') {
        this.tableData = res.data.body
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    openAddDialog () {
      this.addDialog = true
    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: '这是一段对标题的说明'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 150
      })
    },
    handleClose () {
      this.$refs.addForm && this.$refs.addForm.resetFields()
    },
    handleSizeChange () {

    },
    handleCurrentChange () {

    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
