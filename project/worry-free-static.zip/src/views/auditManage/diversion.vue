<template>
  <div class="diversion">
    <el-form :inline="true"  size="mini">
      <el-form-item>
        <el-button type="primary" size="small" @click="add">添加方案</el-button>
      </el-form-item>
    </el-form>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row   stripe  :max-height="tableMaxHeight" style="width: 100%">
      <el-table-column
      prop="id"
      label="appid"
      width="100px"
      >
        <template slot-scope="scope">
          <span v-if="scope.row.hasDefault">默认</span>
          <span v-else>{{scope.row.id}}</span>
        </template>
      </el-table-column>

      <el-table-column
      prop="appName"
      label="app名"
      >
      </el-table-column>

      <el-table-column
      prop="userLevel"
      label="用户资质"
      >
      <template slot-scope="scope">
        <div v-for="(item,index) in scope.row.userLevelArr" :key="index">
          {{ userLevelMap[item]}}
        </div>
      </template>
      </el-table-column>
      <el-table-column
      prop="title"
      label="首页导流文案"
      >
      <template slot-scope="scope">
        <span>{{scope.row.title}}</span>
      </template>
      </el-table-column>
      <el-table-column
      prop="homepageUrl"
      width="300"
      align="left"
      label="首页导流链接"
      >
      <template slot-scope="scope">
          <span>{{scope.row.homepageUrl}}</span>
      </template>
      </el-table-column>
      <el-table-column
      prop="discoverUrl"
      width="300"
      align="left"
      label="发现页链接"
      >
      <template slot-scope="scope">
        <div v-for="(item, index) in scope.row.discoverUrlList" :key="index">
          <span>{{item}}</span>
        </div>
      </template>
      </el-table-column>
      <el-table-column
      label="操作"
      width="80"
      >
      <template slot-scope="scope">
        <el-button type="text" size="mini" @click="edit(scope.row)">编辑</el-button>
        <el-button v-if="!scope.row.hasDefault" type="text" size="mini" @click="openTips(scope.row, tableData)">删除</el-button>
      </template>
      </el-table-column>
    </el-table>
    <!-- <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div> -->
    <el-dialog :title="title + '方案'" size="mini" :visible.sync="addDialog" @close="handleClose" width="50%">
      <el-form size="mini" :model="addForm" ref='addForm' :rules="addRules">        
        <el-form-item label="app名:"  label-width="110px" prop="appName" v-if="!detailObj.hasDefault">
          <el-select v-model="addForm.appName" style="width:100%" clearable filterable multiple>
            <el-option
            v-for="(item,index) in restaurants"
            :key="index"
            :label="item.appName"
            :value="item.appName"            
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="用户资质:"  prop="userLevel" label-width="110px" v-if="!detailObj.hasDefault">
          <!-- <el-radio-group v-model="show" style="width: 100%" @change="check(show)">
            <el-row>
              <el-col :span='8' v-for="(item, index) in aptitudeList" :key="index">
                <el-radio-button :label="item.code" style="100%">{{item.name}}</el-radio-button>
              </el-col>
            </el-row>
          </el-radio-group> -->
          <el-checkbox-group v-model="addForm.userLevel">
            <el-checkbox-button v-for="(item, index) in aptitudeList" :key="index" :label="item.code" >{{item.name}}</el-checkbox-button>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="首页导流文案:"  label-width="110px" prop="title">
          <el-input  v-model="addForm.title"></el-input>
        </el-form-item>
        <el-form-item label="首页导流链接:"  label-width="110px" prop="homepageUrl">
          <el-input  v-model="addForm.homepageUrl"></el-input>
        </el-form-item>
        <el-form-item label="发现页链接:"  label-width="110px" prop="discoverUrl">
          <el-input
            type="textarea"
            :rows="4"
            placeholder="请输入内容"
            v-model="addForm.discoverUrl">
          </el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
          <el-button @click="addDialog = false">取消</el-button>
          <el-button type="primary" @click="submit">确认</el-button>
        </div>
    </el-dialog>
  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'
import diversion from '../../api/diversion.js'
import auditApi from '../../api/auditApi.js'
export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      userLevelMap: {
        1: '资质好',
        2: '资质一般/未知',
        3: '资质差'
      },
      phoneList: [
        {key: 1, value: 'Android'},
        {key: 2, value: 'iOS'}
      ],
      addDialog: false,
      textarea: '',
      aptitudeList: [
        {
          name: '资质差',
          code: 3
        },
        {
          name: '资质一般/未知',
          code: 2
        },
        {
          name: '资质好',
          code: 1
        }
      ],
      addForm: {
        'appName': [],
        userLevel: [],
        'discoverUrl': '',
        'title': '',
        'homepageUrl': ''
      },
      addRules: {
        appName: [
          {
            required: true,
            trigger: 'change',
            validator: (rule, value, callback) => {
              if (this.addForm.appName.length < 1) {
                callback(new Error('请选择app名'))
              } else {
                callback()
              }
            }
          }
        ],
        userLevel: [
          {
            required: true,
            trigger: 'change',
            validator: (rule, value, callback) => {
              if (this.addForm.userLevel.length < 1) {
                callback(new Error('请选择'))
              } else {
                callback()
              }
            }
          }
        ]
        // discoverUrl: [{ required: true, message: '不能为空', trigger: 'change' }],
        // title: [{ required: true, message: '不能为空', trigger: 'change' }],
        // homepageUrl: [{ required: true, message: '不能为空', trigger: 'change' }]

        // \d+(\.\d+){0,2}
        // /^[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2}$/
      },
      title: '添加',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [10, 50, 100],
        pageSize: 10, // pageSize
        total: 10 // totalRecordNum
      },
      tableData: [],
      listLoading: false,
      restaurants: [],
      itemObj: {},
      detailObj: {}
    }
  },
  created () {
    // this.operateType()
  },
  mounted () {
    this.handleResize()
    this.getDataList()
    window.addEventListener('resize', this.handleResize)
    this.loadAll()
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {

  },
  methods: {
    trimSpace (str, isGlobal) {
      let result
      result = str.replace(/(^\s+)|(\s+$)/g, '')
      if (isGlobal.toLowerCase() === 'g') {
        result = result.replace(/\s/g, '')
      }
      return result
    },
    bouncer (arr) {
      // Don't show a false ID to this bouncer.
      return arr.filter(function (val) {
        return !(!val || val === '')
      })
    },
    transfer (val) {
    },
    openTips (index, rows) {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        let params = {
          id: index.id
        }
        diversion.deleteData(params).then(res => {
          this.getDataList()
        }).catch(error => {
          console.log(error)
        })
        this.$message({
          type: 'success',
          message: '删除成功!'
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    getDataList () {
      diversion.getDataList().then(res => {
        res.data.body.forEach(val => {
          val.discoverUrlList = val.discoverUrl.split(',')
          val.userLevelArr = val.userLevel.split(',')
        })
        this.tableData = res.data.body
      }).catch(error => {
        console.log(error)
      })
    },
    add () {
      this.title = '添加'
      this.detailObj = ''
      this.addForm = {
        'appName': [],
        userLevel: [],
        'discoverUrl': '',
        'title': '',
        'homepageUrl': ''
      }
      this.addDialog = true
      this.$nextTick(() => {
        this.$refs.addForm && this.$refs.addForm.clearValidate()
      })
    },
    edit (row) {
      this.title = '编辑'
      this.detailObj = row
      this.addForm = {
        userLevel: row.userLevel.split(',').map(Number),
        'discoverUrl': row.discoverUrl.replace(/,/g, '\n'),
        'homepageUrl': row.homepageUrl,
        'title': row.title,
        'appName': row.appName.split(',')
      }
      this.addDialog = true
    },
    submit () {
      let NameList = []
      NameList = this.addForm.discoverUrl.split('\n')
      NameList = NameList.map((v) => {
        return this.trimSpace(v, 'g')
      })
      NameList = this.bouncer(NameList)
      NameList = NameList.join(',')
      let os = []
      let packageName = []
      this.restaurants.forEach(t => {
        this.addForm.appName.forEach(v => {
          if (v === t.appName) {
            os.push(t.os)
            packageName.push(t.packageName)
          }
        })
      })
      let params = {
        appName: this.addForm.appName.join(','),
        packageName: packageName.join(','),
        os: os.join(','),
        discoverUrl: NameList,
        title: this.addForm.title,
        homepageUrl: this.addForm.homepageUrl,
        userLevel: this.addForm.userLevel.join(','),
        operatorId: this.$store.state.loginUser.userId
      }
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        try {
          let confirm = await this.$confirm(`确认${this.title}方案?`, '提示', { type: 'warning' })
          if (confirm) {
            if (this.title === '添加') {
              diversion.editData(params).then(res => {
                if (res.data.respCode === '1000') {
                  this.addDialog = false
                  this.$message({
                    type: 'success',
                    message: '添加成功!'
                  })
                  this.getDataList()
                } else {
                  this.$message.error(res.data.respMsg)
                }
              }).catch(error => {
                console.log(error + '11111')
              })
            } else {
              params.id = this.detailObj.id
              diversion.editData(params).then(res => {
                if (res.data.respCode === '1000') {
                  this.addDialog = false
                  this.$message({
                    type: 'success',
                    message: '添加成功!'
                  })
                  this.getDataList()
                } else {
                  this.$message.error(res.data.respMsg)
                }
              }).catch(error => {
                console.log(error)
              })
            }
          }
        } catch (error) {
          console.log('cancel')
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 150
      })
    },
    handleClose () {
      this.$refs.addForm && this.$refs.addForm.resetFields()
    },
    handleSizeChange () {

    },
    handleCurrentChange () {

    },
    querySearch (queryString, cb) {
      let restaurants = this.restaurants
      let results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants
      // 调用 callback 返回建议列表的数据
      cb(results)
    },
    createFilter (queryString) {
      return (restaurant) => {
        console.log(restaurant.name + '111')
        return (restaurant.value.indexOf(queryString.toLowerCase()) === 0)
      }
    },
    async loadAll () {
      let res = await auditApi.fetchTableData()
      if (res.data.respCode === '1000') {
        let newArr = []
        res.data.body.forEach(val => {
          newArr.push({'value': val.appName, ...val})
        })
        this.restaurants = newArr
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    handleSelect (item) {
      this.itemObj = item
    },
    check (i) {
      this.disabled.firstText = false
      this.disabled.firstHref = false
      if (i === 1) {
        // this.addForm.homepageUrl = ''
        // this.addForm.title = ''
        this.disabled.firstText = true
        this.disabled.firstHref = true
      } else if (this.title === '编辑') {
        this.addForm.homepageUrl = this.detailObj.homepageUrl
        this.addForm.title = this.detailObj.title
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }
  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .el-autocomplete {
    width: 100%;
  }
</style>