<template>
  <div >
    <el-form :inline="true"  size="mini">
      <el-form-item>
        <el-button type="primary" size="small" @click="add">添加方案</el-button>
      </el-form-item>
    </el-form>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row   stripe  :max-height="tableMaxHeight" style="width: 100%">
      <el-table-column
      prop="id"
      label="方案ID"
      width="100px"
      >
        <template slot-scope="scope">
          <span v-if="scope.row.hasDefault">{{scope.$index === 0? '发现页默认方案' : '非发现页默认方案'}}</span>
          <span v-else v-bind:class="{ toGrey: scope.row.colorGrey }">{{scope.row.id}}</span>
        </template>
      </el-table-column>

      <el-table-column
      prop="appName"
      label="app名"
      >
      <template slot-scope="scope">
          <span v-if="scope.row.hasDefault">--</span>
          
          <span v-else v-bind:class="{ toGrey: scope.row.colorGrey }">{{scope.row.appName}}</span>
        </template>
      </el-table-column>
      <el-table-column
      prop="diversionLocation"
      label="导流位"
      >
      <template slot-scope="scope">
          <div v-if="scope.row.hasDefault">--</div>
          <div v-if="!scope.row.hasDefault&&scope.row.diversionLocationArr.length !== 1" v-bind:class="{ toGrey: scope.row.colorGrey }"> <span v-for="(item,index) in scope.row.diversionLocationArr">{{index === scope.row.diversionLocationArr.length -1?diversionLocationMap[item] :diversionLocationMap[item] + `,`}}</span></div>
          <div v-if="!scope.row.hasDefault&&scope.row.diversionLocationArr.length === 1" v-bind:class="{ toGrey: scope.row.colorGrey }"> <span v-for="item in scope.row.diversionLocationArr">{{diversionLocationMap[item]}}</span></div>
        </template>
      </el-table-column>
      <el-table-column
      prop="riskLevel"
      label="风控等级"
      >
      <template slot-scope="scope">
          <span v-if="scope.row.hasDefault">--</span>
          <span v-else v-bind:class="{ toGrey: scope.row.colorGrey }">{{scope.row.riskLevelStr}}</span>
      </template>
      </el-table-column>
      <el-table-column
      prop="productList"
      label="导流产品"
      align="left"
      width="620"
      >
      <template slot-scope="scope">
        <div v-for="(item, index) in scope.row.productList" :key="index">
          <span v-bind:class="{ toGrey: scope.row.colorGrey }">{{item.productName}}</span> &nbsp
          <span v-bind:class="{ toGrey: scope.row.colorGrey }">{{item.linkType}}</span>&nbsp
          <span v-bind:class="{ toGrey: scope.row.colorGrey }">{{item.address}}</span>&nbsp
          <span v-bind:class="{ toGrey: scope.row.colorGrey }">{{item.averagePrice}}</span>
        </div>
      </template>
      </el-table-column>
      <el-table-column
      prop="effectiveTime"
      width="250"
      label="生效时间"
      >
      <template slot-scope="scope">
        <div v-if="scope.row.hasDefault"> -- </div>
        <template v-if="!scope.row.hasDefault">
        <div v-for="(item, index) in scope.row.timeArr" :key="index" v-bind:class="{ toGrey: scope.row.colorGrey }">{{item}}</div>
        </template>
      </template>
      </el-table-column>
      <el-table-column
      label="操作"
      width="80"
      >
      <template slot-scope="scope">
        <el-button type="text" size="mini" @click="edit(scope.row)">编辑</el-button>
        <el-button v-if="!scope.row.hasDefault" type="text" size="mini" @click="openTips(scope.row, tableData)">删除</el-button>
      </template>
      </el-table-column>
    </el-table>
    <!-- <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div> -->
    <el-dialog :title="title + '方案'" size="mini" :visible.sync="addDialog" @close="handleClose" width="50%" :close-on-press-escape="false" :close-on-click-modal="false">
      <el-form size="mini" :model="addForm" ref='addForm' :rules="addRules" label-width="110px">        
        <el-form-item label="app名:"  label-width="110px" prop="appName" v-if="!detailObj.hasDefault">
          <el-select v-model="addForm.appName" style="width:100%" clearable filterable multiple placeholder="app来自于app管理页面">
            <el-option
            v-for="(item,index) in restaurants"
            :key="index"
            :label="item.appName"
            :value="item.appName"            
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="导流位:"  prop="diversionLocation" label-width="110px" v-if="!detailObj.hasDefault" >
            <el-checkbox-group v-model="addForm.diversionLocation">
            <el-checkbox-button v-for="(item, index) in diversionLocationList" :key="index" :label="item.limitValue" >{{item.limitName}}</el-checkbox-button>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="风控等级:" prop="riskLevel" label-width="110px" v-if="!detailObj.hasDefault">
          <!-- <checkButton :list="checkList"  @_getvalue="getValue" :default="addForm.riskLevel"></checkButton> -->
          <el-checkbox-group v-model="addForm.riskLevel">
            <el-checkbox-button v-for="(item, index) in checkList" :key="index" :label="item.limitValue" >{{item.limitName}}</el-checkbox-button>
          </el-checkbox-group>
        </el-form-item>
        <div style="width:100%;">
            <div class="line"></div>
        </div>
       <div v-for="(item,index) in addForm.productList" :key="index">
        <el-form-item label="产品id:"   :prop="'productList.' + index + '.productId'" :rules="[{ required:true, validator:checkId, trigger: 'blur' }]">
          <el-input v-model="item.productId" @keyup.native.enter="fetchForm(index,item)" :controls="false" :disabled="title === '编辑' && item.disabled"></el-input>
        </el-form-item>
        <el-form-item v-if="title === '添加'">
          <span style="padding-left:60px;color:#97a8be">提示:请输入已添加产品的id，输入完成按'enter'键显示对应的产品名称&链接</span>
        </el-form-item>
        <el-form-item label="产品名称:" :prop="'productList.' + index + '.productName'" :rules="[{ required:true, message:'不能为空', trigger: 'blur' }]">
          <el-input  v-model="item.productName" disabled></el-input>
        </el-form-item>
          <el-form-item label="产品链接："  :prop="'productList.' +index + '.linkSeqId'" :rules="[{ required:true, message:'请输入', trigger: 'blur' }]">
                <div v-for="(itemChild, indexChild) in temp[index]" :key="indexChild + '.temp'">
                  <el-radio  :label="itemChild.linkSeqId" v-model="item.linkSeqId">
                    {{`链接${itemChild.linkSeqId}--${itemChild.linkType}`}}
                    <!-- <div style="line-height: 20px;">{{item.address}}</div> -->
                  </el-radio>
                  <div style="line-height: 20px;" :key="'address.' + indexChild">{{itemChild.address}}</div>
                </div>
        </el-form-item>
        <el-form-item label="排序:"  :prop="'productList.' + index + '.productSeqId'" :rules="[{ required:true, validator:checkId, trigger: 'blur' }]">
          <el-input  v-model="item.productSeqId"></el-input>
        </el-form-item>
        <el-form-item label="" >
          <el-button type="text" size="small" @click="addPro(item,index)" v-if="index === addForm.productList.length -1">
            新增产品
        </el-button>
        <el-button type="text" size="small"  @click="delPro(item,index)" v-if="addForm.productList.length > 1">
          删除产品
        </el-button>
        </el-form-item>
        <div style="width:100%;">
            <div class="line"></div>
        </div>
         </div>
        <el-form-item v-if="!detailObj.hasDefault" label="生效时间:" v-for="(item,index) in addForm.time" :key="'time' + index" :prop="'time.' + index + '.time'" :rules="[{ required:true, validator:checkTime, trigger: 'blur' }]">
          <el-date-picker
            size="mini"
            v-model="item.time"
            type="datetimerange"
            range-separator="至"
            start-placeholder="开始时间"
            value-format="yyyy-MM-dd HH:mm:ss"
            :default-time="['00:00:00', '23:59:59']"
            end-placeholder="结束时间">
          </el-date-picker>
          <el-button size="mini" @click="addItem(item,index)" v-if="index === addForm.time.length -1">
            +
          </el-button>
          <el-button size="mini"  @click="delItem(item,index)" v-if="addForm.time.length > 1">
            -
          </el-button>
       </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
          <el-button @click="addDialog = false">取消</el-button>
          <el-button type="primary" @click="submit">确认</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import VueElTooltip from '../../../components/VueElTooltip'
import auditApi from '../../../api/auditApi.js'
import insideManageApi from '../../../api/insideDiversion/insideManage.js'
import auditLinkApi from '../../../api/newAudit/auditLink.js'
import checkButton from '../components/checkButton'
export default {
  components: {
    VueElTooltip,
    checkButton
  },
  data () {
    let checkId = (rule, value, callback) => {
      console.log(value)
      if (value === '') {
        callback(new Error('请输入数字~'))
      } else if (/^[0-9]*$/.test(value)) {
        callback()
      } else {
        callback(new Error('请输入数字~'))
      }
    }
    let checkTime = (rule, value, callback) => {
      if (value && value.length > 0) {
        callback()
      } else {
        callback(new Error('请选择'))
      }
    }
    return {
      checkId: checkId,
      checkTime: checkTime,
      delIds: [],
      proList: {
        1: '花钱无忧',
        2: '贷款王',
        3: '导流平台'
      },
      diversionLocationMap: {
        1: '首页',
        2: '发现页',
        3: '借款成功',
        4: '借款被拒',
        5: '已借款未逾期',
        6: '还款成功',
        7: '首页弹窗'
      },
      phoneList: [
        {key: 1, value: 'Android'},
        {key: 2, value: 'iOS'}
      ],
      addDialog: false,
      textarea: '',
      show: 3,
      diversionLocationList: [
        {limitValue: 1, limitName: '首页'},
        {limitValue: 2, limitName: '发现页'},
        {limitValue: 3, limitName: '借款成功'},
        {limitValue: 4, limitName: '借款被拒'},
        {limitValue: 6, limitName: '还款成功'},
        {limitValue: 7, limitName: '首页弹窗'}
      ],
      checkList: [
        {limitValue: '0', limitName: '无'},
        {limitValue: 'A', limitName: 'A'},
        {limitValue: 'B', limitName: 'B'},
        {limitValue: 'C', limitName: 'C'},
        {limitValue: 'D', limitName: 'D'},
        {limitValue: 'E', limitName: 'E'},
        {limitValue: 'Z', limitName: 'Z'}
      ],
      aptitudeList: [
        {
          name: '资质差',
          code: 3
        },
        {
          name: '资质一般/未知',
          code: 2
        },
        {
          name: '资质好',
          code: 1
        }
      ],
      addForm: {
        diversionLocation: [],
        appName: '',
        linkUrl: '',
        os: '',
        packageName: '',
        riskLevel: [],
        time: [
          {
            time: []
          }
        ],
        productList: [
          {
            'address': '',
            'linkType': '',
            'productExtendId': '',
            productId: '',
            productName: '',
            'linkSeqId': '',
            productSeqId: ''
          }
        ]
      },
      addRules: {
        appName: [
          {
            required: true,
            trigger: 'change',
            validator: (rule, value, callback) => {
              if (this.addForm.appName.length < 1) {
                callback(new Error('请选择app名'))
              } else {
                callback()
              }
            }
          }
        ],
        // discoverUrl: [{ required: true, message: '不能为空', trigger: 'change' }],
        diversionLocation: [{
          required: true,
          trigger: 'blur',
          validator: (rule, value, callback) => {
            if (this.addForm.diversionLocation.length < 1) {
              callback(new Error('请选择导流位'))
            } else {
              callback()
            }
          }
        }],
        riskLevel: [{
          required: true,
          trigger: 'blur',
          validator: (rule, value, callback) => {
            if (this.addForm.riskLevel.length < 1) {
              callback(new Error('请选择风控等级'))
            } else {
              callback()
            }
          }
        }],
        title: [{ required: true, message: '导流文案不能为空', trigger: 'blur' }],
        linkUrl: [{ required: true, message: '导流链接不能为空', trigger: 'blur' }],
        productName: [{
          required: true,
          trigger: 'change',
          validator: (rule, value, callback) => {
            let NameList = this.addForm.linkUrl.split('\n')
            NameList = NameList.map((v) => {
              return this.trimSpace(v, 'g')
            })
            NameList = this.bouncer(NameList)
            if (this.addForm.productName.length < 1) {
              callback(new Error('请添加导流产品'))
            } else if (this.addForm.productName.length !== NameList.length) {
              callback(new Error('导流链接的数量必须和导流产品的数量一致'))
              this.$message.error('导流链接的数量必须和导流产品的数量一致')
            } else {
              callback()
            }
          }
        }]
        // title: [{ required: true, message: '不能为空', trigger: 'change' }],
        // title: [{ required: true, message: '不能为空', trigger: 'change' }],
        // title: [{ required: true, message: '不能为空', trigger: 'change' }]
      },
      title: '添加',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [10, 50, 100],
        pageSize: 10, // pageSize
        total: 10 // totalRecordNum
      },
      tableData: [
      ],
      temp: [],
      listLoading: false,
      restaurants: [],
      itemObj: {},
      detailObj: {}
    }
  },
  created () {
    this.fetchProductList()
    console.log(insideManageApi)
    // this.operateType()
  },
  mounted () {
    this.handleResize()
    this.getDataList()
    window.addEventListener('resize', this.handleResize)
    this.loadAll()
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {

  },
  methods: {
    async fetchForm (index, item) {
      let id = this.title === '编辑' ? this.addForm.id : ''
      let ids = this.addForm.productList.map(v => {
        return Number(v.productId)
      })
      let nary = ids.sort()

      for (let i = 0; i < ids.length; i++) {
        if (nary[i] === nary[i + 1]) {
          this.$message.error(`该方案下存在相同产品`)
          return
        }
      }
      // if (count > 0) {
      //   return this.$message.error('该方案下存在相同产品！')
      // }
      let res = await auditLinkApi.getProductInfo(this.addForm.productList[index].productId, id)
      if (res.data.respCode === '1000') {
        this.addForm.productList[index].productName = res.data.body.productName
        let temp = JSON.parse(JSON.stringify(this.temp))
        temp[index] = res.data.body.allLinks
        this.temp = JSON.parse(JSON.stringify(temp))
        // this.temp = [...temp]
        console.log(3, this.temp)
      } else {
        this.$message.error(res.data.respMsg)
        this.addForm.productList[index].productName = ''
      }
    },
    addPro () {
      this.addForm.productList.push({
        'address': '',
        'linkType': '',
        'productExtendId': '',
        productId: '',
        productName: '',
        'linkSeqId': '',
        productSeqId: ''
      })
    },
    delPro (item, index) {
      if (this.title === '编辑') {
        this.delIds.push(item.productId)
      }
      this.addForm.productList.splice(index, 1)
      this.temp.splice(index, 1)
    },
    getDiversionLocation (val) {
      this.addForm.diversionLocation = val
    },
    addItem () {
      this.addForm.time.push({
        time: []
      })
    },
    delItem (item, index) {
      this.addForm.time.splice(index, 1)
    },
    delProductName (index) {
      this.addForm.productName.splice(index, 1)
    },
    addProductName () {
      this.miniDialog.show = true
    },
    getValue (value) {
      this.addForm.riskLevel = value
    },
    trimSpace (str, isGlobal) {
      let result
      result = str.replace(/(^\s+)|(\s+$)/g, '')
      if (isGlobal.toLowerCase() === 'g') {
        result = result.replace(/\s/g, '')
      }
      return result
    },
    bouncer (arr) {
      // Don't show a false ID to this bouncer.
      return arr.filter(function (val) {
        return !(!val || val === '')
      })
    },
    transfer (val) {
    },
    async openTips (row) {
      try {
        let confirm = await this.$confirm(`确认删除该方案？`, '提示', { type: 'warning' })
        if (confirm) {
          let res = await auditLinkApi.delete(row.id)
          if (res.data.respCode === '1000') {
            this.$message.success('删除成功')
            this.getDataList()
          } else {
            this.$message.error(res.data.respMsg)
          }
        }
      } catch (error) {
        console.log(error)
      }
    },
    async getDataList () {
      let res = await auditLinkApi.getAll()
      if (res.data.respCode === '1000') {
        res.data.body.forEach(t => {
          t.riskLevelStr = t.riskLevel.replace(/0/g, '无')
          t.diversionLocationArr = t.diversionLocation.split(',')
          t.diversionLocationArr = t.diversionLocationArr.map(Number)
          t.timeArr = t.effectiveTime.split(',')
          if (t.effectiveTime !== '' && t.effectiveTime) {
            let time = [{time: []}]
            for (let i = 0; i < t.timeArr.length; i++) {
              time[i] = t.timeArr[i].split('~')
            }
            for (let i = 0; i < time.length; i++) {
              for (let j = 0; j < time[i].length; j++) {
                time[i][j] = time[i][j].substring(0, 19)
                time[i][j] = time[i][j].replace(/-/g, '/')
                time[i][j] = new Date(time[i][j]).getTime()
              }
            }
            let timestamp = new Date().getTime()
            t.colorGrey = true
            time.forEach((v, i) => {
              if (timestamp > v[0] && timestamp < v[1]) {
                t.colorGrey = false
              }
            })
          }
        })
        this.tableData = res.data.body
      } else {
        this.$_messsage.error(res.data.respMsg)
      }
    },
    add () {
      this.temp = []
      this.title = '添加'
      this.detailObj = {}
      this.addForm = {
        id: null,
        hasDefault: 0,
        diversionLocation: [],
        appName: [],
        linkUrl: '',
        os: '',
        packageName: '',
        riskLevel: [],
        time: [
          {
            time: []
          }
        ],
        productList: [
          {
            'address': '',
            'linkType': '',
            'productExtendId': '',
            productId: '',
            productName: '',
            'linkSeqId': '',
            productSeqId: ''
          }
        ]
      }
      this.addDialog = true
      this.$nextTick(() => {
        this.$refs.addForm && this.$refs.addForm.clearValidate()
      })
    },
    async fetchTemp (row) {
      this.temp = []
      let res = await auditLinkApi.getLinkById(row.id)
      if (res.data.respCode === '1000') {
        res.data.body.productList.forEach(t => {
          if (t.allLinks) {
            this.temp.push(t.allLinks)
          }
        })
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    edit (row) {
      this.temp = []
      this.fetchTemp(row)
      this.title = '编辑'
      this.delIds = []
      this.detailObj = row
      let time = [{time: []}]
      if (row.effectiveTime) {
        for (let i = 0; i < row.timeArr.length; i++) {
          time[i] = {time: row.timeArr[i].split('~')}
        }
      }
      let diversionLocation = []
      if (row.hasDefault === 0) {
        diversionLocation = row.diversionLocation.split(',')
        diversionLocation = diversionLocation.map(Number)
      } else {
        diversionLocation = []
      }
      let productList = []
      if (!row.productList.length) {
        productList = [
          {
            'address': '',
            'linkType': '',
            'productExtendId': '',
            productId: '',
            productName: '',
            'linkSeqId': '',
            productSeqId: ''
          }
        ]
      } else {
        productList = JSON.parse(JSON.stringify(row.productList))
      }
      productList.forEach(t => {
        t.disabled = true
      })

      this.addForm = {
        id: row.id,
        hasDefault: row.hasDefault,
        diversionLocation: diversionLocation,
        appName: row.hasDefault === 0 ? row.appName.split(',') : [],
        linkUrl: '',
        os: '',
        packageName: '',
        riskLevel: row.hasDefault === 0 ? row.riskLevel.split(',') : [],
        time: time,
        productList: productList
      }
      console.log(productList)
      this.addDialog = true
    },
    submit () {
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        try {
          let confirm = await this.$confirm(`确认提交操作吗？`, '提示', { type: 'warning' })
          if (confirm) {
            if (this.title === '添加') {
              this.fetchAdd()
            } else {
              this.fetchEdit()
            }
          }
        } catch (error) {
          console.log(error)
        }
      })
    },
    async fetchAdd () {
      let os = []
      let packageName = []
      this.restaurants.forEach(t => {
        this.addForm.appName.forEach(v => {
          if (v === t.appName) {
            os.push(t.os)
            packageName.push(t.packageName)
          }
        })
      })
      let effectiveTime = []
      this.addForm.time.forEach(t => {
        t.Str = t.time.join('~')
      })
      this.addForm.time.forEach((v, i) => {
        effectiveTime.push(v.Str)
      })
      effectiveTime = effectiveTime.join(',')
      this.addForm.productList.forEach((v, i) => {
        this.temp[i].forEach((value, index) => {
          if (v.linkSeqId === value.linkSeqId) {
            v.address = value.address
            v.linkType = value.linkType
            v.productExtendId = value.productExtendId
          }
        })
      })
      let params = {
        hasDefault: this.addForm.hasDefault,
        appName: this.addForm.appName.join(','),
        packageName: packageName.join(','),
        os: os.join(','),
        diversionLocation: this.addForm.diversionLocation.join(','),
        riskLevel: this.addForm.riskLevel ? this.addForm.riskLevel.join(',') : '',
        operatorId: this.$store.state.loginUser.userId,
        effectiveTime: effectiveTime,
        productList: this.addForm.productList
      }
      let res = await auditLinkApi.saveOrUpdate(params)
      if (res.data.respCode === '1000') {
        this.$message.success('操作成功')
        this.getDataList()
        this.addDialog = false
      } else {
        this.$_messsage.error(res.data.respMsg)
      }
    },
    async fetchEdit () {
      let params = {

      }
      this.addForm.productList.forEach((v, i) => {
        this.temp[i].forEach((value, index) => {
          if (v.linkSeqId === value.linkSeqId) {
            v.address = value.address
            v.linkType = value.linkType
            v.productExtendId = value.productExtendId
          }
        })
      })
      if (!this.detailObj.hasDefault) {
        let os = []
        let packageName = []
        this.restaurants.forEach(t => {
          this.addForm.appName.forEach(v => {
            if (v === t.appName) {
              os.push(t.os)
              packageName.push(t.packageName)
            }
          })
        })
        let effectiveTime = []
        this.addForm.time.forEach(t => {
          t.Str = t.time.join('~')
        })

        this.addForm.time.forEach((v, i) => {
          effectiveTime.push(v.Str)
        })
        effectiveTime = effectiveTime.join(',')
        params = {
          id: this.addForm.id,
          hasDefault: this.addForm.hasDefault,
          appName: this.addForm.appName.join(','),
          packageName: packageName.join(','),
          os: os.join(','),
          diversionLocation: this.addForm.diversionLocation.join(','),
          riskLevel: this.addForm.riskLevel ? this.addForm.riskLevel.join(',') : '',
          operatorId: this.$store.state.loginUser.userId,
          effectiveTime: effectiveTime,
          productList: this.addForm.productList,
          deletedProductIds: this.delIds.length === 0 ? [] : this.delIds
        }
      }
      if (this.detailObj.hasDefault) {
        params = {
          id: this.addForm.id,
          hasDefault: this.addForm.hasDefault,
          operatorId: this.$store.state.loginUser.userId,
          productList: this.addForm.productList,
          deletedProductIds: this.delIds.length === 0 ? [] : this.delIds
        }
      }
      let res = await auditLinkApi.saveOrUpdate(params)
      if (res.data.respCode === '1000') {
        this.$message.success('操作成功')
        this.getDataList()
        this.addDialog = false
      } else {
        this.$_messsage.error(res.data.respMsg)
      }
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 150
      })
    },
    handleClose () {
      this.$refs.addForm && this.$refs.addForm.resetFields()
    },
    handleMinClose () {
      this.$refs.minForm && this.$refs.minForm.resetFields()
    },
    handleSizeChange () {

    },
    handleCurrentChange () {

    },
    querySearch (queryString, cb) {
      let restaurants = this.restaurants
      let results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants
      // 调用 callback 返回建议列表的数据
      cb(results)
    },
    createFilter (queryString) {
      return (restaurant) => {
        return (restaurant.value.indexOf(queryString.toLowerCase()) === 0)
      }
    },
    async fetchProductList () {
      let res = await insideManageApi.getInnerDiversionProducts()
      if (res.data.respCode === '1000') {
        this.productNameList = res.data.body
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    async loadAll () {
      let res = await auditApi.fetchTableData()
      if (res.data.respCode === '1000') {
        let newArr = []
        res.data.body.forEach(val => {
          newArr.push({'value': val.appName, ...val})
        })
        this.restaurants = newArr
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    handleSelect (item) {
      this.itemObj = item
    },
    check (i) {
      this.disabled.firstText = false
      this.disabled.firstHref = false
      if (i === 1) {
        this.addForm.homepageUrl = ''
        this.addForm.title = ''
        this.disabled.firstText = true
        this.disabled.firstHref = true
      } else if (this.title === '编辑') {
        this.addForm.homepageUrl = this.detailObj.homepageUrl
        this.addForm.title = this.detailObj.title
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.line {
      width: 98%;
      height: 2px; 
      margin-left: 10px;
      background: #667c99;
      margin-bottom:10px;
    }
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }
  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .el-autocomplete {
    width: 100%;
  }
  .toGrey{
    color:rgb(151, 168, 190)
  }
</style>