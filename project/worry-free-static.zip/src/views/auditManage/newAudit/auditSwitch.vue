<template>
  <div >
    <el-form :inline="true"  size="mini">
      <el-form-item>
        <el-button type="primary" size="small" @click="add">添加方案</el-button>
        <span class="topText">提示: 命中以下方案的情况不进行导流</span>
      </el-form-item>
    </el-form>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row   stripe  :max-height="tableMaxHeight" style="width: 100%">
      <el-table-column
      prop="id"
      label="方案ID"
      width="100px"
      >
        <template slot-scope="scope">
          <span>{{scope.row.id}}</span>
        </template>
      </el-table-column>

      <el-table-column
      prop="appName"
      label="app名"
      >
      <template slot-scope="scope">
          <span>{{scope.row.appName}}</span>
        </template>
      </el-table-column>
      <el-table-column
      prop="diversionLocation"
      label="导流位"
      >
      <template slot-scope="scope">
          <div v-if="!scope.row.hasDefault&&scope.row.diversionLocationArr.length !== 1" v-bind:class="{ toGrey: scope.row.colorGrey }"> <span v-for="(item,index) in scope.row.diversionLocationArr">{{index === scope.row.diversionLocationArr.length -1?diversionLocationMap[item] :diversionLocationMap[item] + `,`}}</span></div>
          <div v-if="!scope.row.hasDefault&&scope.row.diversionLocationArr.length === 1" v-bind:class="{ toGrey: scope.row.colorGrey }"> <span v-for="item in scope.row.diversionLocationArr">{{diversionLocationMap[item]}}</span></div>
        </template>
      </el-table-column>
      <el-table-column
      prop="riskLevel"
      label="风控等级"
      >
      <template slot-scope="scope">
          <span>{{scope.row.riskLevelStr}}</span>
      </template>
      </el-table-column>
      <el-table-column
      label="操作"
      >
      <template slot-scope="scope">
        <el-button type="text" size="mini" @click="edit(scope.row)">编辑</el-button>
        <el-button type="text" size="mini" @click="openTips(scope.row, tableData)">删除</el-button>
      </template>
      </el-table-column>
    </el-table>
    <!-- <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div> -->
    <el-dialog :title="title + '方案'" size="mini" :visible.sync="addDialog" @close="handleClose" width="50%" :close-on-press-escape="false" :close-on-click-modal="false">
      <el-form size="mini" :model="addForm" ref='addForm' :rules="addRules">        
        <el-form-item label="app名:"  label-width="110px" prop="appName">
          <el-select v-model="addForm.appName" style="width:100%" clearable filterable multiple laceholder="app来自于app管理页面">
            <el-option
            v-for="(item,index) in restaurants"
            :key="index"
            :label="item.appName"
            :value="item.appName"            
            >
            </el-option>
          </el-select>
          <!-- <el-autocomplete
            class="inline-input"
            v-model="addForm.appName"
            :fetch-suggestions="querySearch"
            placeholder="app来自于app管理页面"
            @select="handleSelect"
            >
            <el-button slot="append" icon="el-icon-search"></el-button>
          </el-autocomplete> -->
        </el-form-item>
        <el-form-item label="导流位:"  prop="diversionLocation" label-width="110px" v-if="!detailObj.hasDefault" >
            <el-checkbox-group v-model="addForm.diversionLocation">
            <el-checkbox-button v-for="(item, index) in diversionLocationList" :key="index" :label="item.limitValue" >{{item.limitName}}</el-checkbox-button>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="风控等级:" prop="riskLevel" label-width="110px" v-if="!detailObj.hasDefault">
          <el-checkbox-group v-model="addForm.riskLevel">
            <el-checkbox-button v-for="(item, index) in checkList" :key="index" :label="item.limitValue" >{{item.limitName}}</el-checkbox-button>
          </el-checkbox-group>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
          <el-button @click="addDialog = false">取消</el-button>
          <el-button type="primary" @click="submit">确认</el-button>
        </div>
    </el-dialog>
  </div>
</template>

<script>
import VueElTooltip from '../../../components/VueElTooltip'
import auditApi from '../../../api/auditApi.js'
import auditSwitchApi from '../../../api/newAudit/auditSwitch.js'
// import insideManageApi from '../../../api/insideDiversion/insideManage.js'
import checkButton from '../components/checkButton'
export default {
  components: {
    VueElTooltip,
    checkButton
  },
  data () {
    return {
      diversionLocationMap: {
        1: '首页',
        2: '发现页',
        3: '借款成功',
        4: '借款被拒',
        5: '已借款未逾期首页',
        6: '还款成功',
        7: '首页弹窗'
      },
      disabled: {
        firstText: false,
        firstHref: false
      },
      phoneList: [
        {key: 1, value: 'Android'},
        {key: 2, value: 'iOS'}
      ],
      addDialog: false,
      textarea: '',
      show: 3,
      diversionLocationList: [
        {limitValue: 1, limitName: '首页'},
        {limitValue: 2, limitName: '发现页'},
        {limitValue: 3, limitName: '借款成功'},
        {limitValue: 4, limitName: '借款被拒'},
        {limitValue: 6, limitName: '还款成功'},
        {limitValue: 7, limitName: '首页弹窗'}
      ],
      checkList: [
        {limitValue: '0', limitName: '无'},
        {limitValue: 'A', limitName: 'A'},
        {limitValue: 'B', limitName: 'B'},
        {limitValue: 'C', limitName: 'C'},
        {limitValue: 'D', limitName: 'D'},
        {limitValue: 'E', limitName: 'E'},
        {limitValue: 'Z', limitName: 'Z'}
      ],
      aptitudeList: [
        {
          name: '资质差',
          code: 3
        },
        {
          name: '资质一般/未知',
          code: 2
        },
        {
          name: '资质好',
          code: 1
        }
      ],
      addForm: {
        diversionLocation: [],
        appName: [],
        riskLevel: []
      },
      addRules: {
        appName: [
          {
            required: true,
            trigger: 'change',
            validator: (rule, value, callback) => {
              if (this.addForm.appName.length < 1) {
                callback(new Error('请选择app名'))
              } else {
                callback()
              }
            }
          }
        ],
        diversionLocation: [{
          required: true,
          trigger: 'blur',
          validator: (rule, value, callback) => {
            if (this.addForm.diversionLocation.length < 1) {
              callback(new Error('请选择导流位'))
            } else {
              callback()
            }
          }
        }],
        riskLevel: [{
          required: true,
          trigger: 'blur',
          validator: (rule, value, callback) => {
            if (this.addForm.riskLevel.length < 1) {
              callback(new Error('请选择风控等级'))
            } else {
              callback()
            }
          }
        }]
      },
      title: '添加',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [10, 50, 100],
        pageSize: 10, // pageSize
        total: 10 // totalRecordNum
      },
      tableData: [

      ],
      listLoading: false,
      restaurants: [],
      productNameList: [
        {
          'productId': 48862,
          'productName': '11111'
        },
        {
          'productId': 48862,
          'productName': '222222'
        },
        {
          'productId': 48862,
          'productName': '33333'
        }
      ],
      itemObj: {},
      detailObj: {}
    }
  },
  created () {
    console.log(auditSwitchApi)
    // this.operateType()
  },
  mounted () {
    this.handleResize()
    this.getDataList()
    window.addEventListener('resize', this.handleResize)
    this.loadAll()
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {

  },
  methods: {
    getDiversionLocation (val) {
      this.addForm.diversionLocation = val
    },
    getValue (value) {
      this.addForm.riskLevel = value
    },
    trimSpace (str, isGlobal) {
      let result
      result = str.replace(/(^\s+)|(\s+$)/g, '')
      if (isGlobal.toLowerCase() === 'g') {
        result = result.replace(/\s/g, '')
      }
      return result
    },
    bouncer (arr) {
      // Don't show a false ID to this bouncer.
      return arr.filter(function (val) {
        return !(!val || val === '')
      })
    },
    async openTips (row) {
      try {
        let confirm = await this.$confirm(`确认删除该方案？`, '提示', { type: 'warning' })
        if (confirm) {
          let res = await auditSwitchApi.deleteDiversionSwitchById(row.id)
          if (res.data.respCode === '1000') {
            this.$message.success('删除成功')
            this.getDataList()
          } else {
            this.$message.error(res.data.respMsg)
          }
        }
      } catch (error) {
        console.log(error)
      }
    },
    async getDataList () {
      let res = await auditSwitchApi.getAll()
      if (res.data.respCode === '1000') {
        res.data.body.forEach(t => {
          t.riskLevelStr = t.riskLevel.replace(/0/g, '无')
          t.diversionLocationArr = t.diversionLocation.split(',')
          t.diversionLocationArr = t.diversionLocationArr.map(Number)
        })
        this.tableData = res.data.body
      } else {
        this.$_messsage.error(res.data.respMsg)
      }
    },
    // getDataList () {
    //   insideManageApi.getInsideDiversions().then(res => {
    //     res.data.body.forEach(val => {
    //       val.discoverUrlList = val.discoverUrl.split(',')
    //     })
    //     this.tableData = res.data.body
    //   }).catch(error => {
    //     console.log(error)
    //   })
    // },
    add () {
      this.title = '添加'
      this.detailObj = ''
      this.addForm = {
        appName: [],
        riskLevel: [],
        diversionLocation: []
      }
      this.addDialog = true
      this.$nextTick(() => {
        this.$refs.addForm && this.$refs.addForm.clearValidate()
      })
    },
    edit (row) {
      let diversionLocation = row.diversionLocation.split(',')
      diversionLocation = diversionLocation.map(Number)
      this.title = '编辑'
      this.detailObj = row
      this.addForm = {
        id: row.id,
        diversionLocation: diversionLocation,
        appName: row.appName.split(','),
        riskLevel: row.riskLevel ? row.riskLevel.split(',') : []
      }
      this.addDialog = true
    },
    submit () {
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        try {
          let confirm = await this.$confirm(`确认提交操作吗？`, '提示', { type: 'warning' })
          if (confirm) {
            let os = []
            let packageName = []
            this.restaurants.forEach(t => {
              this.addForm.appName.forEach(v => {
                if (v === t.appName) {
                  os.push(t.os)
                  packageName.push(t.packageName)
                }
              })
            })
            let params = {
              id: this.addForm.id ? this.addForm.id : null,
              appName: this.addForm.appName.join(','),
              packageName: packageName.join(','),
              os: os.join(','),
              diversionLocation: this.addForm.diversionLocation.join(','),
              riskLevel: this.addForm.riskLevel ? this.addForm.riskLevel.join(',') : '',
              operatorId: this.$store.state.loginUser.userId
            }
            let res = await auditSwitchApi.saveOrUpdateDiversionSwitch(params)
            if (res.data.respCode === '1000') {
              this.$message.success('操作成功')
              this.getDataList()
              this.addDialog = false
            } else {
              this.$_messsage.error(res.data.respMsg)
            }
          }
        } catch (error) {
          console.log(error)
        }
      })
    },
    submitMinForm () {
      this.$refs['minForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        this.addForm.productName.push(this.miniDialog.minForm.productName)
        this.miniDialog.show = false
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 150
      })
    },
    handleClose () {
      this.$refs.addForm && this.$refs.addForm.resetFields()
    },
    handleMinClose () {
      this.$refs.minForm && this.$refs.minForm.resetFields()
    },
    handleSizeChange () {

    },
    handleCurrentChange () {

    },
    querySearch (queryString, cb) {
      let restaurants = this.restaurants
      let results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants
      // 调用 callback 返回建议列表的数据
      cb(results)
    },
    createFilter (queryString) {
      return (restaurant) => {
        return (restaurant.value.indexOf(queryString.toLowerCase()) === 0)
      }
    },
    async loadAll () {
      let res = await auditApi.fetchTableData()
      if (res.data.respCode === '1000') {
        let newArr = []
        res.data.body.forEach(val => {
          newArr.push({'value': val.appName, ...val})
        })
        this.restaurants = newArr
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    handleSelect (item) {
      this.itemObj = item
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }
  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .el-autocomplete {
    width: 100%;
  }
  .topText{
    margin-left:60px;
    color:gray
  }
</style>