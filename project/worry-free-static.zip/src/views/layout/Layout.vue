<template>
  <div class="container">
    <!-- <navbar></navbar> -->
    <sidebar></sidebar>
    <app-main></app-main>
  </div>
</template>

<script>
  import { Navbar, Sidebar, AppMain } from 'views/layout'

  export default {
    name: 'layout',
    components: {
      Navbar,
      Sidebar,
      AppMain
    },
    computed: {}
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
  @import "src/styles/mixin.scss";

  .container {
    position: absolute;
    top: 0px;
    bottom: 0px;
    width: 100%;
  }
</style>
