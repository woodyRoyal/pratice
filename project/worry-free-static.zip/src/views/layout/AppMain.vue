<template>
  <main class="content-container" :class="!sidebar.opened ? 'left-collapsed' : 'left-expanded'">
    <span class="el-breadcrumb__item">
        <span class="el-breadcrumb__inner" style="font-size:14px;">位置：</span>
      </span>
    <breadcrumb class="breadcrumb-container"> </breadcrumb>
    <div class="user-info">
      <a title="退出" @click="logout">[退出]</a>
      <span>{{displayName}}</span>
    </div>
    <div class="boundary"> </div>
    <transition name="fade" mode="out-in">
      <router-view></router-view>
    </transition>
  </main>
</template>

<script>
  import { mapGetters } from 'vuex'
  import Breadcrumb from 'components/Breadcrumb'
  import { UCENTER_LOGIN_URL } from 'api/login'
  export default {
    name: 'AppMain',
    components: {
      Breadcrumb
    },
    computed: {
      ...mapGetters([
        'sidebar',
        'displayName'
      ]),
      key () {
        return this.$route.name !== undefined
          ? this.$route.name + +new Date()
          : this.$route + +new Date()
      }
    },
    data () {
      return {
        levelList: null
      }
    },
    mounted () {
      this.getBreadcrumb()
    },
    methods: {
      logout () {
        this.$store.dispatch('FilterLogout').then((val) => {
          if (val) {
            console.log('logout error!!!' + val)
            this.$message.warning(val)
          } else {
            // 返回到登录页
            window.location.href = UCENTER_LOGIN_URL
          }
        })
      },
      getBreadcrumb () {
        let matched = this.$route.matched.filter(item => item.name)
        const first = matched[0]
        if (first && first.name !== '花钱无忧后台') {
          matched = [ {path: '/home/index', name: '花钱无忧后台'} ].concat(matched)
        }
        this.levelList = []
        matched.forEach(t => {
          if (t.name !== '产品管理模块' && t.name !== 'APP管理模块' && t.name !== '过审&导流平台模块') {
            this.levelList.push(t)
          }
        })
      }
    }
  }
</script>

<style lang="scss">
  .content-container {
    position: absolute;
    height: calc(100% - 0px);
    overflow: auto;
    background: #fff;
    flex: 1;
    padding: 2px 10px 0px 10px;
  }

  .left-collapsed {
    left: 50px;
    width: calc(100% - 50px);
  }

  .left-expanded {
    left: 180px;
    width: calc(100% - 180px);
  }
  .boundary{
    color: #303133;
    border-bottom: 3px solid #e9e9e9;
    margin-bottom:5px;
  }
  // .breadcrumb-container{
  //   float: left;
  // }
  /*右侧登录用户信息*/
    .user-info {
      /*width: 160px;*/
      position: absolute;
      top:-4px;
      right: 2px;
      height: 40px;
      font-size: 12px;
      color: #bfcbd9;
      line-height: 40px;
      padding-right: 10px;
      display: flex;
      flex-direction: row-reverse;
      span {
        padding: 0 10px;
      }
      a {
        color: #95A5B4;
        &:hover {
          color: #20a0ff;
        }
      }
    }
</style>
