/**
* Created by zuo on 2017/9/14.
*/

<template>
  <!--没有添加的路由-->
  <!-- <div v-if="!addRouters.length" class="home-content">
    <p>您好，{{ displayName }}，欢迎使用{{currentSysName}}。</p>
    <p>您的账号未分配角色，请企业微信联系叶庆平。</p>
  </div> -->
  <!--有添加的路由-->
  <div class="home-content">
    <p>您好，{{ displayName }}，欢迎使用花钱无忧后台。</p>
    <p>使用过程中有任何问题，请企业微信联系相关工作人员。</p>
  </div>
</template>

<script type="text/ecmascript-6">
  import packageConfig from 'package'
  import { mapGetters } from 'vuex'

  export default {
    data () {
      return {
        currentSysName: packageConfig.sysname, // 当前系统名称
        version: packageConfig.version // 当前系统名称
      }
    },
    computed: {
      ...mapGetters([
        'addRouters',
        'displayName',
        'username',
        'token'
      ])
    },
    mounted () {
      // this.refreshLoad()
    },
    methods: {
      refreshLoad () {
        this.$store.dispatch('RefreshLoad').then(res => {
          console.log('home/index refresh loaded login...')
        }).catch(err => {
          console.log(err)
        })
      }
    }
  }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  .home-content {
    margin: 0 auto;
    color: #99A9BF;
    width: 100%;
    position: relative;
    top: 30%;
    font-size: 20px;
    text-align: center;
  }
</style>
