<template>

  <aside class="sidebar-container" :class="!sidebar.opened ? 'menu-collapsed' : 'menu-expanded'">
    <div class="logo" :class="!sidebar.opened ? 'logo-collapse-width' : 'logo-width'">
      <img class="logo-img-title" src="../../assets/img/slogan.png" v-if="sidebar.opened"
           @click="gotoUcenter"/>
      <img class="logo-img" src="../../assets/img/logo.png" v-else
           @click="gotoUcenter"/>
    </div>
    <!--导航菜单-->
    <!-- background-color="#545c64"
             text-color="#fff"
             active-text-color="#ffd04b" -->
    <el-menu :default-active="defaultActive" mode="vertical" class="expanded-menu" 
             @open="handleopen" @close="handleclose" @select="handleselect" background-color="#545c64" text-color="#fff" active-text-color="#ffd04b"
             unique-opened router v-show="sidebar.opened">

      <template v-for="(item, index) in permissionRouters" v-if="!item.hidden">
        <el-submenu :index="item.name" v-if="!item.noDropdown&&item.children&&!item.children.children">
          <!-- <el-submenu :index="item.name" v-if="!item.noDropdown">
          </el-submenu> -->
          <template slot="title">
            <i :class="item.icon" aria-hidden="true"></i>
            {{item.name}}
          </template>
            <el-submenu v-for="(child,index) in item.children"  :index="child.name"  v-if="item.noDropdown && child.children" :key="index">
                <template slot="title">
                <i :class="child.icon" aria-hidden="true"></i>
                {{child.name}}
                </template>
                <!-- @dblclick.native="openUrl(item.path + '/' + child.path)" -->
                <el-menu-item class="submenu-user-defined" v-for="threeChild in child.children"
                            :index="item.path + '/' + child.path + '/' + threeChild.path" :key="threeChild.path"
                            v-if="!threeChild.hidden && !threeChild.children">
                  {{threeChild.name}}
                </el-menu-item>
            </el-submenu>
            <!-- @dblclick.native="openUrl(item.path + '/' + child.path,$event)" --> 
            <el-menu-item class="submenu-user-defined" v-for="child in item.children"
                        :index="item.path + '/' + child.path" :key="child.path"
                        v-if="!child.hidden && child.noDropdown" >
            <i :class="child.icon" aria-hidden="true"></i>
            {{child.name}}
          </el-menu-item>
        </el-submenu>
        <el-menu-item v-if="item.noDropdown && item.children.length > 0"
                      :index="item.path + '/' + item.children[0].path">
          <i :class="item.children[0].icon" aria-hidden="true"></i>
          {{item.children[0].name}}
        </el-menu-item>
      </template>

    </el-menu>
    <!--导航菜单-折叠后-->
    <ul class="el-menu collapsed" v-show="!sidebar.opened" ref="menuCollapsed">
      <li v-for="(item, index) in permissionRouters" v-if="!item.hidden" class="el-submenu item">
        <template v-if="!item.noDropdown">
          <div class="el-submenu__title" @mouseover="showMenu(index, true)" @mouseout="showMenu(index, false)">
            <i :class="item.icon" aria-hidden="true"></i>
          </div>
          <ul class="el-menu submenu" :class="'submenu-hook-'+index" @mouseover="showMenu(index, true)"
              @mouseout="showMenu(index, false)">
            <li v-for="child in item.children" v-if="!child.hidden" :key="child.path" class="el-menu-item"
                :class="{'is-active' : $route.path == item.path + '/' + child.path}"
                @click="$router.push(item.path + '/' + child.path)">
              {{child.name}}
            </li>
          </ul>
        </template>
        <template v-else>
          <div class="el-menu el-submenu" @mouseover="showMenu(index, true)" @mouseout="showMenu(index, false)">
            <div class="el-submenu__title el-menu-item" :class="{'is-active' :$route.path == item.children[0].path}"
                 @click="$router.push(item.path + '/' + item.children[0].path)">
              <i :class="item.children[0].icon" aria-hidden="true"></i>
            </div>
            <ul class="el-menu submenu" :class="'submenu-hook-'+index" @mouseover="showMenu(index, true)"
                @mouseout="showMenu(index, false)">
              <li class="el-menu-item"
                  :class="{'is-active' : $route.path == item.path + '/' + item.children[0].path}"
                  @click="$router.push(item.path + '/' + item.children[0].path)">
                {{item.children[0].name}}
              </li>
            </ul>
          </div>
        </template>
      </li>
    </ul>
    <div class="toggle-menu-collapsed" :title="sidebar.opened ? '收起':'展开'">
      <a @click="toggleSideBar" :class="[sidebar.opened ? 'menu-expanded':'menu-collapsed']">
        <i class="iconfont" :class="[sidebar.opened ? 'icon-jiantou-left':'icon-jiantou-right']"></i>
      </a>
    </div>
  </aside>
</template>

<script>
  import { mapGetters } from 'vuex'

  export default {
    name: 'Sidebar',
    data () {
      return {
        ctrl: false
      }
    },
    computed: {
      defaultActive () {
        if (this.$route.meta.active) return this.$route.meta.active
        else return this.$route.path
      },
      ...mapGetters([
        'sidebar',
        'permissionRouters'
      ])
    },
    methods: {
      openUrl (item, $event) {
        console.log($event)
      },
      hasOneShowingChildren (children) {
        const showingChildren = children.filter(item => {
          return !item.hidden
        })
        if (showingChildren.length === 1) {
          return true
        }
        return false
      },
      onSubmit () {
        console.log('submit!')
      },
      handleopen () {
        // console.log('handleopen');
      },
      handleclose () {
        // console.log('handleclose');
      },
      handleselect: function (a, b) {
      },
      showMenu (i, status) {
        this.$refs.menuCollapsed.getElementsByClassName('submenu-hook-' + i)[0].style.display = status ? 'block' : 'none'
      },
      toggleSideBar () {
        this.$store.dispatch('ToggleSideBar')
      },
      gotoUcenter () {
        window.location.href = process.env.UCENTER_API
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
/*左侧logo*/
    .logo {
      background-color: #545c64;
      cursor: pointer;
      height: 40px;
      .logo-img-title {
        margin: 8px 24px;
      }
      .logo-img {
        margin: 8px 12px;
      }
    }
    /*长*/
    .logo-width {
      width: 179px;
    }
    /*短*/
    .logo-collapse-width {
      width: 50px
    }
  .sidebar-container {
    position: absolute;
    width: 180px;
    height: calc(100% - 40px);
    .iconfont {
      margin-right: 10px;
      font-size: 18px;
    }
    .expanded-menu {
      width: auto !important;
      overflow-y: auto !important;
    }
    .el-menu {
      // background: #545c64;
      height: calc(100% - 40px);
      border-radius: 0;
      .el-submenu .el-menu-item {
        min-width: 0;
      }
      .el-menu-item, .el-submenu__title {
        height: 50px;
        line-height: 50px;
      }
    }
    .collapsed {
      width: 50px;
      .item {
        position: relative;
      }
      .submenu {
        position: absolute;
        top: 0px;
        left: 50px;
        z-index: 99999;
        height: auto;
        display: none;
      }
    }
    .el-menu-item, .el-submenu__title {
      padding: 0 16px;
    }
    .el-submenu {
      background: none;
    }
    .submenu-user-defined {
      // padding-left: 35px !important;
    }
  }

  .menu-collapsed {
    width: 50px;
  }

  .menu-expanded a{
    width: 179px;
  }

  .toggle-menu-collapsed a {
    position: fixed;
    bottom: 0;
    left: 0;
    font-size: 13px;
    height: 40px;
    text-align: center;
    line-height: 40px;
    transition-duration: .3s;
    outline: none;
    color: #e4e8f1;
    background: #545c64;
    .iconfont {
      margin: 0;
    }
  }

  /*滚动条整体部分 定义滚动条高宽及背景*/
  ::-webkit-scrollbar {
    width: 6px;
    height: 8px;
    background: none;
  }

  /*!*滚动条的轨道 内阴影+圆角*!*/
  ::-webkit-scrollbar-track-piece {
    background: none;
  }

  /*!*滚动条里面的滑块 内阴影+圆角*!*/
  ::-webkit-scrollbar-thumb {
    background-color: #8492A6;
    border-radius: 1px;
  }
</style>
