export default {
  userTypeDetail:[
    {
      key: 2,
      name: '芝麻分贷类用户登录后第N天',
    },
    {
      key: 3,
      name: '身份证贷类用户登录后第N天',
    },
    {
      key: 4,
      name: '大额分期类用户登录后第N天',
    },
    {
      key: 5,
      name: '公积金贷类用户登录后第N天',
    },
    {
      key: 10,
      name: '用户首次登录后第N天',
    },
    {
      key: 20,
      name: '距离上次启动APP后N天未首次登录',
    },
  ],
  userTypeList: [
    {
      key: 1,
      name: '全部用户',
      disable: false,
    },
    {
      key: 2,
      name: '筛选用户',
      disable: false,
    },
    {
      key: 3,
      name: '用户类型',
      disable: false,
    },
    {
      key: 4,
      name: '导入',
      disable: false,
    },
  ],
  userTypeMap: {
    1: '全部用户',
    2: '筛选用户',
    3: '用户类型',
    4: '导入用户',
  },
  afterList: [
    {
      key: 1,
      name: '启动APP',
    },
    {
      key: 2,
      name: '内部浏览',
    },
    {
      key: 3,
      name: '外部浏览',
    },
    {
      key: 4,
      name: 'APP页面',
    },
  ],
  afterMap: {
    1: '启动APP',
    2: '内部浏览',
    3: '外部浏览',
    4: 'APP页面',
  },
  appType: [
    {
      key: 'product',
      name: '指定产品',
      pageType: 2,
    },
    {
      key: 'JRCS_SY',
      name: '首页',
      pageType: 1,
    },
    {
      key: 'JRCS_SYFLCPLB',
      name: '首页分类产品列表',
      pageType: 1,
    },
    {
      key: 'JRCS_DKDQ',
      name: '贷款大全',
      pageType: 1,
    },
    {
      key: 'JRCS_CNKD',
      name: '猜你可贷',
      pageType: 1,
    },
    {
      key: 'JRCS_WD',
      name: '我的',
      pageType: 1,
    },
    {
      key: 'JRCS_WDYHQ',
      name: '我的-优惠券',
      pageType: 1,
    },
    {
      key: 'JRCS_WDWSDKXX',
      name: '我的-完善贷款信息',
      pageType: 1,
    },
    {
      key: 'JRCS_XYK',
      name: '信用卡',
      pageType: 1,
    },
    {
      key: 'JRCS_ZNTJ',
      name: '智能推荐',
      pageType: 1,
    },
  ],
  CAREER_LIST :[
    {'limitName': '工薪族', 'limitValue': 0},
    {'limitName': '企业主', 'limitValue': 1},
    {'limitName': '自由职业', 'limitValue': 3},
    {'limitName': '其他', 'limitValue': 2},
  ],
}
