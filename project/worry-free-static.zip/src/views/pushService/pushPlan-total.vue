<template>
  <div>
    <el-tabs v-model="queryForm.productLine"
             @tab-click="changePro">
      <el-tab-pane label="花钱无忧"
                   name="1">
      </el-tab-pane>
      <el-tab-pane label="贷款王"
                   name="2">
      </el-tab-pane>
      <el-tab-pane label="立即借"
                   name="5">
      </el-tab-pane>
    </el-tabs>
    <el-form :inline="true"
             :model="queryForm"
             size="mini"
             class="margin-mini">
      <el-form-item label="推送计划名称:">
        <el-input v-model="queryForm.planName"></el-input>
      </el-form-item>
      <el-form-item label="推送时间:">
        <el-date-picker
          v-model="queryForm.pushTime"
          size="mini"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          value-format="yyyy-MM-dd"
          end-placeholder="结束日期">
        </el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button type="primary"
                   size="mini"
                   @click="fetchData()">
          查询
        </el-button>
        <el-button type="primary"
                   size="mini"
                   @click="reset()">
          重置
        </el-button>
        <el-button type="primary"
                   size="mini"
                   @click="down()">
          导出
        </el-button>
      </el-form-item>
    </el-form>
    <el-table :data="tableData"
              stripe
              border
              width="100%"
              :loading="loading">
      <el-table-column prop="execTime"
                       label="推送时间">
        <template slot-scope="scope">
          {{ scope.row.execTime | parseTime }}
        </template>
      </el-table-column>
      <el-table-column label="推送计划"
                       prop="planName">
        <template slot-scope="scope">
          <span class="btnText"
                @click="push(scope.row,false)">{{ scope.row.planName }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作系统"
                       prop="os">
        <template slot-scope="scope">
          {{ osList[`${scope.row.os}`] }}
        </template>
      </el-table-column>
      <el-table-column label="推送状态"
                       prop="currentValue">
        <template slot-scope="scope">
          {{ returnStatus(scope.row.execTime,scope.row.endTime) }}
        </template>
      </el-table-column>
      <el-table-column label="计划人数(人)"
                       prop="totalCount">
      </el-table-column>
      <el-table-column label="实际应发人数(去重后)"
                       prop="actualCount">
      </el-table-column>
      <el-table-column label="推送至第三方人数"
                       prop="thirdCount">
      </el-table-column>
      <el-table-column label="第三方下发人数(人)"
                       prop="issueCount">
      </el-table-column>
      <el-table-column label="到达量"
                       prop="arrivalCount">
      </el-table-column>
      <el-table-column label="到达率"
                       prop="">
        <template slot-scope="scope">
          {{ GetPercent(scope.row.arrivalCount,scope.row.issueCount) }}
        </template>
      </el-table-column>
      <el-table-column label="点击量"
                       prop="clickCount">
      </el-table-column>
      <el-table-column label="点击率"
                       prop="">
        <template slot-scope="scope">
          {{ GetPercent(scope.row.clickCount,scope.row.arrivalCount) }}
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination-container">
      <el-pagination :current-page.sync="pagination.pageNum"
                     :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange">
      </el-pagination>
    </div>
  </div>
</template>
<script>
import api from '../../api/app7.1/pushCount'
export default {
  components: {

  },
  data () {
    return {
      osList: {
        1: 'android',
        2: 'ios',
        3: 'pc',
        4: 'h5',
        5: '其他',
      },
      loading: false,
      queryForm: {
        planName: '',
        pushTime: [],
        productLine: '1',
      },
      activeName: '1',
      tableData: [],
      pagination: {
        pageNum: 1,
        pageSize: 30,
        total: 0,
        pageSizes: [10, 30, 50, 100],
      },
    }
  },
  created () {
    if (this.$route.query.productLine) {
      this.queryForm.productLine = this.$route.query.productLine + ''
    }
    this.fetchData()
  },
  methods: {
    push (val, type) {
      this.$router.push({name: '推送配置', params: {planCode: val.planCode, edit: type}})
    },
    returnStatus (s, d) {
      // s === d ? return '推送中' : return'推送完成'
      if (s === d) {
        return '推送中'
      } else {
        return '推送完成'
      }
    },
    GetPercent (num, total) {
    /// <summary>
    /// 求百分比
    /// </summary>
    /// <param name="num">当前数</param>
    /// <param name="total">总数</param>
      num = parseFloat(num)
      total = parseFloat(total)
      if (isNaN(num) || isNaN(total)) {
        return '-'
      }
      return total <= 0 ? '0%' : (Math.round(num / total * 10000) / 100.00) + '%'
    },
    changePro () {
      this.pagination.pageNum = 1
      this.fetchData()
    },
    async fetchData () {
      this.loading = true
      let time = this.queryForm.pushTime ? this.queryForm.pushTime : []
      let data = {
        ...this.queryForm,
        pushTime: time.length === 2 ? time[0] + '~' + time[1] : '',
        pageNum: this.pagination.pageNum,
        pageSize: this.pagination.pageSize,
      }
      let res = await api.query(data)
      this.loading = false
      if (res.data.respCode === '1000') {
        this.tableData = res.data.body.list
        this.pagination.total = res.data.body.total
      }
    },
    reset () {
      this.queryForm.planName = ''
      this.queryForm.pushTime = []
      // this.queryForm = {
      //   planName: '',
      //   pushTime: [],
      //   productLine: '1'

      // }
      this.fetchData()
    },
    down () {
      let pushTime = this.queryForm.pushTime && this.queryForm.pushTime.length === 2 ? this.queryForm.pushTime[0] + '~' + this.queryForm.pushTime[1] : ''
      window.location.href = process.env.BASE_API +
      `/pushCount/exportData?productLine=${this.queryForm.productLine}&pushTime=${pushTime}&planName=${this.queryForm.planName}&planType=1`
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNum = val
      this.fetchData()
    },
  },
}
</script>