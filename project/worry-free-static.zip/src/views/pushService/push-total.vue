<template>
  <div>
    <el-tabs v-model="searchForm.productLine"
             @tab-click="fetchData">
      <el-tab-pane label="花钱无忧"
                   name="1">
      </el-tab-pane>
      <el-tab-pane label="贷款王"
                   name="2">
      </el-tab-pane>
      <el-tab-pane label="立即借"
                   name="5">
      </el-tab-pane>
    </el-tabs>
    <el-form :inline="true"
             :model="searchForm"
             size="mini"
             class="margin-mini">
      <el-form-item label="推送时间:">
        <el-date-picker
          v-model="searchForm.pushTime"
          size="mini"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          value-format="yyyy-MM-dd"
          end-placeholder="结束日期">
        </el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button type="primary"
                   size="mini"
                   @click="fetchData()">
          查询
        </el-button>
        <el-button type="primary"
                   size="mini"
                   @click="reset()">
          重置
        </el-button>
        <el-button type="primary"
                   size="mini"
                   @click="down()">
          导出
        </el-button>
      </el-form-item>
    </el-form>
    <el-table :data="tableData"
              stripe
              border
              width="100%"
              :loading="loading">
      <el-table-column prop="execTime"
                       label="推送日期">
        <template slot-scope="scope">
          {{ scope.row.execTime | parseTime }}
        </template>
      </el-table-column>
      <el-table-column label="环节"
                       prop="segment">
        <template slot-scope="scope">
          {{ segmentList[`${scope.row.segment}`] }}
        </template>
      </el-table-column>
      <el-table-column label="节点"
                       prop="node">
        <template slot-scope="scope">
          <span class="btnText"
                @click="edit(scope.row,'详情')">{{ nodeList[`${scope.row.node}`] }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作系统"
                       prop="os">
        <template slot-scope="scope">
          {{ osList[`${scope.row.os}`] }}
        </template>
      </el-table-column>
      <el-table-column label="计划发送人数(人)"
                       prop="totalCount">
      </el-table-column>
      <el-table-column label="推送至第三方人数"
                       prop="thirdCount">
      </el-table-column>
      <el-table-column label="第三方下发人数(人)"
                       prop="issueCount">
      </el-table-column>
      <el-table-column label="到达量"
                       prop="arrivalCount">
      </el-table-column>
      <el-table-column label="到达率"
                       prop="">
        <template slot-scope="scope">
          {{ GetPercent(scope.row.arrivalCount,scope.row.issueCount) }}
        </template>
      </el-table-column>
      <el-table-column label="点击量"
                       prop="clickCount">
      </el-table-column>
      <el-table-column label="点击率"
                       prop="">
        <template slot-scope="scope">
          {{ GetPercent(scope.row.clickCount,scope.row.arrivalCount) }}
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination-container">
      <el-pagination :current-page.sync="pagination.pageNum"
                     :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange">
      </el-pagination>
    </div>
    <el-dialog :title="'模板' + templateObj.title" 
               size="mini" 
               :visible.sync="templateObj.show"   
               :close-on-press-escape="false" 
               :close-on-click-modal="false">
      <el-form 
        ref="queryForm"
        label-width="140px"
        class="query-form"
        size="mini"
        :rules="queryFormRules"
        :model="queryForm">
        <el-form-item
          label="产品线"
        >
          <span>{{ productLineMap[`${queryForm.productLine}`] }}</span>
        </el-form-item>
        <el-form-item
          label="环节"
        >
          <span>{{ segmentList[`${queryForm.segment}`] }}</span>
        </el-form-item>
        <el-form-item
          label="节点"
        >
          <span>{{ nodeList[`${queryForm.node}`] }}</span>
        </el-form-item>
        <el-form-item
          prop="planExecTime" 
          label="间隔时间">
          <el-input
            v-model.trim="queryForm.planExecTimeNum"
            :disabled="templateObj.title === '详情'"
            style="width:350px"
          >
          </el-input>
          <el-select
            v-model="queryForm.planExecTimeType"
            :disabled="templateObj.title === '详情'"
          >
            <el-option
              value="min"
              label="分钟"
            >
            </el-option>
            <el-option
              value="hour"
              label="小时"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="IOS推送标题"
                      prop="">
          <el-input
            v-model="queryForm.iosTitle" 
            :disabled="templateObj.title === '详情'"
            placeholder="限50字内"
            :maxlength="50"  
            style="width:350px">
          </el-input>
        </el-form-item>
        <el-form-item label="IOS推送内容"
                      prop="iosContent">       
          <el-input
            v-model="queryForm.iosContent"
            :disabled="templateObj.title === '详情'"
            placeholder="限100字内"
            :maxlength="100"
            type="textarea"
            :rows="4"
            style="width:350px">
          </el-input>
        </el-form-item>
        <el-form-item label="Android推送标题"
                      prop="androidTitle">
          <el-input
            v-model="queryForm.androidTitle"
            :disabled="templateObj.title === '详情'"  
            placeholder="限50字内"
            :maxlength="50"
            style="width:350px">
          </el-input>
        </el-form-item>
        <el-form-item label="Android推送内容"
                      prop="androidContent">        
          <el-input
            v-model="queryForm.androidContent"
            :disabled="templateObj.title === '详情'"   
            placeholder="限100字内"
            :maxlength="100"
            type="textarea"
            :rows="4"
            style="width:350px">
          </el-input>
        </el-form-item>
        <el-form-item label="点击推送后"
                      prop="clickAction">
          <el-radio-group
            v-model="queryForm.clickAction"
            :disabled="templateObj.title === '详情'" 
            @change="changeClickAction">
            <el-radio v-for="item in afterList"
                      :key="item.key"
                      :label="item.key"
                      :disabled="item.disable">
              {{ item.name }}
            </el-radio>
          </el-radio-group>
        </el-form-item>
        <el-card v-show="queryForm.clickAction !== 1 && queryForm.clickAction !== ''"
        >
          <el-form ref="afterForm" 
                   :model="afterForm"
                   :inline="true" 
                   size="mini" 
                   :rules="afterFormRules">
            <el-form-item v-show="queryForm.clickAction == 2 || queryForm.clickAction == 3"
                          label="url地址"
                          prop="linkUrl">
              <el-input
                v-model="afterForm.linkUrl" 
                :disabled="templateObj.title === '详情'"></el-input>
            </el-form-item>

            <el-form-item v-show="queryForm.clickAction == 4"
                          label=" "
                          prop="pageTag">
              <el-select v-model="afterForm.pageTag"
                         :disabled="templateObj.title === '详情'"
                         placeholder="指定产品"
                         style="width:140px;" 
                         @change="changePageTag">
                <el-option
                  v-for="(item,index) in appType"
                  :key="index"
                  :value="item.key"
                  :label="item.name">
                </el-option>
              </el-select> 
            </el-form-item>

            <el-form-item v-show="queryForm.clickAction == 4 && afterForm.pageTag == 'product'"
                          prop="productId"
                          label=" ">
              <el-select
                v-model="afterForm.productId"
                :disabled="templateObj.title === '详情'" 
                filterable
                remote
                reserve-keyword
                :loading="loading"
                :remote-method="remoteMethod"
                placeholder="产品名称"
                style="width:140px;" 
                @change="changeProductId">
                <el-option
                  v-for="(item,index) in productList"
                  :key="index"
                  :value="item.id"
                  :label="item.name">
                </el-option>
              </el-select> 
            </el-form-item>

            <el-form-item v-show="queryForm.clickAction == 4 && afterForm.pageTag == 'product'"
                          label=" "
                          prop="linkId">
              <el-select v-model="afterForm.linkId"
                         :disabled="templateObj.title === '详情'"
                         placeholder="选择链接id" 
                         style="width:140px;">
                <el-option
                  v-for="(item,index) in linkList"
                  :key="index"
                  :value="item.id"
                  :label="item.address">
                </el-option>
              </el-select> 
            </el-form-item>

            <el-form-item v-show="queryForm.clickAction == 4 && afterForm.pageTag == 'JRCS_SYFLCPLB'"
                          label=" "
                          prop="category">
              <el-input
                v-model="afterForm.category" 
                :disabled="templateObj.title === '详情'"
                placeholder="分类id"
              ></el-input>
            </el-form-item>

            <el-form-item v-show="queryForm.clickAction == 4 && afterForm.pageTag == 'JRCS_SYFLCPLB'"
                          label=" "
                          prop="className">
              <el-input
                v-model="afterForm.className"
                :disabled="templateObj.title === '详情'"
                placeholder="分类名称"></el-input>
            </el-form-item>
          </el-form>
        </el-card>
      </el-form>
      <div slot="footer" 
           class="dialog-footer">
        <el-button @click="templateObj.show = false">
          关闭
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import api from '../../api/app7.1/pushTotal'
import config from './config'
export default {
  components: {

  },
  data () {
    return {
      queryForm:{
        planExecTimeNum:'',
        planExecTimeType:'',
        clickAction:'',
        productLine:'',
        segment:'',
        node:'',
        iosTitle:'',
        iosContent:'',
        androidTitle:'',
        androidContent:'',
      },
      queryFormRules:{
        planExecTime: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
                if (!/^[0-9]*$/.test(this.queryForm.planExecTimeNum) || !this.queryForm.planExecTimeNum || this.queryForm.planExecTimeNum === '0'){
                  callback(new Error('请填写正确的时间数值'))
                } else {
                  callback()
                }
            },
          },
        ],
        iosContent: [{ required: true, message: '请填写', trigger: 'blur' }],
        androidTitle: [{ required: true, message: '请填写', trigger: 'blur' }],
        androidContent: [{ required: true, message: '请填写', trigger: 'blur' }],
      },
      afterForm: {
        linkUrl: '',
        productId: '',
        pageType: '',
        category: '',
        className: '',
        pageTag: '',
      },
      afterFormRules: {
        linkUrl: [{
          required: true,
          trigger: 'blur',
          validator: (rule, value, callback) => {
            if ((this.queryForm.clickAction === 2 || this.queryForm.clickAction === 3) && (!value)) {
              callback(new Error('请选择'))
            } else {
              callback()
            }
          },
        }],
        pageTag: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.clickAction === 4 && (!value)) {
                callback(new Error('请选择'))
              } else {
                callback()
              }
            },
          },
        ],
        productId: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.clickAction === 4 && this.afterForm.pageTag === 'product' && (!value)) {
                callback(new Error('请选择'))
              } else {
                callback()
              }
            },
          },
        ],
        linkId: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.clickAction === 4 && this.afterForm.pageTag === 'product' && (!value)) {
                callback(new Error('请选择'))
              } else {
                callback()
              }
            },
          },
        ],
        category: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.clickAction === 4 && this.afterForm.pageTag === 'JRCS_SYFLCPLB' && (!value)) {
                callback(new Error('请填写'))
              } else {
                callback()
              }
            },
          },
        ],
        className: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.clickAction === 4 && this.afterForm.pageTag === 'JRCS_SYFLCPLB' && (!value)) {
                callback(new Error('填写'))
              } else {
                callback()
              }
            },
          },
        ],
      },
      templateObj:{
        show:false,
        title:'详情',
        detailObj:{},
      },
      linkList:[],
      afterList: config.afterList,
      appType: config.appType,
      productList:[],
      segmentList:{
        1:'注册后',
        2:'启动APP',
      },
      nodeList:{
        101:'注册未登录',
        102:'启动APP后未登录',
      },
      osList: {
        1: 'android',
        2: 'ios',
        3: 'pc',
        4: 'h5',
        5: '其他',
      },
      productLineMap:{
        1:'花钱无忧',
        2:':贷款王',
        5:'立即借',
      },
      loading: false,
      searchForm: {
        pushTime: [],
        productLine: '1',
      },
      activeName: '1',
      tableData: [],
      pagination: {
        pageNum: 1,
        pageSize: 30,
        total: 0,
        pageSizes: [10, 30, 50, 100],
      },
    }
  },
  created () {
    if (this.$route.query.productLine) {
      this.queryForm.productLine = this.$route.query.productLine + ''
    }
    this.fetchData()
  },
  methods: {
    changeClickAction () {
      this.$refs['afterForm'].clearValidate()
      this.afterForm = {
        linkUrl: '',
        productId: '',
        pageType: '',
        category: '',
        className: '',
        pageTag: '',
        linkId: '',
      }
    },
    initAfterForm (obj) {
      if (obj.pageType === 2) {
        let data = {
          id: obj.productId,
          pageNum: 1,
          pageSize: 100,
        }
        this.fetchProductList(data, obj)
        this.fetchLinkList(obj.productId, obj)
      } else {
        this.afterForm = {
          linkUrl: obj.linkUrl,
          productId: obj.productId,
          pageType: obj.pageType,
          category: obj.category,
          className: obj.className,
          pageTag: obj.linkUrl,
          linkId: obj.linkId,
        }
      }
    },
    async edit (row,type) {
      const data = {
        planCode: row.planCode,
      }
      let res = await api.queryByPlanCode(data)
      if(res.data.respCode === '1000') {
        this.templateObj.title = type
        this.templateObj.detailObj = res.data.body
        this.resetQueryForm(res.data.body)
        this.initAfterForm(res.data.body)
        this.templateObj.show = true
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    resetQueryForm(obj) {
      let arr = ['','']
      if(obj.planExecTime) {
         arr = obj.planExecTime.split('~')
      }
      this.queryForm={
        planExecTimeNum:arr[0],
        planExecTimeType:arr[1],
        clickAction:obj.clickAction,
        productLine:obj.productLine,
        segment:obj.segment,
        node:obj.node,
        iosTitle:obj.iosTitle,
        iosContent:obj.iosContent,
        androidTitle:obj.androidTitle,
        androidContent:obj.androidContent,
      }
    },
    resetAfterForm(obj) {
      this.afterForm ={
        linkUrl: obj.linkUrl,
        productId: obj.productId,
        pageType: obj.pageType,
        category:obj.category,
        className: obj.className,
        pageTag:obj.pageTag,
      }
    },
    returnStatus (s, d) {
      // s === d ? return '推送中' : return'推送完成'
      if (s === d) {
        return '推送中'
      } else {
        return '推送完成'
      }
    },
    GetPercent (num, total) {
    /// <summary>
    /// 求百分比
    /// </summary>
    /// <param name="num">当前数</param>
    /// <param name="total">总数</param>
      num = parseFloat(num)
      total = parseFloat(total)
      if (isNaN(num) || isNaN(total)) {
        return '-'
      }
      return total <= 0 ? '0%' : (Math.round(num / total * 10000) / 100.00) + '%'
    },
    async fetchData () {
      this.loading = true
      let time = this.searchForm.pushTime ? this.searchForm.pushTime : []
      let data = {
        productLine:this.searchForm.productLine,
        pushTime: time.length === 2 ? time[0] + '~' + time[1] : '',
        pageNum: this.pagination.pageNum,
        pageSize: this.pagination.pageSize,
      }
      let res = await api.query(data)
      this.loading = false
      if (res.data.respCode === '1000') {
        this.tableData = res.data.body.list
        this.pagination.total = res.data.body.total
      }
    },
    reset () {
      this.searchForm.pushTime = []
      // this.queryForm = {
      //   planName: '',
      //   pushTime: [],
      //   productLine: '1'

      // }
      this.fetchData()
    },
    down () {
      let pushTime = this.searchForm.pushTime.length === 2 ? this.searchForm.pushTime[0] + '~' + this.searchForm.pushTime[1] : ''
      window.location.href = process.env.BASE_API +
      `/pushOnTimeConfig/exportCountData?productLine=${this.searchForm.productLine}&pushTime=${pushTime}&planType=2`
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNum = val
      this.fetchData()
    },
    async fetchProductList (data, obj) {
      let res = await api.getProductList(data)
      this.loading = false
      if (res.data.respCode === '1000') {
        this.productList = res.data.body.list
        if (obj) {
          this.afterForm = {
            linkUrl: obj.linkUrl,
            productId: obj.productId,
            pageType: obj.pageType,
            category: obj.category,
            className: obj.className,
            linkId: obj.linkId,
            pageTag: 'product',
          }
        }
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    changePageTag () {
      this.$refs['afterForm'].clearValidate()
      this.afterForm.className = ''
      this.afterForm.category = ''
      this.afterForm.productId = ''
      this.afterForm.linkId = ''
    },
    remoteMethod (query) {
      if (query !== '') {
        this.loading = true
        let data = {
          name: query,
          pageNum: 1,
          pageSize: 100,
        }
        this.fetchProductList(data)
        // setTimeout(() => {
        //   this.loading = false
        //   this.options = this.list.filter(item => {
        //     return item.label.toLowerCase()
        //       .indexOf(query.toLowerCase()) > -1
        //   })
        // }, 200)
      } else {
        this.productList = []
      }
    },
    changeProductId (val) {
      this.afterForm.linkId = null
      if (val) {
        this.fetchLinkList(val)
      }
    },
    async fetchLinkList (val, obj) {
      let data = {
        productLine: this.queryForm.productLine,
        productId: val,
      }
      let res = await api.searchLinks(data)
      if (res.data.respCode === '1000') {
        this.linkList = res.data.body
        if (obj) {
          this.afterForm = {
            linkUrl: obj.linkUrl,
            productId: obj.productId,
            pageType: obj.linkUrl,
            category: obj.category,
            className: obj.className,
          }
        }
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
  },
}
</script>