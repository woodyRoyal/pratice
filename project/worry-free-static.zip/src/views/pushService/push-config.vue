<template>
  <div>
    <el-form 
      ref="totalForm"
      label-width="140px"
      class="query-form"
      size="mini"
      :rules="queryFormRules"
      :model="queryForm">
      <el-form-item
        prop="planName" 
        label="推送计划名称：">
        <el-input
          v-model.trim="queryForm.planName"
          :disabled="type === 'look' || type === 'edit'"
          style="width:350px"
          :maxlength="100"
          placeholder="计划名称限制在100字内"
        >
        </el-input>
      </el-form-item>
      <el-form-item
        prop="productLine" 
        label="推送产品线：">
        <el-radio-group v-model="queryForm.productLine"
                        :disabled="type === 'look' || type === 'edit'"
                        @change="changeProductLine">
          <el-radio v-for="item in productLineList"
                    :key="item.id"
                    :label="item.id">
            {{ item.name }}
          </el-radio>
        </el-radio-group>
      </el-form-item>

      <el-form-item
        prop="selectType" 
        label="目标用户：">
        <el-radio-group
          v-model="queryForm.selectType" 
          :disabled="type === 'look' || type === 'edit'" 
          @change="changeSelectType">
          <el-radio v-for="item in userTypeList"
                    :key="item.key"
                    :label="item.key"
                    :disabled="item.disable">
            {{ item.name }}
          </el-radio>
        </el-radio-group>
        <el-upload
          v-if="queryForm.selectType === 4 && type !== 'look'"
          ref="upLoadDom"
          :disabled="type === 'look'"
          style="display:inline-block"
          :show-file-list="false"
          class="upload-demo"
          :action="URL_UPLOAD"
          :on-success="upLoadSuccess"
          :limit="1"
        >
          <el-button size="small"
                     type="primary">
            点击上传
          </el-button>
        </el-upload>
        <span v-if="queryForm.selectType === 4"
              class="btnText"
              @click="down()">{{ file.name }}</span>
      </el-form-item>
      <el-form-item v-show="queryForm.selectType === 3"
                    prop="userTypeSeq"
                    label="选择用户类型">
        <el-select
          v-model="queryForm.userTypeSeq"
          :disabled="type === 'look' || type === 'edit'"
          style="width:200px;" 
        >
          <el-option
            v-for="item in userTypeDetail"
            :key="item.key"
            :value="item.key"
            :label="item.name"
          >
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item v-show="queryForm.selectType === 3"
                    prop="numbers"
                    label=" ">
        <el-input v-model.trim="queryForm.numbers"
                  :disabled="type === 'look'"
                  placeholder="填写N值，使用英文逗号分隔"
                  style="width:200px;">
        </el-input>
      </el-form-item>
      <el-card v-show="queryForm.selectType === 2"
               style="width:850px;margin-bottom:10px;">
        <el-form 
          ref="userTypeForm" 
          :inline="true"
          size="mini"
          :rules="userTypeFormRules"
          :model="userTypeForm">
          <div>
            <el-form-item label="注册渠道">
              <!-- <el-input
              :disabled="type === 'look'"
              v-model="userTypeForm.registerChannel"
              placeholder="输入内容模糊匹配选择" 
              style="width:160px;">
              </el-input> -->
              <el-select
                v-model="userTypeForm.registerChannel"
                style="width:260px;"
                :disabled="type === 'look'"
                filterable
                remote
                multiple
                reserve-keyword
                :loading="loading"
                :remote-method="remoteRegisterChannel"
                placeholder="输入内容模糊匹配选择" 
              >
                <el-option
                  v-for="(item,index) in RegisterChannelList"
                  :key="index"
                  :value="item.name"
                  :label="item.name">
                </el-option>
              </el-select> 
            </el-form-item>

            <el-form-item label="号码归属地">
              <el-select
                v-model="userTypeForm.mobileProvince" 
                :disabled="type === 'look'"
                multiple
                style="width:260px;" 
                @change="changeValue">
                <el-option
                  v-for="(item,index) in provinceList"
                  :key="index"
                  :value="item"
                  :label="item">
                </el-option>
              </el-select>
            </el-form-item> 
          </div>
          <div>
            <el-form-item label="手机系统:"
                          label-width="135px">
              <el-radio-group v-model="userTypeForm.os"
                              :disabled="type === 'look'">
                <el-radio :label="0">
                  不限
                </el-radio>
                <el-radio :label="2">
                  IOS
                </el-radio>
                <el-radio :label="1">
                  Android
                </el-radio>
              </el-radio-group>
            </el-form-item> 
          </div>
          <div>
            <el-form-item label="注册日期"
                          label-width="135px">
              <div 
                v-for="(item,index) in userTypeForm.registerDateRange"
                :key="index"
              >
                <el-date-picker
                  v-model="item.time"
                  :disabled="type === 'look'"
                  style="margin-top:5px;"
                  size="mini"
                  type="daterange"
                  range-separator="至"
                  start-placeholder="开始日期"
                  value-format="yyyy-MM-dd"
                  end-placeholder="结束日期">
                </el-date-picker>
                <el-button size="mini"
                           :disabled="type === 'look'"
                           @click="addItem('registerDateRange')">
                  +
                </el-button>
                <el-button v-show="userTypeForm.registerDateRange.length>1"
                           size="mini"  
                           :disabled="type === 'look'" 
                           @click="delItem(index,'registerDateRange')">
                  -
                </el-button>
              </div>
            </el-form-item>
          </div>

          <div>
            <el-form-item label="最近一次登录日期"
                          label-width="135px">
              <div 
                v-for="(item,index) in userTypeForm.lastLoginDateRange"
                :key="index"
              >
                <el-date-picker
                  v-model="item.time"
                  :disabled="type === 'look'"
                  style="margin-top:5px;"
                  size="mini"
                  type="daterange"
                  range-separator="至"
                  start-placeholder="开始日期"
                  value-format="yyyy-MM-dd"
                  end-placeholder="结束日期">
                </el-date-picker>
                <el-button 
                  size="mini"
                  :disabled="type === 'look'" 
                  @click="addItem('lastLoginDateRange')">
                  +
                </el-button>
                <el-button v-if="userTypeForm.lastLoginDateRange.length > 1"
                           size="mini"  
                           :disabled="type === 'look'" 
                           @click="delItem(index,'lastLoginDateRange')">
                  -
                </el-button>
              </div>
            </el-form-item>
          </div>

          <div> 
            <el-form-item label="累计登录天数"
                          label-width="135px"
                          prop="loginDays">
              <el-input v-model="userTypeForm.loginDays[0]"
                        style="width:60px;"
                        :disabled="type === 'look'"
              >
              </el-input>
              天
              至
              <el-input
                v-model="userTypeForm.loginDays[1]" 
                :disabled="type === 'look'"
                style="width:60px;">
              </el-input>
              天
              <span class="font">
                前后包含，请填写整数
              </span>
            </el-form-item>
          </div>

          <div> 
            <el-form-item label="百融分值"
                          label-width="135px"
                          prop="scoreRange">
              <el-input v-model="userTypeForm.scoreRange[0]"
                        style="width:60px;"
                        :disabled="type === 'look'"
              >
              </el-input>
              分
              至
              <el-input v-model="userTypeForm.scoreRange[1]"
                        style="width:60px;"
                        :disabled="type === 'look'"
              >
              </el-input>
              分
              <span class="font">
                前后包含，请填写0-100的整数
              </span>
            </el-form-item>
          </div>
          <!-- 9.17新增需求 -->
          <div> 
            <el-form-item label="用户年龄"
                          label-width="135px"
                          prop="age">
              <el-input v-model="userTypeForm.age[0]"
                        style="width:60px;"
                        :disabled="type === 'look'"
              >
              </el-input>
              岁
              至
              <el-input
                v-model="userTypeForm.age[1]" 
                :disabled="type === 'look'"
                style="width:60px;">
              </el-input>
              岁
            </el-form-item>


            <el-form-item label="最近登录日期前30日累计产品点击量"
                          label-width="170px"
                          prop="clickCount">
              <el-input v-model="userTypeForm.clickCount[0]"
                        style="width:60px;"
                        :disabled="type === 'look'"
              >
              </el-input>
              次
              至
              <el-input
                v-model="userTypeForm.clickCount[1]" 
                :disabled="type === 'look'"
                style="width:60px;">
              </el-input>
              次
            </el-form-item>
          </div>

          <div>
            <el-form-item label="职业类型"
                          label-width="135px"
                          
                          prop="careers">
              <el-checkbox-group
                v-model="userTypeForm.careers" 
                :disabled="type === 'look'">
                <el-checkbox :label="0">
                  工薪族
                </el-checkbox>
                <el-checkbox :label="1">
                  企业主
                </el-checkbox>
                <el-checkbox :label="3">
                  自由职业
                </el-checkbox>
              </el-checkbox-group>
            </el-form-item>
            <el-form-item label="是否设置精准推荐"
                          label-width="135px"
                          prop="recommend">
              <el-radio-group v-model="userTypeForm.recommend"
                              :disabled="type === 'look'">
                <el-radio :label="0">
                  未设置
                </el-radio>
                <el-radio :label="1">
                  已设置
                </el-radio>
              </el-radio-group>
            </el-form-item>
          </div>
        </el-form>
      </el-card>
      <el-form-item label="IOS推送标题"
                    prop="iosTitle">
        <el-input
          v-model="queryForm.iosTitle" 
          :disabled="type === 'look'"
          placeholder="限50字内"
          :maxlength="50"  
          style="width:350px">
        </el-input>
      </el-form-item>
      <el-form-item label="IOS推送内容"
                    prop="iosContent">
        <div v-if="!computeuserTypeSeq">
          <el-button
            type="text" 
            @click="insertContent('iosContent')">
            产品名称
          </el-button>   
        </div>         
        <el-input
          v-model="queryForm.iosContent"
          :disabled="type === 'look'" 
          placeholder="限100字内"
          :maxlength="100"
          type="textarea"
          :rows="4"
          style="width:350px">
        </el-input>
      </el-form-item>
      <el-form-item label="Android推送标题"
                    prop="androidTitle">
        <el-input
          v-model="queryForm.androidTitle"
          :disabled="type === 'look'"  
          placeholder="限50字内"
          :maxlength="50"
          style="width:350px">
        </el-input>
      </el-form-item>
      <el-form-item label="Android推送内容"
                    prop="androidContent">
        <div v-if="!computeuserTypeSeq">
          <el-button
            type="text" 
            @click="insertContent('androidContent')">
            产品名称
          </el-button>   
        </div>
        
        <el-input
          v-model="queryForm.androidContent"
          :disabled="type === 'look'"  
          placeholder="限100字内"
          :maxlength="100"
          type="textarea"
          :rows="4"
          style="width:350px">
        </el-input>
      </el-form-item>

      <el-form-item label="点击推送后"
                    prop="clickAction">
        <el-radio-group
          v-model="queryForm.clickAction" 
          :disabled="type === 'look'" 
          @change="changeClickAction">
          <el-radio v-for="item in afterList"
                    :key="item.key"
                    :label="item.key"
                    :disabled="item.disable">
            {{ item.name }}
          </el-radio>
        </el-radio-group>
      </el-form-item>
      <el-card v-show="queryForm.clickAction !== 1 && queryForm.clickAction !== ''"
               style="width:850px;">
        <el-form ref="afterForm" 
                 :model="afterForm"
                 :inline="true" 
                 size="mini" 
                 :rules="afterFormRules">
          <el-form-item v-show="queryForm.clickAction == 2 || queryForm.clickAction == 3"
                        label="url地址"
                        prop="linkUrl">
            <el-input
              v-model="afterForm.linkUrl" 
              :disabled="type === 'look'"></el-input>
          </el-form-item>

          <el-form-item v-show="queryForm.clickAction == 4"
                        label=" "
                        prop="pageTag">
            <el-select v-model="afterForm.pageTag"
                       :disabled="type === 'look'"
                       placeholder="指定产品"
                       style="width:140px;" 
                       @change="changePageTag">
              <el-option
                v-for="(item,index) in appType"
                :key="index"
                :value="item.key"
                :label="item.name">
              </el-option>
            </el-select> 
          </el-form-item>

          <el-form-item v-show="queryForm.clickAction == 4 && afterForm.pageTag == 'product'"
                        prop="productId"
                        label=" ">
            <el-select
              v-model="afterForm.productId"
              :disabled="type === 'look'" 
              filterable
              remote
              reserve-keyword
              :loading="loading"
              :remote-method="remoteMethod"
              placeholder="产品名称"
              style="width:140px;" 
              @change="changeProductId">
              <el-option
                v-for="(item,index) in productList"
                :key="index"
                :value="item.id"
                :label="item.name">
              </el-option>
            </el-select> 
          </el-form-item>

          <el-form-item v-show="queryForm.clickAction == 4 && afterForm.pageTag == 'product'"
                        label=" "
                        prop="linkId">
            <el-select v-model="afterForm.linkId"
                       :disabled="type === 'look'"
                       placeholder="选择链接id" 
                       style="width:140px;">
              <el-option
                v-for="(item,index) in linkList"
                :key="index"
                :value="item.id"
                :label="item.address">
              </el-option>
            </el-select> 
          </el-form-item>

          <el-form-item v-show="queryForm.clickAction == 4 && afterForm.pageTag == 'JRCS_SYFLCPLB'"
                        label=" "
                        prop="category">
            <el-input
              v-model="afterForm.category" 
              :disabled="type === 'look'"
              placeholder="分类id"
            ></el-input>
          </el-form-item>

          <el-form-item v-show="queryForm.clickAction == 4 && afterForm.pageTag == 'JRCS_SYFLCPLB'"
                        label=" "
                        prop="className">
            <el-input
              v-model="afterForm.className"
              :disabled="type === 'look'" 
              placeholder="分类名称"></el-input>
          </el-form-item>
        </el-form>
      </el-card>
      <el-form-item label="推送时间"
                    prop="planExecType">
        <el-radio-group
          v-model="queryForm.planExecType"
          :disabled="type === 'look' || type === 'edit'"
          @change="changePlanExecType">
          <el-radio v-show="computeuserTypeSeq"
                    :label="1">
            现在推送
          </el-radio>
          <el-radio v-show="computeuserTypeSeq"
                    :label="2">
            定时推送
          </el-radio>
          <el-radio :label="3">
            重复推送
          </el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item v-show="queryForm.planExecType == 2"
                    label="定时推送时间"
                    prop="planExecTime">
        <el-date-picker
          v-model="queryForm.planExecTime"
          :disabled="type === 'look'"
          size="mini"
          type="datetime"
          placeholder="请选择日期和时间"
          value-format="yyyy-MM-dd HH:mm:ss"
        >
        </el-date-picker>
      </el-form-item>
      <el-form-item v-show="queryForm.planExecType == 3"
                    label="每月"
                    prop="day">
        <el-select
          v-model="queryForm.day"
          :disabled="type === 'look'" 
          multiple
          collapse-tags
          @change="changeDay" 
        >
          <el-option
            v-for="item in dayList"
            :key="item"
            :value="item"
          >
          </el-option>
        </el-select>
        号
        <el-time-picker
          v-model="queryForm.datTime"
          :disabled="type === 'look'"
          value-format="HH:mm:ss"
          placeholder="选择时间">
        </el-time-picker>
      </el-form-item>
      <el-form-item label="去重选择">
        <el-checkbox
          v-model="queryForm.distinctTag"
          :disabled="type === 'look'" 
          :true-label="1" 
          :false-label="2">
          按推送日期去重
        </el-checkbox>
      </el-form-item>

      <el-form-item label=" ">
        <el-button
          :disabled="type === 'look'" 
          type="primary" 
          size="large"  
          @click="submit()">
          提交
        </el-button>
      </el-form-item>
    </el-form>

    <el-dialog :visible.sync="dialog.show"
               title="推送消息预览">
      <el-form size="mini"
               label-width="130px">
        <el-form-item label="推送计划名称">
          <span>{{ queryForm.planName }}</span>
        </el-form-item>
        <el-form-item label="推送产品线">
          <span>{{ productLineMap[`${queryForm.productLine}`] }}</span>
        </el-form-item>
        <el-form-item label="目标用户">
          <span>{{ userTypeMap[`${queryForm.selectType}`] }}</span>
        </el-form-item>
        <el-form-item label="IOS推送标题">
          <span>{{ queryForm.iosTitle }}</span>
        </el-form-item>
        <el-form-item label="IOS推送内容">
          <span>{{ queryForm.iosContent }}</span>
        </el-form-item>
        <el-form-item label="Android推送标题">
          <span>{{ queryForm.androidTitle }}</span>
        </el-form-item>
        <el-form-item label="Android推送内容">
          <span>{{ queryForm.androidContent }}</span>
        </el-form-item>
        <el-form-item label="点击通知后">
          <span>{{ afterMap[`${queryForm.clickAction}`] }}</span>
        </el-form-item>
        <el-form-item label="推送时间">
          <span>{{ planExecTypeMap[`${queryForm.planExecType}`] }}</span>
        </el-form-item>
        <el-form-item v-show="queryForm.planExecType == 2"
                      label="定时推送时间"
                      prop="planExecTime">
          <el-date-picker
            v-model="queryForm.planExecTime"
            size="mini"
            disabled
            type="datetime"
            placeholder="请选择日期和时间"
            value-format="yyyy-MM-dd HH:mm:ss"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item v-show="queryForm.planExecType == 3"
                      label="每月"
                      prop="day">
          <el-select
            v-model="queryForm.day" 
            disabled
            multiple 
          >
            <el-option
              v-for="item in dayList"
              :key="item"
              :value="item"
            >
            </el-option>
          </el-select>
          号
          <el-time-picker
            v-model="queryForm.datTime"
            disabled
            value-format="HH:mm:ss"
            placeholder="选择时间">
          </el-time-picker>
        </el-form-item>
        <el-form-item label="去重选择">
          <span>{{ queryForm.distinctTag === 1?'按推送日期去重':'不去重' }}</span>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="dialog.show = false">
          返回修改
        </el-button>
        <el-button v-if="queryForm.planExecType === 1"
                   type="primary"
                   @click="fetchForm()">
          确定现在推送
        </el-button>
        <el-button v-if="queryForm.planExecType === 2"
                   type="primary"
                   @click="fetchForm()">
          确定定时推送
        </el-button>
        <el-button v-if="queryForm.planExecType === 3"
                   type="primary"
                   @click="fetchForm()">
          确定重复推送
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { platform } from '../../assets/config'
import api from '../../api/app7.1/pushConfig'
import config from './config'
// import {parseTime} from '../../utils/formatDate'
export default {
  components: {

  },
  data () {
    return {
      version: null,
      planCode: null,
      RegisterChannelList: [],
      URL_UPLOAD: api.URL_UPLOAD,
      all: false,
      dayAll: false,
      btnLoading: false,
      loading: false,
      productLineList: platform.productLine,
      productLineMap: platform.productLineMap,
      provinceList: platform.provinceList,
      userTypeDetail:config.userTypeDetail,
      planExecTypeMap: {
        1: '现在推送',
        3: '重复推送',
        2: '定时推送',
      },
      productList: [],
      linkList: [],
      dayList: [],
      afterList: config.afterList,
      afterMap: config.afterMap,
      appType: config.appType,
      userTypeList: config.userTypeList,
      userTypeMap: config.userTypeMap,
      file: {
        name: '',
        fdfsDomain: '',
      },
      queryForm: {
        // 用户类型
        userTypeSeq:null,
        numbers:'',
        planName: '',
        productLine: '',
        // 目标用户：
        selectType: '',

        // 百融分值
        scoreRange: '',
        // 文件
        filePath: '',
        iosContent: '',
        iosTitle: '',
        androidTitle: '',
        androidContent: '',
        clickAction: 1,
        distinctTag: 1,
        planExecType: '',
        planExecTime: '',
        day: [],
        datTime: '',
      },
      queryFormRules: {
        userTypeSeq: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.selectType === 3 && (!this.queryForm.userTypeSeq)) {
                callback(new Error('请选定时推送时间'))
              } else {
                callback()
              }
            },
          },
        ],
        numbers: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              this.queryForm.numbers = this.queryForm.numbers.replace(/，/g,',')
              if (this.queryForm.selectType === 3 && (this.queryForm.numbers === '')) {
                callback(new Error('请填写N值'))
              } else if(!/^[0-9,]*$/.test(this.queryForm.numbers) && (this.queryForm.selectType === 3)){
                callback(new Error('请填写正确的参数值，并使用逗号分隔'))
              } else {
                callback()
              }
            },
          },
        ],
        planName: [{ required: true, message: '请填写推送计划名称', trigger: 'blur' }],
        productLine: [{ required: true, message: '请选择推送产品线', trigger: 'change' }],
        selectType: [{ required: true, message: '请选择目标用户：', trigger: 'change' }],
        clickAction: [{ required: true, message: '请选择点击推送后：', trigger: 'change' }],
        planExecType: [{ required: true, message: '请选择推送时间：', trigger: 'change' }],
        planExecTime: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.planExecType === 2 && (!this.queryForm.planExecTime)) {
                callback(new Error('请选定时推送时间'))
              } else {
                callback()
              }
            },
          },
        ],
        day: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.planExecType === 3 && (!this.queryForm.day.length || !this.queryForm.datTime)) {
                callback(new Error('请选择每月推送时间'))
              } else {
                callback()
              }
            },
          },
        ],
        iosTitle: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              const arr = [1, 3, 4]
              if (arr.includes(this.queryForm.selectType) && value === '') {
                callback(new Error('请填写'))
              } else if (this.queryForm.selectType === 2 && (this.userTypeForm.os === 2 || this.userTypeForm.os === 0) && value === '') {
                callback(new Error('请填写'))
              } else {
                callback()
              }
            },
          },
        ],
        iosContent: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              const arr = [1, 3, 4]
              if (arr.includes(this.queryForm.selectType) && value === '') {
                callback(new Error('请填写'))
              } else if (this.queryForm.selectType === 2 && (this.userTypeForm.os === 2 || this.userTypeForm.os === 0) && value === '') {
                callback(new Error('请填写'))
              } else {
                callback()
              }
            },
          },
        ],
        androidTitle: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              const arr = [1, 3, 4]
              if (arr.includes(this.queryForm.selectType) && value === '') {
                callback(new Error('请填写'))
              } else if (this.queryForm.selectType === 2 && (this.userTypeForm.os === 1 || this.userTypeForm.os === 0) && value === '') {
                callback(new Error('请填写'))
              } else {
                callback()
              }
            },
          },
        ],
        androidContent: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              const arr = [1, 3, 4]
              if (arr.includes(this.queryForm.selectType) && value === '') {
                callback(new Error('请填写'))
              } else if (this.queryForm.selectType === 2 && (this.userTypeForm.os === 1 || this.userTypeForm.os === 0) && value === '') {
                callback(new Error('请填写'))
              } else {
                callback()
              }
            },
          },
        ],
      },
      afterForm: {
        linkUrl: '',
        productId: '',
        pageType: '',
        category: '',
        className: '',
        pageTag: '',
      },
      afterFormRules: {
        linkUrl: [{
          required: true,
          trigger: 'blur',
          validator: (rule, value, callback) => {
            if ((this.queryForm.clickAction === 2 || this.queryForm.clickAction === 3) && (!value)) {
              callback(new Error('请选择'))
            } else {
              callback()
            }
          },
        }],
        pageTag: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.clickAction === 4 && (!value)) {
                callback(new Error('请选择'))
              } else {
                callback()
              }
            },
          },
        ],
        productId: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.clickAction === 4 && this.afterForm.pageTag === 'product' && (!value)) {
                callback(new Error('请选择'))
              } else {
                callback()
              }
            },
          },
        ],
        linkId: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.clickAction === 4 && this.afterForm.pageTag === 'product' && (!value)) {
                callback(new Error('请选择'))
              } else {
                callback()
              }
            },
          },
        ],
        category: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.clickAction === 4 && this.afterForm.pageTag === 'JRCS_SYFLCPLB' && (!value)) {
                callback(new Error('请填写'))
              } else {
                callback()
              }
            },
          },
        ],
        className: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.clickAction === 4 && this.afterForm.pageTag === 'JRCS_SYFLCPLB' && (!value)) {
                callback(new Error('填写'))
              } else {
                callback()
              }
            },
          },
        ],
      },
      CAREER_LIST:config.CAREER_LIST,
      userTypeForm: {
        os: 0,
        registerChannel: [],
        mobileProvince: [],
        loginDays: ['', ''],
        scoreRange: ['', ''],
        age: ['', ''],
        clickCount: ['', ''],
        careers:[],
        recommend:null,
        registerDateRange: [
          {
            time: '',
          },
        ],
        lastLoginDateRange: [
          {
            time: '',
          },
        ],
      },
      userTypeFormRules: {
        loginDays: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              let start = this.userTypeForm.loginDays[0]
              let end = this.userTypeForm.loginDays[1]
              if (this.queryForm.selectType === 2) {
                if ((!/^[0-9]*$/.test(start) && start !== '') || (!/^[0-9]*$/.test(end) && end !== '')) {
                  callback(new Error('只能填写正整数'))
                } else if (start !== '' && end !== '' && (Number(end) < Number(start))) {
                  callback(new Error('后面的数不能小于前面的数'))
                } else {
                  callback()
                }
              }
            },

          },
        ],
        scoreRange: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              let start = this.userTypeForm.scoreRange[0]
              let end = this.userTypeForm.scoreRange[1]
              if (this.queryForm.selectType === 2) {
                if ((!/^[0-9]*$/.test(start) && start !== '') || (!/^[0-9]*$/.test(end) && end !== '')) {
                  callback(new Error('只能填写整数'))
                } else if (start !== '' && end !== '' && (Number(end) < Number(start))) {
                  console.log(start, end)
                  callback(new Error('后面的数不能小于前面的数'))
                } else if (start !== '' && end !== '' && (Number(start) > 100 || Number(end) > 100)) {
                  callback(new Error('请填写0-100的整数'))
                } else {
                  callback()
                }
              }
            },

          },
        ],
        age: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              let start = this.userTypeForm.age[0]
              let end = this.userTypeForm.age[1]
              if (this.queryForm.selectType === 2) {
                if ((!/^[0-9]*$/.test(start) && start !== '') || (!/^[0-9]*$/.test(end) && end !== '')) {
                  callback(new Error('只能填写正整数'))
                } else if (start !== '' && end !== '' && (Number(end) < Number(start))) {
                  callback(new Error('后面的数不能小于前面的数'))
                } else {
                  callback()
                }
              }
            },

          },
        ],
        clickCount: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              let start = this.userTypeForm.clickCount[0]
              let end = this.userTypeForm.clickCount[1]
              if (this.queryForm.selectType === 2) {
                if ((!/^[0-9]*$/.test(start) && start !== '') || (!/^[0-9]*$/.test(end) && end !== '')) {
                  callback(new Error('只能填写正整数'))
                } else if (start !== '' && end !== '' && (Number(end) < Number(start))) {
                  callback(new Error('后面的数不能小于前面的数'))
                } else {
                  callback()
                }
              }
            },

          },
        ],
      },
      dialog: {
        show: false,
      },
      pageData: [],
      platformName: '花钱无忧',
      opeanLinkList: [],
    }
  },
  computed: {
    computeuserTypeSeq () {
      if([2,3,4,5,10,20].includes(this.queryForm.userTypeSeq)){
        return false
      } else {
        return true
      }
    },
    type () {
      if (!this.$route.params.planCode) {
        return 'add'
      } else if (this.$route.params.planCode && !this.$route.params.edit) {
        return 'look'
      } else {
        return 'edit'
      }
    },
  },
  created () {
    this.dayList = ['全选']
    for (let i = 1; i < 32; i++) {
      this.dayList.push(i)
    }
    if (this.$route.params.planCode) {
      this.fetchData()
    }
  },
  // mounted () {
  // },
  methods: {
    insertContent (type) {
      this.queryForm[type] = this.queryForm[type] + '${productName}'
    },
    async remoteRegisterChannel (query) {
      if (query !== '') {
        this.loading = true
        let data = {
          name: query,
          pageSize: 1000,
          currentPage: 1,
        }
        let res = await api.queryChannel(data)
        this.loading = false
        if (res.data.respCode === '1000') {
          this.RegisterChannelList = res.data.body.list
        } else {
          this.$message.error('获取渠道号失败')
          this.RegisterChannelList = []
        }
        // setTimeout(() => {
        //   this.loading = false
        //   this.options = this.list.filter(item => {
        //     return item.label.toLowerCase()
        //       .indexOf(query.toLowerCase()) > -1
        //   })
        // }, 200)
      } else {
        this.RegisterChannelList = []
      }
    },
    async fetchData () {
      let data = {
        planCode: this.$route.params.planCode,
      }
      let res = await api.queryByPlanCode(data)
      if (res.data.respCode === '1000') {
        let obj = res.data.body
        this.version = obj.version
        let day = []
        let datTime = ''
        if (obj.planExecType === 3) {
          let index = obj.planExecTime.indexOf(' ')
          day = obj.planExecTime.substring(0, index)
          if (day.indexOf('*') > -1) {
            day = ['全选']
            for (let i = 1; i < 32; i++) {
              day.push(i)
            }
          } else {
            day = JSON.parse(day).length === 31 ? this.dayList : JSON.parse(day)
          }
          datTime = obj.planExecTime.substring(index)
          if (datTime.length < 8) {
            datTime = datTime + ':00'
          }
        }

        this.queryForm = {
          userTypeSeq:obj.userTypeSeq,
          numbers:obj.numbers? obj.numbers.join(',') :'',
          planName: obj.planName,
          productLine: obj.productLine,
          // 目标用户：
          selectType: obj.selectType,
          // 文件
          filePath: obj.filePath,
          iosContent: obj.iosContent,
          iosTitle: obj.iosTitle,
          androidTitle: obj.androidTitle,
          androidContent: obj.androidContent,
          clickAction: obj.clickAction,
          distinctTag: obj.distinctTag,
          planExecType: obj.planExecType,
          planExecTime: obj.planExecTime,
          day: day,
          datTime: datTime,
        }
        if (obj.selectType === 4) {
          this.file.name = obj.filePath
          this.file.fdfsDomain = obj.fdfsDomain
        }
        if (obj.selectType === 2) {
          this.initUserTypeForm(obj)
        }
        if (obj.clickAction !== 1) {
          this.initAfterForm(obj)
        }
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    initUserTypeForm (obj) {
      let loginDays = ['', '']
      let scoreRange = ['', '']
      let age = ['', '']
      let clickCount = ['', '']
      let registerDateRange = [{time: []}]
      let lastLoginDateRange = [{time: []}]
      let registerChannel = []
      if (obj.loginDaysRange && obj.loginDaysRange.length) {
        loginDays = obj.loginDaysRange.split('~')
      }
      if (obj.scoreRange && obj.scoreRange.length) {
        scoreRange = obj.scoreRange.split('~')
      }
      // 二期字段
      if (obj.age && obj.age.length) {
        age = obj.age.split('~')
      }
      if (obj.clickCount && obj.clickCount.length) {
        clickCount = obj.clickCount.split('~')
      }
      if (obj.registerDateRange && obj.registerDateRange.length) {
        registerDateRange = []
        obj.registerDateRange.forEach((t) => {
          registerDateRange.push({time: t.split('~')})
        })
      }
      if (obj.lastLoginDateRange && obj.lastLoginDateRange.length) {
        lastLoginDateRange = []
        obj.lastLoginDateRange.forEach((t) => {
          lastLoginDateRange.push({time: t.split('~')})
        })
      }
      registerChannel = obj.registerChannel ? obj.registerChannel.split(',') : []
      registerChannel.forEach((t) => {
        if (t) {
          this.RegisterChannelList.push({name: t})
        }
      })
      this.userTypeForm = {
        os: obj.os || 0,
        mobileProvince: obj.mobileProvince || [],
        registerChannel: registerChannel,
        loginDays: loginDays.length === 2 ? loginDays : ['', ''],
        scoreRange: scoreRange.length === 2 ? scoreRange : ['', ''],
        registerDateRange: registerDateRange,
        lastLoginDateRange: lastLoginDateRange,
        age: age,
        clickCount: clickCount,
        careers:obj.careers?obj.careers : [],
        recommend:obj.recommend,
      }
    },
    initAfterForm (obj) {
      if (obj.pageType === 2) {
        let data = {
          id: obj.productId,
          pageNum: 1,
          pageSize: 100,
        }
        this.fetchProductList(data, obj)
        this.fetchLinkList(obj.productId, obj)
      } else {
        this.afterForm = {
          linkUrl: obj.linkUrl,
          productId: obj.productId,
          pageType: obj.pageType,
          category: obj.category,
          className: obj.className,
          pageTag: obj.linkUrl,
          linkId: obj.linkId,
        }
      }
    },
    changeClickAction () {
      this.$refs['afterForm'].clearValidate()
      this.afterForm = {
        linkUrl: '',
        productId: '',
        pageType: '',
        category: '',
        className: '',
        pageTag: '',
        linkId: '',
      }
    },
    changePageTag () {
      this.$refs['afterForm'].clearValidate()
      this.afterForm.className = ''
      this.afterForm.category = ''
      this.afterForm.productId = ''
      this.afterForm.linkId = ''
    },
    changeValue (val) {
      if (this.all) {
        if (val.length === 34 && val.includes('全选')) {
          val.shift()
          this.userTypeForm.mobileProvince = val
          this.all = false
        }
        if (!val.includes('全选') && this.provinceList.length - 1 === val.length) {
          this.userTypeForm.mobileProvince = []
          this.all = false
        }
      } else {
        if (val.includes('全选')) {
          console.log('点击全选')
          this.userTypeForm.mobileProvince = this.provinceList
          this.all = true
        }
        if (!val.includes('全选') && val.length === 34) {
          console.log('选择完了所有按钮')
          val.unshift('全选')
          this.userTypeForm.mobileProvince = val
          this.all = true
        }
      }
    },
    changeDay (val) {
      if (this.dayAll) {
        if (val.length === 31 && val.includes('全选')) {
          val.shift()
          this.queryForm.day = val
          this.dayAll = false
        }
        if (!val.includes('全选') && this.dayList.length - 1 === val.length) {
          this.queryForm.day = []
          this.dayAll = false
        }
      } else {
        if (val.includes('全选')) {
          console.log('点击全选')
          this.queryForm.day = this.dayList
          this.dayAll = true
        }
        if (!val.includes('全选') && val.length === 31) {
          console.log('选择完了所有按钮')
          val.unshift('全选')
          this.queryForm.day = val
          this.dayAll = true
        }
      }
    },
    changeProductId (val) {
      this.afterForm.linkId = null
      if (val) {
        this.fetchLinkList(val)
      }
    },
    changeProductLine (val) {
      if (this.afterForm.productId && val) {
        this.fetchLinkList(this.afterForm.productId, null)
      }
    },
    async fetchLinkList (val, obj) {
      if (!this.queryForm.productLine) {
        return this.$message.error('请先选择产品线')
      }
      let data = {
        productLine: this.queryForm.productLine,
        productId: val,
      }
      let res = await api.searchLinks(data)
      if (res.data.respCode === '1000') {
        this.linkList = res.data.body
        if (obj) {
          this.afterForm = {
            linkUrl: obj.linkUrl,
            productId: obj.productId,
            pageType: obj.linkUrl,
            category: obj.category,
            className: obj.className,
          }
        }
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    changePlanExecType () {
      this.$refs['totalForm'].clearValidate(['planExecTime', 'day'])
    },
    remoteMethod (query) {
      if (query !== '') {
        this.loading = true
        let data = {
          name: query,
          pageNum: 1,
          pageSize: 100,
        }
        this.fetchProductList(data)
        // setTimeout(() => {
        //   this.loading = false
        //   this.options = this.list.filter(item => {
        //     return item.label.toLowerCase()
        //       .indexOf(query.toLowerCase()) > -1
        //   })
        // }, 200)
      } else {
        this.productList = []
      }
    },
    async fetchProductList (data, obj) {
      let res = await api.getProductList(data)
      this.loading = false
      if (res.data.respCode === '1000') {
        this.productList = res.data.body.list
        if (obj) {
          this.afterForm = {
            linkUrl: obj.linkUrl,
            productId: obj.productId,
            pageType: obj.pageType,
            category: obj.category,
            className: obj.className,
            linkId: obj.linkId,
            pageTag: 'product',
          }
        }
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    submit () {
      if (this.queryForm.selectType === 4 && !this.queryForm.filePath) {
        return this.$message.error('请先上传文件')
      }
      if (this.queryForm.planExecType === 2) {
        let selectTime = new Date(this.queryForm.planExecTime).getTime()
        let time = this.calculateDiffTime(selectTime)
        console.log(time)
        if (time < 1) {
          return this.$message.error('定时推送时间不能早于当前时间')
        }
      }
      let flag = true
      this.btnLoading = true
      const arr = ['totalForm']
      if (this.queryForm.selectType === 2) {
        arr.push('userTypeForm')
      }
      if (this.queryForm.clickAction !== 1) {
        arr.push('afterForm')
      }
      arr.forEach((t) => {
        this.$refs[t].validate((valid) => {
          if (!valid) {
            this.btnLoading = false
            flag = false
          }
        })
      })

      if (flag) {
        this.dialog.show = true
      }
      // this.$refs['totalForm'].validate(async valid => {

      // })
    },
    async fetchForm () {
      if (this.queryForm.planExecType === 2) {
        let selectTime = new Date(this.queryForm.planExecTime).getTime()
        let time = this.calculateDiffTime(selectTime)
        console.log(time)
        if (time < 1) {
          return this.$message.error('定时推送时间不能早于当前时间')
        }
      }
      this.btnLoading = true
      let data = {
        version: this.version,
        planCode: this.$route.params.planCode ? Number(this.$route.params.planCode) : null,
        ...this.queryFormRes(),
        ...this.userTypeFormRes(),
        ...this.afterFormRes(),
        planType:1,
      }
      for (let key in data) {
        if (JSON.stringify(data[key]) === '[]') {
          data[key] = null
        }
      }
      if(this.queryForm.selectType !== 3) {
        delete data.numbers
        delete data.userTypeSeq
      }
      // if (this.queryForm.planExecType === 1) {
      //   data.planExecTime = parseTime(new Date())
      // }
      let res = await api.saveOrUpdate(data)
      this.btnLoading = false
      if (res.data.respCode === '1000') {
        this.$message.success('已成功创建推送计划')
        this.dialog.show = false
        this.$router.push({name: '推送计划', query: {productLine: this.queryForm.productLine}})
        // if (this.queryForm.planExecType === 1) {
        //   this.$router.push({name: '计划推送统计', query: {productLine: this.queryForm.productLine}})
        // } else {
        //   this.$router.push({name: '推送计划', query: {productLine: this.queryForm.productLine}})
        // }
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    clearForm () {
      this.queryForm = {
        planName: '',
        productLine: '',
        // 目标用户：
        selectType: '',

        // 百融分值
        scoreRange: '',
        // 文件
        filePath: '',
        iosContent: '',
        iosTitle: '',
        androidTitle: '',
        androidContent: '',
        clickAction: 1,
        distinctTag: 1,
        planExecType: '',
        planExecTime: '',
        day: [],
        datTime: '',
      }
      this.afterForm = {
        linkUrl: '',
        productId: '',
        pageType: '',
        category: '',
        className: '',
        pageTag: '',
      }
      this.userTypeForm = {
        os: 0,
        mobileProvince: [],
        loginDays: ['', ''],
        scoreRange: ['', ''],
        age: ['', ''],
        clickCount: ['', ''],
        careers:[],
        recommend:null,
        registerDateRange: [
          {
            time: [],
          },
        ],
        lastLoginDateRange: [
          {
            time: [],
          },
        ],
      }
    },
    calculateDiffTime (selectTime) {
      let now = new Date().getTime()
      let timeDiff = selectTime - now
      let minute = timeDiff / 1000 / 60
      minute = minute || ''
      return minute
    },
    queryFormRes () {
      let data = {}
      if (this.queryForm.planExecType === 1) {
        data = {
          ...this.queryForm,
          planExecTime: '',
        }
      }
      if (this.queryForm.planExecType === 2) {
        data = {
          ...this.queryForm,
        }
      }
      if (this.queryForm.planExecType === 3) {
        let day = []
        day = this.queryForm.day.filter((t) => t !== '全选')
        data = {
          ...this.queryForm,
          planExecTime: JSON.stringify(day) + ' ' + this.queryForm.datTime,
        }
      }
      if(this.queryForm.selectType === 3) {
        let numbers = this.queryForm.numbers === ''?[]:this.queryForm.numbers.split(',')
        for(let i = 0; i < numbers.length; i++) {
          if(numbers[i]===''||numbers[i]===null||numbers[i]===undefined){
              numbers.splice(i,1);
              i=i-1;
          }
        }
        for(let i = 0; i < numbers.length; i++) {
          numbers[i] = Number(numbers[i])
        }
        data = {
          ...data,
          numbers:numbers,
        }
      }
      return data
    },
    // 封装userTypeForm
    userTypeFormRes () {
      let registerDateRange = []
      let lastLoginDateRange = []
      // 假如筛选用户
      if (this.queryForm.selectType === 2) {
        this.userTypeForm.registerDateRange.forEach((t) => {
          if (t.time) {
            if (t.time.length > 0) {
              registerDateRange.push(t.time[0] + '~' + t.time[1])
            }
          }
        })
        this.userTypeForm.lastLoginDateRange.forEach((t) => {
          if (t.time) {
            if (t.time.length > 0) {
              lastLoginDateRange.push(t.time[0] + '~' + t.time[1])
            }
          }
        })
      }
      // console.log(this.userTypeForm.mobileProvince)
      let mobileProvince = []
      mobileProvince = this.userTypeForm.mobileProvince.filter((t) => t !== '全选')
      let loginDaysStart = this.userTypeForm.loginDays[0]
      let loginDaysEnd = this.userTypeForm.loginDays[1]
      let scoreRangeStart = this.userTypeForm.scoreRange[0]
      let scoreRangeEnd = this.userTypeForm.scoreRange[1]
      // 二期
      let ageStart = this.userTypeForm.age[0]
      let ageEnd = this.userTypeForm.age[1]

      let clickCountStart = this.userTypeForm.clickCount[0]
      let clickCountEnd = this.userTypeForm.clickCount[1]
      let loginDaysRange = ''
      let scoreRange = ''
      let age = ageStart + "~" + ageEnd
      let clickCount = clickCountStart + `~` +  clickCountEnd
      if(ageStart === '' && ageEnd === '') {
        age = ''
      }
      if(clickCountStart === '' && clickCountEnd === '') {
        clickCount = ''
      }
      if (loginDaysStart === '' && loginDaysEnd) {
        loginDaysRange = '0~' + loginDaysEnd
      } else if (loginDaysStart && loginDaysEnd === '') {
        loginDaysRange = loginDaysStart + '~9999'
      } else if (loginDaysStart !== '' && loginDaysEnd !== '') {
        loginDaysRange = loginDaysStart + `~` + loginDaysEnd
      } else {
        loginDaysRange = ''
      }

      if (scoreRangeStart === '' && scoreRangeEnd) {
        scoreRange = '0~' + scoreRangeEnd
      } else if (scoreRangeStart && scoreRangeEnd === '') {
        scoreRange = scoreRangeStart + '~9999'
      } else if (scoreRangeStart !== '' && scoreRangeEnd !== '') {
        scoreRange = scoreRangeStart + `~` + scoreRangeEnd
      } else {
        scoreRange = ''
      }

      let data = {
        ...this.userTypeForm,
        registerChannel: this.userTypeForm.registerChannel ? this.userTypeForm.registerChannel.join(',') : '',
        mobileProvince: mobileProvince,
        registerDateRange: registerDateRange,
        lastLoginDateRange: lastLoginDateRange,
        loginDaysRange: loginDaysRange,
        scoreRange: scoreRange,
        os: this.userTypeForm.os === 0 ? null : this.userTypeForm.os,
        age:age,
        clickCount:clickCount,
      }
      if (this.queryForm.selectType === 2) {
        return data
      } else {
        return {}
      }
    },
    // 封装afterForm
    afterFormRes () {
      if (this.queryForm.clickAction !== 1) {
        let data = {}
        if (this.queryForm.clickAction === 2 || this.queryForm.clickAction === 3) {
          data = {
            linkUrl: this.afterForm.linkUrl,
          }
        }
        if (this.queryForm.clickAction === 4) {
          if (this.afterForm.pageTag !== 'product' && this.afterForm.pageTag !== 'JRCS_SYFLCPLB') {
            data = {
              pageType: 1,
              linkUrl: this.afterForm.pageTag,
            }
          }
          if (this.afterForm.pageTag === 'product') {
            data = {
              pageType: 2,
              productId: this.afterForm.productId,
              linkId: this.afterForm.linkId,
            }
          }
          if (this.afterForm.pageTag === 'JRCS_SYFLCPLB') {
            data = {
              pageType: 1,
              category: this.afterForm.category,
              className: this.afterForm.className,
              linkUrl: this.afterForm.pageTag,
            }
          }
        }
        return data
      } else {
        return {}
      }
    },
    addItem (type) {
      this.userTypeForm[type].push({
        time: '',
      })
    },
    delItem (index, type) {
      this.userTypeForm[type].splice(index, 1)
    },
    changeSelectType () {
      this.$refs['totalForm'].clearValidate(['userTypeSeq','numbers'])
      this.userTypeForm = {
        os: 0,
        registerChannel: [],
        mobileProvince: [],
        loginDays: ['', ''],
        scoreRange: ['', ''],
        age: ['', ''],
        clickCount: ['', ''],
        careers:[],
        recommend:null,
        registerDateRange: [
          {
            time: '',
          },
        ],
        lastLoginDateRange: [
          {
            time: '',
          },
        ],
      }
      this.file.name = ''
      this.queryForm.numbers = ''
      this.queryForm.userTypeSeq = ''
      this.queryForm.filePath = ''
    },
    down () {
      window.location.href = this.file.fdfsDomain + this.queryForm.filePath
    },
    upLoadSuccess (res, file) {
      if (res.respCode === '1000') {
        this.file = file
        this.queryForm.filePath = res.body.filePath
        this.file.fdfsDomain = res.body.fdfsDomain
      } else {
        this.$message.error(res.respMsg)
      }
      console.log(res)
    },
  },
}
</script>
<style lang="scss" scoped>
.font{
      color: #999999
    }
</style>
