<template>
  <div>
    <el-tabs v-model="queryForm.productLine"
             @tab-click="changePro">
      <el-tab-pane label="花钱无忧"
                   name="1">
      </el-tab-pane>
      <el-tab-pane label="贷款王"
                   name="2">
      </el-tab-pane>
      <el-tab-pane label="立即借"
                   name="5">
      </el-tab-pane>
    </el-tabs>
    <el-form :inline="true"
             :model="queryForm"
             size="mini"
             class="margin-mini">
      <el-form-item label="推送计划名称:">
        <el-input 
          v-model="queryForm.planName"
        ></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary"
                   size="mini"
                   @click="fetchData()">
          查询
        </el-button>
        <el-button type="primary"
                   size="mini"
                   @click="reset()">
          重置
        </el-button>
      </el-form-item>
    </el-form>
    <el-table :data="tableData"
              stripe
              border
              width="100%"
              :loading="loading">
      <el-table-column prop="planCode"
                       label="推送计划ID">
      </el-table-column>
      <el-table-column label="推送计划名称"
                       prop="planName">
        <template slot-scope="scope">
          <span class="btnText"
                @click="push(scope.row,false)">{{ scope.row.planName }}</span>
        </template>
      </el-table-column>
      <el-table-column label="目标用户"
                       prop="selectType">
        <template slot-scope="scope">
          <span>
            {{ selectTypeList[`${scope.row.selectType}`] }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="计划推送时间"
                       prop="planExecTime">
        <template slot-scope="scope">
          <span v-if="scope.row.planExecType ===3 && scope.row.day && scope.row.day.length != 31">
            {{ `每月${scope.row.day}号${scope.row.datTime}` }}
          </span>
          <span v-else-if="scope.row.planExecType ===3 && scope.row.day && scope.row.day.length == 31">
            {{ `每月 每天 ${scope.row.datTime}` }}
          </span>
          <span v-else>
            {{ scope.row.planExecTime }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="创建时间"
                       prop="createAt">
        <template slot-scope="scope">
          <span>
            {{ scope.row.createAt | parseTime }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="推送状态"
                       prop="planExecStatus">
        <template slot-scope="scope">
          <span>
            {{ planExecStatusList[`${scope.row.planExecStatus}`] }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="启用状态"
                       prop="planStatus">
        <template slot-scope="scope">
          <span>
            {{ planStatusList[`${scope.row.planStatus}`] }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="操作"
                       prop="standardValue">
        <template slot-scope="scope">
          <el-button v-if="scope.row.planStatus === 2 "
                     type="text"
                     @click="push(scope.row,true)">
            修改
          </el-button>
          <el-button v-if="scope.row.planStatus === 2 "
                     type="text"
                     @click="updateStatus(scope.row,'启用')">
            启用
          </el-button>
          <el-button v-if="scope.row.planStatus === 1"
                     type="text"
                     @click="updateStatus(scope.row,'禁用')">
            禁用
          </el-button>
        </template>
      </el-table-column>
    </el-table> 
    <div class="pagination-container">
      <el-pagination :current-page.sync="pagination.pageNum"
                     :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange">
      </el-pagination>
    </div>
  </div>
</template>
<script>
import api from '../../api/app7.1/pushPlan'
export default {
  components: {

  },
  data () {
    return {
      selectTypeList: {
        1: '全部用户',
        2: '筛选用户',
        3: '用户类型',
        4: '导入用户',
      },
      planExecStatusList: {
        1: '未推送',
        2: '推送中',
        3: '推送完成',
      },
      planStatusList: {
        1: '启用',
        2: '禁用',
      },
      loading: false,
      queryForm: {
        planName: '',
        productLine: '1',
      },
      tableData: [],
      pagination: {
        pageNum: 1,
        pageSize: 30,
        total: 0,
        pageSizes: [10, 30, 50, 100],
      },
    }
  },
  created () {
    if (this.$route.query.productLine) {
      this.queryForm.productLine = this.$route.query.productLine + ''
    }
    this.fetchData()
  },
  methods: {
    push (val, type) {
      this.$router.push({name: '推送配置', params: {planCode: val.planCode, edit: type}})
    },
    calculateDiffTime (selectTime) {
      let now = new Date().getTime()
      let timeDiff = selectTime - now
      let minute = timeDiff / 1000 / 60
      minute = minute || ''
      return minute
    },
    async updateStatus (val, str) {
      try {
        if (str === '启用') {
          if (val.planExecType === 2) {
            let selectTime = new Date(val.planExecTime).getTime()
            let time = this.calculateDiffTime(selectTime)
            if (time < 1) {
              return this.$message.error('定时推送时间不能早于当前时间')
            }
          }
        }
        let string = `确认要${str}本计划吗？`
        let confirm = await this.$confirm(string, '提示', { type: 'warning', confirmButtonText: '确认' })
        if (confirm) {
          let data = {
            planCode: val.planCode,
            planStatus: val.planStatus === 1 ? 2 : 1,
          }
          let res = await api.updateStatus(data)
          if (res.data.respCode === '1000') {
            this.$message.success('操作成功')
            this.fetchData()
          } else {
            this.$message.error(res.data.respMsg)
          }
        }
      } catch (error) {
        console.log(error)
      }
    },
    changePro () {
      this.pagination.pageNum = 1
      this.fetchData()
    },
    async fetchData () {
      this.loading = true
      let data = {
        ...this.queryForm,
        pageNum: this.pagination.pageNum,
        pageSize: this.pagination.pageSize,
      }
      let res = await api.query(data)
      this.loading = false
      if (res.data.respCode === '1000') {
        res.data.body.list.forEach((t) => {
          if (t.planExecType === 3) {
            let day = ''
            let datTime = ''
            let index = t.planExecTime.indexOf(' ')
            day = t.planExecTime.substring(0, index)
            if (day.indexOf('*') > -1) {
              day = []
              for (let i = 1; i < 32; i++) {
                day.push(i)
              }
            } else {
              day = JSON.parse(day)
            }
            datTime = t.planExecTime.substring(index)
            if (datTime.length < 8) {
              datTime = datTime + ':00'
            }
            t.day = day
            t.datTime = datTime
          }
        })
        this.tableData = res.data.body.list
        this.pagination.total = res.data.body.total
      }
    },
    reset () {
      this.queryForm.planName = ''
      this.fetchData()
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNum = val
      this.fetchData()
    },
  },
}
</script>