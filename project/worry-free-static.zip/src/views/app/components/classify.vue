<!-- 组件说明 -->
<template>
  <div>
    <el-button type="primary"
               size="mini"
               class="least mt-5"
               @click="add()">
      添加
    </el-button>
    <el-button v-if="showType === '中部banner' || showType === '首页分类'"
               type="primary"
               size="mini"
               class="least"
               @click="saveSort()">
      提交生效
    </el-button>
    <p style="color:red;font-size:12px;">
      {{ titleInfo }}
    </p>
    <el-table :data="tableDataObj[classifyCode]"
              stripe
              border
              width="100%">
      <el-table-column v-if="showType === '首页分类'"
                       prop="idStr"
                       :label="titileID[classifyCode] +'-ID'">
      </el-table-column>
      <el-table-column v-if="showType !== '首页分类'"
                       prop="id"
                       :label="titileID[classifyCode] +'-ID'">
      </el-table-column>
      <el-table-column prop="advertisementName"
                       :label="mainTitle"
                       width="100">
      </el-table-column>
      <el-table-column v-if="showType === '中部banner'"
                       prop="subTitle"
                       label="副标题">
      </el-table-column>
      <el-table-column prop="img"
                       :label="iconTitle">
        <template slot-scope="scope">
          <img :src="scope.row.img"
               style="width:35px;height:35px">
        </template>
      </el-table-column>
      <el-table-column prop="clickTo"
                       label="点击去向">
        <template slot-scope="scope">
          <span>{{ clickToList[scope.row.clickTo] }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="linkName"
                       label="选择链接">
        <template slot-scope="scope">
          <span v-if="scope.row.clickTo === '2'">{{ scope.row.linkName }}</span>
          <span v-else> -- </span>
        </template>
      </el-table-column>
      <el-table-column prop="linkAddress"
                       label="链接地址">
        <template slot-scope="scope">
          <span v-if="scope.row.clickTo === '2'">{{ scope.row.linkName }}</span>
          <span v-else> -- </span>
        </template>
      </el-table-column>
      <el-table-column prop="advertisementStatus"
                       label="状态">
        <template slot-scope="scope">
          <div class="product-status">
            <span>
              <span v-if="scope.row.advertisementStatus"
                    style="color:green;">启用</span>
              <span v-else
                    style="color:red">停用</span>
            </span>
            <span
              @click.capture.stop="disableStatus(scope.row)"
            >
              <el-switch
                v-model="scope.row.advertisementStatus"
                :active-value="1"
                :inactive-value="0"
                active-color="#13ce66"
                inactive-color="#ff4949">
              </el-switch>
            </span>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="updateAt"
                       label="最后修改时间">
        <template slot-scope="scope">
          {{ scope.row.updateAt | parseTime }}
        </template>
      </el-table-column>
      <el-table-column prop="operator"
                       label="操作人">
      </el-table-column>
      <el-table-column prop="value"
                       label="操作">
        <template slot-scope="scope">
          <el-button type="primary"
                     size="mini"
                     @click="edit(scope.row)">
            编辑
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <div v-if="showType !== '首页分类' && showType !== '中部banner'"
         class="pagination-container">
      <el-pagination :current-page.sync="pagination.pageNo"
                     :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange">
      </el-pagination>
    </div>
    <!-- 添加编辑自定义开屏广告 -->
    <el-dialog :visible.sync="addOrEditShow"
               :title="addOrEditTitle + titileID[classifyCode]"
               @close="closeOpenAD">
      <el-form ref="addFormDom"
               :model="addForm"
               size="mini"
               :rules="rules"
               label-width="120px">
        <el-form-item :label="addFormTitle"
                      prop="advertisementName">
          <el-input v-model="addForm.advertisementName"
                    :maxlength="maxlengthCalc"
                    :placeholder=" '限' + maxlengthCalc + '个字'"
                    class="length-1">
          </el-input>
          <span class="font-info">{{ '限' + maxlengthCalc + '个字' }}</span>               
        </el-form-item>

        <el-form-item v-if="showType === '中部banner'"
                      label="副标题"
                      prop="subTitle">
          <el-input v-model="addForm.subTitle"
                    :maxlength="10"
                    placeholder="限10个字"
                    class="length-1">
          </el-input>
          <span class="font-info">限10个字</span>                         
        </el-form-item>
        <el-form-item :label="iconTitle"
                      prop="img">
          <el-upload ref="uploadFile"
                     class="upload-user-defined"
                     name="in"
                     :auto-upload="false"
                     action="url"
                     :show-file-list="false"
                     :with-credentials="true"
                     :on-change="UploadChange"
                     :disabled="uploading">
            <el-button size="mini"
                       type="primary"
                       :loading="uploading">
              选择文件
            </el-button>
            <span class="font-info">{{ picWidth }}</span>
          </el-upload>
        </el-form-item>
        <el-form-item label=""
                      prop="img">
          <div v-if="addForm.img"
               class="parentPosition">
            <img :src="addForm.img"
                 style="max-height:400px;max-width:300px">
            <el-button class="son"
                       type="danger"
                       size="mini"
                       @click="deletePic()">
              删除
            </el-button>
          </div>
        </el-form-item>

        <el-form-item label="点击去向"
                      prop="clickTo"> 
          <el-select v-model="addForm.clickTo">
            <el-option value="1"
                       label="精准推荐系统匹配">
            </el-option>
            <el-option value="2"
                       label="指定链接">
            </el-option>
          </el-select>                        
        </el-form-item>

        <el-form-item v-if="addForm.clickTo === '2'"
                      label="选择链接"
                      prop="linkId">
          <el-select v-model="addForm.linkId"
                     @change="changeLink">
            <el-option
              v-for="(item,index) in linksAll"
              :key="index"
              :value="item.id"
              :label="item.linkName"
            >
            </el-option>
          </el-select>                        
        </el-form-item>
        <el-form-item v-if="addForm.linkId !=='' && addForm.linkId!==null && addForm.clickTo === '2'"
                      label="链接地址"
                      prop="linkAddress">
          <span>{{ addForm.linkAddress }}</span>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="addOrEditShow = false">
          取消
        </el-button>
        <el-button type="primary"
                   @click="save">
          确认
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import api from '../../../api/app7.0/openAdvertising'
import commonApi from '../../../api/incomeApi/common.js'
export default {
  components: {

  },
  props: ['channelId', 'classifyCode', 'tableDataObj', 'pagination'],
  data () {
    return {
      linksAll: [],
      clickToList: {
        1: '精准推荐系统匹配',
        2: '指定链接',
      },
      uploading: false,
      titileID: {
        1: '首页分类-1',
        2: '首页分类-2',
        3: '首页分类-3',
        4: '首页分类-4',
        7: '中部banner-1',
        8: '中部banner-2',
        21: '首页悬浮广告',
        23: '中部banner-3',
        24: '首页主列表-硬广位1',
        25: '首页主列表-硬广位2',
        26: '贷款大全-硬广位1',
        27: '贷款大全-硬广位2',
        28: '我的-硬广位',
      },
      addOrEditShow: false,
      addOrEditTitle: '添加',
      addForm: {
        id: null,
        linkId: '',
        img: '',
        advertisementName: '',
        linkAddress: '',
        clickTo: '',
        subTitle: '',
      },
      rules: {
        subTitle: [
          { required: true, message: '请选择', trigger: 'blur' },
        ],
        advertisementName: [
          { required: true, message: '请填写', trigger: 'blur' },
        ],
        img: [
          { required: true, message: '请上传图片', trigger: 'change' },
        ],
        linkId: [
          { required: true, message: '请选择', trigger: 'change' },
        ],
        clickTo: [
          { required: true, message: '请选择', trigger: 'change' },
        ],
      },
    }
  },
  computed: {
    showType () {
      if (['1', '2', '3', '4'].includes(this.classifyCode)) {
        return '首页分类'
      } else if (['7', '8', '23'].includes(this.classifyCode)) {
        return '中部banner'
      } else if (['24', '25', '26', '27', '28'].includes(this.classifyCode)) {
        return '新增硬广'
      } else if (['21'].includes(this.classifyCode)) {
        return '悬浮广告'
      } else {
        return 'other'
      }
    },
    iconTitle () {
      if (this.showType === '首页分类') return '图标'
      return '图片'
    },
    mainTitle () {
      if (this.showType === '中部banner') return '主标题'
      return '广告名称'
    },
    addFormTitle () {
      if (this.showType === '中部banner') {
        return '主标题'
      } else if (this.showType === '新增硬广' || this.showType === '悬浮广告') {
        return '广告名称'
      } else {
        return '分类名称'
      }
    },
    maxlengthCalc () {
      if (this.showType === '新增硬广' || this.showType === '悬浮广告') return 15
      return 6
    },
    titleInfo () {
      if (this.showType === '新增硬广') {
        return '*仅可同时启用一个，若已有启用的广告，再启用另一个时，前一个将自动停用。若全部停用，则前端不展示该硬广位。'
      } else if (this.showType === '悬浮广告') {
        return '*若已有启用的分类，再启用另一个时，前一分类将自动停用。可全部停用，全部停用后哦，前端将不展示悬浮广告'
      } else {
        return '*必须有切只有一个在开启状态。点击上方"提交生效"按钮后，APP前端才会生效'
      }
    },
    picWidth () {
      // if (['1', '2', '3', '4'].includes(this.classifyCode)) {
      //   return '首页分类'
      // } else if (['7', '8', '23'].includes(this.classifyCode)) {
      //   return '中部banner'
      // } else if (['24', '25', '26', '27', '28'].includes(this.classifyCode)) {
      //   return '新增硬广'
      // } else if (['21'].includes(this.classifyCode)) {
      //   return '悬浮广告'
      // } else {
      //   return 'other'
      // }
      if (this.showType === '首页分类') {
        return '(图片尺寸86*86px)'
      } else if (['7'].includes(this.classifyCode)) {
        return '(图片尺寸210*134px)'
      } else if (['8', '23'].includes(this.classifyCode)) {
        return '(图片尺寸180*110px)'
      } else if (['24', '25', '26', '27', '28'].includes(this.classifyCode)) {
        return '(图片尺寸：678*180px)'
      } else if (this.showType === '悬浮广告') {
        return '(图片尺寸160*160px，支持gif动图)'
      } else {
        return '(图片尺寸750*180px)'
      }
    },
  },
  created () {
    this.fetchLinks()
  },
  methods: {
    deletePic () {
      this.addForm.img = ''
    },
    add () {
      this.fetchLinks()
      this.addForm = {
        id: null,
        linkId: '',
        img: '',
        advertisementName: '',
        linkAddress: '',
        clickTo: '1',
      }
      this.addOrEditTitle = '添加'
      this.addOrEditShow = true
    },
    async edit (row) {
      let res = await api.getAdvertsLinkById(row.linkId)
      if (res.data.respCode === '1000') {
        let flag = false
        this.linksAll.forEach((t) => {
          if (t.id === row.linkId) {
            flag = true
          }
        })
        if (!flag) {
          this.linksAll.push(res.data.body)
        }
      } else {
        return this.$_message.error(res.data.respMsg)
      }
      this.addOrEditTitle = '编辑'
      let linkAddress = ''
      this.linksAll.forEach((t) => {
        if (t.id === row.linkId) {
          linkAddress = t.linkAddress
        }
      })
      this.addForm = {
        id: row.id,
        linkId: row.linkId === 0 ? '' : row.linkId,
        img: row.img,
        clickTo: row.clickTo,
        advertisementName: row.advertisementName,
        linkAddress: linkAddress,
        subTitle: row.subTitle,
      }
      this.addOrEditShow = true
    },
    saveSort () {
      let arr1 = ['1', '2', '3', '4']
      let arr2 = ['7', '8', '23']
      if (arr1.includes(this.classifyCode)) {
        this.validateClassify()
      }
      if (arr2.includes(this.classifyCode)) {
        this.validateBanner()
      }
    },
    async validateBanner () {
      let flag1 = 0
      let flag2 = 0
      let flag3 = 0
      let strArr = []
      this.tableDataObj['7'].forEach((t) => {
        if (t.advertisementStatus === 1) flag1++
      })
      this.tableDataObj['8'].forEach((t) => {
        if (t.advertisementStatus === 1) flag2++
      })
      this.tableDataObj['23'].forEach((t) => {
        if (t.advertisementStatus === 1) flag3++
      })
      if (flag1 !== 1 && this.tableDataObj['7'].length) strArr.push('中部banner-1')
      if (flag2 !== 1 && this.tableDataObj['8'].length) strArr.push('中部banner-2')
      if (flag3 !== 1 && this.tableDataObj['23'].length) strArr.push('中部banner-3')
      if (strArr.length > 0) {
        let str = '请更正' + strArr.join('、') + '的状态。提交时请保证中部banner下有且只有一个在启用中'
        this.$alert(str, '提示:', {
          confirmButtonText: '我知道了',
          showClose: false,
          dangerouslyUseHTMLString: false,
        })
        return
      }
      try {
        let str = '提交后，中部banner-1、中部banner-2、中部banner-3、会同时修改为当前启用的图片、主标题、副标题，你确定要提交吗？'
        let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '启用' })
        if (confirm) {
          let arr1 = this.tableDataObj['7'].map((t) => ({
              id: t.id,
              advertisementStatus: t.advertisementStatus,
            }))
          let arr2 = this.tableDataObj['8'].map((t) => ({
              id: t.id,
              advertisementStatus: t.advertisementStatus,
            }))
          let arr3 = this.tableDataObj['23'].map((t) => ({
              id: t.id,
              advertisementStatus: t.advertisementStatus,
            }))
          let data = {
            updateAdvertisementList: arr1.concat(arr2).concat(arr3),
          }
          let res = await api.batchUpdateStatus(data)
          if (res.data.respCode === '1000') {
            this.$parent.clearAllTable()
            this.$parent.fetchMaxTable()
            this.$_message.success('操作成功')
          } else {
            this.$_message.error('操作成功')
          }
        }
      } catch (error) {
        //
      }
    },
    async validateClassify () {
      let flag1 = 0
      let flag2 = 0
      let flag3 = 0
      let flag4 = 0
      let strArr = []
      this.tableDataObj['1'].forEach((t) => {
        if (t.advertisementStatus === 1) flag1++
      })
      this.tableDataObj['2'].forEach((t) => {
        if (t.advertisementStatus === 1) flag2++
      })
      this.tableDataObj['3'].forEach((t) => {
        if (t.advertisementStatus === 1) flag3++
      })
      this.tableDataObj['4'].forEach((t) => {
        if (t.advertisementStatus === 1) flag4++
      })
      if (flag1 !== 1 && this.tableDataObj['1'].length) strArr.push('首页分类-1')
      if (flag2 !== 1 && this.tableDataObj['2'].length) strArr.push('首页分类-2')
      if (flag3 !== 1 && this.tableDataObj['3'].length) strArr.push('首页分类-3')
      if (flag4 !== 1 && this.tableDataObj['4'].length) strArr.push('首页分类-4')
      if (strArr.length) {
        let str = '请更正' + strArr.join('、') + '的状态。提交时请保证每个首页分类下有且只有一个在启用中'
        this.$alert(str, '提示:', {
          confirmButtonText: '我知道了',
          showClose: false,
          dangerouslyUseHTMLString: false,
        })
        return
      }
      try {
        let str = '提交后，首页分类-1、首页分类-2、首页分类-3、首页分类-4会同时修改为当前启用的分类图标和名称，你确定要提交吗？'
        let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '启用' })
        if (confirm) {
          let arr1 = this.tableDataObj['1'].map((t) => ({
              id: t.id,
              advertisementStatus: t.advertisementStatus,
            }))
          let arr2 = this.tableDataObj['2'].map((t) => ({
              id: t.id,
              advertisementStatus: t.advertisementStatus,
            }))
          let arr3 = this.tableDataObj['3'].map((t) => ({
              id: t.id,
              advertisementStatus: t.advertisementStatus,
            }))
          let arr4 = this.tableDataObj['4'].map((t) => ({
              id: t.id,
              advertisementStatus: t.advertisementStatus,
            }))
          let data = {
            updateAdvertisementList: arr1.concat(arr2).concat(arr3).concat(arr4),
          }
          let res = await api.batchUpdateStatus(data)
          if (res.data.respCode === '1000') {
            this.$_message.success('操作成功')
            this.$parent.clearAllTable()
            this.$parent.fetchMaxTable()
          } else {
            this.$_message.error('操作成功')
          }
        }
      } catch (error) {
        //
      }
    },

    save () {
      this.$refs['addFormDom'].validate(async (valid) => {
        if (!valid) {
          return false
        }
        const data = {
          id: this.addForm.id,
          classifyCode: parseInt(this.classifyCode),
          channelId: this.channelId,
          advertisementName: this.addForm.advertisementName,
          img: this.addForm.img,
          clickTo: this.addForm.clickTo,
          linkId: this.addForm.clickTo === '2' ? this.addForm.linkId : null,
          operator: this.$store.state.loginUser.userId,
          subTitle: this.showType === '中部banner' ? this.addForm.subTitle : '',
        }
        const res = await api.saveOrUpdateAD(data)
        if (res.data.respCode === '1000') {
          this.$_message.success('操作成功')
          this.addOrEditShow = false
          this.$parent.clearMaxTable()
          this.$parent.fetchMaxTable()
        } else {
          this.$_message.error(res.data.respMsg)
        }
      })
    },
    async fetchTableData () {
      let data = {
        classifyCode: parseInt(this.classifyCode),
        channelId: this.channelId,
        pageIndex: this.pagination.pageNo,
        pageSize: this.pagination.pageSize,
      }
      let res = await api.list(data)
      if (res.data.respCode === '1000') {
        this.tableData = res.data.body.hardAdvertisementInfoVoList
        this.pagination.pageNo = res.data.body.pageIndex
        this.pagination.total = res.data.body.totalCount
      } else {
        this.$_message.error(res.data.respMsg)
      }
    },
    changeLink () {
      this.linksAll.forEach((t) => {
        if (t.id === this.addForm.linkId) {
          this.addForm.linkAddress = t.linkAddress
        }
      })
    },
    async fetchLinks () {
      let res = await api.getAllValidLinks()
      if (res.data.respCode === '1000') {
        this.linksAll = res.data.body.advertsLinkVos
      } else {
        this.$_message.error(res.data.respMsg)
      }
    },
    closeOpenAD () {
      this.$refs['addFormDom'].resetFields()
      this.$refs['uploadFile'] && this.$refs['uploadFile'].clearFiles()
    },
    disableStatus (row) {
      if (this.showType === '首页分类' || this.showType === '中部banner') {
        this.batchStatus(row)
      } else {
        this.singleStatus(row)
      }
    },
    async batchStatus (row) {
      if (!row.advertisementStatus) {
        const data = {
          id: row.id,
          advertisementStatus: 1,
        }
        let res = await api.updateStatus(data)
        if (res.data.respCode === '1000' && res.data.body) {
          try {
            let str = `您选择的链接【${row.linkName}】已被停用，是否重新启用这个链接？`
            let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '启用' })
            if (confirm) {
              const pra = {
                advertisementId: row.id,
                linkId: row.linkId,
                operator: this.$store.state.loginUser.userId,
              }
              let res1 = await api.updateLinkAndAdvertisementStatus(pra)
              if (res1.data.respCode === '1000') {
                this.$_message.success(res.data.respMsg)
                row.advertisementStatus = 1
              } else {
                this.$_message.error(res.data.respMsg)
              }
            }
          } catch (error) {
            this.$message.warning('取消操作')
          }
        } else {
          row.advertisementStatus = 1
        }
      } else {
        row.advertisementStatus = 0
      }
    },
    async singleStatus (row) {
      const data = {
        id: row.id,
        advertisementStatus: row.advertisementStatus ? 0 : 1,
      }
      let res = await api.updateStatus(data)
      if (res.data.respCode === '1000' && res.data.body) {
        try {
          let str = `您选择的链接【${row.linkName}】已被停用，是否重新启用这个链接？`
          let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '启用' })
          if (confirm) {
            const pra = {
              id: row.id,
              linkId: row.linkId,
              operator: this.$store.state.loginUser.userId,
            }
            let res1 = await api.updateLinkAndAdvertisementStatus(pra)
            if (res1.data.respCode === '1000') {
              this.$_message.success(res1.data.respMsg)
              this.$parent.clearMaxTable()
              this.$parent.fetchMaxTable()
            } else {
              this.$parent.clearMaxTable()
              this.$parent.fetchMaxTable()
              this.$_message.error(res1.data.respMsg)
            }
          }
        } catch (error) {
          this.$message.warning('取消操作')
        }
      } else if (res.data.respCode === '1000' && !res.data.body) {
        this.$parent.clearMaxTable()
        this.$parent.fetchMaxTable()
      } else {
        this.$_message.error(res.data.respMsg)
      }
    },
    handleSizeChange (val) {
      this.$emit('changeData', val, 'size')
    },
    handleCurrentChange (val) {
      this.$emit('changeData', val, 'pageNo')
    },
    async UploadChange (file) {
      try {
        this.file = file.raw
        this.uploading = true
        let param = new window.FormData()
        param.append('file', this.file)
        let res = await commonApi.upload(param)
        if (res.data.respCode === '1000') {
          this.addForm.img = res.data.body
          this.uploading = false
        } else {
          this.$_message.error(res.data.respMsg)
          this.uploading = false
        }
      } catch (error) {
        this.uploading = false
      }
    },
  },
}
</script>

<style lang='scss' scoped>
.mt-5{
  margin-top:5px
}
.length-1{
  width: 250px
}
.font-info {
  color:#999999;
  font-size: 12px
}
.son{
  position: absolute;
  top:0;
  right:0
}
.parentPosition{
  position: relative;
  max-height:400px;
  max-width:300px
}
</style>