<!-- 组件说明 -->
<template>
  <div>
    <!-- 开屏广告 -->
    <el-dialog :visible.sync="$store.state.appManage.picDialog.show"
               top="5vh">
      <span slot="title"
            class="dialog-title Foot-center">
        <span>{{ TAG_OBJ[classifyCode] + '图片管理' }}</span>
        <el-button type="primary"
                   size="mini"
                   @click="add()">添加</el-button>
        <el-button type="primary"
                   size="mini"
                   @click="saveConfig()">保存设置</el-button>
      </span>
      <p style="color:red;font-size:12px;">
        *点击右上角"保存设置"后状态和排序才会生效(排序从1开始，依次增加)
      </p>
      <el-table :data="tableData"
                stripe
                border
                width="100%">
        <el-table-column prop="id"
                         label="图片ID">
        </el-table-column>
        <el-table-column prop="imgName"
                         label="图片名称"
                         width="100">
        </el-table-column>
        
        <el-table-column prop="img"
                         label="图片">
          <template slot-scope="scope">
            <el-button type="text"
                       size="mini"
                       @click="openPic(scope.row)">
              点击查看
            </el-button>
          </template>
        </el-table-column>
        <el-table-column align="center"
                         prop="seq"
                         label="排序"
                         width="90">
          <template slot-scope="scope">
            <div class="pd">
              <el-input v-model.number="scope.row.seq"
                        size="mini"
                        type="number"
                        :min="1"
                        onkeypress="return(  /[0-9]/.test(String.fromCharCode(event.keyCode)))"></el-input>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="bannerStatus"
                         label="状态">
          <template slot-scope="scope">
            <div class="product-status">
              <span>
                <span v-if="scope.row.status"
                      style="color:green;">启用</span>
                <span v-else
                      style="color:red">停用</span>
              </span>
              <span
              >
                <el-switch
                  v-model="scope.row.status"
                  :active-value="1"
                  :inactive-value="0"
                  active-color="#13ce66"
                  inactive-color="#ff4949">
                </el-switch>
              </span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="updateAt"
                         label="最近修改时间">
          <template slot-scope="scope">
            {{ scope.row.updateAt | parseTime }}
          </template>
        </el-table-column>
        <el-table-column prop="operator"
                         label="操作人">
        </el-table-column>
        <el-table-column prop="value"
                         label="操作">
          <template slot-scope="scope">
            <el-button type="primary"
                       size="mini"
                       @click="edit(scope.row)">
              编辑
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-container">
        <el-pagination :current-page.sync="pagination.pageNo"
                       :page-sizes="pagination.pageSizes"
                       :page-size="pagination.pageSize"
                       layout="total, sizes, prev, pager, next, jumper"
                       :total="pagination.total"
                       @size-change="handleSizeChange"
                       @current-change="handleCurrentChange">
        </el-pagination>
      </div>
    </el-dialog>

    <el-dialog :visible.sync="picDialog.show"
               top="5vh">
      <span slot="title"
            class="dialog-title Foot-center">
        <span>{{ picDialog.pictitle }}</span>
      </span>
      <div style="overflow: hidden">
        <div>
          <img v-if="picDialog.show"
               :src="picDialog.picAddress"
               :style="{height:styleCompute[classifyCode].height,width:styleCompute[classifyCode].width}"
          >
        </div>
      </div>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="picDialog.show = false">取消</el-button>
      </span>
    </el-dialog>
    <el-dialog :visible.sync="addOrEditShow"
               :title="addOrEditTitle + TAG_OBJ[classifyCode] + '图片'"
               @close="closeOpenAD">
      <el-form ref="addFormDom"
               :model="addForm"
               size="mini"
               :rules="rules"
               label-width="120px">
        <el-form-item label="图片名称"
                      prop="imgName">
          <el-input v-model="addForm.imgName"
                    :maxlength="20"
                    placeholder="限20个字"
                    class="length-1">
          </el-input>
          <span class="font-info">限20个字</span>                         
        </el-form-item>
        <el-form-item label="图片"
                      prop="img">
          <el-upload ref="uploadFile"
                     class="upload-user-defined"
                     name="in"
                     :auto-upload="false"
                     action="url"
                     :show-file-list="false"
                     :with-credentials="true"
                     :on-change="UploadChange"
                     :disabled="uploading">
            <el-button size="mini"
                       type="primary"
                       :loading="uploading">
              选择文件
            </el-button>
            <span class="font">{{ picWidth[classifyCode] }}</span>
          </el-upload>
        </el-form-item>
        <el-form-item label=""
                      prop="">
          <div v-if="addForm.img"
               :style="{height:styleCompute[classifyCode].height,width:styleCompute[classifyCode].width}"
               class="parentPosition">
            <img :src="addForm.img"
                 :style="{height:styleCompute[classifyCode].height,width:styleCompute[classifyCode].width}">
            <el-button class="son"
                       type="danger"
                       size="mini"
                       @click="deletePic()">
              删除
            </el-button>
          </div>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="addOrEditShow = false">
          取消
        </el-button>
        <el-button type="primary"
                   @click="save">
          确认
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import api from '../../../api/app7.0/picApi'
import commonApi from '../../../api/incomeApi/common.js'
import { TAG_OBJ } from '../app'
export default {
  components: {

  },
  props: ['channelId', 'classifyCode'],
  data () {
    return {
      TAG_OBJ:TAG_OBJ,
      type: {

      },
      picWidth:{
        18:'(开屏广告图片尺寸750*1084px)',
        6:'(首页banner图片尺寸678*180px)',
        20:'(弹窗广告图片尺寸574*640px)',
      },
      styleCompute:{
        18:{width:'750px',height:'1084px'},
        6:{width:'678px',height:'180px'},
        20:{width:'574px',height:'640px'},
      },
      file: null,
      linksAll: [],
      uploading: false,
      picDialog: {
        show: false,
        pictitle: '',
        picAddress: '',
      },
      addOrEditShow: false,
      addOrEditTitle: '添加',
      addForm: {
        id: null,
        img: '',
        imgName: '',
      },
      rules: {
        imgName: [
          { required: true, message: '请填写图片名称', trigger: 'blur' },
        ],
        img: [
          { required: true, message: '请上传图片', trigger: 'change' },
        ],
        linkId: [
          { required: true, message: '请选择', trigger: 'none' },
        ],
        clickTo: [
          { required: true, message: '请选择', trigger: 'none' },
        ],
      },
      tableData: [],
      pagination: {
        pageNo: 1,
        pageSizes: [30, 50, 100, 200],
        pageSize: 100,
        total: 0,
      },
    }
  },
  methods: {
    // 判断填写排序是不是连续的方法
    arrange(source) {
    let t;
    let ta;
    let r = [];
    source.forEach(function(v) {
          if (t === v) {
              ta.push(t);
              t++;
              return;
          }
          ta = [v];
          t = v + 1;
          r.push(ta);
      });

      return r;
  },
    deletePic () {
      this.addForm.img = ''
    },
    add () {
      this.addForm = {
        id: null,
        img: '',
        imgName: '',
      }
      this.addOrEditTitle = '添加'
      this.addOrEditShow = true
    },
    closeOpenAD () {
      this.$refs['addFormDom'].resetFields()
      this.$refs['uploadFile'] && this.$refs['uploadFile'].clearFiles()
    },
    save () {
      this.$refs['addFormDom'].validate(async (valid) => {
        if (!valid) {
          return false
        }
        const data = {
          id: this.addForm.id,
          classifyCode: parseInt(this.classifyCode),
          channelId: this.channelId,
          imgName: this.addForm.imgName,
          img: this.addForm.img,
          operator: this.$store.state.loginUser.userId,
        }
        const res = await api.saveOrUpdate(data)
        if (res.data.respCode === '1000') {
          this.$_message.success('操作成功')
          this.addOrEditShow = false
          this.fetchPicList()
        } else {
          this.$_message.error(res.data.respMsg)
        }
      })
    },
   async saveConfig () {
      for (let i = 0; i < this.tableData.length; i++) {
          if ((this.tableData[i].seq === '' || this.tableData[i].seq === null) && (this.tableData[i].status)) {
            this.$message.warning(`启用的图片请填写排序`)
            return
          }
        }
        let sort = []
        this.tableData.forEach((v) =>{
          if(v.status) {
            sort.push(v.seq)
          }
        })
        if (sort.length > 1) {
          let nary = sort.sort()
          for (let i = 0; i < sort.length; i++) {
            if (nary[i] === nary[i + 1]) {
              this.$message.warning(`排序数字不能重复`)
              return
            }
          }
        }
        sort =  this.arrange(sort)
        if(sort.length !== 1 && sort.length !== 0) {
          this.$message.warning(`请填写连续的排序数字`)
          return
        }
        try {
          let confirm = await this.$confirm('确认保存设置吗？', '提示', { type: 'warning', confirmButtonText: '保存设置' })
          if (confirm) {
            const updateBannerList = this.tableData.map((t) => ({
                id: t.id,
                seq: t.seq,
                status: t.status,
                'channelId':this.channelId,
                'classifyCode':parseInt(this.classifyCode),
              }))
             
            let res = await api.saveSeqAndStatus(updateBannerList)
            if (res.data.respCode === '1000') {
              this.$_message.success('操作成功')
              this.fetchPicList()
            } else {
              this.$_message.error(res.data.respMsg)
            }
          }
        } catch (error) {
          console.log(error)
        }
    },
    // async fetchLinks () {
    //   let res = await api.getAllValidLinks()
    //   if (res.data.respCode === '1000') {
    //     this.linksAll = res.data.body.advertsLinkVos
    //   } else {
    //     this.$_message.error(res.data.respMsg)
    //   }
    // },
    async fetchPicList () {
      let data = {
        classifyCode: parseInt(this.classifyCode),
        channelId: this.channelId,
        pageNum: this.pagination.pageNo,
        pageSize: this.pagination.pageSize,
      }
      let res = await api.list(data)
      if (res.data.respCode === '1000') {
        this.tableData = res.data.body.list
        this.pagination.pageNo = res.data.body.pageNum
        this.pagination.total = res.data.body.total
      } else {
        this.$_message.error(res.data.respMsg)
      }
    },
     edit (row) {
      // let res = await api.getAdvertsLinkById(row.linkId)
      // if (res.data.respCode === '1000') {
      //   let flag = false
      //   this.linksAll.forEach((t) => {
      //     if (t.id === row.linkId) {
      //       flag = true
      //     }
      //   })
      //   if (!flag) {
      //     this.linksAll.push(res.data.body)
      //   }
      // } else {
      //   return this.$_message.error(res.data.respMsg)
      // }
      // let linkAddress = ''
      // this.linksAll.forEach((t) => {
      //   if (t.id === row.linkId) {
      //     linkAddress = t.linkAddress
      //   }
      // })
      this.addForm = {
        id: row.id,
        img: row.img,
        imgName: row.imgName,
      }
      this.addOrEditShow = true
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchOpenADList()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchOpenADList()
    },
    openPic (row) {
      this.picDialog.pictitle = row.advertisementName
      this.picDialog.picAddress = row.img
      this.picDialog.show = true
    },
    async disableAD (row) {
      const data = {
        id: row.id,
        advertisementStatus: row.advertisementStatus ? 0 : 1,
      }
      let res = await api.updateStatus(data)
      if (res.data.respCode === '1000' && res.data.body) {
        try {
          let str = `您选择的链接【${row.linkName}】已被停用，是否重新启用这个链接？`
          let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '启用' })
          if (confirm) {
            const pra = {
              advertisementId: row.id,
              linkId: row.linkId,
              operator: this.$store.state.loginUser.userId,
            }
            let res1 = await api.updateLinkAndAdvertisementStatus(pra)
            if (res1.data.respCode === '1000') {
              this.$_message.success(res1.data.respMsg)
              this.fetchOpenADList()
            } else {
              this.fetchOpenADList()
              this.$_message.error(res1.data.respMsg)
            }
          }
        } catch (error) {
          this.$message.warning('取消操作')
        }
      } else if (res.data.respCode === '1000' && !res.data.body) {
        this.fetchOpenADList()
      } else {
        this.$_message.error(res.data.respMsg)
      }
    },
    changeLink () {
      this.linksAll.forEach((t) => {
        if (t.id === this.addForm.linkId) {
          this.addForm.linkAddress = t.linkAddress
        }
      })
    },
    async UploadChange (file) {
      try {
        this.file = file.raw
        this.uploading = true
        let param = new window.FormData()
        param.append('file', this.file)
        let res = await commonApi.upload(param)
        if (res.data.respCode === '1000') {
          this.addForm.img = res.data.body
          this.uploading = false
        } else {
          this.$_message.error(res.data.respMsg)
          this.uploading = false
        }
      } catch (error) {
        this.uploading = false
      }
    },
  },
}
</script>

<style lang='scss' scoped>
.length-1{
  width: 250px
}
.font-info {
  color:#999999;
  font-size: 12px
}
.son{
  position: absolute;
  top:0;
  right:0
}
.parentPosition{
  position: relative;
}
</style>