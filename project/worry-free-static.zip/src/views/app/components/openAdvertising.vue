<!-- 组件说明 -->
<template>
  <div>
    <!-- 开屏广告 -->
    <el-dialog :visible.sync="$store.state.appManage.openAdvertise.show">
      <span slot="title"
            class="dialog-title Foot-center">
        <span>{{ titleShow }}</span>
        <el-button type="primary"
                   size="mini"
                   @click="add()">添加</el-button>
        <el-button type="primary"
                   size="mini"
                   @click="saveConfig()">保存设置</el-button>
      </span>
      <p style="color:red;font-size:12px;">
        {{ titleInfo }}
      </p>
      <el-table :data="tableData"
                stripe
                border
                width="100%">
        <el-table-column prop="id"
                         :label="IDtitle">
        </el-table-column>
        <el-table-column prop="advertisementName"
                         label="广告名称"
                         width="100">
        </el-table-column>
        <el-table-column align="center"
                         prop="seq"
                         label="排序"
                         width="90">
          <template slot-scope="scope">
            <div class="pd">
              <el-input v-model.number="scope.row.seq"
                        size="mini"
                        type="number"
                        :min="1"
                        onkeypress="return(  /[0-9]/.test(String.fromCharCode(event.keyCode)))"></el-input>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="img"
                         label="图片">
          <template slot-scope="scope">
            <el-button type="text"
                       size="mini"
                       @click="openPic(scope.row)">
              点击查看
            </el-button>
          </template>
        </el-table-column>
        <el-table-column prop="linkName"
                         label="选择链接">
        </el-table-column>
        <el-table-column prop="linkAddress"
                         label="链接地址">
        </el-table-column>
        <el-table-column prop="advertisementStatus"
                         label="状态">
          <template slot-scope="scope">
            <div class="product-status">
              <span>
                <span v-if="scope.row.advertisementStatus"
                      style="color:green;">启用</span>
                <span v-else
                      style="color:red">停用</span>
              </span>
              <span
                @click.capture.stop="disableAD(scope.row)"
              >
                <el-switch
                  v-model="scope.row.advertisementStatus"
                  :active-value="1"
                  :inactive-value="0"
                  active-color="#13ce66"
                  inactive-color="#ff4949">
                </el-switch>
              </span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="updateAt"
                         label="最后修改时间">
          <template slot-scope="scope">
            {{ scope.row.updateAt | parseTime }}
          </template>
        </el-table-column>
        <el-table-column prop="operator"
                         label="操作人">
        </el-table-column>
        <el-table-column prop="value"
                         label="操作">
          <template slot-scope="scope">
            <el-button type="primary"
                       size="mini"
                       @click="edit(scope.row)">
              编辑
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-container">
        <el-pagination :current-page.sync="pagination.pageNo"
                       :page-sizes="pagination.pageSizes"
                       :page-size="pagination.pageSize"
                       layout="total, sizes, prev, pager, next, jumper"
                       :total="pagination.total"
                       @size-change="handleSizeChange"
                       @current-change="handleCurrentChange">
        </el-pagination>
      </div>
    </el-dialog>

    <!-- 查看图片 -->
    <el-dialog :visible.sync="picDialog.show">
      <span slot="title"
            class="dialog-title Foot-center">
        <span>{{ picDialog.pictitle }}</span>
      </span>
      <div style="overflow: hidden">
        <div>
          <img style="width: 200px; height: 200px;"
               :src="picDialog.picAddress">
        </div>
      </div>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="picDialog.show = false">取消</el-button>
      </span>
    </el-dialog>
    <!-- 添加编辑自定义开屏广告 -->
    <el-dialog :visible.sync="addOrEditShow"
               :title="addOrEditTitle + titleShow"
               @close="closeOpenAD">
      <el-form ref="addFormDom"
               :model="addForm"
               size="mini"
               :rules="rules"
               label-width="120px">
        <el-form-item label="广告名称"
                      prop="advertisementName">
          <el-input v-model="addForm.advertisementName"
                    :maxlength="15"
                    placeholder="限15个字"
                    class="length-1">
          </el-input>
          <span class="font-info">限15个字</span>                         
        </el-form-item>
        <el-form-item label="图片"
                      prop="img">
          <el-upload ref="uploadFile"
                     class="upload-user-defined"
                     name="in"
                     :auto-upload="false"
                     action="url"
                     :show-file-list="false"
                     :with-credentials="true"
                     :on-change="UploadChange"
                     :disabled="uploading">
            <el-button size="mini"
                       type="primary"
                       :loading="uploading">
              选择文件
            </el-button>
            <span class="font">{{ picWidth }}</span>
          </el-upload>
        </el-form-item>
        <el-form-item label=""
                      prop="img">
          <div v-if="addForm.img"
               class="parentPosition">
            <img :src="addForm.img"
                 style="max-height:300px;max-width:400px">
            <el-button class="son"
                       type="danger"
                       size="mini"
                       @click="deletePic()">
              删除
            </el-button>
          </div>
          <!-- <img :src="addForm.img" style="max-height:400px;max-width:300px"> -->
        </el-form-item>
        <el-form-item label="点击去向"
                      prop="clickTo"> 
          <el-select v-model="addForm.clickTo">
            <el-option value="1"
                       label="精准推荐系统匹配">
            </el-option>
            <el-option value="2"
                       label="指定链接">
            </el-option>
          </el-select>                        
        </el-form-item>
        <el-form-item v-if="addForm.clickTo === '2'"
                      label="选择链接"
                      prop="linkId">
          <el-select v-model="addForm.linkId"
                     @change="changeLink">
            <el-option
              v-for="(item,index) in linksAll"
              :key="index"
              :value="item.id"
              :label="item.linkName"
            >
            </el-option>
          </el-select>                        
        </el-form-item>
        <el-form-item v-if="addForm.linkId && addForm.clickTo === '2'"
                      label="链接地址"
                      prop="linkAddress">
          <span>{{ addForm.linkAddress }}</span>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="addOrEditShow = false">
          取消
        </el-button>
        <el-button type="primary"
                   @click="save">
          确认
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import api from '../../../api/app7.0/openAdvertising'
import commonApi from '../../../api/incomeApi/common.js'
export default {
  components: {

  },
  props: ['channelId', 'classifyCode'],
  data () {
    return {
      type: {

      },
      file: null,
      linksAll: [],
      uploading: false,
      picDialog: {
        show: false,
        pictitle: '',
        picAddress: '',
      },
      addOrEditShow: false,
      addOrEditTitle: '添加',
      addForm: {
        id: null,
        linkId: '',
        img: '',
        advertisementName: '',
        linkAddress: '',
        clickTo: '',
      },
      rules: {
        advertisementName: [
          { required: true, message: '请填写', trigger: 'blur' },
        ],
        img: [
          { required: true, message: '请上传图片', trigger: 'change' },
        ],
        linkId: [
          { required: true, message: '请选择', trigger: 'none' },
        ],
        clickTo: [
          { required: true, message: '请选择', trigger: 'none' },
        ],
      },
      tableData: [],
      pagination: {
        pageNo: 1,
        pageSizes: [30, 50, 100, 200],
        pageSize: 30,
        total: 0,
      },
    }
  },
  computed: {
    titleInfo () {
      if (this.classifyCode === '20') return '*点击右上角"保存设置"后状态和排序才会生效'
      return '*点击右上角"保存设置"后状态和排序才会生效'
    },
    titleShow () {
      if (this.classifyCode === '20') return '自定义弹窗广告'
      return '自定义开屏广告'
    },
    IDtitle () {
      if (this.classifyCode === '20') return '弹窗广告id'
      return '开屏广告ID'
    },
    picWidth () {
      if (this.classifyCode === '20') return '(弹窗广告图片尺寸574*640px)'
      return '(开屏广告图片尺寸750*1084px)'
    },
  },
  methods: {
    deletePic () {
      this.addForm.img = ''
    },
    add () {
      this.fetchLinks()
      this.addForm = {
        id: null,
        linkId: '',
        img: '',
        advertisementName: '',
        linkAddress: '',
        clickTo: '',
      }
      this.addOrEditTitle = '添加'
      this.addOrEditShow = true
    },
    closeOpenAD () {
      this.$refs['addFormDom'].resetFields()
      this.$refs['uploadFile'] && this.$refs['uploadFile'].clearFiles()
    },
    save () {
      this.$refs['addFormDom'].validate(async (valid) => {
        if (!valid) {
          return false
        }
        const data = {
          id: this.addForm.id,
          classifyCode: parseInt(this.classifyCode),
          channelId: this.channelId,
          advertisementName: this.addForm.advertisementName,
          img: this.addForm.img,
          linkId: this.addForm.linkId,
          operator: this.$store.state.loginUser.userId,
          clickTo:this.addForm.clickTo,
        }
        const res = await api.saveOrUpdateAD(data)
        if (res.data.respCode === '1000') {
          this.$_message.success('操作成功')
          this.addOrEditShow = false
          this.fetchOpenADList()
        } else {
          this.$_message.error(res.data.respMsg)
        }
      })
    },
   async saveConfig () {
      for (let i = 0; i < this.tableData.length; i++) {
          if ((!this.tableData[i].seq && this.tableData[i].seq !== '0') && (this.tableData[i].advertisementStatus)) {
            this.$message.warning(`请给启用的条目设置排序(不能为0)`)
            return
          }
        }
       let sort = []
        this.tableData.forEach((v) =>{
          if(v.seq) {
            sort.push(v.seq)
          }
        })
        console.log(sort)
        if (sort.length > 1) {
          let nary = sort.sort()
          for (let i = 0; i < sort.length; i++) {
            if (nary[i] === nary[i + 1]) {
              this.$message.warning(`排序数字不能重复`)
              return
            }
          }
        }
  
        try {
          let confirm = await this.$confirm('确认保存设置吗？', '提示', { type: 'warning', confirmButtonText: '保存设置' })
          if (confirm) {
            const updateBannerList = this.tableData.map((t) => ({
                id: t.id,
                seq: t.seq,
                advertisementStatus: t.advertisementStatus,
                'channelId':this.channelId,
                'classifyCode':parseInt(this.classifyCode),
              }))
             
            let res = await api.updateSeqAndStatus(updateBannerList)
            if (res.data.respCode === '1000') {
              this.$_message.success('操作成功')
              this.fetchOpenADList()
            } else {
              this.$_message.error(res.data.respMsg)
            }
          }
        } catch (error) {
          console.log(error)
        }
    },
    async fetchLinks () {
      let res = await api.getAllValidLinks()
      if (res.data.respCode === '1000') {
        this.linksAll = res.data.body.advertsLinkVos
      } else {
        this.$_message.error(res.data.respMsg)
      }
    },
    async fetchOpenADList () {
      let data = {
        classifyCode: parseInt(this.classifyCode),
        channelId: this.channelId,
        pageIndex: this.pagination.pageNo,
        pageSize: this.pagination.pageSize,
      }
      let res = await api.list(data)
      if (res.data.respCode === '1000') {
        this.tableData = res.data.body.hardAdvertisementInfoVoList
        this.pagination.pageNo = res.data.body.pageIndex
        this.pagination.total = res.data.body.totalCount
      } else {
        this.$_message.error(res.data.respMsg)
      }
    },
    async edit (row) {
      let res = await api.getAdvertsLinkById(row.linkId)
      if (res.data.respCode === '1000') {
        let flag = false
        this.linksAll.forEach((t) => {
          if (t.id === row.linkId) {
            flag = true
          }
        })
        if (!flag) {
          this.linksAll.push(res.data.body)
        }
      } else {
        return this.$_message.error(res.data.respMsg)
      }
      let linkAddress = ''
      this.linksAll.forEach((t) => {
        if (t.id === row.linkId) {
          linkAddress = t.linkAddress
        }
      })
      this.addForm = {
        id: row.id,
        linkId: row.linkId,
        img: row.img,
        advertisementName: row.advertisementName,
        linkAddress: linkAddress,
        clickTo:row.clickTo,
      }
      this.addOrEditShow = true
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchOpenADList()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchOpenADList()
    },
    openPic (row) {
      this.picDialog.pictitle = row.advertisementName
      this.picDialog.picAddress = row.img
      this.picDialog.show = true
    },
    async disableAD (row) {
      if (!row.advertisementStatus) {
          const data = {
            id: row.id,
            advertisementStatus: 1,
          }
          let res = await api.updateStatus(data)
          if (res.data.respCode === '1000' && res.data.body) {
            try {
              let str = `您选择的链接【${row.linkName}】已被停用，是否重新启用这个链接？`
              let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '启用' })
              if (confirm) {
                const pra = {
                  bannerId: row.id,
                  linkId: row.linkId,
                  operator: this.$store.state.loginUser.userId,
                }
                let res1 = await api.updateLinkAndAdvertisementStatus(pra)
                if (res1.data.respCode === '1000') {
                  this.$_message.success(res.data.respMsg)
                  row.advertisementStatus = 1
                } else {
                  this.$_message.error(res.data.respMsg)
                }
              }
            } catch (error) {
              this.$message.warning('取消操作')
            }
          } else {
            row.advertisementStatus = 1
          }
        } else {
          row.advertisementStatus = 0
        }
    },
    changeLink () {
      this.linksAll.forEach((t) => {
        if (t.id === this.addForm.linkId) {
          this.addForm.linkAddress = t.linkAddress
        }
      })
    },
    async UploadChange (file) {
      try {
        this.file = file.raw
        this.uploading = true
        let param = new window.FormData()
        param.append('file', this.file)
        let res = await commonApi.upload(param)
        if (res.data.respCode === '1000') {
          this.addForm.img = res.data.body
          this.uploading = false
        } else {
          this.$_message.error(res.data.respMsg)
          this.uploading = false
        }
      } catch (error) {
        this.uploading = false
      }
    },
  },
}
</script>

<style lang='scss' scoped>
.length-1{
  width: 250px
}
.font-info {
  color:#999999;
  font-size: 12px
}
.son{
  position: absolute;
  top:0;
  right:0
}
.parentPosition{
  position: relative;
  max-height:300px;
  max-width:400px
}
</style>