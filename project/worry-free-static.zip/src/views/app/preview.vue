<template>
  <!--  数据展示 -->
  <el-table :data="tableData" border stripe :key="classifyCode" highlight-current-row style="width:100%;margin-top:20px;">
    <el-table-column align="center" prop="id" label="产品ID"></el-table-column>
    <el-table-column align="center" prop="name" label="产品名称"></el-table-column>
    <el-table-column align="center" label="排序">
      <template slot-scope="scope">
        <span v-html="scope.row.classifySort"></span>
      </template>
    </el-table-column>
    <el-table-column align="center" prop="couponName" label="优惠券名称" v-if="classifyCode == 14"></el-table-column>
    <el-table-column align="center" prop="subCouponName" label="副标题" v-if="classifyCode == 14"></el-table-column>
    <el-table-column align="center" prop="couponContent" label="优惠金额/内容" v-if="classifyCode == 14"></el-table-column>
    <el-table-column align="center" label="额度/元" v-if="classifyCode != 14">
      <template slot-scope="scope">
        <span>{{ scope.row.productLimitEnd ==  scope.row.productLimitStart ?  scope.row.productLimitStart : scope.row.productLimitStart + '~' + scope.row.productLimitEnd  }}</span>
      </template>
    </el-table-column>
    <el-table-column align="center" label="期限" v-if="classifyCode != 14">
      <template slot-scope="scope">
        <span>{{ scope.row.durationStart == scope.row.durationEnd ?  scope.row.durationStart : scope.row.durationStart + '~' + scope.row.durationEnd  }}</span>
        <span>{{scope.row.durationType == 0 ? '天' : '月'}}</span>
      </template>
    </el-table-column>
    <el-table-column align="center" label="息费" v-if="classifyCode != 14">
      <template slot-scope="scope">
        <span>{{ scope.row.rateStart ==  scope.row.rateEnd ?  scope.row.rateStart + '%' : scope.row.rateStart + '%' + '~' + scope.row.rateEnd + '%'  }}</span>
        <span>{{scope.row.rateType == 0 ? '每日' : '每月'}}</span>
      </template>
    </el-table-column>
    <el-table-column align="center" label="开屏广告图片" v-if="classifyCode == 18">
      <template slot-scope="scope">
        <span>已选择</span>
      </template>
    </el-table-column>
    <el-table-column align="center" label="Banner图片" v-if="classifyCode == 6">
      <template slot-scope="scope">
        <span>已选择</span>
      </template>
    </el-table-column>
    <el-table-column align="center" label="首页弹窗图片" v-if="classifyCode == 20">
      <template slot-scope="scope">
        <span>已选择</span>
      </template>
    </el-table-column>
    <el-table-column align="center" prop="tagName" label="产品标签" v-if="showFirst"></el-table-column>
    <el-table-column align="center" label="点击去向">
      
      <template slot-scope="scope">
        <span>{{ scope.row.clickDestination == 1 ? '合作方H5页' : '产品详情' }}</span>
      </template>
    </el-table-column>
    <el-table-column align="center" prop="name" label="创建时间">
      <template slot-scope="scope">
        <span>{{ scope.row.createAt | parseTime }}</span>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
  export default {
    data () {
      return {
        tableData: [],
        classifyCode: '1',
        showFirst: false, // 首页主列表-猜你可贷
        showSecond: false // 开屏广告-首页弹框
      }
    },
    watch: {
      '$route.params' () {
        this.classifyCode = this.$route.params.classifyCode
        this.tableData = JSON.parse(window.name)
        this.sortTableData()
        this.disShowOrHide()
      }
    },
    methods: {
      // 排序
      sortTableData () {
        let arr = []
        let arrTop = []
        arr = JSON.parse(JSON.stringify(this.tableData))
        let len = arr.length
        for (let i = 0; i < len - 1; i++) {
          for (let j = 0; j < len - 1 - i; j++) {
            if (arr[j].classifySort > arr[j + 1].classifySort) { // 相邻元素两两对比
              let temp = arr[j + 1] // 元素交换
              arr[j + 1] = arr[j]
              arr[j] = temp
            }
            // 排序数字相同 根据ID排序
            if (arr[j].classifySort === arr[j + 1].classifySort) {
              if (arr[j].id > arr[j + 1].id) {
                let temp = arr[j + 1] // 元素交换
                arr[j + 1] = arr[j]
                arr[j] = temp
              }
            }
          }
        }
        this.tableData = arr
        this.tableData.forEach(t => {
          if (t.classifySort || t.classifySort === 0) { arrTop.push(t) }
        })
        this.tableData = arrTop
      },
      // 区分显示隐藏
      disShowOrHide () {
        let arr = ['9', '1', '2', '3', '11', '12', '13']
        let brr = ['18', '6', '20']
        if (arr.indexOf(this.classifyCode) > -1) {
          this.showFirst = true
        } else {
          this.showFirst = false
        }
        if (brr.indexOf(this.classifyCode) > -1) {
          this.showSecond = true
        } else {
          this.showSecond = false
        }
      }
    },
    mounted () {
      this.classifyCode = this.$route.params.classifyCode
      this.tableData = JSON.parse(window.name)
      this.sortTableData()
      this.disShowOrHide()
    }
  }
</script>