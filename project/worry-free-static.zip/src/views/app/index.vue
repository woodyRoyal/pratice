<!--app管理-->
<template>
  <div>
    <div class="topBox">
      <!-- 父tab -->
      <el-radio-group v-model="channelId"
                      style="margin-top:0px;"
                      size="small"
                      @change="channelIdChange">
        <el-radio-button v-for="(item,index) in bigTagList"
                         :key="index"
                         :label="item.id">
          {{ item.value }}
        </el-radio-button>
      </el-radio-group>
      <div>
        <el-radio-group v-model="classifyCode"
                        size="mini"
                        type="card"
                        style="margin-top:5px;display: inline-block"
                        @change="tabPositionChange">
          <el-radio-button v-for="(item,index) in tagList"
                           :key="index "
                           style="padding: 5px auto;"
                           :label="item.addressType">
            {{ item.value }}
          </el-radio-button>
        </el-radio-group>
      </div>
    </div>
    <!-- 特定分类下的分界线 -->
    <template v-if="showType">
      <div class="topLine"></div>
      <el-radio-group v-model="typeId"
                      style="margin-top:0px;"
                      size="mini">
        <el-radio-button :label="1">
          指定产品
        </el-radio-button>
        <el-radio-button :label="2">
          {{ tagObj[classifyCode] + '管理' }}
        </el-radio-button>
      </el-radio-group>
    </template>
    
    <!-- 查询表单 -->
    <template v-if="typeId===1 && !isToLink">
      <div style="height:5px"></div>
      <el-form :inline="true"
               :model="queryForm"
               size="mini"
               class="margin-mini">
        <el-form-item label="产品ID">
          <el-input v-model.number="queryForm.productId"
                    style="width:100px;"
                    onkeypress="return( /[\d]/.test(String.fromCharCode(event.keyCode)))"
                    @keyup.native.enter="getTableData()"></el-input>
        </el-form-item>
        <el-form-item label="产品名称">
          <el-input v-model="queryForm.name"
                    style="width:100px;"
                    @keyup.native.enter="getTableData()"></el-input>
        </el-form-item>
        <el-form-item v-if="showFirst && classifyCode != 99"
                      label="产品标签">
          <el-select v-model="queryForm.tag"
                     style="width:100px;">
            <el-option value=""
                       label="全部"></el-option>
            <el-option value="1"
                       label="有"></el-option>
            <el-option value="0"
                       label="无"></el-option>
          </el-select>
        </el-form-item>
              
        <el-form-item v-if="classifyCode != 99"
                      label="硬广位期望UV是否足量">
          <el-select v-model="queryForm.constraintUvSinkFlag"
                     style="width:100px;">
            <el-option value=""
                       label="不限"></el-option>
            <el-option :value="true"
                       label="是"></el-option>
            <el-option :value="false"
                       label="否"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-if="classifyCode != 99"
                      label="期望UV是否足量">
          <el-select v-model="queryForm.uvSinkFlag"
                     style="width:100px;">
            <el-option value=""
                       label="不限"></el-option>
            <el-option :value="true"
                       label="是"></el-option>
            <el-option :value="false"
                       label="否"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary"
                     :loading="searchLoading"
                     class="least"
                     @click="handleSearch">
            筛选
          </el-button>
          <el-button v-if="classifyCode != 99"
                     type="primary"
                     class="least"
                     @click="previewSort">
            预览排序
          </el-button>
          <el-button v-if="classifyCode != 99"
                     type="primary"
                     class="least"
                     @click="submitSort">
            提交排序
          </el-button>
          <el-button v-if="classifyCode != 99"
                     type="primary"
                     class="least"
                     @click="down">
            导出
          </el-button>
        </el-form-item>
        <el-form-item v-if="classifyCode != 99">
          <el-upload ref="upload"
                     class="upload-user-defined"
                     name="in"
                     accept=".csv"
                     :auto-upload="false"
                     action="uploadExcelUrl"
                     :file-list="fileList"
                     :show-file-list="false"
                     :with-credentials="true"
                     :disabled="uploading"
                     :before-upload="handleUploadBefore"
                     :on-success="handleUploadSuccess"
                     :on-error="handleUploadError"
                     :on-progress="handleUploadProgress"
                     :on-change="handleUploadChange">
            <el-button size="mini"
                       type="primary"
                       :loading="uploading"
                       class="least">
              导入排序
            </el-button>
            <!-- <span style="font-size:12px;">只能上传.csv文件</span> -->
          </el-upload>
        </el-form-item>
        <el-form-item>
          <el-button v-if="classifyCode == 6"
                     type="primary"
                     class="least"
                     @click="setBanner">
            自定义banner
          </el-button>
          <el-button v-if="classifyCode == 20 ||classifyCode == 18"
                     type="primary"
                     class="least"
                     @click="setOpenAD">
            {{ '自定义' + tagObj[classifyCode] }}
          </el-button>
          <el-button v-if="classifyCode == 18 || classifyCode == 6 ||classifyCode == 20 "
                     type="primary"
                     class="least"
                     @click="setPictrue">
            {{ tagObj[classifyCode] + '图片管理' }}
          </el-button>
        </el-form-item>
      </el-form>
      <!--  数据展示 -->
      <el-table :key="classifyCode"
                v-loading="listLoading"
                :data="tableData"
                border
                stripe
                highlight-current-row
                style="width:100%;"
                :max-height="tableHeight">
        <el-table-column align="center"
                         prop="id"
                         label="产品ID"
                         width="60"></el-table-column>
        <el-table-column align="center"
                         prop="name"
                         label="产品名称"></el-table-column>
        <template v-if="classifyCode != 99">
          <el-table-column align="center"
                           prop="classifySort"
                           label="排序"
                           width="90">
            <template slot-scope="scope">
              <div class="pd">
                <el-input v-model.number="scope.row.classifySort"
                          size="mini"
                          type="number"
                          :min="1"
                          onkeypress="return(  /[0-9]/.test(String.fromCharCode(event.keyCode)))"></el-input>
              </div>
            </template>
          </el-table-column>
          <el-table-column v-if="classifyCode == 14"
                           align="center"
                           prop="couponName"
                           label="优惠券名称"></el-table-column>
          <el-table-column v-if="classifyCode == 14"
                           align="center"
                           prop="subCouponName"
                           label="副标题"></el-table-column>
          <el-table-column v-if="classifyCode == 14"
                           align="center"
                           prop="couponContent"
                           label="优惠金额/内容"></el-table-column>
          <el-table-column v-if="classifyCode != 14"
                           align="center"
                           label="额度/元">
            <template slot-scope="scope">
              <span>{{ scope.row.productLimitEnd == scope.row.productLimitStart ? scope.row.productLimitStart : scope.row.productLimitStart + '~' + scope.row.productLimitEnd }}</span>
            </template>
          </el-table-column>
          <el-table-column v-if="classifyCode != 14"
                           align="center"
                           label="期限">
            <template slot-scope="scope">
              <div v-if="scope.row.durationStart !== null && scope.row.durationStart !== ''">
                <span>{{ scope.row.durationStart == scope.row.durationEnd ? scope.row.durationStart : scope.row.durationStart + '~' + scope.row.durationEnd }}</span>
                <span>{{ scope.row.durationType == 0 ? '天' : '月' }}</span>  
              </div>
            </template>
          </el-table-column>
          <el-table-column v-if="classifyCode != 14"
                           align="center"
                           label="息费">
            <template slot-scope="scope">
              <div v-if="scope.row.rateStart !== null && scope.row.rateStart !== ''">
                <span>{{ scope.row.rateStart == scope.row.rateEnd ? scope.row.rateStart + '%' : scope.row.rateStart + '%' + '~' + scope.row.rateEnd + '%' }}</span>
                <span>{{ rateTypeList[scope.row.rateType] }}</span>
              </div>
            </template>
          </el-table-column>
          <el-table-column v-if="classifyCode == 18"
                           align="center"
                           label="开屏广告图片">
            <template slot-scope="scope">
              <a v-if="scope.row.openAds.length"
                 class="imitate-a-label"
                 @click="watchDetail(scope.row.name, scope.row.openAds, '18')">点击查看</a>
              <span v-else>---</span>
            </template>
          </el-table-column>
          <el-table-column v-if="classifyCode == 6"
                           align="center"
                           label="Banner图片">
            <template slot-scope="scope">
              <a v-if="scope.row.homeBanners.length"
                 class="imitate-a-label"
                 @click="watchDetail(scope.row.name, scope.row.homeBanners, '6')">点击查看</a>
              <span v-else>---</span>
            </template>
          </el-table-column>
          <el-table-column v-if="classifyCode == 20"
                           align="center"
                           label="首页弹窗图片">
            <template slot-scope="scope">
              <a v-if="scope.row.homePops.length"
                 class="imitate-a-label"
                 @click="watchDetail(scope.row.name, scope.row.homePops, '20')">点击查看</a>
              <span v-else>---</span>
            </template>
          </el-table-column>
          <el-table-column v-if="showFirst"
                           align="center"
                           prop="tagName"
                           label="产品标签"></el-table-column>
          <el-table-column align="center"
                           label="点击去向"
                           width="100">
            <template slot-scope="scope">
              <span>{{ scope.row.clickDestination == 1 ? '合作方H5页' : '产品详情' }}</span>
            </template>
          </el-table-column>
          <el-table-column align="center"
                           label="链接类型"
                           prop="remark">
          </el-table-column>
          <el-table-column align="center"
                           label="硬广位期望UV是否足量"
                           prop="constraintUvSinkFlag">
            <template slot-scope="scope">
              <span v-if="scope.row.constraintUvSinkFlag"
                    style="color:red">
                是
              </span>
              <span v-else>
                否
              </span>
            </template>
          </el-table-column>
          <el-table-column align="center"
                           label="期望UV是否足量"
                           prop="uvSinkFlag">
            <template slot-scope="scope">
              <span v-if="scope.row.uvSinkFlag"
                    style="color:red">
                是
              </span>
              <span v-else>
                否
              </span>
            </template>
          </el-table-column>
          <el-table-column align="center"
                           prop="name"
                           label="创建时间">
            <template slot-scope="scope">
              <span>{{ scope.row.createAt | parseTime }}</span>
            </template>
          </el-table-column>
          <el-table-column align="center"
                           prop="name"
                           label="操作">
            <template slot-scope="scope">
              <el-button type="primary"
                         size="mini"
                         @click="editdirection(scope.row)">
                编辑
              </el-button>
              <!-- <el-button type="primary" size="mini" @click="locked(scope.row,'锁定')" v-if="scope.row.lockFlag === 0">锁定</el-button>
                  <el-button type="success" size="mini" @click="locked(scope.row,'解锁')" v-if="scope.row.lockFlag === 1">解锁</el-button> -->
            </template>
          </el-table-column>
        </template>
        <template v-else>
          <el-table-column align="center"
                           label="是否允许上api banner"
                           prop="status">
            <template slot-scope="scope">
              <el-select v-model="scope.row.status"
                         size="mini"
                         @change="changeCanShow(scope.row)">
                <el-option
                  :key="0"
                  label="否"
                  :value="0"
                ></el-option>

                <el-option
                  :key="1"
                  label="是"
                  :value="1"
                ></el-option>
              </el-select>
            </template>
          </el-table-column>
        </template>
      </el-table>
    </template>
    <div v-if="typeId===1 && isToLink"
         class="fullPageFont">
      {{ infoToLink }}
    </div>
    <template v-if="showType&&typeId===2">
      <!--  特殊分类下指定产品之外的表单 -->
      <classify 
        ref="classifyDom" 
        :channel-id="channelId" 
        :classify-code="classifyCode"  
        :table-data-obj="tableDataObj"
        :pagination="classPagination"
        @changeData="changeData"
      ></classify>
    </template>
      
    <!-- 编辑弹框 -->
    <el-dialog :title="'编辑点击去向—' + dialogName"
               :visible.sync="dialogDirectionVisible"
               :close-on-click-modal="false"
               :close-on-press-escape="false"
               width="60%"
               @close="handleDirectionClose">
      <el-form ref="editForm"
               label-width="140px"
               :model="editForm"
               :rules="editFormRules">
        <el-form-item v-if="classifyCode == 14"
                      label="优惠券名称:"
                      prop="couponName">
          <el-input v-model="editForm.couponName"
                    class="length-1"
                    size="small"></el-input>
          <span class="font">修改后所有的产品线+手机系统中的该字段都会变动</span>
        </el-form-item>
        <el-form-item v-if="classifyCode == 14"
                      label="副标题:"
                      prop="subCouponName">
          <el-input v-model="editForm.subCouponName"
                    class="length-1"
                    size="small"></el-input>
          <span class="font">修改后所有的产品线+手机系统中的该字段都会变动</span>
        </el-form-item>
        <el-form-item v-if="classifyCode == 14"
                      label="优惠金额/内容:"
                      prop="couponContent">
          <el-input v-model="editForm.couponContent"
                    class="length-1"
                    size="small"></el-input>
          <span class="font">修改后所有的产品线+手机系统中的该字段都会变动</span>
        </el-form-item>
        <el-form-item prop="linkSeqId">
          <el-radio-group v-model="editForm.linkSeqId"
                          style="margin-left: -150px;">
            <el-form-item v-for="(item) in links"
                          :key="item.seqId"
                          :label="'链接' + item.seqId + ':'">
              <el-radio :label="item.seqId">
                <span>{{ item.remark }}</span>
              </el-radio>
              <div style="margin-top: -10px;line-height: 20px;">
                {{ item.address }}
              </div>
            </el-form-item>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="点击去向:"
                      prop="clickDestination">
          <el-radio-group v-model="editForm.clickDestination">
            <el-radio :label="0">
              产品详情
            </el-radio>
            <el-radio :label="1">
              合作方H5页
            </el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item v-if="showSecond"
                      :label="tagObj[classifyCode] + '图片:'"
                      prop="imgSeqId">
          <el-radio-group v-model="editForm.imgSeqId">
            <div v-for="(item, index) in picList"
                 :key="index"
                 style="float:left;margin-right: 10px;margin-top:10px; width:200px;">
              <div>
                <img style="width: 200px; height: 200px;"
                     :src="item.imgUrl">
              </div>
              <el-radio class="length-3"
                        size="small"
                        :label="item.seqId"
                        style="margin-top:15px;">
                <span style="white-space: normal;word-wrap:break-word;word-break:break-all">{{ item.remark }}</span>
              </el-radio>
            </div>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="dialogDirectionVisible = false">取 消</el-button>
        <el-button type="primary"
                   @click="handleDirectionSubmit">保 存</el-button>
      </span>
    </el-dialog>
    <!-- 点击查看图片弹框 -->
    <el-dialog :title="'产品' + dialogName + '的' + tagObj[classifyCode] + '图片'"
               :visible.sync="dialogVisiblePic"
               width="30%">
      <div style="overflow: hidden">
        <div v-for="(item, index) in watchDetailList"
             :key="index"
        >
          <img style="width: 200px; height: 200px;"
               :src="item.imgUrl">
        </div>
      </div>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="dialogVisiblePic = false">取消</el-button>
      </span>
    </el-dialog>
    <!-- 以下产品的xxx尚未配置 -->
    <el-dialog :title="'以下产品的' + '“' + fileDialog.typeName +'”'+ '尚未配置' + ',请先配置'"
               :visible.sync="fileDialog.dialogVisible"
               width="30%"
               class="center">
      <div style="overflow: hidden">
        <div style="text-align:center">
          {{ listString }}
        </div>
      </div>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="fileDialog.dialogVisible = false">我知道了</el-button>
      </span>
    </el-dialog>

    <!-- 导入失败 -->
    <el-dialog center
               title="导入失败"
               :visible.sync="fileDialog.errorVisible"
               width="30%"
               class="errorStyle">
      <div style="overflow: hidden">
        <div style="text-align:center">
          <!-- 本列表要求导入的排序数量必须≥2 -->
          {{ fileDialog.errorMsg }}
        </div>
      </div>
      <span slot="footer"
            class="dialog-footer Foot-center"
            style="text-align:center">
        <el-button @click="fileDialog.errorVisible = false">我知道了</el-button>
      </span>
    </el-dialog>

    <!-- 校验通过 -->
    <el-dialog center
               title="校验通过"
               :visible.sync="fileDialog.passVisible"
               width="30%"
               class="passStyle">
      <p v-if="gridData.length > 0">
        以下"产品id"不在本列表中，继续导入时会被剔除：
      </p>
      <p v-if="gridData.length > 0"
         style="font-size:12px;color:#B5C1CC;">
        (这些产品可能被"停用"或系统(ios/安卓)不符合本列表要求)
      </p>
      <el-table v-if="gridData.length > 0"
                :data="gridData"
                stripe
                border
                width="100%">
        <el-table-column prop="id"
                         label="产品ID"></el-table-column>
        <el-table-column prop="name"
                         label="产品名称"></el-table-column>
        <el-table-column prop="classifySort"
                         label="期望排序"></el-table-column>
      </el-table>
      <span slot="footer"
            class="dialog-footer Foot-center"
            style="text-align:center">
        <el-button @click="cancelSubmit">取消</el-button>
        <el-button :loading="finalLoading"
                   @click="finalSubmit">确定导入</el-button>
      </span>
    </el-dialog>

    <!-- 导入成功 -->
    <el-dialog center
               title="导入成功"
               :visible.sync="fileDialog.successVisible"
               width="30%"
               class="successStyle">
      <p>以下"产品id"不在本列表中，已被剔除：</p>
      <el-table :data="gridData"
                stripe
                border
                width="100%">
        <el-table-column prop="id"
                         label="产品ID"></el-table-column>
        <el-table-column prop="name"
                         label="产品名称"></el-table-column>
        <el-table-column prop="classifySort"
                         label="期望排序"></el-table-column>
      </el-table>
      <span slot="footer"
            class="dialog-footer Foot-center"
            style="text-align:center">
        <el-button @click="fileDialog.successVisible = false">我知道了</el-button>
      </span>
    </el-dialog>
    <el-dialog center
               title="导入成功"
               :visible.sync="fileDialog.simpleVisible"
               width="20%"
               class="successStyle">
      <span slot="footer"
            class="dialog-footer Foot-center"
            style="text-align:center">
        <el-button @click="fileDialog.simpleVisible = false">我知道了</el-button>
      </span>
    </el-dialog>
    <!-- 自定义banner -->
    <el-dialog :title="bannerForm.title + '标签'"
               :visible.sync="bannerForm.show">
      <span slot="title"
            class="dialog-title Foot-center">
        <span>自定义banner</span>
        <el-button type="primary"
                   size="mini"
                   @click="addBanner()">添加</el-button>
        <el-button type="primary"
                   size="mini"
                   @click="saveBannerSort()">保存设置</el-button>
        <p style="color:red;font-size:12px;">*点击右上角"保存设置"后状态和排序才会生效</p>
      </span>
      <el-table :data="bannerForm.tableData"
                stripe
                border
                width="100%">
        <el-table-column prop="id"
                         label="bannerID">
        </el-table-column>
        <el-table-column prop="bannerName"
                         label="banner名称"
                         width="100">
        </el-table-column>
        <el-table-column prop="seq"
                         label="排序">
          <template slot-scope="scope">
            <div class="pd">
              <el-input v-model.number="scope.row.seq"
                        size="mini"
                        type="number"
                        :min="1"
                        onkeypress="return(  /[0-9]/.test(String.fromCharCode(event.keyCode)))"></el-input>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="img"
                         label="图片">
          <template slot-scope="scope">
            <el-button type="text"
                       size="mini"
                       @click="openPic(scope.row)">
              点击查看
            </el-button>
          </template>
        </el-table-column>
        <el-table-column prop="linkName"
                         label="选择链接">
        </el-table-column>
        <el-table-column prop="linkAddress"
                         label="链接地址">
        </el-table-column>
        <el-table-column prop="bannerStatus"
                         label="状态">
          <template slot-scope="scope">
            <div class="product-status">
              <span>
                <span v-if="scope.row.bannerStatus"
                      style="color:green;">启用</span>
                <span v-else
                      style="color:red">停用</span>
              </span>
              <span
                @click.capture.stop="disableBanner(scope.row)"
              >
                <el-switch
                  v-model="scope.row.bannerStatus"
                  :active-value="1"
                  :inactive-value="0"
                  active-color="#13ce66"
                  inactive-color="#ff4949">
                </el-switch>
              </span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="updateAt"
                         label="最后修改时间">
          <template slot-scope="scope">
            {{ scope.row.updateAt | parseTime }}
          </template>
        </el-table-column>
        <el-table-column prop="operator"
                         label="操作人">
        </el-table-column>
        <el-table-column prop="value"
                         label="操作">
          <template slot-scope="scope">
            <el-button type="primary"
                       size="mini"
                       @click="editBanner(scope.row)">
              编辑
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-container">
        <el-pagination :current-page.sync="bannerForm.pagination.pageNo"
                       :page-sizes="bannerForm.pagination.pageSizes"
                       :page-size="bannerForm.pagination.pageSize"
                       layout="total, sizes, prev, pager, next, jumper"
                       :total="bannerForm.pagination.total"
                       @size-change="bannerFormSizeChange"
                       @current-change="bannerFormCurrentChange">
        </el-pagination>
      </div>
    </el-dialog>
    <!-- 查看图片 -->
    <el-dialog :visible.sync="bannerForm.picDialog">
      <span slot="title"
            class="dialog-title Foot-center">
        <span>{{ bannerForm.pictitle }}</span>
      </span>
      <div style="overflow: hidden">
        <div>
          <img style="width: 200px; height: 200px;"
               :src="bannerForm.picAddress">
        </div>
      </div>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="bannerForm.picDialog = false">取消</el-button>
      </span>
    </el-dialog>
    <!-- 添加编辑自定义banner -->
    <el-dialog :visible.sync="bannerForm.addOrEditShow"
               :title="bannerForm.addOrEditTitle + '自定义banner'"
               width="850px"
               @close="closeBanner">
      <el-form ref="bannerFormDom"
               :model="bannerForm.addForm"
               size="mini"
               :rules="bannerForm.rules"
               label-width="120px">
        <el-form-item label="banner名称"
                      prop="bannerName">
          <el-input v-model="bannerForm.addForm.bannerName"
                    :maxlength="15"
                    placeholder="限15个字">
          </el-input>                         
        </el-form-item>
        <el-form-item label="图片"
                      prop="img">
          <el-upload ref="uploadFile"
                     class="upload-user-defined"
                     name="in"
                     :auto-upload="false"
                     action="url"
                     :show-file-list="false"
                     :with-credentials="true"
                     :on-change="UploadChange"
                     :disabled="uploading">
            <el-button size="mini"
                       type="primary"
                       :loading="uploading">
              选择文件
            </el-button>
            <span class="font">(首页Banner图片尺寸678*180px)</span>
          </el-upload>
        </el-form-item>
        <el-form-item label=""
                      prop="img">
          <div v-if="bannerForm.addForm.img"
               class="parentPosition">
            <img :src="bannerForm.addForm.img"
                 style="height:180px;width:678px">
            <el-button class="son"
                       type="danger"
                       size="mini"
                       @click="deletePic()">
              删除
            </el-button>
          </div>
        </el-form-item>
        <el-form-item label="选择链接"
                      prop="linkId">
          <el-select v-model="bannerForm.addForm.linkId"
                     @change="changeLink">
            <el-option
              v-for="(item,index) in linksAll"
              :key="index"
              :value="item.id"
              :label="item.linkName"
            >
            </el-option>
          </el-select>                        
        </el-form-item>
        <el-form-item v-if="bannerForm.addForm.linkId !=='' && bannerForm.addForm.linkId!==null"
                      label="链接地址"
                      prop="linkAddress">
          <span>{{ bannerForm.addForm.linkAddress }}</span>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="bannerForm.addOrEditShow = false">
          取消
        </el-button>
        <el-button type="primary"
                   @click="saveBanner">
          确认
        </el-button>
      </div>
    </el-dialog>
    <openAdvertising ref="openAdvertisingDom"
                     :channel-id="channelId"
                     :classify-code="classifyCode">
    </openAdvertising>

    <picManage ref="picManageDom"
               :channel-id="channelId"
               :classify-code="classifyCode">
    </picManage>
  </div>
</template>

<script>
  // 开屏广告一大堆弹窗
  import openAdvertising from './components/openAdvertising'
  // 精准推荐2.0 新增图片管理模块
  import picManage from './components/picManage'
  import classify from './components/classify'
  import api from '../../api/app7.0/openAdvertising'
  import { parseTime } from '../../utils/formatDate'
  import { TAG_LIST, TAG_OBJ, bigTagOBJ,rateTypeList } from './app'
  // import { mapGetters } from 'vuex'
  import appApi from '../../api/app'
  import commonApi from '../../api/incomeApi/common.js'
  export default {
    components: {
      openAdvertising,
      classify,
      picManage,
    },
    data () {
      let linkSeqId = (rule, value, callback) => {
        if (!this.editForm.linkSeqId) {
          callback(new Error('请选择链接'))
        } else {
          callback()
        }
      }
      let imgSeqId = (rule, value, callback) => {
        if (this.picList.length === 0) {
          callback(new Error(this.tagObj[this.classifyCode] + '图片不能为空,请先在产品管理页面上传图片'))
        } else if (!this.editForm.imgSeqId) {
          callback(new Error('请选择图片'))
        } else {
          callback()
        }
      }
      return {
        typeId: 1,
        rateTypeList:rateTypeList,
        tableDataObj: {
          1: [],
          2: [],
          3: [],
          4: [],
          7: [],
          8: [],
          21: [],
          23: [],
          24: [],
          25: [],
          26: [],
          27: [],
          28: [],
        },
        classPagination: {
          pageNo: 1,
          pageSizes: [30, 50, 100, 200],
          pageSize: 30,
          total: 0,
        },
        linksAll: [],
        bannerForm: {
          picDialog: false,
          pictitle: '',
          picAddress: '',
          pagination: {
            pageNo: 1, //
            pageSizes: [30, 50, 100],
            pageSize: 30,
            total: 0,
          },
          show: false,
          tableData: [
          ],
          addOrEditTitle: '添加',
          addOrEditShow: false,
          file: null,
          addForm: {
            linkId: '',
            img: '',
            bannerName: '',
            linkAddress: '',
          },
          rules: {
            bannerName: [
              { required: true, message: '请填写', trigger: 'blur' },
            ],
            img: [
              { required: true, message: '请上传图片', trigger: 'change' },
            ],
            linkId: [
              { required: true, message: '请选择', trigger: 'none' },
            ],
          },
        },
        changeStatus: 0,
        selectList: {
          SystemModuleList: {
            0: '精准推荐系统',
            1: 'API用户预晒',
          },
        },
        bigTagOBJ,
        uploading: false,
        finalLoading: false,
        file: null,
        listString: '',
        gridData: [],
        uploadFileName: '',
        fileDialog: {
          dialogVisible: false,
          errorVisible: false,
          passVisible: false,
          simpleVisible: false,
          successVisible: false,
          typeName: '点击链接',
          errorMsg: '',
        },
        fileList: [],
        parseTime,
        // 查询参数
        queryForm: {
          productId: null,
          name: '',
          tag: '',
          uvSinkFlag: '',
          constraintUvSinkFlag: '',
        },
        // 编辑表单
        editForm: {
          couponName: '',
          subCouponName: '',
          couponContent: '',
          clickDestination: 1,
          linkSeqId: null, // 链接
          imgSeqId: null, // 图片序号
          id: null, // 产品ID
        },
        // 排序验证个数
        picList: [],
        links: [],
        bigTagList: [
          {'id': 1, value: '花钱无忧(安卓)'},
          {'id': 2, value: '花钱无忧(ios)'},
          {'id': 3, value: '贷款王(安卓)'},
          {'id': 4, value: '贷款王(ios)'},
          {'id': 5, value: '立即借（安卓）'},
          {'id': 6, value: '立即借（iOS）'},
        ],
        tagObj: TAG_OBJ,
        tagList: TAG_LIST,
        tableData: [],
        tableHeight: 600,
        classifyCode: '9',
        channelId: 1,
        listLoading: false,
        searchLoading: false,
        dialogDirectionVisible: false, // 点击去向弹框
        dialogName: '', // 点击去向弹框表头提示
        showFirst: false, // 首页主列表-猜你可贷
        showSecond: false, // 开屏广告-首页弹框
        editFormRules: { // 用户去向表单验证规则
          couponName: [
            {
              required: false,
              trigger: 'blur',
              validator: (rule, value, callback) => {
                if (this.editForm.couponName === '' && this.editForm.subCouponName === '' && this.editForm.couponContent === '') {
                  callback()
                } else if (this.editForm.couponName !== '' && this.editForm.subCouponName !== '' && this.editForm.couponContent !== '') {
                  callback()
                } else {
                  callback(new Error('优惠券名称、副标题、优惠金额/内容这三个要素必须同时填写或同时不填写'))
                }
              },
            },
          ],
          subCouponName: [
            {
              required: false,
              trigger: 'blur',
              validator: (rule, value, callback) => {
                if (this.editForm.couponName === '' && this.editForm.subCouponName === '' && this.editForm.couponContent === '') {
                  callback()
                } else if (this.editForm.couponName !== '' && this.editForm.subCouponName !== '' && this.editForm.couponContent !== '') {
                  callback()
                } else {
                  callback(new Error('优惠券名称、副标题、优惠金额/内容这三个要素必须同时填写或同时不填写'))
                }
              },
            },
          ],
          couponContent: [
            {
              required: false,
              trigger: 'blur',
              validator: (rule, value, callback) => {
                if (this.editForm.couponName === '' && this.editForm.subCouponName === '' && this.editForm.couponContent === '') {
                  callback()
                } else if (this.editForm.couponName !== '' && this.editForm.subCouponName !== '' && this.editForm.couponContent !== '') {
                  callback()
                } else {
                  callback(new Error('优惠券名称、副标题、优惠金额/内容这三个要素必须同时填写或同时不填写'))
                }
              },
            },
          ],
          clickDestination: [
            { required: true, message: '请选择产品去向', trigger: 'change' },
          ],
          linkSeqId: [
            { required: true, validator: linkSeqId, trigger: 'change' },
          ],
          imgSeqId: [
            { required: true, validator: imgSeqId, trigger: 'change' },
          ],
        },
        // 点击产看图片弹框
        dialogVisiblePic: false,
        watchDetailList: [], // 点击查看图片list
        flagOpenAds: null,
        flagHomeBanners: null,
        flagHomePops: null,
        showcomputed: true,
      }
    },
    computed: {
      //  tagListIsshow () {
      //   this.tagList.filter( t => {
      //     return t.
      //   })
      // },
      // 是否是指定链接
      isToLink () {
        if (['1', '2', '3', '4'].includes(this.classifyCode)) {
          let flag = false
          this.tableDataObj[this.classifyCode].forEach((t) => {
            if (t.clickTo === '2' && t.advertisementStatus === 1) {
              flag = true
            }
          })
          return flag
        } else if (['7', '8', '21', '23', '24', '25', '26', '27', '28'].includes(this.classifyCode)) {
          let flag = false
          this.tableDataObj[this.classifyCode].forEach((t) => {
            if (t.clickTo === '2' && t.advertisementStatus === 1) {
              flag = true
            }
          })
          return flag
        } else {
          return false
        }
      },
      infoToLink () {
        if (['1', '2', '3', '4'].includes(this.classifyCode)) {
          return '当前分类为指定链接，暂无产品列表'
        } else {
          return '当前点击去向为指定链接，暂无产品列表'
        }
      },
      // 是否为显示
      showType () {
        if (this.classifyCode === '1' ||
      this.classifyCode === '2' ||
      this.classifyCode === '3' ||
      this.classifyCode === '4' ||
      this.classifyCode === '7' ||
      this.classifyCode === '8' ||
      this.classifyCode === '21' ||
      this.classifyCode === '23' ||
      this.classifyCode === '24' ||
      this.classifyCode === '25' ||
      this.classifyCode === '26' ||
      this.classifyCode === '27' ||
      this.classifyCode === '28'
        ) return true
        return false
      },
    },
    watch: {
      'editForm.linkSeqId': function () {
        this.links.forEach((t) => {
          if (t.seqId === this.editForm.linkSeqId) {
            if (t.dockingType === 0) {
              this.showcomputed = true
            } else {
              this.showcomputed = false
            }
          }
        })
      },
    },
    created () {
      if(localStorage.getItem('channelId')) {
        this.channelId = localStorage.getItem('channelId')
      }
      if(localStorage.getItem('classifyCode')) {
        this.classifyCode = localStorage.getItem('classifyCode')
      }
    },
    mounted () {
      this.disShowOrHide()
      this.getTableData()
      // 表格高度
      this.handleResize()
      // 监听窗口大小变化
      window.addEventListener('resize', this.handleResize)
    },
    deactivated () {
      window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      // window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      deletePic () {
        this.bannerForm.addForm.img = ''
      },
      changeData (val, val2) {
        // this.$message.success(val)
        console.log(val, val2)
        if (val2 === 'size') {
          this.classPagination.pageSize = val
          this.clearMaxTable()
          this.fetchMaxTable()
        } else {
          this.classPagination.pageNo = val
          this.clearMaxTable()
          this.fetchMaxTable()
        }
      },
      // 自定义开屏广告
      setOpenAD () {
        this.$store.commit('changeOpenAdvertise', true)
        this.$refs['openAdvertisingDom'].fetchOpenADList()
        this.$refs['openAdvertisingDom'].fetchLinks()
        // this.fetchBannerList()
        // this.bannerForm.show = true
        // this.fetchLinks()
      },
      setPictrue () {
        this.$store.commit('changePicDialog', true)
        this.$refs['picManageDom'].fetchPicList()
      },
      // 自定义banner开始
      closeBanner () {
        this.$refs['bannerFormDom'].resetFields()
        this.$refs['uploadFile'] && this.$refs['uploadFile'].clearFiles()
      },
      async saveBannerSort () {
        for (let i = 0; i < this.bannerForm.tableData.length; i++) {
          if ((this.bannerForm.tableData[i].seq === '' || this.bannerForm.tableData[i].seq === null) && (this.bannerForm.tableData[i].bannerStatus)) {
            this.$message.warning(`请给启用的banner设置排序`)
            return
          }
        }

        let sort = this.bannerForm.tableData.filter((v) => v.seq)
        if (sort.length > 1) {
          let nary = sort.sort()
          for (let i = 0; i < sort.length; i++) {
            if (nary[i] === nary[i + 1]) {
              this.$message.warning(`排序数字不能重复`)
              return
            }
          }
        }
  
        try {
          let confirm = await this.$confirm('确认保存设置吗？', '提示', { type: 'warning', confirmButtonText: '保存设置' })
          if (confirm) {
            const updateBannerList = this.bannerForm.tableData.map((t) => ({
                id: t.id,
                seq: t.seq,
                bannerStatus: t.bannerStatus,
              }))
            const data = {
              updateBannerList: updateBannerList,
            }
            let res = await appApi.batchUpdateSeqAndStatus(data)
            if (res.data.respCode === '1000') {
              this.$_message.success('操作成功')
              this.fetchBannerList()
            } else {
              this.$_message.error(res.data.respMsg)
            }
          }
        } catch (error) {
          //
        }
      },
      async disableBanner (row) {
        if (!row.bannerStatus) {
          const data = {
            id: row.id,
            bannerStatus: 1,
          }
          let res = await appApi.bannerUpdateStatus(data)
          if (res.data.respCode === '1000' && res.data.body) {
            try {
              let str = `您选择的链接【${row.linkName}】已被停用，是否重新启用这个链接？`
              let confirm = await this.$confirm(str, '提示', { type: 'warning', confirmButtonText: '启用' })
              if (confirm) {
                const pra = {
                  bannerId: row.id,
                  linkId: row.linkId,
                  operator: this.$store.state.loginUser.userId,
                }
                let res1 = await appApi.updateLinkAndBannerStatus(pra)
                if (res1.data.respCode === '1000') {
                  this.$_message.success(res.data.respMsg)
                  row.bannerStatus = 1
                } else {
                  this.$_message.error(res.data.respMsg)
                }
              }
            } catch (error) {
              this.$message.warning('取消操作')
            }
          } else {
            row.bannerStatus = 1
          }
        } else {
          row.bannerStatus = 0
        }
      },
      openPic (row) {
        this.bannerForm.pictitle = row.bannerName
        this.bannerForm.picAddress = row.img
        this.bannerForm.picDialog = true
      },
      addBanner () {
        this.fetchLinks()
        this.bannerForm.addForm = {
          linkId: '',
          img: '',
          bannerName: '',
          linkAddress: '',
        }
        this.bannerForm.addOrEditTitle = '编辑'
        this.bannerForm.addOrEditShow = true
      },
      async editBanner (row) {
        let res = await api.getAdvertsLinkById(row.linkId)
        if (res.data.respCode === '1000') {
          let flag = false
          this.linksAll.forEach((t) => {
            if (t.id === row.linkId) {
              flag = true
            }
          })
          if (!flag) {
            this.linksAll.push(res.data.body)
          }
        } else {
          return this.$_message.error(res.data.respMsg)
        }
        let linkAddress = ''
        this.linksAll.forEach((t) => {
          if (t.id === row.linkId) {
            linkAddress = t.linkAddress
          }
        })
        this.bannerForm.addForm = {
          id: row.id,
          linkId: row.linkId,
          img: row.img,
          bannerName: row.bannerName,
          linkAddress: linkAddress,
        }
        this.bannerForm.addOrEditShow = true
      },
      setBanner () {
        this.fetchBannerList()
        this.bannerForm.show = true
        this.fetchLinks()
      },
      async fetchBannerList () {
        let data = {
          classifyCode: parseInt(this.classifyCode),
          channelId: this.channelId,
          pageIndex: this.bannerForm.pagination.pageNo,
          pageSize: this.bannerForm.pagination.pageSize,
        }
        let res = await appApi.bannerList(data)
        if (res.data.respCode === '1000') {
          this.bannerForm.tableData = res.data.body.customizedBannerVoList
          this.bannerForm.pagination.pageNo = res.data.body.pageIndex
          this.bannerForm.pagination.total = res.data.body.totalCount
        } else {
          this.$_message.error(res.data.respMsg)
        }
      },
      async fetchLinks () {
        let res = await appApi.getAllValidLinks()
        if (res.data.respCode === '1000') {
          this.linksAll = res.data.body.advertsLinkVos
        } else {
          this.$_message.error(res.data.respMsg)
        }
      },
      bannerFormSizeChange (val) {
        this.bannerForm.pagination.pageSize = val
        this.fetchBannerList()
      },
      bannerFormCurrentChange (val) {
        this.bannerForm.pagination.pageNo = val
        this.fetchBannerList()
      },
      async UploadChange (file) {
        this.bannerForm.file = file.raw
        this.uploading = true
        let param = new window.FormData()
        param.append('file', this.bannerForm.file)
        let res = await commonApi.upload(param)
        if (res.data.respCode === '1000') {
          this.bannerForm.addForm.img = res.data.body
          this.uploading = false
        } else {
          this.uploading = false
        }
      },
      saveBanner () {
        this.$refs['bannerFormDom'].validate(async (valid) => {
          if (!valid) {
            return false
          }
          let data = {
            ...this.bannerForm.addForm,
            classifyCode: parseInt(this.classifyCode),
            channelId: this.channelId,
            operator: this.$store.state.loginUser.userId,
          }
          let res = await appApi.saveOrUpdateBanner(data)
          if (res.data.respCode === '1000') {
            this.$_message.success('操作成功')
            this.bannerForm.addOrEditShow = false
            this.fetchBannerList()
          } else {
            this.$_message.error(res.data.respMsg)
          }
        })
      },
      changeLink () {
        this.linksAll.forEach((t) => {
          if (t.id === this.bannerForm.addForm.linkId) {
            this.bannerForm.addForm.linkAddress = t.linkAddress
          }
        })
      },
      // 自定义banner结束
      async changeCanShow (val) {
        console.log(val)
        let data = {
          productId: val.id,
          canShow: val.status,
          channelId: this.channelId,
        }
        let res = await appApi.switchApiBannerShow(data)
        if (res.data.respCode === '1000') {
          this.$_message.success('操作成功')
        } else {
          this.$_message.error(res.data.respMsg)
          this.getTableData()
        }
      },
      async locked (row, text) {
        try {
          if (text === '锁定') {
            if (row.classifySort === null) return this.$_message.error('排序序号必须存在')
          }
          let flagCount = 0
          let temp = this.tableData.filter(() => row.classifySort !== null)
          console.log(temp)
          temp.forEach((t) => {
            if (t.classifySort === row.classifySort) {
              flagCount = flagCount + 1
            }
          })
          if (flagCount > 1) return this.$_message.error('排序序号重复')
          let confirm = await this.$confirm(`确定${text}该项吗?`, '提示', { type: 'warning' })
          if (confirm) {
            let lockFlag = row.lockFlag === 0 ? 1 : 0
  
            let data = {
              channelId: row.channelId,
              classifyCode: row.classifyCode,
              productId: row.id,
              lockFlag: lockFlag,
            }
            let res = await appApi.lockFalgEdit(data)
            if (res.data.respCode === '1000') {
              this.$_message.success('操作成功')
              this.getTableData()
            } else {
              this.$_message.error(res.data.respMsg || '操作失败')
            }
          }
        } catch (error) {
          //
        }
      },
      cancelSubmit () {
        this.fileDialog.passVisible = false
      },
  
      async finalSubmit () {
        this.finalLoading = true
        let res = await appApi.importSort(1)
        if (res.data.respCode === '1000') {
          this.finalLoading = false
          this.fileDialog.passVisible = false
          if (res.data.body && res.data.body.length) {
            this.gridData = res.data.body
            this.fileDialog.successVisible = true
          } else {
            this.gridData = res.data.body
            this.fileDialog.simpleVisible = true
          }
          this.getTableData()
        } else if (res.data.respCode === '2001') {
          this.finalLoading = false
          this.fileDialog.passVisible = false
          let str = res.data.respMsg.replace(/\n/g, '</br>')
          console.log(str)
          this.$alert(str, '以下产品不在当前广告板块支持的特色标签范围内:', {
            confirmButtonText: '我知道了',
            showClose: false,
            dangerouslyUseHTMLString: true,
            callback: () => {
              //
            },
          })
        } else if (res.data.respCode === '2000') {
          this.finalLoading = false
          this.fileDialog.passVisible = false
          let str = res.data.respMsg.replace(/\n/g, '</br>')
          console.log(str)
          this.$alert(str, '以下产品不允许上硬广位:', {
            confirmButtonText: '我知道了',
            showClose: false,
            dangerouslyUseHTMLString: true,
            callback: () => {
              //
            },
          })
        } else {
          this.finalLoading = false
          this.$_message.error(res.data.respMsg)
        }
      },
      exportBtn () {
        // let url = ''
        // let params = this.getQueryParams()
        // for (let item in params) {
        //   if (params[item]) {
        //     url += `${item}=${params[item]}&`
        //   }
        // }
        // url = url.substring(0, url.length - 1)
        // window.location.href = `${URL_EXPORT_HISTORY_DETAIL}?` + url
      },
      down () {
        let channelId = this.channelId
        let tag = !this.showFirst ? null : this.queryForm.tag
        let productId = this.queryForm.productId ? this.queryForm.productId : ''
        // channelId: this.channelId,
        //   classifyCode: parseInt(this.classifyCode),
        //   name: this.queryForm.name,
        //   productId: this.queryForm.productId ? this.queryForm.productId : null,
        // tag: !this.showFirst ? null : this.queryForm.tag ? parseInt(this.queryForm.tag) : null
        if (this.showFirst) {
          window.location.href = process.env.BASE_API +
      `/product/exportSort?channelId=${channelId}&classifyCode=${this.classifyCode}&name=${this.queryForm.name}&productId=${productId}&tag=${tag}`
        } else {
          window.location.href = process.env.BASE_API +
      `/product/exportSort?channelId=${channelId}&classifyCode=${this.classifyCode}&name=${this.queryForm.name}&productId=${productId}`
        }
      },
      // 小导航改变事件
      tabPositionChange () {
        this.disShowOrHide()
        this.getTableData() // 获取表格数据
        let arr = ['1', '2', '3', '4', '7', '8', '21', '23', '24', '25', '26', '27', '28']
        if (arr.includes(this.classifyCode)) {
          this.fetchMaxTable()
        } else {
          this.typeId = 1
        }
      },
      clearMaxTable () {
        this.tableDataObj[this.classifyCode] = []
      },
      clearAllTable () {
        this.tableDataObj = {
          1: [],
          2: [],
          3: [],
          4: [],
          7: [],
          8: [],
          21: [],
          23: [],
          24: [],
          25: [],
          26: [],
          27: [],
          28: [],
        }
      },
      async fetchMaxTable () {
        let data = {
          classifyCode: parseInt(this.classifyCode),
          channelId: this.channelId,
          pageSize: this.classPagination.pageSize,
          pageIndex: this.classPagination.pageNo,
        }
        let res = await api.list(data)
        if (res.data.respCode === '1000') {
          if (this.tableDataObj[this.classifyCode]&&!this.tableDataObj[this.classifyCode].length) {
            if (['1', '2', '3', '4'].includes(this.classifyCode)) {
              res.data.body.hardAdvertisementInfoVoList.forEach((t) => {
                t.idStr = this.classifyCode + '-' + t.id
              })
            }
            this.tableDataObj[this.classifyCode] = res.data.body.hardAdvertisementInfoVoList
            this.classPagination.pageNo = res.data.body.pageIndex
            this.classPagination.total = res.data.body.totalCount
          }
        } else {
          this.$message.error(res.data.respMsg)
        }
      },
      // 父tab改变事件
      channelIdChange () {
        /* if (this.channelId === 3 || this.channelId === 4) {
          this.tagList.forEach(item => {
            if (item.addressType === '4') {
              item.isShow = false
            }
          })
        } else {
          this.tagList.forEach(item => {
            if (item.addressType === '4') {
              item.isShow = true
            }
          })
        } */
        this.tableDataObj = {
          1: [],
          2: [],
          3: [],
          4: [],
          7: [],
          8: [],
          21: [],
          23: [],
          24: [],
          25: [],
          26: [],
          27: [],
          28: [],
        }
        this.fetchMaxTable()
        this.getTableData() // 获取表格数据
      },
      // 区分显示隐藏
      disShowOrHide () {
        let arr = ['9', '22', '1', '2', '3', '4', '11', '12', '13']
        let brr = ['18', '6', '20']
        if (arr.indexOf(this.classifyCode) > -1) {
          this.showFirst = true
        } else {
          this.showFirst = false
        }
        if (brr.indexOf(this.classifyCode) > -1) {
          this.showSecond = true
        } else {
          this.showSecond = false
        }
      },
      // 预览排序
      previewSort () {
        let flag = false
        this.tableData.forEach((item) => {
          if (item.classifySort === 0) {
            flag = true
          }
        })
        if (flag) {
          this.$_message.warning('排序数字必须为正整数或空')
        } else {
          this.sortVerification('preview')
        }
      },
      // 提交排序
      submitSort () {
        let flag = false
        this.tableData.forEach((item) => {
          if (item.classifySort === 0) {
            flag = true
          }
        })
        if (flag) {
          this.$_message.warning('排序数字必须为正整数或空')
        } else {
          this.sortVerification('submit')
        }
      },
      // 排序验证
      sortVerification (type) {
        let num = 0
        let ary = []
        let nary = []
        let isReturn = false
        this.tableData.forEach((item) => {
          if (item.classifySort) {
            num++
            ary.push(item.classifySort)
          }
        })
        if (!ary.length) {
          return this.$_message.warning('未填排序')
        }
        nary = ary.sort()
        // console.log(ary, 1)
        // console.log(nary, 2)
        for (let i = 0; i < ary.length; i++) {
          if (nary[i] === nary[i + 1]) {
            // console.log(nary[i], i)
            // console.log(nary[i + 1], i + 1)
            isReturn = true
          }
        }
        if (isReturn) {
          return this.$_message.warning('排序数字不能重复')
        }
        if (this.classifyCode === '22') {
          if (num < 4) {
            return this.$_message.warning(this.tagObj[this.classifyCode] + ':' + '参与排序的产品数量不得少于4,请检查。')
          } else {
            this.validateAgain(type)
          }
        }
  
        if (this.showFirst && this.classifyCode !== '22') {
          if (num <= 1) {
            return this.$_message.warning(this.tagObj[this.classifyCode] + ':' + '参与排序的产品数量不得少于2,请检查。')
          } else {
            this.validateAgain(type)
          }
        } else if (this.classifyCode === '18') {
          if (num < 0) {
            return this.$_message.warning(this.tagObj[this.classifyCode] + ':' + '参与排序的产品数量需大于0，请检查。')
          } else {
            this.validateisChooseLink(type)
          }
        } else if (this.classifyCode === '6' || this.classifyCode === '20') {
          this.validateisChooseLink(type)
        } else if (this.classifyCode === '21') {
          if (num > 1) {
            return this.$_message.warning(this.tagObj[this.classifyCode] + ':' + '参与排序的产品数量必须为0或1，请检查。')
          } else {
            this.validateAgain(type)
          }
        } else if (this.classifyCode === '7' || this.classifyCode === '8') {
          if (num !== 3) {
            return this.$_message.warning(this.tagObj[this.classifyCode] + ':' + '参与排序的产品数量必须为3，请检查。')
          } else {
            this.validateAgain(type)
          }
        } else if (this.classifyCode === '14') {
          this.validateisChooseLink(type)
        } else {
          this.validateCommon(type)
        }
      },
      validateCommon (type) {
        if (type === 'preview') {
          window.open('#/preview-data/' + this.classifyCode, JSON.stringify(this.tableData))
        } else {
          this.submitConfirm() // 提交排序
        }
      },
      // resize回调修改表格高度
      handleResize () {
        let _this = this
        _this.debounceIdentify && clearTimeout(_this.debounceIdentity)
        _this.debounceIdentity = setTimeout(() => {
          console.log('科学防抖')
          _this.$nextTick(() => {
            let h = document.documentElement.clientHeight
            _this.tableHeight = h - 150
          })
        }, 300)
      },
      // 筛选按钮
      handleSearch () {
        this.getTableData()
      },
      // 获取数据
      async getTableData () {
        this.listLoading = true
        this.searchLoading = true
        localStorage.setItem('channelId',this.channelId)
        localStorage.setItem('classifyCode',this.classifyCode)
        let data = {
          channelId: this.channelId,
          constraintUvSinkFlag: this.queryForm.constraintUvSinkFlag,
          uvSinkFlag: this.queryForm.uvSinkFlag,
          classifyCode: parseInt(this.classifyCode),
          name: this.queryForm.name,
          productId: this.queryForm.productId ? this.queryForm.productId : null,
          tag: !this.showFirst ? null : this.queryForm.tag ? parseInt(this.queryForm.tag) : null,
        }
        try {
          let res = await appApi.fetchTableData(data)
          if (res.data.respCode === '1000') {
            this.tableData = res.data.body
            this.listLoading = false
            this.searchLoading = false
          } else {
            this.listLoading = false
            this.searchLoading = false
          }
        } catch (error) {
          this.listLoading = false
          this.searchLoading = false
          console.log(error)
        }
      },
      // 点击去向编辑按钮
      editdirection (val) {
        this.dialogName = val.name
        this.editForm.couponName = val.couponName ? val.couponName : ''
        this.editForm.subCouponName = val.subCouponName ? val.subCouponName : ''
        this.editForm.couponContent = val.couponContent ? val.couponContent : ''
        this.editForm.clickDestination = val.clickDestination
        this.editForm.id = val.id
        if (this.classifyCode === '18') {
          this.picList = val.openAds
        } else if (this.classifyCode === '6') {
          this.picList = val.homeBanners
        } else if (this.classifyCode === '20') {
          this.picList = val.homePops
        }
        this.links = val.links
        this.picList.forEach((t) => { if (t.classInUse) { this.editForm.imgSeqId = t.seqId } })
        this.links.forEach((t) => { if (t.classInUse) { this.editForm.linkSeqId = t.seqId } })
        this.dialogDirectionVisible = true
      },
      // 验证开屏广告
      validate (type) {
        // let flag = true
        // let str = ''
        // this.tableData.forEach((item) => {
        //   let flagCoupon = true
        //   if (this.classifyCode === '18') {
        //     this.flagOpenAds = null
        //     if (!item.openAds.length) {
        //       this.flagOpenAds = false // 未配置
        //     } else {
        //       for (let i = 0; i < item.openAds.length; i++) {
        //         if (item.openAds[i].classInUse) {
        //           this.flagOpenAds = true // 存在classInUse为1的则配置了
        //           break
        //         }
        //       }
        //     }
        //   } else if (this.classifyCode === '6') {
        //     this.flagHomeBanners = null
        //     if (!item.homeBanners.length) {
        //       this.flagHomeBanners = false // 未配置
        //     } else {
        //       for (let i = 0; i < item.homeBanners.length; i++) {
        //         if (item.homeBanners[i].classInUse) {
        //           this.flagHomeBanners = true // 存在classInUse为1的则配置了
        //           break
        //         }
        //       }
        //     }
        //   } else if (this.classifyCode === '20') {
        //     this.flagHomePops = null
        //     if (!item.homePops.length) {
        //       this.flagHomePops = false // 未配置
        //     } else {
        //       for (let i = 0; i < item.homePops.length; i++) {
        //         if (item.homePops[i].classInUse) {
        //           this.flagHomePops = true // 存在classInUse为1的则配置了
        //           break
        //         }
        //       }
        //     }
        //   }
        //   let isClassify = this.classifyCode === '18' ? this.flagOpenAds : this.classifyCode === '6' ? this.flagHomeBanners : this.classifyCode === '20' ? this.flagHomePops : flagCoupon
        //   if (item.classifySort && !isClassify) {
        //     flag = false
        //     str += (item.name + '<br/>')
        //   }
        // })
          if (type === 'preview') {
            window.open('#/preview-data/' + this.classifyCode, JSON.stringify(this.tableData))
          } else {
            // 请求提交排序接口
            this.submitConfirm() // 提交排序
          }
        //取消素材验证，先注释不删，后续可能有改动
        // if (flag) {
        //   if (type === 'preview') {
        //     window.open('#/preview-data/' + this.classifyCode, JSON.stringify(this.tableData))
        //   } else {
        //     // 请求提交排序接口
        //     this.submitConfirm() // 提交排序
        //   }
        // } else {
        //   this.$alert(str, '以下产品的' + this.tagObj[this.classifyCode] + '尚未配置,请检查', {
        //     confirmButtonText: '我知道了',
        //     dangerouslyUseHTMLString: true,
        //     callback: () => {
        //       //
        //     },
        //   })
        // }
      },
      // 是否填写链接验证
      isChooseLink () {
        let flag = true
        let str = ''
        this.tableData.forEach((item) => {
          if (!item.linkSelected && item.classifySort) {
            flag = false
            str += (item.name + '<br/>')
          }
        })
        if (flag) {
          return 1
        } else {
          return str
        }
      },
      // 验证
      validateAgain (type) {
        if (this.isChooseLink() === 1) {
          if (type === 'preview') {
            window.open('#/preview-data/' + this.classifyCode, JSON.stringify(this.tableData))
          } else {
            this.submitConfirm() // 提交排序
          }
        } else {
          this.$alert(this.isChooseLink(), '以下产品的链接尚未配置,请检查', {
            confirmButtonText: '我知道了',
            dangerouslyUseHTMLString: true,
            showClose: false,
            callback: () => {
              //
            },
          })
        }
      },
      // 验证开屏广告图片的
      validateisChooseLink (type) {
        if (this.isChooseLink() === 1) {
          this.validate(type)
        } else {
          this.$alert(this.isChooseLink(), '以下产品的链接尚未配置,请检查', {
            confirmButtonText: '我知道了',
            dangerouslyUseHTMLString: true,
            showClose: false,
            callback: () => {
              // /
            },
          })
        }
      },
      // 提交排序
      submitConfirm () {
        this.$confirm('确定提交产品排序列表?', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }).then(() => {
          this.submitConfirmAgain() // 确认提交排序
        }).catch(() => {
          this.$_message({
            type: 'info',
            message: '已取消排序',
          })
        })
      },
      // 确认提交排序
      async submitConfirmAgain () {
        let arr = []
        this.tableData.forEach((item) => {
          arr.push({
            'classifyCode': parseInt(item.classifyCode),
            'classifyId': item.classifyId,
            'classifySort': item.classifySort ? item.classifySort : null,
            'productId': item.id,
          })
        })
        let res = await appApi.fetchSubmitData(JSON.stringify(arr))
        if (res.data.respCode === '1000') {
          this.$_message.success('提交排序成功')
          this.getTableData() // 排序成功重新获取数据
        } else if (res.data.respCode === '2001') {
          let str = res.data.respMsg.replace(/\n/g, '</br>')
          console.log(str)
          this.$alert(str, '以下产品不在当前广告板块支持的特色标签范围内：', {
            confirmButtonText: '我知道了',
            showClose: false,
            dangerouslyUseHTMLString: true,
            callback: () => {
              //
            },
          })
        } else if (res.data.respCode === '2000') {
          let str = res.data.respMsg.replace(/\n/g, '</br>')
          console.log(str)
          this.$alert(str, '以下产品不允许上硬广位：', {
            confirmButtonText: '我知道了',
            showClose: false,
            dangerouslyUseHTMLString: true,
            callback: () => {
              //
            },
          })
        } else {
          this.$_message.error(res.data.respMsg || '接口错误')
        }
      },
      // 点击查看
      watchDetail (name, value, classifyCode) {
        this.dialogName = name
        let flag = false
        let arr = []
        value.forEach((item) => {
          if (item.classInUse) {
            flag = true
            arr.push(item)
          }
        })
        if (!flag) {
          this.$alert('产品' + name + '尚未配置' + this.tagObj[classifyCode], '提示', {
            confirmButtonText: '我知道了',
            callback: () => {
              //
            },
          })
        } else {
          this.watchDetailList = arr
          this.dialogVisiblePic = true
        }
      },
      // 编辑用户定向弹框关闭
      handleDirectionClose () {
        this.resetForm('editForm')
        // 编辑表单
        this.editForm = {
          couponName: '',
          subCouponName: '',
          couponContent: '',
          clickDestination: 1,
          linkSeqId: null, // 链接
          imgSeqId: null, // 图片序号
          id: null, // 产品ID
        }
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      // 提交点击去向表单
      handleDirectionSubmit () {
        this.submitForm('editForm')
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.submitFormConfirm()
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      async submitFormConfirm () {
        let data = {
          addressType: parseInt(this.classifyCode),
          channelId: this.channelId,
          clickDestination: this.editForm.clickDestination,
          couponContent: this.editForm.couponContent,
          couponName: this.editForm.couponName,
          imgSeqId: this.editForm.imgSeqId,
          linkSeqId: this.editForm.linkSeqId,
          productId: this.editForm.id,
          subCouponName: this.editForm.subCouponName,
        }
        let res = await appApi.fetchEditDirectionForm(data)
        if (res.data.respCode === '1000') {
          this.$_message.success('编辑成功')
          this.dialogDirectionVisible = false
          this.getTableData()
        } else {
          this.$_message.error(res.data.respMsg || '接口错误')
          this.dialogDirectionVisible = false
        }
      },
      // 批量修改-清空已上传的文件列表
      handleClearFiles () {
        this.fileList = []
        this.file = null
      },
      // 批量修改-上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
      handleUploadBefore (file) {
        if (file.name && file.name.length > 0) {
          const ldot = file.name.lastIndexOf('.')
          const type = file.name.toLowerCase().substring(ldot)
          if (type !== '.csv') {
            this.$_message.warning('目前只支持.csv格式的文件')
            return false
          }
          this.uploadFileName = file.name
          console.log(this.uploadFileName)
        }
      },
      // 批量修改-文件上传成功时的钩子
      handleUploadSuccess () {
        console.log('上传成功')
        this.uploadTagVisible = true
      },
      // 批量修改-文件上传失败时的钩子
      handleUploadError (err) {
        if (err.status === 404) {
          this.$_message.error('上传失败，网络连接异常!')
        } else {
          console.log(err)
          this.$_message.error('上传失败!')
        }
      },
      // 导入项目-文件上传时的钩子
      handleUploadProgress () {
        this.isUploading = true // 开启提示
        console.log('上传中...')
      },
      // 导入项目-文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
      async handleUploadChange (file) {
        this.handleClearFiles()
        this.fileList = [file]
        this.uploadFileName = file.name
        this.file = file.raw
        this.uploading = true
        // let data = {
        //   channelId: this.channelId,
        //   classifyCode: parseInt(this.classifyCode),
        //   name: this.queryForm.name,
        //   productId: this.queryForm.productId ? this.queryForm.productId : null,
        //   tag: !this.showFirst ? null : this.queryForm.tag ? parseInt(this.queryForm.tag) : null,
        //   file: this.file
        // }
        let param = new window.FormData()
        let data = {
          channelId: this.channelId,
          name: this.queryForm.name,
          productId: this.queryForm.productId ? this.queryForm.productId : '',
          tag: !this.showFirst ? '' : this.queryForm.tag ? parseInt(this.queryForm.tag) : '',
          classifyCode: parseInt(this.classifyCode),
        }
        // param.append('channelId', this.channelId)
        // param.append('classifyCode', parseInt(this.classifyCode))
        // param.append('name', this.queryForm.name)
        // param.append('productId', this.queryForm.productId ? this.queryForm.productId : null)
        // param.append('tag', !this.showFirst ? null : this.queryForm.tag ? parseInt(this.queryForm.tag) : null)
        param.append('file', this.file)
        try {
          let res = await appApi.importValidation(param, data)
          if (res.data.respCode === '1000') {
          // this.$message.success(res.data.respMsg)
            this.fileDialog.passVisible = true
            if (res.data.body) {
              this.gridData = res.data.body
            }
            this.uploading = false
          } else if (res.data.respCode === '1118') {
            this.uploading = false
            this.fileDialog.typeName = '点击链接'
            if (res.data.body) {
              try {
                let data = []
                res.data.body.forEach((t) => {
                  data.push(t)
                })
                this.listString = data.join(';')
              } catch (error) {
                //
              }
            }
            this.fileDialog.dialogVisible = true
          } else if (res.data.respCode === '1119') {
            this.uploading = false
            this.fileDialog.typeName = '广告图片'
            if (res.data.body) {
              try {
                let data = []
                res.data.body.forEach((t) => {
                  data.push(t)
                })
                this.listString = data.join(';')
              } catch (error) {
                //
              }
            }
            this.fileDialog.dialogVisible = true
          } else if (res.data.respCode === '1120') {
            this.uploading = false
            this.fileDialog.typeName = '优惠券文案'
            if (res.data.body) {
              try {
                let data = []
                res.data.body.forEach((t) => {
                  data.push(t)
                })
                this.listString = data.join(';')
              } catch (error) {
                //
              }
            }
            this.fileDialog.dialogVisible = true
          } else if (res.data.respCode === '2001') {
            let str = res.data.respMsg.replace(/\n/g, '</br>')
            console.log(str)
            this.$alert(str, '以下产品不在当前广告板块支持的特色标签范围内:', {
              confirmButtonText: '我知道了',
              showClose: false,
              dangerouslyUseHTMLString: true,
              callback: () => {
                //
              },
            })
          } else if (res.data.respCode === '2000') {
            let str = res.data.respMsg.replace(/\n/g, '</br>')
            console.log(str)
            this.$alert(str, '以下产品不允许上硬广位:', {
              confirmButtonText: '我知道了',
              showClose: false,
              dangerouslyUseHTMLString: true,
              callback: () => {
                //
              },
            })
          } else {
            this.uploading = false
            this.fileDialog.errorMsg = res.data.respMsg
            this.fileDialog.errorVisible = true
          }
        } catch (error) {
          this.uploading = false
        }
      },
    },
  }
</script>

<style lang="scss" scoped>
.topLine{
  width: 100%;
  height: 2px;
  background: #667c99;
  margin-bottom: 5px;
  margin-top: 5px;
}
.font{
      color: #999999
    }
  .form-user-defined {
    .el-form-item {
      margin-right: 20px;
      margin-bottom: 10px;
    }
    .form-btn {
      .el-form-item {
        margin-right: 0;
      }
    }
  }
  .add-edit-user-dialog {
    .el-form-item {
      margin-bottom: 18px;
    }
    .el-select {
      width: 50%;
    }
  }

  .postscript {
    font-size: 12px;
    margin-left: 100px;
    margin-bottom: 10px;
  }

  .mb-20 {
    margin-bottom: 20px;
  }
  .topBox {
    /*text-align: center;*/
  }
  .box-card {
    display: inline-block;
    width: 858.55px;
    min-height: 600px;
    margin-top: 30px;
  }
  .imitate-a-label:hover {
    text-decoration: underline;
  }
  .el-radio-button__inner {
    padding: 10px 5px;
  }
  .pd {
    padding: 0 10px;
  }
  // .length-1 {
  //   width: 200px;
  // }
  .length-1{
  width: 250px
}
.font-info {
  color:#999999;
  font-size: 12px
}
.son{
  position: absolute;
  top:0;
  right:0
}
.parentPosition{
  position: relative;
  height:180px;
  width:678px
}
.fullPageFont {
  margin:100px auto;
  width: 500px;
  hetght:500px
}
</style>