<!--定时任务-->
<template>
  <div>
    <div class="topBox">
      <!-- 父tab -->
      <el-radio-group v-model="bigID" style="margin-top:0px;" size="small" @change="changeTab">
        <el-radio-button :label="item.value" v-for="(item,index) in bigTagList" :key="index">{{item.value}}</el-radio-button>
      </el-radio-group>
      <span class="searchView">
        <el-button type="success" size="mini" @click="changeSearchView" v-if="searchView[$route.path]">
        隐藏搜索项<i class="el-icon-arrow-up el-icon--right"></i>
        <!-- 隐藏搜索项<i class="el-icon-arrow-down el-icon--right"></i> -->
        </el-button>
        <el-button type="success" size="mini" @click="changeSearchView" v-else>
        展开搜索项<i class="el-icon-arrow-down el-icon--right"></i>
        <!-- 隐藏搜索项<i class="el-icon-arrow-down el-icon--right"></i> -->
        </el-button>
      </span>
      
    </div>
    <keep-alive>
     <router-view :searchView="searchView"></router-view>
    </keep-alive>
  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'
export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      searchView: {
        '/marketing/channelManage/channelTotal': true,
        '/marketing/channelManage/channelH5': true
      },
      permissionList: [],
      hasPer: [],
      bigID: '渠道汇总',
      allListL: [
        {key: '/marketing/channelManage/channelTotal', value: '渠道汇总'},
        {key: '/marketing/channelManage/channelService', value: '渠道服务商'},
        {key: '/marketing/channelManage/channelType', value: '渠道类型'},
        {key: '/marketing/channelManage/channelMedia', value: '投放媒体'},
        {key: '/marketing/channelManage/channelPrincipal', value: '渠道负责人'},
        {key: '/marketing/channelManage/channelH5', value: 'H5落地页'}
      ],
      bigTagList: [

      ]
    }
  },
  created () {
    this.permissionList = this.$store.state.permission.menuPathList
    console.log(this.permissionList)
    this.allListL.forEach(t => {
      this.permissionList.forEach(j => {
        if (t.key === j) {
          this.bigTagList.push(t)
        }
      })
    })
    if (this.bigTagList.length === 0) {
      this.$message.error('该模块没有授权页面！')
      this.$router.push({name: '花钱无忧后台'})
    }
    if (this.$route.path === '/marketing/channelManage') {
      this.$router.push({name: this.bigTagList[0].value})
    }
  },
  mounted () {
    // this.bigID = this.$route.name
  },
  watch: {
    '$route'(){
      this.bigID = this.$route.name
    }
  },
  computed: {
    key () {
      return this.$route.name !== undefined
        ? this.$route.name + +new Date()
        : this.$route + +new Date()
    }
  },
  methods: {
    changeSearchView () {
      this.searchView[this.$route.path] = !this.searchView[this.$route.path]
    },
    changeTab (val) {
      this.$router.push({name: this.bigID})
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 0px;
    position: relative;
  }
  .searchView {
    position: absolute;
    right:0px
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
