<!--定时任务-->
<template>
  <div style="margin-top:10px">
    <div>
      <el-form :inline="true" :model="queryForm" size="mini">
       <el-form-item label="渠道名:" label-width="80px">
         <el-input v-model="queryForm.typeName" placeholder="支持模糊查询" :maxlength="8"></el-input>
       </el-form-item>
       <el-form-item label="状态:" label-width="80px">
         <el-select v-model="queryForm.status">
            <el-option
             label="全部"
             value=""
            >
            </el-option>
            <el-option
             label="显示"
             :value="1"
            >
            </el-option>
            <el-option
             label="隐藏"
             :value="0"
            >
            </el-option>
          </el-select>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="fetchType">查询</el-button>
        <el-button type="primary" size="mini" @click="openAddDialog('addType')">添加渠道类型</el-button>
      </el-form-item>
    </el-form>
    </div>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row stripe :max-height="tableMaxHeight" style="width: 100%">
      <el-table-column
        sortable
        prop="id"
        fixed
        label="渠道类型ID"
        >
      </el-table-column>
      <el-table-column
        prop="name"
        label="渠道类型"
        :show-overflow-tooltip="true"
        >
        <template slot-scope="scope">
            <span class="btnText" @click="edit(scope.row)"> {{scope.row.typeName}}</span>
          </template>
      </el-table-column>
      <el-table-column
        prop="addTime"
        label="添加日期"
        >
      </el-table-column>
      <el-table-column
        prop="address"
        label="状态"
      >
      <template slot-scope="scope">
        {{scope.row.status === 1?'显示':'隐藏'}}
        <span @click.capture.stop="changeStatus(scope.row)">  
          <el-switch
          v-model="scope.row.statusView"
          active-color="#13ce66"
          inactive-color="#ff4949">
        </el-switch>  
        </span>
      </template>
      </el-table-column>
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
    <el-dialog :title="title" size="mini" :visible.sync="addDialog" @close="handleClose">
      <el-form size="mini" :model="addForm" ref='addForm' :rules="addRules">
        <el-form-item label="渠道类型:"  label-width="130px" prop="typeName">
          <el-input v-model="addForm.typeName" :maxlength="8" placeholder="请输入渠道类型，最多8个字符"></el-input>
        </el-form-item>
        <el-form-item label="状态:"  label-width="130px">
          <el-switch
          :active-value="1"
          :inactive-value="0"
          v-model="addForm.status"
          active-color="#13ce66"
          inactive-color="#ff4949">
        </el-switch>
        </el-form-item>
        <!-- <el-form-item label="添加日期:"  label-width="130px" prop="pageUrl">
          <el-input v-model="addForm.addTime" disabled></el-input>
        </el-form-item> -->
      </el-form>
      <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="addDialog = false">取消</el-button>
          <el-button type="primary" @click="submit" :disabled="addForm.typeName === ''">确认</el-button>
        </div>
    </el-dialog>
    <!-- <typeDialog :addType="showDialog.addType"  @closeDialog = "closeh5Dialog"> </typeDialog> -->
  </div>
</template>

<script>
import VueElTooltip from '../../../components/VueElTooltip'
import tableApi from '../../../api/tabApi.js'
import typeDialog from '../channel-tag/dialog/type-dialog.vue'
import commentApi from '../../../api/commentApi.js'
import Moment from 'moment'
export default {
  components: {
    typeDialog,
    VueElTooltip
  },
  data () {
    return {
      temp: {

      },
      addDialog: false,
      queryForm: {
        typeName: '',
        status: ''
      },
      addForm: {
        addTime: '',
        typeName: '',
        status: 1
      },
      addRules: {
        typeName: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (/^[-A-Za-z0-9\u4e00-\u9fa5]+$/.test(value)) {
                callback()
              } else {
                callback(new Error('不能为空,支持汉字、字母或数字!'))
              }
            }
          }
        ]
      },
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [30, 50, 100],
        pageSize: 30, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [],
      listLoading: false
    }
  },
  created () {
    this.fetchType()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {

  },
  methods: {
    async changeStatus (row) {
      try {
        let confirm = await this.$confirm(`确认更改状态吗?`, '提示', { type: 'warning' })
        if (confirm) {
          let data = {
            addTime: row.addTime,
            typeName: row.typeName,
            status: row.status === 1 ? 0 : 1,
            id: row.id,
            userId: this.$store.state.loginUser.userId
          }
          let res = await commentApi.typeSave(data)
          if (res.data.respCode === '1000') {
            this.$message.success('修改成功')
            this.fetchType()
            this.addDialog = false
          } else {
            this.$message.error(res.data.respMsg)
          }
        }
      } catch (error) {

      }
    },
    handleClose () {
      this.$refs.addForm.resetFields()
      let start = Moment(new Date()).format('YYYY-MM-DD')
      this.title = '添加渠道类型'
      this.addForm = {
        addTime: start,
        typeName: '',
        status: 1
      }
    },
    edit (row) {
      this.title = '编辑渠道类型'
      this.addForm = {
        id: row.id,
        addTime: row.addTime,
        typeName: row.typeName,
        status: row.status
      }
      this.addDialog = true
    },
    openAddDialog () {
      let start = Moment(new Date()).format('YYYY-MM-DD')
      this.title = '添加渠道类型'
      this.addForm = {
        addTime: start,
        typeName: '',
        status: 1
      }
      this.addDialog = true
    },
    async submit () {
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        let data = {
          ...this.addForm,
          userId: this.$store.state.loginUser.userId
        }
        let res = await commentApi.typeSave(data)
        if (res.data.respCode === '1000') {
          let str = this.title.substring(0, 2) + '成功'
          this.$message.success(str)
          this.fetchType()
          this.addDialog = false
        } else {
          this.$message.error(res.data.respMsg)
        }
      })
    },
    async fetchType () {
      let data = {
        ...this.queryForm,
        pageNum: this.pagination.pageNo,
        pageSize: this.pagination.pageSize
      }
      let res = await tableApi.type(data)
      if (res.data.respCode === '1000') {
        res.data.body.list.forEach(t => {
          t.status === 1 ? t.statusView = true : t.statusView = false
          t.addTime = Moment(new Date(t.addTime)).format('YYYY-MM-DD')
        })
        this.pagination.pageNo = res.data.body.pageNum
        // this.pagination.pageSize = res.data.body.pageSize
        this.pagination.total = res.data.body.total
        this.tableData = res.data.body.list
      }
    },
    openTypeDialog (val) {
      this.showDialog[val] = true
    },
    closeh5Dialog (val) {
      this.showDialog[val] = false
    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: '这是一段对标题的说明'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 140
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchType()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchType()
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
