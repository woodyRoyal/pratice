<!--定时任务-->
<template>
  <div>
    <div v-if="searchView[$route.path]">
      <div>
        <span class="fs-14"
              style="display:inline-height:38px">平台名称：</span>
        <el-radio-group v-model="queryForm.platformId"
                        size="mini"
                        type="card"
                        style="display: inline-block"
                        @change="fetchData">
          <el-radio-button v-for="(item,index) in selectList.platformList"
                           :key="index"
                           style="margin:5px 0"
                           :label="item.key">
            {{ item.value }}
          </el-radio-button>
        </el-radio-group>
      </div>
      <div>
        <span class="fs-14">渠道类型：</span>
        <el-radio-group v-model="queryForm.typeId"
                        size="mini"
                        type="card"
                        style="display: inline-block"
                        @change="fetchData">
          <el-radio-button v-for="(item,index) in selectList.typeList"
                           :key="index"
                           style="margin:5px 0"
                           :label="item.id">
            {{ item.typeName }}
          </el-radio-button>
        </el-radio-group>
      </div>
      <el-form :inline="true"
               :model="queryForm"
               size="mini"
               class="margin-mini">
        <el-form-item label="渠道号:"
                      label-width="80px">
          <el-input v-model="queryForm.name"
                    @keyup.native.enter="fetchData()"></el-input>
        </el-form-item>
        <!-- <el-form-item label="渠道商:"
                      label-width="80px">
          <el-select v-model="queryForm.facilitatorId"
                     style="width:163px"
                     filterable
                     clearable>
            <el-option
              v-for="(item,index) in selectList.facilitatorList"
              :key="index"
              :label="item.fullName"
              :value="item.id"
            >
              {{ item.fullName }}
            </el-option>
          </el-select>
        </el-form-item> -->
        <el-form-item label="负责人:"
                      label-width="80px">
          <el-select v-model="queryForm.principalId"
                     style="width:163px"
                     filterable
                     clearable>
            <el-option
              v-for="(item,index) in selectList.principalList"
              :key="index"
              :label="item.principalName"
              :value="item.id"
            >
              {{ item.principalName }}
            </el-option>
          </el-select>
        </el-form-item>
        </br>
        <el-form-item label="投放终端:"
                      label-width="80px">
          <el-select v-model="queryForm.terminal"
                     style="width:163px"
                     clearable>
            <el-option
              v-for="(item,index) in selectList.terminalList"
              :key="index"
              :value="item.key"
              :label="item.value" 
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="状态:"
                      label-width="80px">
          <el-select v-model="queryForm.status"
                     style="width:163px">
            <el-option
              v-for="(item,index) in statusList"
              :key="index"
              :value="item.key"
              :label="item.value" 
            >
              {{ item.value }}
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label=" "
                      label-width="20px">
          <el-button size="mini"
                     type="primary"
                     class="least"
                     @click="search">
            查询
          </el-button>
          <el-button size="mini"
                     type="primary"
                     class="least"
                     @click="down">
            导出
          </el-button>
          <el-button v-if="tabButtonPerms['channelTotal.addChannel']"
                     size="mini"
                     type="primary"
                     class="least"
                     @click="addDialog">
            添加渠道
          </el-button>
          <el-button v-if="tabButtonPerms['channelTotal.batchUpdate']"
                     size="mini"
                     type="primary"
                     class="least"
                     @click="openChangeManDialog()">
            批量变更负责人
          </el-button>
        </el-form-item>
      </el-form>
    </div>
    <!--表格-- >
    <!-- :max-height="tableMaxHeight" -->
    <el-table v-loading="listLoading"
              :data="tableData"
              border
              fit
              highlight-current-row
              stripe
              style="width: 100%"
              :max-height="tableMaxHeight">
      <el-table-column
        prop="id"
        fixed
        sortable
        label="渠道ID"
        width="70"
      >
      </el-table-column>
      <el-table-column
        prop="name"
        fixed
        label="渠道号"
      >
        <template slot-scope="scope">
          <el-popover
            placement="right"
            width="155"
            trigger="click">
            <el-form size="mini">
              <el-form-item> 
                <el-button style="width:130px"
                           @click="openEdit(scope.row,'read')">
                  查看
                </el-button>
              </el-form-item>
              <el-form-item v-if="tabButtonPerms['channelTotal.edit']"> 
                <el-button style="width:130px"
                           @click="openEdit(scope.row,'edit')">
                  编辑
                </el-button>
              </el-form-item>
              <el-form-item>
                <el-button @click="pushDetail(scope.row)">
                  查看30天推广数据
                </el-button>
              </el-form-item>
              <el-form-item>
                <el-button>查看30天质量数据</el-button>
              </el-form-item>
            </el-form>
            <!-- <el-button slot="reference" type="text">{{scope.row.name}}</el-button> -->
            <span slot="reference"
                  class="btnText">{{ scope.row.name }}</span>
          </el-popover>
          <!-- <el-button type="text" class="urlSty" @click="openEditDialog">{{scope.row.name}}</el-button> -->
        </template>
      </el-table-column>
      <el-table-column
        prop="typeName"
        label="渠道类型"
        width="110"
      >
      </el-table-column>
      <!-- <el-table-column
      type="selection"
      width="50">
    </el-table-column> -->

      <el-table-column
        prop="paymentName"
        label="付费方式" 
        width="120"
      >
      </el-table-column>
      <el-table-column
        prop="price"
        label="单价"
        width="80"
        sortable
      >
        <template slot-scope="scope">
          {{ scope.row.priceView }}
        </template>
      </el-table-column>
      <el-table-column
        prop="principalName"
        label="负责人"
        width="80"
      >
      <!-- <template slot-scope="scope">
        <span>{{scope.row.nameView}}</span>
      </template> -->
      </el-table-column>
      </el-table-column>
      <el-table-column
        prop="qualityScore"
        label="质量评分"
        width="100"
        sortable
      >
      </el-table-column>
      <!-- <el-table-column
        prop="facilitatorShortName"
        label="渠道商简称"
      >
      </el-table-column> -->
      <el-table-column
        prop="mediaName"
        label="媒体"
        width="80"
      >
      </el-table-column>
      <el-table-column
        prop="platformName"
        label="平台名称"
        width="90"
      >
      </el-table-column>
      <el-table-column
        prop="productLineName"
        label="产品线"
        width="90"
      >
      </el-table-column>
      <el-table-column
        prop="terminalName"
        label="手机系统"
        width="80"
      >
      </el-table-column>
      <el-table-column
        prop="addTime"
        label="添加日期"
        width="80"
        sortable
      >
      </el-table-column>
      <el-table-column
        prop="promoteLinks"
        label="推广链接"
        width="95"
      >
        <template slot-scope="scope">
          <el-button
            v-if="scope.row.linkType !== 1 && scope.row.linkType !== null" 
            v-clipboard:copy="scope.row.promoteLinks" 
            v-clipboard:success="onCopy" 
            v-clipboard:error="onError"
            class="urlSty"
            size="mini"
            type="success"
          >
            复制URL
          </el-button>
          <span v-else>无</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="status"
        label="状态"
        width="75"
      >
        <template slot-scope="scope">
          {{ scope.row.status === 1?'显示':'隐藏' }}
          <el-switch
            v-model="scope.row.statusView"
            active-color="#13ce66"
            inactive-color="#ff4949"
            @change="changeStatus(scope.row)">
          </el-switch>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination-container">
      <el-pagination :current-page.sync="pagination.pageNo"
                     :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange">
      </el-pagination>
    </div>
    <mediaDialog :addmedia="showDialog.addmedia"
                 @closeDialog="closeh5Dialog">
    </mediaDialog>
    <facilitatorDialog :addfacilitator="showDialog.addfacilitator"
                       @closeDialog="closeh5Dialog">
    </facilitatorDialog>
    <!-- 渠道号编辑弹窗 -->
    <!-- <el-dialog :visible.sync="editDialog" width="30%" top="20%" style="text-align:center">
       <el-form>
         <el-form-item> 
           <el-button style="width:156px" @click="openEdit(scope.row)">编辑</el-button>
         </el-form-item>
         <el-form-item>
           <el-button>查看30天推广数据</el-button>
         </el-form-item>
         <el-form-item>
           <el-button>查看30天质量数据</el-button>
         </el-form-item>
       </el-form>
     </el-dialog> -->
    <!-- 批量变更负责人 -->
    <el-dialog title="批量变更负责人"
               size="mini"
               :visible.sync="changeManDialog">
      <el-form ref="batchPrincipal"
               size="mini"
               :model="batchPrincipal"
               :rules="batchRules">
        <el-form-item label="当前渠道负责人："
                      prop="principalIdOld"
                      label-width="140px">
          <el-select v-model="batchPrincipal.principalIdOld"
                     style="width:100%"
                     filterable>
            <el-option
              v-for="(item,index) in selectList.principalList"
              :key="index"
              :label="item.principalName"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="新的渠道负责人："
                      prop="principalIdNew"
                      label-width="140px">
          <el-select v-model="batchPrincipal.principalIdNew"
                     style="width:100%"
                     filterable>
            <el-option
              v-for="(item,index) in selectList.principalList"
              :key="index"
              :label="item.principalName"
              :value="item.id" 
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="更新渠道号："
                      prop="channelsType"
                      label-width="140px">
          <el-radio v-model="batchPrincipal.channelsType"
                    :label="0">
            指定渠道号
          </el-radio>
          <el-radio v-model="batchPrincipal.channelsType"
                    :label="1">
            全渠道
          </el-radio>
        </el-form-item>
        <el-form-item label=""
                      prop="channels"
                      label-width="140px">
          <el-input v-model="batchPrincipal.channels"
                    type="textarea"
                    :disabled="batchPrincipal.channelsType === 1">
          </el-input>
        </el-form-item>
        <el-form-item label=""
                      prop="000"
                      label-width="140px">
          注：渠道号之间，请用英文分号 ; 隔开
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button type="primary"
                   @click="submitPrincipal">
          确定变更
        </el-button>
      </div>
    </el-dialog>
    <!-- 添加渠道 -->
    <el-dialog :title="title"
               size="tiny"
               :visible.sync="dialogClassFormVisible"
               top="5vh"
               @close="handleClassDialogClose">
      <el-form ref="addform"
               :model="addform"
               size="mini"
               :rules="addformRules"
               label-width="90px">
        <el-row>
          <el-col :span="18">
            <el-form-item label="渠道号:"
                          prop="name"
                          label-width="100px">
              <el-input v-if="isEditName"
                        v-model="addform.name"
                        :disabled="isEditName || title === '查看'"></el-input>
              <el-input v-if="!isEditName"
                        v-model="addform.name"
                        type="textarea"
                        placeholder="每行1个渠道，最多100行，回车分隔"
                        :disabled="isEditName ||title === '查看'"
                        :autosize="{ minRows: 2, maxRows: 10}"
                        @blur="isLink()"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="2">
            <el-form-item :label="activeLabel"
                          prop="status">
              <el-switch
                v-model="addform.status"
                :disabled="title === '查看'"
                active-color="#13ce66"
                inactive-color="#ff4949">
              </el-switch>
              <!-- <el-checkbox v-model="addform.status"></el-checkbox> -->
            </el-form-item>
          </el-col>
        </el-row>
          
        <el-row>
          <el-col :span="18">
            <el-form-item label="负责人"
                          prop="principalId"
                          label-width="100px">
              <el-select v-model="addform.principalId"
                         style="width:100%"
                         filterable
                         :disabled="title === '查看'">
                <el-option
                  v-for="(item,index) in selectList.principalList"
                  :key="index"
                  :label="item.principalName"
                  :value="item.id" 
                >
                  {{ item.principalName }}
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <!-- <el-col :span="2">
              <el-form-item label=""  prop="classCode" style="margin-left:-42px;">
                <el-button size="mini" type="primary" @click="openTypeDialog('addH5')" :disabled="title === '查看'">
                  +
                </el-button>
              </el-form-item>
            </el-col> -->
        </el-row>

        <el-row>
          <el-col :span="18">
            <el-form-item label="渠道类型:"
                          prop="typeId"
                          label-width="100px">
              <el-select v-model="addform.typeId"
                         style="width:100%"
                         :disabled="title === '查看'">
                <el-option
                  v-for="(item,index) in selectList.addTypeList"
                  :key="index"
                  :label="item.typeName"
                  :value="item.id" 
                >
                  {{ item.typeName }}
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <!-- <el-col :span="2">
              <el-form-item label=""  prop="classCode" style="margin-left:-42px;">
                <el-button size="mini" type="primary" :disabled="title === '查看'">
                  +
                </el-button>
              </el-form-item>
            </el-col> -->
        </el-row>

        <!-- <el-row>
          <el-col :span="18">
            <el-form-item label="渠道商简称:"
                          prop="facilitatorId"
                          label-width="100px">
              <el-select v-model="addform.facilitatorId"
                         style="width:100%"
                         filterable
                         :disabled="title === '查看'">
                <el-option
                  v-for="(item,index) in selectList.facilitatorList"
                  :key="index"
                  :label="item.shortName"
                  :value="item.id" 
                >
                  {{ item.shortName }}
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="2">
            <el-form-item label=""
                          prop="classCode"
                          style="margin-left:-42px;">
              <el-button size="mini"
                         type="primary"
                         :disabled="title === '查看'"
                         @click="openTypeDialog('addfacilitator')">
                +
              </el-button>
            </el-form-item>
          </el-col>
        </el-row> -->
        <!-- <el-row>
          <el-col :span="18">
            <el-form-item label="渠道商全称:"
                          prop=""
                          label-width="100px">
              <el-select v-model="addform.facilitatorId"
                         style="width:100%"
                         disabled
                         placeholder=" ">
                <el-option
                  v-for="(item,index) in selectList.facilitatorList"
                  :key="index"
                  :label="item.fullName"
                  :value="item.id" 
                >
                  {{ item.fullName }}
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row> -->
        <el-row>
          <el-col :span="18">
            <el-form-item label="媒体:"
                          prop="mediaId"
                          label-width="100px">
              <el-select v-model="addform.mediaId"
                         style="width:100%"
                         filterable
                         :disabled="title === '查看'">
                <el-option
                  v-for="(item,index) in selectList.mediaList"
                  :key="index"
                  :label="item.mediaName"
                  :value="item.id" 
                >
                  {{ item.mediaName }}
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="2">
            <el-form-item label=""
                          prop="classCode"
                          style="margin-left:-42px;">
              <el-button size="mini"
                         type="primary"
                         :disabled="title === '查看'"
                         @click="openTypeDialog('addmedia')">
                +
              </el-button>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="18">
            <el-form-item label="付费方式:"
                          prop="payment"
                          label-width="100px">
              <el-select v-model="addform.payment"
                         style="width:100%"
                         :disabled="title === '查看'"
                         @change="changePayment">
                <el-option
                  v-for="(item,index) in selectList.feeList"
                  :key="index"
                  :value="item.key"
                  :label="item.value" 
                >
                  {{ item.value }}
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="18">
            <el-form-item label="结算数据源:"
                          prop="settleSource"
                          label-width="100px">
              <el-select v-model="addform.settleSource"
                         :placeholder="myplaceholder"
                         style="width:100%"
                         :disabled="addform.payment===0 ||title === '查看'"
                         @change="changeSource">
                <el-option
                  
                  v-for="(item,index) in selectList.settleSourceList"
                  :key="index"
                  :value="item.key"
                  :label="item.value" 
                >
                  {{ item.value }}
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="18">
            <el-form-item label="单价(元):"
                          prop="price"
                          label-width="100px">
              <el-input v-model="addform.price"
                        :disabled="isEditPrice ||title === '查看'"
                        :placeholder="myplaceholder"
                        @blur="fix2('price',2)"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="18">
            <el-form-item label="账户返点:"
                          prop="rebates"
                          label-width="100px">
              <el-input v-model="addform.rebates"
                        :disabled="isEditRebates || title === '查看'"
                        :placeholder="myplaceholder"
                        @blur="fix2('rebates',2)"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="18">
            <el-form-item label="质量评分:"
                          prop="qualityScore"
                          label-width="100px">
              <el-input v-model="addform.qualityScore"
                        placeholder="1.0"
                        disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="18">
            <el-form-item label="平台名称:"
                          prop="platform"
                          label-width="100px">
              <el-select v-model="addform.platform"
                         style="width:100%"
                         :disabled="title === '查看'"
                         @change="productListHandle(addform.platform)">
                <el-option
                  v-for="(item,index) in selectList.platformList2"
                  :key="index"
                  :value="item.key"
                  :label="item.value" 
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="18">
            <el-form-item label="产品线:"
                          prop="productLine"
                          label-width="100px">
              <el-select v-model="addform.productLine"
                         style="width:100%"
                         disabled
                         placeholder=" ">
                <el-option
                  v-for="(item,index) in selectList.productLine"
                  :key="index"
                  :label="item.value"
                  :value="item.key" 
                >
                  {{ item.value }}
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="18">
            <el-form-item label="投放终端:"
                          prop="terminal"
                          label-width="100px">
              <el-select v-model="addform.terminal"
                         style="width:100%"
                         :disabled="title === '查看'">
                <el-option
                  v-for="(item,index) in selectList.terminalList"
                  :key="index"
                  :value="item.key"
                  :label="item.value" 
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="18">
            <el-form-item label="目标用户分类"
                          prop="aimUserClass"
                          label-width="110px">
              <el-select v-model="addform.aimUserClass"
                         style="width:100%"
                         :disabled="title === '查看'">
                <el-option
                  v-for="(item,index) in selectList.aimUserClassList"
                  :key="index"
                  :value="item.key"
                  :label="item.value" 
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="18">
            <el-form-item label="添加日期:"
                          prop="addTime"
                          label-width="100px">
              <!-- <el-date-picker
                  disabled
                  v-model="addform.addTime"
                  style="width:100%"
                  value-format="yyyy-mm-dd"
                  >
                </el-date-picker> -->
              <el-input v-model="addform.addTime"
                        disabled>
              </el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="18">
            <el-form-item label="推广链接:"
                          label-width="100px">
              <el-select v-model="addform.linkType"
                         style="width:100%"
                         :disabled="title === '查看'">
                <el-option
                  v-for="(item,index) in selectList.linkTypeList"
                  :key="index"
                  :label="item.value"
                  :value="item.key" 
                >
                  {{ item.value }}
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-if="addform.linkType !== 1">
          <el-col :span="12">
            <el-form-item label=" "
                          prop="domainName"
                          label-width="100px">
              <el-select v-if="addform.linkType === 2"
                         v-model="addform.domainName"
                         style="width:100%"
                         :disabled="title === '查看'">
                <el-option
                  v-for="(item,index) in selectList.domainNameList"
                  :key="index"
                  :label="item.showDomain"
                  :value="item.realDomain" 
                >
                  {{ item.showDomain }}
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item label="https加密访问:"
                          prop="httpsFlag"
                          label-width="120px">
              <el-checkbox v-model="addform.httpsFlag"
                           :disabled="title === '查看'"></el-checkbox>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-if="addform.linkType !== 1">
          <el-form-item label-width="100px"
                        label=" ">
            <!-- <el-button
                    class="urlSty" 
                    size="mini" 
                    type="success"
                    @click="link()"
                    >生成URL</el-button> -->
            <el-button
              v-clipboard:copy="addform.promoteLinks"
              v-clipboard:success="onCopy"
              v-clipboard:error="onError"
              :disabled="title === '查看'" 
              style="margin-left:10px"
              class="urlSty"
              size="mini"
              type="success"
            >
              复制URL
            </el-button>
          </el-form-item>
        </el-row>
        <el-row v-if="addform.linkType !== 1">
          <el-col :span="18">
            <el-form-item label=" "
                          prop="promoteLinks"
                          label-width="100px">
              <el-input v-model="addform.promoteLinks"
                        type="textarea"
                        :disabled="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="info">
        <template v-if="addform.linkType === 2">
          <p>注：</p>
          <p style="line-height:16px">
            1、推广链接支持任意使用一下三个域名：（1）jieqian.2345.com（网络） （2）jieqian.2345jr.com（小贷）（3）jieqian.shengyingjr.com（盛盈）
          </p>
          <p style="line-height:16px">
            2、建议优先使用https，避免被劫持
          </p>
          <p style="line-height:16px">
            2、针对APP推广的H5落地页，url链接支持加参数（参数与参数之间用&链接）控制页面访问，目前已支持：
          </p>
          <p style="line-height:16px">
            （1）ICP备案信息文案：icpwl代表网络ICP，icpjr代表金融ICP，icpxd代表小贷ICP；
          </p>
          <p style="line-height:16px">
            （2）page#（H5页面样式）：如/page1，/page2；控制页面UI和前端样式
          </p>
          <p style="line-height:16px">
            （3）页面脚注：footerTip，若footerTip=true代表显示，footerTip=true代表隐藏；
          </p>
          <p style="line-height:16px">
            （4）media（媒体）：若投放渠道是vivo，必须加这个参数（下载包从vivo市场下载，目前只有vivo一个媒体）；若投放其他渠道，绝对不能加！
          </p>
          <p style="line-height:16px">
            样例：http://jiekuan.shengyingjr.com/wfree/m/tg/page1/index.html?channel=1111&icpjr&footerTip=true&media=vivo；
          </p>
        </template>
        <template v-if="addform.linkType === 3">
          <p>注：</p>
          <p style="line-height:16px">
            短信投放前，请通过第三方工具将此链接转换成短链接；
          </p>
          <p style="line-height:16px">
            样例：http://jiekuan.2345.com/wfree/m/dx/type1/index.html?channel=bx-zhaoshoudai_cpr_lsb；
          </p>
        </template>
        <template v-if="addform.linkType === 4">
          <p>注：</p>
          <p style="line-height:16px">
            请确保实际上传的Apk文件名和下载链接保持一致
          </p>
          <p style="line-height:16px">
            下载URL：https://app.2345.cn/hqwyandroid/app-#p#-#channel#.apk
          </p>
          <p style="line-height:16px">
            1、#p#根据页面推广的产品判断，如：hqwy代表花钱无忧、dkw代表贷款王、dasheng代表大圣钱包
          </p>
          <p style="line-height:16px">
            2、#channel#代表渠道号，取自H5落地页URL的channel值；
          </p>
          <p style="line-height:16px">
            样例：https://app.2345.cn/hqwyandroid/app-hqwy-#channel#.apk
          </p>
        </template>
        <template v-if="addform.linkType === 5">
          <p>注：</p>
          <p style="line-height:16px">
            目前H5聚合页仍是老系统，相关数据目前存储在老系统。若需看数据，请在老系统创建同名渠道号。
          </p>
          <p style="line-height:16px">
            样例：http://appunion.2345.com/dkw/?cid=31&title=1¬ice=0&adban=0&prom=0&list=1&jb=0&adbut=0；
          </p>
        </template>      
      </div>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="dialogClassFormVisible = false">
          取 消
        </el-button>
        <el-button v-if="this.title !=='查看'"
                   type="primary"
                   :disabled="isSubmit"
                   :loading="submitLoading"
                   @click="handleAddClassConfirm">
          确 定
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import VueElTooltip from '../../../components/VueElTooltip'
import totalApi from '../../../api/totalApi.js'
import h5Dialog from '../channel-tag/dialog/h5-dialog'
import facilitatorDialog from '../channel-tag/dialog/facilitator-dialog.vue'
import mediaDialog from '../channel-tag/dialog/media-dialog.vue'
import totalJson from './total.js'
import Moment from 'moment'
export default {
  components: {
    VueElTooltip,
    h5Dialog,
    facilitatorDialog,
    mediaDialog,
  },
  props: {
    searchView: {
      type: Object,
      default: {

      },
    },
  },
  data () {
    let checkName = async (rule, value, callback) => {
      if (!value || value === '') {
        return callback(new Error('渠道号不能为空'))
      }
      // if (this.title === '添加渠道') {

      //   let res = await totalApi.unique(this.addform.name)
      //   if (res.data.respCode === '1000' && res.data.body === '0') {
      //     callback()
      //   } else {
      //     callback(new Error('渠道号重复！'))
      //   }
      // } else {
      //   callback()
      // }
      if (this.title === '添加渠道') {
        let NameList = []
        NameList = this.addform.name.split('\n')
        NameList = NameList.map((v) => this.trimSpace(v, 'g'))
        NameList = this.bouncer(NameList)
        // let NameList = []
        // NameList = this.bouncer(this.addform.name.split('\n'))
        console.log(NameList, '过滤')
        if (NameList.length > 100) {
          return callback(new Error(`最多100行`))
        }
        for (let i = 0; i < NameList.length; i++) {
          if (NameList[i].length > 100) {
            return callback(new Error(`第${i + 1}行超过了100字！`))
          }
        }
        let res = await totalApi.checkChannelName({listName: NameList})
        if (res.data.respCode === '1000') {
          callback()
        } else {
          callback(new Error('渠道号重复！'))
        }
      } else {
        callback()
      }
    }
    return {
      submitLoading: false,
      hashMap: {

      },
      activeNames: ['1'],
      tabButtonPerms: {
        'channelTotal.addChannel': false,
        'channelTotal.edit': false,
        'channelTotal.batchUpdate': false,
      },
      showDialog: {
        addH5: false,
        addfacilitator: false,
        addmedia: false,
      },
      selectList: {
        aimUserClassList: [
          {key: 0, value: '不限'},
          {key: 1, value: '小额消费贷用户'},
          {key: 2, value: '大额分期用户'},
        ],
        mediaList: [],
        // 渠道服务商
        facilitatorList: [],
        typeList: [],
        // 渠道负责人
        principalList: [],
        addTypeList: [],
        settleSourceList: totalJson.settleSourceList,
        terminalList: totalJson.terminalList,
        feeList: totalJson.feeList,
        platformList: totalJson.platformList3,
        platformList2: totalJson.platformList2,
        productLine: totalJson.productLine,
        domainNameList: [],
        linkTypeList: totalJson.linkTypeList,
        principalDoc: {

        },
      },
      editDialog: false,
      changeManDialog: false,
      dialogClassFormVisible: false,
      statusList: [
        {key: 1, value: '仅显示'},
        {key: 0, value: '仅隐藏'},
        {key: 3, value: '不限'},
      ],
      queryForm: {
        // facilitatorId: '',
        status: 1,
        name: '',
        platformId: 0,
        principalId: '',
        terminal: 3,
        typeId: 0,
      },
      https: {
        domainName: '',
        httpsFlag: 1,
        linkType: 1,
      },
      batchPrincipal: {
        principalIdNew: '',
        principalIdOld: '',
        channels: '',
        channelsType: 1,
        idOld: '',
      },
      batchRules: {
        principalIdNew: [
          { required: true, message: '请选择', trigger: 'change' },
        ],
        principalIdOld: [
          { required: true, message: '请选择', trigger: 'change' },
        ],
        channels: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.batchPrincipal.channelsType === 0 && value === '') {
                callback(new Error('请输入指定的渠道号!'))
              } else {
                callback()
              }
            },
          },
        ],
      },
      addform: {
        id: null,
        addTime: '',
        createUserId: '',
        // facilitatorId: '',
        mediaId: '',
        name: '',
        payment: '',
        platform: '',
        price: '',
        principalId: '',
        promoteLinks: '',
        qualityScore: '',
        rebates: '',
        settleSource: '',
        status: true,
        terminal: '',
        typeId: '',
        domainName: '',
        httpsFlag: true,
        linkType: 1,
        aimUserClass: 0,
      },
      addformRules: {
        name: [{validator: checkName, trigger: 'blur', required: true}],
        principalId: [{ required: true, message: '请选择', trigger: 'change' }],
        typeId: [{ required: true, message: '请选择', trigger: 'change' }],
        facilitatorId: [{ required: true, message: '请选择', trigger: 'change' }],
        mediaId: [{ required: true, message: '请选择', trigger: 'change' }],
        payment: [{ required: true, message: '请选择', trigger: 'change' }],
        aimUserClass: [{ required: true, message: '请选择', trigger: 'change' }],
        settleSource: [
          {
            required: true,
            trigger: 'change',
            validator: (rule, value, callback) => {
              if (this.addform.payment !== 0 && value === '') {
                callback(new Error('请选择!'))
              } else {
                callback()
              }
            },
          },
        ],
        price: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.addform.payment !== 0 && value === '') {
                callback(new Error('输入格式错误，请输入数字，最多保留小数点后2位！'))
              } else if (this.addform.payment !== 0 && /^[0-9.]*$/.test(value)) {
                callback()
              } else if (this.addform.payment === 0) {
                callback()
              } else {
                callback(new Error('输入格式错误，请输入数字，最多保留小数点后2位！'))
              }
            },
          },
        ],
        rebates: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.addform.payment !== 0) {
                if (this.addform.settleSource === 1) {
                  callback()
                } else {
                  if (/^[0-9.]*$/.test(value) && value >= 1) {
                    callback()
                  } else {
                    callback(new Error('请输入账户返点(数字),须≥1.0！'))
                  }
                }
              } else {
                callback()
              }
              // if (this.addform.payment !== 0 && value === '') {
              //   callback(new Error('输入格式错误，请输入数字，最多保留小数点后3位！'))
              // } else if (this.addform.payment !== 0 && /^[0-9.]*$/.test(value)) {
              //   callback()
              // } else if (this.addform.payment === 0) {
              //   callback()
              // } else {
              //   callback(new Error('输入格式错误，请输入数字，最多保留小数点后3位！'))
              // }
            },
          },
        ],
        platform: [{ required: true, message: '请选择', trigger: 'change' }],
        terminal: [{ required: true, message: '请选择', trigger: 'change' }],
      },
      nameID: 1,
      typeID: 1,
      nameList: [
        {key: 1, value: '不限'},
        {key: 2, value: '花钱无忧'},
        {key: 3, value: '无忧钱包'},
        {key: 4, value: '大圣钱包'},
        {key: 5, value: '贷款王'},
        {key: 6, value: 'H5聚合页'},
      ],
      typeList: [
        {key: 0, value: '不限'},
        {key: 1, value: '信息流'},
        {key: 2, value: '外部短信'},
        {key: 3, value: '贷款平台'},
        {key: 4, value: '苹果官方市场'},
        {key: 5, value: '安卓应用市场'},
      ],
      title: '',
      tableMaxHeight: 800,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [30, 50, 100],
        pageSize: 30, // pageSize
        total: 0, // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null,
      },
      tableData: [],
      listLoading: false,
    }
  },
  computed: {
    pageHeight () {
      if (this.searchView[this.$route.path]) {
        return 240
      } else {
        return 100
      }
    },
    isSubmit () {
      if (this.addform.payment === 0) {
        if (
          this.addform.mediaId === '' ||
          this.addform.name === '' ||
          this.addform.mediaId === '' ||
          this.addform.platform === '' ||
          this.addform.principalId === '' ||
          this.addform.terminal === '' ||
          this.addform.typeId === ''
        ) {
          return true
        } else {
          return false
        }
      }

      if (this.addform.payment !== 0) {
        if (
          this.addform.mediaId === '' ||
          this.addform.name === '' ||
          this.addform.mediaId === '' ||
          this.addform.platform === '' ||
          this.addform.price === '' ||
          this.addform.principalId === '' ||
          // this.addform.rebates === '' ||
          this.addform.terminal === '' ||
          this.addform.typeId === '' ||
          this.addform.payment === '' ||
          this.addform.settleSource === ''
        ) {
          return true
        } else {
          return false
        }
      }
    },
    isEditRebates () {
      if (this.addform.payment === 0) return true
      if (this.addform.payment !== 0 && this.addform.settleSource === 1) {
        return true
      }
      if (this.addform.payment !== 0 && this.addform.settleSource === 2) {
        return false
      }
    },
    myplaceholder () {
      if (this.addform.payment === 0) return '-'
      return ''
    },
    isEditPrice () {
      if (this.addform.payment === 0) return true
      return false
    },
    isEditName () {
      if (this.title === '编辑渠道') return true
      return false
    },
    activeLabel () {
      if (this.addform.status) {
        return '显示'
      } else {
        return '隐藏'
      }
    },
  },
  watch: {
    'pageHeight': function () {
      this.handleResize()
    },
    // domainName: '',
    //     httpsFlag: true,
    //     linkType: 1
    // 'addform.name': function () {
    //   if (this.addform.linkType === 1) {
    //     return false
    //   }
    //   this.link()
    // },
    'addform.domainName': function () {
      if (this.addform.linkType === 1 || this.addform.linkType === null) {
        return false
      }
      this.link()
    },
    'addform.httpsFlag': function () {
      if (this.addform.linkType === 1 || this.addform.linkType === null) {
        return false
      }
      this.link()
    },
    'addform.linkType': function () {
      if (this.addform.linkType === 1 || this.addform.linkType === null) {
        return false
      }
      this.link()
    },
    'addform.platform': function () {
      if (this.addform.linkType === 1 || this.addform.linkType === null) {
        return false
      }
      this.link()
    },
  },
  async created () {
    // let res = await totalApi.checkChannelName({listName: ['352434']})
    // console.log(res)
    this.fetchPrincipal()
    this.fetchData()
    this.getDomain()
    this.fetchType()
    this.fetchFacilitator()
    this.fetchMedia()
    const btnKeys = ['channelTotal.addChannel', 'channelTotal.batchUpdate', 'channelTotal.edit']
    btnKeys.forEach((t) => {
      this.$store.state.loginUser.tabButtonPerms.forEach((j) => {
        if (t === j) {
          this.tabButtonPerms[t] = true
        }
      })
    })
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    handleSortChange (column) {
      console.log(column, 'val')
    },
    sortMethod (a, b) {
      // console.log(cloum, val)
      return a - b
    },
    // 产品名称变化时，产品线值改变
    productListHandle (val) {
      this.addform.productLine = val < 4 ? 1 : val === 4 ? 2 : 5
    },
    changeSource () {
      if (this.addform.settleSource === 1) {
        this.addform.rebates = ''
      }
      if (this.addform.settleSource === 2) {
        this.addform.rebates = '1.0'
      }
    },
    trimSpace (str, isGlobal) {
      let result
      result = str.replace(/(^\s+)|(\s+$)/g, '')
      if (isGlobal.toLowerCase() === 'g') {
        result = result.replace(/\s/g, '')
      }
      return result
    },
    async isLink () {
      if (this.addform.linkType === 1) {
        return false
      }
      this.link()
    },
    down () {
      // let data = {
      //     currentPage: this.pagination.pageNo,
      //     pageSize: this.pagination.pageSize,
      //     name: this.queryForm.name,
      //     platformId: this.queryForm.platformId === 0 ? '' : this.queryForm.platformId,
      //     facilitatorId: this.queryForm.facilitatorId,
      //     principalId: this.queryForm.principalId,
      //     status: this.queryForm.status === 3 ? '' : this.queryForm.status,
      //     terminal: this.queryForm.terminal === 3 ? '' : this.queryForm.terminal,
      //     typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId
      //   }
      window.location.href = process.env.BASE_API +
      `/channel/exportChannelInfo?typeId=${this.queryForm.typeId === 0 ? '' : this.queryForm.typeId}&terminal=${this.queryForm.terminal === 3 ? '' : this.queryForm.terminal}` +
      `&status=${this.queryForm.status === 3 ? '' : this.queryForm.status}&principalId=${this.queryForm.principalId}` +
      `&platformId=${this.queryForm.platformId === 0 ? '' : this.queryForm.platformId}&currentPage=${this.pagination.pageNo}&pageSize=${this.pagination.pageSize}` +
      `&name=${this.queryForm.name}`
    },
    async changeStatus (row) {
      this.id = row.id
      this.addform = {
        addTime: row.addTime,
        createUserId: row.createUserId,
        mediaId: row.mediaId,
        name: row.name,
        payment: row.payment,
        platform: row.platformId,
        price: row.price,
        principalId: row.principalId,
        promoteLinks: row.promoteLinks,
        qualityScore: row.qualityScore,
        rebates: row.rebates,
        settleSource: row.settleSource,
        status: row.status,
        terminal: row.terminal,
        typeId: row.typeId,
        httpsFlag: row.httpsFlag,
        domainName: row.domainName,
        linkType: row.linkType,
        aimUserClass: row.aimUserClass,
        productLine:row.productLine,
      }
      let data = {
        ...this.addform,
        qualityScore: 1.00,
        httpsFlag: row.httpsFlag,
        domainName: this.addform.domainName === '' ? null : this.addform.domainName,
        linkType: this.addform.linkType,
        status: row.statusView === true ? 1 : 0,
        id: this.id,
        userId: this.$store.state.loginUser.userId,
      }
      let res = await totalApi.save(data)
      if (res.data.respCode === '1000') {
        this.$message.success('编辑成功')
        this.fetchData()
        this.dialogClassFormVisible = false
      } else {
        this.$message.error(res.data.respMsg || '操作失败')
      }
    },
    pushDetail (row) {
      console.log(row)
      // window.open('#/preview-data/' + this.classifyCode, JSON.stringify(this.tableData))
      window.open(`#/marketing/channelDatabase/channelDetail/${row.name}`)
    },
    bouncer (arr) {
      // Don't show a false ID to this bouncer.
      return arr.filter(function (val) {
        return !(!val || val === '')
      })
    },
    async link () {
      if (this.title === '编辑渠道') {
        let data = {
          channel: this.addform.name,
          domainName: this.addform.domainName === '' ? null : this.addform.domainName,
          httpsFlag: this.addform.httpsFlag ? 1 : 0,
          linkType: this.addform.linkType,
          platform: this.addform.platform,
        }
        let res = await totalApi.assemble(data)
        if (res.data.respCode === '1000') {
          this.addform.promoteLinks = res.data.body
        }
      }
      if (this.title === '添加渠道') {
        let listName = []
        listName = this.addform.name.split('\n')
        listName = listName.map((v) => this.trimSpace(v, 'g'))
        listName = this.bouncer(listName)
        let data = {
          listName: listName,
          domainName: this.addform.domainName === '' ? null : this.addform.domainName,
          httpsFlag: this.addform.httpsFlag ? 1 : 0,
          linkType: this.addform.linkType,
          platform: this.addform.platform,
        }
        let res = await totalApi.batchAssembleLink(data)
        if (res.data.respCode === '1000') {
          this.hashMap = res.data.body
          let keys = Object.keys(this.hashMap)
          if (keys.length > 0) {
            this.addform.promoteLinks = this.hashMap[keys[0]]
          }
        }
      }
    },
    handleAddClassConfirm () {
      this.submitLoading = true
      if (this.title === '添加渠道') {
        if (this.addform.linkType !== 1 && this.addform.promoteLinks === '') return this.$message.error('请先生成url')
        this.$refs['addform'].validate(async (valid) => {
          if (!valid) {
            this.submitLoading = false
            return false
          }
          let listName = []
          listName = this.addform.name.split('\n')
          listName = listName.map((v) => this.trimSpace(v, 'g'))
          listName = this.bouncer(listName)
          let httpsFlag = this.addform.httpsFlag ? 1 : 0
          let data = {
            ...this.addform,
            qualityScore: 1.00,
            httpsFlag: httpsFlag,
            name: null,
            status: this.addform.status === true ? 1 : 0,
            userId: this.$store.state.loginUser.userId,
            listName: listName,
            nameAndLinkMap: this.hashMap,
          }
          window.setTimeout(async () => {
            let res = await totalApi.batchSave(data, this.$store.state.loginUser.userId)
            if (res.data.respCode === '1000') {
              this.$message.success('添加成功')
              this.dialogClassFormVisible = false
              this.submitLoading = false
              this.fetchData()
            } else {
              this.submitLoading = false
              this.$message.error(res.data.respMsg || '操作失败')
            }
          }, 300)
        })
      }
      if (this.title === '编辑渠道') {
        if (this.addform.linkType !== 1 && this.addform.promoteLinks === '') return this.$message.error('请先生成url')
        this.$refs['addform'].validate(async (valid) => {
          if (!valid) {
            this.submitLoading = false
            return false
          }
          let httpsFlag = this.addform.httpsFlag ? 1 : 0
          let data = {
            ...this.addform,
            qualityScore: 1.00,
            httpsFlag: httpsFlag,
            domainName: this.addform.domainName === '' ? null : this.addform.domainName,
            linkType: this.addform.linkType,
            status: this.addform.status === true ? 1 : 0,
            id: this.id,
            userId: this.$store.state.loginUser.userId,
          }
          let res = await totalApi.save(data, this.$store.state.loginUser.userId)
          if (res.data.respCode === '1000') {
            this.$message.success('编辑成功')
            this.fetchData()
            this.submitLoading = false
            this.dialogClassFormVisible = false
          } else {
            this.$message.error(res.data.respMsg || '操作失败')
            this.submitLoading = false
          }
        })
      }
    },
    async submitPrincipal () {
      console.log(this.batchPrincipal)
      this.$refs['batchPrincipal'].validate(async (valid) => {
        if (!valid) {
          return false
        }
        let data = {
          ...this.batchPrincipal,
          userId: this.$store.state.loginUser.userId,
          idOld: this.$store.state.loginUser.userId,
        }
        let res = await totalApi.batchUpdate(data)
        if (res.data.respCode === '1000') {
          this.$message.success('变更成功！')
          this.changeManDialog = false
          this.fetchData()
        } else {
          this.$message.error(res.data.respMsg || '操作失败')
        }
      })
    },
    openEdit (row, type) {
      console.log(row)
      this.id = row.id
      let status = true
      row.status === 1 ? status = true : status = false
      let httpsFlag = true
      row.httpsFlag === 1 ? httpsFlag = true : httpsFlag = false
      this.addform = {
        addTime: row.addTime,
        createUserId: row.createUserId,
        mediaId: row.mediaId,
        name: row.name,
        payment: row.payment,
        platform: row.platformId,
        price: row.price,
        principalId: row.principalId,
        promoteLinks: row.promoteLinks,
        qualityScore: row.qualityScore,
        rebates: row.rebates,
        settleSource: row.settleSource,
        status: status,
        terminal: row.terminal,
        typeId: row.typeId,
        httpsFlag: httpsFlag,
        domainName: row.domainName,
        linkType: row.linkType,
        aimUserClass: row.aimUserClass,
        productLine:row.productLine,
      }
      if (type === 'edit') {
        this.title = '编辑渠道'
      }
      if (type === 'read') {
        this.title = '查看'
      }
      this.dialogClassFormVisible = true
    },
    openChangeManDialog () {
      this.$refs['batchPrincipal'] && this.$refs['batchPrincipal'].resetFields()
      this.changeManDialog = true
    },
    addDialog () {
      this.submitLoading = false
      this.title = '添加渠道'
      this.hashMap = {}
      this.addform = {
        addTime: '',
        mediaId: '',
        name: '',
        payment: '',
        platform: '',
        price: '',
        principalId: '',
        promoteLinks: '',
        qualityScore: '',
        rebates: '',
        settleSource: '',
        status: true,
        terminal: '',
        typeId: '',
        domainName: '',
        httpsFlag: true,
        linkType: 1,
        aimUserClass: 0,
      }
      let start = Moment(new Date()).format('YYYY-MM-DD')
      this.addform.addTime = start
      this.addform.linkType = 1
      this.addform.domainName = this.selectList.domainNameList[0].realDomain
      this.dialogClassFormVisible = true
      // this.$refs.addform.clearValidate()
    },
    // 额外的弹窗
    openTypeDialog (val) {
      this.showDialog[val] = true
    },
    closeh5Dialog (val) {
      this.showDialog[val] = false
    },
    // 复制URL
    onCopy () {
      this.$message.success('复制URL成功！')
    },
    onError () {
      this.$message.success('复制URL失败！')
    },
    async fetchData () {
      try {
        this.listLoading = true
        let data = {
          currentPage: this.pagination.pageNo,
          pageSize: this.pagination.pageSize,
          name: this.queryForm.name,
          platformId: this.queryForm.platformId === 0 ? '' : this.queryForm.platformId,
          principalId: this.queryForm.principalId,
          status: this.queryForm.status === 3 ? '' : this.queryForm.status,
          terminal: this.queryForm.terminal === 3 ? '' : this.queryForm.terminal,
          typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
        }
        let res = await totalApi.fetchTableData(data)
        if (res.data.respCode === '1000') {
          this.listLoading = false
          res.data.body.list.forEach((t) => {
            if (t.price || t.price === 0) {
              t.priceView = t.price.toFixed(2)
            }
            t.status === 1 ? t.statusView = true : t.statusView = false
            t.addTime = Moment(new Date(t.addTime)).format('YYYY-MM-DD')
            t.nameView = this.selectList.principalDoc[t.principalId]
          })
          this.tableData = res.data.body.list
          this.pagination.pageNo = res.data.body.pageNum
          this.pagination.pageSize = res.data.body.pageSize
          this.pagination.total = res.data.body.total
        } else {
          this.listLoading = false
        }
      } catch (error) {
        this.listLoading = false
      }
    },
    // async fetchPages () {
    //   try {
    //     this.listLoading = true
    //     let data = {
    //       currentPage: this.pagination.pageNo,
    //       pageSize: this.pagination.pageSize,
    //       name: this.queryForm.name,
    //       platformId: this.queryForm.platformId === 0 ? '' : this.queryForm.platformId,
    //       facilitatorId: this.queryForm.facilitatorId,
    //       principalId: this.queryForm.principalId,
    //       status: this.queryForm.status === 3 ? '' : this.queryForm.status,
    //       terminal: this.queryForm.terminal === 3 ? '' : this.queryForm.terminal,
    //       typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId
    //     }
    //     let res = await totalApi.fetchTableData(data)
    //     if (res.data.respCode === '1000') {
    //       this.listLoading = false
    //       res.data.body.list.forEach(t => {
    //         t.status === 1 ? t.statusView = true : t.statusView = false
    //         t.addTime = Moment(new Date(t.addTime)).format('YYYY-MM-DD')
    //         t.nameView = this.selectList.principalDoc[t.principalId]
    //         if (t.price) {
    //           t.price = t.price.toFixed(2)
    //         }
    //       })
    //       this.tableData = res.data.body.list.slice(0, 20)
    //       setTimeout(() => { this.tableData = res.data.body.list }, 0)
    //       this.pagination.pageNo = res.data.body.pageNum
    //       this.pagination.pageSize = res.data.body.pageSize
    //       this.pagination.total = res.data.body.total
    //     } else {
    //       this.listLoading = false
    //     }
    //   } catch (error) {
    //     this.listLoading = false
    //   }
    // },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: '这是一段对标题的说明',
        },
      })
    },
    changePayment (val) {
      console.log(val)
      if (val === 0) {
        this.addform.settleSource = ''
        this.addform.price = ''
        this.addform.rebates = ''
      }
    },
    handleResize () {
      // let num = this.statusView
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - this.pageHeight
        // this.tableMaxHeight = h
      })
    },
    search () {
      this.fetchData()
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    },
    async fetchMedia () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1,
      }
      let res = await totalApi.media(data)
      if (res.data.respCode === '1000') {
        this.selectList.mediaList = res.data.body.list
      }
    },
    async fetchFacilitator () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1,
      }
      let res = await totalApi.facilitator(data)
      if (res.data.respCode === '1000') {
        this.selectList.facilitatorList = res.data.body.list
      }
    },
    async fetchType () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1,
      }
      let res = await totalApi.type(data)
      if (res.data.respCode === '1000') {
        let topArr = [{id: 0, typeName: '不限'}]
        this.selectList.typeList = topArr.concat(res.data.body.list)
        this.selectList.addTypeList = res.data.body.list
      }
    },
    async fetchPrincipal () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1,
      }
      let res = await totalApi.principal(data)
      if (res.data.respCode === '1000') {
        this.selectList.principalList = res.data.body.list
        for (let i = 0; i < this.selectList.principalList.length; i++) {
          this.selectList.principalDoc[this.selectList.principalList[i].id] = this.selectList.principalList[i].principalName
        }
      }
    },
    async getDomain () {
      let res = await totalApi.getDomain()
      if (res.data.respCode === '1000') {
        this.selectList.domainNameList = res.data.body
        this.addform.domainName = res.data.body[0].realDomain
      }
    },
    handleClassDialogClose () {
      this.$refs.addform.resetFields()
    },
    fix2 (val, num) {
      if (this.addform.payment !== 0 && /^[0-9.]*$/.test(this.addform[val])) {
        if (this.addform[val] && this.addform[val] !== '') { this.addform[val] = Number(this.addform[val]).toFixed(num) }
      }
    },
  },
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 0px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .urlSty:hover{
    text-decoration:underline
  }
  .fs-14 {
    padding-left:8px;
    font-size: 14px
  }
</style>
