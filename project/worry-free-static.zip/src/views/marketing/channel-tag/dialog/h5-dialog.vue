<template>
  <div>
    <!-- 落地页添加 -->
    <el-dialog :title="title" size="mini" :visible.sync="addDialog" @close="handleClose" :show-close="false" :close-on-click-modal="false" :close-on-press-escape="false">
      <el-form size="mini" :model="addForm" ref='addForm' :rules="addRules">
        <el-form-item label="落地页简称"  label-width="130px" prop="abbreviation">
          <el-input v-model="addForm.abbreviation" :maxlength="8"></el-input>
        </el-form-item>
        <el-form-item label="落地页URL"  label-width="130px" prop="pageUrl">
          <el-row>
            <el-col :span="24">
                <el-input type="textarea" 
                v-model="addForm.pageUrl" 
                ref='urlInput' 
                placeholder="多个URL之间用西文分号 ;"
                :maxlength="255"  
                :autosize="{ minRows: 2, maxRows: 4}"></el-input>
            </el-col>
            <!-- <el-col :span="4" :push="1">
              <el-button type="success" @click="insertRow">插入换行</el-button>
            </el-col> -->
          </el-row>
        </el-form-item>
        <el-form-item label="备注"  label-width="130px" prop="remark">
          <el-input type="textarea" v-model="addForm.remark"  :autosize="{ minRows: 2, maxRows: 4}"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="cancel">取消</el-button>
          <el-button type="primary" @click="submit">确认</el-button>
        </div>
    </el-dialog>
  </div>
</template>

<script>
import h5Api from '../../../../api/h5Api.js'
export default {
  components: {
  },
  props: {
    addH5: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      statusList: [{key: 0, value: '显示'}, {key: 1, value: '隐藏'}],
      addDialog: this.addH5,
      queryForm: {
        status: '',
        pageUrl: ''
      },
      addForm: {
        abbreviation: '',
        pageUrl: '',
        remark: ''
      },
      addRules: {
        abbreviation: [
          { required: true, message: '落地页简称不能为空', trigger: 'blur' }
        ],
        pageUrl: [
          { required: true, message: '落地页URL不能为空', trigger: 'blur' }
        ]
      },
      title: '添加落地页'
    }
  },
  created () {
  },
  mounted () {
  },
  destroyed () {
  },
  computed: {

  },
  watch: {
    addH5 () {
      this.addDialog = this.addH5
    }
  },
  methods: {
    cancel () {
      this.$emit('closeDialog', 'addH5')
    },
    handleClose () {
      this.$emit('closeDialog', false)
      this.$refs.addForm.resetFields()
    },
    edit (row) {
      this.addForm = row
      this.addDialog = true
    },
    async submit () {
      this.$parent.fetchData()
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        if (this.title === '添加落地页') {
          let res = await h5Api.insert(this.addForm)
          if (res.data.resCode === '1000') {
            this.$message.success('添加成功')
            this.$parent.fetchData()
          } else {
            this.$message.error(res.data.resMsg || '操作失败')
          }
        }
      })
    },
    insertRow () {
      this.addForm.pageUrl = this.addForm.pageUrl + '\n'
      this.$refs.urlInput.focus()
    },
    openAddDialog () {
      this.title = '添加落地页'
      this.addForm = {
        abbreviation: '',
        pageUrl: '',
        remark: ''
      }
      this.addDialog = true
    }
  }
}
</script>
<style lang="scss">
</style>
