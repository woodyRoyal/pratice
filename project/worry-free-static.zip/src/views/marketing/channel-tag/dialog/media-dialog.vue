<template>
  <div>
    <!-- 落地页添加 -->
    <el-dialog :title="title" size="mini" :visible.sync="addDialog" @open="openAddDialog" @close="handleClose" :show-close="false" :close-on-click-modal="false" :close-on-press-escape="false">
      <el-form size="mini" :model="addForm" ref='addForm' :rules="addRules">
        <el-form-item label="媒体:"  label-width="130px" prop="mediaName">
          <el-input v-model="addForm.mediaName" :maxlength="16"></el-input>
        </el-form-item>
        <el-form-item label="添加日期:"  label-width="130px" prop="pageUrl">
          <el-input v-model="addForm.addTime" disabled></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="cancel">取消</el-button>
          <el-button type="primary" @click="submit">确认</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import Moment from 'moment'
import commentApi from '../../../../api/commentApi.js'
export default {
  components: {
  },
  props: {
    addmedia: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      statusList: [{key: 0, value: '显示'}, {key: 1, value: '隐藏'}],
      addDialog: this.addmedia,
      queryForm: {
        status: '',
        pageUrl: ''
      },
      addForm: {
        addTime: '',
        mediaName: '',
        status: 1
      },
      addRules: {
        mediaName: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (/^[A-Za-z0-9\u4e00-\u9fa5]+$/.test(value)) {
                callback()
              } else {
                callback(new Error('不能为空,支持汉字、字母或数字!'))
              }
            }
          }
        ]
      },
      title: '添加媒体'
    }
  },
  created () {
  },
  mounted () {
  },
  destroyed () {
  },
  computed: {

  },
  watch: {
    addmedia () {
      this.addDialog = this.addmedia
    }
  },
  methods: {
    cancel () {
      this.$emit('closeDialog', 'addmedia')
    },
    handleClose () {
      this.$emit('closeDialog', false)
      this.$refs.addForm.resetFields()
    },
    edit (row) {
      this.addForm = row
      this.addDialog = true
    },
    async submit () {
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        if (this.title === '添加媒体') {
          let data = {
            ...this.addForm,
            userId: this.$store.state.loginUser.userId
          }
          let res = await commentApi.mediaSave(data)
          if (res.data.respCode === '1000') {
            console.log(res, '进去判断')
            this.$message.success('添加成功')
            this.$parent.fetchMedia()
            this.cancel()
          } else {
            this.$message.error(res.data.respMsg)
          }
        }
      })
    },
    insertRow () {
      this.addForm.pageUrl = this.addForm.pageUrl + '\n'
      this.$refs.urlInput.focus()
    },
    openAddDialog () {
      let start = Moment(new Date()).format('YYYY-MM-DD')
      this.title = '添加媒体'
      this.addForm = {
        addTime: start,
        mediaName: '',
        status: 1
      }
      this.addDialog = true
    }
  }
}
</script>
<style lang="scss">
</style>
