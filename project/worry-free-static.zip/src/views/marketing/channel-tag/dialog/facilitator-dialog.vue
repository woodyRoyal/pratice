<template>
  <div>
    <el-dialog :title="title" size="mini" :visible.sync="addDialog" @open="openAddDialog" @close="handleClose" :show-close="false" :close-on-click-modal="false" :close-on-press-escape="false">
      <el-form size="mini" :model="addForm" ref='addForm' :rules="addRules">
        <el-form-item label="渠道服务商全称:"  label-width="130px" prop="fullName">
          <el-input v-model="addForm.fullName" :maxlength="16"></el-input>
        </el-form-item>
        <el-form-item label="渠道服务商简称:"  label-width="130px" prop="shortName">
          <el-input v-model="addForm.shortName" :maxlength="8"></el-input>
        </el-form-item>
        <el-form-item label="添加日期:"  label-width="130px" prop="pageUrl">
          <el-input v-model="addForm.addTime" disabled></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="cancel">取消</el-button>
          <el-button type="primary" @click="submit">确认</el-button>
        </div>
    </el-dialog>
  </div>
</template>

<script>
import Moment from 'moment'
import commentApi from '../../../../api/commentApi.js'
export default {
  components: {
  },
  props: {
    addfacilitator: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      statusList: [{key: 0, value: '显示'}, {key: 1, value: '隐藏'}],
      addDialog: this.addfacilitator,
      queryForm: {
        status: '',
        pageUrl: ''
      },
      addForm: {
        addTime: '',
        fullName: '',
        shortName: '',
        status: 1
      },
      addRules: {
        shortName: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (/^[A-Za-z0-9\u4e00-\u9fa5]+$/.test(value)) {
                callback()
              } else {
                callback(new Error('不能为空,支持汉字、字母或数字!'))
              }
            }
          }
        ],
        fullName: [
          { required: true, message: '渠道服务商全称不能为空', trigger: 'blur' }
        ]
      },
      title: '添加落地页'
    }
  },
  created () {
  },
  mounted () {
  },
  destroyed () {
  },
  computed: {

  },
  watch: {
    addfacilitator () {
      this.addDialog = this.addfacilitator
    }
  },
  methods: {
    cancel () {
      this.$emit('closeDialog', 'addfacilitator')
    },
    handleClose () {
      this.$emit('closeDialog', false)
      this.$refs.addForm.resetFields()
    },
    edit (row) {
      this.addForm = row
      this.addDialog = true
    },
    async submit () {
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        if (this.title === '添加渠道商') {
          let data = {
            ...this.addForm,
            userId: this.$store.state.loginUser.userId
          }
          let res = await commentApi.facilitatorSave(data)
          if (res.data.respCode === '1000') {
            console.log(res, '进去判断')
            this.$message.success('添加成功')
            this.$parent.fetchFacilitator()
            this.cancel()
          } else {
            this.$message.error(res.data.respMsg)
          }
        }
      })
    },
    insertRow () {
      this.addForm.pageUrl = this.addForm.pageUrl + '\n'
      this.$refs.urlInput.focus()
    },
    openAddDialog () {
      let start = Moment(new Date()).format('YYYY-MM-DD')
      this.title = '添加渠道商'
      this.addForm = {
        addTime: start,
        fullName: '',
        shortName: '',
        status: 1
      }
      this.addDialog = true
    }
  }
}
</script>
<style lang="scss">
</style>
