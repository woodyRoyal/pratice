<!--定时任务-->
<template>
  <div>
    <div v-if="searchView[$route.path]">
      <el-form :inline="true" :model="queryForm" size="mini" class="margin-mini" style="margin-top:5px">
       <el-form-item label="落地页URL:" label-width="90px" >
         <el-input v-model="queryForm.pageUrl"  @keyup.native.enter="fetchData()"></el-input>
       </el-form-item>
       <el-form-item label="状态:" label-width="67px">
         <el-select v-model="queryForm.status">
            <el-option
            v-for="(item,index) in statusList"
            :key="index"
            :value="item.key"
            :label="item.value" 
            >
            </el-option>
          </el-select>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="fetchData()">查询</el-button>
        <el-button type="primary" size="mini" @click="openAddDialog">添加落地页</el-button>
      </el-form-item>
    </el-form>
    </div>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row stripe :max-height="tableMaxHeight" style="width: 100%">
      <el-table-column
        prop="id"
        label="落地页ID"
        fixed
        width="70"
        >
      </el-table-column>
      <el-table-column
        prop="abbreviation"
        label="落地页简称"
        width="120"
        >
        <template slot-scope="scope">
          <span class="btnText" @click="edit(scope.row)">{{scope.row.abbreviation}}</span>
          <!-- <el-button type="text" @click="edit(scope.row)">{{scope.row.abbreviation}}</el-button> -->
        </template>
      </el-table-column>
      <el-table-column
        prop="pageUrl"
        label="落地页URL"
        align="left"
        class="tableLeft"
        >
        <template slot-scope="scope">
          <span v-html="scope.row.pageView">            
          </span>
        </template>
      </el-table-column>
      </el-table-column>
      <el-table-column
        prop="remark"
        width="200"
        label="备注"
      >
      </el-table-column>
      <el-table-column
        prop="createAt"
        width="100"
        label="添加日期"
      >
      </el-table-column>
      <el-table-column
        prop="status"
        label="状态"
        width="120"
      >
      <template slot-scope="scope">
        {{scope.row.status === 0?'显示':'隐藏'}}
        <el-switch
          @change="changeStatus(scope.row)"
          v-model="scope.row.statusView"
          active-color="#13ce66"
          inactive-color="#ff4949">
        </el-switch>
      </template>
      </el-table-column>
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNum" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
    <!-- 落地页添加 -->
    <el-dialog :title="title" size="mini" :visible.sync="addDialog" @close="handleClose">
      <el-form size="mini" :model="addForm" ref='addForm' :rules="addRules">
        <el-form-item label="落地页简称"  label-width="130px" prop="abbreviation">
          <el-input v-model="addForm.abbreviation" :maxlength="8"></el-input>
        </el-form-item>
        <el-form-item label="落地页URL"  label-width="130px" prop="pageUrl">
          <el-row>
            <el-col :span="24">
                <el-input type="textarea" 
                v-model="addForm.pageUrl" 
                ref='urlInput' 
                placeholder="以 http:// 或 https://开头，多个URL之间用西文分号 ;"
                :maxlength="255"  
                :autosize="{ minRows: 2, maxRows: 4}"></el-input>
            </el-col>
            <!-- <el-col :span="4" :push="1">
              <el-button type="success" @click="insertRow">插入换行</el-button>
            </el-col> -->
          </el-row>
          
        </el-form-item>
        <el-form-item label="备注"  label-width="130px" prop="remark">
          <el-input type="textarea" v-model="addForm.remark"  :autosize="{ minRows: 2, maxRows: 4}"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="addDialog = false">取消</el-button>
          <el-button type="primary" @click="submit">确认</el-button>
        </div>
    </el-dialog>
  </div>
</template>

<script>
import VueElTooltip from '../../../components/VueElTooltip'
import h5Api from '../../../api/h5Api.js'
import Moment from 'moment'
export default {
  components: {
    VueElTooltip
  },
  props: {
    searchView: {
      type: Object,
      default: {

      }
    }
  },
  data () {
    return {
      statusList: [{key: 0, value: '显示'}, {key: 1, value: '隐藏'}],
      addDialog: false,
      queryForm: {
        status: '',
        pageUrl: ''
      },
      addForm: {
        abbreviation: '',
        pageUrl: '',
        remark: ''
      },
      addRules: {
        abbreviation: [
          { required: true, message: '落地页简称不能为空', trigger: 'blur' }
        ],
        pageUrl: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (value === '') {
                callback(new Error('请输入url'))
              } else if (/[；]/.test(value)) {
                callback(new Error('输入错误，请以英文分号分隔'))
              } else if (/^([hH][tT]{2}[pP]:\/\/|[hH][tT]{2}[pP][sS]:\/\/)/.test(value)) {
                callback()
              } else {
                callback(new Error('输入错误，以 http:// 或 https://开头,英文分号分隔'))
              }
            }
          }
        ]
      },
      title: '添加落地页',
      tableMaxHeight: 600,
      pagination: {
        pageNum: 1, // pageNum
        pageSizes: [30, 50, 100],
        pageSize: 30, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [],
      listLoading: false
    }
  },
  created () {
    this.fetchData()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {
    pageHeight () {
      if (this.searchView[this.$route.path]) {
        return 160
      } else {
        return 120
      }
    }
  },
  watch: {
    'pageHeight': function () {
      this.handleResize()
    }
  },
  methods: {
    async changeStatus (row) {
      let data = {
        status: row.statusView ? 0 : 1,
        id: row.id
      }
      let res = await h5Api.edit(data)
      if (res.data.respCode === '1000') {
        this.$message.success('编辑成功')
        this.fetchData()
      } else {
        this.$message.error(res.data.respMsg || '操作失败')
      }
    },
    handleClose () {
      this.$refs.addForm.resetFields()
    },
    edit (row) {
      this.addForm = {
        ...row,
        pageUrl: row.pageUrl.replace(/;/g, ';\n')
      }
      this.title = '编辑落地页'
      this.addDialog = true
    },
    async submit () {
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        if (this.title === '添加落地页') {
          let data = {
            abbreviation: this.addForm.abbreviation,
            pageUrl: this.addForm.pageUrl.replace(/\n/g, ''),
            remark: this.addForm.remark
          }
          let res = await h5Api.insert(data)
          if (res.data.respCode === '1000') {
            this.$message.success('添加成功')
            this.fetchData()
            this.addDialog = false
          } else {
            this.$message.error(res.data.respMsg || '操作失败')
          }
        }
        if (this.title === '编辑落地页') {
          let data = {
            abbreviation: this.addForm.abbreviation,
            id: this.addForm.id,
            pageUrl: this.addForm.pageUrl.replace(/\n/g, ''),
            remark: this.addForm.remark
          }
          let res = await h5Api.edit(data)
          if (res.data.respCode === '1000') {
            this.$message.success('编辑成功')
            this.fetchData()
            this.addDialog = false
          } else {
            this.$message.error(res.data.respMsg || '操作失败')
          }
        }
      })
    },
    async fetchData () {
      this.listLoading = true
      let data = {
        ...this.queryForm,
        pageNum: this.pagination.pageNum,
        pageSize: this.pagination.pageSize
      }
      let res = await h5Api.fetchTableData(data)
      if (res.data.respCode === '1000') {
        res.data.body.list.forEach(t => {
          t.status === 0 ? t.statusView = true : t.statusView = false
          t.pageView = t.pageUrl.replace(/;/g, ';</br>')
          if (t.createAt) {
            t.createAt = Moment(new Date(t.createAt)).format('YYYY-MM-DD')
          }
        })
        this.tableData = res.data.body.list
        this.pagination.pageNum = res.data.body.pageNum
        this.pagination.pageSize = res.data.body.pageSize
        this.pagination.total = res.data.body.total
        this.listLoading = false
      } else {
        this.$message.error(res.data.respMsg || '列表接口出错')
        this.listLoading = false
      }
    },
    insertRow () {
      this.addForm.pageUrl = this.addForm.pageUrl + '\n'
      this.$refs.urlInput.focus()
    },
    openAddDialog () {
      this.title = '添加落地页'
      this.addForm = {
        abbreviation: '',
        pageUrl: '',
        remark: ''
      }
      this.addDialog = true
    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: '这是一段对标题的说明'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - this.pageHeight
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNum = val
      this.fetchData()
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
