export default {
  feeList: [
    {key: 0, value: '免费'},
    {key: 1, value: 'CPC(按点击付费)'},
    {key: 2, value: 'CPA(按激活付费)'},
    {key: 3, value: 'CPD(按下载付费)'},
    {key: 4, value: 'CPT(按时长付费)'},
    {key: 5, value: 'CPM(按展示付费)'},
    {key: 6, value: 'CPS(按分成付费)'},
    {key: 7, value: 'CPR(按注册付费)'},
    {key: 8, value: 'CPAP(按申请付费)'},
    {key: 9, value: 'CPK(按开户付费)'},
    {key: 10, value: 'CPL(按动用付费)'},
    {key: 11, value: '刷榜'}
  ],
  phonelist: ['iOS', 'Android', 'iOS/Android'],
  statusList: [{key: 1, value: '显示'}, {key: 0, value: '隐藏'}],
  terminalList: [{key: 1, value: 'android'}, {key: 2, value: 'ios'}, {key: 3, value: '不限'}],
  settleSourceList: [{key: 1, value: '我方'}, {key: 2, value: '对方'}],
  platformList: [{key: 0, value: '不限'}, {key: 1, value: '花钱无忧'}, {key: 2, value: '大圣钱包'}, {key: 3, value: '无忧钱包'}, {key: 4, value: '贷款王'}, {key: 5, value: 'H5聚合页'}, {key: 8, value: '立即借'}],
  platformList2: [{key: 1, value: '花钱无忧'}, {key: 2, value: '大圣钱包'}, {key: 3, value: '无忧钱包'}, {key: 4, value: '贷款王'}, {key: 8, value: '立即借'}],
  platformList3: [{key: 0, value: '不限'}, {key: 1, value: '花钱无忧'}, {key: 2, value: '大圣钱包'}, {key: 3, value: '无忧钱包'}, {key: 4, value: '贷款王'}, {key: 8, value: '立即借'}],
  productLine: [{key: 1, value: '花钱无忧'}, {key: 2, value: '贷款王'}, {key: 5, value: '立即借'}],
  ispList: [{key: '1', value: '移动'}, {key: '2', value: '联通'}, {key: '3', value: '电信'}],
  passageWay: [{
    value: 'ZD',
    label: '智鼎'
  }, {
    value: 'AW',
    label: '昂网'
  }, {
    value: 'YR',
    label: '云融'
  }],
  linkTypeList: [
    {key: 1, value: '无'},
    {key: 2, value: '通过信息流等引导用户访问H5注册落地页'},
    {key: 3, value: '通过短信引导用户访问H5落地页'},
    {key: 4, value: '直接提供APK下载链接'},
    {key: 5, value: '直接访问H5聚合页'}
  ]
}
