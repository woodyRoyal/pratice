<!--定时任务-->
<template>
  <div>
    <div>
      <el-form :inline="true" :model="queryForm" size="mini">
       <el-form-item label="渠道号:" label-width="60px">
         <el-input v-model="queryForm.id"></el-input>
       </el-form-item>
       <el-form-item label="平台名称:" label-width="80px">
         <el-input v-model="queryForm.id"></el-input>
       </el-form-item>
       <el-form-item>
           <el-checkbox v-model="checked">显示停用渠道号</el-checkbox>
       </el-form-item>
      <el-form-item>
        <el-button size="mini" >查询</el-button>
        <el-button  size="mini" >添加回调渠道</el-button>
      </el-form-item>
    </el-form>
    </div>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row show-summary  stripe  :max-height="tableMaxHeight" :summary-method="getSummaries" style="width: 100%">
      <el-table-column
        prop="date"
        label="回调ID"
        :render-header="renderHeader"
        >
      </el-table-column>
      <el-table-column
        prop="name"
        label="渠道号"
        :show-overflow-tooltip="true"
        :render-header="renderHeader"
        >
        <template slot-scope="scope">
          <el-tooltip content="Top Left 提示文字">
            <span>{{scope.row.name}}</span>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column
        prop="province"
        label="平台名称"
        :render-header="renderHeader"
        >
      </el-table-column>
      <el-table-column
        prop="city"
        label="回调时机"
        :render-header="renderHeader"
        >
      </el-table-column>
      <el-table-column
        prop="address"
        label="核减比例"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="address"
        label="添加日期"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="address"
        label="状态"
        :render-header="renderHeader"
      >
      </el-table-column>
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'

export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      checked: true,
      queryForm: {
        radio: 1,
        time: [],
        date: ''
      },
      bigID: 1,
      nameID: 1,
      typeID: 1,
      bigTagList: [
        {key: 1, value: '渠道汇总'},
        {key: 2, value: '渠道服务商'},
        {key: 3, value: '渠道类型'},
        {key: 4, value: '投放媒体'},
        {key: 5, value: '渠道负责人'},
        {key: 6, value: 'H5落地页'}
      ],
      nameList: [
        {key: 1, value: '不限'},
        {key: 2, value: '花钱无忧'},
        {key: 3, value: '无忧钱包'},
        {key: 4, value: '大圣钱包'},
        {key: 5, value: '贷款王'},
        {key: 6, value: 'H5聚合页'}
      ],
      typeList: [
        {key: 0, value: '不限'},
        {key: 1, value: '信息流'},
        {key: 2, value: '外部短信'},
        {key: 3, value: '贷款平台'},
        {key: 4, value: '苹果官方市场'},
        {key: 5, value: '安卓应用市场'}
      ],
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [10, 50, 100],
        pageSize: 10, // pageSize
        total: 10 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [],
      listLoading: false
    }
  },
  created () {
    // this.fetchData()
    for (let i = 0; i < 101; i++) {
      this.tableData.push({
        date: '2016-05-07',
        name: '王小虎',
        province: '上海',
        city: '普陀区',
        address: '上海市',
        zip: i + parseInt(Math.random() * 20)
      })
    }
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {

  },
  methods: {
    getSummaries (param) {
      const { columns, data } = param
      const sums = []
      columns.forEach((column, index) => {
        if (index === 0) {
          sums[index] = '总价'
          return
        }
        const values = data.map(item => Number(item[column.property]))
        if (!values.every(value => isNaN(value))) {
          sums[index] = values.reduce((prev, curr) => {
            const value = Number(curr)
            if (!isNaN(value)) {
              return prev + curr
            } else {
              return prev
            }
          }, 0)
          sums[index] += ' 元'
        } else {
          sums[index] = 'N/A'
        }
      })

      return sums
    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: '这是一段对标题的说明'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 195
      })
    },
    handleSizeChange () {

    },
    handleCurrentChange () {

    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14 {
    font-size: 14px
  }
</style>
