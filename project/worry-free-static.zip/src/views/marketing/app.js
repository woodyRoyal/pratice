export const TAG_LIST = [
  {addressType: '9', value: '首页主列表', isShow: false},
  {addressType: '1', value: '首页分类-1', isShow: false},
  {addressType: '2', value: '首页分类-2', isShow: false},
  {addressType: '3', value: '首页分类-3', isShow: false},
  {addressType: '4', value: '首页分类-4', isShow: true},
  {addressType: '11', value: '跑马灯', isShow: false},
  {addressType: '12', value: '贷款大全', isShow: false},
  {addressType: '13', value: '猜你可贷', isShow: false},
  {addressType: '18', value: '开屏广告', isShow: false},
  {addressType: '6', value: '首页banner', isShow: false},
  {addressType: '20', value: '首页弹窗', isShow: false},
  {addressType: '21', value: '首页悬浮广告', isShow: false},
  {addressType: '7', value: '中部banner-1', isShow: false},
  {addressType: '8', value: '中部banner-2', isShow: false},
  {addressType: '14', value: '优惠券', isShow: false}
]

export const TAG_OBJ = {
  '9': '首页主列表',
  '1': '首页分类-1',
  '2': '首页分类-2',
  '3': '首页分类-3',
  '4': '首页分类-4',
  '11': '跑马灯',
  '12': '贷款大全',
  '13': '猜你可贷',
  '18': '开屏广告',
  '6': '首页banner',
  '20': '首页弹窗',
  '21': '首页悬浮广告',
  '7': '中部banner-1',
  '8': '中部banner-2',
  '14': '优惠券'
}
