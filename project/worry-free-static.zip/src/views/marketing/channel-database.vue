<!--定时任务-->
<template>
  <div>
    <div class="topBox">
      <!-- 父tab -->
      <el-radio-group v-model="bigID" style="margin-top:0px;" size="small" @change="changeTab">
        <el-radio-button :label="item.value" v-for="(item,index) in bigTagList" :key="index">{{item.value}}</el-radio-button>
      </el-radio-group>
      <span class="searchView">
        <el-button type="success" size="mini" @click="changeSearchView" v-if="searchView[$route.path]">
        隐藏搜索项<i class="el-icon-arrow-up el-icon--right"></i>
        <!-- 隐藏搜索项<i class="el-icon-arrow-down el-icon--right"></i> -->
        </el-button>
        <el-button type="success" size="mini" @click="changeSearchView" v-else>
        展开搜索项<i class="el-icon-arrow-down el-icon--right"></i>
        <!-- 隐藏搜索项<i class="el-icon-arrow-down el-icon--right"></i> -->
        </el-button>
      </span>
    </div>
    <router-view :searchView="searchView"></router-view>
  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'

export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      searchView: {
        '/marketing/channelDatabase/channelDetail': true,
        '/marketing/channelDatabase/channelDetailHour': true,
        '/marketing/channelDatabase/expend': true,
        '/marketing/channelDatabase/quality': true
      },
      permissionList: [],
      bigID: '渠道推广明细',
      allListL: [
        {key: '/marketing/channelDatabase/channelDetail', value: '渠道推广明细（按天）'},
        {key: '/marketing/channelDatabase/channelDetailHour', value: '渠道推广明细（按小时）'},
        {key: '/marketing/channelDatabase/expend', value: '推广支出录入'},
        {key: '/marketing/channelDatabase/quality', value: '渠道质量审核'}
      ],
      bigTagList: [
        // {key: 1, value: '渠道推广明细（按天）'},
        // {key: 2, value: '渠道推广明细（按小时）'}
        // {key: 3, value: '推广支出录入'},
        // {key: 4, value: '渠道质量数据'}
      ]
    }
  },
  created () {
    this.permissionList = this.$store.state.permission.menuPathList
    this.allListL.forEach(t => {
      this.permissionList.forEach(j => {
        if (t.key === j) {
          this.bigTagList.push(t)
        }
      })
    })
    if (this.bigTagList.length === 0) {
      this.$message.error('该模块没有授权页面！')
      this.$router.push({name: '花钱无忧后台'})
    }
    if (this.$route.path === '/marketing/channelDatabase') {
      this.$router.push({name: this.bigTagList[0].value})
    }
  },
  mounted () {
    this.bigID = this.$route.name
  },
  watch: {
  },
  computed: {

  },
  methods: {
    changeSearchView () {
      this.searchView[this.$route.path] = !this.searchView[this.$route.path]
    },
    changeTab (val) {
      this.$router.push({name: this.bigID})
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 0px;
    position: relative;
  }
  .searchView {
    position: absolute;
    right:0px
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
