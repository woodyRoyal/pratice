<!--定时任务-->
<template>
  <div>
    <div v-if="searchView[$route.path]">
      <!-- 父tab -->
      <!-- <el-radio-group v-model="bigID" style="margin-top:10px;" size="small">
        <el-radio-button :label="item.key" v-for="(item,index) in bigTagList" :key="index">{{item.value}}</el-radio-button>
      </el-radio-group> -->
      <div>
        <span class="fs-14">投放平台：</span>
        <el-radio-group size="mini" type="card" style="display: inline-block" v-model="queryForm.platform" @change="fetchData">
          <el-radio-button style="margin:5px 0;"  :label="item.key" v-for="(item,index) in selectList.platformList" :key="index">{{ item.value }}</el-radio-button>
        </el-radio-group>
      </div>
      <div>
        <span class="fs-14">渠道类型：</span>
        <el-radio-group size="mini" type="card" style="display: inline-block" v-model="queryForm.typeId" @change="fetchData">
          <el-radio-button style="margin:5px 0"  :label="item.id" v-for="(item,index) in selectList.typeList" :key="index">{{ item.typeName }}</el-radio-button>
        </el-radio-group>
      </div>
      <el-form :inline="true" :model="queryForm" size="mini" class="margin-mini">
       <el-form-item label="渠道号:" label-width="90px">
         <el-input v-model="queryForm.channelName"  @keyup.native.enter="fetchData()"></el-input>
       </el-form-item>
       <el-form-item label="渠道商:" label-width="60px">
         <el-select v-model="queryForm.facilitatorId" style="width:100%" filterable clearable>
            <el-option
            v-for="(item,index) in selectList.facilitatorList"
            :key="index"
            :label="item.fullName"
            :value="item.id" 
            >
            {{item.fullName}}
            </el-option>
          </el-select>
       </el-form-item>
       <el-form-item label="负责人:" label-width="60px">
         <el-select style="width:163px" v-model="queryForm.principalId" filterable clearable>
            <el-option
            v-for="(item,index) in selectList.principalList"
            :key="index"
            :label="item.principalName"
            :value="item.id"
            >
            {{item.principalName}}
            </el-option>
          </el-select>
       </el-form-item>
       <el-form-item label="ROI:" label-width="40px">
         <el-input v-model="queryForm.id" style="width:50px"></el-input>
         -
         <el-input v-model="queryForm.id" style="width:50px"></el-input>
         %
       </el-form-item>
       </br>
       <el-form-item label="考核日期:" label-width="90px">
         <el-date-picker
            v-model="queryForm.time"
            type="daterange"
            range-separator="至"
            :clearable="false"
            start-placeholder="开始日期"
            value-format="yyyy-MM-dd"
            end-placeholder="结束日期">
          </el-date-picker>
       </el-form-item>
       <el-form-item label="单次点击ARPU值:" label-width="130px">
         <span>{{consult.result}}元/个</span>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" class="btn-mini" @click="editConsult">修改参数值</el-button>
        <el-button size="mini" class="btn-mini" @click="fetchData">查询</el-button>
        <el-button  size="mini" class="btn-mini" @click="down" :loading="downLoading" >导出</el-button>
        <el-button  class="btn-mini" @click="toHighDialog">更新最高可接受成本</el-button>
      </el-form-item>
    </el-form>
    <div class="text-box">
      <p>说明：</p>
      <p>1、渠道质量首次考核日期，是自渠道推广的第七天起，即首次推广日期+6；每日取近齐天数据作为渠道考核数据；</p>
      <p>2、某渠道修改质量评分后，从下一个运算周期开始，即自修改日开始使用新的评分；昨日及之前医生称的推广支出等数据，请手动修改</p>
      <p>3、ROI=(最高可接受成本/付费成本-1)*100%，0%即为盈亏平衡</p>
      <p>4、最高可接受成本：系统每周一更新，也可手动更新；(1)H5聚合页:即单词点击ARPU值；(2)APP:单登录用户ARPU=30日TAD*人均点击产品数*单次点击ARPU值/激活登录率</p>
    </div>
    </div>
    <!--表格-->
    <el-table 
      :data="tableData"
      v-loading="listLoading"
      border fit
      highlight-current-row
      show-summary
      :summary-method="getSummaries"
      stripe
      :max-height="tableMaxHeight"
      style="width:100%"
      >
      <el-table-column
        prop="countDate"
        label="考核日期"
        :fixed = "tableData.length>0"
        sortable
        >
      </el-table-column>
      <el-table-column
        prop="channelName"
        label="渠道号"
        min-width="100"
        
        >
        <template slot-scope="scope">
          <div>
            <el-popover
            placement="right"
            width="320"
            trigger="hover">
            <template>
              <div style="margin-bottom:10px">渠道号: {{hoverRow.channelName}}</div>
                <el-table :data="gridData" stripe border :show-header="false" width="100%">
                  <el-table-column  prop="name" label=""></el-table-column>
                  <el-table-column  prop="value" label=""></el-table-column>
                </el-table>
            </template>
            <i slot="reference" class="el-icon-info" @mouseenter="fetchDetail(scope.row)"></i>
          </el-popover>
          <el-popover
            placement="right"
            width="155"
            trigger="click">
                <el-form size="mini">
                  <el-form-item >
                    <el-button @click="pushDetail(scope.row)">查看30天推广数据</el-button>
                  </el-form-item>
                  <el-form-item>
                    <el-button >查看30天质量数据</el-button>
                  </el-form-item>
                </el-form>
            <!-- <el-button slot="reference" type="text" @click="openEditDialog">{{scope.row.channelName}}</el-button> -->
            <span slot="reference" class="btnText" @click="openEditDialog">{{scope.row.channelName}}</span>
          </el-popover>
          </div>
         
        </template>
      </el-table-column>
        <el-table-column
        prop="platform"
        label="投放平台"
        
      >
      <template slot-scope="scope">
        <span>
          {{platformDIC[scope.row.platform]}}
        </span>
      </template>
      </el-table-column>
      <el-table-column
        prop="channelType"
        label="质量评分"
        
        >
      </el-table-column>

      <el-table-column
        prop="firstLoginCount"
        label="市场反馈"
        
        >
      </el-table-column>

      <el-table-column
        prop="registerCount"
        label="ROI"
        
      >
      </el-table-column>

      <el-table-column
        prop="regLogConvRate"
        label="付费成本"
        width="110"
        
      >
      </el-table-column>
      <el-table-column
        prop="regAndLogSameDay"
        label="最高可接受成本"
        
      >
      </el-table-column>
      <el-table-column
        prop="reglogSameDayRate"
        label="30天TAD"
        width="110"
        
      >
      </el-table-column>

      <el-table-column
        prop="principal"
        label="单次点击ARPU值"
        
      >
      </el-table-column>
      <el-table-column
        prop="principal"
        label="人均点击产品数"
        
      >
      </el-table-column>
      <el-table-column
        prop="principal"
        label="登录"
        
      >
      </el-table-column>

      <el-table-column
        prop="principal"
        label="注册"
        
      >
      </el-table-column>
      <el-table-column
        prop="principal"
        label="注册登录转化率"
        
      >
      </el-table-column>
      <el-table-column
        prop="principal"
        label="注册当日登录率"
        
      >
      </el-table-column>
      <el-table-column
        prop="principal"
        label="自然登陆量"
      >
      </el-table-column>
      <el-table-column
        prop="principal"
        label="日活"
      >
      </el-table-column>
    
      <el-table-column
        prop="principal"
        label="负责人"
      >
      </el-table-column>
      <el-table-column
        prop="terminal"
        label="投放系统"
      >
      <template slot-scope="scope">
        <span>
          {{phoneDIC[scope.row.terminal]}}
        </span>
      </template>
      </el-table-column>
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
    <!--editConsult <a href="http://t1-img.huaqianwy.com/mc/sys/img/2018090710/2018-09-07_9_null_null__null_null_null_null_null_1_100.xlsx" download="推广明细20180907093254_8.xlsx">5643</a> -->
    <!-- 渠道号编辑弹窗 -->
     <el-dialog :visible.sync="consult.editConsultDialog" title="修改参考值" width="35%" @close="closeConsult">
       <el-form size="mini" ref="consultForm" :model="consultForm" :rules="consultRules">
         <el-form-item label="单次点击ARPU值:" label-width="140px" prop="result">
           <el-input v-model="consultForm.result"></el-input>
         </el-form-item>
       </el-form>
       <div slot="footer" class="dialog-footer">
          <el-button @click="consult.editConsultDialog = false">取 消</el-button>
          <el-button type="primary">确定</el-button>
        </div>
     </el-dialog>

     <el-dialog :visible.sync="highDialog.showDialog" title="添加渠道">
       <el-form size="mini" ref="costForm" :model="costForm">
         <el-form-item label="更新渠道号:" label-width="110px" prop="result">
            <el-radio-group v-model="highDialog.radio">
              <el-radio :label="1">指定渠道号</el-radio>
              <el-radio :label="2">全渠道</el-radio>
            </el-radio-group>
         </el-form-item>
         <el-form-item label=" " label-width="20px" prop="result" v-if="highDialog.radio === 1">
            <el-input
              type="textarea"
              :autosize="{ minRows: 4, maxRows: 4}"
              placeholder="请输入内容"
              v-model="textarea">
            </el-input>
         </el-form-item>
         <el-form-item label=" " label-width="20px" v-if="highDialog.radio === 1">
          <el-upload class="upload-user-defined" name="in" accept=".csv" :auto-upload='false'
                   action="uploadExcelUrl" :file-list="fileList" :show-file-list="false"
                   :with-credentials="true" ref = "upload" :disabled = "uploading" 
                   :before-upload="handleUploadBefore" :on-success="handleUploadSuccess" :on-error="handleUploadError"
                   :on-progress="handleUploadProgress" :on-change="handleUploadChange">
          <el-button size="mini" type="primary" :loading="uploading">导入排序
          </el-button>
          <span style="font-size:12px;">渠道号之间请用西文逗号";"隔开;支持txt、csv文件导入</span>
        </el-upload>
        </el-form-item>
         <el-form-item label=" " label-width="20px" prop="result" v-if="highDialog.radio === 2">
           <div>
             <p>即将更新考核日期=2018-09-10(昨日)的最高可接受成本字段，音全渠道更新，花费时间将较长！</p>
             <p>建议制定渠道号更新。确认无误后再点击执行！</p>
           </div>
         </el-form-item>
         <el-form-item label="更新结果:" label-width="100px" prop="result">
            
         </el-form-item>
        <el-form-item label="" label-width="100px" prop="result">
            <div>更新中,预计等待5分钟...</div>
            <div>
              <p>完成！</p>
              <p>成功更新57个渠道号，以下3个渠道更新失败：</p>
              <p>1；2；3；4；5；</p>
            </div>
        </el-form-item>

         
       </el-form>
       <div slot="footer" class="dialog-footer">
          <el-button @click="highDialog.showDialog = false">取 消</el-button>
          <el-button type="primary" :loading="highDialog.loading">执行更新</el-button>
        </div>
     </el-dialog>

     <el-dialog :visible.sync="evaluateDialog.showDialog" :title="evaluateDialog.title">
       <div style="margin-bottom:15px">
         <span>渠道号：bx-gfewg-fwaf</span>
         <el-button type="primary" :loading="evaluateDialog.loading" size="mini" style="float:right">提交</el-button>
       </div>
       <el-form size="mini" ref="evaluateForm" :model="evaluateForm" :rules="evaluateRules">
         <el-form-item label="评分:" label-width="60px" prop="score">
           <el-input v-model="evaluateForm.score" style="width:100px"></el-input>
         </el-form-item>
         <el-form-item label=" " label-width="60px" prop="">
           <el-input
              type="textarea"
              :autosize="{ minRows: 4, maxRows: 4}"
              placeholder="请输入内容"
              v-model="textarea">
            </el-input>
         </el-form-item>
       </el-form>
       <div>
         <p>评价记录：</p>
         <div style="width:100%;border-bottom:2px solid #ccc"></div>
         <div class="text-block">
           <div class="rightText">2018-07-11 20:07 市场(于亚卫)反馈：</div>
           <div class="rightText">三个打一个还被反杀，会不会玩？</div>
         </div>

         <div class="text-block">
           <div class="leftText">BI(胡斌)评价 2018-07-11 16：07：</div>
           <div class="leftText">you can you up？</div>
         </div>
       </div>
     </el-dialog>
  </div>
</template> 

<script>
import VueElTooltip from '../../../components/VueElTooltip'
import dataBaseApi from '../../../api/dataBaseApi.js'
import dataBaseJson from './dataBase.js'
import Moment from 'moment'
import TABLE_TITLE_TIP from './detailInfoJson.js'
export default {
  components: {
    VueElTooltip
  },
  props: {
    searchView: {
      type: Object,
      default: {

      }
    }
  },
  data () {
    return {
      consultForm: {
        result: 20.21
      },
      consultRules: {
        result: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (value === '') {
                callback(new Error('请输入!'))
              } else if (/^(-)?\d+(\.\d+)?$/.test(value)) {
                callback()
              } else {
                callback(new Error('请输入正确的数字'))
              }
            }
          }
        ]
      },
      consult: {
        result: 20.21,
        editConsultDialog: false
      },
      costForm: {

      },
      highDialog: {
        radio: 1,
        loading: true,
        showDialog: false
      },
      evaluateForm: {
        score: '7'
      },
      evaluateDialog: {
        title: '质量评价填写',
        loading: true,
        showDialog: false
      },
      evaluateRules: {
        score: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (value === '') {
                callback(new Error('请输入!'))
              } else if (!/^(-)?\d+(\.\d+)?$/.test(value)) {
                callback(new Error('请输入0到1.0之间的数字！'))
              } else if (value > 1 || value < 0) {
                callback(new Error('请输入0到1.0之间的数字！'))
              } else {
                callback()
              }
            }
          }
        ]
      },
      timer: null,
      downLoading: false,
      TABLE_TITLE_TIP: TABLE_TITLE_TIP,
      summaryHourVo: {},
      isclick: false,
      hoverWidth: '300',
      editDialog: false,
      hoverRow: {

      },
      gridData: [
        {'name': '渠道类型', value: ''},
        {'name': '渠道商'},
        {'name': '媒体'},
        {'name': '付费方式'},
        {'name': '单价'},
        {'name': '状态'},
        {'name': '负责人:'},
        {'name': '平台平成'},
        {'name': '投放终端'}
      ],
      platformDIC: {
        1: '花钱无忧',
        2: '大圣钱包',
        3: '无忧钱包',
        4: '贷款王',
        5: 'H5聚合'
      },
      phoneDIC: {
        1: 'Android',
        2: 'iOS',
        3: 'iOS/Android'
      },
      queryForm: {
        time: [],
        channelName: '',
        facilitatorId: '',
        platform: 0,
        principalId: '',
        typeId: 0,
        hour: '不限'
      },
      selectList: {
        hourList: [],
        platformList: dataBaseJson.platformList,
        typeList: [],
        facilitatorList: [],
        principalList: []
      },
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [30, 50, 100],
        pageSize: 30, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [],
      listLoading: false
    }
  },
  created () {
    // console.log(process.env)
    this.queryForm.hour = new Date().getHours() - 1
    this.queryForm.time = Moment(new Date()).format('YYYY-MM-DD')
    this.fetchType()
    this.fetchData()
    this.tableData = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
    this.fetchfacilitator()
    this.fetchprincipalList()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
    this.getHour()
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
    clearInterval(this.timer)
  },
  computed: {
    pageHeight () {
      if (this.searchView[this.$route.path]) {
        return 468
      } else {
        return 185
      }
    }
  },
  watch: {
    'pageHeight': function () {
      this.handleResize()
    }
  },
  methods: {
    toHighDialog () {
      this.highDialog.showDialog = true
    },
    closeConsult () {
      this.$refs.consultForm.resetFields()
    },
    editConsult () {
      this.consult.editConsultDialog = true
    },
    async down () {
      if (this.downLoading) { return }
      this.downLoading = true
      let hour = this.queryForm.hour === '不限' ? '' : this.queryForm.hour
      let data = {
        channelName: this.queryForm.channelName,
        hour: hour,
        countDateHour: this.queryForm.time,
        facilitatorId: this.queryForm.facilitatorId,
        principalId: this.queryForm.principalId,
        typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
        platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
        pageNum: this.pagination.pageNo,
        pageSize: this.pagination.pageSize,
        queryType: 0
      }
      let res = await dataBaseApi.startDown(data)
      if (res.data.respCode === '1000') {
        if (res.data.body.downLoadFlag === 1) {
          clearInterval(this.timer)
          // let url = res.data.body.downLoadUrl.substring(3, res.data.body.downLoadUrl.length)
          // window.open(process.env.DOWN_URL + url)
          window.location.href = process.env.DOWN_URL + res.data.body.downLoadUrl
          // window.open('http://dev-img.huaqianwy.com' + res.data.body.downLoadUrl)
        }
        if (res.data.body.downLoadFlag === 0) {
          this.timer = setInterval(() => {
            this.poll()
          }, 1000)
        }
      } else {
        this.downLoading = false
        this.$message.error(res.data.respMsg)
      }
      // channelName: this.queryForm.channelName,
      // countDateHour: this.queryForm.time,
      // hour: this.queryForm.hour === '不限' ? '' : this.queryForm.hour,
      // facilitatorId: this.queryForm.facilitatorId,
      // principalId: this.queryForm.principalId,
      // typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
      // platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
      // pageNum: this.pagination.pageNo,
      // pageSize: this.pagination.pageSize
      // if (this.queryForm.hour === '不限') {
      //   hour = ''
      // } else {
      //   hour = this.queryForm.hour
      // }
      // window.location.href = '/mc/sys/img/推广明细20180906202603_19/推广明细20180906202603_19.xlsx'
      // window.location.href = process.env.BASE_API +
      // `/promotion/detail/downloadDetailListHour?channelName=${this.queryForm.channelName}&hour=${hour}` +
      // `&countDateHour=${this.queryForm.time}&facilitatorId=${this.queryForm.facilitatorId}&principalId=${this.queryForm.principalId}` +
      // `&typeId=${this.queryForm.typeId === 0 ? '' : this.queryForm.typeId}&pageNum=${this.pagination.pageNo}&pageSize=${this.pagination.pageSize}`
    },
    async poll () {
      let hour = this.queryForm.hour === '不限' ? '' : this.queryForm.hour
      let data = {
        channelName: this.queryForm.channelName,
        hour: hour,
        countDateHour: this.queryForm.time,
        facilitatorId: this.queryForm.facilitatorId,
        principalId: this.queryForm.principalId,
        typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
        platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
        pageNum: this.pagination.pageNo,
        pageSize: this.pagination.pageSize,
        queryType: 1
      }
      let res = await dataBaseApi.startDown(data)
      if (res.data.respCode === '1000') {
        if (res.data.body.downLoadFlag === 1) {
          // let url = res.data.body.downLoadUrl.substring(3, res.data.body.downLoadUrl.length)
          // window.open(process.env.BASE_API + url)
          // window.open('http://dev-img.huaqianwy.com' + res.data.body.downLoadUrl)
          window.location.href = process.env.DOWN_URL + res.data.body.downLoadUrl
          clearInterval(this.timer)
          this.downLoading = false
        }
      }
    },
    async fetchDetail (val) {
      this.hoverRow = val
      this.gridData = [
        {'name': '渠道类型', value: val.channelType},
        {'name': '渠道商简称', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: val.principal},
        {'name': '平台名称', value: ''},
        {'name': '投放终端', value: ''}
      ]
      let res = await dataBaseApi.hover(this.hoverRow.channelName)
      // let res = await dataBaseApi.hover('测试渠道')
      if (res.data.respCode === '1000') {
        if (!res.data.body) {
          return this.$message.error('查询寻不到渠道明细')
        }
        this.gridData[0].value = res.data.body.typeName
        this.gridData[2].value = res.data.body.mediaName
        this.gridData[1].value = res.data.body.facilitatorShortName
        this.gridData[3].value = res.data.body.paymentName
        this.gridData[4].value = res.data.body.price
        this.gridData[5].value = res.data.body.status === 1 ? '显示' : '隐藏'
        this.gridData[6].value = res.data.body.principalName
        this.gridData[7].value = res.data.body.platformName
        // {'name': '平台名称', value: this.platformDIC[val.platform]},
        // {'name': '投放终端', value: this.phoneDIC[val.terminal]}
        this.gridData[8].value = res.data.body.terminalName
      }
    },
    clearDetail () {
      this.gridData[2].value = ''
      this.gridData[3].value = ''
      this.gridData[4].value = ''
      this.gridData[5].value = ''
    },
    pushDetail (row) {
      console.log(row)
      // window.open('#/preview-data/' + this.classifyCode, JSON.stringify(this.tableData))
      window.open(`#/marketing/channelDatabase/channelDetail/${row.channelName}`)
    },
    getHour () {
      let hour = []
      for (let i = 0; i < 24; i++) {
        hour.push(i)
      }
      this.selectList.hourList = ['不限'].concat(hour)
    },
    async fetchType () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.type(data)
      if (res.data.respCode === '1000') {
        let topArr = [{id: 0, typeName: '不限'}]
        this.selectList.typeList = topArr.concat(res.data.body.list)
      }
    },
    async fetchfacilitator () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.facilitator(data)
      if (res.data.respCode === '1000') {
        this.selectList.facilitatorList = res.data.body.list
      }
    },
    async fetchprincipalList () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.principal(data)
      if (res.data.respCode === '1000') {
        this.selectList.principalList = res.data.body.list
      }
    },
    async fetchData () {
      try {
        this.listLoading = true
        // let countDateDefault = Moment(new Date()).format('YYYY-MM-DD')
        let data = {
          channelName: this.queryForm.channelName,
          countDateHour: this.queryForm.time,
          hour: this.queryForm.hour === '不限' ? '' : this.queryForm.hour,
          facilitatorId: this.queryForm.facilitatorId,
          principalId: this.queryForm.principalId,
          typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
          platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
          pageNum: this.pagination.pageNo,
          pageSize: this.pagination.pageSize
        }
        let res = await dataBaseApi.detailHour(data)
        if (res.data.respCode === '1000') {
          this.listLoading = false
          this.pagination.total = res.data.body.pageInfoRes.total
          this.pagination.pageNo = res.data.body.pageInfoRes.pageNum
          // this.tableData = res.data.body.pageInfoRes.list
          this.summaryHourVo = res.data.body.summaryHourVo
        } else {
          this.listLoading = false
        }
      } catch (error) {
        this.listLoading = false
      }
    },
    openEditDialog () {
      this.hoverWidth = 150
      this.isclick = true
    },
    tableHover (val) {
      this.hoverRow = val
      this.gridData = [
        {'name': '渠道类型', value: val.channelType},
        {'name': '渠道商简称', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: val.principal},
        {'name': '平台名称', value: this.platformDIC[val.platform]},
        {'name': '投放终端', value: this.phoneDIC[val.terminal]}
      ]
    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: TABLE_TITLE_TIP[column.property]
          // content: 'TABLE_TITLE_TIP[column.property]'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - this.pageHeight
      })
    },
    getSummaries (param) {
      const sums = []
      sums[0] = '汇总'
      sums[1] = '-'
      sums[2] = '-'
      sums[3] = this.summaryHourVo.firstLoginCount
      sums[4] = this.summaryHourVo.registerCount
      sums[5] = this.summaryHourVo.regLogConvRate
      sums[6] = this.summaryHourVo.regAndLogSameDay
      sums[7] = this.summaryHourVo.reglogSameDayRate
      sums[8] = '-'
      sums[9] = '-'
      sums[10] = '-'
      return sums
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    },
    handleClearFiles () {
      this.fileList = []
      this.file = null
    },
    // 批量修改-上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
    handleUploadBefore (file) {
      if (file.name && file.name.length > 0) {
        const ldot = file.name.lastIndexOf('.')
        const type = file.name.toLowerCase().substring(ldot)
        if (type !== '.csv') {
          this.$message.warning('目前只支持.csv格式的文件')
          return false
        }
        this.uploadFileName = file.name
        console.log(this.uploadFileName)
      }
    },
    // 批量修改-文件上传成功时的钩子
    handleUploadSuccess (response, file, fileList) {
      console.log('上传成功')
      this.uploadTagVisible = true
    },
    // 批量修改-文件上传失败时的钩子
    handleUploadError (err, file, fileList) {
      if (err.status === 404) {
        this.$message.error('上传失败，网络连接异常!')
      } else {
        console.log(err)
        this.$message.error('上传失败!')
      }
    },
    // 导入项目-文件上传时的钩子
    handleUploadProgress (event, file, fileList) {
      this.isUploading = true // 开启提示
      console.log('上传中...')
    },
    // 导入项目-文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
    async handleUploadChange (file, fileList) {
      this.handleClearFiles()
      this.fileList = [file]
      this.uploadFileName = file.name
      this.file = file.raw
      this.uploading = true
      // let data = {
      //   channelId: this.channelId,
      //   classifyCode: parseInt(this.classifyCode),
      //   name: this.queryForm.name,
      //   productId: this.queryForm.productId ? this.queryForm.productId : null,
      //   tag: !this.showFirst ? null : this.queryForm.tag ? parseInt(this.queryForm.tag) : null,
      //   file: this.file
      // }
      let param = new window.FormData()
      let data = {
        channelId: this.channelId,
        name: this.queryForm.name,
        productId: this.queryForm.productId ? this.queryForm.productId : '',
        tag: !this.showFirst ? '' : this.queryForm.tag ? parseInt(this.queryForm.tag) : '',
        classifyCode: parseInt(this.classifyCode)
      }
      // param.append('channelId', this.channelId)
      // param.append('classifyCode', parseInt(this.classifyCode))
      // param.append('name', this.queryForm.name)
      // param.append('productId', this.queryForm.productId ? this.queryForm.productId : null)
      // param.append('tag', !this.showFirst ? null : this.queryForm.tag ? parseInt(this.queryForm.tag) : null)
      param.append('file', this.file)
      try {
        let res = await dataBaseApi.importValidation(param, data)
        if (res.data.respCode === '1000') {
          // this.$message.success(res.data.respMsg)
          this.fileDialog.passVisible = true
          if (res.data.body) {
            this.gridData = res.data.body
          }
          this.uploading = false
        }
      } catch (error) {
        this.uploading = false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14{
    padding-left: 18px;
    font-size:14px
  }
  .text-box{
    font-size: 12px;
  }
  .text-block{
    margin:10px;
  }
  .rightText {
    text-align: right;
    line-height: 25px;
  }
  .leftText {
    line-height: 25px;
  }
</style>
