<!--定时任务-->
<template>
  <div>
    <div v-if="searchView[$route.path]">
      <!-- 父tab -->
      <!-- <el-radio-group v-model="bigID" style="margin-top:10px;" size="small">
        <el-radio-button :label="item.key" v-for="(item,index) in bigTagList" :key="index">{{item.value}}</el-radio-button>
      </el-radio-group> -->
      <div>
        <span class="fs-14">平台名称：</span>
        <el-radio-group size="mini" type="card" style="display: inline-block" v-model="queryForm.platform" @change="fetchData">
          <el-radio-button style="margin:5px 0" :label="item.key" v-for="(item,index) in selectList.platformList" :key="index">{{ item.value }}</el-radio-button>
        </el-radio-group>
      </div>
      <div>
        <span class="fs-14">渠道类型：</span>
        <el-radio-group size="mini" type="card" style="display: inline-block" v-model="queryForm.typeId" @change="fetchData">
          <el-radio-button style="margin:5px 0"  :label="item.id" v-for="(item,index) in selectList.typeList" :key="index">{{ item.typeName }}</el-radio-button>
        </el-radio-group>
      </div>
      <el-form :inline="true" :model="queryForm" size="mini" class="margin-mini">
       <el-form-item label="渠道号:" label-width="80px">
         <el-input v-model="queryForm.channelName" @keyup.native.enter="fetchData()"></el-input>
       </el-form-item>
       <el-form-item label="渠道商:" label-width="80px">
         <el-select v-model="queryForm.facilitatorId" style="width:100%" filterable clearable>
            <el-option
            v-for="(item,index) in selectList.facilitatorList"
            :key="index"
            :label="item.fullName"
            :value="item.id" 
            >
            {{item.fullName}}
            </el-option>
          </el-select>
       </el-form-item>
       <el-form-item label="负责人:" label-width="80px">
         <el-select style="width:163px" v-model="queryForm.principalId" filterable clearable>
            <el-option
            v-for="(item,index) in selectList.principalList"
            :key="index"
            :label="item.principalName"
            :value="item.id"
            >
            {{item.principalName}}
            </el-option>
          </el-select>
       </el-form-item>
       </br>
       <el-form-item label="支出日期:" label-width="80px">
         <el-date-picker
            v-model="queryForm.time"
            type="daterange"
            range-separator="至" 
            :clearable="false"
            start-placeholder="开始日期"
            value-format="yyyy-MM-dd"
            :picker-options="pickerOptions"
            end-placeholder="结束日期">
          </el-date-picker>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="fetchData()" class="least">查询</el-button>
        <el-button type="primary" size="mini" @click="down" :loading="downLoading" class="least">导出</el-button>
        <el-button type="primary" size="mini" @click="openUpload" class="least">批量导入</el-button>
        <el-button type="primary" size="mini" @click="updateList" :loading="downLoading" v-if="tabButtonPerms['expend.lock']" class="least">提报</el-button>
      </el-form-item>
    </el-form>
    </div>
    <!--表格-->
    <el-table
      v-loading="tableLoading" 
      :data="tableData"
      border fit
      highlight-current-row
      stripe
      show-summary
      :summary-method="getSummaries"
      :max-height="tableMaxHeight"
      style="width:100%"
      >
      <el-table-column
        prop="countDate"
        label="支出日期"
        :fixed = "tableData.length>0"
        width="80"
        sortable
        >
      </el-table-column>
      <el-table-column
        prop="channelName"
        label="渠道号"
        min-width="100"
        >
        <template slot-scope="scope">
          <div>
            <el-popover
            placement="right"
            width="320"
            trigger="hover">
            <template>
              <div style="margin-bottom:10px">渠道号: {{hoverRow.channelName}}</div>
                <el-table :data="gridData" stripe border :show-header="false" width="100%">
                  <el-table-column  prop="name" label=""></el-table-column>
                  <el-table-column  prop="value" label=""></el-table-column>
                </el-table>
            </template>
            <i slot="reference" class="el-icon-info" @mouseenter="fetchDetail(scope.row)"></i>
          </el-popover>
          <el-popover
            placement="right"
            width="155"
            trigger="click">
                <el-form size="mini">
                  <el-form-item>
                    <el-button @click="pushDetail(scope.row)">查看30天推广数据</el-button>
                  </el-form-item>
                  <el-form-item>
                    <el-button >查看30天质量数据</el-button>
                  </el-form-item>
                </el-form>
            <!-- <el-button slot="reference" type="text" @click="openEditDialog">{{scope.row.channelName}}</el-button> -->
            <span slot="reference" class="btnText" @click="openEditDialog">{{scope.row.channelName}}</span>
          </el-popover>
          </div>
         
        </template>
      </el-table-column>
      <el-table-column
      min-width="55"
      :render-header="renderCheck"
      >
      <template slot-scope="scope"> 
        <el-checkbox v-model="scope.row.statusView" v-if="scope.row.submissionStatus === false" @change="changeStatus"> </el-checkbox>
      </template>
      </el-table-column>
      <el-table-column
        prop="channelType"
        label="渠道类型"
        >
      </el-table-column>

      <el-table-column
        prop="dailyRealFee"
        label="实际支出(元)"
        :render-header="renderHeader"
        min-width="80"
        >
        <template slot-scope="scope">
          <template v-if="scope.row.submissionStatus">
            <span>{{scope.row.dailyRealFee}}</span>
          </template>
          <template v-if="!scope.row.submissionStatus">
             <div v-if="!scope.row.dailyRealFeeView" @dblclick="edit(scope.row,'dailyRealFee','dailyRealFeeView')" ><span :class="scope.row.dailyRealFeeViewRED">{{scope.row.dailyRealFee}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
            <div v-if="scope.row.dailyRealFeeView"><el-input v-model.number="scope.row.dailyRealFee" size="mini" @blur="blurInput(scope.row,'dailyRealFee','dailyRealFeeView')"> </el-input></div>
          </template>
      </template>
      </el-table-column>

      <el-table-column
        prop="paymentName"
        label="合作方式"
        min-width="70"
      >
      </el-table-column>

      <el-table-column
        prop="settleSourceName"
        label="结算数据源"
        width="70"
      >
      </el-table-column>
      <el-table-column
        prop="dailyPrice"
        label="单价"
        width="60"
        :render-header="renderHeader"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.submissionStatus">
            <span>{{scope.row.dailyPrice}}</span>
          </template>
          <template v-if="!scope.row.submissionStatus">
            <div v-if="!scope.row.dailyPriceView" @dblclick="edit(scope.row,'dailyPrice','dailyPriceView')"><span :class="scope.row.dailyPriceViewRED">{{scope.row.dailyPrice}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
          <div v-if="scope.row.dailyPriceView"><el-input  v-model.number="scope.row.dailyPrice" size="mini" @blur="blurInput(scope.row,'dailyPrice','dailyPriceView')"> </el-input></div>
          </template>
      </template>
      </el-table-column>
      <el-table-column
        prop="weSettlementNum"
        label="我方结算量"
        width="70"
        :render-header="renderHeader"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.submissionStatus">
            <span v-if="scope.row.settleSource !== 1">-</span>
            <span v-if="scope.row.settleSource === 1">{{scope.row.weSettlementNum}}</span>
          </template>
          <template v-if="!scope.row.submissionStatus">
            <span v-if="scope.row.settleSource !== 1">-</span>
            <div v-if="scope.row.settleSource === 1&&!scope.row.weSettlementNumView" @dblclick="edit(scope.row,'weSettlementNum','weSettlementNumView')"><span :class="scope.row.weSettlementNumViewRED">{{scope.row.weSettlementNum}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
            <div v-if="scope.row.settleSource === 1&&scope.row.weSettlementNumView"><el-input v-model.number="scope.row.weSettlementNum" size="mini" @blur="blurInput(scope.row,'weSettlementNum','weSettlementNumView')"> </el-input></div>
          </template>
      </template>
      </el-table-column>

      <el-table-column
        prop="dailyQualityScore"
        label="评分"
        width="65"
        :render-header="renderHeader"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.submissionStatus">
            <span>{{scope.row.dailyQualityScore}}</span>
          </template>
          <template v-if="!scope.row.submissionStatus">
            <div v-if="!scope.row.dailyQualityScoreView" @dblclick="edit(scope.row,'dailyQualityScore','dailyQualityScoreView')"><span :class="scope.row.dailyQualityScoreViewRED">{{scope.row.dailyQualityScore}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-if="scope.row.dailyQualityScoreView"><el-input v-model.number="scope.row.dailyQualityScore" size="mini" @blur="blurInput(scope.row,'dailyQualityScore','dailyQualityScoreView')"> </el-input></div>
          </template>
        
      </template>
      </el-table-column>

      <el-table-column
        prop="accountCost"
        label="账户花费(元)"
        width="75"
        :render-header="renderHeader"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.submissionStatus">
            <span>{{scope.row.accountCost}}</span>
          </template>
          <template v-if="!scope.row.submissionStatus">
            <div v-if="!scope.row.accountCostView" @dblclick="edit(scope.row,'accountCost','accountCostView')"><span :class="scope.row.accountCostViewRED">{{scope.row.accountCost}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-if="scope.row.accountCostView"><el-input v-model.number="scope.row.accountCost" size="mini" @blur="blurInput(scope.row,'accountCost','accountCostView')"> </el-input></div>
          </template>
        
      </template>
      </el-table-column>

      <el-table-column
        prop="accountRebate"
        label="账户返点"
        width="60"
        :render-header="renderHeader"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.submissionStatus">
            <span>{{scope.row.accountRebate}}</span>
          </template>
          <template v-if="!scope.row.submissionStatus">
              <div v-if="!scope.row.accountRebateView" @dblclick="edit(scope.row,'accountRebate','accountRebateView')"><span :class="scope.row.accountRebateViewRED">{{scope.row.accountRebate}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-if="scope.row.accountRebateView"><el-input v-model.number="scope.row.accountRebate" size="mini" @blur="blurInput(scope.row,'accountRebate','accountRebateView')"> </el-input></div>
          </template>
      </template>
      </el-table-column>

      <el-table-column
        prop="principalName"
        label="负责人"
        width="60"
      >
      </el-table-column>
      <el-table-column
        prop="payCost"
        label="付费成本"
        width="60"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="highAcceptCost"
        label="最高可接受成本"
        width="90"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="productClickCount"
        label="产品点击数"
        width="65"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="registerCount"
        label="注册"
        width="50"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="firstLoginCount"
        label="首次登陆"
        width="60"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="naturalLogin"
        label="自然登录"
        width="60"
        :render-header="renderHeader"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.submissionStatus">
            <span>{{scope.row.naturalLogin}}</span>
          </template>
          <template v-if="!scope.row.submissionStatus">
             <div v-if="!scope.row.naturalLoginView" @dblclick="edit(scope.row,'naturalLogin','naturalLoginView')"><span :class="scope.row.naturalLoginViewRED">{{scope.row.naturalLogin}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-if="scope.row.naturalLoginView"><el-input v-model.number="scope.row.naturalLogin" size="mini" @blur="blurInput(scope.row,'naturalLogin','naturalLoginView')"> </el-input></div>
          </template>
      </template>
      </el-table-column>
      <el-table-column
        prop="costLogin"
        label="付费登录"
        width="60"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="platformName"
        label="投放平台"
      >
      <!-- <template slot-scope="scope">
        <span>
          {{platformDIC[scope.row.platform]}}
        </span>
      </template> -->
      </el-table-column>
      <el-table-column
        prop="terminalName"
        label="投放系统"
        :render-header="renderHeader"
      >
      <!-- <template slot-scope="scope">
        <span>
          {{phoneDIC[scope.row.terminal]}}
        </span>
      </template> -->
      </el-table-column>
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
    
    <!-- 渠道号编辑弹窗 -->
     <el-dialog :visible.sync="uploadDialog" :title="downTitle" width="30%" center @close="closeFile">
       <el-form v-if="downTitle !=='导入文件'" style="text-align:center">
         <el-form-item>
           <el-button size="mini" style="width:116px" type="success" @click="toTemplate(1)">自然登录</el-button>
         </el-form-item>
         <el-form-item>
           <el-button size="mini" style="width:116px" type="success" @click="toTemplate(2)">账户花费</el-button>
         </el-form-item>
         <el-form-item>
           <el-button size="mini" type="success"  style="width:116px" @click="toTemplate(3)">质量评分</el-button>
         </el-form-item>
         <!-- <el-form-item>
           <el-button size="mini" style="width:116px" type="success" @click="toTemplate(4)">自然登陆量</el-button>
         </el-form-item> -->
       </el-form>
       <template v-else>
        <div >
          <el-upload class="upload-user-defined" name="in" accept=".csv" :auto-upload='false'
                   :action="uploadCompent.uploadExcelUrl" :file-list="uploadCompent.fileList" :show-file-list="true"
                   :with-credentials="true" ref = "upload" :before-remove="removeFile"
                   :before-upload="handleUploadBefore" :on-success="handleUploadSuccess" :on-error="handleUploadError"
                   :on-progress="handleUploadProgress" :on-change="handleUploadChange" :disabled="uploadCompent.isUploading">
          <el-button size="mini" type="primary" :loading="uploadCompent.isUploading">选择文件
          </el-button>
          <span style="font-size:12px;">只能上传.csv文件</span>
        </el-upload>
        </div>
        <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="downTemplate">下载模板</el-button>
        <el-button type="primary" @click="finalUpload" :disabled="isUpload" :loading="uploadCompent.isUploading">批量导入</el-button>
      </span>
      </template>
     </el-dialog>
     <!-- <el-dialog
      title="提示"
      :visible.sync="centerDialogVisible"
      :show-close = "false"
      :close-on-press-escape = "false"
      :close-on-click-modal = "false"
      width="25%"
      center>
      <template v-if="status === '生成中'">
        <span>正在生成文件...</span>
      </template>
      <template v-if="status === '生成文件失败'">
        <div class="center">生成文件失败</div>
      </template>

      <template v-if="status === '已生成文件'">
        <div class="center">已生成文件！</div>
      </template>
      <span slot="footer" class="dialog-footer" v-if="status === '生成文件失败'">
        <el-button type="primary"  size="mini" @click="centerDialogVisible = false">退出</el-button>
      </span>
      <span slot="footer" class="dialog-footer" v-if="status === '已生成文件'">
        <el-button type="primary"  size="mini">点击下载</el-button>
      </span>
    </el-dialog> -->
  </div>
</template>

<script>
// import numberUtils from '../../../utils/numberUtils.js'
import VueElTooltip from '../../../components/VueElTooltip'
import dataBaseApi from '../../../api/dataBaseApi.js'
import expendApi from '../../../api/expendApi.js'
import dataBaseJson from './dataBase.js'
import TABLE_TITLE_TIP from './expendJson.js'
import renderHead from '../../../components/renderHead/renderHead.vue'
import Moment from 'moment'
export default {
  components: {
    VueElTooltip,
    renderHead
  },
  props: {
    searchView: {
      type: Object,
      default: {

      }
    }
  },
  data () {
    return {
      value: null,
      tabButtonPerms: {
        'expend.lock': false,
        'expend.export': false
      },
      file: null,
      type: null,
      downTitle: '导入文件',
      uploadDialog: false,
      parentCheck: false,
      uploadCompent: {
        uploadExcelUrl: '35435465',
        fileList: [],
        isUploading: false
      },
      timer: null,
      downLoading: false,
      centerDialogVisible: true,
      status: '已生成文件',
      tableLoading: false,
      TABLE_TITLE_TIP: TABLE_TITLE_TIP,
      isclick: false,
      hoverWidth: '300',
      editDialog: false,
      hoverRow: {

      },
      summaryDailyVo: {

      },
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      gridData: [
        {'name': '渠道类型', value: ''},
        {'name': '渠道商', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: ''},
        {'name': '平台平成', value: ''},
        {'name': '投放终端', value: ''}
      ],
      platformDIC: {
        1: '花钱无忧',
        2: '大圣钱包',
        3: '无忧钱包',
        4: '贷款王',
        5: 'H5聚合'
      },
      phoneDIC: {
        1: 'Android',
        2: 'iOS',
        3: 'iOS/Android'
      },
      queryForm: {
        time: [],
        channelName: '',
        facilitatorId: '',
        platform: 0,
        principalId: '',
        typeId: 0
      },
      selectList: {
        platformList: dataBaseJson.platformList,
        typeList: [],
        facilitatorList: [],
        principalList: []
      },
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [30, 50, 100],
        pageSize: 30, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [
        // {
        //   'channelDailyFeeId': 2,
        //   'countDate': '2018-09-16',
        //   'channelName': 'guiye_test',
        //   'channelType': '信息流',
        //   'dailyRealFee': 6768.0000,
        //   'payment': 1,
        //   'paymentName': 'CPC(按点击付费)',
        //   'dailyPrice': 1.2000,
        //   'settleSource': 1,
        //   'settleSourceName': '我方',
        //   'weSettlementNum': 5640,
        //   'dailyQualityScore': 1.000,
        //   'accountCost': 4120.0000,
        //   'accountRebate': 1.00,
        //   'principalName': '于亚卫',
        //   'payCost': 1.0000,
        //   'highAcceptCost': 1.5000,
        //   'productClickCount': 1567,
        //   'registerCount': 5741,
        //   'firstLoginCount': 5874,
        //   'naturalLogin': 234,
        //   'costLogin': 5640,
        //   'platformId': 3,
        //   'terminalId': 2,
        //   'platformName': '无忧钱包',
        //   'terminalName': 'iOS',
        //   'submissionStatus': true,
        //   statusView: false
        // },
        // {
        //   'channelDailyFeeId': 2,
        //   'countDate': '2018-09-16',
        //   'channelName': 'guiye_test',
        //   'channelType': '信息流',
        //   'dailyRealFee': 6768.0000,
        //   'payment': 1,
        //   'paymentName': 'CPC(按点击付费)',
        //   'dailyPrice': 1.2000,
        //   'settleSource': 1,
        //   'settleSourceName': '我方',
        //   'weSettlementNum': 5640,
        //   'dailyQualityScore': 1.000,
        //   'accountCost': 4120.0000,
        //   'accountRebate': 1.00,
        //   'principalName': '于亚卫',
        //   'payCost': 1.0000,
        //   'highAcceptCost': 1.5000,
        //   'productClickCount': 1567,
        //   'registerCount': 5741,
        //   'firstLoginCount': 5874,
        //   'naturalLogin': 234,
        //   'costLogin': 5640,
        //   'platformId': 3,
        //   'terminalId': 2,
        //   'platformName': '无忧钱包',
        //   'terminalName': 'iOS',
        //   'submissionStatus': false,
        //   statusView: false
        // },
        // {
        //   'channelDailyFeeId': 2,
        //   'countDate': '2018-09-16',
        //   'channelName': 'guiye_test',
        //   'channelType': '信息流',
        //   'dailyRealFee': 6768.0000,
        //   'payment': 1,
        //   'paymentName': 'CPC(按点击付费)',
        //   'dailyPrice': 1.2000,
        //   'settleSource': 1,
        //   'settleSourceName': '我方',
        //   'weSettlementNum': 5640,
        //   'dailyQualityScore': 1.000,
        //   'accountCost': 4120.0000,
        //   'accountRebate': 1.00,
        //   'principalName': '于亚卫',
        //   'payCost': 1.0000,
        //   'highAcceptCost': 1.5000,
        //   'productClickCount': 1567,
        //   'registerCount': 5741,
        //   'firstLoginCount': 5874,
        //   'naturalLogin': 234,
        //   'costLogin': 5640,
        //   'platformId': 3,
        //   'terminalId': 2,
        //   'platformName': '无忧钱包',
        //   'terminalName': 'iOS',
        //   'submissionStatus': true,
        //   statusView: false
        // }
      ],
      listLoading: false
    }
  },
  created () {
    let countDateDefault = null
    if (this.$route.params.channelName) {
      let start = Moment(new Date()).format('YYYY-MM-DD')
      let temp = new Date().getTime() - 3600 * 1000 * 24 * 30
      let end = Moment(temp).format('YYYY-MM-DD')
      this.queryForm.time = [end, start]
      this.queryForm.channelName = this.$route.params.channelName
    } else {
      countDateDefault = Moment(new Date().getTime() - 3600 * 1000 * 24).format('YYYY-MM-DD')
      this.queryForm.time = [countDateDefault, countDateDefault]
    }

    this.fetchType()
    this.fetchData()
    this.fetchfacilitator()
    this.fetchprincipalList()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
    const btnKeys = ['expend.lock', 'expend.export']
    btnKeys.forEach(t => {
      this.$store.state.loginUser.tabButtonPerms.forEach(j => {
        if (t === j) {
          this.tabButtonPerms[t] = true
        }
      })
    })
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {
    isUpload () {
      if (this.uploadCompent.fileList.length < 1) return true
      return false
    },
    pageHeight () {
      if (this.searchView[this.$route.path]) {
        return 235
      } else {
        return 100
      }
    }
  },
  watch: {
    'pageHeight': function () {
      this.handleResize()
    }
  },
  methods: {
    async blurInput (row, content, view) {
      if (!/^(-)?\d+(\.\d+)?$/.test(row[content])) {
        return this.$message.error('请输入数字')
      }
      if (content === 'dailyQualityScore') {
        if (row[content] > 1 || row[content] < 0) {
          return this.$message.error('请输入0到1.0之间的数字！')
        }
      }
      if (content === 'accountRebate') {
        if (row[content] < 1) {
          return this.$message.error('请输入≥1.0的数字！')
        }
      }
      if (content !== 'naturalLogin' && content !== 'weSettlementNum') {
        row[content] = Number(row[content])
        // this.value = row[content] * 100
        row[content] = row[content].toFixed(2)
      }
      let userId = this.$store.state.loginUser.userId
      let dataObj = {}
      if (row.channelDailyFeeId) {
        dataObj = {
          channelDailyFeeId: row.channelDailyFeeId
        }
      } else {
        dataObj = {
          channelName: row.channelName,
          countDate: row.countDate
        }
      }
      let data = {
        userId: userId,
        ...dataObj
      }
      data[content] = row[content]
      let res = await expendApi.edit(data)
      if (res.data.respCode === '1000') {
        this.$message.success('编辑成功')
        row[view] = false
        let temp = view + 'RED'
        row[temp] = 'isRed'
        // this.fetchData()
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    edit (row, content, view) {
      row[view] = true
    },
    downTemplate () {
      window.location.href = process.env.BASE_API + `/promotion/fee/list/downloadTemplate?type=${this.type}`
    },
    toTemplate (type) {
      this.type = type
      this.downTitle = '导入文件'
    },
    openUpload () {
      this.downTitle = '亲爱的，你想导入什么?'
      this.uploadDialog = true
    },
    changeStatus (val) {
      let filterArr = this.tableData.filter(item => {
        return item.submissionStatus === false
      })
      let parentCheck = true
      filterArr.forEach(t => {
        if (t.statusView === false) {
          parentCheck = false
        }
      })
      this.parentCheck = parentCheck
    },
    renderCheck (createElement, {column}) {
      return createElement(renderHead, {
        props: {
          checked: this.parentCheck,
          isDisable: this.tabButtonPerms['expend.lock']
          // content: 'TABLE_TITLE_TIP[column.property]'
        },
        on: {
          'clickCheck': (a) => {
            this.parentCheck = a
            if (this.parentCheck) {
              let filterArr = this.tableData.filter(item => {
                return item.submissionStatus === false
              })
              filterArr.forEach(t => {
                t.statusView = true
              })
            }
            if (!this.parentCheck) {
              let filterArr = this.tableData.filter(item => {
                return item.submissionStatus === false
              })
              filterArr.forEach(t => {
                t.statusView = false
              })
            }
          }
        }
      })
    },
    async down () {
      if (this.downLoading) { return }
      this.downLoading = true
      let data = {
        channelName: this.queryForm.channelName,
        countDateStart: this.queryForm.time[0] || '',
        countDateEnd: this.queryForm.time[1] || '',
        facilitatorId: this.queryForm.facilitatorId,
        principalId: this.queryForm.principalId,
        typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
        platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
        // pageNum: this.pagination.pageNo,
        // pageSize: this.pagination.pageSize,
        queryType: 0
      }
      let res = await expendApi.dayStartDown(data)
      if (res.data.respCode === '1000') {
        if (res.data.body.downLoadFlag === 1) {
          clearInterval(this.timer)
          // let url = res.data.body.downLoadUrl.substring(3, res.data.body.downLoadUrl.length)
          // window.open(process.env.DOWN_URL + url)
          window.location.href = process.env.DOWN_URL + res.data.body.downLoadUrl
          // window.open('http://dev-img.huaqianwy.com' + res.data.body.downLoadUrl)
        }
        if (res.data.body.downLoadFlag === 0) {
          this.timer = setInterval(() => {
            this.poll()
          }, 1500)
        }
      } else {
        this.downLoading = false
        this.$message.error(res.data.respMsg)
      }
    },
    async poll () {
      let data = {
        channelName: this.queryForm.channelName,
        // countDateDefault: '2200-08-07',
        countDateStart: this.queryForm.time[0] || '',
        countDateEnd: this.queryForm.time[1] || '',
        // countDateStart: '2018-07-17',
        // countDateEnd: '2918-08-16',
        facilitatorId: this.queryForm.facilitatorId,
        principalId: this.queryForm.principalId,
        typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
        platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
        // pageNum: this.pagination.pageNo,
        // pageSize: this.pagination.pageSize,
        queryType: 1
      }
      let res = await expendApi.dayStartDown(data)
      if (res.data.respCode === '1000') {
        if (res.data.body.downLoadFlag === 1) {
          clearInterval(this.timer)
          window.location.href = process.env.DOWN_URL + res.data.body.downLoadUrl
          this.downLoading = false
        }
      }
    },
    async fetchDetail (val) {
      this.hoverRow = val
      this.gridData = [
        {'name': '渠道类型', value: val.channelType},
        {'name': '渠道商简称', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: val.principal},
        {'name': '平台名称', value: ''},
        {'name': '投放终端', value: ''}
      ]
      let res = await dataBaseApi.hover(this.hoverRow.channelName)
      // let res = await dataBaseApi.hover('测试渠道')
      if (res.data.respCode === '1000') {
        if (!res.data.body) {
          return this.$message.error('查询寻不到渠道明细')
        }
        this.gridData[0].value = res.data.body.typeName
        this.gridData[2].value = res.data.body.mediaName
        this.gridData[1].value = res.data.body.facilitatorShortName
        this.gridData[3].value = res.data.body.paymentName
        this.gridData[4].value = res.data.body.price
        this.gridData[5].value = res.data.body.status === 1 ? '显示' : '隐藏'
        this.gridData[6].value = res.data.body.principalName
        this.gridData[7].value = res.data.body.platformName
        // {'name': '平台名称', value: this.platformDIC[val.platform]},
        // {'name': '投放终端', value: this.phoneDIC[val.terminal]}
        this.gridData[8].value = res.data.body.terminalName
      }
    },
    clearDetail () {
      this.gridData[2].value = ''
      this.gridData[3].value = ''
      this.gridData[4].value = ''
      this.gridData[5].value = ''
    },
    pushDetail (row) {
      console.log(row)
      // window.open('#/preview-data/' + this.classifyCode, JSON.stringify(this.tableData))
      window.open(`#/marketing/channelDatabase/channelDetail/${row.channelName}`)
    },
    async fetchType () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.type(data)
      if (res.data.respCode === '1000') {
        let topArr = [{id: 0, typeName: '不限'}]
        this.selectList.typeList = topArr.concat(res.data.body.list)
      }
    },
    async fetchfacilitator () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.facilitator(data)
      if (res.data.respCode === '1000') {
        this.selectList.facilitatorList = res.data.body.list
      }
    },
    async fetchprincipalList () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.principal(data)
      if (res.data.respCode === '1000') {
        this.selectList.principalList = res.data.body.list
      }
    },
    async fetchData (val) {
      try {
        this.tableLoading = true
        let data = {
          channelName: this.queryForm.channelName,
          countDateStart: this.queryForm.time[0] || '',
          countDateEnd: this.queryForm.time[1] || '',
          facilitatorId: this.queryForm.facilitatorId,
          principalId: this.queryForm.principalId,
          typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
          platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
          pageNum: this.pagination.pageNo,
          pageSize: this.pagination.pageSize
        }
        let res = await expendApi.expendList(data)
        if (res.data.respCode === '1000') {
          this.tableLoading = false
          this.pagination.total = res.data.body.pageInfoRes.total
          this.pagination.pageNo = res.data.body.pageInfoRes.pageNum
          this.summaryDailyVo = res.data.body.summaryDailyVo
          res.data.body.pageInfoRes.list.forEach(t => {
            if (t.dailyRealFee || t.dailyRealFee === 0) { t.dailyRealFee = this.formatNum(t.dailyRealFee) }
            if (t.payCost || t.payCost === 0) { t.payCost = this.formatNum(t.payCost) }
            if (t.accountCostRED || t.accountCostRED === 0) { t.accountCostRED = this.formatNum(t.accountCostRED) }
            if (t.accountCost || t.accountCost === 0) { t.accountCost = t.accountCost.toFixed(2) }
            if (t.accountRebate || t.accountRebate === 0) { t.accountRebate = t.accountRebate.toFixed(2) }
            if (t.dailyPrice || t.dailyPrice === 0) { t.dailyPrice = this.formatNum(t.dailyPrice) }
            if (t.highAcceptCost || t.highAcceptCost === 0) { t.highAcceptCost = this.formatNum(t.highAcceptCost) }
            t.statusView = false
            t.dailyRealFeeView = false // 实际支出
            t.dailyPriceView = false // 单价
            t.weSettlementNumView = false // 我方结算量
            t.dailyQualityScoreView = false // 评分
            t.accountCostView = false // 账户花费
            t.accountRebateView = false // 账户返点
            t.naturalLoginView = false // 自然登录
            // 字段是否变红
            t.statusViewRED = ''
            t.dailyRealFeeViewRED = '' // 实际支出
            t.dailyPriceViewRED = '' // 单价
            t.weSettlementNumViewRED = '' // 我方结算量
            t.dailyQualityScoreViewRED = '' // 评分
            t.accountCostViewRED = '' // 账户花费
            t.accountRebateViewRED = '' // 账户返点
            t.naturalLoginViewRED = '' // 自然登录
          })
          this.tableData = res.data.body.pageInfoRes.list
          this.parentCheck = false
        } else {
          this.tableLoading = false
        }
      } catch (error) {
        this.tableLoading = false
      }
    },
    formatNum (num) {
      // num = Number(num) / 100
      num = num.toFixed(2)
      return num
    },
    openEditDialog () {
      this.hoverWidth = 150
      this.isclick = true
    },
    tableHover (val) {

    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: TABLE_TITLE_TIP[column.property]
          // content: 'TABLE_TITLE_TIP[column.property]'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - this.pageHeight
      })
    },
    getSummaries (param) {
      const sums = []
      sums[0] = '汇总'
      sums[1] = '-'
      sums[2] = '-'
      sums[3] = '-'
      if (this.summaryDailyVo.dailyRealFee || this.summaryDailyVo.dailyRealFee === 0) {
        sums[4] = this.formatNum(this.summaryDailyVo.dailyRealFee)
      }

      sums[5] = '-'
      sums[6] = '-'
      sums[7] = '-'
      sums[8] = this.summaryDailyVo.weSettlementNum
      sums[9] = '-'
      if (this.summaryDailyVo.accountCost || this.summaryDailyVo.accountCost === 0) {
        sums[10] = this.formatNum(this.summaryDailyVo.accountCost)
      }
      sums[11] = '-'
      sums[12] = '-'
      if (this.summaryDailyVo.payCost || this.summaryDailyVo.payCost === 0) {
        sums[13] = this.formatNum(this.summaryDailyVo.payCost)
      }
      // sums[13] = this.summaryDailyVo.payCost
      sums[14] = '-'
      sums[15] = this.summaryDailyVo.productClickCount
      sums[16] = this.summaryDailyVo.registerCount
      sums[17] = this.summaryDailyVo.firstLoginCount
      sums[18] = this.summaryDailyVo.naturalLogin
      sums[19] = this.summaryDailyVo.costLogin
      sums[20] = '-'
      sums[21] = '-'
      return sums
    },
    async updateList () {
      let filterArr = this.tableData.filter(item => {
        return item.submissionStatus === false
      })
      let ids = []
      filterArr.forEach(t => {
        if (t.statusView === true) {
          ids.push(t.channelDailyFeeId)
        }
      })
      if (ids.length === 0) {
        return this.$message.warning('请至少勾选一条记录！')
      }
      try {
        let confirm = await this.$confirm(`提交成功后，将无法修改本记录所有字段的信息，确认提交吗？`, '提示', { type: 'warning' })
        if (confirm) {
          let userId = this.$store.state.loginUser.userId
          let data = {
            ids: ids,
            userId: userId
          }
          let res = await expendApi.lock(data)
          if (res.data.respCode === '1000') {
            this.$message.success('提报成功')
            this.fetchData()
          } else {
            this.$message.error(res.data.respMsg)
          }
        }
      } catch (error) {
        this.$message.warning('取消提报')
      }
    },
    // 批量修改-清空已上传的文件列表
    handleClearFiles () {
      this.uploadCompent.fileList = []
      this.file = null
    },
    // 批量修改-上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
    handleUploadBefore (file) {
      if (file.name && file.name.length > 0) {
        const ldot = file.name.lastIndexOf('.')
        const type = file.name.toLowerCase().substring(ldot)
        if (type !== '.csv') {
          this.$message.warning('目前只支持.csv格式的文件')
          return false
        }
        this.uploadFileName = file.name
        console.log(this.uploadFileName)
      }
    },
    async finalUpload () {
      try {
        this.uploadCompent.isUploading = true
        let param = new window.FormData()
        param.append('file', this.file)
        // param.append('type', this.type)
        // let userId = this.$store.state.loginUser.userId
        let userId = this.$store.state.loginUser.userId
        let res = await expendApi.upload(param, this.type, userId)
        if (res.data.respCode === '1000') {
          this.$message.success('操作成功')
          this.uploadCompent.isUploading = false
          this.uploadDialog = false
          this.fetchData()
        } else {
          this.uploadCompent.isUploading = false
          this.$message.error(res.data.respMsg)
        }
      } catch (error) {
        this.uploadCompent.isUploading = false
      }
    },

    // 批量修改-文件上传成功时的钩子
    handleUploadSuccess (response, file, fileList) {
      console.log('上传成功')
    },
    // 批量修改-文件上传失败时的钩子
    handleUploadError (err, file, fileList) {
      if (err.status === 404) {
        this.$message.error('上传失败，网络连接异常!')
      } else {
        console.log(err)
        this.$message.error('上传失败!')
      }
    },
    // 导入项目-文件上传时的钩子
    handleUploadProgress (event, file, fileList) {
      this.isUploading = true // 开启提示
      console.log('上传中...')
    },
    // 导入项目-文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
    handleUploadChange (file, fileList) {
      this.handleClearFiles()
      this.uploadCompent.fileList = [file]
      this.file = file.raw
      this.isUploading = false // 关闭提示
      // console.log('上传完成')
    },
    removeFile () {
      this.$refs.upload && this.$refs.upload.clearFiles()
      this.uploadCompent.fileList = []
      this.file = null
    },
    closeFile () {
      this.file = null
      this.uploadCompent.fileList = []
      this.$refs.upload && this.$refs.upload.clearFiles()
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14{
    padding-left:8px;
    font-size:14px
  }
  .isRed {
    color:red
  }
</style>
