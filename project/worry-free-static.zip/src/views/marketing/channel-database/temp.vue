<!--定时任务-->
<template>
  <div>
    <div>
      <!-- 父tab -->
      <!-- <el-radio-group v-model="bigID" style="margin-top:10px;" size="small">
        <el-radio-button :label="item.key" v-for="(item,index) in bigTagList" :key="index">{{item.value}}</el-radio-button>
      </el-radio-group> -->
      <div>
        <span class="fs-14">平台名称：</span>
        <el-radio-group size="mini" type="card" style="display: inline-block" v-model="nameID">
          <el-radio-button style="margin-top:10px;"  :label="item.key" v-for="(item,index) in nameList" :key="index">{{ item.value }}</el-radio-button>
        </el-radio-group>
      </div>
      <div>
        <span class="fs-14">渠道类型：</span>
        <el-radio-group size="mini" type="card" style="display: inline-block" v-model="typeID">
          <el-radio-button style="margin:10px 0"  :label="item.key" v-for="(item,index) in typeList" :key="index">{{ item.value }}</el-radio-button>
        </el-radio-group>
      </div>
      <el-form :inline="true" :model="queryForm" size="mini" class="margin-mini">
       <el-form-item label="渠道号:" label-width="70px">
         <el-input v-model="queryForm.id"></el-input>
       </el-form-item>
       <el-form-item label="渠道商:" label-width="60px">
         <el-input v-model="queryForm.id"></el-input>
       </el-form-item>
       <el-form-item label="负责人:" label-width="60px">
         <el-input v-model="queryForm.id"></el-input>
       </el-form-item>
       <el-form-item label="ROI:" label-width="60px">
         <el-input v-model="queryForm.id" style="width:50px"></el-input>
         -
         <el-input v-model="queryForm.id" style="width:50px"></el-input>
         %
       </el-form-item>
       </br>
       <el-form-item label="考核日期" label-width="70px">
         <el-date-picker
            v-model="queryForm.time"
            type="daterange"
            range-separator="至"
            value-format="yyyy-mm-dd"
            start-placeholder="开始日期"
            end-placeholder="结束日期">
        </el-date-picker>
       </el-form-item>
       <el-form-item label="单次点击ARPU值：" label-width="140px">
         <span>2.1元/个</span>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" >修改参数值</el-button>
        <el-button size="mini" >查询</el-button>
        <el-button  size="mini" >导出</el-button>
        <el-button  >更新最高可接受成本</el-button>
      </el-form-item>
    </el-form>
    </div>
    <div class="text-box">
      <p>说明：</p>
      <p>1、渠道质量首次考核日期，是自渠道推广的第七天起，即首次推广日期+6；每日取近齐天数据作为渠道考核数据；</p>
      <p>2、某渠道修改质量评分后，从下一个运算周期开始，即自修改日开始使用新的评分；昨日及之前医生称的推广支出等数据，请手动修改</p>
      <p>3、ROI=(最高可接受成本/付费成本-1)*100%，0%即为盈亏平衡</p>
      <p>4、最高可接受成本：系统每周一更新，也可手动更新；(1)H5聚合页:即单词点击ARPU值；(2)APP:单登录用户ARPU=30日TAD*人均点击产品数*单次点击ARPU值/激活登录率</p>
    </div>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row show-summary  stripe  :max-height="tableMaxHeight" :summary-method="getSummaries" style="width: 100%">
      <el-table-column
        
        prop="date"
        label="支出日期"
        :render-header="renderHeader"
        >
      </el-table-column>
      <el-table-column
        prop="name"
        label="渠道号"
        :show-overflow-tooltip="true"
        :render-header="renderHeader"
        >
        <template slot-scope="scope">
          <el-tooltip content="Top Left 提示文字">
            <span>{{scope.row.name}}</span>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column
        prop="province"
        label="渠道类型"
        :render-header="renderHeader"
        >
      </el-table-column>
      <el-table-column
        prop="city"
        label="实际支出"
        :render-header="renderHeader"
        >
      </el-table-column>
      <el-table-column
        prop="address"
        label="合作方式"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="结算数据源"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="单价"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="我方结算量"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="评分"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="账户花费"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="账户返点"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="负责人"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="付费成本"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="最高可接受成本"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="产品点击数"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="注册"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="登录"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="自然登录"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="付费登录"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="平台名称"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="zip"
        label="手机系统"
        :render-header="renderHeader"
      >
      </el-table-column>
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import VueElTooltip from '../../../components/VueElTooltip'

export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      queryForm: {
        radio: 1,
        time: [],
        date: ''
      },
      bigID: 1,
      nameID: 1,
      typeID: 1,
      bigTagList: [
        {key: 1, value: '渠道汇总'},
        {key: 2, value: '渠道服务商'},
        {key: 3, value: '渠道类型'},
        {key: 4, value: '投放媒体'},
        {key: 5, value: '渠道负责人'},
        {key: 6, value: 'H5落地页'}
      ],
      nameList: [
        {key: 1, value: '不限'},
        {key: 2, value: '花钱无忧'},
        {key: 3, value: '无忧钱包'},
        {key: 4, value: '大圣钱包'},
        {key: 5, value: '贷款王'},
        {key: 6, value: 'H5聚合页'}
      ],
      typeList: [
        {key: 0, value: '不限'},
        {key: 1, value: '信息流'},
        {key: 2, value: '外部短信'},
        {key: 3, value: '贷款平台'},
        {key: 4, value: '苹果官方市场'},
        {key: 5, value: '安卓应用市场'}
      ],
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [10, 50, 100],
        pageSize: 10, // pageSize
        total: 10 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [],
      listLoading: false
    }
  },
  created () {
    // this.fetchData()
    for (let i = 0; i < 101; i++) {
      this.tableData.push({
        date: '2016-05-07',
        name: '王小虎',
        province: '上海',
        city: '普陀区',
        address: '上海市',
        zip: i + parseInt(Math.random() * 20)
      })
    }
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {

  },
  methods: {
    getSummaries (param) {
      const { columns, data } = param
      const sums = []
      columns.forEach((column, index) => {
        if (index === 0) {
          sums[index] = '总价'
          return
        }
        const values = data.map(item => Number(item[column.property]))
        if (!values.every(value => isNaN(value))) {
          sums[index] = values.reduce((prev, curr) => {
            const value = Number(curr)
            if (!isNaN(value)) {
              return prev + curr
            } else {
              return prev
            }
          }, 0)
          sums[index] += ' 元'
        } else {
          sums[index] = 'N/A'
        }
      })

      return sums
    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: '这是一段对标题的说明'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 515
      })
    },
    handleSizeChange () {

    },
    handleCurrentChange () {

    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14 {
    font-size: 14px
  }
  .text-box{
    font-size: 12px;
  }
</style>
