<!--定时任务-->
<template>
  <div>
    <div v-if="searchView[$route.path]">
      <!-- 父tab -->
      <!-- <el-radio-group v-model="bigID" style="margin-top:10px;" size="small">
        <el-radio-button :label="item.key" v-for="(item,index) in bigTagList" :key="index">{{item.value}}</el-radio-button>
      </el-radio-group> -->
      <div>
        <span class="fs-14">平台名称：</span>
        <el-radio-group size="mini" type="card" style="display: inline-block" v-model="queryForm.platform" @change="fetchData">
          <el-radio-button style="margin:5px 0" :label="item.key" v-for="(item,index) in selectList.platformList" :key="index">{{ item.value }}</el-radio-button>
        </el-radio-group>
      </div>
      <div>
        <span class="fs-14">渠道类型：</span>
        <el-radio-group size="mini" type="card" style="display: inline-block" v-model="queryForm.typeId" @change="fetchData">
          <el-radio-button style="margin:5px 0"  :label="item.id" v-for="(item,index) in selectList.typeList" :key="index">{{ item.typeName }}</el-radio-button>
        </el-radio-group>
      </div>
      <el-form :inline="true" :model="queryForm" size="mini" class="margin-mini">
       <el-form-item label="渠道号:" label-width="80px">
         <el-input v-model="queryForm.channelName"  @keyup.native.enter="fetchData()"></el-input>
       </el-form-item>
       <el-form-item label="渠道商:" label-width="80px">
         <el-select v-model="queryForm.facilitatorId" style="width:100%" filterable clearable>
            <el-option
            v-for="(item,index) in selectList.facilitatorList"
            :key="index"
            :label="item.fullName"
            :value="item.id" 
            >
            {{item.fullName}}
            </el-option>
          </el-select>
       </el-form-item>
       <el-form-item label="负责人:" label-width="80px">
         <el-select style="width:163px" v-model="queryForm.principalId" filterable clearable>
            <el-option
            v-for="(item,index) in selectList.principalList"
            :key="index"
            :label="item.principalName"
            :value="item.id"
            >
            {{item.principalName}}
            </el-option>
          </el-select>
       </el-form-item>
       </br>
       <el-form-item label="推广时间:" label-width="80px">
         <el-date-picker
            v-model="queryForm.time"
            type="daterange"
            range-separator="至"
            :clearable="false"
            start-placeholder="开始日期"
            value-format="yyyy-MM-dd"
            :picker-options="pickerOptions"
            end-placeholder="结束日期">
          </el-date-picker>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="fetchData()" class="least">查询</el-button>
        <el-button type="primary" size="mini" @click="down" :loading="downLoading" class="least">导出</el-button>
      </el-form-item>
    </el-form>
    </div>
    <!--表格  -->
    <el-table
      v-loading="tableLoading" 
      :data="tableData"
      border fit
      stripe
      highlight-current-row
      show-summary
      :summary-method="getSummaries"
      :max-height="tableMaxHeight"
      style="width:100%"
      >
      <el-table-column
        prop="countDate"
        label="推广时间"
        :fixed = "tableData.length>0"
        width="80"
        sortable
        >
      </el-table-column>

      <el-table-column
        prop="channelName"
        label="渠道号"
        min-width="100"
        >
        <template slot-scope="scope">
          <div>
            <el-popover
            placement="right"
            width="320"
            trigger="hover">
            <template>
              <div style="margin-bottom:10px">渠道号: {{hoverRow.channelName}}</div>
                <el-table :data="gridData" stripe border :show-header="false" width="100%">
                  <el-table-column  prop="name" label=""></el-table-column>
                  <el-table-column  prop="value" label=""></el-table-column>
                </el-table>
            </template>
            <i slot="reference" class="el-icon-info" @mouseenter="fetchDetail(scope.row)"></i>
          </el-popover>
          <el-popover
            placement="right"
            width="155"
            trigger="click">
                <el-form size="mini">
                  <el-form-item>
                    <el-button @click="pushDetail(scope.row)">查看30天推广数据</el-button>
                  </el-form-item>
                  <el-form-item>
                    <el-button >查看30天质量数据</el-button>
                  </el-form-item>
                </el-form>
            <!-- <el-button slot="reference" type="text" @click="openEditDialog">{{scope.row.channelName}}</el-button> -->
            <span slot="reference" class="btnText" @click="openEditDialog">{{scope.row.channelName}}</span>
          </el-popover>
          </div>
        </template>
      </el-table-column>

      <el-table-column
        prop="channelType"
        label="渠道类型"
        >
      </el-table-column>

      <el-table-column
        prop="firstLoginCount"
        label="首次登录"
        sortable
        :render-header="renderHeader"
        min-width="80"
        >
      </el-table-column>

      <el-table-column
        prop="registerCount"
        label="注册"
        sortable
        min-width="50"
        :render-header="renderHeader"
      >
      </el-table-column>

      <el-table-column
        prop="regLogConvRateView"
        label="注册登录转化率"
        width="110"
        sortable
      >
      <template slot-scope="scope">
        <span>
          {{scope.row.regLogConvRate}}
        </span>
      </template>
      </el-table-column>
      <el-table-column
        prop="regAndLogSameDay"
        label="注册当日登录"
        sortable
        width="100"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="reglogSameDayRateView"
        label="注册当日登录率"
        width="110"
        sortable
      >
      <template slot-scope="scope">
        <span>
          {{scope.row.reglogSameDayRate}}
        </span>
      </template>
      </el-table-column>

      <el-table-column
        prop="activation"
        label="激活"
        width="55"
        :render-header="renderHeader"
      >
      </el-table-column>

      <el-table-column
        prop="dailyActivity"
        label="日活"
        width="60"
        :render-header="renderHeader"
      >
      </el-table-column>

      <el-table-column
        prop="productClickCount"
        label="产品点击数"
        width="70"
        :render-header="renderHeader"
      >
      </el-table-column>

      <el-table-column
        prop="productClickCountPer"
        label="人均产品点击"
        sortable
        width="110"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="h5PagePV"
        label="落地页pv"
        width="60"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="h5PageUV"
        label="落地页uv"
        width="60"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="h5PageIP"
        label="落地页IP"
        width="60"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="verifyCodeClickCount"
        label="验证码点击用户数"
        width="100"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="registerClickCount"
        label="注册点击用户数"
        width="90"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="downloadClickCount"
        label="下载点击用户数"
        width="90"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="principal"
        label="负责人"
        :render-header="renderHeader"
      >
      </el-table-column>
      
      <el-table-column
        prop="platform"
        label="平台名称"
        :render-header="renderHeader"
      >
      <template slot-scope="scope">
        <span>
          {{platformDIC[scope.row.platform]}}
        </span>
      </template>
      </el-table-column>
      <el-table-column
        prop="terminal"
        label="手机系统"
        :render-header="renderHeader"
      >
      <template slot-scope="scope">
        <span>
          {{phoneDIC[scope.row.terminal]}}
        </span>
      </template>
      </el-table-column>
      <el-table-column
        prop="payment"
        label="合作方式"
      >
      <template slot-scope="scope">
        <span> {{payList[scope.row.payment]}} </span>
      </template>
      </el-table-column>
      <el-table-column
        prop="price"
        label="单价"
      >
      <template slot-scope="scope">
        <span> {{scope.row.priceView}} </span>
      </template>
      </el-table-column>
      <el-table-column
        prop="mediaName"
        label="媒体"
      >
      </el-table-column>
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import VueElTooltip from '../../../components/VueElTooltip'
import dataBaseApi from '../../../api/dataBaseApi.js'
import dataBaseJson from './dataBase.js'
import TABLE_TITLE_TIP from './detailInfoJson.js'
import Moment from 'moment'
export default {
  components: {
    VueElTooltip
  },
  props: {
    searchView: {
      type: Object,
      default: {

      }
    }
  },
  data () {
    return {
      payList: dataBaseJson.payList,
      timer: null,
      downLoading: false,
      centerDialogVisible: true,
      status: '已生成文件',
      tableLoading: false,
      TABLE_TITLE_TIP: TABLE_TITLE_TIP,
      isclick: false,
      hoverWidth: '300',
      editDialog: false,
      hoverRow: {

      },
      summaryDailyVo: {

      },
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      gridData: [
        {'name': '渠道类型', value: ''},
        {'name': '渠道商', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: ''},
        {'name': '平台平成', value: ''},
        {'name': '投放终端', value: ''}
      ],
      platformDIC: {
        1: '花钱无忧',
        2: '大圣钱包',
        3: '无忧钱包',
        4: '贷款王',
        5: 'H5聚合'
      },
      phoneDIC: {
        1: 'Android',
        2: 'iOS',
        3: 'iOS/Android'
      },
      queryForm: {
        time: [],
        channelName: '',
        facilitatorId: '',
        platform: 0,
        principalId: '',
        typeId: 0
      },
      selectList: {
        platformList: dataBaseJson.platformList,
        typeList: [],
        facilitatorList: [],
        principalList: []
      },
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [30, 50, 100],
        pageSize: 30, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [],
      listLoading: false
    }
  },
  created () {
    let countDateDefault = null
    if (this.$route.params.channelName) {
      let start = Moment(new Date()).format('YYYY-MM-DD')
      let temp = new Date().getTime() - 3600 * 1000 * 24 * 30
      let end = Moment(temp).format('YYYY-MM-DD')
      this.queryForm.time = [end, start]
      this.queryForm.channelName = this.$route.params.channelName
    } else {
      countDateDefault = Moment(new Date().getTime() - 3600 * 1000 * 24).format('YYYY-MM-DD')
      this.queryForm.time = [countDateDefault, countDateDefault]
    }

    this.fetchType()
    this.fetchData()
    this.fetchfacilitator()
    this.fetchprincipalList()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
    clearInterval(this.timer)
  },
  computed: {
    pageHeight () {
      if (this.searchView[this.$route.path]) {
        return 235
      } else {
        return 100
      }
    }
  },
  watch: {
    'pageHeight': function () {
      this.handleResize()
    }
  },
  methods: {
    async down () {
      if (this.downLoading) { return }
      this.downLoading = true
      let data = {
        channelName: this.queryForm.channelName,
        // countDateDefault: '2200-08-07',
        countDateStart: this.queryForm.time[0] || '',
        countDateEnd: this.queryForm.time[1] || '',
        // countDateStart: '2018-07-17',
        // countDateEnd: '2918-08-16',
        facilitatorId: this.queryForm.facilitatorId,
        principalId: this.queryForm.principalId,
        typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
        platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
        pageNum: this.pagination.pageNo,
        pageSize: this.pagination.pageSize,
        queryType: 0
      }
      let res = await dataBaseApi.dayStartDown(data)
      if (res.data.respCode === '1000') {
        if (res.data.body.downLoadFlag === 1) {
          clearInterval(this.timer)
          // let url = res.data.body.downLoadUrl.substring(3, res.data.body.downLoadUrl.length)
          // window.open(process.env.DOWN_URL + url)
          window.location.href = process.env.DOWN_URL + res.data.body.downLoadUrl
          // window.open('http://dev-img.huaqianwy.com' + res.data.body.downLoadUrl)
        }
        if (res.data.body.downLoadFlag === 0) {
          this.timer = setInterval(() => {
            this.poll()
          }, 1500)
        }
      } else {
        this.downLoading = false
        this.$message.error(res.data.respMsg)
      }
      // channelName: this.queryForm.channelName,
      // countDateHour: this.queryForm.time,
      // hour: this.queryForm.hour === '不限' ? '' : this.queryForm.hour,
      // facilitatorId: this.queryForm.facilitatorId,
      // principalId: this.queryForm.principalId,
      // typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
      // platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
      // pageNum: this.pagination.pageNo,
      // pageSize: this.pagination.pageSize
      // if (this.queryForm.hour === '不限') {
      //   hour = ''
      // } else {
      //   hour = this.queryForm.hour
      // }
      // window.location.href = '/mc/sys/img/推广明细20180906202603_19/推广明细20180906202603_19.xlsx'
      // window.location.href = process.env.BASE_API +
      // `/promotion/detail/downloadDetailListHour?channelName=${this.queryForm.channelName}&hour=${hour}` +
      // `&countDateHour=${this.queryForm.time}&facilitatorId=${this.queryForm.facilitatorId}&principalId=${this.queryForm.principalId}` +
      // `&typeId=${this.queryForm.typeId === 0 ? '' : this.queryForm.typeId}&pageNum=${this.pagination.pageNo}&pageSize=${this.pagination.pageSize}`
    },
    async poll () {
      let data = {
        channelName: this.queryForm.channelName,
        // countDateDefault: '2200-08-07',
        countDateStart: this.queryForm.time[0] || '',
        countDateEnd: this.queryForm.time[1] || '',
        // countDateStart: '2018-07-17',
        // countDateEnd: '2918-08-16',
        facilitatorId: this.queryForm.facilitatorId,
        principalId: this.queryForm.principalId,
        typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
        platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
        pageNum: this.pagination.pageNo,
        pageSize: this.pagination.pageSize,
        queryType: 1
      }
      let res = await dataBaseApi.dayStartDown(data)
      if (res.data.respCode === '1000') {
        if (res.data.body.downLoadFlag === 1) {
          clearInterval(this.timer)
          window.location.href = process.env.DOWN_URL + res.data.body.downLoadUrl
          this.downLoading = false
        }
      }
    },
    async fetchDetail (val) {
      this.hoverRow = val
      this.gridData = [
        {'name': '渠道类型', value: val.channelType},
        {'name': '渠道商简称', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: val.principal},
        {'name': '平台名称', value: ''},
        {'name': '投放终端', value: ''}
      ]
      let res = await dataBaseApi.hover(this.hoverRow.channelName)
      // let res = await dataBaseApi.hover('测试渠道')
      if (res.data.respCode === '1000') {
        if (!res.data.body) {
          return this.$message.error('查询寻不到渠道明细')
        }
        this.gridData[0].value = res.data.body.typeName
        this.gridData[2].value = res.data.body.mediaName
        this.gridData[1].value = res.data.body.facilitatorShortName
        this.gridData[3].value = res.data.body.paymentName
        this.gridData[4].value = res.data.body.price
        this.gridData[5].value = res.data.body.status === 1 ? '显示' : '隐藏'
        this.gridData[6].value = res.data.body.principalName
        this.gridData[7].value = res.data.body.platformName
        // {'name': '平台名称', value: this.platformDIC[val.platform]},
        // {'name': '投放终端', value: this.phoneDIC[val.terminal]}
        this.gridData[8].value = res.data.body.terminalName
      }
    },
    clearDetail () {
      this.gridData[2].value = ''
      this.gridData[3].value = ''
      this.gridData[4].value = ''
      this.gridData[5].value = ''
    },
    pushDetail (row) {
      console.log(row)
      // window.open('#/preview-data/' + this.classifyCode, JSON.stringify(this.tableData))
      window.open(`#/marketing/channelDatabase/channelDetail/${row.channelName}`)
    },
    async fetchType () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.type(data)
      if (res.data.respCode === '1000') {
        let topArr = [{id: 0, typeName: '不限'}]
        this.selectList.typeList = topArr.concat(res.data.body.list)
      }
    },
    async fetchfacilitator () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.facilitator(data)
      if (res.data.respCode === '1000') {
        this.selectList.facilitatorList = res.data.body.list
      }
    },
    async fetchprincipalList () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.principal(data)
      if (res.data.respCode === '1000') {
        this.selectList.principalList = res.data.body.list
      }
    },
    percentum (percentum) {
      try {
        let temp = percentum.replace('%', '')
        temp = Number(temp)
        return temp
      } catch (error) {
      }
    },
    async fetchData (val) {
      try {
        this.tableLoading = true
        let data = {
          channelName: this.queryForm.channelName,
          countDateDefault: null,
          // countDateDefault: '2200-08-07',
          countDateStart: this.queryForm.time[0] || '',
          countDateEnd: this.queryForm.time[1] || '',
          // countDateStart: '2018-07-17',
          // countDateEnd: '2918-08-16',
          facilitatorId: this.queryForm.facilitatorId,
          principalId: this.queryForm.principalId,
          typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
          platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
          pageNum: this.pagination.pageNo,
          pageSize: this.pagination.pageSize
        }
        let res = await dataBaseApi.detailDaily(data)
        if (res.data.respCode === '1000') {
          this.tableLoading = false
          this.pagination.total = res.data.body.pageInfoRes.total
          this.pagination.pageNo = res.data.body.pageInfoRes.pageNum
          // this.pagination.pageSize = res.data.body.pageSize
          this.summaryDailyVo = res.data.body.summaryDailyVo
          res.data.body.pageInfoRes.list.forEach(t => {
            if (t.price || t.price === 0) {
              t.priceView = t.price.toFixed(2)
            }
            if (t.reglogSameDayRate) {
              t.reglogSameDayRateView = this.percentum(t.reglogSameDayRate)
            }

            if (t.regLogConvRate) {
              t.regLogConvRateView = this.percentum(t.regLogConvRate)
            }
          })
          this.tableData = res.data.body.pageInfoRes.list
        } else {
          this.tableLoading = false
        }
      } catch (error) {
        this.tableLoading = false
      }
    },
    formatNum (num) {
      // num = Number(num) / 100
      num = num.toFixed(2)
      return num
    },
    async fetchPages (val) {
      try {
        this.tableLoading = true
        let data = {
          channelName: this.queryForm.channelName,
          countDateDefault: null,
          // countDateDefault: '2200-08-07',
          countDateStart: this.queryForm.time[0] || '',
          countDateEnd: this.queryForm.time[1] || '',
          // countDateStart: '2018-07-17',
          // countDateEnd: '2918-08-16',
          facilitatorId: this.queryForm.facilitatorId,
          principalId: this.queryForm.principalId,
          typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
          platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
          pageNum: this.pagination.pageNo,
          pageSize: this.pagination.pageSize
        }
        let res = await dataBaseApi.detailDaily(data)
        if (res.data.respCode === '1000') {
          this.tableLoading = false
          this.pagination.total = res.data.body.pageInfoRes.total
          this.pagination.pageNo = res.data.body.pageInfoRes.pageNum
          // this.pagination.pageSize = res.data.body.pageSize
          this.summaryDailyVo = res.data.body.summaryDailyVo
          this.tableData = res.data.body.pageInfoRes.list.slice(0, 20)
          // this.tableData = res.data.body.pageInfoRes.list
          setTimeout(() => { this.tableData = res.data.body.pageInfoRes.list }, 0)
        } else {
          this.tableLoading = false
        }
      } catch (error) {
        this.tableLoading = false
      }
    },
    openEditDialog () {
      this.hoverWidth = 150
      this.isclick = true
    },
    tableHover (val) {

    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: TABLE_TITLE_TIP[column.property]
          // content: 'TABLE_TITLE_TIP[column.property]'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - this.pageHeight
      })
    },
    getSummaries (param) {
      const sums = []
      sums[0] = '汇总'
      sums[1] = '-'
      sums[2] = '-'
      sums[3] = this.summaryDailyVo.firstLoginCount
      sums[4] = this.summaryDailyVo.registerCount
      sums[5] = this.summaryDailyVo.regLogConvRate
      sums[6] = this.summaryDailyVo.regAndLogSameDay
      sums[7] = this.summaryDailyVo.reglogSameDayRate
      sums[8] = this.summaryDailyVo.activation
      sums[9] = this.summaryDailyVo.dailyActivity
      sums[10] = this.summaryDailyVo.productClickCount
      sums[11] = this.summaryDailyVo.productClickCountPer
      sums[12] = this.summaryDailyVo.h5PagePV
      sums[13] = this.summaryDailyVo.h5PageUV
      sums[14] = this.summaryDailyVo.h5PageIP
      sums[15] = this.summaryDailyVo.verifyCodeClickCount
      sums[16] = this.summaryDailyVo.registerClickCount
      sums[17] = this.summaryDailyVo.downloadClickCount
      sums[18] = '-'
      sums[19] = '-'
      sums[20] = '-'
      sums[21] = '-'
      sums[22] = '-'
      sums[23] = '-'
      return sums
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14{
    padding-left:8px;
    font-size:14px
  }
</style>
