export default {
  platformList: [{key: 0, value: '不限'}, {key: 1, value: '花钱无忧'}, {key: 2, value: '大圣钱包'}, {key: 3, value: '无忧钱包'}, {key: 4, value: '贷款王'}, {key: 5, value: 'H5聚合页'}, {key: 8, value: '立即借'}],

  payList: {
    0: '免费',
    1: 'CPC(按点击付费)',
    2: 'CPA(按激活付费)',
    3: 'CPD(按下载付费)',
    4: 'CPT(按时长付费)',
    5: 'CPM(按展示付费)',
    6: 'CPS(按分成付费)',
    7: 'CPR(按注册付费)',
    8: 'CPAP(按申请付费)',
    9: 'CPK(按开户付费)',
    10: 'CPL(按动用付费)',
    11: '刷榜'
  }
}
