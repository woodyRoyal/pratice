<!--分组管理-->
<template>
  <imp-panel>
    <h3 class="box-title" slot="header" style="width: 100%;">
      <el-button type="primary" icon="plus" size="small" @click="addNewGroup">新增</el-button>
      <el-button type="danger" icon="delete" size="small" @click="batchDelete">删除</el-button>
    </h3>
    <el-row slot="body" :gutter="20">
      <el-col :span="8">
        <el-tree class="el-card tree-height" v-if="groupTree" show-checkbox highlight-current default-expand-all
                 ref="groupTree" check-strictly :expand-on-click-node="false" :data="groupTree"
                 @node-click="handleNodeClick" node-key="id" :props="treeProps">
        </el-tree>
      </el-col>
      <el-col :span="16">
        <el-card class="box-card">
          <div class="card-title" v-if="isAddForm">新增分组</div>
          <div class="text item">
            <el-form :model="form" ref="form" label-width="100px">
              <el-form-item label="父级">
                <el-cascader
                  :options="groupTree"
                  change-on-select
                  :show-all-levels="false"
                  v-model="form.parentId"
                  :props="menuTreeProps"
                ></el-cascader>
              </el-form-item>
              <el-form-item label="名称">
                <el-input v-model="form.name" auto-complete="off"></el-input>
              </el-form-item>
              <el-form-item label="分组码">
                <el-input v-model="form.code" auto-complete="off"></el-input>
              </el-form-item>
              <el-form-item label="类别">
                <el-input v-model="form.type" auto-complete="off"></el-input>
              </el-form-item>
              <el-form-item label="是否启用">
                <el-radio class="radio" v-model="form.valid" label="1">是</el-radio>
                <el-radio class="radio" v-model="form.valid" label="0">否</el-radio>
              </el-form-item>
              <el-form-item label="">
                <el-button type="primary" @click="onSubmit" v-text="form.id?'修改':'新增'"></el-button>
                <el-button type="danger" @click="deleteSelected" v-show="form.id && form.id!=null">删除
                </el-button>
              </el-form-item>
            </el-form>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </imp-panel>

</template>
<script type="text/babel">
  import panel from '../../components/SelectTree/panel.vue'
  import SelectTree from '../../components/SelectTree/selectTree.vue'
  import treeter from '../../components/SelectTree/treeter'
  import merge from 'element-ui/src/utils/merge'
  import {
    fetchGroupTree, fetchSaveOrUpdateGroup, fetchDeleteGroupByIdList
  } from '../../api/sys'

  export default {
    mixins: [treeter],
    components: {
      'imp-panel': panel,
      'el-select-tree': SelectTree
    },
    data () {
      return {
        treeProps: { // 树选择器配置选项 字段映射
          children: 'children',
          label: 'name',
          id: 'id'
        },
        menuTreeProps: {
          children: 'children',
          label: 'name',
          value: 'id'
        },
        group: [],
        groupTree: [], // 分组树
        // 表单数据
        form: {
          id: null,
          parentId: [],
          name: '',
          code: '',
          valid: '1',
          type: ''
        },
        isAddForm: false
      }
    },
    methods: {
      flattenDeep (arr) {
        arr.forEach(v => {
          if (v.children && v.children.length > 0) {
            this.flattenDeep(v.children)
            this.group.push(v)
          } else {
            this.group.push(v)
          }
        })
      },
      // 新增分组 置空form
      addNewGroup () {
        this.form = {
          id: null,
          parentId: [],
          name: '',
          code: '',
          valid: '1',
          type: ''
        }
        this.isAddForm = true
      },
      // 删除当前选择的分组
      deleteSelected () {
        // id转为数组
        let ids = []
        ids.push(this.form.id)
        this.deleteGroups(ids)
      },
      // 批量删除
      batchDelete () {
        let checkKeys = this.$refs.groupTree.getCheckedKeys()
        if (checkKeys == null || checkKeys.length === 0) {
          this.$message.warning('请选择要删除的分组')
          return
        }
        this.$confirm('确定要删除所选分组吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.deleteGroups(checkKeys)
        }).catch(() => {
        })
      },
      // 删除分组
      deleteGroups (idList) {
        let idString = idList.join(',')
        fetchDeleteGroupByIdList(idString)
          .then(res => {
            if (res.data.code === '0') {
              this.$message.success('删除成功')
              this.addNewGroup()
              this.getGroupTree()
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 树节点点击事件
      handleNodeClick (data) {
        this.isAddForm = false
        this.form = merge({}, data)
        let parentId = []
        // 后端返回子节点的所有父级id 解决多级节点问题
        this.form.parentIds = this.form.parentIds.split('/')
        for (let i = 0; i < this.form.parentIds.length - 1; i++) {
          parentId.push(Number(this.form.parentIds[i]))
        }
        this.form.parentId = parentId.length > 1 ? parentId : []
      },
      // 提交表单
      onSubmit () {
        if (this.form.name === '') {
          return this.$message.error('分组名称不能为空！')
        }
        if (this.form.code === '') {
          return this.$message.error('分组码不能为空！')
        }
        let ob = {
          id: this.form.id,
          parentId: this.form.parentId,
          name: this.form.name,
          code: this.form.code,
          valid: this.form.valid,
          type: this.form.type
        }
        ob.parentId = this.form.parentId ? this.form.parentId[this.form.parentId.length - 1] : null
        fetchSaveOrUpdateGroup(ob)
          .then(res => {
            if (res.data.code === '0' && res.data.data) {
              this.$message.success('操作成功')
              if (this.form.id == null) { // 新增
                this.form.id = res.data.data.id
                this.appendTreeNode(this.groupTree, res.data.data)
                this.isAddForm = false
              } else { // 修改
                this.updateTreeNode(this.groupTree, res.data.data)
              }
              this.getGroupTree()
            } else if (res.data.code === '4012') {
              this.$message.error('分组父节点不能是其本身')
            }
          })
          .catch(e => {
            console.log(e)
          })
      },
      // 获取分组树
      getGroupTree () {
        fetchGroupTree()
          .then(res => {
            if (res.data.code === '0' && res.data.data) {
              this.groupTree = res.data.data
              this.flattenDeep(this.groupTree)
            }
          })
          .catch(error => {
            console.log(error)
          })
      }
    },
    created () {
      this.getGroupTree()
    },
    mounted () {
    }
  }
</script>

<style lang="scss" scoped>
  .el-card {
    border-radius: 0;
  }

  .tree-height {
    max-height: 510px;
    overflow: auto;
  }

  /*文字淡入效果*/
  .card-title {
    margin-bottom: 10px;
    opacity: 0; /*实先规定文字的状态是不显示的*/
    animation: fade-in 4s ease 0s 1;
    /*规定动画的最后状态为结束状态*/
    animation-fill-mode: forwards;
  }

  /*自定义一个透明度从0到1的动画，它的名称是fade-in*/
  @keyframes fade-in {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
</style>
