<!--定时任务-->
<template>
  <div>
    <div>
      <el-form :inline="true" :model="queryForm" size="mini">
       <el-form-item label="用户名" label-width="80px">
         <el-input v-model="queryForm.username" @keyup.native.enter="fetchData()"></el-input>
       </el-form-item>
      <el-form-item label="展示名称" label-width="80px">
         <el-input v-model="queryForm.displayName" @keyup.native.enter="fetchData()"></el-input>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="fetchData()">查询</el-button>
        <el-button type="primary" size="mini" @click="openAddDialog">添加用户</el-button>
      </el-form-item>
    </el-form>
    </div>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row stripe :max-height="tableMaxHeight" style="width: 100%">
      <el-table-column
        sortable
        prop="id"
        fixed
        label="用户ID"
        >
      </el-table-column>
      <el-table-column
        prop="username"
        label="用户名"
        >
      </el-table-column>
      <el-table-column
        prop="displayName"
        label="展示名称"
        >
      </el-table-column>
      <el-table-column
        prop="address"
        label="是否启用"
      >
      <template slot-scope="scope">
        是
      </template>
      </el-table-column>
      <el-table-column
        prop="nameList"
        label="	拥有角色"
        >
      </el-table-column>
      <el-table-column
        prop="address"
        label="操作"
      >
      <template slot-scope="scope">
        <el-button type="text" size="mini" @click="edit(scope.row)">分配角色</el-button>
        <el-button type="text" size="mini" @click="del(scope.row)">删除用户</el-button>
      </template>
      </el-table-column>
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
    <!--  -->
    <el-dialog title="添加用户" size="mini" :visible.sync="addDialog">
      <el-form size="mini" :model="addform" ref="addform" :rules="addRules">
        <el-form-item label="用户名:" prop="username" label-width="130px">
          <el-input v-model="addform.username" placeholder="请填写2345员工邮箱名前缀!"></el-input>
        </el-form-item>

        <el-form-item label="展示名称:" prop="displayName" label-width="130px">
           <el-input v-model="addform.displayName" placeholder="请填写2345OA和企业微信显示的中文名!"></el-input>
        </el-form-item>
        <el-form-item label="提示:" prop="" label-width="130px">
          <span>若填写用户名、姓名在2345OA体系内不存在，将无法登录，请仔细确认!</span>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="addDialog = false">取消</el-button>
          <el-button type="primary" @click="submit">确认</el-button>
        </div>
    </el-dialog>
    <!-- 分配角色 -->
    <el-dialog title="分配角色" size="mini" :visible.sync="editDialog">
      <el-form size="mini" :model="editform">
        <el-form-item label="用户:" prop="username" label-width="100px">
          <span>{{row.username}}</span>
        </el-form-item>

        <el-form-item label="角色:" label-width="100px">
          <el-checkbox-group v-model="editform.role">
          <el-checkbox
          v-for=" (item,index) in roleList"
          :key="index"
          :label="item.id"
          :value="item.id"
          >{{item.name}}</el-checkbox>
        </el-checkbox-group>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="editDialog = false">取消</el-button>
          <el-button type="primary" @click="submiteditform">确认</el-button>
        </div>
    </el-dialog>
  </div>
</template>

<script>
import systemApi from '../../api/systemApi.js'
// import Moment from 'moment'
export default {

  data () {
    return {
      row: {},
      roleList: [],
      addDialog: false,
      editDialog: false,
      editform: {
        role: []
      },
      queryForm: {
        username: '',
        displayName: ''
      },
      addform: {
        displayName: '',
        username: ''
      },
      addRules: {
        username: [
          {required: true, message: '请输入用户名', trigger: 'blur'}
        ],
        displayName: [
          {required: true, message: '请输入显示名', trigger: 'blur'}
        ]
      },
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [10, 50, 100],
        pageSize: 100, // pageSize
        total: 10 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [],
      listLoading: false
    }
  },
  created () {
    this.fetchRoleList()
    this.fetchData()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {

  },
  methods: {
    // 删除当前分类
    del (row) {
      this.$confirm('确认删除该用户吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        systemApi.deleteUser(row.id)
          .then(response => {
            if (response.data.respCode === '1000') {
              this.$message.success('操作成功')
              this.fetchData()
            }
          })
          .catch(e => {
            console.log(e)
          })
      }).catch(() => {
      })
    },
    // async del (row) {
    //   try {
    //     let confirm = await this.$confirm(`确删除该用户吗?`, '提示', { type: 'warning' })
    //     if (confirm) {
    //       let res = systemApi.deleteUser(row.id)
    //       if (res.data.respCode === '1000') {
    //         this.$message.success('操作成功')
    //         this.fetchData()
    //       } else {
    //         this.$message.success(res.data.respMsg || '操作失败')
    //       }
    //     }
    //   } catch (error) {
    //     console.log('cancel')
    //   }
    // },
    async fetchRoleList () {
      let res = await systemApi.roleList()
      if (res.data.respCode === '1000') {
        this.roleList = res.data.body
      }
    },
    edit (row) {
      this.row = row
      this.editform.role = []
      for (let i = 0; i < this.row.roleKeys.length; i++) {
        this.row.roleKeys[i] = Number(this.row.roleKeys[i])
      }
      this.editform.role = this.row.roleKeys
      this.editDialog = true
    },
    async submiteditform () {
      let data = {
        userId: this.row.id,
        postIds: this.editform.role
      }
      let res = await systemApi.associatedUserPost(data)
      if (res.data.respCode === '1000') {
        this.$message.success('操作成功')
        this.fetchData()
        this.editDialog = false
      } else {
        this.$message.success(res.data.respMsg || '操作失败')
      }
    },
    submit () {
      this.$refs['addform'].validate(async valid => {
        if (!valid) {
          return false
        }
        let res = await systemApi.addUser(this.addform)
        if (res.data.respCode === '1000') {
          this.$message.success('操作成功')
          this.addDialog = false
          this.fetchData()
        } else {
          this.$message.success(res.data.respMsg || '操作失败')
        }
      })
    },
    async fetchData () {
      let data = {
        displayName: this.queryForm.displayName,
        username: this.queryForm.username,
        currentPage: this.pagination.pageNo,
        pageSize: this.pagination.pageSize
      }
      let res = await systemApi.findUserByPage(data)
      if (res.data.respCode === '1000') {
        res.data.body.list.forEach(t => {
          t.nameList = []
          t.roleKeys = Object.keys(t.roleNames)
          // t.roleKeys.forEach(v => {
          //   t.nameList.push(t.roleNames[v])
          // })
          t.nameList = Object.values(t.roleNames)
          t.nameList = t.nameList.join(',')
        })
        // this.pagination.pageSize = res.data.body.pageSize
        this.pagination.pageNo = res.data.body.pageNum
        this.pagination.total = res.data.body.total
        this.tableData = res.data.body.list
      }
    },
    openAddDialog () {
      this.addDialog = true
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 200
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
