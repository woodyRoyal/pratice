<!--角色管理-->
<template>
  <div class="role-manage">
    <!--表单-->
    <el-form :inline="true" :model="queryFormData" class="form-user-defined">
      <el-row>
        <el-col :span="12" class="form-btn">
          <el-form-item>
            <el-button size="small" type="primary" icon="plus" @click="dialogFormVisible = true">新增</el-button>
          </el-form-item>
        </el-col>
        <el-col :span="12" style="text-align: right;" class="form-btn">
          <el-form-item>
            <el-input @keyup.enter.native="getTableData" size="small" class="length-1" placeholder="请输入角色名"
                      v-model="queryFormData.name">
              <el-button slot="append" type="primary" size="small" @click="handleSearchData">搜索</el-button>
            </el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <!--表格-->
    <el-table :data="tableData" border fit highlight-current-row style="width: 100%">
      <el-table-column align="center" label="角色id" prop="id" sortable fixed>
      </el-table-column>
      <el-table-column align="center" label="角色名称" prop="name">
      </el-table-column>

      <el-table-column align="center" label="描述" prop="remark">
      </el-table-column>

       <!-- <el-table-column align="center" label="权限列表" prop="resourcesView"  min-width="350">
         <template slot-scope="scope">
          <el-popover placement="top">
            <span >
              {{ index + 1 == scope.row.resourcesView.length ? scope.row.resourcesView : scope.row.resourcesView + "，"
              }}
            </span>
            <div slot="reference" class="name-wrapper">
              <span >
                {{ index + 1 == scope.row.resourcesView.length ? scope.row.resourcesView: scope.row.resourcesView + "，"
                }}
              </span>
            </div>
          </el-popover>
        </template>
      </el-table-column> -->

      <el-table-column align="center" label="是否启用">
        <template slot-scope="scope">
          <!-- 0 禁用; 1 启用 -->
          <span>{{ scope.row.deleted === 0 ? '是' : '否' }}</span>
        </template>
      </el-table-column>

      <el-table-column align="center" label="操作" min-width="100px">
        <template slot-scope="scope">
          <el-button type="primary" @click='handleEditRole(scope.row)' size="mini"
                     icon="edit">修改
          </el-button>
          <el-button type="danger" @click="handleDeleteRole(scope.row)" icon="delete2"
                     size="mini">删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页-->
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="queryFormData.pageNum" :page-sizes="pageSizes"
                     :page-size="queryFormData.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="queryFormData.totalRecord">
      </el-pagination>
    </div>
    <!--新增角色-->
    <el-dialog :title="dialogTitle" :visible.sync="dialogFormVisible" @close="handleDialogClose"
               class="add-edit-role-dialog">
      <el-form :model="addRoleform" :rules="addFormRules" ref="addRoleform" label-width="80px">
        <el-form-item label="角色名" prop="name">
          <el-input v-model="addRoleform.name" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="描述" prop="remark">
          <el-input v-model="addRoleform.remark" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="权限" prop="resourceIds" class="is-required">
          <el-tree show-checkbox highlight-current style="max-height: 300px;overflow: auto"
                   ref="permissionTreeData"
                   default-expand-all
                   @check-change="handleCheckChange"
                   :data="permissionTreeData"
                   check-strictly
                   node-key="id" :props="permissionTreeProps">
          </el-tree>
        </el-form-item>
        <el-form-item label="是否启用" prop="valid">
          <el-radio class="radio" v-model="addRoleform.deleted" :label="0">是</el-radio>
          <el-radio class="radio" v-model="addRoleform.deleted" :label="1">否</el-radio>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleAddRoleCancel">取 消</el-button>
        <el-button type="primary" @click="handleAddRoleConfirm" :loading="isBtnLoading">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import ElSelectTree from '../../components/SelectTree/selectTree.vue'
  import systemApi from '../../api/systemApi.js'
  export default {
    components: {
      ElSelectTree
    },
    data () {
      // 权限
      const validatePermission = (rule, value, callback) => {
        if (!value || value.length === 0) {
          callback(new Error('请选择权限'))
        } else {
          callback()
        }
      }
      return {
        row: {},
        // 查询表单参数
        queryFormData: {
          name: '', // 角色名
          pageSize: 100, // 每页条数
          pageNum: 1, // 页码
          totalRecord: null, // 总记录数
          totalPage: null // 总页数
        },
        pageSizes: [50, 100, 200, 500],

        tableData: null, // 表数据
        listLoading: false,

        dialogFormVisible: false, // 显示新增角色框

        permissionTreeData: [], // 权限树数据
        permissionListMap: {}, // 权限数据对象
        permissionTreeProps: { // 权限树配置 字段映射
          children: 'children',
          label: 'name',
          id: 'id'
        },

        addRoleform: { // 新增角色表单
          name: '',
          remark: '',
          resourceIds: [], // 角色权限id数组 页面使用
          deleted: 0 // 1_停用 0_启用
        },
        // 新增角色表单输入验证规则
        addFormRules: {
          name: [
            {required: true, message: '请输入角色名', trigger: 'blur'}
          ],
          resourceIds: [
            {validator: validatePermission, trigger: 'change'}
          ]
        },
        dialogTitle: '新增角色', // 弹窗的title
        isBtnLoading: false // 确定按钮控制
      }
    },
    mounted () {
      this.fetchTree()
      // let _this = this
      // this.getPermissionTree()
      // this.getPermissionList()
      this.getTableData()
    },
    methods: {
      // 处理分页每页显示数改变事件
      handleSizeChange (val) {
        this.queryFormData.pageSize = val
        this.getTableData()
      },
      // 处理页码改变事件
      handleCurrentChange (val) {
        this.queryFormData.pageNum = val
        this.getTableData()
      },
      // 搜索按钮
      handleSearchData () {
        this.getTableData()
      },
      // 获取表格数据
      async getTableData () {
        this.listLoading = true
        let data = {
          currentPage: this.queryFormData.pageNum,
          pageSize: this.queryFormData.pageSize,
          name: this.queryFormData.name
        }
        let res = await systemApi.rolePage(data)
        if (res.data.respCode === '1000') {
          this.tableData = res.data.body.list.forEach(t => {
            t.resourceIds = Object.keys(t.resources)
            t.resourcesView = []
            // t.resourceIds.forEach(v => {
            //   t.resourcesView.push(t.resources[v])
            // })
            t.resourcesView = Object.values(t.resources)
            // t.resourcesView = t.resourcesView.join(',')
          })
          this.queryFormData.pageSize = res.data.body.pageSize
          this.queryFormData.pageNum = res.data.body.pageNum
          this.queryFormData.totalRecord = res.data.body.total
          this.tableData = res.data.body.list
        }
      },
      // 获取权限树
      async fetchTree () {
        let res = await systemApi.allResourceTree()
        if (res.data.respCode === '1000') {
          this.permissionTreeData = res.data.body
        }
      },
      // 获取权限树
      // getPermissionTree () {
      //   fetchPermissionTree()
      //     .then(response => {
      //       let res = response.data
      //       if (res.code === '0' && res.isSuccess === 'success') {
      //         this.permissionTreeData = res.data
      //       }
      //     })
      //     .catch(error => {
      //       console.log(error)
      //     })
      // },
      // 点击新增按钮，打开dialog
      openRoleDialog () {
        this.dialogFormVisible = true
        this.dialogTitle = '新增角色'
        // 新增角色表单置空
        this.addRoleform = { // 新增角色表单
          name: '',
          remark: '',
          resourceIds: [], // 角色权限id数组 页面使用
          deleted: 0 // 1_停用 0_启用
        }
      },
      // 清空树节点的选择
      resetChecked () {
        this.$refs.permissionTreeData.setCheckedKeys([])
      },
      // 通过key设置
      setCheckedKeys (keys) {
        this.$refs.permissionTreeData.setCheckedKeys(keys)
      },
      // Dialog 关闭的回调
      handleDialogClose () {
        // 表单置空
        this.addRoleform = {
          name: '',
          remark: '',
          resourceIds: [], // 角色权限id数组 页面使用
          deleted: 0 // 1_停用 0_启用
        }
        this.resetChecked()
        this.dialogTitle = '新增角色'
        this.$refs['addRoleform'].resetFields()
      },
      // 点击编辑按钮，打开dialog
      handleEditRole (role) {
        this.row = role
        for (let i = 0; i < role.resourceIds.length; i++) {
          role.resourceIds[i] = Number(role.resourceIds[i])
        }
        this.dialogTitle = '编辑角色'
        this.addRoleform = {
          name: role.name,
          remark: role.remark,
          resourceIds: role.resourceIds,
          deleted: role.deleted
        }
        this.dialogFormVisible = true
        // this.addRoleform = Object.assign({}, role)
        // 给权限树赋值（等视图渲染完再，不然undefined）
        this.$nextTick(() => {
          this.setCheckedKeys(role.resourceIds)
        })
      },
      // 删除当前角色
      async handleDeleteRole (role) {
        try {
          let confirm = await this.$confirm('确认删除该角色吗', '提示', { type: 'warning' })
          if (confirm) {
            let data = {
              id: role.id
            }
            let res = await systemApi.delRole(data)
            if (res && res.data.respCode === '1000') {
              this.$message({
                type: 'success',
                message: '删除成功!'
              })
              this.getTableData()
            } else {
              this.$message({
                type: 'error',
                message: res.data.respMsg || '删除失败'
              })
            }
          }
        } catch (error) {
          console.log('cancel')
        }
      },
      // 处理权限树选中事件
      handleCheckChange (data, checked, indeterminate) {
        let parentIds = data.parentIds
        if (parentIds) {
          for (let i = 0; i < parentIds.length; i++) {
            parentIds[i] = parentIds[i].toString()
          }
          this.addRoleform.resourceIds = parentIds.concat(this.$refs.permissionTreeData.getCheckedKeys())
          let temp = []
          for (let i = 0; i < this.addRoleform.resourceIds.length; i++) {
            if (temp.indexOf(this.addRoleform.resourceIds[i]) === -1) {
              temp.push(this.addRoleform.resourceIds[i])
            }
          }
          this.addRoleform.resourceIds = temp
          this.setCheckedKeys(this.addRoleform.resourceIds)
        } else {
          this.addRoleform.resourceIds = this.$refs.permissionTreeData.getCheckedKeys()
          this.setCheckedKeys(this.addRoleform.resourceIds)
        }
      },
      // 确认添加角色
      handleAddRoleConfirm () {
        this.$refs['addRoleform'].validate(async (valid) => {
          if (!valid) { return false }
          if (this.dialogTitle === '新增角色') {
            let resourceIds = []
            for (let i = 0; i < this.addRoleform.resourceIds.length; i++) {
              resourceIds.push(Number(this.addRoleform.resourceIds[i]))
            }

            let data = {
              ...this.addRoleform,
              resourceIds: resourceIds
            }
            let res = await systemApi.addRole(data)
            if (res.data.respCode === '1000') {
              this.$message.success('新增成功')
              this.dialogFormVisible = false
              this.getTableData()
            } else {
              this.$message.error(res.data.respMsg || '新增失败')
            }
          }

          if (this.dialogTitle === '编辑角色') {
            let resourceIds = []
            for (let i = 0; i < this.addRoleform.resourceIds.length; i++) {
              resourceIds.push(Number(this.addRoleform.resourceIds[i]))
            }
            let data = {
              ...this.addRoleform,
              resourceIds: resourceIds,
              id: this.row.id
            }
            let res = await systemApi.editRole(data)
            if (res.data.respCode === '1000') {
              this.$message.success('编辑成功')
              this.dialogFormVisible = false
              this.getTableData()
            } else {
              this.$message.error(res.data.respMsg || '新增失败')
            }
          }
        })
      },
      // 取消添加角色
      handleAddRoleCancel () {
        this.dialogFormVisible = false
        this.resetForm('addRoleform')
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      handleCascaderChange (val) {
        this.addRoleform.groupId = val[val.length - 1] // 取最后一级分组的id
      }
    }
  }
</script>

<style lang="scss" scoped>
  .form-user-defined {
    .el-form-item {
      margin-right: 20px;
      margin-bottom: 10px;
    }
    .form-btn {
      .el-form-item {
        margin-right: 0;
      }
    }
  }

  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

</style>
