<!-- 组件说明 -->
<template>
  <div>
    <el-form :inline="true"
             :model="queryForm"
             size="mini"
             class="margin-mini">
      <el-form-item label="广告位ID">
        <el-input v-model="queryForm.adBlockId">
        </el-input>
      </el-form-item>
      <el-form-item label="所属产品线">
        <el-select v-model="queryForm.productLine"
                   style="width:100px;"
                   clearable>
          <el-option value=""
                     label="全部"></el-option>
          <el-option :value="1"
                     label="花钱无忧"></el-option>
          <el-option :value="2"
                     label="贷款王"></el-option>
          <el-option :value="5"
                     label="立即借"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="手机">
        <el-select v-model="queryForm.cellSystem"
                   style="width:100px;"
                   clearable>
          <el-option value=""
                     label="全部"></el-option>
          <el-option :value="1"
                     label="android"></el-option>
          <el-option :value="2"
                     label="ios"></el-option>
        </el-select>
      </el-form-item>
    
      <el-form-item>
        <el-button type="primary"
                   :loading="listLoading"
                   class="least"
                   @click="fetchData">
          筛选
        </el-button>
        <!-- <el-button type="primary"  @click="previewSort" class="least">预览排序</el-button> -->
        <el-button type="primary"
                   class="least"
                   @click="submitSort">
          提交板块优先级
        </el-button>
        <el-button type="primary"
                   class="least"
                   @click="uploadDialog()">
          批量导入
        </el-button>
      </el-form-item>
      <!-- <el-upload class="upload-user-defined" name="in" accept=".csv" :auto-upload='false'
                   action="uploadExcelUrl" :file-list="fileList" :show-file-list="false"
                   :with-credentials="true" ref="upload" :disabled="uploading"
                   >
          <el-button size="mini" type="primary" :loading="uploading" class="least">批量导入
          </el-button>
          <span style="font-size:12px;">只能上传.csv文件</span>
        </el-upload> -->
    </el-form>
    <el-table :key="classifyCode"
              v-loading="listLoading"
              :data="tableData"
              border
              stripe
              highlight-current-row
              style="width:100%;"
              :max-height="tableHeight">
      <el-table-column align="center"
                       prop="adBlockId"
                       label="广告位ID"
                       sortable>
      </el-table-column>
      <el-table-column align="center"
                       prop="adBlockName"
                       label="广告板块显示名">
      </el-table-column>
      <el-table-column align="center"
                       prop="productLine"
                       label="所属产品线">
        <template slot-scope="scope">
          <span>
            {{ mapList.productLineList[scope.row.productLine] }}
          </span>
        </template>
      </el-table-column>
      <el-table-column align="center"
                       prop="cellSystem"
                       label="手机系统">
        <template slot-scope="scope">
          <span>
            {{ mapList.cellSystemList[scope.row.cellSystem] }}
          </span>
        </template>
      </el-table-column>
      <el-table-column align="center"
                       prop="classifyCode"
                       label="分类code">
      </el-table-column>
      <el-table-column align="center"
                       prop="productMax"
                       label="填充产品数上限">
      </el-table-column>
      <el-table-column align="center"
                       prop="productMin"
                       label="填充产品数下限">
      </el-table-column>
      <el-table-column align="center"
                       prop="adMaterial"
                       label="广告素材要求">
        <template slot-scope="scope">
          <span>{{ mapList.adMaterialMap[scope.row.adMaterial] }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center"
                       prop="specialTag"
                       label="支持的产品特色标签">
        <template slot-scope="scope">
          <span v-for="(item,index) in scope.row.specialTagArr"
                :key="index">
            <span>{{ uniqueTagMap[item] }}</span>
            <span v-if="index !== scope.row.specialTagArr.length - 1">,</span>
          </span>
        </template>
      </el-table-column>
        
      <el-table-column align="center"
                       prop="priority"
                       label="板块优先级"
                       sortable>
        <template slot-scope="scope">
          <div class="pd">
            <el-input v-model.number="scope.row.priority"
                      size="mini"
                      type="number"
                      :min="1"
                      onkeypress="return(  /[0-9]/.test(String.fromCharCode(event.keyCode)))"></el-input>
          </div>
        </template>
      </el-table-column>
      <el-table-column align="center"
                       prop="classifySort"
                       label="操作">
        <template slot-scope="scope">
          <el-button size="mini"
                     type="primary"
                     @click="edit(scope.row)">
            编辑
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog :visible.sync="upDialog.show"
               title="批量更新配置"
               cenetr
               width="600px"
               @close="closeUp">
      <el-form ref="addForm"
               :model="upDialog.upForm"
               size="small"
               :rules="upDialog.upRules">
        <el-form-item>
          <p>导入文件仅限更新填充产品数上线，填充产品数下限、广告素材要求、支持的产品特色标签、板块优先级配置</p>
        </el-form-item>
        <el-form-item label=""
                      prop="file">
          <el-upload ref="upload"
                     class="upload-user-defined"
                     name="in"
                     accept=".csv"
                     :auto-upload="false"
                     action="uploadExcelUrl"
                     :file-list="upDialog.fileList"
                     :show-file-list="true"
                     :with-credentials="true"
                     :disabled="uploading"
                     :on-change="handleUploadChange"
          >
            <el-button size="mini"
                       type="primary"
                       :loading="uploading"
                       class="least">
              选择文件
            </el-button>
            <span style="font-size:12px;">只能上传.csv文件</span>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button type="success"
                   @click="submitFile">
          批量导入
        </el-button>
      </div>
    </el-dialog>


    <el-dialog :visible.sync="editDialog.show"
               title="编辑"
               cenetr
               width="1000px"
               @close="closeUp">
      <el-form 
        ref="addForm" 
        :model="editDialog.editForm" 
        size="small"
        :label-width="editDialog.width" 
        :rules="editDialog.editRules">
        <el-form-item label="广告位ID:"
                      prop="file">
          <span>{{ editDialog.editForm.adBlockId }}</span>
        </el-form-item>
        <el-form-item label="广告板块后台名称:"
                      prop="file">
          <span>{{ editDialog.editForm.adBlockId }}</span>
        </el-form-item>
        <el-form-item label="所属产品线:"
                      prop="file">
          <span>{{ mapList.productLineList[editDialog.editForm.productLine] }}</span>
        </el-form-item>
        <el-form-item label="手机系统:"
                      prop="file">
          <span>{{ mapList.cellSystemList[editDialog.editForm.cellSystem] }}</span>
        </el-form-item>
        <el-form-item label="分类code:"
                      prop="file">
          <span>{{ editDialog.editForm.classifyCode }}</span>
        </el-form-item>
        <el-form-item label="填充产品数上限:"
                      prop="productMax">
          <el-input v-model="editDialog.editForm.productMax"
                    size="small"
                    class="length-1"></el-input>
          <span class="font">请填写1~999之间的整数</span>
        </el-form-item>
        <el-form-item label="填充产品数下限:"
                      prop="productMin">
          <el-input v-model="editDialog.editForm.productMin"
                    size="small"
                    class="length-1"></el-input>
          <span class="font">请填写1~999之间的整数</span>
        </el-form-item>
        <el-form-item label="广告素材要求:"
                      prop="adMaterial">
          <el-select v-model="editDialog.editForm.adMaterial"
                     class="length-1"
                     clearable>
            <el-option
              v-for="(item,index) in mapList.adMateria"
              :key="index"
              :value="item.key"
              :label="item.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="特色标签:"
                      prop="specialTag">
          <adplaceCheck :list="uniqueTagList"
                        :radiolist="radiolist"
                        :default="editDialog.editForm.specialTag"
                        @_getvalue="getSpecialTag"></adplaceCheck>
          <div class="font">
            不限、用户点击行为和用户资质为单选，其他标签可单独复选。
          </div>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="editDialog.show = false">
          取消
        </el-button>
        <el-button type="primary"
                   @click="submitEdit">
          保存
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import Api from '../../api/incomeApi/adplace'
  import adplaceCheck from './components/adplaceCheck'
  export default {
    components: {
      adplaceCheck,
    },
    data () {
      return {
        uniqueTagMap: {
          0: '不限',
          1: '小额极速',
          2: '芝麻分贷',
          3: '身份证贷',
          4: '大额分期',
          5: '公积金贷',
          6: '快速审批',
          7: '新品专区',
          8: '用户点击行为',
          9: '用户资质',
        },
        radiolist:[
          {'limitName': '用户点击行为', 'limitValue': 8},
          {'limitName': '用户资质', 'limitValue': 9},
        ],
        uniqueTagList: [
          {'limitName': '小额极速', 'limitValue': 1},
          {'limitName': '芝麻分贷', 'limitValue': 2},
          {'limitName': '身份证贷', 'limitValue': 3},
          {'limitName': '大额分期', 'limitValue': 4},
          {'limitName': '公积金贷', 'limitValue': 5},
          {'limitName': '快速审批', 'limitValue': 6},
          {'limitName': '新品专区', 'limitValue': 7},
          
        ], // 特色标签列表
        mapList: {
          cellSystemList: {
            1: 'android',
            2: 'ios',
          },
          blockTypeList: {
            0: '列表位',
            1: '硬广位',
          },
          productLineList: {
            1: '花钱无忧',
            2: '贷款王',
            5: '立即借',
          },
          adMateria: [
            {key: 1, value: '列表型'},
            {key: 2, value: '优惠券'},
            {key: 3, value: '开屏广告'},
            {key: 4, value: '首页弹窗'},
            {key: 5, value: '首页banner'},
          ],
          adMaterialMap: {
            1: '列表型',
            2: '优惠券',
            3: '开屏广告',
            4: '首页弹窗',
            5: '首页banner',
          },
        },
        upDialog: {
          fileList: [],
          show: false,
          upForm: {
            file: null,
          },
        },
        editDialog: {
          width: '130px',
          show: false,
          editForm: {
            id: '',
            adMaterial: '',
            specialTag: [0],
            productMax: '',
            productMin: '',
            // render
            adBlockId: '',
            adBlockName: '',
            productLine: '',
            cellSystem: '',
            classifyCode: '',
          },
          editRules: {
            adMaterial: [{ required: true, message: '请选择', trigger: 'blur' }],
            specialTag: [
              {
                required: true,
                trigger: 'blur',
                validator: (rule, value, callback) => {
                  if (!value.length) {
                    callback(new Error('请选择特色标签'))
                  } else {
                    callback()
                  }
                },
              }],
            productMax: [
              {
                required: true,
                trigger: 'blur',
                validator: (rule, value, callback) => {
                  if (value === '') {
                    callback(new Error('请填写1~999之间的整数'))
                  } else if (!/^[0-9]*[1-9][0-9]*$/.test(value)) {
                    callback(new Error('请填写1~999之间的整数'))
                  } else if (value > 999 || value < 1) {
                    callback(new Error('请填写1~999之间的整数'))
                  } else {
                    callback()
                  }
                },
              },
            ],
            productMin: [
              {
                required: true,
                trigger: 'blur',
                validator: (rule, value, callback) => {
                  if (value === '') {
                    callback(new Error('请填写1~999之间的整数'))
                  } else if (!/^[0-9]*[1-9][0-9]*$/.test(value) && !(value < 1000)) {
                    callback(new Error('请填写1~999之间的整数'))
                  } else if (value > 999 || value < 1) {
                    callback(new Error('请填写1~999之间的整数'))
                  } else {
                    callback()
                  }
                },
              },
            ],
          },
        },
        classifyCode: '9',
        uploading: false,
        listLoading: false,
        fileList: [],
        queryForm: {
          adBlockId: '',
          cellSystem: '',
          productLine: '',
        },
        tableHeight: 800,
        tableData: [
        ],
      }
    },
    computed: {

    },
    created () {
      this.fetchData()
    },
    mounted () {
      this.handleResize()
    },
    destroyed () {
      window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      // 操作编辑-获取特色标签数据
      getSpecialTag (value) {
        // console.log(value)
        
        this.editDialog.editForm.specialTag = value
      },
      handleClearFiles () {
        this.upDialog.upForm.file = null
        this.upDialog.fileList = []
      },
      uploadDialog () {
        this.upDialog.show = true
      },
      handleUploadChange (file) {
        this.handleClearFiles()
        this.upDialog.fileList = [file]
        this.upDialog.upForm.file = file.raw
      },
      async submitFile () {
        if (!this.upDialog.upForm.file) return this.$message.error('请先选择文件')
        let param = new window.FormData()
        param.append('file', this.upDialog.upForm.file)
        let res = await Api.fethchFile(param)
        if (res.data.respCode === '1000') {
          this.$_message.success('操作成功')
          this.upDialog.show = false
          this.fetchData()
        } else {
          this.$_message.error(res.data.respMsg)
        }
      },
      edit (row) {
        let specialTag = [0]
        specialTag = row.specialTag.split(',').map((v) => Number(v))
        this.editDialog.editForm = {...row, specialTag: specialTag}
        this.editDialog.show = true
      },
      submitEdit () {
        this.$refs['addForm'].validate(async (valid) => {
          if (!valid) {
            return false
          }
          const data = {
            adMaterial: this.editDialog.editForm.adMaterial,
            id: this.editDialog.editForm.id,
            productMax: this.editDialog.editForm.productMax,
            productMin: this.editDialog.editForm.productMin,
            specialTag: this.editDialog.editForm.specialTag.join(','),
            classifyCode:this.editDialog.editForm.classifyCode,
            productLine:this.editDialog.editForm.productLine,
            cellSystem:this.editDialog.editForm.cellSystem,
          }
          let res = await Api.updateAdBlock(data)
          if (res.data.respCode === '1000') {
            this.editDialog.show = false
            this.fetchData()
            this.$_message.success('操作成功')
          } else {
            this.$_message.error(res.data.respMsg)
          }
        })
      },
      closeUp () {
        this.$refs.uploadFile && this.$refs.uploadFile.clearFiles()
        this.handleClearFiles()
      },
      // 提交排序
      async submitSort () {
        let sort = this.tableData.map((v) => Number(v.priority))
        for (let i = 0; i < sort.length; i++) {
          if (sort[i] > 127 || sort[i] < 1) {
            this.$message.warning(`优先级数字请填写1~127`)
            return
          }
        }
        // let nary = sort.sort()
        // for (let i = 0; i < sort.length; i++) {
        //   if (nary[i] === nary[i + 1]) {
        //     this.$message.warning(`优先级数字不能重复`)
        //     return
        //   }
        // }
        let confirm = await this.$confirm(`确定提交排序吗?`, '提示', { type: 'warning' })
        if (confirm) {
          this.sortVerification()
        }
      },
      async sortVerification () {
        let adBlockList = this.tableData.map((t, i) => ({id: t.id,
            priority: t.priority,
            productLine: t.productLine,
            cellSystem: t.cellSystem,
            adBlockId: t.adBlockId,
          }))

        // let data = {
        //   adBlockListVO: adBlockList
        // }
        let res = await Api.adjustPriority(adBlockList)
        if (res.data.respCode === '1000') {
          this.$_message.success('操作成功')
          this.fetchData()
        } else {
          this.$_message.error(res.data.respMsg)
        }
      },
      handleResize () {
        this.$nextTick(() => {
          let h = document.documentElement.clientHeight
          this.tableMaxHeight = h - 160
        // this.tableMaxHeight = h - 230
        })
      },
      async fetchData () {
        this.listLoading = true
        let res = await Api.list(this.queryForm)
        this.listLoading = false
        if (res.data.respCode === '1000') {
          res.data.body.forEach((t) => {
            t.specialTagArr = t.specialTag.split(',').map(Number)
          })
          this.tableData = res.data.body
        }
      },
    },
  }
</script>

<style lang='scss' scoped>
.font{
      color: #999999
    }
.length-1 {
      width: 190px;
    }
</style>