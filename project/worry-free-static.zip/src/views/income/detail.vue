<!--定时任务-->
<template>
  <div>
    <div>
      <el-form :inline="true" :model="queryForm" size="mini" class="margin-mini">
        <el-form-item label="日期">
         <el-date-picker
            style="width:305px"
            v-model="time"
            type="daterange"
            range-separator="至"
            :clearable="false"
            start-placeholder="开始日期"
            value-format="yyyy-MM-dd"
            end-placeholder="结束日期">
          </el-date-picker>
       </el-form-item>
       <el-form-item label="甲方产品:">
         <el-input v-model="queryForm.productName" style="width:120px" @keyup.native.enter="fetchData()" placeholder="支持模糊查询"></el-input>
       </el-form-item>
       <el-form-item label="链接类型">
         <el-input v-model="queryForm.linkType" @keyup.native.enter="fetchData()"> </el-input>
       </el-form-item>
       <el-form-item label="产品线">
         <el-select style="width:120px" v-model="queryForm.productLine" filterable clearable>
           <el-option value="" label="不限">不限</el-option>
            <el-option
            v-for="(value,key,index) in selectList.productLineList"
            :key="index"
            :label="value"
            :value="key"
            >
            {{value}}
            </el-option>
          </el-select>
       </el-form-item>
       <el-form-item label="商务负责人">
         <el-select v-model="queryForm.businessPrincipalId" style="width:120px" filterable clearable>
            <el-option value="" label="不限">不限</el-option>
            <el-option
            v-for="(item,index) in selectList.facilitatorList"
            :key="index"
            :label="item.value"
            :value="item.key" 
            >
            {{item.value}}
            </el-option>
          </el-select>
       </el-form-item>
       <el-form-item label="客户名称">
         <el-input v-model="queryForm.advertiserName" @keyup.native.enter="fetchData()" placeholder="支持模糊查询"> </el-input>
       </el-form-item>
       <el-form-item label="收入">
         <el-select v-model="queryForm.estimateIncome" style="width:120px" filterable clearable placeholder="不限">
           <el-option value="" label="不限">不限</el-option>
            <el-option
            v-for="(value,key,index) in selectList.estimateIncomeList"
            :key="index"
            :label="value"
            :value="key"
            >
            {{value}}
            </el-option>
          </el-select>
       </el-form-item>
       <el-form-item label="结算方式">
         <el-select style="width:120px" v-model="queryForm.settlementMode" filterable clearable multiple placeholder="不限">
           <!-- <el-option value="" label="不限">不限</el-option> -->
            <el-option
            v-for="(value,key,index) in selectList.settlementModeList"
            :key="index"
            :label="value"
            :value="key"
            >
            {{value}}
            </el-option>
          </el-select>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="fetchData()" class="least">查询</el-button>
        <el-button type="primary" size="mini" @click="down" class="least" :loading="downLoading">导出</el-button>
        <el-button type="primary" size="mini" @click="updateList" class="least" v-if="tabButtonPerms['raiseReport']">提报</el-button>
      </el-form-item>
    </el-form>
    </div>
    <!--表格-->
    <!-- show-summary
      :summary-method="getSummaries" -->
    <el-table
      @sort-change = "changeSort"
      v-loading="tableLoading" 
      :data="tableData"
      border fit
      highlight-current-row
      stripe
      :max-height="tableMaxHeight"
      show-summary
      :summary-method="getSummaries"
      style="width:100%"
      >
      <el-table-column
        prop="reportDate"
        label="日期"
        :fixed = "tableData.length>0"
        min-width="80"
        sortable = "custom"
        >
      </el-table-column>
      <el-table-column
        :key="1"
        prop="productName"
        label="甲方产品"
        :fixed = "tableData.length>0"
        min-width="100"
        sortable = "custom"
        >
        <template slot-scope="scope">
          <div>
            <el-popover
            placement="right"
            width="320"
            trigger="hover">
            <template>
              <div style="margin-bottom:10px">甲方产品: {{hoverRow.productName}}</div>
                <el-table :data="gridData" stripe border :show-header="false" width="100%">
                  <el-table-column  prop="name" label=""></el-table-column>
                  <el-table-column  prop="value" label=""></el-table-column>
                </el-table>
            </template>
            <i slot="reference" class="el-icon-info" @mouseenter="fetchDetail(scope.row)"></i>
          </el-popover>
            <span slot="reference" class="" @click="openEditDialog">{{scope.row.productName}}</span>
          </div>
         
        </template>
      </el-table-column>

      <el-table-column
        :key="2"
        prop="linkType"
        label="链接类型"
        :fixed = "tableData.length>0"
        min-width="75"
        >
      </el-table-column>
      
      <el-table-column
        prop="clickUv"
        label="点击UV"
        min-width="80"
      >
      <template slot-scope="scope">
        <template v-if="!tabButtonPerms['newUpdate']">
          <span>{{scope.row.clickUv}}</span>
        </template>
        <template v-else>
          <div v-show="!scope.row.clickUvView" @dblclick="edit(scope.row,'clickUvView','clickUv')"><span >{{ scope.row.clickUv}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
          <div v-show="scope.row.clickUvView"><el-input v-model="scope.row.clickUv" size="mini" @blur="blurInput(scope.row,'clickUvView','clickUv')" :ref="'clickUv'+scope.row.id"  :id="'clickUv'+scope.row.id"> </el-input></div>
        </template>
      </template>
      </el-table-column>

      <el-table-column
        prop="settlementMode"
        label="结算方式"
        min-width="110"
      >
      <template slot-scope="scope">
        <template v-if="!tabButtonPerms['newUpdate']">
          <span> {{selectList.settlementModeList[scope.row.settlementMode] }}</span>
        </template>
        <template v-else>
          <div v-show="!scope.row.settlementModeView" @dblclick="edit(scope.row,'settlementModeView','settlementMode')"><span >{{selectList.settlementModeList[scope.row.settlementMode] }}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
          <div v-show="scope.row.settlementModeView">
          <!-- <el-input v-model="scope.row.clickUv" size="mini" @blur="blurInput(scope.row,'settlementModeView','clickUv')"  :id="'settlementMode'+scope.row.id"> 
          </el-input> -->
          <el-select style="width:100px" v-model="scope.row.settlementMode" filterable  placeholder="不限" size="mini" @change="blurInput(scope.row,'settlementModeView','settlementMode')">
            <el-option
            v-for="(value,key,index) in selectList.settlementModeList"
            :key="index"
            :label="value"
            :value="key"
            >
            {{value}}
            </el-option>
          </el-select>
          </div>
        </template>
      </template>
      </el-table-column>

      <el-table-column
        prop="unitPrice"
        label="单价"
        min-width="80"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.raiseReport === 1 || !tabButtonPerms['newUpdate'] || scope.row.settlementMode === '7' || scope.row.settlementMode === '8'">
          <span :class="{ isRed: scope.row.ladderPrice === 1 }">{{scope.row.unitPrice}}</span>
        </template>
        <template v-else>
          <div v-show="!scope.row.unitPriceView " @dblclick="edit(scope.row,'unitPriceView','unitPrice')"><span :class="{ isRed: scope.row.ladderPrice === 1 }">{{ scope.row.unitPrice}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-show="scope.row.unitPriceView"><el-input v-model="scope.row.unitPrice" size="mini" @blur="blurInput(scope.row,'unitPriceView','unitPrice')" :ref="'unitPrice'+scope.row.id"  :id="'unitPrice'+scope.row.id"> </el-input></div>
        </template>
      </template>
      </el-table-column>

      <el-table-column
        prop="firstLoanSharing"
        label="首贷分成"
        min-width="90"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.raiseReport === 1 || !tabButtonPerms['updateCalcProperties'] || (scope.row.settlementMode !== '0' && scope.row.settlementMode !== '7' && scope.row.settlementMode !== '8')">
          <span :class="{ isRed: scope.row.ladderPrice === 1 }">{{scope.row.firstLoanSharingName}}</span>
        </template>
        <template v-else>
          <div v-show="!scope.row.firstLoanSharingView " @dblclick="edit(scope.row,'firstLoanSharingView','firstLoanSharing')"><span :class="{ isRed: scope.row.ladderPrice === 1 }">{{ scope.row.firstLoanSharingName}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-show="scope.row.firstLoanSharingView"><el-input v-model="scope.row.firstLoanSharing" size="mini" @blur="blurInput(scope.row,'firstLoanSharingView','firstLoanSharing')" :ref="'firstLoanSharing'+scope.row.id" :id="'firstLoanSharing'+scope.row.id"> </el-input></div>
        </template>
      </template>
      </el-table-column>

      <el-table-column
        prop="reloanSharing"
        label="复贷分成"
        min-width="70"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.raiseReport === 1 || !tabButtonPerms['updateCalcProperties'] || (scope.row.settlementMode !== '8' && scope.row.settlementMode !== '0')">
          <span :class="{ isRed: scope.row.ladderPrice === 1 }">{{scope.row.reloanSharingName}}</span>
        </template>
        <template v-else>
          <div v-show="!scope.row.reloanSharingView " @dblclick="edit(scope.row,'reloanSharingView','reloanSharing')"><span :class="{ isRed: scope.row.ladderPrice === 1 }">{{ scope.row.reloanSharingName}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-show="scope.row.reloanSharingView"><el-input v-model="scope.row.reloanSharing" size="mini" @blur="blurInput(scope.row,'reloanSharingView','reloanSharing')" :ref="'reloanSharing'+scope.row.id" :id="'reloanSharing'+scope.row.id"> </el-input></div>
        </template>
      </template>
      </el-table-column>

      <el-table-column
        prop="registerNum"
        label="注册"
        min-width="110"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.raiseReport === 1 || !tabButtonPerms['updateCalcProperties']">
          <span>{{scope.row.registerNum}}</span>
        </template>
        <template v-else>
          <div v-show="!scope.row.registerNumView " @dblclick="edit(scope.row,'registerNumView','registerNum')"><span>{{ scope.row.registerNum}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-show="scope.row.registerNumView"><el-input v-model.number="scope.row.registerNum" size="mini" @blur="blurInput(scope.row,'registerNumView','registerNum')" :ref="'registerNum'+scope.row.id" :id="'registerNum'+scope.row.id"> </el-input></div>
        </template>
      </template>
      </el-table-column>
      <el-table-column
        prop="applyNum"
        label="申请"
        min-width="60"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.raiseReport === 1 || !tabButtonPerms['updateCalcProperties']">
          <span>{{scope.row.applyNum}}</span>
        </template>
        <template v-else>
          <div v-show="!scope.row.applyNumView " @dblclick="edit(scope.row,'applyNumView','applyNum')"><span>{{ scope.row.applyNum}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-show="scope.row.applyNumView"><el-input v-model.number="scope.row.applyNum" size="mini" @blur="blurInput(scope.row,'applyNumView','applyNum')" :ref="'applyNum'+scope.row.id" :id="'applyNum'+scope.row.id"> </el-input></div>
        </template>
      </template>
      </el-table-column>
      <el-table-column
        :key="3"
        prop="openAccountNum"
        label="开户"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.raiseReport === 1 || !tabButtonPerms['updateCalcProperties']">
          <span>{{scope.row.openAccountNum}}</span>
        </template>
        <template v-else>
          <div v-show="!scope.row.openAccountNumView " @dblclick="edit(scope.row,'openAccountNumView','openAccountNum')"><span>{{ scope.row.openAccountNum}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-show="scope.row.openAccountNumView"><el-input v-model="scope.row.openAccountNum" size="mini" @blur="blurInput(scope.row,'openAccountNumView','openAccountNum')" :ref="'openAccountNum'+scope.row.id" :id="'openAccountNum'+scope.row.id"> </el-input></div>
        </template>
      </template>
      </el-table-column>
      <el-table-column
        prop="toUseNum"
        label="动用"
        min-width="60"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.raiseReport === 1 || !tabButtonPerms['updateCalcProperties']">
          <span>{{scope.row.toUseNum}}</span>
        </template>
        <template v-else>
          <div v-show="!scope.row.toUseNumView " @dblclick="edit(scope.row,'toUseNumView','toUseNum')"><span>{{ scope.row.toUseNum}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-show="scope.row.toUseNumView"><el-input v-model="scope.row.toUseNum" size="mini" @blur="blurInput(scope.row,'toUseNumView','toUseNum')" :ref="'toUseNum'+scope.row.id" :id="'toUseNum'+scope.row.id"> </el-input></div>
        </template>
      </template>
      </el-table-column>
      <el-table-column
        prop="firstLoanAmount"
        label="首贷放款额"
        min-width="60"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.raiseReport === 1 || !tabButtonPerms['updateCalcProperties'] || (scope.row.settlementMode !== '0'&&scope.row.settlementMode !== '7' && scope.row.settlementMode !== '8')">
          <span >{{scope.row.firstLoanAmount}}</span>
        </template>
        <template v-else>
          <div v-show="!scope.row.firstLoanAmountView " @dblclick="edit(scope.row,'firstLoanAmountView','firstLoanAmount')"><span >{{ scope.row.firstLoanAmount}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-show="scope.row.firstLoanAmountView"><el-input v-model="scope.row.firstLoanAmount" size="mini" @blur="blurInput(scope.row,'firstLoanAmountView','firstLoanAmount')" :ref="'firstLoanAmount'+scope.row.id" :id="'firstLoanAmount'+scope.row.id"> </el-input></div>
        </template>
      </template>
      </el-table-column>
      <el-table-column
        prop="reloanAmount"
        label="复贷放款额"
        min-width="60"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.raiseReport === 1 || !tabButtonPerms['updateCalcProperties'] || (scope.row.settlementMode !== '8' && scope.row.settlementMode !== '0')">
          <span >{{scope.row.reloanAmount}}</span>
        </template>
        <template v-else>
          <div v-show="!scope.row.reloanAmountView " @dblclick="edit(scope.row,'reloanAmountView','reloanAmount')"><span >{{ scope.row.reloanAmount}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-show="scope.row.reloanAmountView"><el-input v-model="scope.row.reloanAmount" size="mini" @blur="blurInput(scope.row,'reloanAmountView','reloanAmount')" :ref="'reloanAmount'+scope.row.id" :id="'reloanAmount'+scope.row.id"> </el-input></div>
        </template>
      </template>
      </el-table-column>
      <!-- (0:否,1:是) -->
      <el-table-column
        prop="calcDayCpt"
        label="CPT当天是否结算"
        min-width="60"
      >
      <template slot-scope="scope">
        <!-- <template v-if="scope.row.raiseReport === 1 || !tabButtonPerms['updateCalcProperties'] || scope.row.settlementMode !== '5'">
          <span>{{selectList.calcDayCptList[scope.row.calcDayCpt]}}</span>
        </template>
        <template v-else>
          <div v-show="!scope.row.calcDayCptView" @dblclick="edit(scope.row,'calcDayCptView','calcDayCptName')"><span>{{selectList.calcDayCptList[scope.row.calcDayCpt]}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-show="scope.row.calcDayCptView"><el-input v-model="scope.row.calcDayCptName" size="mini" @blur="blurInput(scope.row,'calcDayCptView','calcDayCptName')" :ref="'calcDayCptName'+scope.row.id" :id="'calcDayCptName'+scope.row.id"> </el-input></div>
        </template> -->
        <!-- 改为下拉 -->
        <template v-if="scope.row.raiseReport === 1 || !tabButtonPerms['updateCalcProperties'] || scope.row.settlementMode !== '5'">
          <span>{{selectList.calcDayCptList[scope.row.calcDayCpt]}}</span>
        </template>
        <template v-else>
          <div v-show="!scope.row.calcDayCptView" @dblclick="edit(scope.row,'calcDayCptView','calcDayCpt')"><span >{{selectList.calcDayCptList[scope.row.calcDayCpt]}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
          <div v-show="scope.row.calcDayCptView">
          <!-- <el-input v-model="scope.row.clickUv" size="mini" @blur="blurInput(scope.row,'settlementModeView','clickUv')"  :id="'settlementMode'+scope.row.id"> 
          </el-input> -->
          <el-select style="width:60px" v-model="scope.row.calcDayCpt"  clearable placeholder="" size="mini" @change="blurInput(scope.row,'calcDayCptView','calcDayCpt')">
            <el-option
            v-for="(value,key,index) in selectList.calcDayCptList"
            :key="index"
            :label="value"
            :value="key"
            >
            {{value}}
            </el-option>
          </el-select>
          </div>
        </template>
      </template>
      <!-- <template slot-scope="scope">
        <span>{{selectList.calcDayCptList[scope.row.calcDayCpt] || '--'}}</span>
      </template> -->
      </el-table-column>
      <el-table-column
        prop="incomeAmount"
        label="收入"
        min-width="60"
        sortable = "custom"
      >
      <template slot-scope="scope">
        <span :class="{ isRed: scope.row.estimateIncome === 1 }">  
          {{ scope.row.incomeAmount}}
        </span>
      </template>
      </el-table-column>
      <el-table-column
        prop="clickArpu"
        label="点击ARPU"
        min-width="60"
      >
      <template slot-scope="scope">
        <span v-if="scope.row.clickUv === 0"> -- </span>
        <span v-if="scope.row.clickUv !== 0">{{scope.row.clickArpu}}</span>
      </template>
      </el-table-column>、
      <el-table-column
        prop="uvaConversionRate"
        label="UV-A转化率"
        min-width="60"
      >
      <template slot-scope="scope">
        <!-- <span v-if="scope.row.clickUv === 0">
          {{'--'}}
        </span> -->
        <span>
          {{scope.row.uvaConversionRate}}
        </span> 
      </template>
      </el-table-column>
      <!-- (0:未提报,1:已提报) -->
      <el-table-column
        prop="businessPrincipalName"
        label="商务负责人"
        min-width="80"
        >
      </el-table-column>
      <el-table-column
        prop="productClickUv"
        label="产品点击UV"
        min-width="110"
      >
      </el-table-column>
      <el-table-column
        prop="advertiserName"
        label="客户名称"
        min-width="110"
      >
      </el-table-column>
      <el-table-column
        prop="advertiserId"
        label="客户ID"
        min-width="110"
      >
      </el-table-column>
      <el-table-column
        prop="productId"
        label="产品ID"
        min-width="110"
      >
      </el-table-column>
      <el-table-column  prop="mark" label="备注" min-width="80">
            <template slot-scope="scope">
              <template v-if="!tabButtonPerms['updateCalcProperties']">
                <span >{{scope.row.remark}}</span>
              </template>
              <template v-else>
                <div v-show="!scope.row.remarkView " @dblclick="edit(scope.row,'remarkView','remark')"><span >{{ scope.row.remark}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
                <div v-show="scope.row.remarkView"><el-input v-model="scope.row.remark" size="mini" @blur="updateProperties(scope.row,'remarkView','remark')" :ref="'remark'+scope.row.id" :id="'remark'+scope.row.id"> </el-input></div>
              </template>
            </template>
          </el-table-column>
      <el-table-column
        prop="raiseReport"
        label="提报"
        min-width="60"
        :render-header="renderCheck"
      >
      <template slot-scope="scope"> 
        <el-checkbox v-model="scope.row.statusView" v-if="scope.row.raiseReport === 0 && scope.row.estimateIncome === 0" @change="changeStatus"> </el-checkbox>
      </template>
      </el-table-column>
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>

  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'
import detailApi from '../../api/incomeApi/detailApi.js'
import commonApi from '../../api/incomeApi/common.js'
import renderHead from '../../components/renderHead/renderHead.vue'
import Moment from 'moment'
export default {
  components: {
    VueElTooltip,
    renderHead
  },
  data () {
    return {
      tabButtonPerms: {
        'raiseReport': false,
        'updateCalcProperties': false,
        'newUpdate': false
      },
      tempContent: null,
      parentCheck: false,
      checked: false,
      timer: null,
      downLoading: false,
      centerDialogVisible: true,
      status: '已生成文件',
      tableLoading: false,
      isclick: false,
      hoverWidth: '300',
      editDialog: false,
      hoverRow: {},
      incomeStatementTotal: {
        advertiserId: 'null',
        advertiserName: 'null',
        applyNum: 'null',
        businessPrincipalId: 'null',
        businessPrincipalName: 'null',
        calcDayCpt: 'null',
        clickArpu: 'null',
        clickUv: 'null',
        durationEnd: 'null',
        durationStart: 'null',
        durationType: 'null',
        estimateIncome: 'null',
        firstLoanAmount: 'null',
        firstLoanSharing: 'null',
        id: 'null',
        incomeAmount: 'null',
        ladderPrice: 'null',
        linkId: 'null',
        linkType: 'null',
        openAccountNum: 'null',
        productClickUv: 'null',
        productId: 'null',
        productLimitEnd: 'null',
        productLimitStart: 'null',
        productName: 'null',
        productStatus: 'null',
        raiseReport: 'null',
        rateEnd: 'null',
        rateStart: 'null',
        rateType: 'null',
        registerNum: 'null',
        reloanAmount: 'null',
        reloanSharing: 'null',
        reportDate: 'null',
        settlementMode: 'null',
        toUseNum: 'null',
        unitPrice: 'null',
        uvaConversionRate: 'null'
      },
      gridData: [
        {'name': '广告主', value: ''},
        {'name': '额度', value: ''},
        {'name': '期限', value: ''},
        {'name': '息费', value: ''},
        {'name': '产品状态', value: ''}
      ],
      time: [],
      queryForm: {
        estimateIncome: '',
        advertiserName: '',
        businessPrincipalId: '',
        linkType: '',
        endDate: '',
        startDate: '',
        productLine: '',
        productName: '',
        settlementMode: []

      },
      selectList: {
        estimateIncomeList: {
          0: '非预估收入',
          1: '预估收入'
        },
        productLineList: {
          1: '花钱无忧',
          2: '贷款王',
          3: '导流平台',
          5: '立即借'
        },
        calcDayCptList: {
          0: '否',
          1: '是'
        },
        settlementModeList: {
          1: 'CPA注册',
          2: 'CPA申请',
          3: 'CPK开户',
          4: 'CPL动用',
          5: 'CPT包日',
          6: '点击UV',
          7: 'CPS首贷分成',
          8: 'CPS首贷+复贷分成'
        }
      },
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [30, 50, 100],
        pageSize: 30, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [
        { // 这样的js注释吗
          // 'applyNum': 31238,
          // 'calcDayCpt': 16427,
          // 'clickArpu': 48237,
          // 'firstLoanAmount': 32101,
          // 'firstLoanSharing': 38487,
          // 'openAccountNum': 37385,
          // 'registerNum': 15304,
          // 'reloanAmount': 37876,
          // 'reloanSharing': 18467,
          // 'toUseNum': 31725,
          // 'uvaConversionRate': 53002,
          // 'advertiserId': 1,
          // 'advertiserName': '测试广告主',
          // 'businessPrincipalId': 1,
          // 'businessPrincipalName': '测试商务负责人',
          // 'clickUv': 20,
          // 'durationEnd': 100,
          // 'durationStart': 2,
          // 'durationType': 1,
          // 'estimateIncome': 1,
          // statusView: false,
          // 'id': 1,
          // 'incomeAmount': 0,
          // 'ladderPrice': 0,
          // 'linkId': 1,
          // 'linkType': '花钱无忧',
          // 'productClickUv': 30,
          // 'productId': 231,
          // 'productLimitEnd': 20,
          // 'productLimitStart': 3,
          // 'productName': '百度有钱花',
          // 'productStatus': 1,
          // 'raiseReport': 0,
          // 'rateEnd': 0,
          // 'rateStart': 0,
          // 'rateType': 1,
          // 'reportDate': '2018-11-08',
          // 'settlementMode': '1',
          // 'unitPrice': 12,
          // clickUvView: false,
          // settlementModeView: false
        }
      ],
      sortOrder: {
        'reportDate': 1,
        'productName': 2,
        'incomeAmount': 3
      },
      sortObj: {

      },
      listLoading: false
    }
  },
  created () {
    let temp = new Date().getTime() - 3600 * 1000 * 24
    let start = Moment(temp).format('YYYY-MM-DD')
    this.time = [start, start]
    // this.time = ['2018-8-13', '2018-12-31']
    this.getDic()
    this.fetchData()
    const btnKeys = ['raiseReport', 'updateCalcProperties', 'newUpdate']
    btnKeys.forEach(t => {
      this.$store.state.loginUser.tabButtonPerms.forEach(j => {
        if (t === j) {
          this.tabButtonPerms[t] = true
        }
      })
    })
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {
  },
  watch: {
  },
  directives: {
    focus: {
      inserted: function (el, {value}) {
        if (value) {
          el.focus()
        }
      }
    }
  },
  methods: {
    changeSort (a) {
      let val = null
      if (a['order'] === 'ascending') val = 1
      if (a['order'] === 'descending') val = 2
      let data = {

      }
      if (a) {
        data['sortField'] = this.sortOrder[a['prop']]
        data['sortOrder'] = val
      }
      if (!a['order']) { data = null }
      this.sortObj = data
      this.fetchData()
    },
    async updateProperties (row, type, content) {
      let data = {
        id: row.id
      }
      data[content] = row[content]
      let res = await detailApi.updateProperties(data)
      if (res.data.code === '0') {
        this.$_message({
          showClose: true,
          message: '操作成功',
          type: 'success'
        })
        this.fetchData()
      } else {
        this.$_message.error(res.data.message)
      }
    },
    async blurInput (row, type, content) {
      let data = {
        id: row.id,
        applyNum: row.applyNum,
        calcDayCpt: row.calcDayCpt,
        firstLoanAmount: row.firstLoanAmount,
        firstLoanSharing: row.firstLoanSharing,
        openAccountNum: row.openAccountNum,
        registerNum: row.registerNum,
        reloanAmount: row.reloanAmount,
        reloanSharing: row.reloanSharing,
        toUseNum: row.toUseNum,
        unitPrice: row.unitPrice,
        clickUv: row.clickUv,
        settlementMode: row.settlementMode
      }
      data[content] = row[content]
      console.log(content, data[content])
      if (content === 'clickUv') {
        console.log('clickUV', data[content])
        // data[content] = Number(data[content])
        if (data[content] === '' || data[content] === null) {
          return this.$_message.error('不能为空')
        }
        // data.unitPrice = row.unitPrice
        if (!/^(-)?\d+(\.\d+)?$/.test(data[content])) {
          return this.$_message.error('请输入数字')
        }
      }
      if (content === 'firstLoanSharing' || content === 'reloanSharing') {
        // data.unitPrice = row.unitPrice
        if (!/^(-)?\d+(\.\d+)?$/.test(data[content])) {
          return this.$_message.error('请输入数字')
        }
      }
      // if (content === 'calcDayCptName') {
      //   if (row.calcDayCptName !== '是' && row.calcDayCptName !== '否' && row.calcDayCptName !== '' && row.calcDayCptName !== null) {
      //     return this.$_message.error('请输入“是” 或 “否”，或者不填')
      //   } else {
      //     if (row[content] === '是') {
      //       data.calcDayCpt = 1
      //     } else if (row[content] === '否') {
      //       data.calcDayCpt = 0
      //     } else {
      //       data.calcDayCpt = ''
      //     }
      //   }
      // }
      if (content === 'toUseNum' || content === 'registerNum' || content === 'openAccountNum' || content === 'applyNum') {
        if (!/^(0|[1-9][0-9]*)$/.test(data[content]) && data[content] !== '' && data[content] !== null) {
          return this.$_message.error('请输入大于等于0的整数，或者不填')
        }
      }
      if (content === 'reloanAmount' || content === 'firstLoanAmount') {
        if (!/^(-)?\d+(\.\d+)?$/.test(data[content]) && data[content] !== '' && data[content] !== null) {
          return this.$_message.error('请输入数字，或者不填')
        }
      }
      if (content === 'unitPrice') {
        // data[content] = Number(data[content])
        console.log(data[content])
        // data.unitPrice = row.unitPrice
        if (!/^(-)?\d+(\.\d+)?$/.test(data[content])) {
          return this.$_message.error('请输入数字')
        }
      }

      // console.log(data)
      let res = await detailApi.updateCalcProperties(data)
      if (res.data.code === '0') {
        this.$_message({
          showClose: true,
          message: '操作成功',
          type: 'success'
        })
        this.fetchData()
      } else {
        this.$_message.error(res.data.message)
      }
    },

    edit (row, type, content) {
      this.tempContent = row[content]
      row[type] = true
      this.$nextTick(() => {
        let str = content + row.id
        if (content !== 'calcDayCpt' && content !== 'settlementMode') {
          document.getElementById(str).focus()
        }
        // this.$refs[content + row.id].focus() //这么写能实现功能，但有bug
      })
    },
    async updateList () {
      let filterArr = this.tableData.filter(item => {
        return item.raiseReport === 0 && item.estimateIncome === 0
      })
      let ids = []
      filterArr.forEach(t => {
        if (t.statusView === true) {
          ids.push(t.id)
        }
      })
      if (ids.length === 0) {
        return this.$_message.warning('请至少勾选一条记录！')
      }
      let data = {
        ids: ids.join(',')
      }
      try {
        let confirm = await this.$confirm(`提报成功后，数据不能修改，请确认是否提报!`, '提示', { type: 'warning' })
        if (confirm) {
          let res = await detailApi.raiseReport(data)
          if (res.data.code === '0') {
            this.$_message.success('提报成功')
            this.fetchData()
          } else {
            this.$_message.error(res.data.respMsg)
          }
        }
      } catch (error) {
        // this.$_message.warning('')
      }
    },
    changeStatus (val) {
      let filterArr = this.tableData.filter(item => {
        return item.raiseReport === 0 && item.estimateIncome === 0
      })
      console.log(filterArr)
      let parentCheck = true
      filterArr.forEach(t => {
        if (t.statusView === false) {
          parentCheck = false
        }
      })
      this.parentCheck = parentCheck
    },
    async getDic () {
      let res = await commonApi.getDic(2)
      if (res.data.code === '0') {
        this.selectList.facilitatorList = res.data.data
      }
    },
    submitAdv () {
      window.alert('1')
    },
    batchChange () {
      this.batchDialog.show = true
    },
    closeAdd () {
      this.$refs.addForm.resetFields()
    },
    add () {
      this.addAdvDialog.show = true
    },
    async down () {
      let data = {
        ...this.queryForm,
        startDate: this.time[0] || '',
        endDate: this.time[1] || ''
      }
      window.location.href = process.env.BASE_API + `/incomeStatement/export?businessPrincipalId=${data.businessPrincipalId}&linkType=${data.linkType}&productLine=${data.productLine}&productName=${data.productName}&settlementMode=${data.settlementMode}&startDate=${data.startDate}&endDate=${data.endDate}&advertiserName=${data.advertiserName}&estimateIncome=${data.estimateIncome}`
    },
    async fetchDetail (val) {
      this.hoverRow = val
      let str1 = ''
      let str2 = ''
      let str2Type = val.durationType === 0 ? '每日' : '每月'
      let str3 = val.rateStart === val.rateEnd ? val.rateStart + '%' : val.rateStart + '%' + '~' + val.rateEnd + '%'
      let str3Type = val.rateType === 0 ? '每日' : '每月'
      if (val.productLimitEnd === val.productLimitStart) {
        str1 = val.productLimitEnd || val.productLimitEnd
      } else {
        str1 = `${val.productLimitStart}~${val.productLimitEnd}`
      }

      if (val.durationStart === val.durationEnd) {
        str2 = val.durationStart
      } else {
        str2 = `${val.durationStart}~${val.durationEnd}`
      }
      this.gridData = [
        {'name': '广告主', value: val.advertiserName},
        {'name': '额度', value: str1},
        {'name': '期限', value: str2 + str2Type},
        {'name': '息费', value: str3 + str3Type},
        {'name': '产品状态', value: val.productStatus === 0 ? '停用' : '启用'}
      ]
    },
    toPercent (point) {
      if (point === 0) {
        return 0
      }
      if (point === null) {
        return ''
      }
      let str = parseFloat((point).toPrecision(12)) + ''
      // if (str.indexOf('.') < 0) {
      //   str = str + '.00'
      // } else {
      //   const ldot = str.indexOf('.')
      //   const type = str.substring(ldot + 1, str.length)
      //   if (type.length === 1) {
      //     str = str + '0'
      //   }
      // }
      return str + '%'
    },
    async fetchType () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await detailApi.type(data)
      if (res.data.code === '0') {
        let topArr = [{id: 0, typeName: '不限'}]
        this.selectList.typeList = topArr.concat(res.data.body.list)
      }
    },
    async fetchData () {
      try {
        this.tableLoading = true
        let data = {
          ...this.queryForm,
          startDate: this.time[0] || '',
          endDate: this.time[1] || '',
          pageNum: this.pagination.pageNo,
          pageSize: this.pagination.pageSize
        }
        data = {
          ...data,
          ...this.sortObj
        }
        let res = await detailApi.getList(data)
        if (res.data.code === '0') {
          this.tableLoading = false
          this.parentCheck = false
          this.pagination.total = res.data.data.incomeStatementList.total
          this.pagination.pageNo = res.data.data.incomeStatementList.pageNum
          res.data.data.incomeStatementList.list.forEach(t => {
            if (t.firstLoanSharing)t.firstLoanSharingName = t.firstLoanSharing + '%'
            if (t.reloanSharing)t.reloanSharingName = t.reloanSharing + '%'
            t.settlementMode = t.settlementMode + ''
            if (t.calcDayCpt === null) {
              t.calcDayCpt = ''
            } else {
              t.calcDayCpt = t.calcDayCpt + ''
            }
            t.statusView = false
            t.applyNumView = false
            t.firstLoanAmountView = false
            t.firstLoanSharingView = false
            t.openAccountNumView = false
            t.registerNumView = false
            t.reloanAmountView = false
            t.reloanSharingView = false
            t.toUseNumView = false
            t.unitPriceView = false
            t.calcDayCptView = false
            t.clickUvView = false
            t.settlementModeView = false
            t.remarkView = false
            // if (t.calcDayCpt === 0) t.calcDayCptName = '否'
            // if (t.calcDayCpt === 1) t.calcDayCptName = '是'
            // if (t.calcDayCpt !== 0 && !t.calcDayCpt) t.calcDayCptName = ''
            if (t.uvaConversionRate === null) {
              t.uvaConversionRate = ''
            } else if (t.uvaConversionRate === '--') {
              t.uvaConversionRate = '--'
            } else {
              t.uvaConversionRate = t.uvaConversionRate + '%'
            }
          })
          this.tableData = res.data.data.incomeStatementList.list
          if (res.data.data.incomeStatementTotal) {
            this.incomeStatementTotal = res.data.data.incomeStatementTotal
          }
          if (this.pagination.pageNo > 1 && this.tableData.length === 0) {
            this.pagination.pageNo = 1
            this.fetchData()
          }
        } else {
          this.tableLoading = false
        }
      } catch (error) {
        this.tableLoading = false
      }
    },
    formatNum (num) {
      // num = Number(num) / 100
      num = num.toFixed(2)
      return num
    },
    getSummaries (param) {
      // const { columns } = param
      // console.log(columns)
      const sums = []
      sums[0] = '汇总'
      sums[1] = '-'
      sums[2] = '-'
      sums[3] = this.incomeStatementTotal.clickUv
      sums[4] = '-'
      sums[5] = '-'
      sums[6] = '-'
      sums[7] = '-'
      sums[8] = this.incomeStatementTotal.registerNum
      sums[9] = this.incomeStatementTotal.applyNum
      sums[10] = this.incomeStatementTotal.openAccountNum
      sums[11] = this.incomeStatementTotal.toUseNum
      sums[12] = this.incomeStatementTotal.firstLoanAmount
      sums[13] = this.incomeStatementTotal.reloanAmount
      sums[14] = '-'
      sums[15] = this.incomeStatementTotal.incomeAmount
      sums[16] = this.incomeStatementTotal.clickArpu
      sums[17] = '-'
      sums[18] = '-'
      sums[19] = this.incomeStatementTotal.productClickUv
      sums[20] = '-'
      return sums
    },
    renderCheck (createElement, {column}) {
      return createElement(renderHead, {
        props: {
          checked: this.parentCheck
          // content: 'TABLE_TITLE_TIP[column.property]'

        },
        on: {
          'clickCheck': (a) => {
            this.parentCheck = a
            if (this.parentCheck) {
              let filterArr = this.tableData.filter(item => {
                return item.raiseReport === 0 && item.estimateIncome === 0
              })
              filterArr.forEach(t => {
                t.statusView = true
              })
            }
            if (!this.parentCheck) {
              let filterArr = this.tableData.filter(item => {
                return item.raiseReport === 0 && item.estimateIncome === 0
              })
              filterArr.forEach(t => {
                t.statusView = false
              })
            }
          }
        }
      })
    },
    openEditDialog () {
      this.hoverWidth = 150
      this.isclick = true
    },
    tableHover (val) {

    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label
          // content: TABLE_TITLE_TIP[column.property]
          // content: 'TABLE_TITLE_TIP[column.property]'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 135
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    },
    handleClearFiles () {
      this.ARPUfileList = []
      this.file = null
    },
    // 批量修改-上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
    handleUploadBefore (file) {
      if (file.name && file.name.length > 0) {
        const ldot = file.name.lastIndexOf('.')
        const type = file.name.toLowerCase().substring(ldot)
        if (type !== '.csv') {
          this.$_message.warning('目前只支持.csv格式的文件')
          return false
        }
        this.uploadFileName = file.name
        console.log(this.uploadFileName)
      }
    },
    // 批量修改-文件上传成功时的钩子
    handleUploadSuccess (response, file, fileList) {
      console.log('上传成功')
      this.uploadTagVisible = true
    },
    // 批量修改-文件上传失败时的钩子
    handleUploadError (err, file, fileList) {
      if (err.status === 404) {
        this.$_message.error('上传失败，网络连接异常!')
      } else {
        console.log(err)
        this.$_message.error('上传失败!')
      }
    },
    // 导入项目-文件上传时的钩子
    handleUploadProgress (event, file, fileList) {
      console.log('上传中...')
    },
    async handleUploadChange (file, fileList) {
      this.handleClearFiles()
      this.ARPUfileList = [file]
      this.uploadFileName = file.name
      this.file = file.raw
      // this.uploading = true
      // let param = new window.FormData()
      // param.append('file', this.file)
      // let res = await appApi.importValidation(param, data)
      // this.uploading = false
    },
    closeFile () {
      this.$refs.uploadFile && this.$refs.uploadFile.clearFiles()
      this.handleClearFiles()
    },
    async fetchUpload () {
      if (!this.file) return this.$_message.error('请先选择文件')
      this.uploading = true
      let param = new window.FormData()
      param.append('file', this.file)
      try {
        if (this.batchUploadDialog.type === 1) {
          let res = await detailApi.productArpuImport(param)
          if (res.data.code === '0') {
            this.$_message.success('上传成功')
            this.uploading = false
            this.getTableData()
            this.batchUploadDialog.show = false
          } else {
            this.$_message.error(res.data.message)
            this.uploading = false
          }
        }
        if (this.batchUploadDialog.type === 2) {
          let res = await detailApi.productUvClickLimitImport(param)
          if (res.data.code === '0') {
            this.$_message.success('上传成功')
            this.uploading = false
            this.getTableData()
            this.batchUploadDialog.show = false
          } else {
            this.$_message.error(res.data.message)
            this.uploading = false
          }
        }
      } catch (error) {
        this.uploading = false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14{
    padding-left:8px;
    font-size:14px
  }
  .isRed {
    color: red
  }
</style>
