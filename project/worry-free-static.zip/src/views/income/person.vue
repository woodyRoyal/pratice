<!--定时任务-->
<template>
  <div>
    <div>
      <el-form :inline="true" :model="queryForm" size="mini" class="margin-mini">
       <el-form-item label="商务负责人:">
          <el-input style="width:120px" v-model="queryForm.principalName" @keyup.native.enter="fetchData()"></el-input>
       </el-form-item>
       <el-form-item label="状态:">
         <el-select style="width:120px" v-model="queryForm.status" filterable clearable>
           <el-option value="" label="不限">不限</el-option>
            <el-option
            v-for="(item,index) in selectList.statusList"
            :key="index"
            :label="item.value"
            :value="item.key"
            >
            {{item.value}}
            </el-option>
          </el-select>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="fetchData()" class="least">查询</el-button>
        <el-button type="primary" size="mini" @click="add" class="least">添加负责人</el-button>
      </el-form-item>
    </el-form>
    </div>
    <!--表格-->
    <!-- show-summary
      :summary-method="getSummaries" -->
    <el-table
      v-loading="tableLoading"
      :data="tableData"
      border fit
      highlight-current-row
      stripe
      :max-height="tableMaxHeight"
      style="width:100%"
      >
      <el-table-column
        prop="id"
        label="商务负责人ID"
        :fixed = "tableData.length>0"
        min-width="80"
        >
      </el-table-column>
      <el-table-column
        prop="principalName"
        label="商务负责人"
        min-width="80"
        >
        <template slot-scope="scope">
          <span slot="reference" class="btnText" @click="openEditDialog(scope.row)">{{scope.row.principalName}}</span>
        </template>
      </el-table-column>

      <el-table-column
        prop="status"
        label="状态"
        min-width="80"
      >
        <template slot-scope="scope">
          <div class="product-status">
            <span>
              <span v-if="scope.row.status" style="color:green;">显示</span>
              <span v-else style="color:red">隐藏</span>
            </span>
            <span
              @click.capture.stop="changeStatus(scope.row)">
              <el-switch
              :active-value = "1"
              :inactive-value = "0"
              v-model="scope.row.status"
              active-color="#13ce66"
              inactive-color="#ff4949">
            </el-switch>
            </span>
          </div>
        </template>
      </el-table-column>

      <el-table-column
        prop="createAt"
        label="添加时间"
        min-width="110"
      >
      </el-table-column>
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
    
    <!-- 广告主 -->
     <el-dialog :visible.sync="addAdvDialog.show" :title="addAdvDialog.title" @close="closeAdd">
       <el-form :model="addAdvDialog.addForm" ref="addForm" size="mini" :rules="addAdvDialog.addRules">
         <el-form-item label="商务负责人" :label-width="addAdvDialog.labelWidth" prop="principalName">
            <el-input v-model="addAdvDialog.addForm.principalName">

            </el-input>
         </el-form-item>
       </el-form>
       <div slot="footer" class="dialog-footer">
          <el-button  @click="addAdvDialog.show = false">取消</el-button>
          <el-button type="primary" @click="submitAdv">确认</el-button>
        </div>
     </el-dialog>
  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'
import BusinessPrincipalApi from '../../api/incomeApi/BusinessPrincipalApi.js'
// import Moment from 'moment'
export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      checked: false,
      timer: null,
      downLoading: false,
      centerDialogVisible: true,
      status: '已生成文件',
      tableLoading: false,
      isclick: false,
      hoverWidth: '300',
      editDialog: false,
      addAdvDialog: {
        labelWidth: '120px',
        show: false,
        title: '添加商务负责人',
        addForm: {
          principalName: ''
        },
        addRules: {
          principalName: [
            { required: true, message: '请填写商务负责人', trigger: 'blur' }
          ]
        }
      },
      hoverRow: {

      },
      summaryDailyVo: {

      },
      gridData: [
        {'name': '渠道类型', value: ''},
        {'name': '渠道商', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: ''},
        {'name': '平台平成', value: ''},
        {'name': '投放终端', value: ''}
      ],
      queryForm: {
        principalName: '',
        status: 1
      },
      selectList: {
        statusList: [{key: 0, value: '隐藏'}, {key: 1, value: '显示'}]
      },
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [30, 50, 100],
        pageSize: 30, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [

      ],
      listLoading: false
    }
  },
  created () {
    console.log(this.$store.state.loginUser)
    this.fetchData()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {
  },
  watch: {
  },
  methods: {
    async changeStatus (row) {
      try {
        let str = row.status ? '隐藏' : '显示'
        let confirm = await this.$confirm(`确认${str}该项吗?`, '提示', { type: 'warning' })
        if (confirm) {
          let data = {
            id: row.id,
            status: row.status === 0 ? 1 : 0,
            principalName: row.principalName
          }
          let res = await BusinessPrincipalApi.saveOrUpdateBusinessPrincipal(data)
          if (res.data.code === '0') {
            this.$_message({
              showClose: true,
              message: '操作成功',
              type: 'success'
            })
            this.fetchData()
          } else {
            this.$_message.error(res.data.message)
          }
        }
      } catch (error) {

      }
    },
    submitAdv () {
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        let data = {
          ...this.addAdvDialog.addForm,
          status: 1
        }
        let res = await BusinessPrincipalApi.saveOrUpdateBusinessPrincipal(data)
        if (res.data.code === '0') {
          this.fetchData()
          this.$_message({
            showClose: true,
            message: '操作成功',
            type: 'success'
          })
          this.addAdvDialog.show = false
        } else {
          this.$_message.error(res.data.message)
        }
      })
    },
    batchChange () {
      this.batchDialog.show = true
    },
    closeAdd () {
      this.$refs['addForm'].resetFields()
    },
    openEditDialog (row) {
      this.addAdvDialog.title = '编辑商务负责人'
      this.addAdvDialog.addForm = {
        status: row.status,
        principalName: row.principalName,
        id: row.id
      }
      this.addAdvDialog.show = true
    },
    add () {
      this.addAdvDialog.addForm = {
        status: 1,
        principalName: ''
      }
      this.addAdvDialog.title = '添加商务负责人'
      this.addAdvDialog.show = true
    },
    async poll () {
      let data = {
        isCollect: this.checked ? 1 : 0,
        channelName: this.queryForm.channelName,
        countDateStart: this.queryForm.time[0] || '',
        countDateEnd: this.queryForm.time[1] || '',
        facilitatorId: this.queryForm.facilitatorId,
        principalId: this.queryForm.principalId,
        typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
        platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
        pageNum: this.pagination.pageNo,
        pageSize: this.pagination.pageSize,
        queryType: 1
      }
      let res = await BusinessPrincipalApi.exportDaily(data)
      if (res.data.respCode === '1000') {
        if (res.data.body.downLoadFlag === 1) {
          clearInterval(this.timer)
          window.location.href = process.env.DOWN_URL + res.data.body.downLoadUrl
          this.downLoading = false
        }
      }
    },
    async fetchDetail (val) {
      this.hoverRow = val
      this.gridData = [
        {'name': '渠道类型', value: val.channelType},
        {'name': '渠道商简称', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: val.principal},
        {'name': '平台名称', value: ''},
        {'name': '投放终端', value: ''}
      ]
      let res = await BusinessPrincipalApi.hover(this.hoverRow.channelName)
      // let res = await BusinessPrincipalApi.hover('测试渠道')
      if (res.data.respCode === '1000') {
        if (!res.data.body) {
          return this.$_message.error('查询寻不到渠道明细')
        }
        this.gridData[0].value = res.data.body.typeName
        this.gridData[2].value = res.data.body.mediaName
        this.gridData[1].value = res.data.body.facilitatorShortName
        this.gridData[3].value = res.data.body.paymentName
        this.gridData[4].value = res.data.body.price
        this.gridData[5].value = res.data.body.status === 1 ? '显示' : '隐藏'
        this.gridData[6].value = res.data.body.principalName
        this.gridData[7].value = res.data.body.platformName
        // {'name': '平台名称', value: this.platformDIC[val.platform]},
        // {'name': '投放终端', value: this.phoneDIC[val.terminal]}
        this.gridData[8].value = res.data.body.terminalName
      }
    },
    clearDetail () {
      this.gridData[2].value = ''
      this.gridData[3].value = ''
      this.gridData[4].value = ''
      this.gridData[5].value = ''
    },
    async fetchData (val) {
      try {
        this.tableLoading = true
        let data = {
          ...this.queryForm,
          pageNum: this.pagination.pageNo,
          pageSize: this.pagination.pageSize
        }
        let res = await BusinessPrincipalApi.getBusinessPrincipalList(data)
        if (res.data.code === '0') {
          this.tableLoading = false
          this.pagination.total = res.data.data.total
          this.pagination.pageNo = res.data.data.pageNum
          this.tableData = res.data.data.list
          if (this.pagination.pageNo > 1 && this.tableData.length === 0) {
            this.pagination.pageNo = 1
            this.fetchData()
          }
        } else {
          this.$_message.eror(res.data.message)
          this.tableLoading = false
        }
      } catch (error) {
        this.tableLoading = false
      }
    },
    formatNum (num) {
      // num = Number(num) / 100
      num = num.toFixed(2)
      return num
    },
    getSummaries (param) {
      // const { columns } = param
      // console.log(columns)
      const sums = []
      if (!this.checked) {
        sums[0] = '汇总'
        sums[1] = '-'
        sums[2] = '-'
        sums[3] = '-'
        if (this.summaryDailyVo.dailyRealFee || this.summaryDailyVo.dailyRealFee === 0) {
          sums[4] = this.formatNum(this.summaryDailyVo.dailyRealFee)
        }
        if (this.summaryDailyVo.payCost || this.summaryDailyVo.payCost === 0) {
          sums[5] = this.formatNum(this.summaryDailyVo.payCost)
        }
        sums[6] = this.summaryDailyVo.productClickCount
        sums[7] = this.summaryDailyVo.registerCount
        sums[8] = this.summaryDailyVo.regAndLogSameDay
        sums[9] = this.summaryDailyVo.reglogSameDayRate
        sums[10] = this.summaryDailyVo.firstLoginCount
        sums[11] = this.summaryDailyVo.naturalLogin
        sums[12] = this.summaryDailyVo.costLogin
        sums[13] = '-'
        return sums
      }
      if (this.checked) {
        sums[0] = '汇总'
        if (this.summaryDailyVo.dailyRealFee || this.summaryDailyVo.dailyRealFee === 0) {
          sums[1] = this.formatNum(this.summaryDailyVo.dailyRealFee)
        }
        if (this.summaryDailyVo.payCost || this.summaryDailyVo.payCost === 0) {
          sums[2] = this.formatNum(this.summaryDailyVo.payCost)
        }
        sums[3] = this.summaryDailyVo.productClickCount
        sums[4] = this.summaryDailyVo.registerCount
        sums[5] = this.summaryDailyVo.regAndLogSameDay
        sums[6] = this.summaryDailyVo.reglogSameDayRate
        sums[7] = this.summaryDailyVo.firstLoginCount
        sums[8] = this.summaryDailyVo.naturalLogin
        sums[9] = this.summaryDailyVo.costLogin
        return sums
      }
    },
    tableHover (val) {

    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label
          // content: TABLE_TITLE_TIP[column.property]
          // content: 'TABLE_TITLE_TIP[column.property]'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 100
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    },
    handleClearFiles () {
      this.ARPUfileList = []
      this.file = null
    },
    // 批量修改-上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
    handleUploadBefore (file) {
      if (file.name && file.name.length > 0) {
        const ldot = file.name.lastIndexOf('.')
        const type = file.name.toLowerCase().substring(ldot)
        if (type !== '.csv') {
          this.$_message.warning('目前只支持.csv格式的文件')
          return false
        }
        this.uploadFileName = file.name
        console.log(this.uploadFileName)
      }
    },
    // 批量修改-文件上传成功时的钩子
    handleUploadSuccess (response, file, fileList) {
      console.log('上传成功')
      this.uploadTagVisible = true
    },
    // 批量修改-文件上传失败时的钩子
    handleUploadError (err, file, fileList) {
      if (err.status === 404) {
        this.$_message.error('上传失败，网络连接异常!')
      } else {
        console.log(err)
        this.$_message.error('上传失败!')
      }
    },
    // 导入项目-文件上传时的钩子
    handleUploadProgress (event, file, fileList) {
      console.log('上传中...')
    },
    async handleUploadChange (file, fileList) {
      this.handleClearFiles()
      this.ARPUfileList = [file]
      this.uploadFileName = file.name
      this.file = file.raw
      // this.uploading = true
      // let param = new window.FormData()
      // param.append('file', this.file)
      // let res = await appApi.importValidation(param, data)
      // this.uploading = false
    },
    closeFile () {
      this.$refs.uploadFile && this.$refs.uploadFile.clearFiles()
      this.handleClearFiles()
    },
    async fetchUpload () {
      if (!this.file) return this.$_message.error('请先选择文件')
      this.uploading = true
      let param = new window.FormData()
      param.append('file', this.file)
      try {
        if (this.batchUploadDialog.type === 1) {
          let res = await BusinessPrincipalApi.productArpuImport(param)
          if (res.data.respCode === '1000') {
            this.$_message.success('上传成功')
            this.uploading = false
            this.getTableData()
            this.batchUploadDialog.show = false
          } else {
            this.$_message.error(res.data.respMsg)
            this.uploading = false
          }
        }
        if (this.batchUploadDialog.type === 2) {
          let res = await BusinessPrincipalApi.productUvClickLimitImport(param)
          if (res.data.respCode === '1000') {
            this.$_message.success('上传成功')
            this.uploading = false
            this.getTableData()
            this.batchUploadDialog.show = false
          } else {
            this.$_message.error(res.data.respMsg)
            this.uploading = false
          }
        }
      } catch (error) {
        this.uploading = false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14{
    padding-left:8px;
    font-size:14px
  }
</style>
