<!--定时任务-->
<template>
  <div>
    <div>
      <el-form :inline="true" :model="queryForm" size="mini" class="margin-mini">
       <el-form-item label="广告主:">
         <el-input v-model="queryForm.advertiserName" style="width:120px" @keyup.native.enter="fetchData()" placeholder="支持模糊查询"></el-input>
       </el-form-item>
       <el-form-item label="产品:">
         <el-input v-model="queryForm.productName" style="width:120px" @keyup.native.enter="fetchData()" placeholder="支持模糊查询"></el-input>
       </el-form-item>
       <el-form-item label="商务负责人:">
         <el-select v-model="queryForm.businessPrincipalId" style="width:120px" filterable clearable placeholder="支持模糊查询">
            <el-option
            v-for="(item,index) in selectList.facilitatorList"
            :key="index"
            :label="item.value"
            :value="item.key" 
            >
            {{item.value}}
            </el-option>
          </el-select>
       </el-form-item>
       <el-form-item label="合作状态:">
         <el-select style="width:120px" v-model="queryForm.cooperationStatus" filterable clearable placeholder="支持模糊查询">
           <el-option value="" label="不限">不限</el-option>
            <el-option
            v-for="(item,index) in selectList.cooperationStatus"
            :key="index"
            :label="item.value"
            :value="item.key"
            >
            {{item.value}}
            </el-option>
          </el-select>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="fetchData()" class="least">查询</el-button>
        <el-button type="primary" size="mini" @click="add" class="least">添加广告主</el-button>
        <el-button type="primary" size="mini" @click="batchChange" :loading="downLoading" class="least">批量变更负责人</el-button>
        <!-- <el-button type="primary" size="mini" @click="down" :loading="downLoading">更新数据</el-button> -->
      </el-form-item>
    </el-form>
    </div>
    <!--表格-->
    <!-- show-summary
      :summary-method="getSummaries" -->
    <el-table
      v-loading="tableLoading" 
      :data="tableData"
      border fit
      highlight-current-row
      stripe
      show-summary
      :summary-method="getSummaries"
      :max-height="tableMaxHeight"
      style="width:100%"
      >
      <el-table-column
        prop="id"
        label="广告主ID"
        :fixed = "tableData.length>0"
        min-width="60"
        >
      </el-table-column>
      <el-table-column
        
        :key="1"
        prop="advertiserName"
        label="广告主"
        min-width="100"
        >
        <template slot-scope="scope">
          <div>
            <span slot="reference" class="btnText" @click="openEditDialog(scope.row)">{{scope.row.advertiserName}}</span>
          </div>
        </template>
      </el-table-column>

      <el-table-column
        
        :key="2"
        prop="productName"
        label="产品"
        min-width="75"
        >
        <template slot-scope="scope">
          <span v-html="scope.row.productName">

          </span>
        </template>
      </el-table-column>
      <el-table-column
        prop="businessPrincipalName"
        label="商务负责人"
        min-width="75"
        >
      </el-table-column>

      <el-table-column
        prop="type"
        label="类型"
        min-width="40"
      >
      <template slot-scope="scope">
        <span>
          {{scope.row.type === 1 ?'直客':'代理'}}
        </span>
      </template>
      </el-table-column>

      <el-table-column
        prop="publicOrPrivate"
        label="对公对私"
        min-width="50"
      >
      <template slot-scope="scope">
        <span>{{scope.row.publicOrPrivate === 1? '对公':'对私'}}</span>
      </template>
      </el-table-column>
      <el-table-column
        prop="needInvoice"
        label="是否开票"
        min-width="50"
      >
      <template slot-scope="scope">
        <span>
          {{scope.row.needInvoice === 1? '开票':'不开票'}}
        </span>
      </template>
      </el-table-column>

      <el-table-column
        prop="signingSubject"
        label="签约主体"
        min-width="80"
      >
      </el-table-column>

      <el-table-column
        prop="accountName"
        label="预付账号名称"
        min-width="90"
      >
      </el-table-column>

      <el-table-column
        prop="paymentAmount"
        label="打款金额"
        min-width="70"
      >
      <template slot-scope="scope">
          <div>
            <span  class="btnText" @click=" openRemittanceDialog(scope.row)">{{scope.row.paymentAmount}}</span>
          </div>
        </template>
      </el-table-column>

      <el-table-column
        prop="consumeAmount"
        label="消耗金额"
        min-width="70"
      >
       <template slot-scope="scope">
         <span :class="{isRed:scope.row.consumeMarkRed}">{{scope.row.consumeAmount}}</span>

       </template>
      </el-table-column>
      <!-- <el-table-column
        prop="refundAmount"
        label="退款金额"
        min-width="80"
      >
        <template slot-scope="scope">
          <div v-if="!scope.row.refundAmountView " @dblclick="edit(scope.row,'refundAmountView')"><span :class="scope.row.adjustFeeViewRED">{{scope.row.refundAmount}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-if="scope.row.refundAmountView"><el-input v-model.number="scope.row.refundAmount" size="mini" @blur="blurInput(scope.row,'refundAmount')"> </el-input></div>
        </template>
      </el-table-column> -->
      <el-table-column
        prop="balance"
        label="余额"
        min-width="60"
      >
      <template slot-scope="scope">
        <div>
          <i class="iconfont icon-gantanhao-yuankuang" style="color:red;cursor:pointer" v-if="scope.row.balanceMarkRed" @click="openMonitor(scope.row)"></i>
          <span :class="{isRed:scope.row.balanceMarkRed}">{{scope.row.balance}} </span>
        </div>
      </template>
      </el-table-column>
      <el-table-column
        :key="3"
        prop="terminal"
        label="合作状态"
      >
      <template slot-scope="scope">
          <div class="product-status">
            <span>
              <span v-if="scope.row.cooperationStatus === 1" style="color:green;">合作中</span>
              <span v-else style="color:red">暂停合作</span>
            </span>
            <span
              @click.capture.stop="changeStatus(scope.row)">
              <el-switch
              :active-value = "1"
              :inactive-value = "2"
              v-model="scope.row.cooperationStatus"
              active-color="#13ce66"
              inactive-color="#ff4949">
            </el-switch>
            </span>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="remark"
        label="备注"
        min-width="100"
      >
      <template slot-scope="scope">
          <div v-show="!scope.row.remarkView " @dblclick="edit(scope.row,'remarkView')"><span :class="scope.row.adjustFeeViewRED">{{scope.row.remark}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-show="scope.row.remarkView"><el-input v-model="scope.row.remark" size="mini" @blur="blurInput(scope.row,'remark')" :maxlength="225" :ref="'remarkView' + scope.row.id" :id="'remarkView' + scope.row.id"> </el-input></div>
        </template>
      </el-table-column>
      <el-table-column
        prop="createAt"
        label="添加时间"
        min-width="120"
      >
      </el-table-column>
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNum" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
    
    <!-- 广告主 -->
     <el-dialog :visible.sync="addAdvDialog.show" :title="addAdvDialog.title" @close="closeAdd('addForm')">
       <el-form :model="addAdvDialog.addForm" ref="addForm" size="mini" :rules="addAdvDialog.addRules">
         <el-form-item label="广告主" :label-width="addAdvDialog.labelWidth" prop="advertiserName">
            <el-input v-model="addAdvDialog.addForm.advertiserName">
              
            </el-input>
         </el-form-item>
         <el-form-item label="商务负责人" :label-width="addAdvDialog.labelWidth" prop="businessPrincipalId">
            <el-select v-model="addAdvDialog.addForm.businessPrincipalId"  filterable clearable>
            <el-option
            v-for="(item,index) in selectList.facilitatorList"
            :key="index"
            :label="item.value"
            :value="item.key" 
            >
            {{item.value}}
            </el-option>
          </el-select>
         </el-form-item>
         <el-form-item label="类型" :label-width="addAdvDialog.labelWidth" prop="type">
            <el-select v-model="addAdvDialog.addForm.type"  filterable clearable>
            <el-option
            v-for="(item,index) in selectList.typeList"
            :key="index"
            :label="item.value"
            :value="item.key" 
            >
            {{item.value}}
            </el-option>
          </el-select>
         </el-form-item>
         <el-form-item label="对公对私" :label-width="addAdvDialog.labelWidth" prop="publicOrPrivate">
            <el-select v-model="addAdvDialog.addForm.publicOrPrivate"  filterable clearable>
            <el-option
            v-for="(item,index) in selectList.publicOrPrivateList"
            :key="index"
            :label="item.value"
            :value="item.key" 
            >
            {{item.value}}
            </el-option>
          </el-select>
         </el-form-item>
         <el-form-item label="是否开票" :label-width="addAdvDialog.labelWidth" prop="needInvoice">
            <el-select v-model="addAdvDialog.addForm.needInvoice"  filterable clearable>
            <el-option
            v-for="(item,index) in selectList.needInvoiceList"
            :key="index"
            :label="item.value"
            :value="item.key" 
            >
            {{item.value}}
            </el-option>
          </el-select>
         </el-form-item>
         <el-form-item label="签约主体" :label-width="addAdvDialog.labelWidth" prop="signingSubject">
            <el-input v-model="addAdvDialog.addForm.signingSubject">

            </el-input>
         </el-form-item>
         <el-form-item label="预约账号名称" :label-width="addAdvDialog.labelWidth" prop="accountName">
            <el-input v-model="addAdvDialog.addForm.accountName">

            </el-input>
         </el-form-item>
       </el-form>
       <div slot="footer" class="dialog-footer">
          <el-button  @click="addAdvDialog.show = false">取消</el-button>
          <el-button type="primary" @click="submitAdv">确认</el-button>
        </div>
     </el-dialog>
     <!-- 批量变更负责人 -->
     <el-dialog :visible.sync="batchDialog.show" :title="batchDialog.title" @close="closeAdd('batchForm')">
       <el-form :model="batchDialog.addForm" ref="batchForm" size="mini" :rules="batchDialog.addRules">
         <el-form-item label="当前商务负责人" :label-width="batchDialog.oldPrincipalId" prop="oldPrincipalId">
            <el-select v-model="batchDialog.addForm.oldPrincipalId"  filterable clearable>
            <el-option
            v-for="(item,index) in selectList.facilitatorList"
            :key="index"
            :label="item.value"
            :value="item.key" 
            >
            {{item.value}}
            </el-option>
          </el-select>
         </el-form-item>
         <el-form-item label="新的商务负责人" :label-width="batchDialog.newPrincipalId" prop="newPrincipalId">
            <el-select v-model="batchDialog.addForm.newPrincipalId"  filterable clearable>
            <el-option
            v-for="(item,index) in selectList.facilitatorList"
            :key="index"
            :label="item.value"
            :value="item.key" 
            >
            {{item.value}}
            </el-option>
          </el-select>
         </el-form-item>
       </el-form>
       <div slot="footer" class="dialog-footer">
          <el-button  @click="batchDialog.show = false">取消</el-button>
          <el-button type="primary" @click="submitBatch">确认</el-button>
        </div>
     </el-dialog>
     <!-- 打款记录 -->
     <el-dialog :visible.sync="remittanceDialog.show" :title="remittanceDialog.title">
       <div style="margin-bottom:10px">
        <span style="font-size:18px;color:#303133">广告主：</span> <span style="font-size:18px;color:#303133">{{remittanceDialog.advertiserName}}</span> <el-button type="primary" size="mini" style="margin-left:100px" @click="openAddRecordDialog(true)">添加记录</el-button>
      </div>
        <el-table :data="remittanceDialog.list" stripe border width="100%">
                  <el-table-column  prop="payDate" label="打款时间" min-width="60">
                  </el-table-column>
                  <el-table-column  label="打款金额"  prop="payAmount" min-width="80">
                  </el-table-column>
                  <el-table-column  prop="imgUrl" label="截图" min-width="80">
                    <template slot-scope="scope">
                      <span  class="btnText" @click="editAddRecordDialog(scope.row,false)">[查看]</span>
                    </template>
                  </el-table-column>
                  <el-table-column  prop="advertiserId" label="操作" min-width="80">
                    <template slot-scope="scope">
                      <span  class="btnText" @click="editAddRecordDialog(scope.row,true)">[编辑]</span>
                    </template>
                  </el-table-column>
                </el-table>
     </el-dialog>
     <!-- 添加编辑打款记录 -->
     <el-dialog :visible.sync="addRecordDialog.show" :title="remittanceDialog.title" @close="closeFile">
       <el-form :model="addRecordDialog.addForm" ref="fileDialog" size="mini" :rules="addRecordDialog.addRules">
         <el-form-item label="打款时间" :label-width="addRecordDialog.labelWidth" prop="payDate" v-if="isEdit">
            <el-date-picker
              style="width:100%"
              v-model="addRecordDialog.addForm.payDate"
              type="date"
              value-format="yyyy-MM-dd"
              placeholder="选择日期">
            </el-date-picker>                           
         </el-form-item>
         <el-form-item label="打款金额" :label-width="addRecordDialog.labelWidth" prop="payAmount" v-if="isEdit">
            <el-input v-model="addRecordDialog.addForm.payAmount">

            </el-input>
         </el-form-item>
         <el-form-item label="截图" :label-width="addRecordDialog.labelWidth" prop="imgUrl" v-if="isEdit">
            <el-upload class="upload-user-defined" name="in" :auto-upload='false'
                   action="url" :file-list="ARPUfileList" :show-file-list="true"
                   :with-credentials="true" ref = "uploadFile"
                   :before-upload="handleUploadBefore" :on-success="handleUploadSuccess" :on-error="handleUploadError"
                   :on-progress="handleUploadProgress" :on-change="handleUploadChange" :disabled="uploading">
              <el-button size="mini" type="primary" :loading="uploading">选择文件
              </el-button>
            </el-upload>
         </el-form-item>
         <el-form-item label="" :label-width="addRecordDialog.labelWidth" prop="">
            <img :src="addRecordDialog.addForm.imgUrl" style="max-height:400px;max-width:300px">
            <!-- <img :src="addRecordDialog.addForm.imgUrl"> -->
         </el-form-item>
       </el-form>
       <div slot="footer" class="dialog-footer">
          <el-button  @click="addRecordDialog.show = false">取消</el-button>
          <el-button type="primary" @click="submitFile" v-if="isEdit">确认</el-button>
        </div>
     </el-dialog>
     <!-- 监控记录 -->
     <el-dialog :visible.sync="monitorDialog.show" title="质量监控">
        <div style="margin-bottom:10px">
        <span style="font-size:18px;color:#303133">广告主：</span> <span style="font-size:18px;color:#303133">{{monitorDialog.advertiserName}}</span>
      </div>
        <el-table :data="monitorDialog.list" stripe border width="100%">
                  <el-table-column  prop="monitorDate" label="监控日期" min-width="60">
                  </el-table-column>
                  <el-table-column  label="异常指标项"  prop="monitorName" min-width="80">
                  </el-table-column>
                  <el-table-column  label="当前值"  prop="currentValue" min-width="80">
                  </el-table-column>
                  <el-table-column  label="标准值"  prop="standardValue" min-width="80">
                  </el-table-column>
                  <el-table-column  prop="mark" label="备注" min-width="80">
                    <template slot-scope="scope">
                       <div v-if="!scope.row.markView " @dblclick="edit(scope.row,'markView')"><span >{{scope.row.mark}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
                      <el-input v-model="scope.row.mark" size="mini" @blur="blurMark(scope.row)" :maxlength="225" v-if="scope.row.markView" :ref="'markView' + scope.row.id"></el-input>
                    </template>
                  </el-table-column>
                  <el-table-column  prop="advertiserId" label="操作" min-width="80">
                    <template slot-scope="scope">
                      <el-button type="primary" size="mini" @click="updateInfo(scope.row)" v-if="tabButtonPerms['updateMonitor']">关闭提醒</el-button>
                    </template>
                  </el-table-column>
                </el-table>
     </el-dialog>
  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'
import advertiserApi from '../../api/incomeApi/advertiser.js'
import commonApi from '../../api/incomeApi/common.js'
import Moment from 'moment'
export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      tabButtonPerms: {
        'updateMonitor': false
      },
      isEdit: false,
      file: null,
      ARPUfileList: [],
      uploading: false,
      timer: null,
      downLoading: false,
      centerDialogVisible: true,
      status: '已生成文件',
      tableLoading: false,
      isclick: false,
      hoverWidth: '300',
      editDialog: false,
      addAdvDialog: {
        labelWidth: '120px',
        show: false,
        title: '添加广告主',
        addForm: {
          accountName: '',
          advertiserName: '',
          businessPrincipalId: '',
          needInvoice: '',
          publicOrPrivate: '',
          signingSubject: '',
          type: ''
        },
        addRules: {
          accountName: [
            { required: true, message: '请填写预约账号名称', trigger: 'blur' }
          ],
          advertiserName: [
            { required: true, message: '请填写广告主', trigger: 'blur' }
          ],
          businessPrincipalId: [
            { required: true, message: '请选择', trigger: 'blur' }
          ],
          needInvoice: [
            { required: true, message: '请选择', trigger: 'blur' }
          ],
          publicOrPrivate: [
            { required: true, message: '请选择', trigger: 'blur' }
          ],
          signingSubject: [
            { required: true, message: '请填写签约主体', trigger: 'blur' }
          ],
          type: [
            { required: true, message: '请选择', trigger: 'change' }
          ]
        }
      },
      batchDialog: {
        labelWidth: '120px',
        show: false,
        title: '批量变更负责人',
        addForm: {},
        addRules: {
          newPrincipalId: [
            { required: true, message: '请选择', trigger: 'blur' }
          ],
          oldPrincipalId: [
            { required: true, message: '请选择', trigger: 'blur' }
          ]
        }
      },
      remittanceDialog: {
        productName: '',
        advertiserId: '',
        labelWidth: '120px',
        show: false,
        list: [
          // {
          //   'advertiserId': 2,
          //   'id': 1,
          //   'imgUrl': 'http://www.baidu.com',
          //   'payAmount': 333.22,
          //   'payDate': '2018-10-22'
          // }
        ],
        title: '打款记录',
        addForm: {},
        addRules: {}
      },
      monitorDialog: {
        advertiserName: '',
        advertiserId: '',
        labelWidth: '120px',
        show: false,
        list: [
          // {
          //   'currentValue': 0,
          //   'id': 1,
          //   'mark': '测试内容1jc1',
          //   'monitorDate': '2018-11-09',
          //   'monitorName': '广告主余额过低',
          //   'standardValue': 0
          // }
        ]
      },
      addRecordDialog: {
        advertiserId: null,
        advertiserName: null,
        labelWidth: '120px',
        show: false,
        list: [],
        title: '添加打款记录',
        addForm: {
          advertiserId: '',
          id: '',
          imgUrl: '',
          payAmount: '',
          payDate: ''
        },
        addRules: {
          payAmount: [
            { required: true, message: '请填写金额', trigger: 'blur' }
          ],
          payDate: [
            { required: true, message: '请选择', trigger: 'blur' }
          ],
          imgUrl: [
            { required: true, message: '选择图片', trigger: 'blur' }
          ]
        }
      },
      hoverRow: {

      },
      summaryDailyVo: {
        'type': '',
        'publicOrPrivate': '',
        'needInvoice': '',
        'signingSubject': '',
        'accountName': '',
        'paymentAmount': '',
        'consumeAmount': '',
        'consumeMarkRed': '',
        'refundAmount': '',
        'balance': '',
        'balanceMarkRed': '',
        'cooperationStatus': '',
        'remark': '',
        'createAt': ''

      },
      gridData: [
        {'name': '渠道类型', value: ''},
        {'name': '渠道商', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: ''},
        {'name': '平台平成', value: ''},
        {'name': '投放终端', value: ''}
      ],
      queryForm: {
        productName: '',
        advertiserName: '',
        businessPrincipalId: '',
        cooperationStatus: 1
      },
      selectList: {
        facilitatorList: [],
        cooperationStatus: [{key: 1, value: '合作中'}, {key: 2, value: '暂停合作'}],
        publicOrPrivateList: [{key: 1, value: '对公'}, {key: 2, value: '对私'}],
        needInvoiceList: [{key: 1, value: '开票'}, {key: 2, value: '不开票'}],
        typeList: [{key: 1, value: '直客'}, {key: 2, value: '代理'}]
      },
      docObj: {

      },
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNum: 1, // pageNo
        pageSizes: [30, 50, 100],
        pageSize: 30, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [
        // {
        //   'accountName': '测试打款账号',
        //   'advertiserName': '测试广告主02',
        //   'balance': 210,
        //   'balanceMarkRed': true,
        //   'businessPrincipalId': 1,
        //   'businessPrincipalName': '商务测试人01',
        //   'consumeAmount': 0,
        //   'consumeMarkRed': false,
        //   'cooperationStatus': 1,
        //   'createAt': '2018-11-07 11:34:02',
        //   'id': 2,
        //   'needInvoice': 1,
        //   'paymentAmount': 333.22,
        //   'productName': '测试内容tw59',
        //   'publicOrPrivate': 2,
        //   'refundAmount': 123.22,
        //   'remark': '测试备注',
        //   remarkView: false,
        //   'signingSubject': '测试签约主体',
        //   refundAmountView: false,
        //   'type': 1
        // }
      ],
      listLoading: false
    }
  },
  created () {
    this.getDic()
    this.fetchData()
    console.log(Moment)
    const btnKeys = ['updateMonitor']
    btnKeys.forEach(t => {
      this.$store.state.loginUser.tabButtonPerms.forEach(j => {
        if (t === j) {
          this.tabButtonPerms[t] = true
        }
      })
    })
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {
  },
  watch: {
  },
  methods: {
    edit (row, type) {
      row[type] = true
      this.$nextTick(() => {
        let str = type + row.id
        document.getElementById(str).focus()
        // this.$refs[type + row.id].focus()
      })
    },
    async blurMonitorInput (row) {
      let data = {
        id: row.id,
        mark: row.mark
      }
      let res = await advertiserApi.updateAdvertiserMonitor(data)
      if (res.data.code === '0') {
        this.$_message({
          showClose: true,
          message: '操作成功',
          type: 'success'
        })
        this.fetchMonitor(this.monitorDialog.advertiserId)
      } else {
        this.$_message({
          showClose: true,
          message: res.data.message || '操作失败',
          type: 'error'
        })
      }
    },
    async updateAdvertiserMonitor (row) {
      try {
        let confirm = await this.$confirm(`确认关闭提醒吗?`, '提示', { type: 'warning' })
        if (confirm) {
          let data = {
            id: row.id,
            status: 0
          }
          let res = await advertiserApi.updateAdvertiserMonitor(data)
          if (res.data.code === '0') {
            this.$_message({
              showClose: true,
              message: '操作成功',
              type: 'success'
            })
            this.fetchMonitor(this.monitorDialog.advertiserId)
            this.fetchData()
          } else {
            this.$_message.error(res.data.message || '操作失败')
          }
        }
      } catch (error) {

      }
    },
    async blurMark (row) {
      let data = {
        id: row.id,
        mark: row.mark,
        status: row.status
      }
      let res = await advertiserApi.updateAdvertiserMonitor(data)
      if (res.data.code === '0') {
        this.fetchMonitor(this.monitorDialog.advertiserId)
        this.$_message({
          showClose: true,
          message: '操作成功',
          type: 'success'
        })
      } else {
        this.$_message.error(res.data.message || '操作失败')
      }
    },
    async blurInput (row, type) {
      if (type === 'refundAmount') {
        if (!/^(-)?\d+(\.\d+)?$/.test(row[type])) {
          return this.$_message.error('请输入数字')
        }
      }
      let data = {
        id: row.id,
        refundAmount: row.refundAmount,
        remark: row.remark,
        cooperationStatus: row.cooperationStatus
      }
      data[type] = row[type]
      let res = await advertiserApi.updateIndividual(data)
      if (res.data.code === '0') {
        this.$_message({
          showClose: true,
          message: '操作成功',
          type: 'success'
        })
        this.fetchData()
      } else {
        this.$_message.error(res.data.message || '操作失败')
      }
    },
    openAddRecordDialog () {
      this.isEdit = true
      this.addRecordDialog.addForm = {
        advertiserId: this.remittanceDialog.advertiserId,
        id: null,
        payAmount: '',
        payDate: '',
        imgUrl: ''
      }
      this.addRecordDialog.show = true
    },
    editAddRecordDialog (row, type) {
      this.isEdit = type
      this.addRecordDialog.addForm = {
        advertiserId: this.remittanceDialog.advertiserId,
        id: row.id,
        payAmount: row.payAmount,
        payDate: row.payDate,
        imgUrl: row.imgUrl
      }
      this.addRecordDialog.show = true
    },
    async changeStatus (row) {
      try {
        let str = row.cooperationStatus === 1 ? '暂停合作' : '合作'
        let confirm = await this.$confirm(`确认与该广告主${str}吗?`, '提示', { type: 'warning' })
        if (confirm) {
          let data = {
            id: row.id,
            remark: row.remark,
            refundAmount: row.refundAmount,
            cooperationStatus: row.cooperationStatus === 1 ? 2 : 1
          }
          let res = await advertiserApi.updateIndividual(data)
          if (res.data.code === '0') {
            this.$_message({
              showClose: true,
              message: '操作成功',
              type: 'success'
            })
            this.fetchData()
          } else {
            this.$_message.error(res.data.message || '操作失败')
          }
        }
      } catch (error) {

      }
    },
    async openRemittanceDialog (row) {
      this.remittanceDialog.advertiserName = row.advertiserName
      this.remittanceDialog.advertiserId = row.id
      this.getAdvertiserPaymentList(this.remittanceDialog.advertiserId)
      this.remittanceDialog.show = true
    },
    async getAdvertiserPaymentList (id) {
      let res = await advertiserApi.getAdvertiserPaymentList(id)
      if (res.data.code === '0') {
        this.remittanceDialog.list = res.data.data
      } else {
        this.$_message.error(res.data.message)
      }
    },
    submitAdv () {
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        let data = {

        }
        if (this.addAdvDialog.title === '添加广告主') {
          data = {
            accountName: this.addAdvDialog.addForm.accountName,
            advertiserName: this.addAdvDialog.addForm.advertiserName,
            businessPrincipalId: this.addAdvDialog.addForm.businessPrincipalId,
            needInvoice: this.addAdvDialog.addForm.needInvoice,
            publicOrPrivate: this.addAdvDialog.addForm.publicOrPrivate,
            signingSubject: this.addAdvDialog.addForm.signingSubject,
            type: this.addAdvDialog.addForm.type
          }
        } else {
          data = {
            ...this.addAdvDialog.addForm
          }
        }

        console.log(data)
        let res = await advertiserApi.saveOrUpdate(data)
        if (res.data.code === '0') {
          this.fetchData()
          this.addAdvDialog.show = false
          this.$_message({
            showClose: true,
            message: '操作成功',
            type: 'success'
          })
        } else {
          this.$_message.error(res.data.message)
        }
      })
    },
    submitFile () {
      this.$refs['fileDialog'].validate(async valid => {
        if (!valid) {
          return false
        }
        let data = {
          ...this.addRecordDialog.addForm
        }
        let res = await advertiserApi.saveOrUpdatePayment(data)
        if (res.data.code === '0') {
          this.addRecordDialog.show = false
          this.getAdvertiserPaymentList(this.remittanceDialog.advertiserId)
          this.fetchData()
          this.$_message({
            showClose: true,
            message: '操作成功',
            type: 'success'
          })
        } else {
          this.$_message.error(res.data.message)
        }
      })
    },
    batchChange () {
      this.batchDialog.show = true
    },
    closeAdd (val) {
      this.$refs[val].resetFields()
    },
    add () {
      this.addAdvDialog.addForm = {
        accountName: '',
        advertiserName: '',
        businessPrincipalId: '',
        needInvoice: '',
        publicOrPrivate: '',
        signingSubject: '',
        type: ''
      }
      this.title = '添加广告主'
      this.addAdvDialog.show = true
    },
    async getDic () {
      let res = await commonApi.getDic(2)
      if (res.data.code === '0') {
        this.selectList.facilitatorList = res.data.data
      }
    },
    submitBatch () {
      this.$refs['batchForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        let res = await advertiserApi.batchUpdateBusinessPrincipal(this.batchDialog.addForm)
        if (res.data.code === '0') {
          this.batchDialog.show = false
          this.fetchData()
          this.$_message({
            showClose: true,
            message: '操作成功',
            type: 'success'
          })
        } else {
          this.$_message.error(res.data.message)
        }
      })
    },
    async fetchData () {
      try {
        this.tableLoading = true
        let data = {
          ...this.queryForm,
          pageNum: this.pagination.pageNum,
          pageSize: this.pagination.pageSize
        }
        let res = await advertiserApi.getAdvertiserList(data)
        if (res.data.code === '0') {
          this.tableLoading = false
          this.pagination.total = res.data.data.advertiserVOList.total
          this.pagination.pageNo = res.data.data.advertiserVOList.pageNum
          res.data.data.advertiserVOList.list.forEach(t => {
            t.refundAmountView = false
            if (t.productName) {
              t.productName = t.productName.replace(/\n/g, '</br>')
            }
            t.remarkView = false
          })
          this.tableData = res.data.data.advertiserVOList.list
          if (res.data.data.advertiserTotal) {
            this.summaryDailyVo = res.data.data.advertiserTotal
          }
          if (this.pagination.pageNum > 1 && this.tableData.length === 0) {
            this.pagination.pageNum = 1
            this.fetchData()
          }
        } else {
          this.tableLoading = false
        }
      } catch (error) {
        this.tableLoading = false
      }
    },
    formatNum (num) {
      // num = Number(num) / 100
      num = num.toFixed(2)
      return num
    },
    getSummaries (param) {
      // const { columns } = param
      // console.log(columns)
      const sums = []
      sums[0] = '汇总'
      sums[1] = '-'
      sums[2] = '-'
      sums[3] = '-'
      sums[4] = '-'
      sums[5] = '-'
      sums[6] = '-'
      sums[7] = '-'
      sums[8] = '-'
      sums[9] = this.summaryDailyVo.paymentAmount
      sums[10] = this.summaryDailyVo.consumeAmount
      sums[11] = this.summaryDailyVo.refundAmount
      // sums[12] = this.summaryDailyVo.balance
      // sums[12] = this.summaryDailyVo.balance
      sums[12] = '-'
      sums[13] = '-'
      sums[14] = '-'
      return sums
    },
    openEditDialog (row) {
      this.addAdvDialog.addForm = {
        id: row.id,
        accountName: row.accountName,
        advertiserName: row.advertiserName,
        businessPrincipalId: row.businessPrincipalId + '',
        needInvoice: row.needInvoice,
        publicOrPrivate: row.publicOrPrivate,
        signingSubject: row.signingSubject,
        type: row.type
      }
      this.addAdvDialog.title = '编辑广告主'
      this.addAdvDialog.show = true
    },
    tableHover (val) {

    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label
          // content: TABLE_TITLE_TIP[column.property]
          // content: 'TABLE_TITLE_TIP[column.property]'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 100
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    },
    handleClearFiles () {
      this.ARPUfileList = []
      this.file = null
    },
    // 批量修改-上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
    handleUploadBefore (file) {
      // if (file.name && file.name.length > 0) {
      //   const ldot = file.name.lastIndexOf('.')
      //   const type = file.name.toLowerCase().substring(ldot)
      //   if (type !== '.csv') {
      //     this.$_message.warning('目前只支持.csv格式的文件')
      //     return false
      //   }
      //   this.uploadFileName = file.name
      //   console.log(this.uploadFileName)
      // }
    },
    // 批量修改-文件上传成功时的钩子
    handleUploadSuccess (response, file, fileList) {
      console.log('上传成功')
      this.uploadTagVisible = true
    },
    // 批量修改-文件上传失败时的钩子
    handleUploadError (err, file, fileList) {
      if (err.status === 404) {
        this.$_message.error('上传失败，网络连接异常!')
      } else {
        console.log(err)
        this.$_message.error('上传失败!')
      }
    },
    // 导入项目-文件上传时的钩子
    handleUploadProgress (event, file, fileList) {
      console.log('上传中...')
    },
    async handleUploadChange (file, fileList) {
      this.handleClearFiles()
      this.ARPUfileList = [file]
      this.uploadFileName = file.name
      this.file = file.raw
      this.uploading = true
      let param = new window.FormData()
      param.append('file', this.file)
      let res = await commonApi.upload(param)
      if (res.data.respCode === '1000') {
        this.addRecordDialog.addForm.imgUrl = res.data.body
        this.uploading = false
      } else {
        this.uploading = false
      }
    },
    closeFile () {
      this.$refs.fileDialog.resetFields()
      this.$refs.uploadFile && this.$refs.uploadFile.clearFiles()
      this.handleClearFiles()
    },
    async fetchUpload () {
      if (!this.file) return this.$_message.error('请先选择文件')
      this.uploading = true
      let param = new window.FormData()
      param.append('file', this.file)
      try {
        let res = await advertiserApi.productUvClickLimitImport(param)
        if (res.data.code === '0') {
          this.$_message.success('上传成功')
          this.uploading = false
          this.addRecordDialog.addForm.imgUrl = res.data.data
        } else {
          this.$_message.error(res.data.message)
          this.uploading = false
        }
      } catch (error) {
        this.uploading = false
      }
    },
    async updateInfo (row) {
      try {
        let confirm = await this.$confirm(`确认关闭该项的提醒吗?`, '提示', { type: 'warning' })
        if (confirm) {
          let data = {
            id: row.id,
            mark: row.mark,
            status: 0
          }
          let res = await advertiserApi.updateAdvertiserMonitor(data)
          if (res.data.code === '0') {
            this.$_message({
              showClose: true,
              message: '操作成功',
              type: 'success'
            })
            this.fetchMonitor(this.monitorDialog.advertiserId)
            this.fetchData()
          } else {
            this.$_message.error(res.data.message || '操作失败')
          }
        }
      } catch (error) {

      }
    },
    async openMonitor (row) {
      this.monitorDialog.advertiserName = row.advertiserName
      this.monitorDialog.advertiserId = row.id
      this.monitorDialog.show = true
      this.fetchMonitor(this.monitorDialog.advertiserId)
    },
    async fetchMonitor (id) {
      let res = await advertiserApi.getAdvertiserMonitor(id)
      if (res.data.code === '0') {
        res.data.data.forEach(t => {
          t.markView = false
        })
        this.monitorDialog.list = res.data.data
        this.monitorDialog.show = true
      } else {
        this.$_message({
          showClose: true,
          message: res.data.message,
          type: 'error'
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .isRed {
    color:red
  }
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14{
    padding-left:8px;
    font-size:14px
  }
</style>
