<template>
  <div>
    <el-form label-width="120px"
             class="query-form"
             :model="queryForm">
      <el-form-item label="平台名称"
                    size="small"
                    inline>
        <el-radio-group v-model="queryForm.platform"
                        @change="getWebConfig">
          <el-radio :label="item.id"
                    v-for="item in platformList"
                    :key="item.id">{{item.name}}</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="端">
        <el-radio-group v-model="queryForm.item">
          <el-radio :label="1">官网</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item>
        <el-button type="primary"
                   size="mini"
                   @click="createConfig()">新建</el-button>
        <el-button type="primary"
                   size="mini"
                   @click="publishConfig()">发布</el-button>
        <span class="font">新建、修改操作后，点击发布才会生效。</span>
      </el-form-item>
    </el-form>
    <AddNotice :pageData="pageData"
               :platformName="platformName"
               :platform="queryForm.platform"
               :opeanLinkList="opeanLinkList"></AddNotice>
  </div>
</template>

<script>
import AddNotice from './components/AddNotice'
import { platform } from '../../assets/config'
import websiteApi from '../../api/incomeApi/website.js'
export default {
  data () {
    return {
      platformList: platform.platformList,
      queryForm: {
        platform: 1, // 平台id
        item: 1 // 端id
      },
      pageData: [],
      platformName: '花钱无忧',
      opeanLinkList: []
    }
  },
  mounted () {
    this.getWebConfig()
    this.getNoticeLink()
  },
  methods: {
    // 查询官网首页信息(网站查询)
    async getWebConfig () {
      this.pageData = []
      let platformList = this.platformList
      let platform = this.queryForm.platform
      for (let i = 0; i < platformList.length; i++) {
        if (platformList[i].id === platform) {
          this.platformName = platformList[i].name
          break
        }
      }
      let res = await websiteApi.getWebConfigApi(this.queryForm)
      let data = res.data || {}
      if (data.respCode === '1000') {
        this.pageData = data.body
      } else {
        this.$message.error(data.respMsg || data.message)
      }
    },
    // 查询公告链接
    async getNoticeLink () {
      // 默认查所有的，每次切换不用再查
      let res = await websiteApi.getNoticeLinkApi({ platform: '', item: 1 })
      let data = res.data || {}
      if (data.respCode === '1000') {
        this.opeanLinkList = data.body
      } else {
        this.$message.error(data.respMsg || data.message)
      }
    },
    // 新建
    createConfig () {
      // 若未查询到公告链接，补偿机制
      if (this.opeanLinkList.length < 0) {
        this.getNoticeLink()
      }
      if (this.pageData.length < 5) {
        this.pageData.push({
          id: '',
          imgLink: '',
          isOpean: 1,
          item: 1,
          noticeTitle: '',
          opeanLink: '',
          platform: this.queryForm.platform,
          seq: 0
        })
      } else {
        this.$message.error('每个平台名称每个端最多添加5个配置内容')
      }
    },
    // 发布
    publishConfig () {
      this.$confirm('发布后会立即生效，确认要发布吗？', '发布确认', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.publishWebConfig()
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消发布'
        })
      })
    },
    async publishWebConfig () {
      let res = await websiteApi.publishWebConfigApi({ item: 1, platform: 0 })
      let data = res.data || {}
      if (data.respCode === '1000') {
        this.$message({
          type: 'success',
          message: '发布成功！1s后刷新..'
        })
        setTimeout(() => {
          window.location.reload()
        }, 1000)
      } else {
        this.$message.error(data.respMsg || data.message)
      }
    }
  },
  components: {
    AddNotice
  }
}
</script>

<style lang="scss" scoped>
.query-form {
  .font {
    font-size: 12px;
    color: #aaa;
    margin-left: 10px;
  }
}
</style>
