<template>
  <div
    style="display: flex;align-items: center">
    <el-checkbox-button v-model="checkAll"
                        size="mini"
                        @change="handleAllChange">
      不限
    </el-checkbox-button>
    <el-checkbox-group v-model="checked"
                       size="small"
                       @change="handleChange">
      <el-checkbox-button v-for="item in list"
                          :key="item.limitValue"
                          :label="item.limitValue">
        {{ item.limitName }}<div class="multipleChoose"></div>
      </el-checkbox-button>
    </el-checkbox-group>
    <el-radio-group
      v-model="radio"
      size="small"
      @change="changeRadio">
      <el-radio-button
        :label="8"
      >
        用户点击行为
      </el-radio-button>

      <el-radio-button
        :label="9"
      >
        用户资质
      </el-radio-button>
    </el-radio-group>
  </div>
</template>

<script>
  export default {
    props: {
      list: {
        require: true,
        type: Array,
        default: function () {
          return []
        },
      },
      default: {
        type: Array,
        default: function () {
          return []
        },
      },
    },
    data () {
      return {
        radio:null,
        checkAll: false, // 选择所有标签
        checked: [], // 复选标签数据
        returnData: [], // 最终返回的数据
      }
    },
    watch: {
      default (val) {
        if (val[0] === 0) {
          this.checkAll = true
          this.checked = []
        } else if([8,9].includes(this.default[0])){
        this.checkAll = false
        this.radio = this.default[0]
        this.checked = []
        }else {
          this.checkAll = false
          this.checked = val
        }
      },
    },
    mounted () {
      if (this.default[0] === 0) {
        this.checkAll = true
      } else if([8,9].includes(this.default[0])){
        this.checkAll = false
        this.radio = this.default[0]
        }else {
        this.checkAll = false
        this.checked = this.default
      }
    },
    methods: {
      changeRadio (val) {
        if([8,9].includes(val)) {
          this.checked = []
          this.checkAll = false
        }
        this.judgeReturn()
      },
      // 不限选项变化的时候
      handleAllChange (val) {
        if (val) {
          this.checked = []
          this.radio = null
        }
        this.judgeReturn() // 判断返回的参数
      },
      // 单选选项变化
      handleChange (value) {
        if (value.length) {
          this.checkAll = false
          this.radio = null
        }
        this.judgeReturn() // 判断返回的参数
      },
      judgeReturn () {
        this.returnData = [] // 先清空
        if (this.checkAll) {
          this.returnData.push(0)
        } else if(this.radio){
          this.returnData = [this.radio]
        } else {
          this.returnData = this.checked
        }
        this.$emit('_getvalue', this.returnData)
      },
    },
  }
</script>

<style>
  .multipleChoose {
    color: red;
    position:absolute;
    top: 0;
    right: 0;
    border-style: solid;
    border-width: 0px 0px 10px 10px;
    border-color: transparent transparent #999999 transparent;
    width: 0px;
    height: 0px;
    transform:rotate(-90deg);
  }
</style>