<template>
  <div>
    <el-form :inline="true">
      <el-form-item label="平台名称">
        <el-select v-model="queryForm.platform">
          <el-option v-for="item in platformList"
                     :key="item.idea"
                     :value="item.id"
                     :label="item.name"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="分类">
        <el-select v-model="queryForm.classify">
          <el-option value=""
                     label="全部"></el-option>
          <el-option :value="1"
                     label="官网"></el-option>
          <el-option :value="2"
                     label="APP"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label=" 链接">
        <el-input placeholder=" 链接"
                  v-model="queryForm.linkName"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary"
                   @click="onQuery">查询</el-button>
        <el-button @click="resetForm()">重置</el-button>
      </el-form-item>
    </el-form>
    <el-table :data="tableData"
              v-loading="listLoading"
              border
              stripe
              :key="classifyCode"
              highlight-current-row
              style="width:100%;"
              :max-height="tableHeight">
      <el-table-column prop="platform"
                       label="平台名称"
                       width="180">
        <template slot-scope="scope">
          {{scope.row.platform | platformToMsg}}
        </template>
      </el-table-column>
      <el-table-column prop="item"
                       label="分类"
                       width="180">
        <template slot-scope="scope">
          {{scope.row.item | sourceToMsg}}
        </template>
      </el-table-column>
      <el-table-column prop="linkName"
                       label=" 链接名称">
      </el-table-column>
      <el-table-column prop="linkAddress"
                       label=" 链接">
      </el-table-column>
      <el-table-column prop="linkTargeTitle"
                       label=" 公告内容标题">
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button size="mini"
                     @click="handleEdit(scope.row)">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog :visible.sync="dialog.show"
               title="编辑公告链接"
               width="680px">
      <el-form :model="dialog.addForm"
               ref="addForm"
               size="mini">
        <el-form-item label="分类:"
                      :label-width="dialog.width"
                      prop="classify">
          {{dialog.addForm.item | sourceToMsg}}
        </el-form-item>
        <el-form-item label="链接名称:"
                      prop="linkName"
                      :label-width="dialog.width">
          {{dialog.addForm.linkName}}
        </el-form-item>
        <el-form-item label="链接:"
                      prop="linkAddress"
                      :label-width="dialog.width">
          {{dialog.addForm.linkAddress}}
        </el-form-item>
        <el-form-item label="公告内容标题:"
                      prop="noticeTitle"
                      :label-width="dialog.width">
          <el-input :maxlength="20"
                    placeholder="最多20个字"
                    v-model="dialog.addForm.linkTargeTitle"
                    class="length-1"></el-input>
        </el-form-item>
        <el-form-item label="公告内容:"
                      required
                      prop="noticeContent"
                      :label-width="dialog.width">
          <editor-bar v-model="dialog.addForm.linkTargeContext"
                      @editorHtml="editorHtml"
                      :isClear="isClear"></editor-bar>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="dialog.show = false">取消</el-button>
        <el-button type="primary"
                   :disabled="delHtmlTag==''"
                   @click="submit">确认</el-button>
      </div>
    </el-dialog>
  </div>

</template>


<script>
import { platform } from '../../../assets/config'
import Api from '../../../api/incomeApi/asvertiserLink'
import EditorBar from '@/components/WangEditor'
export default {
  components: {
    EditorBar
  },
  data () {
    return {
      isClear: false,
      tableData: [],
      platformList: platform.platformListAll,
      queryForm: {
        platform: '',
        classify: '',
        linkName: ''
      },
      dialog: {
        show: false,
        title: '新增',
        width: '120px',
        addForm: {
          id: '',
          item: '',
          linkAddress: '',
          linkName: '',
          linkTargeContext: '',
          linkTargeContextForm: '',
          linkTargeTitle: '',
          platform: ''
        }
      },
      listLoading: false,
      classifyCode: '9',
      tableHeight: 800
    }
  },
  computed: {
    delHtmlTag () {
      return this.dialog.addForm.linkTargeContextForm.replace(/<p><br><\/p>/g, '')
    }
  },
  created () {
    this.fetchData()
  },
  methods: {
    async fetchData () {
      const { platform, classify: item, linkName: linkAddress } = this.queryForm
      const res = await Api.getNoticeLink({ platform, item, linkAddress })
      if (res.data.respCode === '1000') {
        this.tableData = res.data.body
      }
    },
    handleEdit (row) {
      this.dialog.show = true
      setTimeout(() => {
        row.linkTargeContextForm = row.linkTargeContext
        this.dialog.addForm = { ...row }
      })
    },
    editorHtml (context) {
      this.dialog.addForm.linkTargeContextForm = context
    },
    async submit () {
      const { id, linkTargeTitle, linkTargeContextForm } = this.dialog.addForm
      this.dialog.addForm.linkTargeContext = linkTargeContextForm
      const res = await Api.updateNoticeLink({ id, linkTargeTitle, linkTargeContext: linkTargeContextForm })
      if (res.data.respCode === '1000') {
        this.dialog.show = false
        this.fetchData()
        this.$_message.success('公告内容修改成功')
      } else {
        this.$_message.error(res.data.respMsg)
      }
    },
    onQuery () {
      this.fetchData()
    },
    resetForm () {
      this.queryForm = {
        platform: '',
        classify: '',
        linkName: ''
      }
    }
  }
}
</script>