<template>
  <div v-loading="isDelete"
       class="add-notice">
    <el-card v-for="(card, index) in pageData"
             :key="index">
      <el-row>
        <el-col :span="16">
          <el-form ref="cardForm"
                   :model="card"
                   :rules="rules"
                   label-width="100px"
                   size="mini">
            <el-form-item class="is-required"
                          label="图片"
                          prop="img">
              <el-upload class="upload-user-defined"
                         name="in"
                         accept="image/png, image/jpg, image/jpeg"
                         :auto-upload="false"
                         action="url"
                         :show-file-list="false"
                         :with-credentials="true"
                         :on-change="uploadImg"
                         :disabled="uploading">
                <el-button size="mini"
                           type="primary"
                           :loading="uploading"
                           @click="curIndex=index">
                  上传图片
                </el-button>
                <div slot="tip"
                     class="el-upload__tip">
                  官网在PC打开时首页banner的图片，图片大小1920*350px；仅支持jpg、jpeg、png格式的图片，不超过10M
                </div>
              </el-upload>
            </el-form-item>
            <el-form-item v-if="card.imgLink">
              <el-image :src="card.imgLink"
                        :preview-src-list="[card.imgLink]"
                        style="width: 480px;height: 87.5px;"></el-image>
              <el-button class="card-img-delete"
                         type="danger"
                         @click="deleteImg(index)">
                删除
              </el-button>
            </el-form-item>
            <el-form-item label="公告标题"
                          prop="noticeTitle">
              <el-input v-model="card.noticeTitle"
                        maxlength="20"
                        placeholder="在手机端打开时，首页轮播公告的内容，最多20个字"
                        show-word-limit></el-input>
            </el-form-item>
            <el-form-item class="is-required"
                          label="是否跳转"
                          prop="isOpean">
              <el-switch v-model="card.isOpean"
                         :active-value="1"
                         :inactive-value="2"
                         active-text="是"
                         inactive-text="否">
              </el-switch>
            </el-form-item>
            <el-form-item v-if="card.isOpean===1"
                          label="跳转链接"
                          prop="opeanLink"
                          :rules="[
                            { required: true, message: '请选择跳转链接', trigger: 'change' }
                          ]">
              <el-select v-model="card.opeanLink"
                         placeholder="请选择">
                <el-option v-for="item in opeanLinkListCur"
                           :key="item.id"
                           :label="item.linkName"
                           :value="item.linkAddress">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="排序"
                          prop="seq">
              <el-input-number v-model="card.seq"
                               controls-position="right"></el-input-number>
              <span class="el-upload__tip"
                    style="margin-left: 10px;">轮播公告的排序或banner的排序，排序越小越靠前</span>
            </el-form-item>
          </el-form>
        </el-col>
        <el-col :span="5">
          <el-button type="primary"
                     @click="saveNotice(index)">
            保存
          </el-button>
          <el-button type="danger"
                     @click="deleteNotice(index)">
            删除
          </el-button>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>
<script>
import commonApi from '../../../api/incomeApi/common.js'
import websiteApi from '../../../api/incomeApi/website.js'
export default {
  name: 'WebsiteAddNotice',
  props: {
    pageData: {
      require: true,
      type: Array,
      default: () => [],
    },
    platformName: {
      required: true,
      type: String,
    },
    platform: {
      required: true,
      type: Number,
    },
    opeanLinkList: {
      require: true,
      type: Array,
      default: () => [],
    },
  },
  data () {
    return {
      rules: {
        noticeTitle: [{ required: true, message: '请输入公告标题', trigger: 'blur' }],
        seq: [{ required: true, message: '请输入排序', trigger: ['blur', 'change'] }],
      },
      options: [
        { label: '请选择', value: '' },
        { label: '1', value: '1' },
      ],
      uploading: false, // 是否有图片正在上传
      curIndex: 0,
      isDelete: false,
    }
  },
  computed: {
    opeanLinkListCur () {
      let opeanLinkList = this.opeanLinkList
      let opeanLinkListCur = []
      let platform = this.platform
      if (opeanLinkList && opeanLinkList.length > 0) {
        for (let i = 0; i < opeanLinkList.length; i++) {
          if (opeanLinkList[i].platform === platform) {
            opeanLinkListCur.push(opeanLinkList[i])
          }
        }
      }
      return opeanLinkListCur
    },
  },
  methods: {
    // 获取pageData值
    getPageData () {
      return JSON.parse(JSON.stringify(this.pageData))
    },
    // 更新pageData值
    updatePageData (index, val) {
      this.$set(this.pageData, index, val)
    },
    // 保存公告
    saveNotice (index) {
      this.$refs['cardForm'][index].validate((valid) => {
        if (valid) {
          let data = this.pageData[index]
          if (!data.imgLink) {
            this.$message.error('请先上传图片')
            return
          }
          this.saveOrUpdateWebConfig(data, index)
        } else {
          return false
        }
      })
    },
    async saveOrUpdateWebConfig (params, index) {
      let res = await websiteApi.saveOrUpdateWebConfigApi(params)
      let data = res.data || {}
      if (data.respCode === '1000') {
        this.$message({
          message: '保存成功，发布后生效',
          type: 'success',
        })
        this.updatePageData(index, data.body)
      } else {
        this.$message.error(data.respMsg || data.message)
      }
    },
    // 删除公告
    deleteNotice (index) {
      if (this.isDelete) {
        return
      }
      this.isDelete = true
      this.$confirm('确认要删除吗？', '删除确认', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }).then(() => {
        // 删除
        let data = this.pageData[index]
        if (data.id) {
          // 已保存，调用删除接口删除
          this.deleteWebConfig(data, index)
        } else {
          this.isDelete = false
          // 未保存，只在页面删除即可
          this.deleteWebConfigSuccessCb(index)
        }
      }).catch(() => {
        this.isDelete = false
        this.$message({
          type: 'info',
          message: '已取消删除',
        })
      })
    },
    async deleteWebConfig (configData, index) {
      let res = await websiteApi.deleteWebConfigApi({ id: configData.id, deleteFlag: 1 })
      let data = res.data || {}
      if (data.respCode === '1000') {
        this.isDelete = false
        this.deleteWebConfigSuccessCb(index)
      } else {
        this.isDelete = false
        this.$message.error(data.respMsg || data.message)
      }
    },
    deleteWebConfigSuccessCb (index) {
      // 重置表单验证
      for (let i = index, l = this.pageData.length; i < l; i++) {
        this.$refs['cardForm'][i].resetFields()
      }
      this.$message({
        type: 'success',
        message: '删除成功!',
      })
      this.$delete(this.pageData, index)
    },
    // 上传图片
    async uploadImg (file) {
      try {
        let is10M = file.size / 1024 / 1024 < 10
        if (!is10M) {
          this.$message.error('图片大小不能超过10M')
          return
        }
        this.uploading = true
        let param = new window.FormData()
        param.append('file', file.raw)
        let res = await commonApi.upload(param)
        if (res.data.respCode === '1000') {
          let pageData = this.pageData
          let curIndex = this.curIndex
          pageData[curIndex].imgLink = res.data.body
          this.updatePageData(curIndex, pageData[curIndex])
          this.uploading = false
        } else {
          this.$_message.error(res.data.respMsg)
          this.uploading = false
        }
      } catch (error) {
        this.uploading = false
      }
    },
    // 删除图片
    deleteImg (index) {
      let data = this.pageData[index]
      data.imgLink = ''
      this.updatePageData(index, data)
    },
  },
}
</script>
<style lang="scss" scoped>
.add-notice {
  .el-card {
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .card-img-delete {
    position: absolute;
    top: 0;
    left: 480px;
    transform: translateX(-100%);
  }
}
</style>


