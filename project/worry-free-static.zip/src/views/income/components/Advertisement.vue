<!-- 组件说明 -->
<template>
  <div>
      <el-button type="primary" size="small" style="margin-bottom:20px;" @click="add()">新增</el-button>
      <el-table :data="tableData" v-loading="listLoading" border stripe :key="classifyCode" highlight-current-row style="width:100%;" :max-height="tableHeight">
        <el-table-column align="center" prop="id" label="链接ID">
        </el-table-column>
        <el-table-column align="center" prop="linkName" label="广告链接名称" width="100">

        </el-table-column>
        <el-table-column align="center" prop="linkAddress" label="链接地址">

        </el-table-column>
        <el-table-column align="center" prop="linkStatus" label="状态">
            <template slot-scope="scope">
                <div class="product-status">
                  <span>
                    <span v-if="!scope.row.linkStatus" style="color:green;">启用</span>
                    <span v-else style="color:red">停用</span>
                  </span>
                  <span
                    @click.capture.stop="LinkEnableDisable(scope.row)">
                    <el-switch
                    :active-value = "0"
                    :inactive-value = "1"
                    v-model="scope.row.linkStatus"
                    active-color="#13ce66"
                    inactive-color="#ff4949">
                  </el-switch>
                  </span>
                </div>
            </template>
        </el-table-column>
        <el-table-column align="center" prop="updateAt" label="最后修改时间">
           <template slot-scope="scope">
             {{scope.row.updateAt | parseTime}}
           </template>
        </el-table-column>
        <el-table-column align="center" prop="operator" label="操作人">

        </el-table-column>
        <el-table-column align="center" prop="classifySort" label="操作">
          <template slot-scope="scope">
            <el-button size="mini" type="primary" @click="edit(scope.row)">编辑</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNum" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>

      <el-dialog :visible.sync="dialog.show" :title="dialog.title + '广告链接'" @close="closeDialog" width="680px">
       <el-form :model="dialog.addForm" ref="addForm" size="mini" :rules="dialog.addRules">
         <el-form-item label="广告链接名称:" :label-width="dialog.width" prop="linkName">
           <el-input :maxlength="15" placeholder="限15个字" v-model="dialog.addForm.linkName" class="length-1"></el-input>
           <span class="font-info"> 限15个字</span>
         </el-form-item>
         <el-form-item label="链接地址:" prop="linkAddress" :label-width="dialog.width">
           <el-input v-model="dialog.addForm.linkAddress" class="length-1"></el-input>
         </el-form-item>
         <el-form-item label="状态:" prop="status" :label-width="dialog.width">
           <span style="color:#13ce66;" v-show="!dialog.addForm.linkStatus">启用</span>
           <span style="color:#ff4949;" v-show="dialog.addForm.linkStatus">停用</span>
           <el-switch
            v-model="dialog.addForm.linkStatus"
            active-color="#13ce66"
            inactive-color="#ff4949"
            :active-value="0"
            :inactive-value="1">
          </el-switch>
         </el-form-item>
       </el-form>
       <div slot="footer" class="dialog-footer">
          <el-button  @click="dialog.show = false">取消</el-button>
          <el-button type="primary" @click="submit">确认</el-button>
        </div>
     </el-dialog>
  </div>
</template>

<script>
import { parseTime } from '../../../utils/formatDate'
import Api from '../../../api/incomeApi/asvertiserLink'
export default {
  components: {

  },
  data () {
    return {
      parseTime,
      pagination: {
        pageNum: 1,
        pageSizes: [30, 50, 100],
        pageSize: 30,
        total: 0
      },
      dialog: {
        show: false,
        title: '新增',
        width: '120px',
        addRules: {
          linkAddress: [
            { required: true, message: '请填写', trigger: 'blur' }
          ],
          linkName: [
            { required: true, message: '请填写', trigger: 'blur' }
          ]
        },
        addForm: {
          id: null,
          linkStatus: 0,
          linkAddress: '',
          linkName: ''
        }
      },
      classifyCode: '9',
      uploading: false,
      listLoading: false,
      fileList: [],
      queryForm: {

      },
      tableHeight: 800,
      tableData: []
    }
  },
  created () {
    this.fetchData()
    // this.$alert(str, '以下产品的' + this.tagObj[this.classifyCode] + '尚未配置,请检查', {
    //   confirmButtonText: '我知道了',
    //   dangerouslyUseHTMLString: true,
    //   callback: action => {
    //   }
    // })
  },
  computed: {

  },
  methods: {
    edit (row) {
      this.dialog.addForm = {...row}
      this.dialog.show = true
    },
    async fetchData () {
      let data = {
        pageIndex: this.pagination.pageNum,
        pageSize: this.pagination.pageSize
      }
      const res = await Api.list(data)
      if (res.data.respCode === '1000') {
        this.tableData = res.data.body.advertsLinkVos
        this.pagination.pageNum = res.data.body.pageIndex
        this.pagination.total = res.data.body.totalCount
      }
    },

    async LinkEnableDisable (row) {
      try {
        let str = row.linkStatus ? '停用' : '启用'
        let confirm = await this.$confirm(`确认${str}该链接吗?`, '提示', { type: 'warning' })
        if (confirm) {
          let data = {
            id: row.id,
            linkStatus: row.linkStatus === 0 ? 1 : 0
          }
          let res = await Api.updateAdvertsLinkStatus(data)
          if (res.data.respCode === '1000') {
            this.$_message.success('操作成功')
            row.linkStatus = row.linkStatus === 0 ? 1 : 0
            this.fetchData()
          } else {
            this.$_message.error(res.data.respMsg || '操作失败')
          }
        }
      } catch (error) {

      }
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNum = val
      this.fetchData()
    },
    submit () {
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        // const data = {}
        let res = await Api.insertOrUpdateAdvertsLink(this.dialog.addForm)
        if (res.data.respCode === '1000') {
          this.dialog.show = false
          this.fetchData()
          this.$_message.success('操作成功')
        } else {
          this.$_message.error(res.data.respMsg)
        }
      })
    },
    add () {
      this.addForm = {
        id: null,
        linkStatus: 0,
        linkAddress: '',
        linkName: ''
      }
      this.title = '新增'
      this.dialog.show = true
    },
    closeDialog () {
      this.$refs['addForm'].resetFields()
    }
  }
}
</script>

<style lang='scss' scoped>
.length-1{
  width: 250px
}
.font-info {
  color:#999999;
  font-size: 12px
}
</style>