<template>
  <el-tabs v-model="activeName">
    <el-tab-pane label="广告链接管理"
                 name="advertisement">
      <Advertisement></Advertisement>
    </el-tab-pane>
    <el-tab-pane label="公告链接管理"
                 name="notice">
      <Notice></Notice>
    </el-tab-pane>
  </el-tabs>
</template>
<script>
import Advertisement from './components/Advertisement'
import Notice from './components/Notice'
export default {
  data () {
    return {
      activeName: 'advertisement'
    }
  },
  components: {
    Advertisement,
    Notice
  }
}
</script>