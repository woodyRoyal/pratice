<!--定时任务-->
<template>
  <div>
    <div v-if="searchView[$route.path]">
      <!-- 父tab -->
      <!-- <el-radio-group v-model="bigID" style="margin-top:10px;" size="small">
        <el-radio-button :label="item.key" v-for="(item,index) in bigTagList" :key="index">{{item.value}}</el-radio-button>
      </el-radio-group> -->
      <div>
        <span class="fs-14">投放平台：</span>
        <el-radio-group size="mini" type="card" style="display: inline-block" v-model="queryForm.platform" @change="fetchData">
          <el-radio-button style="margin:5px 0" :label="item.key" v-for="(item,index) in selectList.platformList" :key="index">{{ item.value }}</el-radio-button>
        </el-radio-group>
      </div>
      <div>
        <span class="fs-14">渠道类型：</span>
        <el-radio-group size="mini" type="card" style="display: inline-block" v-model="queryForm.typeId" @change="fetchData">
          <el-radio-button style="margin:5px 0"  :label="item.id" v-for="(item,index) in selectList.typeList" :key="index">{{ item.typeName }}</el-radio-button>
        </el-radio-group>
      </div>
      <el-form :inline="true" :model="queryForm" size="mini" class="margin-mini">
       <el-form-item label="渠道号:" label-width="80px">
         <el-input v-model="queryForm.channelName" @keyup.native.enter="fetchData()"></el-input>
       </el-form-item>
       <el-form-item label="渠道商:" label-width="80px">
         <el-select v-model="queryForm.facilitatorId" style="width:100%" filterable clearable>
            <el-option
            v-for="(item,index) in selectList.facilitatorList"
            :key="index"
            :label="item.fullName"
            :value="item.id" 
            >
            {{item.fullName}}
            </el-option>
          </el-select>
       </el-form-item>
       <el-form-item label="负责人:" label-width="80px">
         <el-select style="width:163px" v-model="queryForm.principalId" filterable clearable>
            <el-option
            v-for="(item,index) in selectList.principalList"
            :key="index"
            :label="item.principalName"
            :value="item.id"
            >
            {{item.principalName}}
            </el-option>
          </el-select>
       </el-form-item>
       </br>
       <el-form-item label="月份:" label-width="80px">
         <el-date-picker
         :clearable="false"
         style="width:163px"
        v-model="queryForm.countMonthStart"
        value-format="yyyy-MM"
        type="month"
        placeholder="起始月">
      </el-date-picker>
        ~
      <el-date-picker
      style="width:163px"
      :clearable="false"
        v-model="queryForm.countMonthEnd"
        type="month"
        value-format="yyyy-MM"
        placeholder="终止月">
      </el-date-picker>
       </el-form-item>
       <el-form-item label="">
        <el-checkbox v-model="checked" @change="fetchData()">按月汇总</el-checkbox>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="fetchData()" class="least">查询</el-button>
        <el-button type="primary" size="mini" @click="down" :loading="downLoading" class="least">导出</el-button>
        <el-button type="primary" size="mini" @click="updateList" v-if="tabButtonPerms['monthTable.lock']" class="least">提报</el-button>
      </el-form-item>
    </el-form>
    </div>
    <!--完整表格-->
    <el-table
      v-loading="tableLoading" 
      :data="tableData"
      border fit
      highlight-current-row
      stripe
      show-summary
      :summary-method="getSummaries"
      :max-height="tableMaxHeight"
      style="width:100%"
      >
      <el-table-column
        prop="countMonth"
        label="月份"
        :fixed = "tableData.length>0"
        min-width="75"
        sortable
        >
      </el-table-column>
      <el-table-column
        v-if="!checked"
        :key="0"
        prop="platform"
        label="投放平台"
        min-width="100"
      >
      <template slot-scope="scope">
        <span>
          {{platformDIC[scope.row.platform]}}
        </span>
      </template>
      </el-table-column>
      <el-table-column
        v-if="!checked"
        :key="1"
        prop="channelName"
        label="渠道号"
        min-width="100"
        >
        <template slot-scope="scope">
          <div>
            <el-popover
            placement="right"
            width="320"
            trigger="hover">
            <template>
              <div style="margin-bottom:10px">渠道号: {{hoverRow.channelName}}</div>
                <el-table :data="gridData" stripe border :show-header="false" width="100%">
                  <el-table-column  prop="name" label=""></el-table-column>
                  <el-table-column  prop="value" label=""></el-table-column>
                </el-table>
            </template>
            <i slot="reference" class="el-icon-info" @mouseenter="fetchDetail(scope.row)"></i>
          </el-popover>
          <el-popover
            placement="right"
            width="155"
            trigger="click">
                <el-form size="mini">
                  <el-form-item>
                    <el-button @click="pushDetail(scope.row)">查看30天推广数据</el-button>
                  </el-form-item>
                  <el-form-item>
                    <el-button >查看30天质量数据</el-button>
                  </el-form-item>
                </el-form>
            <!-- <el-button slot="reference" type="text" @click="openEditDialog">{{scope.row.channelName}}</el-button> -->
            <span slot="reference" class="btnText" @click="openEditDialog">{{scope.row.channelName}}</span>
          </el-popover>
          </div>
         
        </template>
      </el-table-column>

      <el-table-column
        v-if="!checked"
        :key="2"
        prop="channelType"
        label="渠道类型"
        min-width="60"
        >
      </el-table-column>
      <el-table-column
        v-if="!checked"
        :key="25"
        prop="principalName"
        label="负责人"
        min-width="50"
        >
      </el-table-column>
      
      <el-table-column
      v-if="!checked"
      :key="3"
      min-width="50"
      :render-header="renderCheck"
      >
      <template slot-scope="scope"> 
        <el-checkbox v-model="scope.row.statusView" v-if="scope.row.status === 0" @change="changeStatus"> </el-checkbox>
      </template>
      </el-table-column>
      <el-table-column
        prop="dailyRealFee"
        label="实际支出(元)"
        :render-header="renderHeader"
        min-width="80"
        >
      </el-table-column>

      <el-table-column
        prop="adjustFee"
        label="调整上月支出差额"
        min-width="100"
      >
      <template slot-scope="scope">
        <template v-if="scope.row.status === 1">
          <span>{{scope.row.adjustFee}}</span>
        </template>
        <template v-if="scope.row.status === 0">
          <div v-if="!scope.row.adjustFeeView " @dblclick="edit(scope.row)"><span :class="scope.row.adjustFeeViewRED">{{scope.row.adjustFee}}</span><i class="el-icon-edit-outline iconBtn"></i> </div>
        <div v-if="scope.row.adjustFeeView"><el-input v-model.number="scope.row.adjustFee" size="mini" @blur="blurInput(scope.row)"> </el-input></div>
        </template>
      </template>
      </el-table-column>

      <el-table-column
        v-if="!checked"
        :key="100"
        prop="facilitatorFullName"
        label="渠道商"
        min-width="70"
      >
      </el-table-column>
      <el-table-column
      v-if="!checked"
        :key="101"
        prop="paymentName"
        label="合作方式"
        min-width="75"
      >
      </el-table-column>
      <el-table-column
        prop="payCost"
        label="付费成本"
        min-width="75"
        :render-header="renderHeader"
      >
      </el-table-column>

      <el-table-column
      v-if="!checked"
        :key="102"
        prop="highAcceptCost"
        label="最高可接受成本(媒体)"
        min-width="130"
        :render-header="renderHeader"
      >
      </el-table-column>

      <el-table-column
        prop="productClickCount"
        label="产品点击数"
        min-width="70"
        :render-header="renderHeader"
      >
      </el-table-column>

      <el-table-column
        prop="registerCount"
        label="注册"
        min-width="50"
        :render-header="renderHeader"
      >
      </el-table-column>

      <el-table-column
        prop="regAndLogSameDay"
        label="注册当日登录"
        min-width="80"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="reglogSameDayRate"
        label="注册当日登录率"
        min-width="85"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="firstLoginCount"
        label="首次登录"
        min-width="50"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="naturalLogin"
        label="自然登录"
        min-width="60"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="costLogin"
        label="付费登录数"
        min-width="75"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        v-if="!checked"
        :key="4"
        prop="terminal"
        label="投放系统"
        :render-header="renderHeader"
        min-width="70"
      >
      <template slot-scope="scope">
        <span>
          {{phoneDIC[scope.row.terminal]}}
        </span>
      </template>
      </el-table-column>
      <!-- <el-table-column
        v-if="!checked"
        prop="terminal"
        label="负责人"
        min-width="60"
      >
      </el-table-column> -->
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import VueElTooltip from '../../../components/VueElTooltip'
import renderHead from '../../../components/renderHead/renderHead.vue'
// import renderHead from './renderHead'
import dataBaseApi from '../../../api/dataBaseApi.js'
import tableApi from '../../../api/tableApi.js'
import dataBaseJson from './dataBase.js'
import TABLE_TITLE_TIP from './detailInfoJson.js'
import Moment from 'moment'
export default {
  components: {
    VueElTooltip,
    renderHead
  },
  props: {
    searchView: {
      type: Object,
      default: {

      }
    }
  },
  data () {
    return {
      tabButtonPerms: {
        'monthTable.lock': false
      },
      parentCheck: false,
      checked: false,
      timer: null,
      downLoading: false,
      centerDialogVisible: true,
      status: '已生成文件',
      tableLoading: false,
      TABLE_TITLE_TIP: TABLE_TITLE_TIP,
      isclick: false,
      hoverWidth: '300',
      editDialog: false,
      hoverRow: {

      },
      summaryMonthVo: {

      },
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      gridData: [
        {'name': '渠道类型', value: ''},
        {'name': '渠道商', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: ''},
        {'name': '平台平成', value: ''},
        {'name': '投放终端', value: ''}
      ],
      platformDIC: {
        1: '花钱无忧',
        2: '大圣钱包',
        3: '无忧钱包',
        4: '贷款王',
        5: 'H5聚合'
      },
      phoneDIC: {
        1: 'Android',
        2: 'iOS',
        3: 'iOS/Android'
      },
      queryForm: {
        countMonthStart: '',
        countMonthEnd: '',
        channelName: '',
        facilitatorId: '',
        platform: 0,
        principalId: '',
        typeId: 0
      },
      selectList: {
        platformList: dataBaseJson.platformList,
        typeList: [],
        facilitatorList: [],
        principalList: []
      },
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [30, 50, 100],
        pageSize: 30, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [],
      listLoading: false
    }
  },
  created () {
    let countDateDefault = null
    if (this.$route.params.channelName) {
      let start = Moment(new Date()).format('YYYY-MM-DD')
      let temp = new Date().getTime() - 3600 * 1000 * 24 * 30
      let end = Moment(temp).format('YYYY-MM-DD')
      this.queryForm.time = [end, start]
      this.queryForm.channelName = this.$route.params.channelName
    } else {
      countDateDefault = Moment(new Date().getTime()).format('YYYY-MM')
      this.queryForm.countMonthStart = countDateDefault
      this.queryForm.countMonthEnd = countDateDefault
    }
    this.fetchType()
    this.fetchData()
    this.fetchfacilitator()
    this.fetchprincipalList()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
    const btnKeys = ['monthTable.lock']
    btnKeys.forEach(t => {
      this.$store.state.loginUser.tabButtonPerms.forEach(j => {
        if (t === j) {
          this.tabButtonPerms[t] = true
        }
      })
    })
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {
    pageHeight () {
      if (this.searchView[this.$route.path]) {
        return 240
      } else {
        return 115
      }
    }
  },
  watch: {
    'pageHeight': function () {
      this.handleResize()
    }
  },
  methods: {
    async blurInput (row) {
      if (!/^(-)?\d+(\.\d+)?$/.test(row.adjustFee)) {
        return this.$message.error('请输入数字，支持正数、负数、小数')
      }
      let data = {
        id: row.id,
        channelName: row.channelName,
        countMonth: row.countMonth
      }
      row.adjustFee = Number(row.adjustFee)
      if (row.adjustFee >= 0) {
        row.adjustFee = row.adjustFee.toFixed(2)
      } else {
        row.adjustFee = -row.adjustFee
        console.log(row.adjustFee, '1')
        row.adjustFee = row.adjustFee.toFixed(2)
        row.adjustFee = '-' + row.adjustFee
      }
      data.adjustFee = row.adjustFee
      // console.log(+row.adjustFee, typeof row.adjustFee)

      console.log(row, row.id)
      let res = await tableApi.update(data)
      if (res.data.respCode === '1000') {
        this.$message.success('编辑成功')
        row.adjustFeeViewRED = 'isRed'
        row.adjustFeeView = false
        if (res.data.body !== null) {
          row.id = res.data.body
        }
        // this.fetchData()
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    edit (row) {
      row.adjustFeeView = true
    },
    test () {
      this.parentCheck = !this.parentCheck
    },
    async down () {
      if (this.downLoading) { return }
      this.downLoading = true
      let data = {
        channelName: this.queryForm.channelName,
        countMonthStart: this.queryForm.countMonthStart,
        countMonthEnd: this.queryForm.countMonthEnd,
        facilitatorId: this.queryForm.facilitatorId,
        principalId: this.queryForm.principalId,
        typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
        platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
        pageNum: this.pagination.pageNo,
        pageSize: this.pagination.pageSize,
        queryType: 0
      }
      let res = await tableApi.exportMonth(data)
      if (res.data.respCode === '1000') {
        if (res.data.body.downLoadFlag === 1) {
          clearInterval(this.timer)
          // let url = res.data.body.downLoadUrl.substring(3, res.data.body.downLoadUrl.length)
          // window.open(process.env.DOWN_URL + url)
          window.location.href = process.env.DOWN_URL + res.data.body.downLoadUrl
          // window.open('http://dev-img.huaqianwy.com' + res.data.body.downLoadUrl)
        }
        if (res.data.body.downLoadFlag === 0) {
          this.timer = setInterval(() => {
            this.poll()
          }, 1500)
        }
      } else {
        this.downLoading = false
        this.$message.error(res.data.respMsg)
      }
      // channelName: this.queryForm.channelName,
      // countDateHour: this.queryForm.time,
      // hour: this.queryForm.hour === '不限' ? '' : this.queryForm.hour,
      // facilitatorId: this.queryForm.facilitatorId,
      // principalId: this.queryForm.principalId,
      // typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
      // platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
      // pageNum: this.pagination.pageNo,
      // pageSize: this.pagination.pageSize
      // if (this.queryForm.hour === '不限') {
      //   hour = ''
      // } else {
      //   hour = this.queryForm.hour
      // }
      // window.location.href = '/mc/sys/img/推广明细20180906202603_19/推广明细20180906202603_19.xlsx'
      // window.location.href = process.env.BASE_API +
      // `/promotion/detail/downloadDetailListHour?channelName=${this.queryForm.channelName}&hour=${hour}` +
      // `&countDateHour=${this.queryForm.time}&facilitatorId=${this.queryForm.facilitatorId}&principalId=${this.queryForm.principalId}` +
      // `&typeId=${this.queryForm.typeId === 0 ? '' : this.queryForm.typeId}&pageNum=${this.pagination.pageNo}&pageSize=${this.pagination.pageSize}`
    },
    async poll () {
      let data = {
        isCollect: this.checked ? 1 : 0,
        channelName: this.queryForm.channelName,
        countMonthStart: this.queryForm.countMonthStart,
        countMonthEnd: this.queryForm.countMonthEnd,
        facilitatorId: this.queryForm.facilitatorId,
        principalId: this.queryForm.principalId,
        typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
        platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
        pageNum: this.pagination.pageNo,
        pageSize: this.pagination.pageSize,
        queryType: 1
      }
      let res = await tableApi.exportMonth(data)
      if (res.data.respCode === '1000') {
        if (res.data.body.downLoadFlag === 1) {
          clearInterval(this.timer)
          window.location.href = process.env.DOWN_URL + res.data.body.downLoadUrl
          this.downLoading = false
        }
      }
    },
    async fetchDetail (val) {
      this.hoverRow = val
      this.gridData = [
        {'name': '渠道类型', value: val.channelType},
        {'name': '渠道商简称', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: val.principal},
        {'name': '平台名称', value: ''},
        {'name': '投放终端', value: ''}
      ]
      let res = await dataBaseApi.hover(this.hoverRow.channelName)
      // let res = await dataBaseApi.hover('测试渠道')
      if (res.data.respCode === '1000') {
        if (!res.data.body) {
          return this.$message.error('查询寻不到渠道明细')
        }
        this.gridData[0].value = res.data.body.typeName
        this.gridData[2].value = res.data.body.mediaName
        this.gridData[1].value = res.data.body.facilitatorShortName
        this.gridData[3].value = res.data.body.paymentName
        this.gridData[4].value = res.data.body.price
        this.gridData[5].value = res.data.body.status === 1 ? '显示' : '隐藏'
        this.gridData[6].value = res.data.body.principalName
        this.gridData[7].value = res.data.body.platformName
        // {'name': '平台名称', value: this.platformDIC[val.platform]},
        // {'name': '投放终端', value: this.phoneDIC[val.terminal]}
        this.gridData[8].value = res.data.body.terminalName
      }
    },
    clearDetail () {
      this.gridData[2].value = ''
      this.gridData[3].value = ''
      this.gridData[4].value = ''
      this.gridData[5].value = ''
    },
    pushDetail (row) {
      console.log(row)
      // window.open('#/preview-data/' + this.classifyCode, JSON.stringify(this.tableData))
      window.open(`#/marketing/channelDatabase/channelDetail/${row.channelName}`)
    },
    async fetchType () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.type(data)
      if (res.data.respCode === '1000') {
        let topArr = [{id: 0, typeName: '不限'}]
        this.selectList.typeList = topArr.concat(res.data.body.list)
      }
    },
    async fetchfacilitator () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.facilitator(data)
      if (res.data.respCode === '1000') {
        this.selectList.facilitatorList = res.data.body.list
      }
    },
    async fetchprincipalList () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.principal(data)
      if (res.data.respCode === '1000') {
        this.selectList.principalList = res.data.body.list
      }
    },
    async fetchData (val) {
      try {
        this.tableLoading = true
        let data = {
          isCollect: this.checked ? 1 : 0,
          channelName: this.queryForm.channelName,
          countMonthStart: this.queryForm.countMonthStart,
          countMonthEnd: this.queryForm.countMonthEnd,
          facilitatorId: this.queryForm.facilitatorId,
          principalId: this.queryForm.principalId,
          typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
          platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
          pageNum: this.pagination.pageNo,
          pageSize: this.pagination.pageSize
        }
        let res = await tableApi.reprotMonth(data)
        if (res.data.respCode === '1000') {
          this.tableLoading = false
          this.pagination.total = res.data.body.pageInfoRes.total
          this.pagination.pageNo = res.data.body.pageInfoRes.pageNum
          this.summaryMonthVo = res.data.body.summaryMonthVo
          res.data.body.pageInfoRes.list.forEach(t => {
            // if (t.adjustFee || t.adjustFee === 0) { t.adjustFee = this.formatNum(t.adjustFee) }
            if (t.adjustFee && t.adjustFee > 0) {
              t.adjustFee = this.formatNum(t.adjustFee)
            } else if (t.adjustFee && t.adjustFee < 0) {
              t.adjustFee = -t.adjustFee
              t.adjustFee = t.adjustFee.toFixed(2)
              t.adjustFee = '-' + t.adjustFee
            } else if (t.adjustFee === 0) {
              t.adjustFee = this.formatNum(t.adjustFee)
            } else {

            }
            if (t.dailyRealFee || t.dailyRealFee === 0) { t.dailyRealFee = this.formatNum(t.dailyRealFee) }
            t.adjustFeeView = false
            t.adjustFeeViewRED = ''
            if (t.status === 0) {
              t.statusView = false
            }
          })
          this.tableData = res.data.body.pageInfoRes.list
          this.parentCheck = false
        } else {
          this.tableLoading = false
        }
      } catch (error) {
        this.tableLoading = false
      }
    },
    formatNum (num) {
      // num = Number(num) / 100
      num = num.toFixed(2)
      return num
    },
    openEditDialog () {
      this.hoverWidth = 150
      this.isclick = true
    },
    tableHover (val) {

    },

    getSummaries (param) {
      // const { columns } = param
      // console.log(columns)

      const sums = []

      if (!this.checked) {
        sums[0] = '汇总'
        sums[1] = '-'
        sums[2] = '-'
        sums[3] = '-'
        sums[4] = '-'
        if (this.summaryMonthVo.dailyRealFee || this.summaryMonthVo.dailyRealFee === 0) {
          sums[6] = this.formatNum(this.summaryMonthVo.dailyRealFee)
        }
        // sums[5] = this.summaryMonthVo.dailyRealFee
        if (this.summaryMonthVo.adjustFee || this.summaryMonthVo.adjustFee === 0) {
          sums[7] = this.formatNum(this.summaryMonthVo.adjustFee)
        }
        sums[8] = '-'
        sums[9] = '-'
        // if (this.summaryMonthVo.payCost || this.summaryMonthVo.payCost === 0) {
        //   sums[9] = this.formatNum(this.summaryMonthVo.payCost)
        // }
        if (this.summaryMonthVo.payCost || this.summaryMonthVo.payCost === 0) {
          sums[10] = this.formatNum(this.summaryMonthVo.payCost)
        }
        sums[11] = '-'
        sums[12] = this.summaryMonthVo.productClickCount
        sums[13] = this.summaryMonthVo.registerCount
        sums[14] = this.summaryMonthVo.regAndLogSameDay
        sums[15] = this.summaryMonthVo.reglogSameDayRate
        sums[16] = this.summaryMonthVo.firstLoginCount
        sums[17] = this.summaryMonthVo.naturalLogin
        sums[18] = this.summaryMonthVo.costLogin
        sums[19] = '-'
        sums[20] = '-'
        return sums
      }
      if (this.checked) {
        sums[0] = '汇总'
        if (this.summaryMonthVo.dailyRealFee || this.summaryMonthVo.dailyRealFee === 0) {
          sums[1] = this.formatNum(this.summaryMonthVo.dailyRealFee)
        }
        if (this.summaryMonthVo.adjustFee || this.summaryMonthVo.adjustFee === 0) {
          sums[2] = this.formatNum(this.summaryMonthVo.adjustFee)
        }
        if (this.summaryMonthVo.payCost || this.summaryMonthVo.payCost === 0) {
          sums[3] = this.formatNum(this.summaryMonthVo.payCost)
        }
        // sums[1] = this.summaryMonthVo.dailyRealFee
        // sums[2] = this.summaryMonthVo.adjustFee
        // sums[3] = this.summaryMonthVo.payCost
        sums[4] = this.summaryMonthVo.productClickCount
        sums[5] = this.summaryMonthVo.registerCount
        sums[6] = this.summaryMonthVo.regAndLogSameDay
        sums[7] = this.summaryMonthVo.reglogSameDayRate
        sums[8] = this.summaryMonthVo.firstLoginCount
        sums[9] = this.summaryMonthVo.naturalLogin
        sums[10] = this.summaryMonthVo.costLogin
        return sums
      }
    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: TABLE_TITLE_TIP[column.property]
          // content: 'TABLE_TITLE_TIP[column.property]'
        }
      })
    },
    renderCheck (createElement, {column}) {
      return createElement(renderHead, {
        props: {
          checked: this.parentCheck
          // content: 'TABLE_TITLE_TIP[column.property]'

        },
        on: {
          'clickCheck': (a) => {
            this.parentCheck = a
            if (this.parentCheck) {
              let filterArr = this.tableData.filter(item => {
                return item.status === 0
              })
              filterArr.forEach(t => {
                t.statusView = true
              })
            }
            if (!this.parentCheck) {
              let filterArr = this.tableData.filter(item => {
                return item.status === 0
              })
              filterArr.forEach(t => {
                t.statusView = false
              })
            }
          }
        }
      })
    },
    async updateList () {
      let filterArr = this.tableData.filter(item => {
        return item.status === 0
      })
      let ids = []
      filterArr.forEach(t => {
        if (t.statusView === true) {
          ids.push({channelName: t.channelName, countMonth: t.countMonth})
        }
      })
      if (ids.length === 0) {
        return this.$message.warning('请至少勾选一条记录！')
      }
      try {
        let data = {
          lockList: ids
        }
        let confirm = await this.$confirm(`提报成功后，数据不能修改，请确认是否提报!`, '提示', { type: 'warning' })
        if (confirm) {
          let res = await tableApi.lock(data)
          if (res.data.respCode === '1000') {
            this.$message.success('提报成功')
            this.fetchData()
          } else {
            this.$message.error(res.data.respMsg)
          }
        }
      } catch (error) {
        this.$message.warning('取消提报')
      }
    },
    changeStatus (val) {
      let filterArr = this.tableData.filter(item => {
        return item.status === 0
      })
      let parentCheck = true
      filterArr.forEach(t => {
        if (t.statusView === false) {
          parentCheck = false
        }
      })
      this.parentCheck = parentCheck
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - this.pageHeight
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14{
    padding-left:8px;
    font-size:14px
  }
  .iconBtn{
    font-size: 16px;
    cursor: pointer;
  }
  .isRed {
    color: red
  }
</style>
