<!--定时任务-->
<template>
  <div>
    <div v-if="searchView[$route.path]">
      <!-- 父tab -->
      <!-- <el-radio-group v-model="bigID" style="margin-top:10px;" size="small">
        <el-radio-button :label="item.key" v-for="(item,index) in bigTagList" :key="index">{{item.value}}</el-radio-button>
      </el-radio-group> -->
      <div>
        <span class="fs-14">投放平台：</span>
        <el-radio-group size="mini" type="card" style="display: inline-block" v-model="queryForm.platform" @change="fetchData">
          <el-radio-button style="margin:5px 0" :label="item.key" v-for="(item,index) in selectList.platformList" :key="index">{{ item.value }}</el-radio-button>
        </el-radio-group>
      </div>
      <div>
        <span class="fs-14">渠道类型：</span>
        <el-radio-group size="mini" type="card" style="display: inline-block" v-model="queryForm.typeId" @change="fetchData">
          <el-radio-button style="margin:5px 0"  :label="item.id" v-for="(item,index) in selectList.typeList" :key="index">{{ item.typeName }}</el-radio-button>
        </el-radio-group>
      </div>
      <el-form :inline="true" :model="queryForm" size="mini" class="margin-mini">
       <el-form-item label="渠道号:" label-width="80px">
         <el-input v-model="queryForm.channelName" @keyup.native.enter="fetchData()"></el-input>
       </el-form-item>
       <el-form-item label="渠道商:" label-width="80px">
         <el-select v-model="queryForm.facilitatorId" style="width:100%" filterable clearable>
            <el-option
            v-for="(item,index) in selectList.facilitatorList"
            :key="index"
            :label="item.fullName"
            :value="item.id"
            >
            {{item.fullName}}
            </el-option>
          </el-select>
       </el-form-item>
       <el-form-item label="负责人:" label-width="80px">
         <el-select style="width:163px" v-model="queryForm.principalId" filterable clearable>
            <el-option
            v-for="(item,index) in selectList.principalList"
            :key="index"
            :label="item.principalName"
            :value="item.id"
            >
            {{item.principalName}}
            </el-option>
          </el-select>
       </el-form-item>
       </br>
       <el-form-item label="推广时间:" label-width="80px">
         <el-date-picker
            v-model="queryForm.time"
            type="daterange"
            range-separator="至"
            :clearable="false"
            start-placeholder="开始日期"
            value-format="yyyy-MM-dd"
            :picker-options="pickerOptions"
            end-placeholder="结束日期">
          </el-date-picker>
       </el-form-item>
       <el-form-item label="">
        <el-checkbox v-model="checked" @change="changeChecked">按天汇总</el-checkbox>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="fetchData()" class="least">查询</el-button>
        <el-button type="primary" size="mini" @click="down" :loading="downLoading" class="least">导出</el-button>
        <!-- <el-button type="primary" size="mini" @click="down" :loading="downLoading">更新数据</el-button> -->
      </el-form-item>
    </el-form>
    </div>
    <!--表格-->
    <el-table
      v-loading="tableLoading" 
      :data="tableData"
      border fit
      highlight-current-row
      stripe
      show-summary
      :summary-method="getSummaries"
      :max-height="tableMaxHeight"
      style="width:100%"
      >
      <el-table-column
        prop="countDate"
        label="日期"
        :fixed = "tableData.length>0"
        min-width="80"
        sortable
        >
      </el-table-column>
      <el-table-column
        v-if="!checked"
        :key="0"
        prop="platform"
        label="投放平台"
        min-width="80"
      >
      <template slot-scope="scope">
        <span>
          {{platformDIC[scope.row.platform]}}
        </span>
      </template>
      </el-table-column>
      <el-table-column
        v-if="!checked"
        :key="1"
        prop="channelName"
        label="渠道号"
        min-width="100"
        >
        <template slot-scope="scope">
          <div>
            <el-popover
            placement="right"
            width="320"
            trigger="hover">
            <template>
              <div style="margin-bottom:10px">渠道号: {{hoverRow.channelName}}</div>
                <el-table :data="gridData" stripe border :show-header="false" width="100%">
                  <el-table-column  prop="name" label=""></el-table-column>
                  <el-table-column  prop="value" label=""></el-table-column>
                </el-table>
            </template>
            <i slot="reference" class="el-icon-info" @mouseenter="fetchDetail(scope.row)"></i>
          </el-popover>
          <el-popover
            placement="right"
            min-width="155"
            trigger="click">
                <el-form size="mini">
                  <el-form-item>
                    <el-button @click="pushDetail(scope.row)">查看30天推广数据</el-button>
                  </el-form-item>
                  <el-form-item>
                    <el-button >查看30天质量数据</el-button>
                  </el-form-item>
                </el-form>
            <!-- <el-button slot="reference" type="text" @click="openEditDialog">{{scope.row.channelName}}</el-button> -->
            <span slot="reference" class="btnText" @click="openEditDialog">{{scope.row.channelName}}</span>
          </el-popover>
          </div>
         
        </template>
      </el-table-column>

      <el-table-column
        v-if="!checked"
        :key="2"
        prop="channelType"
        label="渠道类型"
        min-width="75"
        >
      </el-table-column>
      <el-table-column
        prop="dailyRealFee"
        label="实际支出(元)"
        :render-header="renderHeader"
        min-width="80"
        >
      </el-table-column>

      <el-table-column
        prop="payCost"
        label="付费成本(元)"
        min-width="80"
        :render-header="renderHeader"
      >
      </el-table-column>

      <el-table-column
        prop="productClickCount"
        label="产品点击数"
        min-width="110"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="registerCount"
        label="注册"
        min-width="110"
        :render-header="renderHeader"
      >
      </el-table-column>

      <el-table-column
        prop="regAndLogSameDay"
        label="注册当日登录"
        min-width="80"
        :render-header="renderHeader"
      >
      </el-table-column>

      <el-table-column
        prop="reglogSameDayRate"
        label="注册当日登录率"
        min-width="90"
        :render-header="renderHeader"
      >
      </el-table-column>

      <el-table-column
        prop="firstLoginCount"
        label="登录"
        min-width="70"
        :render-header="renderHeader"
      >
      </el-table-column>

      <el-table-column
        prop="naturalLogin"
        label="自然登录"
        min-width="110"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        prop="costLogin"
        label="付费登录"
        min-width="60"
        :render-header="renderHeader"
      >
      </el-table-column>
      <el-table-column
        v-if="!checked"
        :key="3"
        prop="terminal"
        label="投放系统"
      >
      <template slot-scope="scope">
        <span>
          {{phoneDIC[scope.row.terminal]}}
        </span>
      </template>
      </el-table-column>
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
    
    <!-- 渠道号编辑弹窗 -->
     <!-- <el-dialog :visible.sync="editDialog" width="30%" top="20%" style="text-align:center">
       <el-form >
         <el-form-item>
           <el-button size="mini">编辑</el-button>
         </el-form-item>
         <el-form-item>
           <el-button size="mini">查看30天推广数据</el-button>
         </el-form-item>
         <el-form-item>
           <el-button size="mini">查看30天质量数据</el-button>
         </el-form-item>
       </el-form>
     </el-dialog> -->
     <!-- <el-dialog
      title="提示"
      :visible.sync="centerDialogVisible"
      :show-close = "false"
      :close-on-press-escape = "false"
      :close-on-click-modal = "false"
      width="25%"
      center>
      <template v-if="status === '生成中'">
        <span>正在生成文件...</span>
      </template>
      <template v-if="status === '生成文件失败'">
        <div class="center">生成文件失败</div>
      </template>

      <template v-if="status === '已生成文件'">
        <div class="center">已生成文件！</div>
      </template>
      <span slot="footer" class="dialog-footer" v-if="status === '生成文件失败'">
        <el-button type="primary"  size="mini" @click="centerDialogVisible = false">退出</el-button>
      </span>
      <span slot="footer" class="dialog-footer" v-if="status === '已生成文件'">
        <el-button type="primary"  size="mini">点击下载</el-button>
      </span>
    </el-dialog> -->
  </div>
</template>

<script>
import VueElTooltip from '../../../components/VueElTooltip'
import dataBaseApi from '../../../api/dataBaseApi.js'
import tableApi from '../../../api/tableApi.js'
import dataBaseJson from './dataBase.js'
import TABLE_TITLE_TIP from './detailInfoJson.js'
import Moment from 'moment'
export default {
  components: {
    VueElTooltip
  },
  props: {
    searchView: {
      type: Object,
      default: {

      }
    }
  },
  data () {
    return {
      checked: false,
      timer: null,
      downLoading: false,
      centerDialogVisible: true,
      status: '已生成文件',
      tableLoading: false,
      TABLE_TITLE_TIP: TABLE_TITLE_TIP,
      isclick: false,
      hoverWidth: '300',
      editDialog: false,
      hoverRow: {

      },
      summaryDailyVo: {

      },
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      gridData: [
        {'name': '渠道类型', value: ''},
        {'name': '渠道商', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: ''},
        {'name': '平台平成', value: ''},
        {'name': '投放终端', value: ''}
      ],
      platformDIC: {
        1: '花钱无忧',
        2: '大圣钱包',
        3: '无忧钱包',
        4: '贷款王',
        5: 'H5聚合'
      },
      phoneDIC: {
        1: 'Android',
        2: 'iOS',
        3: 'iOS/Android'
      },
      queryForm: {
        time: [],
        channelName: '',
        facilitatorId: '',
        platform: 0,
        principalId: '',
        typeId: 0
      },
      selectList: {
        platformList: dataBaseJson.platformList,
        typeList: [],
        facilitatorList: [],
        principalList: []
      },
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [30, 50, 100],
        pageSize: 30, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [],
      listLoading: false
    }
  },
  created () {
    // this.$loading()
    let countDateDefault = null
    if (this.$route.params.channelName) {
      let start = Moment(new Date()).format('YYYY-MM-DD')
      let temp = new Date().getTime() - 3600 * 1000 * 24 * 30
      let end = Moment(temp).format('YYYY-MM-DD')
      this.queryForm.time = [end, start]
      this.queryForm.channelName = this.$route.params.channelName
    } else {
      countDateDefault = Moment(new Date().getTime() - 3600 * 1000 * 24).format('YYYY-MM-DD')
      this.queryForm.time = [countDateDefault, countDateDefault]
    }
    this.fetchType()
    this.fetchData()
    this.fetchfacilitator()
    this.fetchprincipalList()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {
    pageHeight () {
      if (this.searchView[this.$route.path]) {
        return 240
      } else {
        return 115
      }
    }
  },
  watch: {
    'pageHeight': function () {
      this.handleResize()
    }
  },
  methods: {
    changeChecked () {
      this.fetchData()
    },
    async down () {
      if (this.downLoading) { return }
      this.downLoading = true
      let data = {
        isCollect: this.checked ? 1 : 0,
        channelName: this.queryForm.channelName,
        countDateStart: this.queryForm.time[0] || '',
        countDateEnd: this.queryForm.time[1] || '',
        facilitatorId: this.queryForm.facilitatorId,
        principalId: this.queryForm.principalId,
        typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
        platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
        pageNum: this.pagination.pageNo,
        pageSize: this.pagination.pageSize,
        queryType: 0
      }
      let res = await tableApi.exportDaily(data)
      if (res.data.respCode === '1000') {
        if (res.data.body.downLoadFlag === 1) {
          clearInterval(this.timer)
          // let url = res.data.body.downLoadUrl.substring(3, res.data.body.downLoadUrl.length)
          // window.open(process.env.DOWN_URL + url)
          window.location.href = process.env.DOWN_URL + res.data.body.downLoadUrl
          // window.open('http://dev-img.huaqianwy.com' + res.data.body.downLoadUrl)
        }
        if (res.data.body.downLoadFlag === 0) {
          this.timer = setInterval(() => {
            this.poll()
          }, 1500)
        }
      } else {
        this.downLoading = false
        this.$message.error(res.data.respMsg)
      }
      // channelName: this.queryForm.channelName,
      // countDateHour: this.queryForm.time,
      // hour: this.queryForm.hour === '不限' ? '' : this.queryForm.hour,
      // facilitatorId: this.queryForm.facilitatorId,
      // principalId: this.queryForm.principalId,
      // typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
      // platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
      // pageNum: this.pagination.pageNo,
      // pageSize: this.pagination.pageSize
      // if (this.queryForm.hour === '不限') {
      //   hour = ''
      // } else {
      //   hour = this.queryForm.hour
      // }
      // window.location.href = '/mc/sys/img/推广明细20180906202603_19/推广明细20180906202603_19.xlsx'
      // window.location.href = process.env.BASE_API +
      // `/promotion/detail/downloadDetailListHour?channelName=${this.queryForm.channelName}&hour=${hour}` +
      // `&countDateHour=${this.queryForm.time}&facilitatorId=${this.queryForm.facilitatorId}&principalId=${this.queryForm.principalId}` +
      // `&typeId=${this.queryForm.typeId === 0 ? '' : this.queryForm.typeId}&pageNum=${this.pagination.pageNo}&pageSize=${this.pagination.pageSize}`
    },
    async poll () {
      let data = {
        isCollect: this.checked ? 1 : 0,
        channelName: this.queryForm.channelName,
        countDateStart: this.queryForm.time[0] || '',
        countDateEnd: this.queryForm.time[1] || '',
        facilitatorId: this.queryForm.facilitatorId,
        principalId: this.queryForm.principalId,
        typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
        platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
        pageNum: this.pagination.pageNo,
        pageSize: this.pagination.pageSize,
        queryType: 1
      }
      let res = await tableApi.exportDaily(data)
      if (res.data.respCode === '1000') {
        if (res.data.body.downLoadFlag === 1) {
          clearInterval(this.timer)
          window.location.href = process.env.DOWN_URL + res.data.body.downLoadUrl
          this.downLoading = false
        }
      }
    },
    async fetchDetail (val) {
      this.hoverRow = val
      this.gridData = [
        {'name': '渠道类型', value: val.channelType},
        {'name': '渠道商简称', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: val.principal},
        {'name': '平台名称', value: ''},
        {'name': '投放终端', value: ''}
      ]
      let res = await dataBaseApi.hover(this.hoverRow.channelName)
      // let res = await dataBaseApi.hover('测试渠道')
      if (res.data.respCode === '1000') {
        if (!res.data.body) {
          return this.$message.error('查询寻不到渠道明细')
        }
        this.gridData[0].value = res.data.body.typeName
        this.gridData[2].value = res.data.body.mediaName
        this.gridData[1].value = res.data.body.facilitatorShortName
        this.gridData[3].value = res.data.body.paymentName
        this.gridData[4].value = res.data.body.price
        this.gridData[5].value = res.data.body.status === 1 ? '显示' : '隐藏'
        this.gridData[6].value = res.data.body.principalName
        this.gridData[7].value = res.data.body.platformName
        // {'name': '平台名称', value: this.platformDIC[val.platform]},
        // {'name': '投放终端', value: this.phoneDIC[val.terminal]}
        this.gridData[8].value = res.data.body.terminalName
      }
    },
    clearDetail () {
      this.gridData[2].value = ''
      this.gridData[3].value = ''
      this.gridData[4].value = ''
      this.gridData[5].value = ''
    },
    pushDetail (row) {
      console.log(row)
      // window.open('#/preview-data/' + this.classifyCode, JSON.stringify(this.tableData))
      window.open(`#/marketing/channelDatabase/channelDetail/${row.channelName}`)
    },
    async fetchType () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.type(data)
      if (res.data.respCode === '1000') {
        let topArr = [{id: 0, typeName: '不限'}]
        this.selectList.typeList = topArr.concat(res.data.body.list)
      }
    },
    async fetchfacilitator () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.facilitator(data)
      if (res.data.respCode === '1000') {
        this.selectList.facilitatorList = res.data.body.list
      }
    },
    async fetchprincipalList () {
      let data = {
        pageNum: 1,
        pageSize: 1000,
        status: 1
      }
      let res = await dataBaseApi.principal(data)
      if (res.data.respCode === '1000') {
        this.selectList.principalList = res.data.body.list
      }
    },
    async fetchData (val) {
      try {
        this.tableLoading = true
        let data = {
          isCollect: this.checked ? 1 : 0,
          channelName: this.queryForm.channelName,
          countDateStart: this.queryForm.time[0] || '',
          countDateEnd: this.queryForm.time[1] || '',
          facilitatorId: this.queryForm.facilitatorId,
          principalId: this.queryForm.principalId,
          typeId: this.queryForm.typeId === 0 ? '' : this.queryForm.typeId,
          platform: this.queryForm.platform === 0 ? '' : this.queryForm.platform,
          pageNum: this.pagination.pageNo,
          pageSize: this.pagination.pageSize
        }
        let res = await tableApi.reprotDaily(data)
        if (res.data.respCode === '1000') {
          this.tableLoading = false
          this.pagination.total = res.data.body.pageInfoRes.total
          this.pagination.pageNo = res.data.body.pageInfoRes.pageNum
          // this.pagination.pageSize = res.data.body.pageSize
          this.summaryDailyVo = res.data.body.summaryDailyVo
          res.data.body.pageInfoRes.list.forEach(t => {
            if (t.dailyRealFee || t.dailyRealFee === 0) { t.dailyRealFee = this.formatNum(t.dailyRealFee) }
            if (t.payCost || t.payCost === 0) { t.payCost = this.formatNum(t.payCost) }
          })
          this.tableData = res.data.body.pageInfoRes.list
        } else {
          this.tableLoading = false
        }
      } catch (error) {
        this.tableLoading = false
      }
    },
    formatNum (num) {
      // num = Number(num) / 100
      num = num.toFixed(2)
      return num
    },
    getSummaries (param) {
      // const { columns } = param
      // console.log(columns)
      const sums = []
      if (!this.checked) {
        sums[0] = '汇总'
        sums[1] = '-'
        sums[2] = '-'
        sums[3] = '-'
        if (this.summaryDailyVo.dailyRealFee || this.summaryDailyVo.dailyRealFee === 0) {
          sums[4] = this.formatNum(this.summaryDailyVo.dailyRealFee)
        }
        if (this.summaryDailyVo.payCost || this.summaryDailyVo.payCost === 0) {
          sums[5] = this.formatNum(this.summaryDailyVo.payCost)
        }
        sums[6] = this.summaryDailyVo.productClickCount
        sums[7] = this.summaryDailyVo.registerCount
        sums[8] = this.summaryDailyVo.regAndLogSameDay
        sums[9] = this.summaryDailyVo.reglogSameDayRate
        sums[10] = this.summaryDailyVo.firstLoginCount
        sums[11] = this.summaryDailyVo.naturalLogin
        sums[12] = this.summaryDailyVo.costLogin
        sums[13] = '-'
        return sums
      }
      if (this.checked) {
        sums[0] = '汇总'
        if (this.summaryDailyVo.dailyRealFee || this.summaryDailyVo.dailyRealFee === 0) {
          sums[1] = this.formatNum(this.summaryDailyVo.dailyRealFee)
        }
        if (this.summaryDailyVo.payCost || this.summaryDailyVo.payCost === 0) {
          sums[2] = this.formatNum(this.summaryDailyVo.payCost)
        }
        sums[3] = this.summaryDailyVo.productClickCount
        sums[4] = this.summaryDailyVo.registerCount
        sums[5] = this.summaryDailyVo.regAndLogSameDay
        sums[6] = this.summaryDailyVo.reglogSameDayRate
        sums[7] = this.summaryDailyVo.firstLoginCount
        sums[8] = this.summaryDailyVo.naturalLogin
        sums[9] = this.summaryDailyVo.costLogin
        return sums
      }
    },
    openEditDialog () {
      this.hoverWidth = 150
      this.isclick = true
    },
    tableHover (val) {

    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: TABLE_TITLE_TIP[column.property]
          // content: 'TABLE_TITLE_TIP[column.property]'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - this.pageHeight
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14{
    padding-left:8px;
    font-size:14px
  }
</style>
