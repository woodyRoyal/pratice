export default {
  platformList: [{key: 0, value: '不限'}, {key: 1, value: '花钱无忧'}, {key: 2, value: '大圣钱包'}, {key: 3, value: '无忧钱包'}, {key: 4, value: '贷款王'}, {key: 5, value: 'H5聚合页'}]
}
