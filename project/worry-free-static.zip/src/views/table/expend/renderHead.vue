/**
* 创建chekcbox表头实现全选
*/

<template>
<!-- <i class="el-icon-info"></i> -->
 <div>
    操作<el-checkbox v-model="childChecked" :indeterminate="isIndeterminate" @change="changeCheck"></el-checkbox>
 </div>
</template>

<script type="text/ecmascript-6">
  export default {
    props: {
      checked: {
        type: Boolean,
        default: false
      },
      isIndeterminate: {
        type: Boolean,
        default: false
      }
    },
    data () {
      return {
        childChecked: false
      }
    },
    watch: {
      'checked': function () {
        this.childChecked = this.checked
      },
      'childChecked': function () {
        this.$emit('changeCheck', this.childChecked)
      }
    },
    methods: {
      changeCheck (val) {
        console.log(val)
      },
      created () {
        this.childChecked = this.checked
      }
    }
  }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
  // 增加icon
  .el-table__footer-wrapper thead div, .el-table__header-wrapper thead div {
    display: inline;
  }
</style>
