<template>
  <div>
    <el-dialog title="请输入密码"
               :visible.sync="showDialog">
      <el-form :model="ruleForm"
               :rules="formRules"
               ref="ruleForm"
               label-width="100px">
        <el-form-item label="旧密码"
                      prop="oldPwd">
          <el-input v-model="ruleForm.oldPwd"
                    placeholder="请输入旧密码"
                    type="password"></el-input>
        </el-form-item>
        <el-form-item label="新密码"
                      prop="newPwd">
          <el-input v-model="ruleForm.newPwd"
                    placeholder="请输入新密码"
                    type="password"></el-input>
        </el-form-item>
        <el-form-item label="确认密码"
                      prop="sureNewPwd">
          <el-input v-model="ruleForm.sureNewPwd"
                    placeholder="请输入确认密码"
                    type="password"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="showDialog=false">取 消</el-button>
        <el-button type="primary"
                   @click="modifyPwd">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import fileApi from '../../../api/fileApi.js'
export default {
  name: 'decryptModifyPwd',
  data () {
    let validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入新密码'))
      } else {
        if (this.ruleForm.sureNewPwd !== '') {
          this.$refs.ruleForm.validateField('sureNewPwd')
        }
        callback()
      }
    }
    let validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入新密码'))
      } else if (value !== this.ruleForm.newPwd) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      showDialog: false,
      ruleForm: {
        oldPwd: '',
        newPwd: '',
        sureNewPwd: ''
      },
      formRules: {
        oldPwd: [{ required: true, message: '请输入旧密码', trigger: 'blur' }],
        newPwd: [{ required: true, validator: validatePass, trigger: 'blur' }],
        sureNewPwd: [{ required: true, validator: validatePass2, trigger: 'blur' }]
      }
    }
  },
  methods: {
    show () {
      this.showDialog = true
    },
    modifyPwd () {
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          fileApi.modifyPwdApi(this.ruleForm).then((res) => {
            let data = res.data || {}
            if (data.respCode === '0') {
              this.$message({
                type: 'success',
                message: '修改密码成功!'
              })
              this.showDialog = false
            }
          })
        }
      })
    }
  }
}
</script>

