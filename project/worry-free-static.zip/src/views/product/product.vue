<!--产品管理-->
<template>
  <div>
    <div class="mb-20">
      <el-button type="primary" size="small" @click="handleAdd">添加产品</el-button>
    </div>
        
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row style="width: 100%">
      <el-table-column align="center" prop="id" label="ID" width="60"></el-table-column>
      <el-table-column align="center" prop="name" label="产品名称"></el-table-column>
      <el-table-column align="center" prop="status" label="状态" min-width="100">
        <template slot-scope="scope">
          <!-- <el-tag>
            {{scope.row.status}}
          </el-tag> -->
          <span :class="scope.row.class">
            {{ statusApi[scope.row.status] }}
          </span>
          <el-button type="primary" size="mini" style="margin-left:8px;" round @click="updateProduct(scope.row)">
            {{ scope.row.status === 1 ? '停用' : '启用' }}
          </el-button>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="productLimit" label="额度"></el-table-column>
      <el-table-column align="center" prop="duration" label="期限"></el-table-column>
      <el-table-column align="center" prop="rate" label="利率" width="60"></el-table-column>
      <el-table-column align="center" prop="loanTime" label="放款时间"></el-table-column>
      <el-table-column align="center" prop="tagName" label="标签"></el-table-column>
      <el-table-column align="center" prop="remoteAddress" label="合作方H5页" min-width="280"></el-table-column>
      <el-table-column align="center" prop="" label="产品限制" width="60">
        <template slot-scope="scope">
          <el-button type="text" @click="limitEdit(scope.row)">
            编辑
          </el-button>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="" label="操作" width="60">
        <template slot-scope="scope">
          <el-button type="text" @click="editProduct(scope.row)">
            编辑
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog :title="updateTitle" :visible.sync="addDialog" top="5vh" @close="closeForm">
      <el-form ref="addForm" :model="addForm" :rules="rules">
        <el-form-item prop="name" label="产品名称" label-width="110px" >
          <el-input v-model="addForm.name" placeholder="" :maxlength="50"></el-input>
        </el-form-item>
        <el-form-item prop="productLimit" label="额度" label-width="110px" >
          <el-input v-model="addForm.productLimit" placeholder="" :maxlength="50"></el-input>
        </el-form-item>
        <el-form-item prop="duration" label="期限" label-width="110px">
          <el-input v-model="addForm.duration" placeholder=""></el-input>
        </el-form-item>
        <el-form-item prop="rate" label="利率" label-width="110px" >
          <el-input v-model="addForm.rate" placeholder="" :maxlength="50"></el-input>
        </el-form-item>
        <el-form-item prop="loanTime" label="放款时间" label-width="110px" >
          <el-input v-model="addForm.loanTime" placeholder="" :maxlength="50"></el-input>
        </el-form-item>
        <el-form-item prop="tagName" label="标签" label-width="110px" >
          <el-input v-model="addForm.tagName" placeholder=""></el-input>
        </el-form-item>
        <el-form-item prop="remoteAddress" label="合作方H5页" label-width="110px">
          <el-input v-model="addForm.remoteAddress" placeholder=""></el-input>
        </el-form-item>
        <el-form-item label="上传logo" label-width="110px">
          <div>
            <el-upload
              ref="uploadLogo"
              :with-credentials = "true"
              class="upload-demo"
              :action="URL"
              :on-remove="removeLogo"
              :on-success="uploadLogoSuccess"
              :file-list="logoList">
              <el-button size="small" type="primary">点击上传</el-button>
              <!-- <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div> -->
            </el-upload>
            <!-- <span class="fileinput-button blue-button">
              <span v-text="title"></span>
              <input type="file" @change="uploadLogo" ref="files">
            </span > -->
            <span class="tipFont">
              logo尺寸100*100
            </span>
          </div>
          <div v-if="addForm.logo !==''">
            <span class="logoImg">
            <img :src="addForm.logo" >
          </span>
          </div>
        </el-form-item>
        <el-form-item prop="remark" label="上传banner" label-width="110px">
          <div>
            <el-upload
              ref="uploadBanner"
              :on-remove="removeBanner"
              :with-credentials = "true"
              class="upload-demo"
              :action="URL"
              :on-success="uploadBannerSuccess"
              :file-list="bannerList">
              <el-button size="small" type="primary">点击上传</el-button>
              <!-- <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div> -->
            </el-upload>
            <!-- <span class="fileinput-button blue-button">
            <span v-text="title"></span>
            <input type="file" @change="uploadBanner" ref="files">
          </span> -->
          <span class="tipFont" >
            banner尺寸750*280
          </span>
          </div>
          <div v-if="addForm.banner !==''">
            <span class="bannerImg">
            <img :src="addForm.banner">
          </span>
          </div>
        </el-form-item>
      </el-form>
      <!-- 添加机构 -->
      <template>
        <div slot="footer" class="dialog-footer">
          <el-button @click="addDialog = false">取消</el-button>
          <el-button type="primary" :loading="btnLoading" @click="submitAdd">提交</el-button>
        </div>
      </template>
    </el-dialog>
    <el-dialog title="编辑产品限制" :visible.sync="limitDialog"  type="mini">
      <el-form ref="addForm" :model="addForm">
        <el-form-item prop="name" label="产品名称：" label-width="160px">
          <el-checkbox v-model="limit.Android" style="margin-left:30px;">安卓</el-checkbox>
          <el-checkbox v-model="limit.IOS">IOS</el-checkbox>
        </el-form-item>
      </el-form>
      <template>
        <div slot="footer" class="dialog-footer">
          <el-button @click="limitDialog = false">取消</el-button>
          <el-button type="primary" :loading="btnLoading" @click="handleLimit">提交</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>
<script>
  import { mapGetters } from 'vuex'
  // import axios from 'axios'
  import productApi from '../../api/product.js'
  export default {
    computed: {
      ...mapGetters([
        'userId'
      ])
    },
    data () {
      return {
        bannerList: [],
        logoList: [],
        productRow: null,
        limitRow: null,
        limit: {
          Android: false,
          IOS: false
        },
        URL: productApi['URL_UPLOAD'],
        statusApi: ['停用', '启用'],
        updateTitle: '添加产品',
        title: '点击上传',
        file: '',
        addForm: {
          banner: '',
          duration: '',
          loanTime: '',
          logo: '',
          name: '',
          productLimit: '',
          rate: '',
          remoteAddress: '',
          tagName: ''
        },
        rules: {
          // duration: [
          //   { required: true, message: '请填写产品期限', trigger: 'blur' }
          // ],
          // loanTime: [
          //   { required: true, message: '请填写放款时间', trigger: 'blur' }
          // ],
          name: [
            { required: true, message: '产品名称不能为空', trigger: 'blur' }
          ]
          // productLimit: [
          //   { required: true, message: '请填写产品额度', trigger: 'blur' }
          // ],
          // rate: [
          //   { required: true, message: '请填写产品利率', trigger: 'blur' }
          // ],
          // remoteAddress: [
          //   { required: true, message: '请填写合作方H5', trigger: 'blur' }
          // ],
          // tagName: [
          //   { required: true, message: '请填写产品标签', trigger: 'blur' }
          // ]
        },
        addDialog: false,
        limitDialog: false,
        tableData: [],
        listLoading: false,
        btnLoading: false
      }
    },
    created () {
      // console.log(axios)
      this.fetchData()
    },
    mounted () {
      // 表格高度
      // this.handleResize()
      // 监听窗口大小变化
      // window.addEventListener('resize', this.handleResize)
    },
    deactivated () {
      // window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      // window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      removeLogo () {
        this.addForm.logo = ''
      },
      removeBanner () {
        this.addForm.banner = ''
      },
      uploadBannerSuccess (response, file, fileList) {
        // console.log(response)
        if (response.respCode === '1000') {
          this.addForm.banner = response.body
        } else {
          this.$message.error(response.respMsg)
        }
      },
      uploadLogoSuccess (response, file, fileList) {
        // console.log(response)
        if (response.respCode === '1000') {
          this.addForm.logo = response.body
        } else {
          this.$message.error(response.respMsg)
        }
      },
      async fetchData () {
        this.listLoading = true
        try {
          let res = await productApi.getProducts()
          if (res.data.respCode === '1000') {
            res.data.body.forEach(t => {
              if (t.status === 0) {
                t.class = 'red'
              } else {
                t.class = 'green'
              }
            })
            this.tableData = res.data.body
            this.listLoading = false
          } else {
            this.listLoading = false
          }
        } catch (error) {
          this.listLoading = false
          console.log('cancel')
        }
      },
      closeForm () {
        this.$refs['addForm'] && this.$refs['addForm'].resetFields()
        this.$refs.uploadLogo.clearFiles()
        this.$refs.uploadBanner.clearFiles()
      },
      editProduct (row) {
        this.updateTitle = '编辑产品'
        this.productRow = row
        this.addForm = {
          banner: row.banner,
          duration: row.duration,
          loanTime: row.loanTime,
          code: row.code,
          logo: row.logo,
          name: row.name,
          productLimit: row.productLimit,
          rate: row.rate,
          remoteAddress: row.remoteAddress,
          tagName: row.tagName
        }
        this.addDialog = true
      },
      handleAdd () {
        this.updateTitle = '添加产品'
        this.addForm = {
          banner: '',
          duration: '',
          loanTime: '',
          logo: '',
          name: '',
          productLimit: '',
          rate: '',
          remoteAddress: '',
          tagName: ''
        }
        this.addDialog = true
      },
      async submitAdd () {
        // 后端要穿json 不传 formdata
        this.$refs['addForm'].validate(async valid => {
          if (!valid) {
            return false
          }
          if (this.addForm.logo === '') {
            return this.$message.error('请先上传LOGO！')
          }
          if (this.updateTitle === '添加产品') {
            try {
              let confirm = await this.$confirm(`确定提交该新建产品?`, '提示', { type: 'warning' })
              if (confirm) {
                let res = await productApi.addProduct(this.addForm)
                if (res.data.respCode === '1000') {
                  this.$message.success('操作成功')
                  this.addDialog = false
                  this.fetchData()
                } else {
                  this.$message.error(res.data.respMsg || '接口错误')
                }
              }
            } catch (error) {
              console.log(error)
            }
          } else {
            try {
              let confirm = await this.$confirm(`确定提交该编辑产品?`, '提示', { type: 'warning' })
              if (confirm) {
                let data = {
                  ...this.addForm,
                  id: this.productRow.id
                }
                let res = await productApi.update(data)
                if (res.data.respCode === '1000') {
                  this.$message.success('操作成功')
                  this.addDialog = false
                  this.fetchData()
                } else {
                  this.$message.error(res.data.respMsg || '接口错误')
                }
              }
            } catch (error) {
              // this.$message.error('接口错误')
              console.log(error)
            }
          }
        })
      },
      // async uploadLogo (evt) {
      //   const files = evt.target.files || evt.dataTransfer.files
      //   if (this.$refs.files.value === '') { return }
      //   // this.file = files[0]
      //   let formdata1 = new window.FormData()
      //   formdata1.append('logo', files[0])
      //   // let config = {
      //   //   headers: {'Content-Type': 'multipart/form-data'}
      //   // }
      //   let formApi = productApi['URL_UPLOAD']
      //   axios.post(formApi, formdata1)
      //     .then((response) => {
      //       if (response.data.respCode === '1000') {
      //         this.addForm.logo = response.data.body
      //         this.$message.success('上传成功')
      //       } else {
      //         this.addForm.logo = null
      //         this.$message.error('上传失败')
      //         this.$refs.files.value = ''
      //       }
      //     })
      //     .catch((error) => {
      //       this.$message.error('上传失败')
      //       console.log(error)
      //       this.$refs.files.value = ''
      //     })
      // },
      // uploadBanner (evt) {
      //   const files = evt.target.files || evt.dataTransfer.files
      //   if (this.$refs.files.value === '') { return }
      //   // this.file = files[0]
      //   let formdata1 = new window.FormData()
      //   formdata1.append('logo', files[0])
      //   let config = {
      //     headers: {'Content-Type': 'multipart/form-data'}
      //   }
      //   axios.post('http://172.17.16.44:10023/mc/upload/uploadImgFile', formdata1, config)
      //     .then((response) => {
      //       if (response.data.respCode === '1000') {
      //         this.addForm.banner = response.data.body
      //         this.$message.success('上传成功')
      //       } else {
      //         this.addForm.banner = null
      //         this.$message.error('上传失败')
      //         this.$refs.files.value = ''
      //       }
      //     })
      //     .catch((error) => {
      //       this.$message.error('上传失败')
      //       console.log(error)
      //       this.$refs.files.value = ''
      //     })
      // },
      async limitEdit (row) {
        if (row.limitValue === 0) {
          this.limit.Android = true
          this.limit.IOS = true
        } else if (row.limitValue === 1) {
          this.limit.Android = true
          this.limit.IOS = false
        } else if (row.limitValue === 2) {
          this.limit.Android = false
          this.limit.IOS = true
        } else {
          this.limit.Android = false
          this.limit.IOS = false
        }

        this.limitRow = row
        this.limitDialog = true
      },
      async handleLimit () {
        try {
          if (!this.limit.Android && !this.limit.IOS) {
            return this.$message.error('需至少勾选一个')
          }
          let confirm = await this.$confirm(`确定提交该产品限制?`, '提示', { type: 'warning' })
          if (confirm) {
            let data = {
              limit: 0,
              productId: this.limitRow.id
            }
            if (this.limit.Android && this.limit.IOS) {
              data.limit = 0
            } else if (this.limit.Android && !this.limit.IOS) {
              data.limit = 1
            } else {
              data.limit = 2
            }
            let res = await productApi.limitEdit(data)
            if (res.data.respCode === '1000') {
              this.tableData = res.data.body
              this.fetchData()
              this.$message.success('操作成功')
              this.limitDialog = false
            } else {
              this.$message.error('操作失败')
            }
          } else {
            this.$message({
              type: 'error',
              message: '更改失败'
            })
          }
        } catch (error) {
          console.log('cancel')
        }
      },
      async updateProduct (row) {
        if (row.status === 1) {
          try {
            let data = {
              productId: row.id,
              status: 0
            }
            let confirm = await this.$confirm('<div style="text-align:center;font-size:20px;font-weight:500;">确定停用该产品？</div> <div style="text-align:center;color:red;">请注意:页面管理中配置的该产品都会停用！</div>', '提示', {
              dangerouslyUseHTMLString: true
            })
            if (confirm) {
              let res = await productApi.enableOrDisable(data)
              if (res.data.respCode === '1000') {
                this.$message.success('操作成功')
                this.fetchData()
              } else {
                this.$message.error('操作失败')
              }
            }
          } catch (error) {
            console.log('cancel')
          }
        }

        if (row.status === 0) {
          try {
            let data = {
              productId: row.id,
              status: 1
            }
            let confirm = await this.$confirm(`确定启用该产品吗?`, '提示', { type: 'warning' })
            if (confirm) {
              let res = await productApi.enableOrDisable(data)
              if (res.data.respCode === '1000') {
                this.$message.success('操作成功')
                this.fetchData()
              } else {
                this.$message.error('操作失败')
              }
            }
          } catch (error) {
            console.log('cancel')
          }
        }
      },
      // resize回调修改表格高度
      handleResize () {
        let _this = this
        _this.debounceIdentify && clearTimeout(_this.debounceIdentity)
        _this.debounceIdentity = setTimeout(() => {
          console.log('科学防抖')
          _this.$nextTick(() => {
            let h = document.documentElement.clientHeight
            _this.tableMaxHeight = h - 160
          })
        }, 300)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .form-user-defined {
    .el-form-item {
      margin-right: 20px;
      margin-bottom: 10px;
    }
    .form-btn {
      .el-form-item {
        margin-right: 0;
      }
    }
  }

  .add-edit-user-dialog {
    .el-form-item {
      margin-bottom: 18px;
    }
    .el-select {
      width: 50%;
    }
  }

  .postscript {
    font-size: 12px;
    margin-left: 100px;
    margin-bottom: 10px;
  }

  .mb-20 {
    margin-bottom: 20px;
  }
  .fileinput-button {
    position: relative;
    display: inline-block;
    overflow: hidden;
  }
  .blue-button {
    color: #fff;
    background-color: #409eff;
    border-color: #409eff;
    padding: 0px 30px;
    font-size: 12px;
    border-radius: 3px;
  }
  .fileinput-button input {
    position: absolute;
    right: 0px;
    top: 0px;
    opacity: 0;
    -ms-filter: 'alpha(opacity=0)';
    font-size: 200px;
    cursor: pointer;
}
  .logoImg {
    display: inline-block;
    width: 100px;
    height: 100px;
    border: 1px dashed #c0ccda;
  }
  .bannerImg {
    display: inline-block;
    width: 100%;
    // height: 280px;
    border: 1px dashed #c0ccda;
  }
  img {
    width: 100%;
    height: 100%;
  }
  .tipFont {
    color: #c0ccda;
  }
  .red {
    color: red;
  }
  .green {
    color: green;
  }
</style>
