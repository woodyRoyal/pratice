<!--页面管理-->
<template>
  <div style="text-align:center">
    <div class="topBox">
      <el-radio-group v-model="tabPosition"
                      style="margin-top:30px;display:inline-block;"
                      @change="changeTab">
        <el-radio-button v-for="(item,index) in tagList"
                         :key="index"
                         :label="item.key">
          {{ item.value }}
        </el-radio-button>
      </el-radio-group>
      <!-- <input type="number" onkeypress='return( /[\d]/.test(String.fromCharCode(event.keyCode)))'> -->
    </div>
    <el-card class="box-card">
      <div>
        <el-button type="primary"
                   @click="pageSort">
          排序预览
        </el-button>
        <el-button type="primary"
                   @click="submit">
          排序提交
        </el-button>
      </div>
      <p style="color:red;font-size:12px;">
        排序框中无数字是未配置的产品。
      </p>
      <div>
        <el-table v-loading="listLoading"
                  :data="tableData"
                  border
                  fit
                  highlight-current-row
                  style="width:100%;margin-top:20px;">
          <el-table-column align="center"
                           prop="id"
                           label="ID"></el-table-column>
          <el-table-column align="center"
                           prop="name"
                           label="产品名称"></el-table-column>
          <el-table-column align="center"
                           prop="classifySort"
                           label="排序">
            <template slot-scope="scope">
              <div class="pd">
                <el-input v-model.number="scope.row.classifySort"
                          size="mini"
                          type="number"
                          onkeypress="return( /[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input>
              </div>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div>
      </div>
    </el-card>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import productApi from '../../api/product.js'
  export default {
    computed: {
      ...mapGetters([
        'userId',
      ]),
    },
    data () {
      return {
        tagList: [
          {key: 1, value: '芝麻分贷'},
          {key: 2, value: '身份证贷'},
          {key: 3, value: '大额分期'},
          {key: 4, value: '新品推荐'},
          {key: 5, value: '办信用卡'},
          {key: 6, value: '顶部banner'},
          {key: 7, value: '活动1'},
          {key: 8, value: '活动2'},
          {key: 9, value: '精选贷款'},
          // {key: 10, value: '发现'}
        ],
        tableData: [],
        tabPosition: 1,
        listLoading: false,
      }
    },
    created () {
      this.fetchData()
    },
    mounted () {
      // 表格高度
      // this.handleResize()
      // 监听窗口大小变化
      // window.addEventListener('resize', this.handleResize)
    },
    deactivated () {
      // window.removeEventListener('resize', this.handleResize)
    },
    beforeDestroy () {
      // window.removeEventListener('resize', this.handleResize)
    },
    methods: {
      async fetchData () {
        let data = {
          category: this.tabPosition,
        }
        this.listLoading = true
        try {
          let res = await productApi.listClassifyProduct(data)
          if (res.data.respCode === '1000') {
            let arrTop = []
            let arrBottom = []
            res.data.body.forEach((t) => {
              if (t.classifySort || t.classifySort === 0) { arrTop.push(t) }
              if (!t.classifySort && t.classifySort !== 0) { arrBottom.push(t) }
            })
            this.tableData = arrTop.concat(arrBottom)
            this.listLoading = false
          } else {
            this.listLoading = false
          }
        } catch (error) {
          this.listLoading = false
          console.log('cancel')
        }
      },
      async submitSort () {
        // let arr = JSON.parse(JSON.stringify(this.tableData))
        let arr = []
        this.tableData.forEach((t) => {
          if (t.classifySort === '') { t.classifySort = null }
          arr.push({
            classifyId: t.classifyId,
            classifyCode: t.classifyCode,
            classifySort: t.classifySort,
          })
        })
        let data = {
          listString: JSON.stringify(arr),
        }
        let res = await productApi.saveClassifyProduct(data)
        if (res.data.respCode === '1000') {
          this.fetchData()
          this.$message.success('提交成功')
        } else {
          this.$message.error(res.data.respMsg || '接口错误')
        }
      },
      changeTab (val) {
        this.fetchData()
      },
      pageSort () {
        let arr = []
        let arrTop = []
        let arrBottom = []
        arr = JSON.parse(JSON.stringify(this.tableData))
        console.log(arr)
        let len = arr.length
        for (let i = 0; i < len - 1; i++) {
          for (let j = 0; j < len - 1 - i; j++) {
            if (arr[j].classifySort > arr[j + 1].classifySort) { // 相邻元素两两对比
              let temp = arr[j + 1] // 元素交换
              arr[j + 1] = arr[j]
              arr[j] = temp
            }
          }
        }
        this.tableData = arr
        this.tableData.forEach((t) => {
          if (t.classifySort || t.classifySort === 0) { arrTop.push(t) }
          if (!t.classifySort && t.classifySort !== 0) { arrBottom.push(t) }
        })
        this.tableData = arrTop.concat(arrBottom)
      },
      async submit () {
        try {
          let confirm = await this.$confirm(`确定提交该排序吗?`, '提示', { type: 'warning' })
          if (confirm) {
            this.submitSort()
          } else {
            this.$message({
              type: 'error',
              message: '更改失败',
            })
          }
        } catch (error) {
          console.log('cancel')
        }
      },
      // resize回调修改表格高度
      handleResize (event) {
        let _this = this
        _this.debounceIdentify && clearTimeout(_this.debounceIdentity)
        _this.debounceIdentity = setTimeout(() => {
          console.log('科学防抖')
          _this.$nextTick(() => {
            let h = document.documentElement.clientHeight
            _this.tableMaxHeight = h - 160
          })
        }, 300)
      },
    },
  }
</script>

<style lang="scss" scoped>
  .form-user-defined {
    .el-form-item {
      margin-right: 20px;
      margin-bottom: 10px;
    }
    .form-btn {
      .el-form-item {
        margin-right: 0;
      }
    }
  }

  .add-edit-user-dialog {
    .el-form-item {
      margin-bottom: 18px;
    }
    .el-select {
      width: 50%;
    }
  }

  .postscript {
    font-size: 12px;
    margin-left: 100px;
    margin-bottom: 10px;
  }

  .mb-20 {
    margin-bottom: 20px;
  }
  .topBox {
    text-align: center;
  }
  .box-card {
    display: inline-block;
    width: 858.55px;
    min-height: 600px;
    margin-top: 30px;
  }
  .pd {
    padding: 0 10px;
  }
</style>
