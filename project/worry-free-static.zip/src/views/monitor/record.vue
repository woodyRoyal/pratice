<!--定时任务-->
<template>
  <div>
    <el-form :inline="true" :model="queryForm" size="mini">
       <el-form-item label="操作事项类:">
         <el-select v-model="queryForm.operation" clearable>
           <el-option
           v-for="(item,index) in typeList"
           :key="index"
           :value="item.id"
           :label="item.operateTypeName"
           >
           </el-option>
         </el-select>
       </el-form-item>
      <el-form-item label="日期范围" prop="">
        <!-- <el-date-picker
            v-model="time"
            value-format="yyyy-mm-dd"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期">
        </el-date-picker> -->
        <el-date-picker
            v-model="time"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            value-format="yyyy-MM-dd"
            end-placeholder="结束日期">
          </el-date-picker>
      </el-form-item>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="small" @click="handleSearch">查询</el-button>
      </el-form-item>
    </el-form>
    <!--表格-->
    <el-table :data="tableData" v-loading="listLoading" border fit highlight-current-row   stripe  :max-height="tableMaxHeight" style="width: 100%">
      <el-table-column
        prop="id"
        sortable fixed
        label="操作记录ID"
        >
      </el-table-column>

      <el-table-column
        prop="operateTypeName"
        label="操作事项"
      >
      </el-table-column>

      <el-table-column
        prop="createtime"
        label="操作时间"
        >
      </el-table-column>
      <el-table-column
        prop="username"
        label="操作人"
        >
      </el-table-column>
      
      <el-table-column
        prop="log"
        label="操作说明"
      >
      </el-table-column>
    </el-table>
    <div  class="pagination-container">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'
import monitorApi from '../../api/monitorApi.js'
import Moment from 'moment'
export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      addDialog: false,
      time: [],
      queryForm: {
        operation: '',
        startTime: '',
        endTime: ''
      },
      typeList: [],
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [30, 50, 100],
        pageSize: 30, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [],
      listLoading: false
    }
  },
  created () {
    this.fetchData()
    this.operateType()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {

  },
  methods: {
    add () {

    },
    async operateType () {
      let res = await monitorApi.operateType()
      if (res.data.respCode === '1000') {
        this.typeList = res.data.body
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    handleSearch () {
      this.fetchData()
    },
    async fetchData () {
      let operationTypeId = this.queryForm.operation === '' ? 0 : this.queryForm.operation
      let pra = {
        startTime: (this.time && this.time[0]) || '',
        endTime: (this.time && this.time[1]) || '',
        operationTypeId: operationTypeId,
        pageSize: this.pagination.pageSize,
        pageNum: this.pagination.pageNo
      }
      let res = await monitorApi.fetchTableData(pra)
      if (res.data.respCode === '1000') {
        res.data.body.list.forEach(t => {
          t.createtime = Moment(new Date(t.createtime)).format('YYYY-MM-DD HH:mm:ss')
        })
        this.pagination.pageSize = res.data.body.pageSize
        this.pagination.pageNo = res.data.body.pageNum
        this.pagination.total = res.data.body.total
        this.tableData = res.data.body.list
      } else {
        this.tableData = []
      }
    },
    openAddDialog () {
      this.addDialog = true
    },
    renderHeader (createElement, {column}) {
      return createElement(VueElTooltip, {
        props: {
          label: column.label,
          content: '这是一段对标题的说明'
        }
      })
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 120
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
