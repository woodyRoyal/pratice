<template>
  <div class="production-wrapper">
    <!--<el-radio-group v-model="tabPosition" @change="" style="margin-bottom:30px;">
      <el-radio-button :label="item.id" v-for="(item,index) in tagList" :key="index">{{item.value}}</el-radio-button>
    </el-radio-group>-->
    <!--筛选项 -->
    <el-form :inline="true"
             :model="queryForm"
             size="mini"
             class="margin-mini">
      <el-form-item label="产品ID">
        <el-input v-model.number="queryForm.id"
                  style="width:100px;"
                  onkeypress="return( /[\d]/.test(String.fromCharCode(event.keyCode)))"
                  @keyup.native.enter="getTableData()"></el-input>
      </el-form-item>
      <el-form-item label="产品名称">
        <el-input v-model="queryForm.name"
                  style="width:100px;"
                  @keyup.native.enter="getTableData()"></el-input>
      </el-form-item>
      <el-form-item label="产品状态">
        <el-select v-model="queryForm.status"
                   style="width:100px">
          <el-option value=""
                     label="全部"></el-option>
          <el-option value="0"
                     label="停用"></el-option>
          <el-option value="1"
                     label="启用"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="产品标签"
                    product-line>
        <el-select v-model="queryForm.tag"
                   style="width:100px">
          <el-option value=""
                     label="全部">
            全部
          </el-option>
          <el-option value="1"
                     label="有">
            有
          </el-option>
          <el-option value="0"
                     label="无">
            无
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="广告主">
        <el-select v-model="queryForm.advertiserId"
                   style="width:100px"
                   clearable
                   filterable>
          <el-option v-for="(item,index) in selectList.advertiserList"
                     :key="index"
                     :label="item.value"
                     :value="item.key">
            {{ item.value }}
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="是否VIP产品">
        <el-select v-model="queryForm.vip"
                   style="width:100px"
                   clearable
                   filterable>
          <el-option label="全部"
                     value=""></el-option>
          <el-option label="是"
                     :value="1"></el-option>
          <el-option label="否"
                     :value="0"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary"
                   :loading="searchLoading"
                   class="least"
                   @click="handleSearch">
          筛选
        </el-button>
        <el-button type="primary"
                   class="least"
                   @click="handleAddProduct">
          新建产品
        </el-button>
        <el-button type="primary"
                   class="least"
                   @click="batchUpload">
          批量导入导出
        </el-button>
        <el-button type="primary"
                   class="least"
                   @click="tagDialog">
          标签库管理
        </el-button>
      </el-form-item>
      <!-- <el-form-item label="产品分层、点击ARPU值:">
        <el-upload class="upload-user-defined" name="in" accept=".csv" :auto-upload='false'
                   action="uploadExcelUrl" :file-list="ARPUfileList" :show-file-list="false"
                   :with-credentials="true" ref = "upload" :disabled = "uploading" 
                   :before-upload="handleUploadBefore" :on-success="handleUploadSuccess" :on-error="handleUploadError"
                   :on-progress="handleUploadProgress" :on-change="handleUploadChange">
          <el-button size="mini" type="primary" :loading="uploading">批量导入
          </el-button>
        </el-upload> 
      </el-form-item> -->
    </el-form>
    <!-- 数据展示 -->
    <el-table v-loading="listLoading"
              stripe
              border
              :data="tableData"
              :max-height="tableHeight">
      <el-table-column label="产品ID"
                       prop="id"
                       width="50"></el-table-column>
      <el-table-column label="产品名称"
                       prop="name"></el-table-column>

      <el-table-column label="额度/元"
                       width="75">
        <template slot-scope="scope">
          <span>{{ scope.row.productLimitEnd == scope.row.productLimitStart ? scope.row.productLimitStart : scope.row.productLimitStart + '~' + scope.row.productLimitEnd }}</span>
        </template>
      </el-table-column>
      <el-table-column label="期限"
                       width="70">
        <template slot-scope="scope">
          <div v-if="scope.row.durationStart !== null && scope.row.durationStart !== ''">
            <span>{{ scope.row.durationStart == scope.row.durationEnd ? scope.row.durationStart : scope.row.durationStart + '~' + scope.row.durationEnd }}</span>
            <span>{{ scope.row.durationType == 0 ? '天' : '月' }}</span>  
          </div>
        </template>
      </el-table-column>
      <el-table-column label="息费"
                       width="115">
        <template slot-scope="scope">
          <div v-if="scope.row.rateStart !== null && scope.row.rateStart !== ''">
            <span>{{ scope.row.rateStart == scope.row.rateEnd ? scope.row.rateStart + '%' : scope.row.rateStart + '%' + '~' + scope.row.rateEnd + '%' }}</span>
            <span>{{ rateTypeList[scope.row.rateType] }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="产品标签"
                       prop="tagNames"
                       width="120">
      </el-table-column>
      <el-table-column label="广告主"
                       prop="advertiserName"></el-table-column>
      <!-- <el-table-column label="产品分层"
                       prop="productLayer"
                       width="50"></el-table-column>
      <el-table-column label="花钱无忧点击 ARPU"
                       prop="freeLoanArpu"></el-table-column>
      <el-table-column label="贷款王点击ARPU"
                       prop="dkwArpu"></el-table-column>
      <el-table-column label="立即借点击ARPU"
                       prop="ljjArpu"></el-table-column> -->
      <el-table-column label="是否VIP产品"
                       prop="vip">
        <template slot-scope="scope">
          {{ scope.row.vip? '是' : '否' }}
        </template>
      </el-table-column>
      <el-table-column label="创建时间"
                       width="120">
        <template slot-scope="scope">
          <span>{{ scope.row.createAt | parseTime }}</span>
        </template>
      </el-table-column>
      <el-table-column label="用户定向"
                       width="50">
        <template slot-scope="scope">
          <span class="imitate-a-label"
                @click="handleDirectionEdit(scope.row)">编辑</span>
        </template>
      </el-table-column>
      <el-table-column label="产品状态"
                       width="80">
        <template slot-scope="scope">
          <div class="product-status">
            <span>
              <span v-if="scope.row.status"
                    style="color:green;">启用</span>
              <span v-else
                    style="color:red">停用</span>
            </span>
            <!-- <el-button v-if="scope.row.status" type="warning" size="mini" @click="startOrStopUse(scope.row)">停用</el-button>
            <el-button v-else type="primary" size="mini" @click="startOrStopUse(scope.row)">启用</el-button> -->
            <span v-if="scope.row.status"
                  @click.capture.stop="endUse(scope.row)">
              <el-switch v-model="scope.row.status"
                         :active-value="1"
                         :inactive-value="0"
                         active-color="#13ce66"
                         inactive-color="#ff4949">
              </el-switch>
            </span>
            <!-- <el-button v-if="scope.row.status" type="warning" size="mini" @click="endUse(scope.row)">停用</el-button> -->
            <!-- <el-button v-else type="primary" size="mini" @click="startOrStopUse(scope.row)">启用</el-button> -->
          </div>
        </template>
      </el-table-column>
      <el-table-column label="链接"
                       prop="tagName"
                       width="45">
        <template slot-scope="scope">
          <span style="color:blue;cursor:pointer"
                @click="toUrlList(scope.row)">[编辑]</span>
        </template>
      </el-table-column>
      <el-table-column label="操作"
                       width="140">
        <template slot-scope="scope">
          <el-button type="primary"
                     size="mini"
                     class="least"
                     @click="handleEdit(scope.row)">
            编辑产品
          </el-button>
          <el-button type="primary"
                     size="mini"
                     class="least"
                     @click="handleAdverPicEdit(scope.row)">
            编辑素材
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div v-if="!listLoading"
         class="pagination-container">
      <el-pagination :current-page.sync="pagData.pageNum"
                     :page-sizes="pageSizes"
                     :page-size="pagData.pageSize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="totalRecord"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange">
      </el-pagination>
    </div>
    <!-- 编辑/新增弹框  -->
    <el-dialog :title="isAddOrEdit ? '新增产品' : '编辑产品'"
               :visible.sync="dialogVisibleEdit"
               :close-on-click-modal="false"
               :close-on-press-escape="false"
               width="90%"
               top="1vh"
               @close="handleEditFormClose">
      <el-form ref="addOrEditForm"
               label-width="120px"
               :model="addOrEditForm"
               :rules="AddOrEditFormRules"
               size="mini">
        <el-form-item label="广告主"
                      prop="advertiserId">
          <el-select v-model="addOrEditForm.advertiserId"
                     clearable
                     filterable>
            <el-option v-for="(item,index) in selectList.advertiserList"
                       :key="index"
                       :label="item.value"
                       :value="item.key"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="产品名称:"
                      prop="name">
          <el-input v-model="addOrEditForm.name"
                    size="small"
                    class="length-1"
                    @blur="judeIsRepeatName"></el-input>
        </el-form-item>
        <el-form-item label="副标题:"
                      prop="subhead">
          <el-input v-model="addOrEditForm.subhead"
                    size="small"
                    class="length-1"></el-input>
          <span class="font margin">最多14个字</span>
        </el-form-item>
        <el-form-item label="额度范围:"
                      prop="productLimit">
          <el-input v-model.number="addOrEditForm.productLimitStart"
                    size="small"
                    class="length-2"
                    onkeypress="return( /[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input>
          -
          <el-input v-model.number="addOrEditForm.productLimitEnd"
                    size="small"
                    class="length-2"
                    onkeypress="return( /[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input>
          元
        </el-form-item>
        <el-form-item label="期限:"
                      prop="duration">
          <el-input v-model.number="addOrEditForm.durationStart"
                    size="small"
                    class="length-2"
                    onkeypress="return( /[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input>
          -
          <el-input v-model.number="addOrEditForm.durationEnd"
                    size="small"
                    class="length-2"
                    onkeypress="return( /[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input>
          <el-radio-group v-model="addOrEditForm.durationType"
                          style="margin-left:20px;">
            <el-radio :label="0">
              天
            </el-radio>
            <el-radio :label="1">
              月
            </el-radio>
          </el-radio-group>
          <div class="font">
            若只有一个期限，则前后写成一样即可。若天、月混合的，请换算，如7-365天
          </div>
        </el-form-item>
        <el-form-item label="利率:"
                      prop="rate">
          <el-input v-model="addOrEditForm.rateStart"
                    size="small"
                    class="length-2"></el-input>
          -
          <el-input v-model="addOrEditForm.rateEnd"
                    size="small"
                    class="length-2"></el-input>
          %
          <el-radio-group v-model="addOrEditForm.rateType"
                          style="margin-left:20px;">
            <el-radio :label="2">
              每年
            </el-radio>
            <el-radio :label="1">
              每月
            </el-radio>
            <el-radio :label="0">
              每日
            </el-radio>
          </el-radio-group>
          <div class="font">
            若利率只有一个固定值，则前后写成一样即可。日利率支持三位小数，月利率支持两位小数
          </div>
        </el-form-item>
        <el-form-item label="件均金额:"
                      prop="averagePrice">
          <el-input v-model.number="addOrEditForm.averagePrice"
                    size="small"
                    class="length-1"
                    onkeypress="return( /[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input> 元
          <span class="font">(不支持小数点)</span>
        </el-form-item>
        <el-form-item label="参考通过率:"
                      prop="passRate">
          <el-input v-model.number="addOrEditForm.passRate"
                    size="small"
                    class="length-1"
                    onkeypress="return( /[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input> %
          <span class="font">(1-99之间的整数)</span>
        </el-form-item>
        <el-form-item label="放款时间:"
                      required>
          <el-col :span="8">
            <el-form-item prop="loanTime">
              <el-input v-model.number="addOrEditForm.loanTime"
                        size="small"
                        class="length-1"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item prop="loanType">
              <el-radio-group v-model="addOrEditForm.loanType"
                              style="margin-left:20px;">
                <el-radio :label="0">
                  分钟
                </el-radio>
                <el-radio :label="1">
                  小时
                </el-radio>
                <el-radio :label="2">
                  天
                </el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-form-item>
        <el-form-item label="申请说明:"
                      prop="applyTips">
          <el-input v-model="addOrEditForm.applyTips"
                    type="textarea"
                    size="small"
                    :autosize="{ minRows: 3, maxRows: 6 }"
                    class="length-area"
                    placeholder="如：1、芝麻分≥550；2、手机号实名认证，并且使用6个月以上；3、需要身份证；4、提供网络版征信报告"></el-input>
        </el-form-item>
        <el-form-item label="联系方式:"
                      prop="customPhoneType"
                      :rules="[{ required:true, message:'请选择联系方式',trigger: 'blur' }]">
          <div style="float:left">
            <el-form-item>
              <el-select v-model="addOrEditForm.customPhoneType"
                         @change="changeCustomPhoneType">
                <el-option :value="0"
                           label="客服电话"></el-option>
                <el-option :value="1"
                           label="其他客服"></el-option>
              </el-select>
            </el-form-item>
          </div>
          <div style="float:left;margin-left:15px;">
            <el-form-item prop="customPhone"
                          :rules="[{ required:true, validator:customPhone,trigger: 'blur' }]">
              <el-input v-model="addOrEditForm.customPhone"
                        style="width:220px"
                        :placeholder="customPhonePlaceholder"></el-input>
            </el-form-item>
          </div>
        </el-form-item>
        <el-form-item v-if="addOrEditProductType==='edit'"
                      label="特色标签:"
                      prop="specialTags">
          <!-- <CheckButton :list="uniqueTagList"
                       :default="addOrEditForm.specialTags"
                       @_getvalue="getSpecialTags"></CheckButton> -->
          <!-- <div class="font">
            支持复选。若无特别条件限制，请勾选多个标签或勾选“不限
          </div> -->
          <div v-if="addOrEditForm.specialTags && addOrEditForm.specialTags.length > 0">
            <el-tag v-for="tag in addOrEditForm.specialTags"
                    :key="tag"
                    effect="light"
                    size="small"
                    style="margin-right: 12px">
              {{ tag|getSpecialTagLabel }}
            </el-tag>
          </div>
          <div v-else>
            无标签
          </div>
        </el-form-item>
        <el-form-item label="办理流程:"
                      prop="applyFlow">
          <el-input v-model="addOrEditForm.applyFlow"
                    type="textarea"
                    :autosize="{ minRows: 2, maxRows: 6 }"
                    class="length-area"
                    size="small"
                    placeholder="例如：身份认证→基本资料→人脸识别→芝麻信用→运营商认证→绑定银行卡"></el-input>
        </el-form-item>
        <el-form-item label="产品标签:"
                      prop="tagIds">
          <div style="width:500px">
            <el-checkbox-group v-model="addOrEditForm.tagIds"
                               :max="2">
              <el-checkbox v-for="(item,index) in selectList.activeList"
                           :key="index"
                           :label="item.id">
                {{ item.tagName }}
              </el-checkbox>
            </el-checkbox-group>
          </div>

          <!-- <el-input size="small" class="length-1" v-model="addOrEditForm.tagName"></el-input><span class="font margin">最多6个字</span> -->
          <!-- <div class="font">该标签会在所有APP端的产品描述中均展示，若此处空白则不显示</div> -->
        </el-form-item>
        <!-- <el-form-item label="标签颜色:" prop="tagColor">
          <el-color-picker size="small" v-model="addOrEditForm.tagColor"></el-color-picker>
          <span class="font margin">最终颜色色值由设计师选定</span>
        </el-form-item> -->
        <el-form-item label="特别提示:"
                      prop="prompt">
          <el-input v-model.trim="addOrEditForm.prompt"
                    size="small"
                    class="length-1"></el-input>
          <span class="font">(列表页展示的提示，最多20个字)</span>
        </el-form-item>
        <el-form-item label="小花提示:"
                      prop="detailPrompt">
          <el-input v-model="addOrEditForm.detailPrompt"
                    type="textarea"
                    :autosize="{ minRows:4, maxRows: 10 }"
                    class="length-area"
                    size="small"></el-input>
          <span class="font">(产品详情页展示的提示，最多100个字)</span>
        </el-form-item>
        <!-- <el-form-item v-for="(item, index) in addOrEditForm.baseLinks"
                      :key="item.seqId"
                      :label="'链接' + (item.seqId) + ':'"
                      :prop="'baseLinks.' + index + '.address'"
                      :rules="[{
                          required: false,
                          trigger: 'blur',
                          validator:item.seqId === 1 || item.seqId === 2?url :null
                        }]"
                      >
                           
          <el-input size="small" class="length-1" v-model="item.address" :placeholder="'合作方H5页链接'+ (item.seqId)"></el-input>
          <span class="font-2">链接{{ item.seqId}}备注:</span>
          <el-input size="small" class="length-1" v-model="item.remark" :disabled="index === 0 || index === 1"></el-input>
           <el-checkbox v-model="item.resetFlag" v-if="!isAddOrEdit&&item.seqId ===1">保存时,使用该链接重置到"花钱无忧"所有广告位"</el-checkbox>
           <el-checkbox v-model="item.resetFlag" v-if="!isAddOrEdit&&item.seqId === 2">保存时,使用该链接重置到"贷款王"所有广告位"</el-checkbox>
          <el-button style="margin-left: 10px;" v-if="index > 0" type="danger" size="small" @click="removeEditFormLink(item.seqId)">删除</el-button>
        </el-form-item> -->
        <!-- <el-form-item>
           <el-button type="primary" size="small" @click="addEditFormLink">新增链接</el-button>
        </el-form-item> -->
        <el-form-item label="上传logo:"
                      prop="logo">
          <el-upload class="upload-demo"
                     :action="uploadUrl"
                     :file-list="fileList"
                     :show-file-list="false"
                     :on-remove="removeLogo"
                     :on-success="uploadLogoSuccess">
            <el-button size="small"
                       type="primary">
              点击上传
            </el-button>
            <span class="font">logo图片尺寸100*100px</span>
          </el-upload>
          <div v-if="addOrEditForm.logo">
            <span class="logoImg">
              <img :src="addOrEditForm.logo" />
            </span>
          </div>
        </el-form-item>
        <!-- <el-form-item label="产品状态:" prop="status">
          <el-radio-group v-model="addOrEditForm.status" :disabled="!isAddOrEdit">
            <el-radio :label="1">启用</el-radio>
            <el-radio :label="0">停用</el-radio>
          </el-radio-group>
        </el-form-item> -->
        <!-- <el-form-item label="产品分层:"
                      prop="productLayer"
                      label-width="150px">
          <el-select v-model="addOrEditForm.productLayer"
                     size="mini">
            <el-option v-for="(item,index) in productLayerList"
                       :key="index"
                       :value="item.value"
                       :label="item.key">
              {{ item.key }}
            </el-option>
          </el-select> -->
        <!-- <el-input v-model="addOrEditForm.productLayer"   class="length-area" size="small" ></el-input> -->
        <!-- </el-form-item> -->
        <!-- <el-form-item label="花钱无忧点击Arpu:"
                      prop="freeLoanArpu"
                      label-width="150px">
          <el-input v-model="addOrEditForm.freeLoanArpu"
                    class="length-area"
                    size="small"></el-input>
        </el-form-item>
        <el-form-item label="贷款王点击Arpu:"
                      prop="dkwArpu"
                      label-width="150px">
          <el-input v-model="addOrEditForm.dkwArpu"
                    class="length-area"
                    size="small"></el-input>
        </el-form-item>
        <el-form-item label="立即借Arpu:"
                      prop="ljjArpu"
                      label-width="150px">
          <el-input v-model="addOrEditForm.ljjArpu"
                    class="length-area"
                    size="small"></el-input>
        </el-form-item> -->
        <el-form-item label="用户注册协议:"
                      prop="regAgreeUrl"
                      label-width="150px"
                      :rules="[{ required: !isJointLoginProduct, validator:regAgreeUrlPass, trigger: 'blur' }]">
          <el-input v-model="addOrEditForm.regAgreeUrl"
                    class="length-area"
                    size="small"
                    :disabled="isJointLoginProduct"></el-input>
        </el-form-item>
        <el-form-item label="是否VIP产品:"
                      prop="vip"
                      label-width="150px"
                      :rules="[{ required: true, message:'请选择是否VIP产品', trigger: 'change' }]">
          <!-- <el-input v-model="addOrEditForm.vip"  class="length-area" size="small" ></el-input> -->
          <el-select v-model="addOrEditForm.vip"
                     filterable>
            <el-option label="是"
                       :value="1"></el-option>
            <el-option label="否"
                       :value="0"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-show="!isJointLoginProduct"
                      label="前置撞库开关"
                      prop="hitSwitch"
                      label-width="150px">
          <el-switch v-model="addOrEditForm.hitSwitch"
                     active-color="#13ce66"
                     inactive-color="#ff4949">
          </el-switch>
          <!-- <el-input v-model.number="urlDialog.addForm.reloanSharing" :disabled="reloanSharingDisbale" style="width:200px"></el-input>% -->
        </el-form-item>

        <el-form-item label="是否启用防盗链:"
                      prop="safeLink"
                      label-width="150px"
                      :rules="[{ required: true, message:'是否启用防盗链', trigger: 'change' }]">
          <el-select v-model="addOrEditForm.safeLink"
                     filterable>
            <el-option label="是"
                       :value="1"></el-option>
            <el-option label="否"
                       :value="0"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="dialogVisibleEdit = false">取 消</el-button>
        <el-button type="primary"
                   :loading="btnLoading"
                   @click="handleAddOrEditConfirm">确 定</el-button>
      </span>
    </el-dialog>

    <!-- 编辑用户定向dialogVisibleDirection -->
    <el-dialog :title="'编辑用户定向-' + directionName"
               :visible.sync="dialogVisibleDirection"
               :close-on-click-modal="false"
               :close-on-press-escape="false"
               :inline="true"
               @close="handleUserDirectionFormClose">
      <el-form size="mini"
               label-width="130px">
        <el-form-item label="系统模块:"
                      prop="productLayer">
          <el-select v-model="SystemModule"
                     size="mini"
                     @change="changeSystemModule">
            <el-option v-for="(value,key,index) in selectList.SystemModuleList"
                       :key="index"
                       :value="key"
                       :label="value">
              {{ value }}
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <el-form v-show="SystemModule === '0'"
               ref="userDirectionForm"
               label-width="130px"
               :model="userDirectionForm"
               :rules="userDirectionRules"
               size="mini">
        <el-form-item>
          <span style="color:red;">* 若该产品有明确提到该条件，请勾选相应条件。若未知，请勾选不限</span>
        </el-form-item>
        <el-form-item label="屏蔽省区:">
          <el-select v-model="userDirectionForm.discardProvince"
                     filterable
                     remote
                     multiple
                     size="small">
            <el-option v-for="(item) in provinceList"
                       :key="item.limitValue"
                       :label="item.limitName"
                       :value="item.limitValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="年龄:"
                      prop="age">
          <el-input-number v-model.number="userDirectionForm.age[0]"
                           size="small"
                           :controls="false"
                           onkeypress="return( /[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input-number>
          -
          <el-input-number v-model.number="userDirectionForm.age[1]"
                           size="small"
                           :controls="false"
                           onkeypress="return( /[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input-number>
        </el-form-item>
        <el-form-item label="芝麻分:"
                      prop="creditScore">
          <!-- <CheckButton :list="creditScoreList"
                       :default="userDirectionForm.creditScore"
                       @_getvalue="getCreditScore"></CheckButton> -->
          <el-radio-group v-model="userDirectionForm.creditScore">
            <el-radio-button v-for="item in creditScoreList"
                             :key="item.limitValue"
                             :label="item.limitValue">
              {{ item.limitName }}
            </el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="手机号使用时长:"
                      prop="phoneUseTime">
          <el-radio-group v-model="userDirectionForm.phoneUseTime">
            <el-radio-button v-for="item in phoneTimeList"
                             :key="item.limitValue"
                             :label="item.limitValue">
              {{ item.limitName }}
            </el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="信用卡:"
                      prop="creditCard">
          <el-radio-group v-model="userDirectionForm.creditCard">
            <el-radio-button v-for="item in creditCardList"
                             :key="item.limitValue"
                             :label="item.limitValue">
              {{ item.limitName }}
            </el-radio-button>
          </el-radio-group>
        </el-form-item>
        <!-- <el-form-item label="职业身份:"
                      prop="career">
          <CheckButton :list="careerList"
                       :default="userDirectionForm.career"
                       @_getvalue="getCareer"></CheckButton>
        </el-form-item> -->
        <!-- <el-form-item label="社保:"
                      prop="socialSecurity">
          <el-radio-group v-model="userDirectionForm.socialSecurity">
            <el-radio-button v-for="item in socialSecurityList"
                             :key="item.limitValue"
                             :label="item.limitValue">
              {{ item.limitName }}
            </el-radio-button>
          </el-radio-group>
        </el-form-item> -->
        <el-form-item label="公积金:"
                      prop="fund">
          <el-radio-group v-model="userDirectionForm.fund">
            <el-radio-button v-for="item in accumulationFundList"
                             :key="item.limitValue"
                             :label="item.limitValue">
              {{ item.limitName }}
            </el-radio-button>
          </el-radio-group>
        </el-form-item>
      </el-form>

      <el-form v-show="SystemModule === '1'"
               ref="userDirectionAPIform"
               label-width="160px"
               :model="userDirectionAPIform"
               :rules="userDirectionAPIRules"
               size="mini">
        <el-form-item label="年龄:"
                      prop="ageLimit"
                      :rules="[{ required:userDirectionAPIform.status.age === 0, validator:ageLimit , trigger: 'blur' }]">
          <el-input-number v-model.number="userDirectionAPIform.ageLimit[0]"
                           :disabled="userDirectionAPIform.status.age === 1"
                           size="small"
                           :controls="false"
                           onkeypress="return( /[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input-number>
          -
          <el-input-number v-model.number="userDirectionAPIform.ageLimit[1]"
                           :disabled="userDirectionAPIform.status.age === 1"
                           size="small"
                           :controls="false"
                           onkeypress="return( /[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input-number>
          <el-switch v-model="userDirectionAPIform.status['age']"
                     active-color="#13ce66"
                     inactive-color="#ff4949"
                     :active-value="0"
                     :inactive-value="1"
                     @change="changeSwitch"></el-switch>
          <span>
            {{ userDirectionAPIform.status['age'] === 0 ?"启用" : "停用" }}
          </span>
        </el-form-item>

        <el-form-item label="身份证号码地区屏蔽:">
          <el-select v-model="userDirectionAPIform['idCardAreaLimit']"
                     :disabled="userDirectionAPIform.status.idCardAreaLimit === 1"
                     filterable
                     remote
                     multiple
                     size="small"
                     class="length-API">
            <el-option v-for="(item) in PROVINCEString"
                       :key="item.limitValue"
                       :label="item.limitName"
                       :value="item.limitValue"></el-option>
          </el-select>
          <el-switch v-model="userDirectionAPIform.status['idCardAreaLimit']"
                     active-color="#13ce66"
                     inactive-color="#ff4949"
                     :active-value="0"
                     :inactive-value="1"></el-switch>
          <span>
            {{ userDirectionAPIform.status['idCardAreaLimit'] === 0 ?"启用" : "停用" }}
          </span>
        </el-form-item>

        <el-form-item label="身份证地址地区屏蔽:">
          <el-select v-model="userDirectionAPIform['idCardNoAreaLimit']"
                     :disabled="userDirectionAPIform.status.idCardNoAreaLimit === 1"
                     filterable
                     remote
                     multiple
                     size="small"
                     class="length-API">
            <el-option v-for="(item) in PROVINCEString"
                       :key="item.limitValue"
                       :label="item.limitName"
                       :value="item.limitValue"></el-option>
          </el-select>
          <el-switch v-model="userDirectionAPIform.status['idCardNoAreaLimit']"
                     active-color="#13ce66"
                     inactive-color="#ff4949"
                     :active-value="0"
                     :inactive-value="1"></el-switch>
          <span>
            {{ userDirectionAPIform.status['idCardNoAreaLimit'] === 0 ?"启用" : "停用" }}
          </span>
        </el-form-item>

        <el-form-item label="居住地区屏蔽:">
          <el-select v-model="userDirectionAPIform['liveAreaLimit']"
                     :disabled="userDirectionAPIform.status.liveAreaLimit === 1"
                     filterable
                     remote
                     multiple
                     size="small"
                     class="length-API">
            <el-option v-for="(item) in PROVINCEString"
                       :key="item.limitValue"
                       :label="item.limitName"
                       :value="item.limitValue"></el-option>
          </el-select>
          <el-switch v-model="userDirectionAPIform.status['liveAreaLimit']"
                     active-color="#13ce66"
                     inactive-color="#ff4949"
                     :active-value="0"
                     :inactive-value="1"></el-switch>
          <span>
            {{ userDirectionAPIform.status['liveAreaLimit'] === 0 ?"启用" : "停用" }}
          </span>
        </el-form-item>

        <el-form-item label="定位地区屏蔽:">
          <el-select v-model="userDirectionAPIform['locationAreaAreaLimit']"
                     :disabled="userDirectionAPIform.status.locationAreaAreaLimit === 1"
                     filterable
                     remote
                     multiple
                     size="small"
                     class="length-API">
            <el-option v-for="(item) in PROVINCEString"
                       :key="item.limitValue"
                       :label="item.limitName"
                       :value="item.limitValue"></el-option>
          </el-select>
          <el-switch v-model="userDirectionAPIform.status['locationAreaAreaLimit']"
                     active-color="#13ce66"
                     inactive-color="#ff4949"
                     :active-value="0"
                     :inactive-value="1"></el-switch>
          <span>
            {{ userDirectionAPIform.status['locationAreaAreaLimit'] === 0 ?"启用" : "停用" }}
          </span>
        </el-form-item>

        <el-form-item label="运营商是否实名且本人:">
          <el-select v-model="userDirectionAPIform['carrireRealNameLimit']"
                     :disabled="userDirectionAPIform.status.carrireRealNameLimit === 1"
                     size="small"
                     class="length-API">
            <el-option :key="0"
                       label="是"
                       value="1">
            </el-option>
            <el-option :key="1"
                       label="否"
                       value="2">
            </el-option>
          </el-select>
          <el-switch v-model="userDirectionAPIform.status['carrireRealNameLimit']"
                     active-color="#13ce66"
                     inactive-color="#ff4949"
                     :active-value="0"
                     :inactive-value="1"></el-switch>
          <span>
            {{ userDirectionAPIform.status['carrireRealNameLimit'] === 0 ?"启用" : "停用" }}
          </span>
        </el-form-item>

        <el-form-item label="手机号使用月份:"
                      prop="phoneUseLimit"
                      :rules="[{ required:userDirectionAPIform.status.phoneUseLimit === 0, validator:phoneUseLimit , trigger: 'blur' }]">
          <el-input v-model="userDirectionAPIform['phoneUseLimit']"
                    :disabled="userDirectionAPIform.status.phoneUseLimit === 1"
                    class="length-API"></el-input>
          <el-switch v-model="userDirectionAPIform.status['phoneUseLimit']"
                     active-color="#13ce66"
                     inactive-color="#ff4949"
                     :active-value="0"
                     :inactive-value="1"
                     @change="changeSwitch"></el-switch>
          <span>
            {{ userDirectionAPIform.status['phoneUseLimit'] === 0 ?"启用" : "停用" }}
          </span>
        </el-form-item>
        <el-form-item label="通话记录月份:"
                      prop="phoneCallLogLimit"
                      :rules="[{ required:userDirectionAPIform.status.phoneCallLogLimit === 0, validator:phoneCallLogLimit , trigger: 'blur' }]">
          <el-input v-model="userDirectionAPIform['phoneCallLogLimit']"
                    :disabled="userDirectionAPIform.status.phoneCallLogLimit === 1"
                    class="length-API"></el-input>
          <el-switch v-model="userDirectionAPIform.status['phoneCallLogLimit']"
                     active-color="#13ce66"
                     inactive-color="#ff4949"
                     :active-value="0"
                     :inactive-value="1"
                     @change="changeSwitch"></el-switch>
          <span>
            {{ userDirectionAPIform.status['phoneCallLogLimit'] === 0 ?"启用" : "停用" }}
          </span>
        </el-form-item>
      </el-form>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="dialogVisibleDirection = false">取 消</el-button>
        <el-button type="primary"
                   @click="handleDirectionConfirm">确 定</el-button>
      </span>
    </el-dialog>

    <!-- 编辑广告图片 -->
    <el-dialog :title="'编辑素材-' + directionName"
               :visible.sync="dialogVisibleAdverPic"
               :close-on-click-modal="false"
               :close-on-press-escape="false"
               width="90%"
               @close="handleAdvPicClose">
      <el-form ref="AdvPicForm"
               label-width="100px"
               :model="AdvPicForm"
               :rules="AdvPicFormRules">
        <el-form-item label="开屏广告:">
          <el-upload class="upload-demo"
                     :action="uploadUrl"
                     :show-file-list="false"
                     list-type="picture"
                     :on-success="openAdvSuccess">
            <el-button size="small"
                       type="primary">
              添加图片
            </el-button><span class="font">(开屏广告图片尺寸750*1084)</span>
          </el-upload>
          <PicComponent :list="openAds"
                        :width="172"
                        :height="250"
                        @_getvalue="getOpenAds"></PicComponent>
        </el-form-item>
        <el-form-item label="首页banner:">
          <el-upload class="upload-demo"
                     :action="uploadUrl"
                     :show-file-list="false"
                     list-type="picture"
                     :on-success="openBannerSuccess">
            <el-button size="small"
                       type="primary">
              添加图片
            </el-button><span class="font">(首页Banner图片尺寸678*180)</span>
          </el-upload>
          <PicComponent :list="homeBanners"
                        :width="300"
                        :height="111"
                        @_getvalue="getHomeBanners"></PicComponent>
        </el-form-item>
        <el-form-item label="首页弹窗:">
          <el-upload class="upload-demo"
                     :action="uploadUrl"
                     :show-file-list="false"
                     list-type="picture"
                     :on-success="openPopsSuccess">
            <el-button size="small"
                       type="primary">
              添加图片
            </el-button><span class="font">(首页弹框图片尺寸574*640)</span>
          </el-upload>
          <PicComponent :list="homePops"
                        :width="179"
                        :height="200"
                        @_getvalue="getHomePops"></PicComponent>
        </el-form-item>
        <el-form-item label="优惠券名称:"
                      prop="couponName"
                      label-width="120px">
          <el-input v-model="AdvPicForm.couponName"
                    size="small"
                    class="length-1"></el-input>
          <span class="font">修改后所有的产品线+手机系统中的该字段都会变动</span>
        </el-form-item>
        <el-form-item label="副标题:"
                      prop="subCouponName"
                      label-width="120px">
          <el-input v-model="AdvPicForm.subCouponName"
                    size="small"
                    class="length-1"></el-input>
          <span class="font">修改后所有的产品线+手机系统中的该字段都会变动</span>
        </el-form-item>
        <el-form-item label="优惠金额/内容:"
                      prop="couponContent"
                      label-width="120px">
          <el-input v-model="AdvPicForm.couponContent"
                    size="small"
                    class="length-1"></el-input>
          <span class="font">修改后所有的产品线+手机系统中的该字段都会变动</span>
        </el-form-item>
      </el-form>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="dialogVisibleAdverPic = false">取 消</el-button>
        <el-button type="primary"
                   @click="handleAdvPicConfirm">保 存</el-button>
      </span>
    </el-dialog>
    <!-- 产品标签管理 -->
    <el-dialog :visible.sync="tagDialogForm.show">
      <span slot="title"
            class="dialog-title Foot-center">
        <span>标签库管理</span>
        <el-button type="primary"
                   size="mini"
                   @click="addtag()">添加</el-button>
        <el-button type="primary"
                   size="mini"
                   @click="savetag()">保存设置</el-button>
        <p style="color:red;font-size:12px;">*点击右上角"保存设置"后状态和排序才会生效</p>
      </span>
      <el-table :data="tagDialogForm.tableData"
                stripe
                border
                width="100%">
        <el-table-column prop="id"
                         label="标签ID">
        </el-table-column>
        <el-table-column prop="tagName"
                         label="标签名称">
        </el-table-column>
        <el-table-column prop="tagOrder"
                         label="排序">
          <template slot-scope="scope">
            <div class="pd">
              <el-input v-model.number="scope.row.tagOrder"
                        size="mini"
                        type="number"
                        :min="1"
                        onkeypress="return(  /[0-9]/.test(String.fromCharCode(event.keyCode)))"></el-input>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="tagColor"
                         label="标签颜色">
          <template slot-scope="scope">
            <el-color-picker v-model="scope.row.tagColor"
                             size="small"></el-color-picker>
          </template>
        </el-table-column>
        <el-table-column prop="tagStatus"
                         label="标签状态">
          <template slot-scope="scope">
            <div class="product-status">
              <span>
                <span v-if="scope.row.tagStatus"
                      style="color:green;">启用</span>
                <span v-else
                      style="color:red">停用</span>
              </span>
              <span>
                <el-switch v-model="scope.row.tagStatus"
                           :active-value="1"
                           :inactive-value="0"
                           active-color="#13ce66"
                           inactive-color="#ff4949">
                </el-switch>
              </span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="updateAt"
                         label="最后修改时间">
        </el-table-column>
        <el-table-column prop="operatorName"
                         label="操作人">
        </el-table-column>
        <el-table-column prop="value"
                         label="操作">
          <template slot-scope="scope">
            <el-button type="primary"
                       size="mini"
                       @click="editTag(scope.row)">
              编辑
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-container">
        <el-pagination :current-page.sync="tagDialogForm.pagination.pageNo"
                       :page-sizes="tagDialogForm.pagination.pageSizes"
                       :page-size="tagDialogForm.pagination.pageSize"
                       layout="total, sizes, prev, pager, next, jumper"
                       :total="tagDialogForm.pagination.total"
                       @size-change="tagDialogFormSizeChange"
                       @current-change="tagDialogFormCurrentChange">
        </el-pagination>
      </div>
    </el-dialog>
    <!-- 添加标签 -->
    <el-dialog :title="addTagForm.title + '标签'"
               :visible.sync="addTagForm.show"
               @close="closeTAG">
      <el-form ref="tagDialogForm"
               size="mini"
               :model="addTagForm.addForm"
               :rules="addTagForm.rules"
               label-width="100px">
        <el-form-item label="标签名称:"
                      prop="tagName">
          <el-input v-model="addTagForm.addForm.tagName"
                    maxlength="6"
                    class="length-1">
          </el-input>
          <span class="font">限6个字</span>
        </el-form-item>
        <el-form-item label="标签颜色:"
                      prop="tagColor">
          <span v-for="(item,index) in predefineColors"
                :key="index"
                class="colorBox"
                :style="{background:item}"
                @click="changeColorBox(item)">
            <i v-if="item === addTagForm.addForm.tagColor"
               class="el-icon-check icon-position"></i>
          </span>
          <!-- <el-color-picker size="small" v-model="addTagForm.addForm.tagColor" :predefine="predefineColors"></el-color-picker> -->
          <!-- <span class="font margin">点击后可直接</span> -->
        </el-form-item>
        <!-- <el-form-item>
          <div style="display:flex;">
            <HyLabel :title="addTagForm.addForm.tagName"
                     :color="addTagForm.addForm.tagColor"></HyLabel>
          </div>
        </el-form-item> -->
      </el-form>

      <span slot="footer"
            class="dialog-footer Foot-center">
        <el-button @click="addTagForm.show = false">取消</el-button>
        <el-button type="primary"
                   @click="addOrEditTag()">保存</el-button>
      </span>
    </el-dialog>
    <el-dialog :visible.sync="newDialog.firstDialog"
               width="30%"
               class="center">
      <div slot="title">
        温馨提示，该产品当前所有上架位置情况如下：
      </div>
      <el-table :data="newDialog.allList"
                stripe
                border
                width="100%">
        <el-table-column prop="name"
                         label="该产品在架位置"
                         align="left">
          <template slot-scope="scope">
            <el-row>
              <el-col :push="2"
                      :span="22">
                <span>{{ bigTag[scope.row.channelId] }}</span>-<span>{{ tagObj[scope.row.classifyCode] }}</span>
              </el-col>
            </el-row>
          </template>
        </el-table-column>
        <el-table-column prop="onlineNum"
                         label="该位置在架产品数"></el-table-column>
      </el-table>
      <span slot="footer"
            class="dialog-footer Foot-center">
        <el-button @click="newDialog.firstDialog = false">取消</el-button>
        <el-button :loading="newDialog.continueLoading"
                   @click="continueStart">继续停用</el-button>
      </span>
    </el-dialog>
    <el-dialog :visible.sync="newDialog.finalDialog"
               width="30%"
               class="center"
               top="5vh">
      <div v-if="newDialog.failList.length < 1"
           slot="title">
        该产品已停用
      </div>
      <div v-if="newDialog.failList.length > 0"
           slot="title">
        <p style="color:red;">
          该产品暂无法完全停用，以下位置需要手动下架该产品：
        </p>
        <div v-for="(item,index) in newDialog.failList"
             :key="index"
             style="color:red;font-size:12px;">
          <span style="line-height:16px">{{ bigTag[item.channelId] }}</span>-<span style="line-height:16px">{{ tagObj[item.classifyCode] }};</span>
        </div>
      </div>
      <div style="color:green;">
        <p style="font-size:16px;">
          以下位置以完成下架：
        </p>
        <div v-for="(item,index) in newDialog.successList"
             :key="index"
             style="font-size:12px;">
          <span style="line-height:16px">{{ bigTag[item.channelId] }}</span>-<span style="line-height:16px">{{ tagObj[item.classifyCode] }};</span>
        </div>
      </div>
      <span slot="footer"
            class="dialog-footer Foot-center">
        <el-button @click="newDialog.finalDialog = false">我知道了</el-button>
      </span>
    </el-dialog>
    <!-- 产品链接 -->
    <el-dialog title="查看链接"
               :visible.sync="urlDialog.show"
               :close-on-click-modal="false"
               width="80%"
               :close-on-press-escape="false">
      <div style="margin-bottom:10px">
        <span style="font-size:18px;color:#303133">产品：</span> <span style="font-size:18px;color:#303133">{{ urlDialog.proTitle }}</span>
        <el-button type="primary"
                   size="mini"
                   style="margin-left:100px"
                   @click="addUrlList">
          添加链接
        </el-button>
      </div>
      <el-table :data="urlDialog.urlList"
                stripe
                border
                width="100%">
        <el-table-column prop="seqId"
                         label="链接ID"
                         min-width="60">
        </el-table-column>
        <el-table-column prop="address"
                         label="URL"
                         min-width="160"></el-table-column>
        <el-table-column label="链接类型"
                         prop="remark"
                         min-width="80">
        </el-table-column>
        <el-table-column prop="productLine"
                         label="产品线"
                         min-width="80">
          <template slot-scope="scope">
            <span>
              {{ urlDialog.proList[scope.row.productLine] }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="cellSystem"
                         label="手机系统"
                         min-width="80">
          <template slot-scope="scope">
            <span>
              {{ urlDialog.phoneList[scope.row.cellSystem] }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="fillConstraintSite"
                         label="是否允许上硬广位">
          <template slot-scope="scope">
            <span v-if="scope.row.fillConstraintSite">
              是
            </span>
            <span v-else>
              否
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="uvClickLimit"
                         label="期望点击UV上限"
                         width="100"></el-table-column>
        <el-table-column prop="uvSinkFlag"
                         label="期望UV是否足量">
          <template slot-scope="scope">
            <span v-if="scope.row.uvSinkFlag"
                  style="color:red">
              是
            </span>
            <span v-else>
              否
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="constraintUvClickLimit"
                         label="硬广位期望UV上限"></el-table-column>
        <el-table-column prop="constraintUvSinkFlag"
                         label="硬广位期望UV是否足量">
          <template slot-scope="scope">
            <span v-if="scope.row.constraintUvSinkFlag"
                  style="color:red">
              是
            </span>
            <span v-else>
              否
            </span>
          </template>
        </el-table-column>

        <el-table-column prop="uvLimitFlag"
                         label="是否严格控量">
          <template slot-scope="scope">
            <span v-if="scope.row.uvClickLimit!==0&& scope.row.uvLimitFlag">
              是
            </span>
            <span v-else-if="scope.row.uvClickLimit!==0&& !scope.row.uvLimitFlag">
              否
            </span>
            <span v-else>
              --
            </span>
          </template>
        </el-table-column>

        <el-table-column prop="uvHideFlag"
                         label="是否足量后隐藏">
          <template slot-scope="scope">
            <span v-if="scope.row.uvClickLimit!==0 && scope.row.uvHideFlag">
              是
            </span>
            <span v-else-if="scope.row.uvClickLimit!==0 && !scope.row.uvHideFlag">
              否
            </span>
            <span v-else>
              --
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="linkLayer"
                         label="链接分层"></el-table-column>
        <el-table-column prop="clickArpu"
                         label="点击ARPU">
          <template slot-scope="scope">
            <span>{{ scope.row.clickArpu || 0 }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="uvClickLimit"
                         label="对接方式"
                         width="80">
          <template slot-scope="scope">
            <span> {{ selectList.dockingTypeList[scope.row.dockingType] }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="settlementModeName"
                         label="结算方式">
        </el-table-column>
        <el-table-column prop="unitPrice"
                         label="单价(元)">
          <template slot-scope="scope">
            <span v-if="scope.row.ladderPrice === 1"
                  style="color:red">{{ scope.row.unitPrice }}</span>
            <span v-if="scope.row.ladderPrice === 0">{{ scope.row.unitPrice }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="firstLoanSharing"
                         label="首贷分成">
          <template slot-scope="scope">
            <span v-if="scope.row.ladderPrice === 1"
                  style="color:red">{{ scope.row.firstLoanSharing !== null? scope.row.firstLoanSharing + '%' : '' }}</span>
            <span v-if="scope.row.ladderPrice === 0"> {{ scope.row.firstLoanSharing !== null? scope.row.firstLoanSharing + '%' : '' }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="reloanSharing"
                         label="复贷分成">
          <template slot-scope="scope">
            <span v-if="scope.row.ladderPrice === 1"
                  style="color:red">{{ scope.row.reloanSharing !== null ? scope.row.reloanSharing + '%' : '' }}</span>
            <span v-if="scope.row.ladderPrice === 0">{{ scope.row.reloanSharing !== null ? scope.row.reloanSharing + '%' : '' }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="status"
                         label="状态"
                         width="100">
          <template slot-scope="scope">
            <div class="product-status">
              <span>
                <span v-if="scope.row.status"
                      style="color:green;">启用</span>
                <span v-else
                      style="color:red">停用</span>
              </span>
              <span @click.capture.stop="LinkEnableDisable(scope.row)">
                <el-switch v-model="scope.row.status"
                           :active-value="1"
                           :inactive-value="0"
                           active-color="#13ce66"
                           inactive-color="#ff4949">
                </el-switch>
              </span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="onlineNum"
                         label="编辑链接"
                         width="60">
          <template slot-scope="scope">
            <span style="color:blue;cursor:pointer"
                  @click="editMiniUrl(scope.row)">
              [编辑]
            </span>
          </template>
        </el-table-column>

        <el-table-column prop="onlineNum"
                         label="重置到产品线所有广告位"
                         min-width="60">
          <template slot-scope="scope">
            <span v-if="scope.row.status === 1 && (scope.row.seqId < 21)"
                  style="color:blue;cursor:pointer"
                  @click="resetMiniUrl(scope.row)">
              [重置]
            </span>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
    <!-- 新增 -->
    <el-dialog :title="urlDialog.miniTitle"
               :visible.sync="urlDialog.miniShow"
               :close-on-click-modal="false"
               @close="closeUrlForm">
      <el-form ref="urlDialogForm"
               size="mini"
               :model="urlDialog.addForm"
               :rules="urlDialog.addFormRules">
        <el-form-item label="URL"
                      prop="address"
                      label-width="175px">
          <el-input v-model="urlDialog.addForm.address"
                    style="width:200px"
                    :disabled="isEditUrl || urlDialog.addForm.dockingType === 2"></el-input>
        </el-form-item>
        <el-form-item label="链接类型"
                      prop="remark"
                      label-width="175px">
          <el-input v-model="urlDialog.addForm.remark"
                    :disabled="urlDialog.addForm.seqId < 21 && urlDialog.miniTitle === '编辑链接'"
                    style="width:200px"></el-input>
          <!-- <el-select v-model="urlDialog.addForm.remark" size="mini"  style="width:200px" :disabled="urlDialog.addForm.seqId < 21 && urlDialog.miniTitle === '编辑链接'">
            <el-option
            v-for="(item,index) in selectList.urlTypeList"
            :key="index"
            :value="item"
            :label="item"
            > 
            {{item}}
            </el-option>
          </el-select> -->
        </el-form-item>
        <el-form-item label="产品线"
                      prop="productLine"
                      label-width="175px">
          <el-select v-model="urlDialog.addForm.productLine"
                     size="mini"
                     :disabled="urlDialog.miniTitle === '编辑链接'"
                     style="width:200px">
            <el-option v-for="(value,key,index) in urlDialog.proList"
                       :key="index"
                       :value="key"
                       :label="value">
              {{ value }}
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="手机系统"
                      prop="cellSystem"
                      label-width="175px">
          <el-select v-model="urlDialog.addForm.cellSystem"
                     size="mini"
                     style="width:200px">
            <el-option v-for="(value,key,index) in urlDialog.phoneList"
                       :key="index"
                       :value="key"
                       :label="value">
              {{ value }}
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="期望UV上限"
                      prop="uvClickLimit"
                      label-width="175px">
          <el-input v-model="urlDialog.addForm.uvClickLimit"
                    style="width:200px"></el-input>
        </el-form-item>
        <el-form-item label="硬广位期望UV上限"
                      prop="constraintUvClickLimit"
                      label-width="175px">
          <el-input v-model="urlDialog.addForm.constraintUvClickLimit"
                    style="width:200px"></el-input>
        </el-form-item>
        <el-form-item label="是否允许上硬广位"
                      prop="fillConstraintSite"
                      label-width="175px">
          <el-switch v-model="urlDialog.addForm.fillConstraintSite"
                     active-color="#13ce66"
                     inactive-color="#ff4949">
          </el-switch>
          <!-- <el-input v-model="urlDialog.addForm.fillConstraintSite" style="width:200px"></el-input> -->
        </el-form-item>
        <el-form-item v-if="urlDialog.addForm.uvClickLimit !=='0' &&urlDialog.addForm.uvClickLimit !==0"
                      label="是否严格控量"
                      prop="fillConstraintSite"
                      label-width="175px">
          <el-select v-model="urlDialog.addForm.uvLimitFlag"
                     size="mini"
                     style="width:200px">
            <el-option :value="0"
                       label="否"></el-option>
            <el-option :value="1"
                       label="是"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-if="urlDialog.addForm.uvClickLimit !=='0' &&urlDialog.addForm.uvClickLimit !==0"
                      label="是否足量后隐藏"
                      prop="fillConstraintSite"
                      label-width="175px">
          <el-select v-model="urlDialog.addForm.uvHideFlag"
                     size="mini"
                     style="width:200px">
            <el-option :value="0"
                       label="否"></el-option>
            <el-option :value="1"
                       label="是"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="对接方式"
                      prop="dockingType"
                      label-width="175px">
          <el-select v-model="urlDialog.addForm.dockingType"
                     size="mini"
                     :disabled="urlDialog.miniTitle === '编辑链接'"
                     style="width:200px"
                     @change="changeDockingType">
            <el-option v-for="(item,index) in selectList.dockingTypeArr"
                       :key="index"
                       :value="item.key"
                       :label="item.value">
              {{ item.value }}
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="结算方式"
                      prop="settlementMode"
                      label-width="175px">
          <el-select v-model="urlDialog.addForm.settlementMode"
                     filterable
                     clearable
                     style="width:200px"
                     @change="changeSettlementMode">
            <el-option v-for="(value,key) in selectList.settlementModeList"
                       :key="value"
                       :label="value"
                       :value="key">
              {{ value }}
            </el-option>
          </el-select>
          <el-checkbox v-model="urlDialog.addForm.ladderPrice"
                       :true-label="1"
                       :false-label="0">
            阶梯价
          </el-checkbox>
        </el-form-item>
        <el-form-item label="单价"
                      prop="unitPrice"
                      label-width="175px">
          <el-input v-model="urlDialog.addForm.unitPrice"
                    :disabled="unitPriceDisable"
                    style="width:200px"></el-input>
        </el-form-item>
        <el-form-item label="首贷分成"
                      prop="firstLoanSharing"
                      label-width="175px">
          <el-input v-model="urlDialog.addForm.firstLoanSharing"
                    :disabled="firstLoanSharingDisbale"
                    style="width:200px"></el-input>%
        </el-form-item>
        <el-form-item label="复贷分成"
                      prop="reloanSharing"
                      label-width="175px">
          <el-input v-model="urlDialog.addForm.reloanSharing"
                    :disabled="reloanSharingDisbale"
                    style="width:200px"></el-input>%
        </el-form-item>
        <el-form-item label="甲方链接注册渠道"
                      prop="regChannel"
                      label-width="175px"
                      :rules="[{ required:urlDialog.addForm.dockingType === 1 || urlDialog.addForm.dockingType === 2, validator:regChannelPass, trigger: 'blur' }]">
          <el-input v-model="urlDialog.addForm.regChannel"
                    :disabled="urlDialog.addForm.dockingType === 0 || urlDialog.addForm.dockingType === ''"
                    style="width:200px"></el-input>
        </el-form-item>
        <el-form-item label="链接分层"
                      prop="linkLayer"
                      label-width="175px">
          <el-select v-model="urlDialog.addForm.linkLayer"
                     size="mini">
            <el-option v-for="(item,index) in linkLayer"
                       :key="index"
                       :value="item.value"
                       :label="item.key">
              {{ item.key }}
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="点击ARPU是否自动获取"
                      prop="autoArpu"
                      label-width="175px"
                      required>
          <el-switch v-model="urlDialog.addForm.autoArpu"
                     :active-value="1"
                     :inactive-value="2"
                     active-text="是"
                     inactive-text="否"
                     active-color="#13ce66"
                     inactive-color="#ff4949">
          </el-switch>
        </el-form-item>
        <el-form-item v-if="urlDialog.addForm.autoArpu===2"
                      label="点击ARPU"
                      prop="clickArpu"
                      label-width="175px">
          <el-input v-model="urlDialog.addForm.clickArpu"
                    style="width:200px"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer"
            class="dialog-footer Foot-center">
        <el-button @click="urlDialog.miniShow = false">取消</el-button>
        <el-button :loading="btnLoading"
                   @click="submitURL">确定</el-button>
      </span>
    </el-dialog>

    <!-- 新增 -->
    <el-dialog :title="batchUploadDialog.tittle"
               :visible.sync="batchUploadDialog.show"
               center
               :close-on-click-modal="false"
               width="30%"
               @close="closeFile">
      <el-form v-if="batchUploadDialog.tittle === '亲爱的，你想导入导出什么？'"
               size="mini"
               style="text-align:center">
        <!-- <el-form-item label=""
                      prop="">
          <el-button type="success"
                     @click="changeUpload(1)">
            产品分层、花钱无忧点击Arpu、贷款王点击Arpu、立即借点击Arpu
          </el-button>
        </el-form-item> -->
        <el-form-item label=""
                      prop="">
          <el-button type="success"
                     style="width:392px"
                     @click="changeUpload(2)">
            链接的分层、点击ARPU、期望点击UV上限
          </el-button>
        </el-form-item>
      </el-form>
      <el-form v-if="batchUploadDialog.tittle === '导入导出文件'"
               size="mini">
        <!-- <el-form-item label=""  prop="" label-width="100px">
            <el-button type="primary">批量导出</el-button>
        </el-form-item>
        <el-form-item label=""  prop="" label-width="100px">
          <el-button type="primary">批量导入</el-button>
        </el-form-item> -->
        <el-form-item label=""
                      prop=""
                      label-width="100px">
          <el-upload ref="uploadFile"
                     class="upload-user-defined"
                     name="in"
                     accept=".csv"
                     :auto-upload="false"
                     action="url"
                     :file-list="ARPUfileList"
                     :show-file-list="true"
                     :with-credentials="true"
                     :before-upload="handleUploadBefore"
                     :on-success="handleUploadSuccess"
                     :on-error="handleUploadError"
                     :on-progress="handleUploadProgress"
                     :on-change="handleUploadChange"
                     :disabled="uploading">
            <el-button size="mini"
                       type="primary"
                       :loading="uploading">
              选择文件
            </el-button>
            <span style="font-size:12px;">只能上传.csv文件</span>
          </el-upload>
        </el-form-item>
      </el-form>
      <span v-if="batchUploadDialog.tittle === '导入导出文件'"
            slot="footer"
            class="dialog-footer Foot-center">
        <el-button type="success"
                   @click="batchDown()">批量导出</el-button>
        <el-button type="success"
                   @click="fetchUpload()">批量导入</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { parseTime } from '../../utils/formatDate'
import PicComponent from './components/picComponent'
// import HyLabel from '../../components/HyLabel'
import Moment from 'moment'
import {
  rateTypeList,
  PROVINCE,
  PROVINCE_LIST,
  TAG_OBJ,
  BIG_TAG,
  CREDIT_SCORE_LIST, // 用户定向编辑-芝麻分
  CAEDIT_CARD_LIST, // 用户定向编辑-信用卡
  PHONE_TIME_LIST, // 用户定向编辑-手机号使用时长
  CAREER_LIST, // 用户定向编辑-职业身份
  SOCIAL_SECURITY_LIST, // 用户定向编辑-社保
  ACCUMULATION_FUND_LIST, // 用户定向编辑-公积金
  PHONE_SYSTEM_LIST, // 用户定向编辑-手机系统
  // productLayerList, // 产品分层
  linkLayer, // 链接分层
} from './province'
// import CheckButton from './components/checkButton'
import productionApi from '../../api/production'
import commonApi from '../../api/incomeApi/common.js'
// import { isNumber } from 'util'
export default {
  components: {
    // CheckButton,
    PicComponent,
    // HyLabel,
  },
  filters: {
    getSpecialTagLabel (key) {
      if (!key) return
      let list = {
        1: '小额极速',
        2: '芝麻分贷',
        3: '身份证贷',
        4: '大额分期',
        5: '公积金贷',
        6: '快速审批',
        7: '新品专区',
      }
      return list[key] || key
    },
  },
  data () {
    // const regInt = /^[0-9]\d*$/ // 验证正整数
    let productLimit = (rule, value, callback) => {
      if (this.addOrEditForm.productLimitStart === 0 && this.addOrEditForm.productLimitEnd === 0) {
        callback(new Error('额度范围不允许为0-0'))
      } else if ((!this.addOrEditForm.productLimitStart && this.addOrEditForm.productLimitStart !== 0) || (!this.addOrEditForm.productLimitEnd && this.addOrEditForm.productLimitEnd !== 0)) {
        callback(new Error('额度范围不允许为空'))
      } else if (this.addOrEditForm.productLimitEnd < this.addOrEditForm.productLimitStart) {
        callback(new Error('额度范围后一项需大于或等于前一项'))
      } else {
        callback()
      }
    }
    let duration = (rule, value, callback) => {
      let start = this.addOrEditForm.durationStart === null? '' :this.addOrEditForm.durationStart
      let end = this.addOrEditForm.durationEnd === null? '' :this.addOrEditForm.durationEnd
      if (start === 0 && end === 0) {
        callback(new Error('期限范围不允许0-0'))
      } else if((typeof(start) === 'number' && typeof(end) === 'number' && end >= start && start) || (start=== '' && end === '')){
        callback()
      }  else {
        callback(new Error('不符合填写规则'))
      }
      // if (start === 0 && end === 0) {
      //   callback(new Error('期限范围不允许0-0'))
      // }  else if () {
      //   callback(new Error('若只有一个期限，则前后写成一样即可'))
      // } else if (end < start) {
      //   callback(new Error('期限范围后一项需大于或等于前一项'))
      // }else {
      //   callback()
      // }
    }
    const regFloatTwo = /^\d{0,8}\.{0,1}(\d{1,2})?$/ // 验证两位小数
    const regFloatThree = /^\d{0,8}\.{0,1}(\d{1,3})?$/ // 验证三位小数
    let rate = (rule, value, callback) => {
      let start = this.addOrEditForm.rateStart === ''? null : this.addOrEditForm.rateStart
      let end = this.addOrEditForm.rateEnd === ''? null : this.addOrEditForm.rateEnd
      let flag = false
      if((start === null && end !== null) || (start !== null && end === null)){
        flag = true
      }
      // eslint-disable-next-line eqeqeq
      if (start == 0 &&  end == 0) {
        callback(new Error('利率范围不允许为0-0'))
      }  else if (this.addOrEditForm.rateType === 1 || this.addOrEditForm.rateType === 2) {
        if ((!regFloatTwo.test(start) || !regFloatTwo.test(end)) &&  (start !== null && end !== null)) {
          callback(new Error('利率小数位不超过2位的数值！'))
        } else if(flag) {
           callback(new Error('若利率只有一个固定值，则前后写成一样即可'))
        }else if (Number(end) < Number(start)) {
          callback(new Error('不符合填写规则'))
        }  else {
          callback()
        }
      } else if (this.addOrEditForm.rateType === 0) {
        if ((!regFloatThree.test(start) || !regFloatThree.test(end)) &&  (start !== null && end !== null)) {
          callback(new Error('每日的利率小数位不超过3位的数值！'))
        }else if(flag) {
           callback(new Error('若利率只有一个固定值，则前后写成一样即可'))
        } else if (Number(end) < Number(start)) {
          callback(new Error('不符合填写规则'))
        }  else {
          callback()
        }
      } else {
        callback()
      }
    }
    let logo = (rule, value, callback) => {
      if (!this.addOrEditForm.logo) {
        callback(new Error('请上传logo'))
      } else {
        callback()
      }
    }
    let age = (rule, value, callback) => {
      if (value[0] < 18 || value[0] > 60 || value[1] < 18 || value[1] > 60) {
        callback(new Error('年龄必须在18~60之间的正整数'))
      } else if (!value[0] || !value[1]) {
        callback(new Error('期限范围不允许为空'))
      } else if (value[1] < value[0]) {
        callback(new Error('期限范围后一项需大于或等于前一项'))
      } else {
        callback()
      }
    }
    let url = (rule, value, callback) => {
      if (this.addOrEditForm.baseLinks.length === 1) {
        if (this.addOrEditForm.baseLinks[0].address === '') {
          callback(new Error('必须填写一个链接'))
        } else {
          callback()
        }
      }
      if (this.addOrEditForm.baseLinks.length > 1) {
        if (this.addOrEditForm.baseLinks[0].address === '' && this.addOrEditForm.baseLinks[1].address === '') {
          callback(new Error('必须填写一个链接'))
        } else {
          callback()
        }
      }
    }
    let regAgreeUrlPass = (rule, value, callback) => {
      if (this.isJointLoginProduct === true) {
        callback()
      } else if (this.isJointLoginProduct === false && (value === '' || value === null)) {
        callback(new Error('请输入'))
      } else {
        callback()
      }
    }
    let regChannelPass = (rule, value, callback) => {
      if (this.urlDialog.addForm.dockingType === 0 || this.urlDialog.addForm.dockingType === null || this.urlDialog.addForm.dockingType === '') {
        callback()
      } else if (this.urlDialog.addForm.dockingType === 1 && (value === '' || value === null)) {
        callback(new Error('甲方链接注册渠道不能为空'))
      } else if (this.urlDialog.addForm.dockingType === 2 && (value === '' || value === null)) {
        callback(new Error('甲方链接注册渠道不能为空'))
      } else {
        callback()
      }
    }
    let customPhone = (rule, value, callback) => {
      if (this.addOrEditForm.customPhoneType === 0) {
        if (/^[0-9]*$/.test(value) && value !== '') {
          callback()
        } else {
          callback(new Error('输入格式错误，请输入数字'))
        }
      } else {
        if (value !== '') {
          callback()
        } else {
          callback(new Error('请输入联系方式'))
        }
      }
    }
    let ageLimit = (rule, value, callback) => {
      if (this.userDirectionAPIform.status.age === 0) {
        if (value[0] < 18 || value[0] > 60 || value[1] < 18 || value[1] > 60) {
          callback(new Error('年龄必须在18~60之间的正整数'))
        } else if (!value[0] || !value[1]) {
          callback(new Error('期限范围不允许为空'))
        } else if (value[1] < value[0]) {
          callback(new Error('期限范围后一项需大于或等于前一项'))
        } else {
          callback()
        }
      } else {
        if (value[0] < 18 || value[0] > 60 || value[1] < 18 || value[1] > 60) {
          callback(new Error('年龄必须在18~60之间的正整数'))
        } else if ((!value[0] && value[1]) || (value[0] && !value[1])) {
          callback(new Error('请填写完整，或者不填'))
        } else if (value[1] < value[0]) {
          callback(new Error('期限范围后一项需大于或等于前一项'))
        } else {
          callback()
        }
      }
    }
    let phoneUseLimit = (rule, value, callback) => {
      if (this.userDirectionAPIform.status.phoneUseLimit === 0) {
        if (/^[0-9]*$/.test(value) && value !== '') {
          callback()
        } else {
          callback(new Error('请填写正确的数字'))
        }
      } else {
        if (/^[0-9]*$/.test(value) || value === '') {
          callback()
        } else {
          callback(new Error('请填写正确的数字'))
        }
      }
    }
    let phoneCallLogLimit = (rule, value, callback) => {
      if (this.userDirectionAPIform.status.phoneCallLogLimit === 0) {
        if (/^[0-9]*$/.test(value) && value !== '') {
          callback()
        } else {
          callback(new Error('请填写正确的数字'))
        }
      } else {
        if (/^[0-9]*$/.test(value) || value === '') {
          callback()
        } else {
          callback(new Error('请填写正确的数字'))
        }
      }
    }
    return {
      rateTypeList:rateTypeList,
      addOrEditProductType: '', // 新增/编辑产品弹窗类型：add-新增，edit-编辑
      predefineColors: [
        '#FF601A',
        '#4A90E2',
        '#52BB50',
        '#EE2D2D',
        '#FF7825',
        '#6950A1',
        '#FCAF17',
        '#1BCFC9',
        '#4672FF',
        '#D0021B',
      ],
      btnLoading: false,
      directionId: null,
      isApi: false,
      regChannelPass: regChannelPass,
      regAgreeUrlPass: regAgreeUrlPass,
      customPhone: customPhone,
      ageLimit: ageLimit,
      phoneUseLimit: phoneUseLimit,
      phoneCallLogLimit: phoneCallLogLimit,
      isJointLoginProduct: false,
      selectList: {
        activeList: [],
        urlTypeList: ['花钱无忧', '贷款王', '花钱无忧-联登', '贷款王-联登', '花钱无忧-API', '贷款王-API'],
        advertiserList: [],
        settlementModeList: {
          1: 'CPA注册',
          2: 'CPA申请',
          3: 'CPK开户',
          4: 'CPL动用',
          5: 'CPT包日',
          6: '点击UV',
          7: 'CPS首贷分成',
          8: 'CPS首贷+复贷分成',
        },
        dockingTypeList: {
          0: 'H5',
          1: '联合登录',
          2: 'API',
        },
        dockingTypeArr: [
          { key: 0, value: 'H5' },
          { key: 1, value: '联合登录' },
          { key: 2, value: 'API' },
        ],
        SystemModuleList: {
          0: '精准推荐系统',
          1: 'API用户预筛',
        },
      },
      AdvPicFormRules: {
        couponName: [
          {
            required: false,
            trigger: 'none',
            validator: (rule, value, callback) => {
              if (this.AdvPicForm.couponName === '' && this.AdvPicForm.subCouponName === '' && this.AdvPicForm.couponContent === '') {
                callback()
              } else if (this.AdvPicForm.couponName !== '' && this.AdvPicForm.subCouponName !== '' && this.AdvPicForm.couponContent !== '') {
                callback()
              } else {
                callback(new Error('优惠券名称、副标题、优惠金额/内容这三个要素必须同时填写或同时不填写'))
              }
            },
          },
        ],
        subCouponName: [
          {
            required: false,
            trigger: 'none',
            validator: (rule, value, callback) => {
              if (this.AdvPicForm.couponName === '' && this.AdvPicForm.subCouponName === '' && this.AdvPicForm.couponContent === '') {
                callback()
              } else if (this.AdvPicForm.couponName !== '' && this.AdvPicForm.subCouponName !== '' && this.AdvPicForm.couponContent !== '') {
                callback()
              } else {
                callback(new Error('优惠券名称、副标题、优惠金额/内容这三个要素必须同时填写或同时不填写'))
              }
            },
          },
        ],
        couponContent: [
          {
            required: false,
            trigger: 'none',
            validator: (rule, value, callback) => {
              if (this.AdvPicForm.couponName === '' && this.AdvPicForm.subCouponName === '' && this.AdvPicForm.couponContent === '') {
                callback()
              } else if (this.AdvPicForm.couponName !== '' && this.AdvPicForm.subCouponName !== '' && this.AdvPicForm.couponContent !== '') {
                callback()
              } else {
                callback(new Error('优惠券名称、副标题、优惠金额/内容这三个要素必须同时填写或同时不填写'))
              }
            },
          },
        ],
      },
      AdvPicForm: {
        couponContent: '',
        couponName: '',
        subCouponName: '',
      },
      row: null,
      uploading: false,
      ARPUfileList: [],
      file: null,
      MYvalidator: [{ required: true, validator: url, trigger: 'blur' }],
      url: url,
      batchUploadDialog: {
        show: false,
        tittle: '亲爱的，你想导入导出什么？',
        type: 1,
      },
      urlDialog: {
        addForm: {
          fillConstraintSite: false,
          constraintUvClickLimit: 0,
          regChannel: '',
          dockingType: '',
          settlementMode: '',
          unitPrice: '',
          ladderPrice: 0,
          firstLoanSharing: '',
          reloanSharing: '',
          address: '',
          cellSystem: '0',
          id: null,
          productId: '',
          productLine: '',
          remark: '',
          seqId: '',
          uvClickLimit: '',
          uvLimitFlag: 0,
          uvHideFlag: 0,
          autoArpu: 1,
          linkLayer: '',
          clickArpu: '',
        },
        addFormRules: {
          settlementMode: [{ required: true, message: '请选择', trigger: 'blur' }],
          unitPrice: [
            {
              required: true,
              trigger: ['blur', 'change'],
              validator: (rule, value, callback) => {
                if (this.urlDialog.addForm.settlementMode !== '7' && this.urlDialog.addForm.settlementMode !== '8' && !/^(-)?\d+(\.\d+)?$/.test(value) && this.urlDialog.addForm.settlementMode !== '' && this.urlDialog.addForm.settlementMode !== null) {
                  callback(new Error('请输入'))
                } else {
                  callback()
                }
              },
            },
          ],
          firstLoanSharing: [
            {
              required: true,
              trigger: ['blur', 'change'],
              validator: (rule, value, callback) => {
                if ((this.urlDialog.addForm.settlementMode === '7' || this.urlDialog.addForm.settlementMode === '8') && !/^(-)?\d+(\.\d+)?$/.test(value)) {
                  callback(new Error('请输入'))
                } else {
                  callback()
                }
              },
            },
          ],
          reloanSharing: [
            {
              required: true,
              trigger: ['blur', 'change'],
              validator: (rule, value, callback) => {
                if (this.urlDialog.addForm.settlementMode === '8' && !/^(-)?\d+(\.\d+)?$/.test(value)) {
                  callback(new Error('请输入百分数'))
                } else {
                  callback()
                }
              },
            },
          ],
          address: [
            {
              required: true,
              trigger: ['blur', 'change'],
              validator: (rule, value, callback) => {
                if (value === '') {
                  callback(new Error('请输入URL'))
                } else {
                  callback()
                }
              },
            },
          ],
          dockingType: [{ required: true, message: '请选择', trigger: 'change' }],
          cellSystem: [{ required: true, message: '请选择', trigger: 'change' }],
          remark: [
            {
              required: true,
              trigger: ['blur', 'change'],
              validator: (rule, value, callback) => {
                if (value === '') {
                  callback(new Error('请输入'))
                } else {
                  callback()
                }
              },
            },
          ],
          productLine: [{ required: true, message: '请选择', trigger: 'change' }],
          uvClickLimit: [
            {
              required: true,
              trigger: ['blur', 'change'],
              validator: (rule, value, callback) => {
                if (/^[+]{0,1}(\d+)$/.test(value)) {
                  callback()
                  this.$refs.urlDialogForm.validateField(['constraintUvClickLimit'])
                } else {
                  callback(new Error('请输入正整数'))
                }
              },
            },
          ],
          constraintUvClickLimit: [
            {
              required: true,
              trigger: ['blur', 'change'],
              validator: (rule, value, callback) => {
                if (/^[0-9]*$/.test(value) && value !== '') {
                  let temp = Number(value)
                  let uvClickLimit = Number(this.urlDialog.addForm.uvClickLimit)
                  // if (temp === 0 && uvClickLimit !== 0) {
                  //   callback(new Error('硬广位期望UV上限必须≤期望UV上限'))
                  // } else
                  if (uvClickLimit === 0 || temp === 0) {
                    callback()
                  } else if ((uvClickLimit !== 0 && temp !== 0) && value > uvClickLimit) {
                    callback(new Error('硬广位期望UV上限必须≤期望UV上限'))
                  } else {
                    callback()
                  }
                } else {
                  callback(new Error('请输入数字'))
                }
              },
            },
          ],
          linkLayer: [{ required: true, message: '请选择', trigger: 'change' }],
          clickArpu: [
            {
              required: true,
              validator: (rule, value, callback) => {
                if (!value) {
                  callback(new Error('点击ARPU不能为空'))
                } else if (/^[0-9.]*$/.test(value)) {
                  callback()
                } else {
                  callback(new Error('点击ARPU格式不正确'))
                }
              },
              trigger: ['blur', 'change'],
            },
          ],
        },
        proTitle: null,
        miniTitle: '添加链接',
        typeList: {
          1: '开屏广告',
          2: '首页悬浮广告',
          3: '首页弹窗',
          4: '首页banner',
          5: '链接地址',
        },
        proList: {
          1: '花钱无忧',
          2: '贷款王',
          3: '导流平台',
          5: '立即借',
        },
        phoneList: {
          0: '不限',
          1: 'android',
          2: 'ios',
        },
        urlList: [

        ],
        show: false,
        miniShow: false,
      },
      newDialog: {
        continueLoading: false,
        firstDialog: false,
        finalDialog: false,
        allList: [],
        successList: [],
        failList: [],
      },
      updatedDialog: {
        detailDialog: false,
        detailList: [],
        all: true,
        hasError: false,
      },
      tagDialogForm: {
        pagination: {
          pageNo: 1, //
          pageSizes: [30, 50, 100],
          pageSize: 30,
          total: 0,
        },
        tableData: [],
        show: false,
      },
      addTagForm: {
        title: '添加',
        show: false,
        addForm: {
          tagName: '',
          tagColor: '',
        },
        rules: {
          tagName: [
            { required: true, message: '请填写', trigger: 'blur' },
          ],
          tagColor: [
            { required: true, message: '请填写', trigger: 'blur' },
          ],
        },
      },
      parseTime,
      tagObj: TAG_OBJ,
      bigTag: BIG_TAG,
      uploadUrl: productionApi['URL_UPLOAD'], // 图片上传
      // 筛选表单
      queryForm: {
        advertiserId: '',
        status: '',
        tag: '',
        id: null,
        name: '',
        pageNum: 0,
        vip: '',
      },
      // 图片编辑
      openAds: [],
      homeBanners: [],
      homePops: [],
      productId: null,
      directionName: '', // 用户定向 - 弹框表头、
      // 产品分层
      // productLayerList: productLayerList,
      // 链接分层
      linkLayer: linkLayer,
      // 用户定向-城市列表
      provinceList: PROVINCE_LIST,
      // 用户定向编辑-芝麻分
      creditScoreList: CREDIT_SCORE_LIST,
      // 用户定向编辑-信用卡
      creditCardList: CAEDIT_CARD_LIST,
      // 用户定向编辑-手机号使用时长
      phoneTimeList: PHONE_TIME_LIST,
      // 用户定向编辑-职业身份
      careerList: CAREER_LIST,
      // 用户定向编辑-社保
      socialSecurityList: SOCIAL_SECURITY_LIST,
      // 用户定向编辑-公积金
      accumulationFundList: ACCUMULATION_FUND_LIST,
      // 用户定向编辑-手机系统
      phoneSystemList: PHONE_SYSTEM_LIST,
      PROVINCEString: PROVINCE,
      // 系统模块
      SystemModule: '0',
      userDirectionAPIform: {
        ageLimit: [],
        // 身份证号码地区屏蔽
        idCardAreaLimit: [],
        // 身份证地址地区屏蔽
        idCardNoAreaLimit: [],
        // 居住地区屏蔽
        liveAreaLimit: [],
        // 定位地区屏蔽
        locationAreaAreaLimit: [],
        //  运营商是否实名且本人 1:实名且本人，2：未实名
        carrireRealNameLimit: '1',
        // 手机号使用月份
        phoneUseLimit: '',
        // 手机通话记录月份
        phoneCallLogLimit: '',
        status: {
          age: 1,
          idCardAreaLimit: 1,
          idCardNoAreaLimit: 1,
          liveAreaLimit: 1,
          locationAreaAreaLimit: 1,
          carrireRealNameLimit: 1,
          phoneUseLimit: 1,
          phoneCallLogLimit: 1,
        },
      },
      userDirectionAPIRules: {
        // ageLimit: [
        //   { required: true, validator: age, trigger: 'blur' }
        // ]
      },
      // 用户定向编辑-验证表单
      userDirectionForm: {
        phoneUseTime: 8,
        creditCard: 8,
        // socialSecurity: 0,
        fund: 8,
        discardProvince: [],
        age: [18, 60],
        // career: [],
        creditScore: 8,
        productInfoId: null,
      },
      // 用户定向编辑-验证规则
      userDirectionRules: {
        age: [
          { required: true, validator: age, trigger: 'blur' },
        ],
        creditScore: [
          { required: true, message: '请选择芝麻分', trigger: 'blur' },
        ],
        phoneUseTime: [
          { required: true, message: '请选择手机号通话时长', trigger: 'blur' },
        ],
        creditCard: [
          { required: true, message: '请选择信用卡', trigger: 'blur' },
        ],
        // career: [
        //   { required: true, message: '请选择职业身份', trigger: 'blur' },
        // ],
        // socialSecurity: [
        //   { required: true, message: '请选择社保', trigger: 'blur' },
        // ],
        fund: [
          { required: true, message: '请选择公积金', trigger: 'blur' },
        ],
        cellSystem: [
          { required: true, message: '请选择 手机系统', trigger: 'blur' },
        ],
      },
      // 操作编辑-编辑表单
      addOrEditForm: {
        customPhoneType: 0,
        advertiserId: '',
        links: [{ 'address': '', 'remark': '', 'seqId': 1 }],
        baseLinks: [{ 'address': '', 'remark': '花钱无忧专用', 'seqId': 1 }, { 'address': '', 'remark': '贷款王专用', 'seqId': 2 }, { 'address': '', 'remark': '', 'seqId': 21 }],
        name: '',
        subhead: '',
        productLimitStart: null,
        productLimitEnd: null,
        durationStart: null,
        durationEnd: null,
        durationType: 0,
        rateStart: null,
        rateEnd: null,
        rateType: 2,
        averagePrice: '',
        passRate: '',
        loanTime: '',
        loanType: 0,
        applyTips: '',
        applyFlow: '',
        tagName: '',
        tagColor: null,
        prompt: '',
        detailPrompt: '',
        status: null,
        specialTags: [],
        logo: '',
        id: null,
        // dkwArpu: '',
        // freeLoanArpu: '',
        // productLayer: 'C',
        regAgreeUrl: '',
        hitSwitch: false,
        customPhone: '',
        vip: 0,
        // ljjArpu: '',
        safeLink: 0,
        // 客户电话
      },
      // 区分操作编辑
      isAddOrEdit: false,
      // 操作编辑-编辑表单规则
      AddOrEditFormRules: {
        // regAgreeUrl: [
        //   {
        //     required: true,
        //     trigger: 'blur',
        //     validator: (rule, value, callback) => {
        //       if (this.isJointLoginProduct === true) {
        //         callback()
        //       } else if (this.isJointLoginProduct === false && (value === '' || value === null)) {
        //         callback(new Error('请输入'))
        //       } else {
        //         callback()
        //       }
        //     }
        //   }
        // ],
        name: [
          { required: true, message: '请填写产品名称', trigger: 'blur' },
        ],
        advertiserId: [
          { required: true, message: '请填写产品名称', trigger: 'blur' },
        ],
        subhead: [
          { required: true, message: '请填写副标题', trigger: 'blur' },
          { message: '最多输入14个字', trigger: 'blur', max: 14 },
        ],
        productLimit: [ // 额度范围
          { required: true, validator: productLimit, trigger: 'blur' },
        ],
        duration: [ // 期限范围
          { required: false, validator: duration, trigger: 'blur' },
        ],
        rate: [
          { required: false, validator: rate, trigger: 'blur' },
        ],
        averagePrice: [
          { required: true, message: '件均金额不能为空', trigger: 'blur' },
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (value === '') {
                callback(new Error('件均金额不能为空'))
              } else if (!/^[0-9]*[1-9][0-9]*$/.test(value)) {
                callback(new Error('件均金额为正整数'))
              } else {
                callback()
              }
            },
          },
          { type: 'number', message: '件均金额为正整数', min: 1, trigger: 'blur' },
        ],
        passRate: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (value === '') {
                callback(new Error('参考通过率不能为空'))
              } else if (!/^[0-9]*[1-9][0-9]*$/.test(value)) {
                callback(new Error('参考通过率必须为数字值且在1-99之间'))
              } else {
                callback()
              }
            },
          },
          { type: 'number', message: '参考通过率必须为数字值且在1-99之间', min: 1, max: 99, trigger: 'blur' },
        ],
        loanTime: [ // 放款时间
          { required: true, message: '请输入放款时间', trigger: 'blur' },
          { type: 'number', message: '放款时间为正整数', min: 1, trigger: 'blur' },
        ],
        loanType: [
          { required: true, message: '请选择放款类型', trigger: 'blur' },
        ],
        applyTips: [ // 申请说明
          { required: true, message: '请填写申请说明', trigger: 'blur' },
        ],
        // specialTags: [ // 特色标签
        //   { required: true, message: '请选择特色标签', trigger: 'blur' },
        // ],
        // 产品标签
        // tagIds: [
        //   {
        //     required: true,
        //     trigger: 'blur',
        //     validator: (rule, value, callback) => {
        //       if (!value.length) {
        //         callback(new Error('请选择产品标签'))
        //       } else {
        //         callback()
        //       }
        //     }
        //   }
        // ],
        prompt: [
          { message: '最多输入20个字', trigger: 'blur', max: 20 },
        ],
        detailPrompt: [
          { message: '最多输入100个字', trigger: 'blur', max: 100 },
        ],
        logo: [
          { required: true, validator: logo, trigger: 'blur' },
        ],
        // dkwArpu: [
        //   {
        //     required: true,
        //     trigger: 'blur',
        //     validator: (rule, value, callback) => {
        //       if (value === '') {
        //         callback(new Error('输入格式错误，请输入数字'))
        //       } else if (/^[0-9.]*$/.test(value)) {
        //         callback()
        //       } else {
        //         callback(new Error('输入格式错误，请输入数字'))
        //       }
        //     },
        //   },
        // ],
        // ljjArpu: [
        //   {
        //     required: true,
        //     trigger: 'blur',
        //     validator: (rule, value, callback) => {
        //       if (value === '') {
        //         callback(new Error('输入格式错误，请输入数字'))
        //       } else if (/^[0-9.]*$/.test(value)) {
        //         callback()
        //       } else {
        //         callback(new Error('输入格式错误，请输入数字'))
        //       }
        //     },
        //   },
        // ],
        // freeLoanArpu: [
        //   {
        //     required: true,
        //     trigger: 'blur',
        //     validator: (rule, value, callback) => {
        //       if (value === '') {
        //         callback(new Error('输入格式错误，请输入数字'))
        //       } else if (/^[0-9.]*$/.test(value)) {
        //         callback()
        //       } else {
        //         callback(new Error('输入格式错误，请输入数字'))
        //       }
        //     },
        //   },
        // ],
        // productLayer: [{ required: true, message: '请选择', trigger: 'blur' }],
        // status: [ // 产品状态
        //   { required: true, message: '请选择产品状态', trigger: 'blur' }
        // ]
      },
      // uniqueTagList: [
      //   { 'limitName': '小额极速', 'limitValue': 1 },
      //   { 'limitName': '芝麻分贷', 'limitValue': 2 },
      //   { 'limitName': '身份证贷', 'limitValue': 3 },
      //   { 'limitName': '大额分期', 'limitValue': 4 },
      //   { 'limitName': '公积金贷', 'limitValue': 5 },
      // ], // 特色标签列表
      fileList: [], // 编辑上传列表
      // tab相关
      listLoading: false,
      searchLoading: false,
      tableData: [],
      tableHeight: 500,
      pagData: {
        pageSize: 50, // 每页条数
        pageNum: 1, // 页码
      },
      totalRecord: 0, // 总记录数
      pageSizes: [30, 50, 100],
      dialogVisibleEdit: false, // 编辑弹框
      dialogVisibleDirection: false, // 编辑用户定向弹框
      dialogVisibleAdverPic: false, // 编辑广告图片弹框
      urlRow: {},
      text2: {
        index: '44',
      },
    }
  },
  computed: {
    customPhonePlaceholder () {
      if (this.addOrEditForm.customPhoneType === 0) return '客服电话只能输入数字'
      return '请输入内容，如：微信客服：cjkkf'
    },
    unitPriceDisable () {
      if (this.urlDialog.addForm.settlementMode === '' || this.urlDialog.addForm.settlementMode === null || this.urlDialog.addForm.settlementMode === '7' || this.urlDialog.addForm.settlementMode === '8') return true
      return false
    },
    firstLoanSharingDisbale () {
      if (this.urlDialog.addForm.settlementMode === '7' || this.urlDialog.addForm.settlementMode === '8') return false
      return true
    },
    reloanSharingDisbale () {
      if (this.urlDialog.addForm.settlementMode === '8') return false
      return true
    },
    isRemark () {
      if (this.urlDialog.miniTitle === '编辑链接') {
        if (this.urlRow.seqId === 1 || this.urlRow.seqId === 2 || this.urlRow.seqId === 3 || this.urlRow.seqId === 4 || this.urlRow.seqId === 5 || this.urlRow.seqId === 6) {
          return true
        } else {
          return false
        }
      } else {
        return false
      }
    },
    isEditType () {
      if (this.urlDialog.addForm.seqId && this.urlDialog.addForm.seqId < 7) {
        return true
      } else {
        return false
      }
    },
    isEditUrl () {
      if (this.urlDialog.miniTitle === '编辑链接') {
        if (this.urlRow.seqId === 5 || this.urlRow.seqId === 6) {
          return true
        } else {
          return false
        }
      } else {
        return false
      }
    },

  },
  created () {
    this.getDic()
    this.fetchActiveList()
  },
  mounted () {
    this.getTableData()
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    addtag () {
      this.addTagForm.addForm = {
        tagName: '',
        tagColor: '',
      }
      this.addTagForm.show = true
      this.addTagForm.title = '添加'
    },
    editTag (row) {
      this.addTagForm.title = '编辑'
      this.addTagForm.addForm = {
        id: row.id,
        tagName: row.tagName,
        tagColor: row.tagColor,
      }
      this.addTagForm.show = true
    },
    tagDialogFormSizeChange (val) {
      this.tagDialogForm.pagination.pageSize = val
      this.fetTags()
    },
    tagDialogFormCurrentChange (val) {
      this.tagDialogForm.pagination.pageNo = val
      this.fetTags()
    },
    addOrEditTag () {
      this.$refs['tagDialogForm'].validate(async (valid) => {
        if (!valid) {
          return false
        }

        let res = await productionApi.commonTagSaveOrUpdate(this.addTagForm.addForm)
        if (res.data.respCode === '1000') {
          this.$_message.success('操作成功')
          this.addTagForm.show = false
          this.fetTags()
          this.fetchActiveList()
        } else {
          this.$_message.error(res.data.respMsg)
        }
      })
    },
    closeTAG () {
      this.$refs.tagDialogForm.resetFields()
    },
    async savetag () {
      try {
        let confirm = await this.$confirm(`确认保存吗?`, '提示', { type: 'warning' })
        if (confirm) {
          for (let i = 0; i < this.tagDialogForm.tableData.length; i++) {
            if (this.tagDialogForm.tableData[i].tagOrder === '' || this.tagDialogForm.tableData[i].tagOrder === null) {
              this.$_message.error('排序值不能为空')
              return
            }
            if (this.tagDialogForm.tableData[i].tagOrder > 999 || this.tagDialogForm.tableData[i].tagOrder < 1) {
              console.log(this.tagDialogForm.tableData[i].tagOrder)
              this.$_message.error('排序值需要在1~999')
              return
            }
          }
          let list = []
          this.tagDialogForm.tableData.forEach((t) => {
            list.push({
              id: t.id,
              tagOrder: t.tagOrder,
              tagStatus: t.tagStatus,
            })
          })
          let res = await productionApi.commonTagUpdateStatus(list)
          if (res.data.respCode === '1000') {
            this.$_message.success('操作成功')
            this.fetTags()
            this.fetchActiveList()
          } else {
            this.$_message.error(res.data.respMsg)
          }
        }
      } catch (error) {
        // 
      }
    },
    tagDialog () {
      this.fetTags()
      // let data = {
      //   pageIndex: this.tagDialogForm.pagination.pageNo,
      //   pageSize: this.tagDialogForm.pagination.pageSize
      // }
      // let res = await productionApi.commonTaglist(data)
      // if (res.data.respCode === '1000') {
      //   res.data.body.productCommonTagVOList.forEach(t => {
      //     t.updateAt = Moment(t.updateAt).format('YYYY-MM-DD HH:mm:ss')
      //   })
      //   this.tagDialogForm.tableData = res.data.body.productCommonTagVOList
      //   this.tagDialogForm.pagination.pageNo = res.data.body.pageIndex
      //   this.tagDialogForm.pagination.total = res.data.body.totalCount
      // }
      this.tagDialogForm.show = true
    },
    changeColorBox (item) {
      this.addTagForm.addForm.tagColor = item
    },
    async fetTags () {
      let data = {
        pageIndex: this.tagDialogForm.pagination.pageNo,
        pageSize: this.tagDialogForm.pagination.pageSize,
      }
      console.log(data)
      let res = await productionApi.commonTaglist(data)
      if (res.data.respCode === '1000') {
        res.data.body.productCommonTagVOList.forEach((t) => {
          t.updateAt = Moment(t.updateAt).format('YYYY-MM-DD HH:mm:ss')
        })
        this.tagDialogForm.tableData = res.data.body.productCommonTagVOList
        this.tagDialogForm.pagination.pageNo = res.data.body.pageIndex
        this.tagDialogForm.pagination.total = res.data.body.totalCount
      }
    },
    changeCustomPhoneType () {
      this.$refs.addOrEditForm.clearValidate(['customPhone'])
      this.addOrEditForm.customPhone = ''
    },
    changeDockingType (val) {
      if (val === 0) {
        this.urlDialog.addForm.regChannel = ''
      }
    },
    async getDic () {
      let res = await commonApi.getDic(1)
      if (res.data.code === '0') {
        this.selectList.advertiserList = res.data.data
      }
    },
    changeUpload (type) {
      this.batchUploadDialog.tittle = '导入导出文件'
      this.batchUploadDialog.type = type
    },
    batchUpload () {
      this.batchUploadDialog.tittle = '亲爱的，你想导入导出什么？'
      this.batchUploadDialog.show = true
    },
    async resetMiniUrl (row) {
      try {
        let confirm = await this.$confirm(`确认重置该链接吗?`, '提示', { type: 'warning' })
        if (confirm) {
          let channelIds = []
          if (row.productLine === 1) {
            if (row.cellSystem === 0) {
              channelIds = [1, 2]
            }
            if (row.cellSystem === 1) {
              channelIds = [1]
            }
            if (row.cellSystem === 2) {
              channelIds = [2]
            }
          }
          if (row.productLine === 2) {
            if (row.cellSystem === 0) {
              channelIds = [3, 4]
            }
            if (row.cellSystem === 1) {
              channelIds = [3]
            }
            if (row.cellSystem === 2) {
              channelIds = [4]
            }
          }
          let data = {
            productId: row.productId,
            channelIds: channelIds,
            linkSeqId: row.seqId,
          }
          let res = await productionApi.resetLink(data)
          if (res.data.respCode === '1000') {
            this.$message.success('操作成功')
            this.fetchUrlList(this.row)
          } else {
            this.$message.error('操作失败')
          }
        }
      } catch (error) {
        // 
      }
    },
    async LinkEnableDisable (row) {
      try {
        let str = row.status ? '停用' : '启用'
        let confirm = await this.$confirm(`确认${str}该链接吗?`, '提示', { type: 'warning' })
        if (confirm) {
          let data = {
            id: row.id,
            status: row.status === 0 ? 1 : 0,
          }
          let res = await productionApi.LinkEnableDisable(data)
          if (res.data.respCode === '1000') {
            this.$message.success('操作成功')
            row.status = row.status === 0 ? 1 : 0
            this.getTableData()
          } else {
            this.$message.error(res.data.respMsg || '操作失败')
          }
        }
      } catch (error) {
        // 
      }
    },
    closeUrlForm () {
      this.$refs['urlDialogForm'].resetFields()
      this.urlDialog.miniTitle = '添加链接'
    },
    submitURL () {
      this.btnLoading = true
      this.$refs['urlDialogForm'].validate((valid) => {
        if (!valid) {
          this.btnLoading = false
          return false
        }
        let remark = this.trimSpace(this.urlDialog.addForm.remark, 'g')
        let addForm = this.urlDialog.addForm
        let params = {}
        if (this.urlDialog.miniTitle === '编辑链接') {
          params = {
            uvLimitFlag: Number(addForm.uvClickLimit) === 0 ? 0 : addForm.uvLimitFlag,
            uvHideFlag: Number(addForm.uvClickLimit) === 0 ? 0 : addForm.uvHideFlag,
          }
        } else if (this.urlDialog.miniTitle === '添加链接') {
          let seqId = null
          if (this.urlDialog.urlList.length) {
            let lengthId = this.urlDialog.urlList[this.urlDialog.urlList.length - 1].seqId
            if (lengthId < 21) {
              seqId = 21
            } else {
              seqId = this.urlDialog.urlList[this.urlDialog.urlList.length - 1].seqId + 1
            }
          }
          params = {
            productId: this.row.id,
            seqId: seqId,
          }
        }

        let data = {
          ...addForm,
          ...params,
          cellSystem: Number(addForm.cellSystem),
          productLine: Number(addForm.productLine),
          remark: remark,
        }
        this.addOrEditLink(data)
      })
    },
    async addOrEditLink (data) {
      try {
        let res = await productionApi.addOrEditLink(data)
        this.btnLoading = false
        if (res.data.respCode === '1000') {
          this.$message.success('操作成功')
          this.fetchUrlList(this.row)
          this.urlDialog.miniShow = false
        } else {
          this.$message.error(res.data.respMsg)
        }
      } catch (error) {
        this.btnLoading = false
      }
    },
    async addUrlList () {
      this.urlDialog.addForm = {
        regChannel: '',
        dockingType: '',
        settlementMode: '',
        unitPrice: '',
        ladderPrice: 0,
        firstLoanSharing: '',
        reloanSharing: '',
        address: '',
        cellSystem: '0',
        id: null,
        productId: '',
        productLine: '',
        remark: '',
        seqId: '',
        uvClickLimit: '',
        fillConstraintSite: false,
        constraintUvClickLimit: 0,
        uvLimitFlag: 0,
        uvHideFlag: 0,
        autoArpu: 1,
        linkLayer: '',
        clickArpu: '',
      }
      this.isJointLoginProduct = true
      this.urlDialog.miniTitle = '添加链接'
      this.urlDialog.miniShow = true
      // let arr = [{key: 0, value: 'H5'}]
      // let arr1 = [{key: 1, value: '联合登录'}]
      // let arr2 = [{key: 2, value: 'API'}]
      let isApi = false
      let isJointLoginProduct = false
      console.log(isApi, isJointLoginProduct)
      let res = await productionApi.isApiProduct(this.row.id)
      if (res.data.respCode === '1000') {
        if (res.data.body === false) {
          isApi = false
        } else {
          isApi = true
        }
      }

      let res2 = await productionApi.isJointLoginProduct(this.row.id)
      if (res.data.respCode === '1000') {
        if (res2.data.body.supportJointLogin === false) {
          isJointLoginProduct = false
        } else {
          isJointLoginProduct = true
        }
      }
      // dockingTypeArr: [
      //     {key: 0, value: 'H5'},
      //     {key: 1, value: '联合登录'},
      //     {key: 2, value: 'API'}
      //   ]
      if (isApi && isJointLoginProduct) {
        this.selectList.dockingTypeArr = [
          { key: 0, value: 'H5' },
          { key: 1, value: '联合登录' },
          { key: 2, value: 'API对接' },
        ]
      } else if (!isApi && isJointLoginProduct) {
        this.selectList.dockingTypeArr = [
          { key: 0, value: 'H5' },
          { key: 1, value: '联合登录' },
        ]
      } else if (isApi && !isJointLoginProduct) {
        this.selectList.dockingTypeArr = [
          { key: 0, value: 'H5' },
          { key: 2, value: 'API对接' },
        ]
      } else {
        this.selectList.dockingTypeArr = [
          { key: 0, value: 'H5' },
        ]
      }
    },
    async editMiniUrl (row) {
      this.urlRow = row
      let uvClickLimit = Number(row.uvClickLimit)
      this.urlDialog.addForm = {
        address: row.address,
        cellSystem: row.cellSystem + '',
        id: row.id,
        productId: row.productId,
        productLine: row.productLine + '',
        remark: row.remark,
        seqId: row.seqId,
        uvClickLimit: row.uvClickLimit,
        unitPrice: row.unitPrice,
        settlementMode: row.settlementMode === null ? '' : row.settlementMode + '',
        reloanSharing: row.reloanSharing ? row.reloanSharing.replace('%', '') : '',
        ladderPrice: row.ladderPrice,
        firstLoanSharing: row.firstLoanSharing ? row.firstLoanSharing.replace('%', '') : '',
        dockingType: row.dockingType,
        regChannel: row.regChannel,
        fillConstraintSite: row.fillConstraintSite,
        constraintUvClickLimit: row.constraintUvClickLimit,
        uvLimitFlag: uvClickLimit === 0 ? 0 : row.uvLimitFlag,
        uvHideFlag: uvClickLimit === 0 ? 0 : row.uvHideFlag,
        autoArpu: row.autoArpu || 1,
        linkLayer: row.linkLayer,
        clickArpu: row.clickArpu === '--' ? 0 : row.clickArpu,
      }
      this.urlDialog.miniTitle = '编辑链接'
      let res = await productionApi.isJointLoginProduct(this.row.id)
      if (res.data.respCode === '1000') {
        if (res.data.body.supportJointLogin === false) {
          this.isJointLoginProduct = true
          // this.urlDialog.addForm.regChannel = ''
        } else {
          this.isJointLoginProduct = false
        }
      } else {
        this.isJointLoginProduct = false
      }
      this.urlDialog.miniShow = true
    },
    async fetchUrlList (row) {
      let res = await productionApi.searchLinks(row.id)
      if (res.data.respCode === '1000') {
        this.urlDialog.urlList = res.data.body
      }
    },
    async toUrlList (row) {
      this.row = row
      await this.fetchUrlList(row)
      this.urlDialog.proTitle = row.name
      this.urlDialog.show = true
      this.urlDialog.addForm = {
        address: '',
        cellSystem: '0',
        id: null,
        productId: '',
        productLine: '',
        remark: '',
        seqId: '',
        uvClickLimit: '',
      }
    },
    async continueStart () {
      this.newDialog.continueLoading = true
      let res = await productionApi.isDisable(1)
      if (res.data.respCode === '1000') {
        this.newDialog.finalDialog = true
        this.newDialog.firstDialog = false
        this.getTableData()
        this.newDialog.continueLoading = false
      } else {
        this.newDialog.continueLoading = false
        this.$message.error(res.data.respMsg)
      }
    },
    async endUse (row) {
      try {
        let confirm = await this.$confirm(`确认停用该产品吗?`, '提示', { type: 'warning' })
        if (confirm) {
          this.startOrStopUseAgain(row)
        }
      } catch (error) {
        this.$message.warning('取消操作')
      }
      // let data = {
      //   productId: row.id
      // }
      // let res = await productionApi.disableCheck(data)
      // if (res.data.respCode === '1000') {
      //   this.newDialog.firstDialog = true
      //   try {
      //     if (res.data.body.length) {
      //       let successList = []
      //       let failList = []
      //       this.newDialog.allList = res.data.body
      //       res.data.body.forEach(t => {
      //         if (t.canAutoDrop) {
      //           successList.push(t)
      //         } else {
      //           failList.push(t)
      //         }
      //       })
      //       this.newDialog.successList = successList
      //       this.newDialog.failList = failList
      //     } else {
      //       this.newDialog.allList = []
      //     }
      //   } catch (error) {
      //     this.$message.error('服务端错误')
      //   }
      // } else {
      //   this.$message.error(res.data.respMsg)
      // }
    },
    handleResize () {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableHeight = h - 135
      })
    },
    // 筛选按钮
    handleSearch () {
      this.getTableData()
    },
    // 处理分页每页显示数改变事件
    handleSizeChange (val) {
      this.pagData.pageSize = val
      this.getTableData()
    },
    // 处理页码改变事件
    handleCurrentChange (val) {
      this.pagData.pageNum = val
      this.getTableData()
    },
    // 获取表格数据
    async getTableData () {
      this.listLoading = true
      this.searchLoading = true
      this.queryForm.pageNum = this.pagData.pageNum
      let data = {
        advertiserId: this.queryForm.advertiserId,
        status: this.queryForm.status ? parseInt(this.queryForm.status, 10) : null,
        tag: this.queryForm.tag ? parseInt(this.queryForm.tag, 10) : null,
        pageNum: this.queryForm.pageNum,
        pageSize: this.pagData.pageSize,
        name: this.queryForm.name,
        id: this.queryForm.id ? this.queryForm.id : null,
        vip: this.queryForm.vip,
      }
      try {
        let res = await productionApi.fetchTableData(data)
        if (res.data.respCode === '1000') {
          // this.tableData = Object.freeze(res.data.body.list)
          this.tableData = res.data.body.list
          this.tableData.forEach((item) => {
            item.baseLinks = JSON.parse(JSON.stringify(item.links))
          })
          this.totalRecord = res.data.body.total
          this.listLoading = false
          this.searchLoading = false
          if (this.pagData.pageNum > 1 && this.tableData.length === 0) {
            this.pagData.pageNum = 1
            this.getTableData()
          }
        } else {
          this.listLoading = false
          this.searchLoading = false
        }
      } catch (error) {
        this.listLoading = false
        this.searchLoading = false
        console.log(error)
      }
    },
    // 编辑广告图片按钮
    handleAdverPicEdit (value) {
      this.directionName = value.name
      this.openAds = JSON.parse(JSON.stringify(value.openAds))
      this.homePops = JSON.parse(JSON.stringify(value.homePops))
      this.homeBanners = JSON.parse(JSON.stringify(value.homeBanners))
      this.AdvPicForm = {
        couponContent: value.couponContent ? value.couponContent : '',
        couponName: value.couponName ? value.couponName : '',
        subCouponName: value.subCouponName ? value.subCouponName : '',
      }
      this.productId = value.id
      this.dialogVisibleAdverPic = true
    },
    // 广告图片编辑-开屏广告上传成功
    openAdvSuccess (response) {
      if (response.respCode === '1000') {
        this.openAds.push({
          'imgUrl': response.body,
          'remark': '',
          'seqId': this.openAds.length ? this.openAds[this.openAds.length - 1].seqId + 1 : 1,
        })
      } else {
        this.$message.error(response.respMsg)
      }
    },
    // 首页banner上传成功
    openBannerSuccess (response) {
      if (response.respCode === '1000') {
        this.homeBanners.push({
          'imgUrl': response.body,
          'remark': '',
          'seqId': this.homeBanners.length ? this.homeBanners[this.homeBanners.length - 1].seqId + 1 : 1,
        })
      } else {
        this.$message.error(response.respMsg)
      }
    },
    // 首页弹框上传成功
    openPopsSuccess (response) {
      if (response.respCode === '1000') {
        this.homePops.push({
          'imgUrl': response.body,
          'remark': '',
          'seqId': this.homePops.length ? this.homePops[this.homePops.length - 1].seqId + 1 : 1,
        })
      } else {
        this.$message.error(response.respMsg)
      }
    },
    getOpenAds (value) {
      this.openAds = value
    },
    getHomeBanners (value) {
      this.homeBanners = value
    },
    getHomePops (value) {
      this.homePops = value
    },
    handleAdvPicConfirm () {
      this.$refs['AdvPicForm'].validate(async (valid) => {
        console.log(valid)
        if (!valid) {
          return false
        }
        let data = {
          couponContent: this.AdvPicForm.couponContent,
          couponName: this.AdvPicForm.couponName,
          subCouponName: this.AdvPicForm.subCouponName,
          openAds: this.openAds,
          homeBanners: this.homeBanners,
          homePops: this.homePops,
          productId: this.productId,
        }
        let res = await productionApi.fetchEditAdPic(data)
        if (res.data.respCode === '1000') {
          this.$message.success('编辑广告图片成功')
          this.dialogVisibleAdverPic = false
          this.getTableData()
        } else {
          this.$message.error(res.data.respMsg || '接口错误')
          this.dialogVisibleAdverPic = false
        }
      })
      /* if (!this.openAds.length && !this.homeBanners.length && !this.homePops.length) {
        this.$message.warning('请至少上传一张图片')
        return false
      } */
    },
    // 编辑广告图片关闭
    handleAdvPicClose () {
      this.openAds = []
      this.homeBanners = []
      this.homePops = []
      this.productId = null
      this.$refs.AdvPicForm.resetFields()
    },
    // 编辑按钮
    async handleEdit (value) {
      this.addOrEditProductType = 'edit'
      this.dialogVisibleEdit = true
      let tagIds = []
      if (value.tagIds !== '') {
        tagIds = value.tagIds.split(',')
        tagIds = tagIds.map(Number)
      }
      this.addOrEditForm = { ...this.addOrEditForm, ...value, hitSwitch: false, tagIds: tagIds }
      delete this.addOrEditForm['advertiserName']
      this.addOrEditForm.advertiserId = this.addOrEditForm.advertiserId + ''
      this.addOrEditForm.specialTags = value.specialTags
      this.addOrEditForm.regAgreeUrl = value.regAgreeUrl
      this.addOrEditForm.safeLink = value.safeLink
      this.addOrEditForm.passRate = parseInt(value.passRate, 10) || null
      if (value.vip === null || value.vip === '') this.addOrEditForm.vip = 0
      // for (let i = 0; i < this.addOrEditForm.links.length; i++) {
      //   if (this.addOrEditForm.links[i].seqId === 1 || this.addOrEditForm.links[i].seqId === 2) {
      //     if (this.addOrEditForm.links[i].resetFlag === 1) {
      //       this.addOrEditForm.links[i].resetFlag = true
      //     } else {
      //       this.addOrEditForm.links[i].resetFlag = false
      //     }
      //   }
      // }
      // this.addOrEditForm.baseLinks = JSON.parse(JSON.stringify(this.addOrEditForm.links))

      let res = await productionApi.isJointLoginProduct(value.id)
      if (res.data.respCode === '1000') {
        if (res.data.body.supportJointLogin === false) {
          this.isJointLoginProduct = true
          this.urlDialog.addForm.regChannel = ''
          this.addOrEditForm.hitSwitch = null
        } else {
          this.isJointLoginProduct = false
          this.addOrEditForm.hitSwitch = res.data.body.hitSwitch
          // console.log(this.addOrEditForm.hitSwitch, res.data.body.hitSwitch)
        }
      } else {
        this.isJointLoginProduct = false
      }

      let res2 = await productionApi.isApiProduct(value.id)
      if (res2.data.respCode === '1000') {
        if (res2.data.body === false) {
          this.isApi = false
        } else {
          this.isApi = true
        }
      }
      this.dialogVisibleEdit = true
      this.isAddOrEdit = false
    },
    // 启用或者启用按钮
    startOrStopUse (value) {
      if (value.status) {
        this.isCanStopUse(value)
      } else {
        let str = value.status ? '停用' : '启用'
        this.$confirm('确定' + str + '吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }).then(() => {
          this.startOrStopUseAgain(value)
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消操作',
          })
        })
      }
    },
    async isCanStopUse (value) {
      let data = {
        productId: value.id,
      }
      let res = await productionApi.fetchIsEnableOrDisable(data)
      if (res.data.respCode === '1000') {
        if (res.data.body.canDisable) {
          this.$confirm('该产品可以停用，是否停用？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }).then(() => {
            this.startOrStopUseAgain(value)
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '已取消停用',
            })
          })
        } else {
          let str = ''
          res.data.body.useArea.forEach((item) => {
            str += (this.bigTag[item.channelId] + ',' + this.tagObj[item.classifyCode] + '<br/>')
          })
          this.$alert(str, '该产品暂无法停用，请在以下位置下架该产品', {
            confirmButtonText: '我知道了',
            dangerouslyUseHTMLString: true,
            callback: () => {
              // 
            },
          })
        }
      } else {
        this.$message.error(res.data.respMsg || '接口错误')
      }
    },
    async startOrStopUseAgain (value) {
      let data = {
        productId: value.id,
        status: 0,
      }
      let res = await productionApi.fetchEnableOrDisable(data)
      if (res.data.respCode === '1000') {
        this.$message.success(value.status ? '停用成功' : '启用成功')
        this.getTableData()
      } else {
        this.$message.error(res.data.respMsg || '接口错误')
      }
    },
    // 新建产品
    handleAddProduct () {
      this.addOrEditProductType = 'add'
      this.isApi = false
      this.isJointLoginProduct = true
      this.dialogVisibleEdit = true
      this.addOrEditForm = {
        customPhoneType: 0,
        advertiserId: '',
        links: [{ 'address': '', 'remark': '', 'seqId': 1 }],
        baseLinks: [{ 'address': '', 'remark': '花钱无忧专用', 'seqId': 1 }, { 'address': '', 'remark': '贷款王专用', 'seqId': 2 }, { 'address': '', 'remark': '', 'seqId': 21 }],
        name: '',
        subhead: '',
        productLimitStart: null,
        productLimitEnd: null,
        durationStart: null,
        durationEnd: null,
        durationType: 0,
        rateStart: null,
        rateEnd: null,
        rateType: 2,
        averagePrice: '',
        passRate: '',
        loanTime: '',
        loanType: 0,
        applyTips: '',
        applyFlow: '',
        tagName: '',
        tagColor: null,
        prompt: '',
        detailPrompt: '',
        status: null,
        specialTags: [],
        logo: '',
        id: null,
        // dkwArpu: '',
        // freeLoanArpu: '',
        // productLayer: 'C',
        regAgreeUrl: '',
        hitSwitch: false,
        customPhone: '',
        vip: 0,
        // ljjArpu: '',
        tagIds: [],
        safeLink: 0,
      }
      this.isAddOrEdit = true
    },
    removeLogo () {
      this.addOrEditForm.logo = ''
    },
    uploadLogoSuccess (response) {
      if (response.respCode === '1000') {
        this.addOrEditForm.logo = response.body
      } else {
        this.$message.error(response.respMsg)
      }
    },
    // 校验是否重名
    async judeIsRepeatName () {
      let data = {
        name: this.addOrEditForm.name,
        productId: this.addOrEditForm.id,
      }
      let res = await productionApi.fetchIsRepeatName(data)
      if (res.data.respCode === '1000') {
        if (res.data.body.duplicate) {
          this.$alert('\'' + this.addOrEditForm.name + '\'已存在，请确认当前产品不同于已有产品?', '产品重名提示:', {
            confirmButtonText: '我知道了',
            showClose: false,
            callback: () => {
              // 
            },
          })
        } else {
          return false
        }
      } else {
        this.$message.error(res.data.respMsg || '接口错误')
      }
    },
    // 编辑弹框关闭
    handleEditFormClose () {
      this.resetEditForm('addOrEditForm')
    },
    resetEditForm (formName) {
      this.$refs[formName].resetFields()
      // 操作编辑-编辑表单
      this.addOrEditForm = {
        advertiserId: '',
        links: [{ 'address': '', 'remark': '', 'seqId': 1 }, { 'address': '', 'remark': '', 'seqId': 2 }],
        baseLinks: [{ 'address': '', 'remark': '花钱无忧专用', 'seqId': 1 }, { 'address': '', 'remark': '贷款王专用', 'seqId': 2 }, { 'address': '', 'remark': '贷款王专用', 'seqId': 21 }],
        name: '',
        subhead: '',
        productLimitStart: null,
        productLimitEnd: null,
        durationStart: null,
        durationEnd: null,
        durationType: 0,
        rateStart: null,
        rateEnd: null,
        rateType: 2,
        averagePrice: '',
        passRate: '',
        loanTime: '',
        loanType: 0,
        applyTips: '',
        applyFlow: '',
        tagName: '',
        tagColor: null,
        prompt: '',
        detailPrompt: '',
        status: null,
        specialTags: [],
        logo: '',
        id: null,
        // dkwArpu: '',
        // freeLoanArpu: '',
        // productLayer: 'C',
        regAgreeUrl: '',
        customPhone: '',
        tagIds: [],
      }
    },
    // 操作编辑-增加链接
    addEditFormLink () {
      let addNUM = null
      if (this.addOrEditForm.baseLinks.length === 2) {
        addNUM = 19
      } else {
        addNUM = 1
      }
      if (this.addOrEditForm.baseLinks.length === 1) {
        this.addOrEditForm.baseLinks.push({ 'address': '', 'remark': '贷款王专用', 'seqId': this.addOrEditForm.baseLinks[this.addOrEditForm.baseLinks.length - 1].seqId + addNUM })
      } else {
        this.addOrEditForm.baseLinks.push({ 'address': '', 'remark': '', 'seqId': this.addOrEditForm.baseLinks[this.addOrEditForm.baseLinks.length - 1].seqId + addNUM })
      }
    },
    // 操作编辑-删除链接
    removeEditFormLink (seqId) {
      this.addOrEditForm.baseLinks.forEach((item, index) => {
        if (item.seqId === seqId) {
          if (item.inUse) {
            let str = ''
            item.useArea.forEach((item) => {
              str += (this.bigTag[item.channelId] + ',' + this.tagObj[item.classifyCode] + '<br/>')
            })
            this.$alert(str, '该链接暂无法删除，请先在以下位置更换产品链接或下架该产品', {
              confirmButtonText: '我知道了',
              dangerouslyUseHTMLString: true,
              showClose: false,
              callback: () => {
                // 
              },
            })
          } else {
            this.$confirm('确认删除该链接？', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning',
            }).then(() => {
              this.addOrEditForm.baseLinks.splice(index, 1)
            }).catch(() => {
              this.$message({
                type: 'info',
                message: '已取消删除',
              })
            })
          }
        }
      })
    },
    // 操作编辑-获取特色标签数据
    // getSpecialTags (value) {
    //   this.addOrEditForm.specialTags = value
    // },
    // 操作编辑取消
    handleAddOrEditCancel () {
      this.dialogVisibleEdit = false
      this.getTableData()
    },
    // 操作编辑-确认
    handleAddOrEditConfirm () {
      this.submitEditForm('addOrEditForm')
    },
    submitEditForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          // 默认链接去除了
          // if (this.addOrEditForm.baseLinks[0].address === '' && this.addOrEditForm.baseLinks[1].address === '') {
          //   return this.$message.error('链接1与链接2至少要填写一个!')
          // }

          // this.addOrEditForm.links = JSON.parse(JSON.stringify(this.addOrEditForm.baseLinks))
          // let linksArr = []
          // for (let i = 0; i < this.addOrEditForm.links.length; i++) {
          //   if (i < 2) {
          //     linksArr.push(this.addOrEditForm.links[i])
          //   }
          //   if (i > 1) {
          //     if (this.addOrEditForm.links[i].address !== '') {
          //       linksArr.push(this.addOrEditForm.links[i])
          //     }
          //   }
          // }
          // this.addOrEditForm.links = linksArr
          if (this.isAddOrEdit) {
            this.fetchAddForm()
          } else {
            this.fetchEditForm()
          }
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    trimSpace (str, isGlobal) {
      let result
      result = str.replace(/(^\s+)|(\s+$)/g, '')
      if (isGlobal.toLowerCase() === 'g') {
        result = result.replace(/\s/g, '')
      }
      return result
    },
    async fetchAddForm () {
      this.btnLoading = true
      this.addOrEditForm.name = this.trimSpace(this.addOrEditForm.name, 'g')
      let data = {
        ...this.addOrEditForm,
        tagIds: this.addOrEditForm.tagIds.join(','),
      }
      let res = await productionApi.fetchAddProduct(data)
      this.btnLoading = false
      if (res.data.respCode === '1000') {
        this.$message.success('新建成功')
        this.dialogVisibleEdit = false
        this.getTableData()
      } else {
        this.$message.error(res.data.respMsg || '接口错误')
      }
    },
    async fetchEditForm () {
      this.btnLoading = true
      // this.addOrEditForm.links.forEach(t => {
      //   if (t.seqId === 1 || t.seqId === 2) {
      //     if (t.resetFlag === true) {
      //       t.resetFlag = 1
      //     } else {
      //       t.resetFlag = 0
      //     }
      //   }
      // })
      this.addOrEditForm.name = this.trimSpace(this.addOrEditForm.name, 'g')
      // if (this.addOrEditForm.customPhone !== '' && this.addOrEditForm.customPhone) {
      //   this.addOrEditForm.customPhone = Number(this.addOrEditForm.customPhone)
      // } else {
      //   this.addOrEditForm.customPhone = null
      // }
      let data = {
        ...this.addOrEditForm,
        tagIds: this.addOrEditForm.tagIds.join(','),
      }
      // this.addOrEditForm.customPhone = Number(this.addOrEditForm.customPhone)
      let res = await productionApi.fetchEditProduct(data)
      this.btnLoading = false
      if (res.data.respCode === '1000') {
        this.$message.success('编辑成功')
        this.dialogVisibleEdit = false
        this.getTableData()
      } else {
        this.$message.error(res.data.respMsg || '接口错误')
      }
    },
    changeSwitch () {
      this.$refs['userDirectionAPIform'].validate((valid) => {
        console.log(valid)
        if (!valid) {
          return false
        }
      })
    },
    // 用户定向-编辑
    async handleDirectionEdit (value) {
      this.directionName = value.name
      this.directionId = value.id
      // this.userDirectionForm = Object.assign({}, value)
      this.userDirectionForm = {
        ...this.userDirectionForm,
        ...value,
        age: JSON.parse(JSON.stringify(value.age)),
      }
      this.dialogVisibleDirection = true
      const pra = { productId: value.id }
      const { data } = await productionApi.selectByProductId(pra)
      if (data.respCode === '1000') {
        if (data.body.age) {
          this.userDirectionAPIform.ageLimit = data.body.age.limitValue.split(',')
          this.userDirectionAPIform.status.age = data.body.age.status
        }
        if (data.body.idCardAreaLimit) {
          this.userDirectionAPIform.idCardAreaLimit = data.body.idCardAreaLimit.limitValue.split(',')
          this.userDirectionAPIform.status.idCardAreaLimit = data.body.idCardAreaLimit.status
        }
        if (data.body.idCardNoAreaLimit) {
          this.userDirectionAPIform.idCardNoAreaLimit = data.body.idCardNoAreaLimit.limitValue.split(',')
          this.userDirectionAPIform.status.idCardNoAreaLimit = data.body.idCardNoAreaLimit.status
        }
        if (data.body.liveAreaLimit) {
          this.userDirectionAPIform.liveAreaLimit = data.body.liveAreaLimit.limitValue.split(',')
          this.userDirectionAPIform.status.liveAreaLimit = data.body.liveAreaLimit.status
        }
        if (data.body.locationAreaAreaLimit) {
          this.userDirectionAPIform.locationAreaAreaLimit = data.body.locationAreaAreaLimit.limitValue.split(',')
          this.userDirectionAPIform.status.locationAreaAreaLimit = data.body.locationAreaAreaLimit.status
        }
        if (data.body.carrireRealNameLimit) {
          this.userDirectionAPIform.carrireRealNameLimit = data.body.carrireRealNameLimit.limitValue
          this.userDirectionAPIform.status.carrireRealNameLimit = data.body.carrireRealNameLimit.status
        }
        if (data.body.phoneUseLimit) {
          this.userDirectionAPIform.phoneUseLimit = data.body.phoneUseLimit.limitValue
          this.userDirectionAPIform.status.phoneUseLimit = data.body.phoneUseLimit.status
        }
        if (data.body.phoneCallLogLimit) {
          this.userDirectionAPIform.phoneCallLogLimit = data.body.phoneCallLogLimit.limitValue
          this.userDirectionAPIform.status.phoneCallLogLimit = data.body.phoneCallLogLimit.status
        }
      }
    },
    // 切换预筛
    changeSystemModule () {
      if (this.$refs.userDirectionForm) {
        this.$refs.userDirectionForm.clearValidate()
      }
      if (this.$refs.userDirectionAPIform) {
        this.$refs.userDirectionAPIform.clearValidate()
      }
    },
    // 用户定向-编辑确认
    handleDirectionConfirm () {
      if (this.SystemModule === '0') {
        this.submitDirectionForm('userDirectionForm')
      } else {
        this.submitDirectionForm('userDirectionAPIform')
      }
    },
    submitDirectionForm (formName) {
      if (this.SystemModule === '0') {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.fetchDirectionForm()
          } else {
            console.log('error submit!!')
            return false
          }
        })
      } else {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.fetchDirectionAPI()
          } else {
            console.log('error submit!!')
            return false
          }
        })
      }
    },
    async fetchDirectionAPI () {
      let age, idCardAreaLimit, idCardNoAreaLimit, liveAreaLimit, locationAreaAreaLimit
      age = this.userDirectionAPIform.ageLimit.join(',')
      idCardAreaLimit = this.userDirectionAPIform.idCardAreaLimit.join(',')
      idCardNoAreaLimit = this.userDirectionAPIform.idCardNoAreaLimit.join(',')
      liveAreaLimit = this.userDirectionAPIform.liveAreaLimit.join(',')
      locationAreaAreaLimit = this.userDirectionAPIform.locationAreaAreaLimit.join(',')

      let pra = {
        age: {
          limitCode: '1',
          limitValue: age,
          status: this.userDirectionAPIform.status.age,
        },
        idCardAreaLimit: {
          limitCode: '2',
          limitValue: idCardAreaLimit,
          status: this.userDirectionAPIform.status.idCardAreaLimit,
        },
        idCardNoAreaLimit: {
          limitCode: '3',
          limitValue: idCardNoAreaLimit,
          status: this.userDirectionAPIform.status.idCardNoAreaLimit,
        },
        liveAreaLimit: {
          limitCode: '4',
          limitValue: liveAreaLimit,
          status: this.userDirectionAPIform.status.liveAreaLimit,
        },
        locationAreaAreaLimit: {
          limitCode: '5',
          limitValue: locationAreaAreaLimit,
          status: this.userDirectionAPIform.status.locationAreaAreaLimit,
        },
        carrireRealNameLimit: {
          limitCode: '6',
          limitValue: this.userDirectionAPIform.carrireRealNameLimit,
          status: this.userDirectionAPIform.status.carrireRealNameLimit,
        },
        phoneUseLimit: {
          limitCode: '7',
          limitValue: this.userDirectionAPIform.phoneUseLimit,
          status: this.userDirectionAPIform.status.phoneUseLimit,
        },
        phoneCallLogLimit: {
          limitCode: '8',
          limitValue: this.userDirectionAPIform.phoneCallLogLimit,
          status: this.userDirectionAPIform.status.phoneCallLogLimit,
        },
        productId: this.directionId,
      }
      for (let key in pra) {
        if (pra[key].limitValue === '') {
          delete pra[key]
        }
      }
      let res = await productionApi.productLimitSave(pra)
      if (res.data.respCode === '1000') {
        this.$_message.success('操作成功')
        this.dialogVisibleDirection = false
        this.getTableData()
      } else {
        this.$_message.error(res.data.respMsg)
      }
    },
    async fetchDirectionForm () {
      let data = {
        discardProvince: this.userDirectionForm.discardProvince,
        age: this.userDirectionForm.age,
        creditScore: this.userDirectionForm.creditScore,
        phoneUseTime: this.userDirectionForm.phoneUseTime,
        creditCard: this.userDirectionForm.creditCard,
        // career: this.userDirectionForm.career,
        // socialSecurity: this.userDirectionForm.socialSecurity,
        fund: this.userDirectionForm.fund,
        productInfoId: this.userDirectionForm.id,
      }
      let res = await productionApi.fetchEditUserDirect(data)
      if (res.data.respCode === '1000') {
        this.$_message.success('编辑成功')
        this.dialogVisibleDirection = false
        this.getTableData()
      } else {
        this.$_message.error(res.data.respMsg || '接口错误')
        // this.dialogVisibleDirection = false
      }
    },
    // 用户定向弹框关闭
    handleUserDirectionFormClose () {
      if (this.$refs['userDirectionForm']) {
        this.resetUserDirectionForm('userDirectionForm')
      }
      this.SystemModule = '0'

      this.userDirectionAPIform = {
        ageLimit: [],
        // 身份证号码地区屏蔽
        idCardAreaLimit: [],
        // 身份证地址地区屏蔽
        idCardNoAreaLimit: [],
        // 居住地区屏蔽
        liveAreaLimit: [],
        // 定位地区屏蔽
        locationAreaAreaLimit: [],
        //  运营商是否实名且本人 1:实名且本人，2：未实名
        carrireRealNameLimit: '1',
        // 手机号使用月份
        phoneUseLimit: '',
        // 手机通话记录月份
        phoneCallLogLimit: '',
        status: {
          age: 1,
          idCardAreaLimit: 1,
          idCardNoAreaLimit: 1,
          liveAreaLimit: 1,
          locationAreaAreaLimit: 1,
          carrireRealNameLimit: 1,
          phoneUseLimit: 1,
          phoneCallLogLimit: 1,
        },
      }
      // if (this.$refs['userDirectionAPIform']) {
      //   this.$refs['userDirectionAPIform'].resetFields()
      // }
    },
    resetUserDirectionForm (formName) {
      this.$refs[formName].resetFields()
      // 用户定向编辑-验证表单
      this.userDirectionForm = {
        phoneUseTime: 8,
        creditCard: 0,
        // socialSecurity: 0,
        fund: 0,
        discardProvince: [],
        age: [18, 60],
        // career: [],
        creditScore: 8,
      }
    },
    // 用户定向-获取芝麻分
    getCreditScore (value) {
      this.userDirectionForm.creditScore = value
    },
    // 用户定向-获取职业身份
    // getCareer (value) {
    //   this.userDirectionForm.career = value
    // },
    // 批量修改-清空已上传的文件列表
    handleClearFiles () {
      this.ARPUfileList = []
      this.file = null
    },
    // 批量修改-上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
    handleUploadBefore (file) {
      if (file.name && file.name.length > 0) {
        const ldot = file.name.lastIndexOf('.')
        const type = file.name.toLowerCase().substring(ldot)
        if (type !== '.csv') {
          this.$message.warning('目前只支持.csv格式的文件')
          return false
        }
        this.uploadFileName = file.name
        console.log(this.uploadFileName)
      }
    },
    // 批量修改-文件上传成功时的钩子
    handleUploadSuccess () {
      console.log('上传成功')
      this.uploadTagVisible = true
    },
    // 批量修改-文件上传失败时的钩子
    handleUploadError (err) {
      if (err.status === 404) {
        this.$message.error('上传失败，网络连接异常!')
      } else {
        console.log(err)
        this.$message.error('上传失败!')
      }
    },
    // 导入项目-文件上传时的钩子
    handleUploadProgress () {
      console.log('上传中...')
    },
    handleUploadChange (file) {
      this.handleClearFiles()
      this.ARPUfileList = [file]
      this.uploadFileName = file.name
      this.file = file.raw
    },
    closeFile () {
      this.$refs.uploadFile && this.$refs.uploadFile.clearFiles()
      this.handleClearFiles()
    },
    batchDown () {
      let data = {
        status: this.queryForm.status ? parseInt(this.queryForm.status, 10) : '',
        tag: this.queryForm.tag ? parseInt(this.queryForm.tag, 10) : '',
        name: this.queryForm.name,
        id: this.queryForm.id ? this.queryForm.id : '',
      }
      if (this.batchUploadDialog.type === 1) {
        window.location.href = process.env.BASE_API + `/product/productArpuExport?status=${data.status}&tag=${data.tag}&name=${data.name}&id=${data.id}`
      }
      if (this.batchUploadDialog.type === 2) {
        window.location.href = process.env.BASE_API + `/product/productUvClickLimitExport?status=${data.status}&tag=${data.tag}&name=${data.name}&id=${data.id}`
      }
    },
    async fetchUpload () {
      if (!this.file) return this.$message.error('请先选择文件')
      this.uploading = true
      let param = new window.FormData()
      param.append('file', this.file)
      try {
        if (this.batchUploadDialog.type === 1) {
          let res = await productionApi.productArpuImport(param)
          if (res.data.respCode === '1000') {
            this.$message.success('上传成功')
            this.uploading = false
            this.getTableData()
            this.batchUploadDialog.show = false
          } else {
            this.$message.error(res.data.respMsg)
            this.uploading = false
          }
        }
        if (this.batchUploadDialog.type === 2) {
          let res = await productionApi.productUvClickLimitImport(param)
          if (res.data.respCode === '1000') {
            this.$message.success('上传成功')
            this.uploading = false
            this.getTableData()
            this.batchUploadDialog.show = false
          } else {
            this.$message.error(res.data.respMsg)
            this.uploading = false
          }
        }
      } catch (error) {
        this.uploading = false
      }
    },
    async fetchActiveList () {
      let res = await productionApi.commonTagActiveList()
      if (res.data.respCode === '1000') {
        this.selectList.activeList = res.data.body
      }
    },
    changeSettlementMode () {
      this.urlDialog.addForm.unitPrice = ''
      this.urlDialog.addForm.firstLoanSharing = ''
      this.urlDialog.addForm.reloanSharing = ''
      this.$refs.urlDialogForm.validate(() => {
        // 
      })
    },
  },
}
</script>
<style lang="scss" scoped>
.colorBox {
  display: inline-block;
  position: relative;
  width: 30px;
  height: 30px;
  margin-left: 5px;
  cursor: pointer;
}
.icon-position {
  position: absolute;
  color: white;
  top: 5px;
  left: 5px;
  font-size: 16px;
}
.production-wrapper {
  .length-API {
    width: 270px;
  }
  .length-1 {
    width: 190px;
  }
  .length-2 {
    width: 100px;
  }
  .length-area {
    width: 300px;
  }
  .length-3 {
    width: 100%;
  }
  .font {
    color: #999999;
  }
  .font-2 {
    font-weight: bolder;
    color: black;
    margin-left: 10px;
    margin-right: 10px;
  }
  .product-status {
    display: flex;
    justify-content: space-around;
  }
  .margin {
    margin-left: 5px;
  }
  .logoImg {
    display: inline-block;
    width: 100px;
    height: 100px;
    border: 1px dashed #c0ccda;
  }
  img {
    width: 100%;
    height: 100%;
  }
  .font {
    margin-left: 20px;
    color: #99a9bf;
  }
}
</style>