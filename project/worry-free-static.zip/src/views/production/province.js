
export const PROVINCE_LIST = [
  { 'limitName': '新疆', 'limitValue': 29 },
  { 'limitName': '西藏', 'limitValue': 28 },
  { 'limitName': '内蒙古', 'limitValue': 19 },
  { 'limitName': '黑龙江', 'limitValue': 12 },
  { 'limitName': '青海', 'limitValue': 21 },
  { 'limitName': '辽宁', 'limitValue': 18 },
  { 'limitName': '四川', 'limitValue': 26 },
  { 'limitName': '甘肃', 'limitValue': 5 },
  { 'limitName': '宁夏', 'limitValue': 20 },
  { 'limitName': '贵州', 'limitValue': 8 },
  { 'limitName': '吉林', 'limitValue': 15 },
  { 'limitName': '广西', 'limitValue': 7 },
  { 'limitName': '云南', 'limitValue': 30 },
  { 'limitName': '海南', 'limitValue': 9 },
  { 'limitName': '福建', 'limitValue': 4 },
  { 'limitName': '陕西', 'limitValue': 24 },
  { 'limitName': '山西', 'limitValue': 23 },
  { 'limitName': '河北', 'limitValue': 10 },
  { 'limitName': '河南', 'limitValue': 11 },
  { 'limitName': '安徽', 'limitValue': 3 },
  { 'limitName': '山东', 'limitValue': 22 },
  { 'limitName': '江西', 'limitValue': 17 },
  { 'limitName': '湖南', 'limitValue': 14 },
  { 'limitName': '湖北', 'limitValue': 13 },
  { 'limitName': '重庆', 'limitValue': 32 },
  { 'limitName': '北京', 'limitValue': 2 },
  { 'limitName': '广东', 'limitValue': 6 },
  { 'limitName': '江苏', 'limitValue': 16 },
  { 'limitName': '上海', 'limitValue': 25 },
  { 'limitName': '天津', 'limitValue': 27 },
  { 'limitName': '浙江', 'limitValue': 31 },
]

export const PROVINCE = [
  { 'limitName': '新疆', 'limitValue': '29' },
  { 'limitName': '西藏', 'limitValue': '28' },
  { 'limitName': '内蒙古', 'limitValue': '19' },
  { 'limitName': '黑龙江', 'limitValue': '12' },
  { 'limitName': '青海', 'limitValue': '21' },
  { 'limitName': '辽宁', 'limitValue': '18' },
  { 'limitName': '四川', 'limitValue': '26' },
  { 'limitName': '甘肃', 'limitValue': '5' },
  { 'limitName': '宁夏', 'limitValue': '20' },
  { 'limitName': '贵州', 'limitValue': '8' },
  { 'limitName': '吉林', 'limitValue': '15' },
  { 'limitName': '广西', 'limitValue': '7' },
  { 'limitName': '云南', 'limitValue': '30' },
  { 'limitName': '海南', 'limitValue': '9' },
  { 'limitName': '福建', 'limitValue': '4' },
  { 'limitName': '陕西', 'limitValue': '24' },
  { 'limitName': '山西', 'limitValue': '23' },
  { 'limitName': '河北', 'limitValue': '10' },
  { 'limitName': '河南', 'limitValue': '11' },
  { 'limitName': '安徽', 'limitValue': '3' },
  { 'limitName': '山东', 'limitValue': '22' },
  { 'limitName': '江西', 'limitValue': '17' },
  { 'limitName': '湖南', 'limitValue': '14' },
  { 'limitName': '湖北', 'limitValue': '13' },
  { 'limitName': '重庆', 'limitValue': '32' },
  { 'limitName': '北京', 'limitValue': '2' },
  { 'limitName': '广东', 'limitValue': '6' },
  { 'limitName': '江苏', 'limitValue': '16' },
  { 'limitName': '上海', 'limitValue': '25' },
  { 'limitName': '天津', 'limitValue': '27' },
  { 'limitName': '浙江', 'limitValue': '31' },
]
export const TAG_OBJ = {
  '9': '首页主列表',
  '22': '首页预估可贷',
  '1': '首页分类-1',
  '2': '首页分类-2',
  '3': '首页分类-3',
  '4': '首页分类-4',
  '11': '跑马灯',
  '12': '贷款大全',
  '13': '猜你可贷',
  '18': '开屏广告',
  '6': '首页banner',
  '20': '首页弹窗',
  '21': '首页悬浮广告',
  '7': '中部banner-1',
  '8': '中部banner-2',
  '14': '优惠券',
  '23': '首页API banner',
}

export const BIG_TAG = {
  1: '花钱无忧(安卓)',
  2: '花钱无忧(ios)',
  3: '贷款王(安卓)',
  4: '贷款王(ios)',
}

// 用户定向编辑-芝麻分
export const CREDIT_SCORE_LIST = [
  // { 'limitName': '不限', 'limitValue': 9 },
  // { 'limitName': '0-549', 'limitValue': 0 },
  // { 'limitName': '550-649', 'limitValue': 1 },
  { 'limitName': '无要求', 'limitValue': 0 },
  { 'limitName': '550及以上', 'limitValue': 1 },
  { 'limitName': '650及以上', 'limitValue': 2 },
]
// 用户定向编辑-信用卡
export const CAEDIT_CARD_LIST = [
  // { 'limitName': '不限', 'limitValue': 9 },
  // { 'limitName': '有', 'limitValue': 1 },
  // { 'limitName': '无', 'limitValue': 0 },
  { 'limitName': '无要求', 'limitValue': 0 },
  { 'limitName': '需要', 'limitValue': 1 },
]
// 用户定向编辑-手机号使用时长
export const PHONE_TIME_LIST = [
  // {'limitName': '不限', 'limitValue': 9},
  // {'limitName': '1-6个月', 'limitValue': 0},
  { 'limitName': '无要求', 'limitValue': 0 },
  { 'limitName': '6个月以上', 'limitValue': 1 },
]
// 用户定向编辑-职业身份
export const CAREER_LIST = [
  { 'limitName': '工薪族', 'limitValue': 0 },
  { 'limitName': '企业主', 'limitValue': 1 },
  { 'limitName': '自由职业', 'limitValue': 3 },
  { 'limitName': '其他', 'limitValue': 2 },
]
// 用户定向编辑-社保
export const SOCIAL_SECURITY_LIST = [
  { 'limitName': '不限', 'limitValue': 9 },
  { 'limitName': '需要', 'limitValue': 1 },
  { 'limitName': '不需要', 'limitValue': 0 },
]
// 用户定向编辑-公积金
export const ACCUMULATION_FUND_LIST = [
  // { 'limitName': '不限', 'limitValue': 9 },
  { 'limitName': '无要求', 'limitValue': 0 },
  { 'limitName': '需要', 'limitValue': 1 },
  // { 'limitName': '不需要', 'limitValue': 0 },
]
// 用户定向编辑-手机系统
export const PHONE_SYSTEM_LIST = [
  { 'limitName': '不限', 'limitValue': 9 },
  { 'limitName': 'Android', 'limitValue': 1 },
  { 'limitName': 'IOS', 'limitValue': 2 },
]
// 用户定向编辑-产品分层
export const productLayerList = [
  { 'key': 'A', 'value': 'A' },
  { 'key': 'B', 'value': 'B' },
  { 'key': 'C', 'value': 'C' },
]
// 链接编辑-链接分层
export const linkLayer = [
  { 'key': 'A', 'value': 'A' },
  { 'key': 'B', 'value': 'B' },
  { 'key': 'C', 'value': 'C' },
]

export const rateTypeList = {
  0:'每日',
  1:'每月',
  2:'每年',
}

export const data = {
  age: {
    limitCode: '1',
    limitValue: '18,25',
    status: 0,
  },
  idCardAreaLimit: {
    limitCode: '2',
    limitValue: '28,29',
    status: 0,
  },
  idCardNoAreaLimit: {
    limitCode: '3',
    limitValue: '28,29',
    status: 0,
  },
  liveAreaLimit: {
    limitCode: '4',
    limitValue: '28,29',
    status: 0,
  },
  locationAreaAreaLimit: {
    limitCode: '5',
    limitValue: '28,29',
    status: 0,
  },
  carrireRealNameLimit: {
    limitCode: '6',
    limitValue: '1',
    status: 0,
  },
  phoneCallLogLimit: {
    limitCode: '7',
    limitValue: '1',
    status: 0,
  },
  phoneUseLimit: {
    limitCode: '8',
    limitValue: '18,25',
    status: 0,
  },
  productId: 359,
}
