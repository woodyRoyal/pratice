<template>
  <div class="pic-component-wrapper">
    <div class="parent" v-for="(item, index) in list" v-if="list" :style="{width: width + 'px', height: height + 'px'}">
      <div :style="{width: width + 'px', height: height + 'px'}">
        <img :src="item.imgUrl" style="width:100%; height:100%;">
      </div>
      <el-input size="small" placeholder="请填写备注" v-model="item.remark" :style="{width: width + 'px'}"></el-input>

      <el-button class="son" type="danger" size="mini" @click="deletePic(index)">删除</el-button>
    </div>
  </div>
</template>

<script>
  import { TAG_OBJ, BIG_TAG } from '../province'
  export default {
    props: {
      list: {
        require: true
      },
      width: {
        require: true
      },
      height: {
        require: true
      }
    },
    data () {
      return {
        bigTag: BIG_TAG,
        tagObj: TAG_OBJ
      }
    },
    methods: {
      // 删除当前图片
      deletePic (index) {
        if (this.list[index].inUse) {
          this.confirmDelete(this.list[index].useArea, index)
        } else {
          this.$confirm('确认删除该图片?', '', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.list.splice(index, 1)
            this.$emit('_getvalue', this.list)
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除'
            })
          })
        }
      },
      // 确认删除正在使用的图片
      confirmDelete (useArea, index) {
        let str = ''
        useArea.forEach(item => {
          str += (this.bigTag[item.channelId] + ',' + this.tagObj[item.classifyCode] + '<br/>')
        })
        this.$alert(str, '该图片暂无法删除，请先在以下位置下架该图片', {
          confirmButtonText: '我知道了',
          dangerouslyUseHTMLString: true,
          showClose: false,
          callback: action => {
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .pic-component-wrapper {
    .parent {
      margin-right: 10px;
      position: relative;
      float:left;
      margin-bottom: 30px;
    }
    .son {
      position:absolute;
      top:0;
      right:0;
    }
    .length-1 {
      width: 160px;
    }
  }
</style>