<!--定时任务-->
<template>
  <div>
    <div>
      <el-form :inline="true" :model="queryForm" size="mini" class="margin-mini">
        <el-form-item label="导入日期:">
          <el-date-picker
            size="mini"
            :picker-options="pickerOptions0"
            v-model="searchForm.time"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            value-format="yyyy-MM-dd"
            end-placeholder="结束日期">
          </el-date-picker>
       </el-form-item>
       <el-form-item label="手机号:">
          <el-input style="width:120px" v-model="searchForm.mobilePhone" @keyup.native.enter="fetchData()" placeholder="请输入手机号"></el-input>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="fetchData()" class="least">查询</el-button>
        <el-button type="primary" size="mini" @click="downLoad()" class="least" :loading="downLoading">导出</el-button>
      </el-form-item>
      <el-form-item>
        <el-upload class="upload-user-defined" name="in" accept=".txt" :auto-upload='false'
                   action="uploadExcelUrl" :file-list="fileList" :show-file-list="false"
                   :with-credentials="true" :disabled = "uploading" ref="uploadFile"
                   :before-upload="handleUploadBefore" :on-success="handleUploadSuccess" :on-error="handleUploadError"
                   :on-progress="handleUploadProgress" :on-change="handleUploadChange">
          <el-button size="mini" type="primary" :loading="uploading" class="least">导入
          </el-button>
          <!-- <span style="font-size:12px;">只能上传.csv文件</span> -->
        </el-upload>
      </el-form-item>
    </el-form>
    </div>
    <!--表格-->
    <!-- show-summary
      :summary-method="getSummaries" -->
    <el-table
      v-loading="tableLoading"
      :data="tableData"
      border fit
      highlight-current-row
      stripe
      :max-height="tableMaxHeight"
      style="width:100%"
      >
      <el-table-column
        prop="importDate"
        label="导入日期"
        :fixed = "tableData.length>0"
        min-width="80"
        >
      </el-table-column>
      <el-table-column
        prop="mobilePhone"
        label="手机号"
        min-width="80"
        >
      </el-table-column>

      <el-table-column
        prop="operator"
        label="导入
        人员"
        min-width="80"
      >
      </el-table-column>

      <!-- <el-table-column
        prop="createAt"
        label="操作"
        min-width="110"
      >
      <template slot-scope="scope">
        <el-button type="text" size="mini">移除</el-button>
      </template> 
      </el-table-column> -->
    </el-table>
    <div  class="pagination-container" v-if="!tableLoading">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
    
    <!-- 广告主 -->
     <!-- <el-dialog :visible.sync="addAdvDialog.show" :title="addAdvDialog.title" @close="closeAdd">
       <el-form :model="addAdvDialog.addForm" ref="addForm" size="mini" :rules="addAdvDialog.addRules">
         <el-form-item label="商务负责人" :label-width="addAdvDialog.labelWidth" prop="principalName">
            <el-input v-model="addAdvDialog.addForm.principalName">

            </el-input>
         </el-form-item>
       </el-form>
       <div slot="footer" class="dialog-footer">
          <el-button  @click="addAdvDialog.show = false">取消</el-button>
          <el-button type="primary" @click="submitAdv">确认</el-button>
        </div>
     </el-dialog> -->
  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'
import Moment from 'moment'
import unsubscribeApi from '../../api/messageApi/unsubscribe.js'
// import Moment from 'moment'
export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      fileList: [],
      file: null,
      uploading: false,
      pickerOptions0: {
        disabledDate (time) {
          // return time.getTime() > Date.now() - 8.64e7
          let temp = new Date().getTime()
          return time.getTime() > temp
        }
      },
      searchForm: {
        time: [],
        mobilePhone: ''
      },
      checked: false,
      timer: null,
      downLoading: false,
      centerDialogVisible: true,
      status: '已生成文件',
      tableLoading: false,
      editDialog: false,
      hoverRow: {

      },
      summaryDailyVo: {

      },
      gridData: [
        {'name': '渠道类型', value: ''},
        {'name': '渠道商', value: ''},
        {'name': '媒体', value: ''},
        {'name': '付费方式', value: ''},
        {'name': '单价', value: ''},
        {'name': '状态', value: ''},
        {'name': '负责人:', value: ''},
        {'name': '平台平成', value: ''},
        {'name': '投放终端', value: ''}
      ],
      queryForm: {
        principalName: '',
        status: 1
      },
      selectList: {
        statusList: [{key: 0, value: '隐藏'}, {key: 1, value: '显示'}]
      },
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [100, 200, 500],
        pageSize: 100, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [

      ],
      listLoading: false
    }
  },
  // beforeRouteLeave (to, from, next) {
  //   const answer = window.confirm('Do you really want to leave? you have unsaved changes!')
  //   if (answer) {
  //     next()
  //   } else {
  //     next(false)
  //   }
  // },
  created () {
    let start = Moment(new Date()).format('YYYY-MM-DD')
    let temp = new Date().getTime()
    let end = Moment(temp).format('YYYY-MM-DD')
    this.searchForm.time = [end, start]
    this.fetchData()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {
  },
  watch: {
  },
  methods: {
    async fetchData (val) {
      try {
        this.tableLoading = true
        let data = {
          importDateStart: this.searchForm.time[0] || '',
          importDateEnd: this.searchForm.time[1] || '',
          mobilePhone: this.searchForm.mobilePhone,
          pageIndex: this.pagination.pageNo,
          pageSize: this.pagination.pageSize
        }
        let res = await unsubscribeApi.getList(data)
        if (res.data.respCode === '1000') {
          this.tableLoading = false
          this.pagination.total = res.data.body.totalCount
          this.pagination.pageNo = res.data.body.currentIndex
          this.tableData = res.data.body.unsubscribeSmsList
          if (this.pagination.pageNo > 1 && this.tableData.length === 0) {
            this.pagination.pageNo = 1
            this.fetchData()
          }
        } else {
          this.$_message.eror(res.data.message)
          this.tableLoading = false
        }
      } catch (error) {
        this.tableLoading = false
      }
    },
    async downLoad () {
      try {
        let data = {
          importDateStart: this.searchForm.time[0] || '',
          importDateEnd: this.searchForm.time[1] || '',
          mobilePhone: this.searchForm.mobilePhone
        }
        this.downLoading = true
        let res = await unsubscribeApi.down(data)
        // if (res && !res.data.respCode) {
        //   let eleLink = document.createElement('a')
        //   eleLink.download = '测试.csv'
        //   eleLink.style.display = 'none'
        //   let blob = new window.Blob(['\ufeff' + res.data])
        //   eleLink.href = URL.createObjectURL(blob)
        //   document.body.appendChild(eleLink)
        //   eleLink.click()
        //   document.body.removeChild(eleLink)
        //   this.downLoading = false
        // }
        if (res && res.data.respCode) {
          this.$_message.error(res.data.respMsg)
          this.downLoading = false
        } else {
          window.location.href = process.env.BASE_API +
          `/sms/service/unsubscribe/export?importDateEnd=${data.importDateEnd}&importDateStart=${data.importDateStart}&mobilePhone=${data.mobilePhone}`
          this.downLoading = false
        }
      } catch (error) {
        this.downLoading = false
      }
    },
    getSummaries (param) {
      // const { columns } = param
      // console.log(columns)
      const sums = []
      if (!this.checked) {
        sums[0] = '汇总'
        sums[1] = '-'
        sums[2] = '-'
        sums[3] = '-'
        if (this.summaryDailyVo.dailyRealFee || this.summaryDailyVo.dailyRealFee === 0) {
          sums[4] = this.formatNum(this.summaryDailyVo.dailyRealFee)
        }
        if (this.summaryDailyVo.payCost || this.summaryDailyVo.payCost === 0) {
          sums[5] = this.formatNum(this.summaryDailyVo.payCost)
        }
        sums[6] = this.summaryDailyVo.productClickCount
        sums[7] = this.summaryDailyVo.registerCount
        sums[8] = this.summaryDailyVo.regAndLogSameDay
        sums[9] = this.summaryDailyVo.reglogSameDayRate
        sums[10] = this.summaryDailyVo.firstLoginCount
        sums[11] = this.summaryDailyVo.naturalLogin
        sums[12] = this.summaryDailyVo.costLogin
        sums[13] = '-'
        return sums
      }
      if (this.checked) {
        sums[0] = '汇总'
        if (this.summaryDailyVo.dailyRealFee || this.summaryDailyVo.dailyRealFee === 0) {
          sums[1] = this.formatNum(this.summaryDailyVo.dailyRealFee)
        }
        if (this.summaryDailyVo.payCost || this.summaryDailyVo.payCost === 0) {
          sums[2] = this.formatNum(this.summaryDailyVo.payCost)
        }
        sums[3] = this.summaryDailyVo.productClickCount
        sums[4] = this.summaryDailyVo.registerCount
        sums[5] = this.summaryDailyVo.regAndLogSameDay
        sums[6] = this.summaryDailyVo.reglogSameDayRate
        sums[7] = this.summaryDailyVo.firstLoginCount
        sums[8] = this.summaryDailyVo.naturalLogin
        sums[9] = this.summaryDailyVo.costLogin
        return sums
      }
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 100
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    },
    handleClearFiles () {
      this.fileList = []
      this.file = null
    },
    // 批量修改-上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
    handleUploadBefore (file) {
      if (file.name && file.name.length > 0) {
        const ldot = file.name.lastIndexOf('.')
        const type = file.name.toLowerCase().substring(ldot)
        if (type !== '.txt') {
          this.$_message.warning('目前只支持.txt格式的文件')
          return false
        }
        this.uploadFileName = file.name
        console.log(this.uploadFileName)
      }
    },
    // 批量修改-文件上传成功时的钩子
    handleUploadSuccess (response, file, fileList) {
      console.log('上传成功')
      this.uploadTagVisible = true
    },
    // 批量修改-文件上传失败时的钩子
    handleUploadError (err, file, fileList) {
      if (err.status === 404) {
        this.$_message.error('上传失败，网络连接异常!')
      } else {
        console.log(err)
        this.$_message.error('上传失败!')
      }
    },
    // 导入项目-文件上传时的钩子
    handleUploadProgress (event, file, fileList) {
      console.log('上传中...')
    },
    async handleUploadChange (file, fileList) {
      try {
        let userId = this.$store.state.loginUser.userId
        this.handleClearFiles()
        this.fileList = [file]
        this.uploadFileName = file.name
        this.file = file.raw
        this.uploading = true
        let param = new window.FormData()
        param.append('file', this.file)
        param.append('userId', userId)
        let res = await unsubscribeApi.import(param, userId)
        if (res.data.respCode === '1000') {
          this.$_message.success('全部导入成功')
          this.closeFile()
          this.handleClearFiles()
          this.fetchData()
          this.uploading = false
        } else if (res.data.respCode === '1135') {
          this.$_message.warning('部分导入成功')
          this.closeFile()
          this.handleClearFiles()
          this.fetchData()
          this.uploading = false
        } else if (res.data.respCode === '1137') {
          this.$_message.warning('单次导入手机号上限1万条')
          this.closeFile()
          this.fetchData()
          this.handleClearFiles()
          this.uploading = false
        } else {
          this.$_message.error('导入失败，请重试')
          this.closeFile()
          this.handleClearFiles()
          this.uploading = false
        }
      } catch (error) {
        this.uploading = false
      }
    },
    closeFile () {
      this.$refs.uploadFile && this.$refs.uploadFile.clearFiles()
      this.handleClearFiles()
    }
    // async fetchUpload () {
    //   if (!this.file) return this.$_message.error('请先选择文件')
    //   this.uploading = true
    //   let param = new window.FormData()
    //   param.append('file', this.file)
    //   try {
    //     if (this.batchUploadDialog.type === 1) {
    //       let res = await BusinessPrincipalApi.productArpuImport(param)
    //       if (res.data.respCode === '1000') {
    //         this.$_message.success('上传成功')
    //         this.uploading = false
    //         this.getTableData()
    //         this.batchUploadDialog.show = false
    //       } else {
    //         this.$_message.error(res.data.respMsg)
    //         this.uploading = false
    //       }
    //     }
    //     if (this.batchUploadDialog.type === 2) {
    //       let res = await BusinessPrincipalApi.productUvClickLimitImport(param)
    //       if (res.data.respCode === '1000') {
    //         this.$_message.success('上传成功')
    //         this.uploading = false
    //         this.getTableData()
    //         this.batchUploadDialog.show = false
    //       } else {
    //         this.$_message.error(res.data.respMsg)
    //         this.uploading = false
    //       }
    //     }
    //   } catch (error) {
    //     this.uploading = false
    //   }
    // }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14{
    padding-left:8px;
    font-size:14px
  }
</style>
