<template>
  <div>
    <el-tabs v-model="searchForm.productLine"
             @tab-click="fetchData">
      <el-tab-pane label="花钱无忧"
                   name="1">
      </el-tab-pane>
      <el-tab-pane label="贷款王"
                   name="2">
      </el-tab-pane>
      <el-tab-pane label="立即借"
                   name="5">
      </el-tab-pane>
    </el-tabs>
    <el-form :inline="true"
             :model="searchForm"
             size="mini"
             class="margin-mini">
      <el-form-item label="短信计划名称:">
        <el-input v-model="searchForm.planName">
        </el-input>
      </el-form-item>
      <el-form-item label="发送日期范围:">
        <el-date-picker v-model="searchForm.pushTime"
                        size="mini"
                        type="daterange"
                        range-separator="至"
                        start-placeholder="开始日期"
                        value-format="yyyy-MM-dd"
                        end-placeholder="结束日期">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="通道商:">
        <el-input v-model="searchForm.passageName">
        </el-input>
      </el-form-item>
      <el-form-item label="运营商">
        <el-select v-model="searchForm.isp"
                   clearable>
          <el-option label="不限"
                     value=""></el-option>
          <el-option v-for="(item, key, index) in ispMap"
                     :key="index"
                     :value="key"
                     :label="item">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary"
                   size="mini"
                   @click="fetchData()">
          查询
        </el-button>
        <el-button type="primary"
                   size="mini"
                   @click="reset()">
          重置
        </el-button>
        <el-button type="primary"
                   size="mini"
                   @click="down()">
          导出
        </el-button>
      </el-form-item>
    </el-form>
    <VueTable :is-loading="isLoading"
              :columns="tableColumns"
              :data="tableData"
              :is-show-pagination="true"
              :pageable="pageable"
              @getTableData="fetchData">
      <template slot="execTime"
                slot-scope="{ row }">
        <span>{{ row.execTime | parseTime }}</span>
      </template>
      <template slot="planName"
                slot-scope="{ row }">
        <span class="btnText"
              @click="push(row, false)">{{ row.planName }}</span>
      </template>
      <template slot="targetProductLine"
                slot-scope="{ row }">
        <span>{{ productLineMap[row.targetProductLine] }}</span>
      </template>
      <template slot="isp"
                slot-scope="{ row }">
        <span>{{ ispMapAll[row.isp] }}</span>
      </template>
      <template slot="arrivePercent"
                slot-scope="{ row }">
        <span>{{ GetPercent(row.arrivalCount, row.thirdCount) }}</span>
      </template>
      <template slot="fee"
                slot-scope="{ row }">
        <span>{{ accMul(row.price, row.arrivalCount, 3) }}</span>
      </template>
      <template slot="firstDayPercent"
                slot-scope="{ row }">
        <span>{{ GetPercent(row.firstDayLoginCount, row.arrivalCount) }}</span>
      </template>
      <template slot="firstDayFee"
                slot-scope="{ row }">
        <span>{{ accDiv(accMul(row.price, row.arrivalCount, 3), row.firstDayLoginCount, 3) }}</span>
      </template>
      <template slot="twoDayLoginPercent"
                slot-scope="{ row }">
        <span>{{ GetPercent(row.twoDayLoginCount, row.arrivalCount) }}</span>
      </template>
      <template slot="twoDayLoginFee"
                slot-scope="{ row }">
        <span>{{ accDiv(accMul(row.price, row.arrivalCount, 3), row.twoDayLoginCount, 3) }}</span>
      </template>
      <template slot="threeDayLoginPercent"
                slot-scope="{ row }">
        <span>{{ GetPercent(row.threeDayLoginCount, row.arrivalCount) }}</span>
      </template>
      <template slot="threeDayLoginFee"
                slot-scope="{ row }">
        <span>{{ accDiv(accMul(row.price, row.arrivalCount, 3), row.threeDayLoginCount, 3) }}</span>
      </template>
    </VueTable>
  </div>
</template>
<script>
import api from "../../../api/planMsg/planMsgTotal";
import VueTable from "../../../components/vueTable";
import config from "./config";
import { GetPercent, accMul, accDiv, downLoad } from "../../../utils/common";
import { planMsgTotal } from "./tableColumns";
export default {
  components: { VueTable },
  data () {
    return {
      // 计算百分比
      GetPercent: GetPercent,
      // 乘法
      accMul: accMul,
      // 除法
      accDiv: accDiv,
      isLoading: false,
      tableColumns: planMsgTotal,
      segmentList: {
        1: "注册后",
        2: "启动APP",
      },
      nodeList: {
        101: "注册未登录",
        102: "启动APP后未登录",
      },
      osList: {
        1: "android",
        2: "ios",
        3: "pc",
        4: "h5",
        5: "其他",
      },
      // 产线
      productLineMap: config.productLineMap,
      //运营商
      ispMap: config.ispMap,
      ispMapAll: config.ispMapAll,
      loading: false,
      searchForm: {
        planName: "",
        pushTime: [],
        productLine: "1",
        passageName: "",
        isp: "",
      },
      activeName: "1",
      tableData: [],
      pageable: {
        pageNum: 1,
        pageSize: 100,
        pageSizes: [20, 50, 100],
        total: 0,
      },
    };
  },
  created () {
    if (this.$route.query.productLine) {
      this.queryForm.productLine = this.$route.query.productLine + "";
    }
    this.fetchData({});
  },
  methods: {
    returnStatus (s, d) {
      // s === d ? return '推送中' : return'推送完成'
      if (s === d) {
        return "推送中"
      } else {
        return "推送完成"
      }
    },
    // 计算当日成本
    firstDayFee (row) {
      let fee = accMul(row.price, row.arrivalCount, 3);
      return GetPercent(fee, row.firstDayLoginCount);
    },
    push (val, type) {
      this.$router.push({ name: "计划短信配置", params: { planCode: val.planCode, edit: type } });
    },
    async fetchData (pageable) {
      if (pageable && pageable.pageNum) {
        this.pageable.pageNum = pageable.pageNum;
        this.pageable.pageSize = pageable.pageSize;
      }
      let pushTime = "";
      if (this.searchForm.pushTime && this.searchForm.pushTime[0]) {
        pushTime = this.searchForm.pushTime[0] + `~` + this.searchForm.pushTime[1];
      }
      let data = {
        ...this.searchForm,
        pushTime: pushTime,
        pageNum: this.pageable.pageNum,
        pageSize: this.pageable.pageSize,
      };
      this.isLoading = true;
      try {
        let res = await api.query(data);
        if (res.data.respCode === "1000") {
          res.data.body.list.forEach((t) => {
            t.price = accDiv(t.price, 100, 3)
          })
          this.tableData = res.data.body.list;
          this.pageable.total = res.data.body.total;
        }
      } finally {
        this.isLoading = false;
      }
    },
    reset () {
      this.searchForm = {
        planName: "",
        pushTime: [],
        productLine: this.searchForm.productLine,
        passageName: "",
        isp: "",
      };
      this.fetchData();
    },
    down () {
      let pushTime = "";
      if (this.searchForm.pushTime && this.searchForm.pushTime[0]) {
        pushTime = this.searchForm.pushTime[0] + `~` + this.searchForm.pushTime[1];
      }
      let data = {
        ...this.searchForm,
        pushTime: pushTime,
      };
      let url = process.env.BASE_API + `/smsPushCount/exportData`;
      downLoad(url, data);
    },
  },
};
</script>
