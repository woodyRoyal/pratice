// 短信通道字段
export const channel = [
  { label: '通道号', align: 'center', prop: 'passage', fixed: false },
  { label: '产品线', align: 'center', slot: 'productLine', fixed: false },
  { label: '通道商名称', align: 'center', prop: 'passageName', fixed: false },
  { label: '支持运营商', align: 'center', slot: 'isp', prop: 'isp', fixed: false },
  { label: '短信单价(元)', align: 'center', prop: 'price', fixed: false },
  { label: '计费方式', align: 'center', slot: 'settleType', prop: 'settleType', fixed: false },
  { label: '备注', align: 'center', prop: 'remark', fixed: false },
  { label: '状态', align: 'center', slot: 'status', fixed: false },
  { label: '操作', align: 'center', slot: 'edit', prop: 'channelMerchantCode', fixed: false },
]


export const planMsgTotal = [
  { label: '发送时间', align: 'center', slot: 'execTime', fixed: true, width: 70 },
  { label: '发送任务ID', align: 'center', prop: 'batchId', fixed: true },
  { label: '短信计划名称', align: 'center', slot: 'planName', fixed: true },
  { label: '去向平台', align: 'center', slot: 'targetProductLine', fixed: true },
  { label: '待发送人数（人）', align: 'center', prop: 'totalCount', fixed: false },
  { label: '通道接收量（人）', align: 'center', prop: 'thirdCount', fixed: false },
  { label: '到达量（人）', align: 'center', prop: 'arrivalCount', fixed: false },
  { label: '到达率', align: 'center', slot: 'arrivePercent', fixed: false },
  { label: '通道商', align: 'center', prop: 'passageName', fixed: false },
  { label: '运营商', align: 'center', slot: 'isp', fixed: false },
  { label: '单价（元）', align: 'center', prop: 'price', fixed: false },
  { label: '费用', align: 'center', slot: 'fee', fixed: false },
  { label: '当日登录', align: 'center', prop: 'firstDayLoginCount', fixed: false },
  { label: '当日转化率', align: 'center', slot: 'firstDayPercent', fixed: false },
  { label: '当日成本', align: 'center', slot: 'firstDayFee', fixed: false },
  { label: '2日登录', align: 'center', prop: 'twoDayLoginCount', fixed: false },
  { label: '2日转化率', align: 'center', slot: 'twoDayLoginPercent', fixed: false },
  { label: '2日成本', align: 'center', slot: 'twoDayLoginFee', fixed: false },
  { label: '3日登录', align: 'center', prop: 'threeDayLoginCount', fixed: false },
  { label: '3日转化率', align: 'center', slot: 'threeDayLoginPercent', fixed: false },
  { label: '3日成本', align: 'center', slot: 'threeDayLoginFee', fixed: false },
  { label: '发送文案', align: 'center', prop: 'smsContent', fixed: false, showOverflowTooltip: true },
]


