export default {
  // 去向平台
  productLineMap: {
    1: '花钱无忧',
    2: '贷款王',
    5: '立即借',
  },
  // 用户类型
  selectTypeList: {
    1: '全部用户',
    2: '筛选用户',
    3: '用户类型',
    4: '导入用户',
  },
  // 推送状态
  planExecStatusList: {
    1: '未推送',
    2: '推送中',
    3: '推送完成',
  },
  // 计划状态
  planStatusList: {
    1: '启用',
    2: '禁用',
  },
  // 运营商
  ispMap: {
    1: '移动',
    2: '联通',
    3: '电信',
  },
  // 运营商
  ispMapAll: {
    0: '不限',
    1: '移动',
    2: '联通',
    3: '电信',
  },
  settleTypeMap: {
    0: '按成功计费',
    1: '按成功+未知计费',
  },
  statusMap: {
    0: '启用',
    1: '停用',
  },
  userTypeDetail: [
    {
      key: 11,
      name: '最近1次登录时间在发送日前第N天',
    },
    {
      key: 12,
      name: '已注册未登录且注册时间在发送日前第N天',
    },
  ],
  userTypeDetailObj: {
    11: '最近1次登录时间在发送日前第N天',
    12: '已注册未登录且注册时间在发送日前第N天',
  },
  // userTypeDetailObj: [
  //   {
  //     key: 11,
  //     name: '最近1次登录时间在发送日前第N天',
  //   },
  //   {
  //     key: 12,
  //     name: '已注册未登录且注册时间在发送日前第N天',
  //   },
  // ],
  userTypeList: [
    {
      key: 3,
      name: '用户类型',
      disable: false,
    },
    {
      key: 2,
      name: '筛选用户',
      disable: false,
    },
    {
      key: 4,
      name: '导入',
      disable: false,
    },
  ],
  userTypeMap: {
    1: '全部用户',
    2: '筛选用户',
    3: '用户类型',
    4: '导入用户',
  },
}
