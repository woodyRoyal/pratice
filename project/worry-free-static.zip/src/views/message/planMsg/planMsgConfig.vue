<template>
  <div>
    <el-form ref="totalForm"
             label-width="140px"
             class="query-form"
             size="mini"
             :rules="queryFormRules"
             :model="queryForm">
      <el-form-item prop="planName"
                    label="短信计划名称：">
        <el-input v-model.trim="queryForm.planName"
                  :disabled="type === 'look' || type === 'edit'"
                  style="width:350px"
                  :maxlength="100"
                  placeholder="计划名称限制在100字内">
        </el-input>
      </el-form-item>
      <el-form-item prop="productLine"
                    label="推送产品线：">
        <el-radio-group v-model="queryForm.productLine"
                        :disabled="type === 'look' || type === 'edit'">
          <el-radio v-for="item in productLineList"
                    :key="item.id"
                    :label="item.id">
            {{ item.name }}
          </el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item prop="selectType"
                    label="目标用户：">
        <el-radio-group v-model="queryForm.selectType"
                        :disabled="type === 'look' || type === 'edit'"
                        @change="changeSelectType">
          <el-radio v-for="item in userTypeList"
                    :key="item.key"
                    :label="item.key"
                    :disabled="item.disable">
            {{ item.name }}
          </el-radio>
        </el-radio-group>
        <el-upload v-if="queryForm.selectType === 4 && type !== 'look'"
                   ref="upLoadDom"
                   :disabled="type === 'look'"
                   style="display:inline-block"
                   :show-file-list="false"
                   class="upload-demo"
                   :action="URL_UPLOAD"
                   :on-success="upLoadSuccess"
                   :limit="1">
          <el-button size="small"
                     type="primary">
            点击上传
          </el-button>
        </el-upload>
        <span v-if="queryForm.selectType === 4"
              class="btnText"
              @click="down()">{{ file.name }}</span>
      </el-form-item>
      <el-form-item label="运营商："
                    prop="isp">
        <el-checkbox-group v-model="queryForm.isp"
                           :disabled="type === 'look'">
          <el-checkbox :label="1"
                       style="margin-right:5px;">
            移动
          </el-checkbox>
          <el-checkbox :label="2"
                       style="margin-right:5px;">
            联通
          </el-checkbox>
          <el-checkbox :label="3">
            电信
          </el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <!-- 额外的用户类型表单 -->
      <el-card v-show="queryForm.selectType === 3"
               style="width:850px;margin-bottom:10px;">
        <el-form ref="extraUserTypeForm"
                 :inline="true"
                 size="mini"
                 :rules="extraUserTypeRules"
                 :model="extraUserTypeForm"
                 label-width="120px">
          <el-form-item prop="userTypeSeq"
                        label="选择用户类型">
            <el-select v-model="extraUserTypeForm.userTypeSeq"
                       :disabled="type === 'look' || type === 'edit'"
                       style="width:260px;">
              <el-option v-for="item in userTypeDetail"
                         :key="item.key"
                         :value="item.key"
                         :label="item.name">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item prop="numbers"
                        label="">
            <el-input v-model.trim="extraUserTypeForm.numbers"
                      :disabled="type === 'look'"
                      placeholder="填写N值，使用英文逗号分隔"
                      style="width:200px;">
            </el-input>
          </el-form-item>
          <div>
            <el-form-item label="号码归属地">
              <el-select v-model="extraUserTypeForm.mobileProvince"
                         :disabled="type === 'look'"
                         multiple
                         style="width:260px;"
                         @change="changeValue($event,'extraUserTypeForm')">
                <el-option v-for="(item,index) in provinceList"
                           :key="index"
                           :value="item"
                           :label="item">
                </el-option>
              </el-select>
            </el-form-item>
          </div>
          <div>
            <el-form-item label="手机系统:">
              <el-radio-group v-model="extraUserTypeForm.os"
                              :disabled="type === 'look'">
                <el-radio :label="0">
                  不限
                </el-radio>
                <el-radio :label="2">
                  IOS
                </el-radio>
                <el-radio :label="1">
                  Android
                </el-radio>
              </el-radio-group>
            </el-form-item>
          </div>
        </el-form>
      </el-card>

      <el-card v-show="queryForm.selectType === 2"
               style="width:850px;margin-bottom:10px;">
        <el-form ref="userTypeForm"
                 :inline="true"
                 size="mini"
                 :rules="userTypeFormRules"
                 :model="userTypeForm">
          <div>
            <el-form-item label="注册渠道">
              <el-select v-model="userTypeForm.registerChannel"
                         style="width:260px;"
                         :disabled="type === 'look'"
                         filterable
                         remote
                         multiple
                         reserve-keyword
                         :loading="loading"
                         :remote-method="remoteRegisterChannel"
                         placeholder="输入内容模糊匹配选择">
                <el-option v-for="(item,index) in RegisterChannelList"
                           :key="index"
                           :value="item.name"
                           :label="item.name">
                </el-option>
              </el-select>
            </el-form-item>

            <el-form-item label="号码归属地">
              <el-select v-model="userTypeForm.mobileProvince"
                         :disabled="type === 'look'"
                         multiple
                         style="width:260px;"
                         @change="changeValue($event,'userTypeForm')">
                <el-option v-for="(item,index) in provinceList"
                           :key="index"
                           :value="item"
                           :label="item">
                </el-option>
              </el-select>
            </el-form-item>
          </div>
          <div>
            <el-form-item label="手机系统:"
                          label-width="135px">
              <el-radio-group v-model="userTypeForm.os"
                              :disabled="type === 'look'">
                <el-radio :label="0">
                  不限
                </el-radio>
                <el-radio :label="2">
                  IOS
                </el-radio>
                <el-radio :label="1">
                  Android
                </el-radio>
              </el-radio-group>
            </el-form-item>
          </div>
          <div>
            <el-form-item label="是否登录过"
                          label-width="135px">
              <el-radio-group v-model="userTypeForm.isLogin"
                              :disabled="type === 'look'">
                <el-radio label="">
                  不限
                </el-radio>
                <el-radio :label="1">
                  是
                </el-radio>
                <el-radio :label="2">
                  否
                </el-radio>
              </el-radio-group>
            </el-form-item>
          </div>
          <div>
            <el-form-item label="注册日期"
                          label-width="135px">
              <div v-for="(item,index) in userTypeForm.registerDateRange"
                   :key="index">
                <el-date-picker v-model="item.time"
                                :disabled="type === 'look'"
                                style="margin-top:5px;"
                                size="mini"
                                type="daterange"
                                range-separator="至"
                                start-placeholder="开始日期"
                                value-format="yyyy-MM-dd"
                                end-placeholder="结束日期">
                </el-date-picker>
                <el-button size="mini"
                           :disabled="type === 'look'"
                           @click="addItem('registerDateRange')">
                  +
                </el-button>
                <el-button v-show="userTypeForm.registerDateRange.length>1"
                           size="mini"
                           :disabled="type === 'look'"
                           @click="delItem(index,'registerDateRange')">
                  -
                </el-button>
              </div>
            </el-form-item>
          </div>

          <div>
            <el-form-item label="最近一次登录日期"
                          label-width="135px">
              <div v-for="(item,index) in userTypeForm.lastLoginDateRange"
                   :key="index">
                <el-date-picker v-model="item.time"
                                :disabled="type === 'look'"
                                style="margin-top:5px;"
                                size="mini"
                                type="daterange"
                                range-separator="至"
                                start-placeholder="开始日期"
                                value-format="yyyy-MM-dd"
                                end-placeholder="结束日期">
                </el-date-picker>
                <el-button size="mini"
                           :disabled="type === 'look'"
                           @click="addItem('lastLoginDateRange')">
                  +
                </el-button>
                <el-button v-if="userTypeForm.lastLoginDateRange.length > 1"
                           size="mini"
                           :disabled="type === 'look'"
                           @click="delItem(index,'lastLoginDateRange')">
                  -
                </el-button>
              </div>
            </el-form-item>
          </div>

          <div>
            <el-form-item label="百融分值"
                          label-width="135px"
                          prop="scoreRange">
              <el-input v-model="userTypeForm.scoreRange[0]"
                        style="width:60px;"
                        :disabled="type === 'look'">
              </el-input>
              分
              至
              <el-input v-model="userTypeForm.scoreRange[1]"
                        style="width:60px;"
                        :disabled="type === 'look'">
              </el-input>
              分
              <span class="font">
                前后包含，请填写0-100的整数
              </span>
            </el-form-item>
          </div>

          <div>
            <el-form-item label="累计登录天数"
                          label-width="135px"
                          prop="loginDays">
              <el-input v-model="userTypeForm.loginDays[0]"
                        style="width:60px;"
                        :disabled="type === 'look'">
              </el-input>
              天
              至
              <el-input v-model="userTypeForm.loginDays[1]"
                        :disabled="type === 'look'"
                        style="width:60px;">
              </el-input>
              天
              <span class="font">
                前后包含，请填写整数
              </span>
            </el-form-item>
          </div>
          <!-- 9.17新增需求 -->
          <div>
            <el-form-item label="最近登录前30日累计产品点击量"
                          label-width="215px"
                          prop="clickCount">
              <el-input v-model="userTypeForm.clickCount[0]"
                        style="width:60px;"
                        :disabled="type === 'look'">
              </el-input>
              次
              至
              <el-input v-model="userTypeForm.clickCount[1]"
                        :disabled="type === 'look'"
                        style="width:60px;">
              </el-input>
              次
            </el-form-item>
          </div>
        </el-form>
      </el-card>
      <el-form-item label="发送文案："
                    prop="smsContent">
        <el-input v-model="queryForm.smsContent"
                  :disabled="type === 'look'"
                  placeholder="限100字内"
                  :maxlength="100"
                  type="textarea"
                  :rows="4"
                  style="width:350px">
        </el-input>
      </el-form-item>
      <el-form-item prop="targetProductLine"
                    label="去向平台：">
        <el-radio-group v-model="queryForm.targetProductLine"
                        :disabled="type === 'look'"
                        @change="fetchIspList">
          <el-radio v-for="item in productLineList"
                    :key="item.id"
                    :label="item.id">
            {{ item.name }}
          </el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item v-show="queryForm.selectType !== 3"
                    label="定时推送时间："
                    prop="planExecTime">
        <el-date-picker v-model="queryForm.planExecTime"
                        :disabled="type === 'look'"
                        size="mini"
                        type="datetime"
                        placeholder="请选择日期和时间"
                        value-format="yyyy-MM-dd HH:mm:ss">
        </el-date-picker>
      </el-form-item>
      <el-form-item v-show="queryForm.selectType === 3"
                    label="每月："
                    prop="day">
        <el-select v-model="queryForm.day"
                   :disabled="type === 'look'"
                   multiple
                   collapse-tags
                   @change="changeDay">
          <el-option v-for="item in dayList"
                     :key="item"
                     :value="item">
          </el-option>
        </el-select>
        号
        <el-time-picker v-model="queryForm.datTime"
                        :disabled="type === 'look'"
                        value-format="HH:mm:ss"
                        placeholder="选择时间">
        </el-time-picker>
      </el-form-item>
      <el-form-item label="短信通道："
                    prop="smsWay">
        移动
        <el-select v-model="queryForm.smsWay[1]"
                   :disabled="type === 'look'"
                   class="selectLenth-1">
          <el-option v-for="item in isplist[1]"
                     :key="item.id"
                     :label="item.label"
                     :value="item.id">
          </el-option>
        </el-select>
        <br>
        联通
        <el-select v-model="queryForm.smsWay[2]"
                   :disabled="type === 'look'"
                   class="selectLenth-1 mt-10">
          <el-option v-for="item in isplist[2]"
                     :key="item.id"
                     :label="item.label"
                     :value="item.id">
          </el-option>
        </el-select>
        <br>
        电信
        <el-select v-model="queryForm.smsWay[3]"
                   :disabled="type === 'look'"
                   class="selectLenth-1 mt-10">
          <el-option v-for="item in isplist[3]"
                     :key="item.id"
                     :label="item.label"
                     :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="去重发送天数"
                    prop="distinctDays">
        <el-input v-model.trim="queryForm.distinctDays"
                  :disabled="type === 'look'"
                  style="width:177px"
                  @blur="getTimeScope(queryForm.distinctDays,queryForm.planExecTime)">
        </el-input>
        <span v-if="queryForm.planExecType === 2"
              class="font-info">去重范围：{{ timeScope }}</span>
      </el-form-item>
      <el-form-item label=" ">
        <el-button :disabled="type === 'look'"
                   type="primary"
                   size="large"
                   @click="submit()">
          提交
        </el-button>
      </el-form-item>
    </el-form>

    <el-dialog :visible.sync="dialog.show"
               title="消息发送预览">
      <el-form size="mini"
               label-width="130px">
        <el-form-item label="短信计划名称">
          <span>{{ queryForm.planName }}</span>
        </el-form-item>
        <el-form-item label="发送产品线">
          <span>{{ productLineMap[`${queryForm.productLine}`] }}</span>
        </el-form-item>
        <el-form-item label="目标用户">
          <span>{{ userTypeMap[`${queryForm.selectType}`] }}</span>
          <span v-if="queryForm.selectType === 3">
            {{ `(${computeUserTypeDetail()})` }}
          </span>
        </el-form-item>
        <el-form-item label="发送文案">
          <span>{{ queryForm.smsContent }}</span>
        </el-form-item>
        <el-form-item label="短信通道">
          <span>{{ passageNameStr }}</span>
        </el-form-item>
        <el-form-item label="推送时间">
          <span>{{ planExecTypeMap[`${queryForm.planExecType}`] }}</span>
        </el-form-item>
        <el-form-item v-show="queryForm.planExecType == 2"
                      label="定时推送时间"
                      prop="planExecTime">
          <el-date-picker v-model="queryForm.planExecTime"
                          size="mini"
                          disabled
                          type="datetime"
                          placeholder="请选择日期和时间"
                          value-format="yyyy-MM-dd HH:mm:ss">
          </el-date-picker>
        </el-form-item>
        <el-form-item v-show="queryForm.planExecType == 3"
                      label="每月"
                      prop="day">
          <el-select v-model="queryForm.day"
                     disabled
                     multiple>
            <el-option v-for="item in dayList"
                       :key="item"
                       :value="item">
            </el-option>
          </el-select>
          号
          <el-time-picker v-model="queryForm.datTime"
                          disabled
                          value-format="HH:mm:ss"
                          placeholder="选择时间">
          </el-time-picker>
        </el-form-item>
        <el-form-item label="去重发送天数">
          <span>{{ queryForm.distinctDays }}</span>
          <span v-if="queryForm.planExecType === 2"
                class="font-info">去重范围：{{ timeScope }}</span>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="dialog.show = false">
          返回修改
        </el-button>
        <el-button v-if="queryForm.planExecType === 2"
                   type="primary"
                   @click="fetchForm()">
          确定定时推送
        </el-button>
        <el-button v-if="queryForm.planExecType === 3"
                   type="primary"
                   @click="fetchForm()">
          确定重复推送
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { platform } from '../../../assets/config'
import api from '../../../api/planMsg/planMsgConfig'
import { computeTimeScope, calculateDiffTime } from '../../../utils/common'
import config from './config'
import { mapState } from 'vuex'
// import {parseTime} from '../../utils/formatDate'
export default {
  components: {

  },
  data () {
    return {
      // 去重范围
      timeScope: '',
      //版本号
      version: null,
      // 计划id
      planCode: null,
      // 计划渠道列表
      RegisterChannelList: [],
      // 翻译通道
      passageNameStr: '',
      // 下载地址
      URL_UPLOAD: api.URL_UPLOAD,
      // 省份是否全选
      all: false,
      // 天数是否全选
      dayAll: false,
      //提交loading
      btnLoading: false,
      loading: false,
      productLineList: platform.productLine,
      // 产品线
      productLineMap: platform.productLineMap,
      // 省份
      provinceList: platform.provinceList,
      // 用户类型
      userTypeDetail: config.userTypeDetail,
      userTypeDetailObj: config.userTypeDetailObj,
      //  运营商
      ispMap: config.ispMap,
      planExecTypeMap: {
        1: '现在推送',
        3: '重复推送',
        2: '定时推送',
      },
      dayList: [],
      // 目标用户
      userTypeList: config.userTypeList,
      userTypeMap: config.userTypeMap,
      file: {
        name: '',
        fdfsDomain: '',
      },
      queryForm: {
        // 去向平台
        targetProductLine: '',
        // 用户类型
        isp: [],
        planName: '',
        productLine: '',
        // 目标用户：
        selectType: '',
        // 文件
        filePath: '',
        smsContent: '',
        distinctTag: 1,
        planExecType: '',
        planExecTime: '',
        //每月几号
        day: [],
        // 发送实践
        datTime: '',
        // 去重天数
        distinctDays: 0,
        // 短信通道JSON
        smsWay: {
          //移动
          1: null,
          // 联通
          2: null,
          // 电信
          3: null,
        },
      },
      queryFormRules: {
        planName: [{ required: true, message: '请填写推送计划名称', trigger: 'blur' }],
        productLine: [{ required: true, message: '请选择推送产品线', trigger: 'change' }],
        targetProductLine: [{ required: true, message: '请选择去向平台', trigger: 'change' }],
        selectType: [{ required: true, message: '请选择目标用户：', trigger: 'change' }],
        planExecType: [{ required: true, message: '请选择推送时间：', trigger: 'change' }],
        distinctDays: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (/^[0-9]+$/.test(value)) {
                callback()
              } else {
                callback(new Error('可填写大于0的整数'))
              }
            },
          },
        ],
        smsWay: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              let isp = this.queryForm.isp
              let smsWay = this.queryForm.smsWay
              let flag = false
              isp.forEach((t) => {
                if (isp.includes(t) && !smsWay[t]) {
                  flag = true
                }
              })
              if (flag) {
                callback(new Error('请根据目标运营商用户配置完整的通道'))
              } else {
                callback()
              }
            },
          },
        ],
        planExecTime: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.selectType !== 3 && (!this.queryForm.planExecTime)) {
                callback(new Error('请选定时推送时间'))
              } else {
                callback()
              }
            },
          },
        ],
        isp: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value.length) {
                callback(new Error('请选择目标用户对应的运营商'))
              } else {
                callback()
              }
            },
          },
        ],
        day: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.selectType === 3 && (!this.queryForm.day.length || !this.queryForm.datTime)) {
                callback(new Error('请选择每月推送时间'))
              } else {
                callback()
              }
            },
          },
        ],
        smsContent: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (value === '') {
                callback(new Error('请填写'))
              } else {
                callback()
              }
            },
          },
        ],
      },
      CAREER_LIST: config.CAREER_LIST,
      // 目标用户表单
      extraUserTypeForm: {
        userTypeSeq: '',
        numbers: '',
        mobileProvince: [],
        os: '',
      },
      extraUserTypeRules: {
        userTypeSeq: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.queryForm.selectType === 3 && (!this.extraUserTypeForm.userTypeSeq)) {
                callback(new Error('请选择用户类型'))
              } else {
                callback()
              }
            },
          },
        ],
        numbers: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              this.extraUserTypeForm.numbers = this.extraUserTypeForm.numbers.replace(/，/g, ',')
              if (this.queryForm.selectType === 3 && (this.extraUserTypeForm.numbers === '')) {
                callback(new Error('请填写N值'))
              } else if (!/^[0-9,]*$/.test(this.extraUserTypeForm.numbers) && (this.queryForm.selectType === 3)) {
                callback(new Error('请填写正确的参数值，并使用逗号分隔'))
              } else {
                callback()
              }
            },
          },
        ],
      },
      userTypeForm: {
        all: false,
        os: 0,
        registerChannel: [],
        mobileProvince: [],
        loginDays: ['', ''],
        scoreRange: ['', ''],
        clickCount: ['', ''],
        careers: [],
        recommend: null,
        registerDateRange: [
          {
            time: '',
          },
        ],
        lastLoginDateRange: [
          {
            time: '',
          },
        ],
      },
      userTypeFormRules: {
        loginDays: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              let start = this.userTypeForm.loginDays[0]
              let end = this.userTypeForm.loginDays[1]
              if (this.queryForm.selectType === 2) {
                if ((!/^[0-9]*$/.test(start) && start !== '') || (!/^[0-9]*$/.test(end) && end !== '')) {
                  callback(new Error('只能填写正整数'))
                } else if (start !== '' && end !== '' && (Number(end) < Number(start))) {
                  callback(new Error('后面的数不能小于前面的数'))
                } else {
                  callback()
                }
              }
            },

          },
        ],
        scoreRange: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              let start = this.userTypeForm.scoreRange[0]
              let end = this.userTypeForm.scoreRange[1]
              if (this.queryForm.selectType === 2) {
                if ((!/^[0-9]*$/.test(start) && start !== '') || (!/^[0-9]*$/.test(end) && end !== '')) {
                  callback(new Error('只能填写整数'))
                } else if (start !== '' && end !== '' && (Number(end) < Number(start))) {
                  console.log(start, end)
                  callback(new Error('后面的数不能小于前面的数'))
                } else if (start !== '' && end !== '' && (Number(start) > 100 || Number(end) > 100)) {
                  callback(new Error('请填写0-100的整数'))
                } else {
                  callback()
                }
              }
            },

          },
        ],
        clickCount: [
          {
            required: false,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              let start = this.userTypeForm.clickCount[0]
              let end = this.userTypeForm.clickCount[1]
              if (this.queryForm.selectType === 2) {
                if ((!/^[0-9]*$/.test(start) && start !== '') || (!/^[0-9]*$/.test(end) && end !== '')) {
                  callback(new Error('只能填写正整数'))
                } else if (start !== '' && end !== '' && (Number(end) < Number(start))) {
                  callback(new Error('后面的数不能小于前面的数'))
                } else {
                  callback()
                }
              }
            },

          },
        ],
      },
      dialog: {
        show: false,
      },
      pageData: [],
      platformName: '花钱无忧',
      opeanLinkList: [],
    }
  },
  computed: {
    ...mapState({
      // 运营商通道列表
      isplist: (state) => state.planMsgConfig.ispList,
    }),
    type () {
      if (!this.$route.params.planCode) {
        return 'add'
      } else if (this.$route.params.planCode && !this.$route.params.edit) {
        return 'look'
      } else {
        return 'edit'
      }
    },
  },
  created () {
    this.dayList = ['全选']
    for (let i = 1; i < 32; i++) {
      this.dayList.push(i)
    }
    if (this.$route.params.planCode) {
      this.fetchData()
    }
  },
  // mounted () {
  // },
  methods: {
    computeUserTypeDetail () {
      if (this.extraUserTypeForm.userTypeSeq) {
        return this.userTypeDetailObj[`${this.extraUserTypeForm.userTypeSeq}`].replace('N', this.extraUserTypeForm.numbers)
      }
    },
    getTimeScope (day, time) {
      if (day) {
        this.timeScope = computeTimeScope(day, time)
      } else {
        this.timeScope = '不去重'
      }
    },
    fetchIspList (targetProductLine) {
      // 清空原有的短信通道值
      this.queryForm.smsWay = {
        1: null,
        2: null,
        3: null,
      }
      let data = {
        pageNum: 1,
        pageSize: 1000,
        productLine: targetProductLine ? targetProductLine : this.queryForm.targetProductLine,
        status: 0,
      }
      this.$store.dispatch('fetchISP', data)
    },
    async remoteRegisterChannel (query) {
      if (query !== '') {
        this.loading = true
        let data = {
          name: query,
          pageSize: 1000,
          currentPage: 1,
        }
        let res = await api.queryChannel(data)
        this.loading = false
        if (res.data.respCode === '1000') {
          this.RegisterChannelList = res.data.body.list
        } else {
          this.$message.error('获取渠道号失败')
          this.RegisterChannelList = []
        }
      } else {
        this.RegisterChannelList = []
      }
    },
    async fetchData () {
      let data = {
        planCode: this.$route.params.planCode,
      }
      let res = await api.queryByPlanCode(data)
      if (res.data.respCode === '1000') {
        let obj = res.data.body
        this.version = obj.version
        let day = []
        let datTime = ''
        if (obj.planExecType === 3) {
          let index = obj.planExecTime.indexOf(' ')
          day = obj.planExecTime.substring(0, index)
          if (day.indexOf('*') > -1) {
            day = ['全选']
            for (let i = 1; i < 32; i++) {
              day.push(i)
            }
          } else {
            day = JSON.parse(day).length === 31 ? this.dayList : JSON.parse(day)
          }
          datTime = obj.planExecTime.substring(index)
          if (datTime.length < 8) {
            datTime = datTime + ':00'
          }
        }
        this.fetchIspList(obj.targetProductLine)
        this.queryForm = {
          // 去向平台
          targetProductLine: obj.targetProductLine,
          // 用户类型
          isp: obj.isp.split(',').map(Number),
          planName: obj.planName,
          productLine: obj.productLine,
          // 目标用户：
          selectType: obj.selectType,
          // 文件
          filePath: obj.filePath,
          smsContent: obj.smsContent,
          planExecType: obj.planExecType,
          // planExecType: 2,
          planExecTime: obj.planExecTime,
          // planExecTime: '',
          //每月几号
          day: day,
          // 发送实践
          datTime: datTime,
          // 去重天数
          distinctDays: obj.distinctDays,
          // 短信通道JSON
          smsWay: JSON.parse(obj.smsWay),
        }

        if (obj.selectType === 4) {
          this.file.name = obj.filePath
          this.file.fdfsDomain = obj.fdfsDomain
          this.getTimeScope(this.queryForm.distinctDays, obj.planExecTime)
        }
        if (obj.selectType === 2) {
          this.initUserTypeForm(obj)
          this.getTimeScope(this.queryForm.distinctDays, obj.planExecTime)
        }
        if (obj.selectType === 3) {
          this.initExtraUserTypeForm(obj)
        }
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    initExtraUserTypeForm (obj) {
      this.extraUserTypeForm = {
        userTypeSeq: obj.userTypeSeq,
        numbers: obj.numbers.join(','),
        mobileProvince: obj.mobileProvince,
        os: obj.os,
      }
    },
    initUserTypeForm (obj) {
      let loginDays = ['', '']
      let scoreRange = ['', '']
      let clickCount = ['', '']
      let registerDateRange = [{ time: [] }]
      let lastLoginDateRange = [{ time: [] }]
      let registerChannel = []
      if (obj.loginDaysRange && obj.loginDaysRange.length) {
        loginDays = obj.loginDaysRange.split('~')
      }
      if (obj.scoreRange && obj.scoreRange.length) {
        scoreRange = obj.scoreRange.split('~')
      }
      // 二期字段
      if (obj.clickCount && obj.clickCount.length) {
        clickCount = obj.clickCount.split('~')
      }
      if (obj.registerDateRange && obj.registerDateRange.length) {
        registerDateRange = []
        obj.registerDateRange.forEach((t) => {
          registerDateRange.push({ time: t.split('~') })
        })
      }
      if (obj.lastLoginDateRange && obj.lastLoginDateRange.length) {
        lastLoginDateRange = []
        obj.lastLoginDateRange.forEach((t) => {
          lastLoginDateRange.push({ time: t.split('~') })
        })
      }
      registerChannel = obj.registerChannel ? obj.registerChannel.split(',') : []
      registerChannel.forEach((t) => {
        if (t) {
          this.RegisterChannelList.push({ name: t })
        }
      })
      this.userTypeForm = {
        os: obj.os || 0,
        mobileProvince: obj.mobileProvince || [],
        registerChannel: registerChannel,
        loginDays: loginDays.length === 2 ? loginDays : ['', ''],
        scoreRange: scoreRange.length === 2 ? scoreRange : ['', ''],
        registerDateRange: registerDateRange,
        lastLoginDateRange: lastLoginDateRange,
        clickCount: clickCount,
        careers: obj.careers ? obj.careers : [],
        recommend: obj.recommend,
        isLogin: obj.isLogin,
      }
    },
    changeValue (val, type) {
      if (this.all) {
        if (val.length === 34 && val.includes('全选')) {
          val.shift()
          this[type].mobileProvince = val
          this.all = false
        }
        if (!val.includes('全选') && this.provinceList.length - 1 === val.length) {
          this[type].mobileProvince = []
          this.all = false
        }
      } else {
        if (val.includes('全选')) {
          console.log('点击全选')
          this[type].mobileProvince = this.provinceList
          this.all = true
        }
        if (!val.includes('全选') && val.length === 34) {
          console.log('选择完了所有按钮')
          val.unshift('全选')
          this[type].mobileProvince = val
          this.all = true
        }
      }
    },
    changeDay (val) {
      if (this.dayAll) {
        if (val.length === 31 && val.includes('全选')) {
          val.shift()
          this.queryForm.day = val
          this.dayAll = false
        }
        if (!val.includes('全选') && this.dayList.length - 1 === val.length) {
          this.queryForm.day = []
          this.dayAll = false
        }
      } else {
        if (val.includes('全选')) {
          console.log('点击全选')
          this.queryForm.day = this.dayList
          this.dayAll = true
        }
        if (!val.includes('全选') && val.length === 31) {
          console.log('选择完了所有按钮')
          val.unshift('全选')
          this.queryForm.day = val
          this.dayAll = true
        }
      }
    },
    changePlanExecType () {
      this.$refs['totalForm'].clearValidate(['planExecTime', 'day'])
    },
    submit () {
      if (this.queryForm.selectType === 4 && !this.queryForm.filePath) {
        return this.$message.error('请先上传文件')
      }

      let flag = true
      this.btnLoading = true
      const arr = ['totalForm']
      if (this.queryForm.selectType === 2) {
        arr.push('userTypeForm')
      }
      if (this.queryForm.selectType === 3) {
        arr.push('extraUserTypeForm')
      }
      arr.forEach((t) => {
        this.$refs[t].validate((valid) => {
          if (!valid) {
            this.btnLoading = false
            flag = false
          }
        })
      })
      // this.queryForm.selectType === 3 ? this.queryForm.planExecType = 3 : this.queryForm.planExecType = 2
      if (flag) {
        if (this.queryForm.planExecType === 2) {
          let selectTime = new Date(this.queryForm.planExecTime).getTime()
          let time = calculateDiffTime(selectTime)
          if (time < 1) {
            return this.$message.error('定时推送时间不能早于当前时间')
          }
        }
        // 将通道id 翻译为中文
        let passageNameStr = []
        for (let key in this.queryForm.smsWay) {
          if (this.queryForm.smsWay[key]) {
            this.isplist['total'].forEach((t) => {
              if (this.queryForm.smsWay[key] === t.id) {
                passageNameStr.push(`${t.passageName}-${this.ispMap[t.isp]}`)
              }
            })
          }
        }
        this.passageNameStr = passageNameStr.join(',')
        this.dialog.show = true
      }
    },
    async fetchForm () {
      if (this.queryForm.planExecType === 2) {
        let selectTime = new Date(this.queryForm.planExecTime).getTime()
        let time = calculateDiffTime(selectTime)
        if (time < 1) {
          return this.$message.error('定时推送时间不能早于当前时间')
        }
      }
      this.btnLoading = true
      let data = {
        version: this.version,
        planCode: this.$route.params.planCode ? Number(this.$route.params.planCode) : null,
        ...this.queryFormRes(),
        ...this.userTypeFormRes(),
        ...this.extraUserTypeFormRes(),
        planType: 3,
      }
      for (let key in data) {
        if (JSON.stringify(data[key]) === '[]') {
          data[key] = null
        }
      }
      let res = await api.saveOrUpdate(data)
      this.btnLoading = false
      if (res.data.respCode === '1000') {
        this.$message.success('已成功创建推送计划')
        this.dialog.show = false
        this.$router.push({ name: '短信计划管理', query: { productLine: this.queryForm.productLine } })
      } else {
        this.$message.error(res.data.respMsg)
      }
    },
    queryFormRes () {
      let data = {}
      if (this.queryForm.planExecType === 1) {
        data = {
          ...this.queryForm,
          planExecTime: '',
        }
      }
      if (this.queryForm.planExecType === 2) {
        data = {
          ...this.queryForm,
        }
      }
      if (this.queryForm.planExecType === 3) {
        let day = []
        day = this.queryForm.day.filter((t) => t !== '全选')
        data = {
          ...this.queryForm,
          planExecTime: JSON.stringify(day) + ' ' + this.queryForm.datTime,
        }
      }
      data = {
        ...data,
        isp: this.queryForm.isp.join(','),
        smsWay: JSON.stringify(this.queryForm.smsWay),
      }
      return data
    },
    extraUserTypeFormRes () {
      let data = {}
      if (this.queryForm.selectType === 3) {
        let numbers = this.extraUserTypeForm.numbers === '' ? [] : this.extraUserTypeForm.numbers.split(',')
        for (let i = 0; i < numbers.length; i++) {
          if (numbers[i] === '' || numbers[i] === null || numbers[i] === undefined) {
            numbers.splice(i, 1);
            i = i - 1;
          }
        }
        for (let i = 0; i < numbers.length; i++) {
          numbers[i] = Number(numbers[i])
        }
        data = {
          ...this.extraUserTypeForm,
          numbers: numbers,
        }
      }
      return data
    },
    // 封装userTypeForm
    userTypeFormRes () {
      let registerDateRange = []
      let lastLoginDateRange = []
      // 假如筛选用户
      if (this.queryForm.selectType === 2) {
        this.userTypeForm.registerDateRange.forEach((t) => {
          if (t.time) {
            if (t.time.length > 0) {
              registerDateRange.push(t.time[0] + '~' + t.time[1])
            }
          }
        })
        this.userTypeForm.lastLoginDateRange.forEach((t) => {
          if (t.time) {
            if (t.time.length > 0) {
              lastLoginDateRange.push(t.time[0] + '~' + t.time[1])
            }
          }
        })
      }
      // console.log(this.userTypeForm.mobileProvince)
      let mobileProvince = []
      mobileProvince = this.userTypeForm.mobileProvince.filter((t) => t !== '全选')
      let loginDaysStart = this.userTypeForm.loginDays[0]
      let loginDaysEnd = this.userTypeForm.loginDays[1]
      let scoreRangeStart = this.userTypeForm.scoreRange[0]
      let scoreRangeEnd = this.userTypeForm.scoreRange[1]

      let clickCountStart = this.userTypeForm.clickCount[0]
      let clickCountEnd = this.userTypeForm.clickCount[1]
      let loginDaysRange = ''
      let scoreRange = ''
      let clickCount = clickCountStart + `~` + clickCountEnd
      if (clickCountStart === '' && clickCountEnd === '') {
        clickCount = ''
      }
      if (loginDaysStart === '' && loginDaysEnd) {
        loginDaysRange = '0~' + loginDaysEnd
      } else if (loginDaysStart && loginDaysEnd === '') {
        loginDaysRange = loginDaysStart + '~9999'
      } else if (loginDaysStart !== '' && loginDaysEnd !== '') {
        loginDaysRange = loginDaysStart + `~` + loginDaysEnd
      } else {
        loginDaysRange = ''
      }

      if (scoreRangeStart === '' && scoreRangeEnd) {
        scoreRange = '0~' + scoreRangeEnd
      } else if (scoreRangeStart && scoreRangeEnd === '') {
        scoreRange = scoreRangeStart + '~9999'
      } else if (scoreRangeStart !== '' && scoreRangeEnd !== '') {
        scoreRange = scoreRangeStart + `~` + scoreRangeEnd
      } else {
        scoreRange = ''
      }

      let data = {
        ...this.userTypeForm,
        registerChannel: this.userTypeForm.registerChannel ? this.userTypeForm.registerChannel.join(',') : '',
        mobileProvince: mobileProvince,
        registerDateRange: registerDateRange,
        lastLoginDateRange: lastLoginDateRange,
        loginDaysRange: loginDaysRange,
        scoreRange: scoreRange,
        os: this.userTypeForm.os === 0 ? null : this.userTypeForm.os,
        clickCount: clickCount,
      }
      if (this.queryForm.selectType === 2) {
        return data
      } else {
        return {}
      }
    },
    addItem (type) {
      this.userTypeForm[type].push({
        time: '',
      })
    },
    delItem (index, type) {
      this.userTypeForm[type].splice(index, 1)
    },
    changeSelectType (val) {
      // 恢复全选状态
      this.all = false
      this.$refs['extraUserTypeForm'].clearValidate(['userTypeSeq', 'numbers'])
      this.clearUserTypeForm()
      this.clearExtraUserTypeForm()
      this.file.name = ''
      this.queryForm.filePath = ''
      // 推送时间类型根据该字段更改
      val === 3 ? this.queryForm.planExecType = 3 : this.queryForm.planExecType = 2
    },
    clearExtraUserTypeForm () {
      this.extraUserTypeForm = {
        userTypeSeq: '',
        numbers: '',
        mobileProvince: [],
        os: '',
      }
    },
    clearUserTypeForm () {
      this.userTypeForm = {
        os: 0,
        registerChannel: [],
        mobileProvince: [],
        loginDays: ['', ''],
        scoreRange: ['', ''],
        clickCount: ['', ''],
        careers: [],
        recommend: null,
        registerDateRange: [
          {
            time: '',
          },
        ],
        lastLoginDateRange: [
          {
            time: '',
          },
        ],
      }
    },
    down () {
      window.location.href = this.file.fdfsDomain + this.queryForm.filePath
    },
    upLoadSuccess (res, file) {
      if (res.respCode === '1000') {
        this.file = file
        this.queryForm.filePath = res.body.filePath
        this.file.fdfsDomain = res.body.fdfsDomain
      } else {
        this.$message.error(res.respMsg)
      }
      console.log(res)
    },
  },
}
</script>
<style lang="scss" scoped>
.font {
  color: #999999;
}

.selectLenth-1 {
  width: 145px;
}
.mt-10 {
  margin-top: 10px;
}
.font-info {
  color: #999999;
  font-size: 12px;
}
</style>
