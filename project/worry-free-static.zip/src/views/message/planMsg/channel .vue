<template>
  <div>
    <el-form size="mini"
             :inline="true"
             label-width="70px">
      <el-form-item label="通道号">
        <el-input v-model="queryForm.passage">
        </el-input>
      </el-form-item>
      <el-form-item label="通道商">
        <el-input v-model="queryForm.passageName">
        </el-input>
      </el-form-item>
      <el-form-item label="状态">
        <el-select v-model="queryForm.status"
                   clearable>
          <el-option label="全部"
                     value=""></el-option>
          <el-option v-for="(item,key,index) in statusMap"
                     :key="index"
                     :value="key"
                     :label="item">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="运营商">
        <el-select v-model="queryForm.isp"
                   clearable>
          <el-option label="全部"
                     value=""></el-option>
          <el-option v-for="(item,key,index) in ispMap"
                     :key="index"
                     :value="key"
                     :label="item">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary"
                   @click="fetchData">
          查询
        </el-button>
        <el-button type="primary"
                   @click="reset()">
          重置
        </el-button>
      </el-form-item>
    </el-form>
    <VueTable :is-loading="isLoading"
              :columns="tableColumns"
              :data="tableData"
              :is-show-pagination="true"
              :pageable="pageable"
              @getTableData="fetchData">
      <template slot="productLine"
                slot-scope="{ row }">
        <span>{{ productLineMap[`${row.productLine}`] }}</span>
      </template>
      <template slot="settleType"
                slot-scope="{ row }">
        <span>{{ settleTypeMap[`${row.settleType}`] }}</span>
      </template>
      <template slot="isp"
                slot-scope="{ row }">
        <span>{{ ispMap[`${row.isp}`] }}</span>
      </template>
      <template slot="status"
                slot-scope="{ row }">
        <span>{{ statusMap[`${row.status}`] }}</span>
      </template>
      <template slot="edit"
                slot-scope="{ row }">
        <el-button v-if="row.status === 1"
                   type="text"
                   @click="edit(row)">
          修改
        </el-button>
        <el-button type="text"
                   @click="changeLog(row)">
          操作记录
        </el-button>
        <el-button v-if="row.status === 1"
                   type="text"
                   @click="changeStatus(row,'启用')">
          启用
        </el-button>
        <el-button v-if="row.status === 0"
                   type="text"
                   @click="changeStatus(row,'禁用')">
          禁用
        </el-button>
        <!-- <el-button v-if="row.status === 1"
                   type="text"
                   @click="del(row)">
          删除
        </el-button> -->
      </template>
    </VueTable>
    <!-- 修改通道弹窗 -->
    <el-dialog :visible.sync="editDialog.show"
               title="修改通道"
               @close="closeEdit">
      <el-form ref="addform"
               :model="editDialog.form"
               :rules="editDialog.rules"
               size="mini"
               label-width="100px">
        <el-form-item label="通道号"
                      prop="passage">
          <el-input v-model="editDialog.form.passage"
                    disabled></el-input>
        </el-form-item>
        <el-form-item label="通道商名称"
                      prop="passageName">
          <el-input v-model="editDialog.form.passageName"
                    disabled></el-input>
        </el-form-item>
        <el-form-item label="支持运营商"
                      prop="isp">
          <el-radio-group v-model="editDialog.form.isp"
                          disabled>
            <el-radio v-for="(item,key,index) in ispMap"
                      :key="index"
                      :label="key">
              {{ item }}
            </el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="短信单价"
                      prop="price">
          <el-input v-model="editDialog.form.price"></el-input>
        </el-form-item>
        <el-form-item label="计费方式"
                      prop="settleType">
          <el-radio-group v-model="editDialog.form.settleType">
            <el-radio v-for="(item,key,index) in settleTypeMap"
                      :key="index"
                      :label="key">
              {{ item }}
            </el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="备注"
                      prop="remark">
          <el-input v-model="editDialog.form.remark"
                    type="textarea"
                    placeholder="限50字内"
                    maxlength="50"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="editDialog.show = false">
          取消
        </el-button>
        <el-button type="primary"
                   @click="submitEdit">
          保存
        </el-button>
      </div>
    </el-dialog>
    <!-- // 操作记录 -->
    <el-dialog :visible.sync="operate.show"
               title="操作记录">
      <div>
        <div v-for="(item,index) in operate.list"
             :key="index"
             style="margin-bottom:10px">
          <span>{{ index + 1 }}.</span>
          <span>{{ item.operateTime }}</span>
          <!-- <span>{{item.operateUser}}</span> -->
          <span>{{ item.operateFunction }}</span>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import VueTable from '../../../components/vueTable'
import api from '../../../api/planMsg/channel'
import config from './config'
import { channel } from './tableColumns'
export default {
  name: 'Channel',
  components: { VueTable },
  data () {
    return {
      // 列表查询loading
      isLoading: false,
      // 表格配置
      tableColumns: channel,
      queryForm: {
        //通道商
        passageName: '',
        //通道号
        passage: '',
        //状态
        status: '',
        //运营商
        isp: '',
      },
      productLineMap: config.productLineMap,
      statusMap: config.statusMap,
      //结算方式
      settleTypeMap: config.settleTypeMap,
      //支持运营商
      ispMap: config.ispMap,
      tableData: [],
      pageable: {
        pageNum: 1,
        pageSize: 100,
        pageSizes: [20, 50, 100],
        total: 0,
      },
      // 修改通道弹窗
      editDialog: {
        show: false,
        btnLoading: false,
        form: {
          id: null,
          passage: '',
          passageName: '',
          isp: '',
          price: '',
          settleType: '',
          remark: '',
        },
        rules: {
          passage: [{ required: true, message: '请填写', trigger: 'blur' }],
          isp: [{ required: true, message: '请选择', trigger: 'blur' }],
          passageName: [{ required: true, message: '请填写', trigger: 'blur' }],
          settleType: [{ required: true, message: '请选择', trigger: 'blur' }],
          price: [
            {
              required: true,
              trigger: 'blur',
              validator: (rule, value, callback) => {
                if (!/^[0-9.]*$/.test(value)) {
                  callback(new Error('单价请填写数字'))
                } else {
                  callback()
                }
              },
            },
          ],
        },
      },
      // 操作记录
      operate: {
        list: [],
        show: false,
        tableLoading: false,
      },
    }
  },
  computed: {
  },
  created () {
    this.fetchData()
  },
  methods: {
    edit (row) {
      this.editDialog.form = {
        id: row.id,
        passage: row.passage,
        passageName: row.passageName,
        isp: `${row.isp}`,
        price: row.price,
        settleType: `${row.settleType}`,
        remark: row.remark,
      }
      this.editDialog.show = true
    },
    async changeLog (row) {
      try {
        this.operate.tableLoading = false
        let res = await api.getOperateRecord(row.id)
        this.operate.tableLoading = false
        if (res.data.respCode === '1000') {
          if (res.data.body.length < 1) {
            return this.$_message.error('记录为空')
          }
          this.operate.show = true
          this.operate.list = res.data.body
        } else {
          this.$_message.error(res.data.respMsg)
          this.operate.list = []
        }

      } finally {
        this.operate.tableLoading = false
      }
    },
    async changeStatus (row, str) {
      try {
        let text = `确认${str}该通道吗？`
        let confirm = await this.$confirm(text, '提示', { type: 'warning' })
        if (confirm) {
          let data = {
            ...row,
            status: row.status === 1 ? 0 : 1,
          }
          let res = await api.editConfig(data)
          if (res.data.respCode === '1000') {
            this.editDialog.show = false
            this.fetchData()
            this.$_message.success('操作成功')
          } else {
            this.$_message.error(res.data.respMsg)
          }
        }
      } catch (error) {
        //
      }

    },
    async del (row) {
      try {
        let text = "确认删除该通道吗？"
        let confirm = await this.$confirm(text, '提示', { type: 'warning' })
        if (confirm) {
          let data = {
            id: row.id,
            deleteFlag: 1,
          }
          delete data.pageNum
          delete data.pageSize
          let res = await api.editConfig(data)
          if (res.data.respCode === '1000') {
            this.editDialog.show = false
            this.fetchData()
            this.$_message.success('操作成功')
          } else {
            this.$_message.error(res.data.respMsg)
          }
        }
      } catch (error) {
        //
      }

    },
    closeEdit () {
      this.$refs['addform'].resetFields()
      this.editDialog.form = {
        id: null,
        passage: '',
        passageName: '',
        isp: '',
        price: '',
        settleType: '',
        remark: '',
      }
    },
    reset () {
      this.queryForm = {
        //通道商
        passageName: '',
        //通道号
        passage: '',
        //状态
        status: '',
        //运营商
        isp: '',
      }
      this.fetchData({})
    },
    submitEdit () {
      this.editDialog.btnLoading = true
      this.$refs['addform'].validate(async (valid) => {
        if (!valid) {
          this.editDialog.btnLoading = false
          return false
        }
        let res = await api.editConfig(this.editDialog.form)
        this.editDialog.btnLoading = false
        if (res.data.respCode === '1000') {
          this.editDialog.show = false
          this.fetchData()
          this.$_message.success('操作成功')
        } else {
          this.$_message.error(res.data.respMsg)
        }
      })
    },
    async fetchData (pageable) {
      if (pageable && pageable.pageNum) {
        this.pageable.pageNum = pageable.pageNum
        this.pageable.pageSize = pageable.pageSize
      }
      let data = {
        ...this.queryForm,
        pageNum: this.pageable.pageNum,
        pageSize: this.pageable.pageSize,
      }
      for (let key in data) {
        if (data[key] === '') {
          data[key] = null
        }
      }
      this.isLoading = true
      try {
        let res = await api.getConfigList(data)
        if (res.data.respCode === '1000') {
          res.data.body.list.forEach((t) => {
            t.price = t.price.toFixed(3)
          })
          this.tableData = res.data.body.list
          this.pageable.total = res.data.body.total
        }
      } finally {
        this.isLoading = false
      }
    },
  },
}
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.itemFirst {
  width: 200px;
  margin-left: 50px;
}
.font-info {
  color: #99a9bf;
  font-size: 12px;
  margin-left: 10px;
}
.queryItem {
  width: 120px;
}
</style>
