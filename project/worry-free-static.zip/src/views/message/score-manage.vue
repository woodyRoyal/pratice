<!--定时任务-->
<template>
  <div>
    <div class="topBox">
      <!-- 父tab -->
      <el-radio-group v-model="bigID" style="margin-top:0px;" size="small" @change="changeTab">
        <el-radio-button :label="item.value" v-for="(item,index) in bigTagList" :key="index">{{item.value}}</el-radio-button>
      </el-radio-group>
    </div>
    <div style="margin-top:15px"></div>
    <keep-alive>
     <router-view ></router-view>
    </keep-alive>
  </div>
</template>

<script>

export default {

  data () {
    return {
      searchView: {
        '/report/expendTable/dayTable': true,
        '/report/expendTable/monthTable': true
      },
      permissionList: [],
      bigID: '',
      allListL: [
        {key: '/message/scoreManage/score', value: '客户分值查询'},
        {key: '/message/scoreManage/result', value: '查询结果统计'},
      ],
      bigTagList: [
        // {key: '/message/scoreManage/score', value: '客户分值查询'},
        // {key: '/message/scoreManage/result', value: '查询结果统计'},
      ]
    }
  },
  created () {
    this.permissionList = this.$store.state.permission.menuPathList
    this.allListL.forEach(t => {
      this.permissionList.forEach(j => {
        if (t.key === j) {
          this.bigTagList.push(t)
        }
      })
    })
    if (this.bigTagList.length === 0) {
      this.$message.error('该模块没有授权页面！')
      this.$router.push({name: '花钱无忧后台'})
    }
    if (this.$route.path === '/message/scoreManage') {
      this.$router.push({name: this.bigTagList[0].value})
    }
    if(!this.bigID) {
     this.bigID = this.$route.name
    }
  },
  mounted () {
  },
  watch: {
    '$route'(){
      this.bigID = this.$route.name
    }
  },
  computed: {
    key () {
      return this.$route.name !== undefined
        ? this.$route.name + +new Date()
        : this.$route + +new Date()
    }
  },
  methods: {
    changeTab (val) {
      this.$router.push({name: this.bigID})
      // this.$router.replace('/message/MsgConfig/report')
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 0px;
    position: relative;
  }
  .searchView {
    position: absolute;
    right:0px
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
