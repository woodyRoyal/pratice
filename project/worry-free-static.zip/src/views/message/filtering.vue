<!--定时任务-->
<template>
  <div>
    <el-form size="mini" inline>
      <el-form-item label="号码来源平台:" label-width="157px">
        <el-select size="mini" style="width:200px;" v-model="searchForm.selectSource" @change="changeSelectSource">
            <el-option
            :value="2"
            label="基于内部用户筛选"
            >
            </el-option>
            <el-option
            :value="1"
            label="基于客户分值查询筛选"
            >
            </el-option>
        </el-select>
       </el-form-item>
       <div> 
         <el-form-item label=" " label-width="157px">
         <el-checkbox-group v-model="searchForm.mobileSource" @change="changeMobileSource">
          <el-checkbox :label="1" border style="margin-right:0px">花钱无忧</el-checkbox>
          <el-checkbox :label="2" border>贷款王</el-checkbox>
          <el-checkbox :label="5" border>立即借</el-checkbox>
          <el-checkbox :label="3" border>大圣钱包</el-checkbox>
          <el-checkbox :label="4" border>导流平台</el-checkbox>
        </el-checkbox-group>
       </el-form-item>
       </div>
       <el-form-item label="分值查询任务ID：" label-width="158px"  v-if="searchForm.selectSource === 1">
         <el-select multiple v-model="searchForm.taskNo" style="width:450px" placeholder="请先选择平台，再选择任务ID">
           <el-option
           v-for="(item,index) in taskNoList" 
           :key="index"
           :label="item.taskMsg"
           :value="item.taskNo"
           > 
           </el-option>

         </el-select>

       </el-form-item>

       <div v-for="(item,index) in searchForm.dateRange" :key="index" style="margin-bottom:10px">
         <el-select v-model="searchForm.dateType" size="mini" style="width:143px;margin-right:10px" v-if="index === 0">
          <el-option
          v-for="(item,index) in selectList.dayType"
          :key="item.key"
          :value="item.key"
          :label="item.value"
          :disabled="isDisabled && index === 2"
          >
          </el-option>
        </el-select>
        <span class="blockWidth" v-if="index > 0"></span>
        <el-form-item>
          <el-date-picker
            size="mini"
            v-model="item.time"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            value-format="yyyy-MM-dd"
            end-placeholder="结束日期">
          </el-date-picker>
          <el-button size="mini" @click="addItem(item,index)" v-if="index === searchForm.dateRange.length -1">
            +
          </el-button>
          <el-button size="mini"  @click="delItem(item,index)" v-if="searchForm.dateRange.length > 1">
            -
          </el-button>
        </el-form-item>
       </div>
       <el-form-item label="客户分值:" label-width="157px">
          <el-input-number v-model.number="searchForm.scoreRange[0]" :controls="false" onkeypress='return( /[\d]/.test(String.fromCharCode(event.keyCode)))' style="width:80px"></el-input-number>
          分 至
          <el-input-number v-model.number="searchForm.scoreRange[1]" :controls="false" onkeypress='return( /[\d]/.test(String.fromCharCode(event.keyCode)))' style="width:80px"></el-input-number>分
          <span style="padding-left:20px;color:rgb(211,211,211)">前后包含，请填写0~100的整数</span>
       </el-form-item>
       
       <el-form-item label="注册当天是否登录:" label-width="157px" v-if="searchForm.dateType === 3">
          <el-radio-group v-model="searchForm.registerLogin">
            <el-radio :label="0">不限</el-radio>
            <el-radio :label="1">是</el-radio>
            <el-radio :label="2">否</el-radio>
          </el-radio-group>
       </el-form-item>
       <div>
         <el-form-item label="手机系统:" label-width="157px">
          <el-radio-group v-model="searchForm.lastLoginOs">
            <el-radio :label="0">不限</el-radio>
            <el-radio :label="1">IOS</el-radio>
            <el-radio :label="2">Android</el-radio>
          </el-radio-group>
       </el-form-item>
       </div>
       <div>
         <el-form-item label="是否借过款:" label-width="157px">
          <el-radio-group v-model="searchForm.ldkwLoan">
            <el-radio :label="0">不限</el-radio>
            <el-radio :label="1">是</el-radio>
            <el-radio :label="2">否</el-radio>
          </el-radio-group>
       </el-form-item>
       </div>
       
       <el-form-item label="是否逾期中:" label-width="157px">
          <el-radio-group v-model="searchForm.ldkwOverdue">
            <el-radio :label="0">不限</el-radio>
            <el-radio :label="1">是</el-radio>
            <el-radio :label="2">否</el-radio>
          </el-radio-group>
       </el-form-item>                 
       <div> 
         <el-form-item label="号码归属地:" label-width="157px">
          <el-select v-model="searchForm.mobileProvince" size="mini" multiple  style="width:220px" @change="changeValue" placeholder="不限">
            <el-option
            v-for="(item,index) in provinceList"
            :key="index"
            :label="item"
            :value="item"
            >
            </el-option>
          </el-select>
        </el-form-item>
       </div>
        <el-form-item label="运营商:" label-width="157px">
          <el-checkbox-group v-model="searchForm.isp">
            <el-checkbox :label="1" style="margin-right:10px">移动</el-checkbox>
            <el-checkbox :label="2" style="margin-right:10px">联通</el-checkbox>
            <el-checkbox :label="3">电信</el-checkbox>
          </el-checkbox-group>
       </el-form-item>
       <div>
         <el-form-item label="去重发送日期:" label-width="157px">
          <el-date-picker
            size="mini"
            v-model="searchForm.removeDuplicateDate"
            type="date"
            range-separator="至"
            value-format="yyyy-MM-dd"
            end-placeholder="结束日期">
          </el-date-picker>
       </el-form-item> 
       </div>
       <div>
         <el-form-item label=" " label-width="100px">
         <el-button type="primary" round size="mini" style="width:150px" @click="submit()" :loading="loading"> 查询</el-button>
         <template v-if="resultKey">
           <span style="padding-left:50px">查询结果：{{count}}条</span>
         </template>
          <template v-if="resultKey && tabButtonPerms['create']">
           <el-button type="danger"  size="mini" @click="add">新建任务</el-button>
          </template> 
         </el-form-item>
       </div> 
    </el-form>
      <!-- <el-row>
           <el-col :span="8">
           </el-col>
           <el-col :span="12">
           </el-col>
      </el-row> -->
    <el-dialog :visible.sync="dialog.show" :title="dialog.title" width="70%" @close="closeForm">
       <el-form :model="dialog.addForm" ref="addform" size="mini" :rules="dialog.addRules" inline >
         <el-row>
           <el-col :span="12">
             <el-form-item label='任务ID:' :label-width="dialog.labelWidth" prop="taskNo">
                <span>
                  {{taskNo}}
                </span>
            </el-form-item> 
           </el-col>
           <el-col :span="12">
             <el-form-item label="发送日期:" :label-width="dialog.labelWidth" prop="postDate">
                <el-date-picker
                  size="mini"
                  style="width:163px"
                  v-model="dialog.addForm.postDate"
                  type="date"
                  range-separator="至"
                  value-format="yyyy-MM-dd"
                  end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item> 
           </el-col>
         </el-row>
         <el-row>
           <el-col :span="12">
             <el-form-item label='发送渠道号:' :label-width="dialog.labelWidth" prop="postChannelNo">
                  <el-input v-model="dialog.addForm.postChannelNo">
                  </el-input>
              </el-form-item> 
           </el-col>
           <el-col :span="12">
              <el-form-item label="发送目的:" :label-width="dialog.labelWidth" prop="postPurpose">
                <el-select v-model="dialog.addForm.postPurpose" size="mini"  clearable style="width:163px">
                  <el-option
                  v-for="(item,index) in selectList.postPurposeList"
                  :key="index"
                  :label="item.value"
                  :value="item.key"
                  >
                  </el-option>
                </el-select>
            </el-form-item> 
           </el-col>
      </el-row>
      <el-row>
           <el-col :span="12">
             <el-form-item label='发送平台:' :label-width="dialog.labelWidth" prop="postPlatform">
                <el-select v-model="dialog.addForm.postPlatform" size="mini"  clearable style="width:163px" @change="changePostPlatform">
                  <el-option
                  v-for="(item,index) in selectList.postPlatformList"
                  :key="index"
                  :label="item.value"
                  :value="item.key"
                  >
                  </el-option>
                </el-select>
            </el-form-item> 
           </el-col>
           <el-col :span="12">
              <el-form-item label="通道:" :label-width="dialog.labelWidth" prop="postChannel">
                <el-input v-model="dialog.addForm.postChannel">
                </el-input>
            </el-form-item> 
           </el-col>
      </el-row>
      <el-row v-if="dialog.addForm.postPlatform === 4" :key="1">
           <el-col :span="12">
             <el-form-item label='其它发送平台' :label-width="dialog.labelWidth" prop="postPlatformRemark">
               <el-input v-model="dialog.addForm.postPlatformRemark">

               </el-input>
            </el-form-item> 
           </el-col>
      </el-row>
      <el-row>
           <el-col :span="12">
             <el-form-item label='形式:' :label-width="dialog.labelWidth" prop="postForm">
                <el-select v-model="dialog.addForm.postForm" size="mini"  clearable style="width:163px" @change="changePostForm">
                  <el-option
                  v-for="(item,index) in selectList.postFormList"
                  :key="index"
                  :label="item.value"
                  :value="item.key"
                  >
                  </el-option>
                </el-select>
            </el-form-item> 
           </el-col>
           <el-col :span="12">
              <el-form-item label="运营商:" :label-width="dialog.labelWidth" prop="chooseIsp">
                <el-input v-model="dialog.addForm.chooseIsp" disabled>
                </el-input>
            </el-form-item> 
           </el-col>
      </el-row>
      <el-row v-if="dialog.addForm.postForm === 5">
           <el-col :span="12">
             <el-form-item label='其它形式:' :label-width="dialog.labelWidth" prop="postFormRemark">
               <el-input v-model="dialog.addForm.postFormRemark">

               </el-input>
            </el-form-item> 
           </el-col>
      </el-row>
      <el-row>
           <el-col :span="12">
             <el-form-item label='单价(元):' :label-width="dialog.labelWidth" prop="unitPrice">
                <el-input v-model="dialog.addForm.unitPrice">
                </el-input>
            </el-form-item> 
           </el-col>
           <el-col :span="12">
             <el-form-item label="发送数量:" :label-width="dialog.labelWidth" prop="postNum">
                <el-input v-model="dialog.addForm.postNum">
                </el-input>
            </el-form-item> 
           </el-col>
      </el-row>
      <el-row>

           <el-col :push="12" :span="12">
             <el-form-item label="查询结果:" :label-width="dialog.labelWidth" prop="xxx">
               <span>{{count}}条</span>
            </el-form-item> 
           </el-col>
      </el-row>

      <el-row>
           <el-col :span="24">
             <el-form-item label='发送文案:' :label-width="dialog.labelWidth" prop="postContent">
                <el-input v-model="dialog.addForm.postContent" type="textarea" style="width:300px">
                </el-input>
            </el-form-item> 
           </el-col>
      </el-row>
      <el-row>
           <el-col :span="24">
             <el-form-item label='备注内容:' :label-width="dialog.labelWidth" prop="remark">
                <el-input v-model="dialog.addForm.remark" type="textarea" style="width:300px">
                </el-input>
            </el-form-item> 
           </el-col>
      </el-row>
       </el-form>
       <div slot="footer" class="dialog-footer">
          <el-button  @click="dialog.show = false">取消</el-button>
          <el-button type="primary" @click="submitAdv" :loading="loading">确认</el-button>
        </div>
     </el-dialog>
  </div>
</template>

<script>
import VueElTooltip from '../../components/VueElTooltip'
import areaJson from './areaJson.js'
import messageApi from '../../api/messageApi/message.js'
import Moment from 'moment'
export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      all: false, // 全选标记
      tabButtonPerms: {
        'updateMonitor': false
      },
      loading: false,
      count: '',
      taskNo: '',
      resultKey: null,
      dialog: {
        taskNo: '',
        show: false,
        title: '新建任务',
        addForm: {
          taskNo: '',
          resultKey: null,
          chooseIsp: '',
          exportFileName: 'mobileNumber',
          operatorUserId: '',
          postChannel: '',
          postChannelNo: '',
          postContent: '',
          postDate: '',
          postForm: '',
          postFormRemark: '',
          postNum: '',
          postPlatform: '',
          postPlatformRemark: '',
          postPurpose: '',
          remark: '',
          unitPrice: ''
        },
        labelWidth: '110px',
        addRules: {
          postDate: [{ required: true, message: '请选择', trigger: 'change' }],
          postChannelNo: [{message: '请输入发送渠道', trigger: 'blur', required: true}],
          postPurpose: [{ required: true, message: '请选择', trigger: 'change' }],
          postPlatform: [{ required: true, message: '请选择', trigger: 'change' }],
          postChannel: [{ required: true, message: '请输入通道名称', trigger: 'blur' }],
          postForm: [{ required: true, message: '请输入通道名称', trigger: 'blur' }],
          postContent: [{ required: true, message: '请输入发送文案', trigger: 'blur' }],
          postPlatformRemark: [{ required: true, message: '请输入发送平台', trigger: 'blur' }],
          postFormRemark: [{ required: true, message: '请输入其它形式', trigger: 'blur' }],
          postNum: [{
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (value === '') {
                callback(new Error('请输入发送数量'))
              } else if (/^[1-9]\d*$/.test(value) && value > 0 && value < this.count + 1) {
                callback()
              } else {
                callback(new Error('发送数量≤查询结果数量且发送数量>0'))
              }
            }
          }],
          unitPrice: [
            {
              required: true,
              trigger: 'blur',
              validator: (rule, value, callback) => {
                if (value === '') {
                  callback(new Error('请输入单价'))
                } else if (/^[0-9.]*$/.test(value)) {
                  callback()
                } else {
                  callback(new Error('仅允许输入数字，含小数点'))
                }
              }
            }
          ]
        }
      },
      provinceList: areaJson.provinceList,
      numPlatform: 0,
      searchForm: {
        selectSource: 1,
        taskNo: [],
        scoreRange: [],
        // mobileProvinceAll: true,
        mobileSource: [],
        mobileProvince: [],
        dateRange: [{time: []}],
        dateType: 1,
        isp: [1],
        lastLoginOs: 0,
        ldkwLoan: 0,
        ldkwOverdue: 0,
        registerLogin: 0,
        removeDuplicateDate: ''
      },
      checkList: [],
      dayType: 1,
      value6: '',
      dayPickList: [{time: []}, {time: []}, {time: []}],
      taskNoList: [],
      selectList: {
        dayType: [
          {key: 1, value: '最近一次登陆日期', disabled: false},
          {key: 2, value: '首次登陆日期', disabled: false},
          {key: 3, value: '注册日期', disabled: false}
        ],
        // 发送目的
        postPurposeList: [
          {key: 1, value: '拉活'},
          {key: 2, value: '拉新'},
          {key: 3, value: '拉首次登陆'}
        ],
        // 发送平台
        postPlatformList: [
          {key: 1, value: '花钱无忧'},
          {key: 2, value: '贷款王'},
          {key: 5, value: '立即借'},
          {key: 3, value: '大圣钱包'},
          {key: 4, value: '其他'}
        ],
        postPlatformObj: {
          1: '花钱无忧',
          2: '贷款王',
          5: '立即借',
          3: '大圣钱包',
          4: '其他'
        },
        // 运营商
        chooseIspList: [
          {key: 0, value: '不限'},
          {key: 1, value: '移动'},
          {key: 2, value: '联通'},
          {key: 3, value: '电信'},
          {key: 4, value: '移动+联通'},
          {key: 5, value: '移动+电信'},
          {key: 6, value: '联通+电信'},
          {key: 7, value: '三网'}
        ],
        // 形式
        postFormList: [
          {key: 1, value: '短信'},
          {key: 2, value: '语音'},
          {key: 3, value: '闪信'},
          {key: 4, value: '彩信'},
          {key: 5, value: '其它'}
        ],
        postFormObj: {
          1: '短信',
          2: '语音',
          3: '闪信',
          4: '彩信',
          5: '其它'
        }
      }
    }
  },
  created () {
    const btnKeys = ['create']
    btnKeys.forEach(t => {
      this.$store.state.loginUser.tabButtonPerms.forEach(j => {
        if (t === j) {
          this.tabButtonPerms[t] = true
        }
      })
    })

    // this.dialog.addForm.removeDuplicateDate = '2019-01-21'
  },
  mounted () {
    let temp = new Date().getTime() - 3600 * 1000 * 24 * 3
    this.searchForm.removeDuplicateDate = Moment(temp).format('YYYY-MM-DD')
    // this.dialog.addForm.removeDuplicateDate = temp
  },
  destroyed () {
  },
  computed: {
    isDisabled () {
      if (this.searchForm.mobileSource.length === 1 && this.searchForm.mobileSource[0] === 4) return true
      return false
    }
  },
  watch: {
    // 'searchForm.mobileProvinceAll': function () {
    //   if (this.searchForm.mobileProvinceAll) { this.searchForm.mobileProvince = [] }
    // }
    // 'searchForm.mobileProvince': function () {
    //   if (this.searchForm.mobileProvince.length === 0 && !this.searchForm.mobileProvinceAll) { this.searchForm.mobileProvinceAll = true }
    // }
  },
  methods: {
    async changeSelectSource () {
      this.searchForm.mobileSource = []
    },
    async changeMobileSource (val) {
      if (val.length === 1 && val.includes(4) && this.searchForm.dateType === 3) {
        this.searchForm.dateType = 1
      }
      this.searchForm.taskNo = []
      if (this.searchForm.mobileSource.length && this.searchForm.selectSource === 1) {
        let data = {
          userPlatform: this.searchForm.mobileSource
        }
        let res = await messageApi.getTaskNoList(data)
        if (res.data.respCode === '1000') {
          this.taskNoList = res.data.body
        } else {
          this.$_message.error(res.data.respMsg)
        }
      } else {
        this.taskNoList = []
      }
    },
    changeValue (val) {
      if (this.all) {
        if (val.length === 34 && val.includes('全选')) {
          console.log('删除完全部按钮')
          val.shift()
          this.searchForm.mobileProvince = val
          this.all = false
        }
        if (!val.includes('全选') && this.provinceList.length - 1 === val.length) {
          console.log('点击取消全选')
          this.searchForm.mobileProvince = []
          this.all = false
        }
      } else {
        if (val.includes('全选')) {
          console.log('点击全选')
          this.searchForm.mobileProvince = this.provinceList
          this.all = true
        }
        if (!val.includes('全选') && val.length === 34) {
          console.log('选择完了所有按钮')
          val.unshift('全选')
          this.searchForm.mobileProvince = val
          this.all = true
        }
      }
    },
    changeMobileProvince (val) {
      // console.log(this.provinceList.length) 35
      let all = false
      val.forEach(t => {
        if (t === '全选') {
          all = true
        }
      })
      if (all) {
        this.searchForm.mobileProvince = JSON.parse(JSON.stringify(this.provinceList))
      } else {
        this.searchForm.mobileProvince.forEach((v, i) => {
          if (v === '全选') {
            this.searchForm.mobileProvince.splice(i, 1)
          }
        })
      }
    },
    changePostPlatform () {
      this.dialog.addForm.postPlatformRemark = ''
    },
    changePostForm () {
      this.dialog.addForm.postFormRemark = ''
    },
    add () {
      this.dialog.addForm.chooseIsp = ''
      let count = 0
      this.searchForm.isp.forEach(t => {
        count += t
      })
      if (this.searchForm.isp.length === 1) {
        if (count === 1) {
          this.dialog.addForm.chooseIsp = '移动'
        }
        if (count === 2) {
          this.dialog.addForm.chooseIsp = '联通'
        }
        if (count === 3) {
          this.dialog.addForm.chooseIsp = '电信'
        }
      }
      if (this.searchForm.isp.length === 2) {
        if (count === 3) {
          this.dialog.addForm.chooseIsp = '移动+联通'
        }
        if (count === 4) {
          this.dialog.addForm.chooseIsp = '移动+电信'
        }
        if (count === 5) {
          this.dialog.addForm.chooseIsp = '联通+电信'
        }
      }
      if (this.searchForm.isp.length === 3) {
        this.dialog.addForm.chooseIsp = '三网'
      }
      let date = Moment(new Date()).format('YYYY-MM-DD')
      this.dialog.addForm.postDate = date
      this.dialog.addForm.postChannelNo = 'message20'
      this.dialog.addForm.postPurpose = 1
      this.dialog.addForm.postPlatform = 1
      this.dialog.addForm.postForm = 1
      this.dialog.addForm.unitPrice = 0.06
      this.dialog.show = true
    },
    async submitAdv () {
      try {
        let confirm = await this.$confirm(`确认新建任务吗?`, '提示', { type: 'warning' })
        if (confirm) {
          this.fetchSubmit()
        }
      } catch (error) {

      }
    },
    async fetchSubmit () {
      this.$refs['addform'].validate(async valid => {
        if (!valid) {
          this.loading = false
          return false
        }
        this.loading = true
        let userId = this.$store.state.loginUser.userId
        let exportFileName = this.taskNo + '_' + this.selectList.postPlatformObj[this.dialog.addForm.postPlatform] + '_' + this.dialog.addForm.postChannel + '_' + this.selectList.postFormObj[this.dialog.addForm.postForm] + '_' + this.dialog.addForm.chooseIsp + '_' + this.dialog.addForm.postNum + '.txt'
        let count = 0
        this.searchForm.isp.forEach(t => {
          count += t
        })
        let isp = 0
        if (this.searchForm.isp.length === 1) {
          if (count === 1) {
            isp = 1
          }
          if (count === 2) {
            isp = 2
          }
          if (count === 3) {
            isp = 3
          }
        }
        if (this.searchForm.isp.length === 2) {
          if (count === 3) {
            isp = 4
          }
          if (count === 4) {
            isp = 5
          }
          if (count === 5) {
            isp = 6
          }
        }
        if (this.searchForm.isp.length === 3) {
          isp = 7
        }
        let data = {
          ...this.dialog.addForm,
          operatorUserId: userId,
          exportFileName: exportFileName,
          chooseIsp: isp,
          taskNo: this.taskNo,
          resultKey: this.resultKey
        }
        // addForm: {
        //   taskNo: '',
        //   resultKey: null,
        //   chooseIsp: '',
        //   exportFileName: 'mobileNumber',
        //   operatorUserId: '',
        //   postChannel: '',
        //   postChannelNo: '',
        //   postContent: '',
        //   postDate: '',
        //   postForm: '',
        //   postFormRemark: '',
        //   postNum: '',
        //   postPlatform: '',
        //   postPlatformRemark: '',
        //   postPurpose: '',
        //   remark: '',
        //   unitPrice: ''
        // }
        // window.location.href = process.env.BASE_API +
        //     `/product/exportSort?taskNo=${data.taskNo}&resultKey=${data.resultKey}&chooseIsp=${data.chooseIsp}&exportFileName=${data.exportFileName}&operatorUserId=${data.operatorUserId}
        //     &postChannel=${data.postChannel}&postChannelNo=${data.postChannelNo}&postContent=${data.postContent}&postDate=${data.postDate}&postForm=${data.postForm}
        //     &postFormRemark=${data.postFormRemark}&postNum=${data.postNum}&postPlatform=${data.postPlatform}&postPlatformRemark=${data.postPlatformRemark}&postPurpose=${data.postPurpose}
        //     &remark=${data.remark}&unitPrice=${data.unitPrice}
        //   `
        try {
          let res = await messageApi.create(data)
          if (res && res.data.respCode === '1000') {
            this.loading = false
            this.$_message.success('任务新建成功')
            this.resultKey = null
            this.dialog.show = false
          } else {
            this.loading = false
            this.$_message.error(res.data.respMsg)
          }
        } catch (error) {
          this.loading = false
        }
      })
    },

    async submit () {
      try {
        console.log(this.searchForm)
        let dateRange = []
        let dateFlag = false
        let date = false
        let userId = this.$store.state.loginUser.userId
        this.searchForm.dateRange.forEach(t => {
          if (t.time !== null) {
            if (t.time.length === 0) {
              dateFlag = true
            }
            if (t.time.length > 0) {
              dateRange.push(t.time[0] + '~' + t.time[1])
              let s1 = new Date(t.time[0].replace(/-/g, '/'))
              let s2 = new Date(t.time[1].replace(/-/g, '/'))
              let days = s2.getTime() - s1.getTime()
              if (parseInt(days / (1000 * 60 * 60 * 24)) > 60) {
                date = true
              }
            }
          } else {
            dateFlag = true
          }
        })
        if (this.searchForm.mobileSource.length === 0) {
          return this.$_message.error('请选择平台')
        }
        if (this.searchForm.isp.length === 0) {
          return this.$_message.error('请选择运营商')
        }
        if (this.searchForm.removeDuplicateDate === '' || this.searchForm.removeDuplicateDate === null) {
          return this.$_message.error('请选择去重发送日期')
        }

        if (dateFlag) {
          return this.$_message.error('请选择日期范围')
        }
        if (date) {
          return this.$_message.error('日期范围只能在两个月内')
        }
        // if (!this.searchForm.scoreRange[0] && !this.searchForm.scoreRange[1]) {
        //   return this.$_message.error('客户分值可只填写一个或两个都填写')
        // }
        if (this.searchForm.scoreRange[0] !== undefined && (this.searchForm.scoreRange[0] > 100 || this.searchForm.scoreRange[0] < 0)) {
          return this.$_message.error('分值为0到100的整数')
        }
        if (this.searchForm.scoreRange[1] !== undefined && (this.searchForm.scoreRange[1] > 100 || this.searchForm.scoreRange[1] < 0)) {
          return this.$_message.error('分值为0到100的整数')
        }
        if (this.searchForm.scoreRange[0] !== undefined && this.searchForm.scoreRange[1] !== undefined && this.searchForm.scoreRange[0] > this.searchForm.scoreRange[1]) {
          return this.$_message.error('终止分值必须大于起始分值！')
        }

        // if (this.searchForm.mobileProvince.length === 0) {
        //   this.searchForm.mobileProvinceAll = true
        // }
        let mobileProvince = []
        mobileProvince = this.searchForm.mobileProvince.filter(t => {
          return t !== '全选'
        })
        let scoreRange = []
        let a = this.searchForm.scoreRange[0] !== undefined ? this.searchForm.scoreRange[0] : ''
        let b = this.searchForm.scoreRange[1] !== undefined ? this.searchForm.scoreRange[1] : ''
        if (this.searchForm.scoreRange[0] === undefined && this.searchForm.scoreRange[1] === undefined) {
          scoreRange = []
        } else {
          scoreRange = [a + '~' + b]
        }
        let data = {
          ...this.searchForm,
          dateRange: dateRange,
          operatorUserId: userId,
          mobileProvince: mobileProvince,
          scoreRange: scoreRange
        }
        this.loading = true
        let res = await messageApi.innerSearch(data)
        if (res.data.respCode === '1000') {
          this.loading = false
          if (res.data.body.resultKey && res.data.body.count) {
            this.resultKey = res.data.body.resultKey
            this.count = res.data.body.count
            this.taskNo = res.data.body.taskNo
            this.$_message.success('成功')
          } else {
            this.$_message.warning('查询结果为空')
            this.count = res.data.body.count
            this.resultKey = null
          }
        } else {
          this.loading = false
          this.$_message.error(res.data.respMsg)
        }
      } catch (error) {
        this.loading = false
      }
    },
    closeForm () {
      this.$refs.addform.resetFields()
    },
    addItem () {
      this.searchForm.dateRange.push({
        time: []
      })
    },
    delItem (item, index) {
      this.searchForm.dateRange.splice(index, 1)
    }
  }
}
</script>

<style lang="scss" scoped>
.blockWidth {
  display: inline-block;
  width:152px;
}
  .topBox{
    margin-bottom: 10px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14{
    padding-left:8px;
    font-size:14px
  }
</style>
