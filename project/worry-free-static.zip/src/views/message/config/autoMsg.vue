<!--定时任务-->
<template>
  <div>
    <div class="topBox">
      <el-form :inline="true" :model="queryForm" size="mini" class="margin-mini">
        <el-form-item label="平台名称:">
          <el-select  v-model="queryForm.platform" style="width:100px" clearable>
            <el-option
            v-for="(item,index) in mapList.platform"
            :key="index"
            :value="item.key"
            :label="item.value" 
            >
            </el-option>
          </el-select>
       </el-form-item>
       <el-form-item label="运营商:">
          <el-select  v-model="queryForm.isp" style="width:100px" clearable>
            <el-option
            v-for="(item,index) in mapList.ispList"
            :key="index"
            :value="item.key"
            :label="item.value" 
            >
            </el-option>
          </el-select>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="fetchData()" class="least" :loading="loading">搜索</el-button>
      </el-form-item>
    </el-form>
        <el-button type="primary" size="mini" @click="edit(editDialog.addFormEmpty, 1)" class="least" :loading="loading">新增</el-button>
    </div>
    <!--表格-->
    <!-- show-summary
      :summary-method="getSummaries" -->
    <el-table
      v-loading="tableLoading"
      :data="tableData"
      border fit
      highlight-current-row
      stripe
      :max-height="tableMaxHeight"
      style="width:100%"
      >
      <el-table-column
        prop="platform"
        label="平台名称"
        width="100px"
        >
        <template slot-scope="scope">
          {{scope.row.platform | platformFilter}}
        </template>
      </el-table-column>
      <el-table-column
        prop="segment"
        label="环节"
        width="100px"
        >
        <template slot-scope="scope">
          {{scope.row.segment | segmentFilter}}
        </template>
      </el-table-column>
      <el-table-column
        prop="node"
        label="节点"
        width="100px"
        >
        <template slot-scope="scope">
          {{scope.row.node | nodeFilter}}
        </template>
      </el-table-column>
      <el-table-column
        prop="isp"
        label="运营商"
        width="100px"
        >
        <template slot-scope="scope">
          {{scope.row.isp | ispFilter}}
        </template>
      </el-table-column>
      <el-table-column
        prop="passageWay"
        label="第一通道"
        >
        <template slot-scope="scope">
          {{scope.row.firstPassageWay | passageWay}}
        </template>
      </el-table-column>
      <el-table-column
        prop="firstMessage"
        label="第一通道短信模板"
        width="160px"
        >
      </el-table-column>
      <el-table-column
        prop="passageWay"
        label="第二短信通道"
        >
        <template slot-scope="scope">
          {{scope.row.secondPassageWay | passageWay}}
        </template>
      </el-table-column>
      <el-table-column
        prop="secondMessage"
        label="第二通道短信模板"
        width="160px"
        >
      </el-table-column>
      <el-table-column
        prop="spaceTime"
        width="100px"
        label="间隔时间"
        >
        <template slot-scope="scope">
          <span>
            {{scope.row.spaceTime}} 分钟
          </span>
        </template>
      </el-table-column>
      <el-table-column
        prop="status"
        width="100px"
        label="状态"
        >
        <template slot-scope="scope">
          <span :class="{t_red: scope.row.status === 1}">
              {{mapList.status[scope.row.status]}}
          </span>
        </template>
      </el-table-column>

      <el-table-column
        prop="createAt"
        label="操作"
        width="160"
      >
      <template slot-scope="scope">
        <el-button type="text" size="mini" @click="edit(scope.row)">修改</el-button>
        <el-button type="text" size="mini" @click="deleteVisibleHandle(scope.row)">删除</el-button>
        <el-button type="text" size="mini" @click="oprateDialog(scope.row)">操作记录</el-button>
      </template> 
      </el-table-column>
    </el-table>
    <!-- <div  class="pagination-container" v-if="!tableLoading">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div> -->
    
    <!-- 修改 -->
     <el-dialog :visible.sync="editDialog.show" :title="dialogTitle" @close="closeDialog">
       
       <el-form :model="editDialog.addForm" ref="addForm" size="mini" :rules="editDialog.addRules" label-width="100px">
         <el-form-item label="平台名称" prop="platform">
          <el-select  v-model="editDialog.addForm.platform" style="width:200px" :disabled="dialogType === 0">
            <el-option
            v-for="(item,index) in mapList.platform"
            :key="index"
            :value="item.key"
            :label="item.value" 
            >
            </el-option>
          </el-select>
         </el-form-item>
         <el-form-item label="环节" prop="segment">
          <el-select  v-model="editDialog.addForm.segment" style="width:200px" :disabled="dialogType === 0">
            <el-option
            value="1"
            label="注册后" 
            >
            </el-option>
          </el-select>
         </el-form-item>
         <el-form-item label="节点" prop="node">
          <el-select  v-model="editDialog.addForm.node" style="width:200px" :disabled="dialogType === 0">
            <el-option
            value="101"
            label="注册N分钟未登陆" 
            >
            </el-option>
          </el-select>
         </el-form-item>
         <el-form-item label="运营商" prop="isp">
          <el-select  v-model="editDialog.addForm.isp" multiple style="width:200px" :disabled="dialogType === 0">
            <el-option
            v-for="(item,index) in mapList.ispList"
            :disabled="item.disabled" 
            :key="index"
            :value="item.key"
            :label="item.value" 
            >
            </el-option>
          </el-select>
         </el-form-item>
         <el-form-item label="第一通道" prop="firstPassageWay">
          <el-select  v-model="editDialog.addForm.firstPassageWay" style="width:200px">
            <el-option
            v-for="(item,index) in mapList.passageWay"
            :key="index"
            :value="item.value"
            :label="item.label"
            :disabled="item.disabled" 
            >
            </el-option>
          </el-select>
         </el-form-item>
          <el-form-item label="第一通道短信模板"  prop="firstMessage">
            <el-input v-model="editDialog.addForm.firstMessage" type='textarea' :rows="6" :maxlength="70">
          </el-input>
          </el-form-item>
          <el-form-item label="第二通道" prop="secondPassageWay">
          <el-select  v-model="editDialog.addForm.secondPassageWay" style="width:200px" clearable>
             <el-option
            v-for="(item,index) in mapList.passageWayTwo"
            :key="index"
            :value="item.value"
            :label="item.label" 
            :disabled="item.disabled"
            >
            </el-option>
          </el-select>
         </el-form-item>
          <el-form-item label="第二通道短信模板"  prop="secondMessage" :required="!!editDialog.addForm.secondPassageWay">
            <el-input v-model="editDialog.addForm.secondMessage" type='textarea' :rows="6" :maxlength="70" :disabled="editDialog.addForm.secondPassageWay === ''">
          </el-input>
          </el-form-item>
         <el-form-item label="间隔时间"  prop="spaceTime">
           <el-row>
             <el-col :span="4">
               <el-input v-model="editDialog.addForm.spaceTime">
                </el-input>
             </el-col>
             分钟
           </el-row>
         </el-form-item>
         <el-form-item label="状态"  prop="status">
           <el-switch
            v-model="editDialog.addForm.status"
            active-color="#13ce66"
            inactive-color="#cccccc">
          </el-switch>
          启用
         </el-form-item>
       </el-form>
       <div slot="footer" class="dialog-footer">
          <el-button  @click="editDialog.show = false">取消</el-button>
          <el-button type="primary" @click="submit">保存</el-button>
        </div>
     </el-dialog>

     <el-dialog :visible.sync="operate.show" title="操作记录" >
       <div>
         <div v-for="(item,index) in operate.list" style="margin-bottom:10px">
           <span>{{index + 1}}.</span>
           <span>{{item.operateTime}}</span>
           <!-- <span>{{item.operateUser}}</span> -->
           <span>{{item.operateFunction}}</span>
         </div>
       </div>
     </el-dialog>
    <!-- 删除操作 -->
     <el-dialog
      title="删除确认"
      :visible.sync="dialogDeletedVisible">
      <span>确定要删除吗?</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogDeletedVisible = false">取 消</el-button>
        <el-button type="primary" @click="deleteHandle">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import VueElTooltip from '../../../components/VueElTooltip'
// import Moment from 'moment'
import homeApi from '../../../api/messageApi/config/home.js'
import totalJson from '../../marketing/channel-tag/total'
import {objArrDeepCopy, unique} from '../../../utils/index'
// import Moment from 'moment'
export default {
  components: {
    VueElTooltip
  },
  data () {
    let validateMessage = (rule, value, callback) => {
      if (this.editDialog.addForm.secondMessage === '' && !!this.editDialog.addForm.secondPassageWay) {
        callback(new Error('请填写短信模板'))
      } else {
        callback()
      }
    }
    return {
      mapList: {
        passageWay: objArrDeepCopy(totalJson.passageWay),
        passageWayTwo: objArrDeepCopy(totalJson.passageWay),
        platform: objArrDeepCopy(totalJson.platformList2),
        ispList: objArrDeepCopy(totalJson.ispList),
        status: {
          0: '启用',
          1: '禁用'
        }
      },
      queryForm: {
        platform: null,
        isp: null
      },
      operate: {
        list: [],
        show: false
      },
      editDialog: {
        show: false,
        addRules: {
          platform: [{
            required: true,
            message: '请选择'
          }],
          segment: [{
            required: true,
            message: '请选择'
          }],
          node: [{
            required: true,
            message: '请选择'
          }],
          isp: [{
            required: true, type: 'array', message: '请选择', trigger: 'change'
          }],
          firstPassageWay: [{
            required: true,
            message: '请选择'
          }],
          firstMessage: [{
            required: true,
            message: '请填写短信模板',
            trigger: 'blur'
          }],
          secondMessage: [{ validator: validateMessage }],
          spaceTime: [
            {
              required: true,
              trigger: 'blur',
              validator: (rule, value, callback) => {
                if (value === '') {
                  callback(new Error('请输入间隔时间!'))
                } else if (/^[0-9]*$/.test(value) && value > 0) {
                  callback()
                } else {
                  callback(new Error('只能输入正整数！'))
                }
              }
            }
          ]
        },
        addForm: {
          id: '',
          platform: '',
          node: '101',
          isp: [ ],
          segment: '1',
          firstPassageWay: '',
          firstMessage: '',
          secondPassageWay: '',
          secondMessage: '',
          operateUserId: '',
          spaceTime: 0,
          status: false
        },
        addFormEmpty: {
          id: '',
          platform: '',
          node: '101',
          isp: [ ],
          segment: '1',
          firstPassageWay: '',
          firstMessage: '',
          secondPassageWay: '',
          secondMessage: '',
          operateUserId: '',
          spaceTime: 0,
          status: false
        }
      },
      loading: false,
      tableLoading: false,
      selectList: {
        statusList: [{key: 0, value: '隐藏'}, {key: 1, value: '显示'}]
      },
      dialogTitle: '',
      dialogType: 0,
      dialogDeletedVisible: false,
      dialogDeletedRow: null,
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [100, 200, 500],
        pageSize: 100, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [

      ],
      listLoading: false
    }
  },
  // beforeRouteLeave (to, from, next) {
  //   const answer = window.confirm('Do you really want to leave? you have unsaved changes!')
  //   if (answer) {
  //     next()
  //   } else {
  //     next(false)
  //   }
  // },
  watch: {
    'editDialog.addForm.platform': {
      handler () {
        this.dialogType === 1 && this.ispCheck()
      }
    },
    'editDialog.addForm.node': {
      handler () {
        this.dialogType === 1 && this.ispCheck()
      }
    },
    'editDialog.addForm.segment': {
      handler () {
        this.dialogType === 1 && this.ispCheck()
      }
    },
    'editDialog.addForm.secondPassageWay': {
      handler (val) {
        this.passageWayHandle('passageWay', val)
      }
    },
    'editDialog.addForm.firstPassageWay': {
      handler (val) {
        this.passageWayHandle('passageWayTwo', val)
      }
    }
  },
  created () {
    this.fetchData()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    closeDialog () {
      this.editDialog.show = false
      this.$refs.addForm.resetFields()
      this.mapList.passageWay = objArrDeepCopy(totalJson.passageWay)
      this.mapList.passageWayTwo = objArrDeepCopy(totalJson.passageWay)
    },
    async oprateDialog (row) {
      let data = {
        id: row.id
      }
      let res = await homeApi.operateRecord(data)
      this.tableLoading = false
      if (res.data.respCode === '1000') {
        if (res.data.body.length < 1) {
          return this.$_message.error('记录为空')
        }
        this.operate.show = true
        this.operate.list = res.data.body
      } else {
        this.$_message.error(res.data.respMsg)
        this.operate.list = []
      }
    },
    async submit () {
      this.$refs['addForm'].validate(async valid => {
        if (!valid) {
          return false
        }
        let obj = Object.assign({}, this.editDialog.addForm)
        obj.spaceTime = Number(this.editDialog.addForm.spaceTime)
        obj.isp = this.editDialog.addForm.isp + ''
        obj.status = this.editDialog.addForm.status ? 0 : 1
        let res = await homeApi.saveOrUpdate(obj)
        if (res.data.respCode === '1000') {
          this.editDialog.show = false
          this.$_message.success('操作成功')
          this.fetchData()
        } else {
          this.$_message.error(res.data.respMsg)
        }
      })
    },
    // 删除弹框显示
    deleteVisibleHandle (row) {
      this.dialogDeletedVisible = true
      this.dialogDeletedRow = row
    },
    // 删除短信配置
    async deleteHandle () {
      this.dialogDeletedVisible = false
      let res = await homeApi.delete({
        id: this.dialogDeletedRow.id
      })
      if (res.data.respCode === '1000') {
        this.$_message.success('操作成功')
        this.fetchData()
      } else {
        this.$_message.error(res.data.respMsg)
      }
    },
    // 检查可选择运营商
    async ispCheck () {
      let res = await homeApi.ispCheck({
        id: this.editDialog.addForm.id,
        node: this.editDialog.addForm.node,
        platform: this.editDialog.addForm.platform,
        segment: this.editDialog.addForm.segment
      })
      if (res.data.respCode === '1000') {
        let disabledArr = res.data.body
        this.editDialog.addForm.isp = unique(this.editDialog.addForm.isp, disabledArr)
        this.mapList.ispList = objArrDeepCopy(totalJson.ispList)
        this.mapList.ispList.forEach(item => {
          if (disabledArr.indexOf(item.key) > -1) {
            item.disabled = true
          }
        })
      } else {
        this.$_message.error(res.data.respMsg)
      }
    },
    // 增加和编辑短信配置
    edit (row, type = 0) {
      this.dialogTitle = type ? '新增自动短信' : '修改自动短信'
      let isp = row.isp + ''
      this.editDialog.addForm = Object.assign({}, row, {operateUserId: this.$store.state.loginUser.userId})
      this.editDialog.addForm.isp = isp ? isp.split(',') : []
      this.editDialog.addForm.status = !row.status
      this.editDialog.show = true
      this.dialogType = type
    },
    // 通道互斥
    passageWayHandle (name, val) {
      this.mapList[name].forEach(item => {
        item.disabled = false
        if (item.value === val) item.disabled = true
      })
    },
    async fetchData (val) {
      this.tableLoading = true
      try {
        let res = await homeApi.configList({
          isp: this.queryForm.isp,
          platform: this.queryForm.platform
        })
        this.tableLoading = false
        if (res.data.respCode === '1000') {
          this.tableData = res.data.body
        } else {
          this.$_message.eror(res.data.respMsg)
        }
      } catch (error) {
        this.tableLoading = false
      }
    },
    getSummaries (param) {
      // const { columns } = param
      // console.log(columns)
      const sums = []
      sums[0] = '汇总'
      sums[1] = this.userScoreQueryReportVO.total
      return sums
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 175
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between;
  }
  .bg{
    background-color: rgba(242, 242, 242, 0.388235294117647);
    margin-bottom:20px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }
  .t_red{
    color: rgb(247, 107, 107);
  }
  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14{
    padding-left:8px;
    font-size:14px
  }
</style>
