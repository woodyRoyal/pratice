<!--定时任务-->
<template>
  <div>
    <div class="topBox">
      <el-form :inline="true" :model="queryForm" size="mini" class="margin-mini">
        <el-form-item label="平台名称:">
          <el-select  v-model="queryForm.platform" style="width:100px" clearable>
            <el-option
            v-for="(item,index) in mapList.platform"
            :key="index"
            :value="item.key"
            :label="item.value" 
            >
            </el-option>
          </el-select>
       </el-form-item>
       <el-form-item label="运营商:">
          <el-select  v-model="queryForm.isp" style="width:100px" clearable>
            <el-option
            v-for="(item,index) in mapList.ispList"
            :key="index"
            :value="item.key"
            :label="item.value" 
            >
            </el-option>
          </el-select>
       </el-form-item>
       <el-form-item label="通道:">
          <el-select style="width:100px"  v-model="queryForm.passageWay" clearable>
            <el-option
            v-for="(item,index) in mapList.passageWay"
            :key="index"
            :value="item.value"
            :label="item.label"
            :disabled="item.disabled" 
            >
            </el-option>
          </el-select>
       </el-form-item>
        <el-form-item label="发送日期:">
          <el-date-picker
            size="mini"
            :picker-options="pickerOptions0"
            v-model="queryForm.time"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            value-format="yyyy-MM-dd"
            end-placeholder="结束日期">
          </el-date-picker>
       </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="fetchData()" class="least" :loading="loading">搜索</el-button>
        <el-button type="primary" size="mini" @click="downLoad()" class="least" :loading="downLoading">导出</el-button>
      </el-form-item>
    </el-form>
    </div>
    <!--表格-->
    <!-- show-summary
      :summary-method="getSummaries" -->
    <el-table
      v-loading="tableLoading"
      :data="tableData"
      border fit
      highlight-current-row
      stripe
      :max-height="tableMaxHeight"
      style="width:100%"
      >
      <el-table-column
        prop="platform"
        label="平台名称"
        width="100px"
        >
        <template slot-scope="scope">
          {{scope.row.platform | platformFilter}}
        </template>
      </el-table-column>
      <el-table-column
        prop="isp"
        label="运营商"
        width="100px"
        >
        <template slot-scope="scope">
          {{scope.row.isp | ispFilter}}
        </template>
      </el-table-column>
      <el-table-column
        prop="sendTime"
        label="发送日期"
        >
      </el-table-column>
      <el-table-column
        prop="passageWay"
        label="通道"
        >
        <template slot-scope="scope">
          {{scope.row.passageWay | passageWay}}
        </template>
      </el-table-column>
      <el-table-column
        prop="segment"
        label="环节"
        >
        <template slot-scope="scope">
          {{scope.row.segment | segmentFilter}}
        </template>
      </el-table-column>
      <el-table-column
        prop="node"
        label="节点"
        >
        <template slot-scope="scope">
          {{scope.row.node | nodeFilter}}
        </template>
      </el-table-column>
      <el-table-column
        prop="sendAmount"
        label="发送数量"
        >
      </el-table-column>
      <el-table-column
        prop="arrivalAmount"
        label="到达数量"
        >
      </el-table-column>
      <el-table-column
        prop="arrivalRate"
        label="到达率"
        >
        <template slot-scope="scope">
          {{scope.row.arrivalRate + '%'}}
        </template>
      </el-table-column>
      <el-table-column
        prop="firstLoginAmount"
        label="首登数量"
        >
      </el-table-column>
      <el-table-column
        prop="firstLoginRate"
        label="首登转化率"
        >
        <template slot-scope="scope">
          {{scope.row.firstLoginRate + '%'}}
        </template>
      </el-table-column>
    </el-table>
    <div  class="pagination-container" v-if="!tableLoading">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                     :current-page.sync="pagination.pageNo" :page-sizes="pagination.pageSizes"
                     :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="pagination.total">
      </el-pagination>
    </div>
    
    <!-- 广告主 -->
     <!-- <el-dialog :visible.sync="addAdvDialog.show" :title="addAdvDialog.title" @close="closeAdd">
       <el-form :model="addAdvDialog.addForm" ref="addForm" size="mini" :rules="addAdvDialog.addRules">
         <el-form-item label="商务负责人" :label-width="addAdvDialog.labelWidth" prop="principalName">
            <el-input v-model="addAdvDialog.addForm.principalName">

            </el-input>
         </el-form-item>
       </el-form>
       <div slot="footer" class="dialog-footer">
          <el-button  @click="addAdvDialog.show = false">取消</el-button>
          <el-button type="primary" @click="submitAdv">确认</el-button>
        </div>
     </el-dialog> -->
  </div>
</template>

<script>
import VueElTooltip from '../../../components/VueElTooltip'
// import Moment from 'moment'
import reportApi from '../../../api/messageApi/config/report.js'
import totalJson from '../../marketing/channel-tag/total'
import {objArrDeepCopy} from '../../../utils/index'
// import Moment from 'moment'
export default {
  components: {
    VueElTooltip
  },
  data () {
    return {
      mapList: {
        passageWay: objArrDeepCopy(totalJson.passageWay),
        platform: totalJson.platformList2,
        ispList: objArrDeepCopy(totalJson.ispList),
        status: {
          0: '启用',
          1: '禁用'
        }
      },
      id: null,
      loading: false,
      pickerOptions0: {
        disabledDate (time) {
          // return time.getTime() > Date.now() - 8.64e7
          let temp = new Date().getTime()
          return time.getTime() > temp
        }
      },
      filterSearch: {
        userPlatform: '',
        dateRange: [{time: []}]
      },
      searchForm: {
        time: [],
        mobilePhone: ''
      },
      checked: false,
      timer: null,
      downLoading: false,
      centerDialogVisible: true,
      status: '已生成文件',
      tableLoading: false,
      editDialog: false,
      queryForm: {
        time: [],
        isp: '',
        passageWay: '',
        platform: '',
        sendStatus: ''
      },
      title: '新增',
      tableMaxHeight: 600,
      pagination: {
        pageNo: 1, // pageNo
        pageSizes: [100, 200, 500],
        pageSize: 100, // pageSize
        total: 0 // totalRecordNum
      },
      formFilter: {
        customerName: '',
        customerCode: '',
        customerType: null
      },
      tableData: [

      ],
      listLoading: false
    }
  },
  // beforeRouteLeave (to, from, next) {
  //   const answer = window.confirm('Do you really want to leave? you have unsaved changes!')
  //   if (answer) {
  //     next()
  //   } else {
  //     next(false)
  //   }
  // },
  created () {
    this.fetchData()
  },
  mounted () {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed () {
    window.removeEventListener('resize', this.handleResize)
  },
  computed: {
  },
  watch: {
  },
  methods: {
    async fetchFilterSearch () {
      let dateRange = []
      let dateFlag = false
      let date = false
      this.filterSearch.dateRange.forEach(t => {
        if (t.time !== null) {
          if (t.time.length === 0) {
            dateFlag = true
          }
          if (t.time.length > 0) {
            dateRange.push(t.time[0] + '~' + t.time[1])
            let s1 = new Date(t.time[0].replace(/-/g, '/'))
            let s2 = new Date(t.time[1].replace(/-/g, '/'))
            let days = s2.getTime() - s1.getTime()
            if (parseInt(days / (1000 * 60 * 60 * 24)) > 60) {
              date = true
            }
          }
        } else {
          dateFlag = true
        }
      })

      if (dateFlag) {
        return this.$_message.error('请选择日期范围')
      }
      if (date) {
        return this.$_message.error('日期范围只能在两个月内')
      }
      let data = {
        lastLoginDate: dateRange,
        userPlatform: this.filterSearch.userPlatform
      }
      this.loading = true
      const res = await reportApi.select(data)
      if (res.data.code === '0') {
        this.$message.warning('已创建筛选任务，请稍后…')
        this.id = setInterval(() => {
          this.loading = false
          clearInterval(this.id)
        }, 3000)
      } else {
        this.loading = false
      }
    },
    async fetchData (val) {
      this.tableLoading = true
      if (!this.queryForm.time) {
        this.queryForm.time = []
      }
      let data = {
        beginSendTime: this.queryForm.time[0] || '',
        endSendTime: this.queryForm.time[1] || '',
        passageWay: this.queryForm.passageWay,
        platform: this.queryForm.platform,
        isp: this.queryForm.isp,
        pageNum: this.pagination.pageNo,
        pageSize: this.pagination.pageSize
      }
      let res = await reportApi.dataReport(data)
      if (res.data.respCode === '1000') {
        this.tableLoading = false
        res.data.body.list.forEach(t => {
          t.passageWayArr = t.passageWay.split(',')
          if (t.firstLoginRate !== null) {
            let temp = parseFloat((t.firstLoginRate * 100).toPrecision(12))
            t.firstLoginRate = temp.toFixed(2)
          }
          if (t.arrivalRate !== null) {
            let temp = parseFloat((t.arrivalRate * 100).toPrecision(12))
            t.arrivalRate = temp.toFixed(2)
          }
        })
        this.pagination.total = res.data.body.total
        this.pagination.pageNo = res.data.body.pageNum
        this.tableData = res.data.body.list
        if (this.pagination.pageNo > 1 && this.tableData.length < 1) {
          this.pagination.pageNo = 1
          this.fetchData()
        }
      } else {
        this.$_message.error(res.data.respMsg)
        this.tableLoading = false
      }
    },
    async downLoad () {
      if (!this.queryForm.time) {
        this.queryForm.time = []
      }
      let data = {
        beginSendTime: this.queryForm.time[0] || '',
        endSendTime: this.queryForm.time[1] || '',
        passageWay: this.queryForm.passageWay,
        platform: this.queryForm.platform,
        isp: this.queryForm.isp,
        sendStatus: this.queryForm.sendStatus,
        pageNum: this.pagination.pageNo,
        pageSize: this.pagination.pageSize
      }

      window.location.href = process.env.BASE_API +
      `/auto/sms/dataReport/export?beginSendTime=${data.beginSendTime}&endSendTime=${data.endSendTime}&passageWay=${data.passageWay}&platform=${data.platform}&isp=${data.isp}`
    },
    getSummaries (param) {
      // const { columns } = param
      // console.log(columns)
      const sums = []
      sums[0] = '汇总'
      sums[1] = this.userScoreQueryReportVO.total
      return sums
    },
    handleResize (event) {
      this.$nextTick(() => {
        let h = document.documentElement.clientHeight
        this.tableMaxHeight = h - 175
      })
    },
    handleSizeChange (val) {
      this.pagination.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pagination.pageNo = val
      this.fetchData()
    },
    handleClearFiles () {
      this.fileList = []
      this.file = null
    },
    // 批量修改-上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传
    handleUploadBefore (file) {
      if (file.name && file.name.length > 0) {
        const ldot = file.name.lastIndexOf('.')
        const type = file.name.toLowerCase().substring(ldot)
        if (type !== '.txt') {
          this.$_message.warning('目前只支持.txt格式的文件')
          return false
        }
        this.uploadFileName = file.name
        console.log(this.uploadFileName)
      }
    },
    // 批量修改-文件上传成功时的钩子
    handleUploadSuccess (response, file, fileList) {
      console.log('上传成功')
      this.uploadTagVisible = true
    },
    // 批量修改-文件上传失败时的钩子
    handleUploadError (err, file, fileList) {
      if (err.status === 404) {
        this.$_message.error('上传失败，网络连接异常!')
      } else {
        console.log(err)
        this.$_message.error('上传失败!')
      }
    },
    // 导入项目-文件上传时的钩子
    handleUploadProgress (event, file, fileList) {
      console.log('上传中...')
    },
    async handleUploadChange (file, fileList) {
      try {
        let userId = this.$store.state.loginUser.userId
        this.handleClearFiles()
        this.fileList = [file]
        this.uploadFileName = file.name
        this.file = file.raw
        this.uploading = true
        let param = new window.FormData()
        param.append('file', this.file)
        param.append('userId', userId)
        let res = await reportApi.import(param, userId)
        if (res.data.respCode === '1000') {
          this.$_message.success('全部导入成功')
          this.closeFile()
          this.handleClearFiles()
          this.fetchData()
          this.uploading = false
        } else if (res.data.respCode === '1135') {
          this.$_message.warning('部分导入成功')
          this.closeFile()
          this.handleClearFiles()
          this.fetchData()
          this.uploading = false
        } else if (res.data.respCode === '1137') {
          this.$_message.warning('单次导入手机号上限1万条')
          this.closeFile()
          this.fetchData()
          this.handleClearFiles()
          this.uploading = false
        } else {
          this.$_message.error('导入失败，请重试')
          this.closeFile()
          this.handleClearFiles()
          this.uploading = false
        }
      } catch (error) {
        this.uploading = false
      }
    },
    closeFile () {
      this.$refs.uploadFile && this.$refs.uploadFile.clearFiles()
      this.handleClearFiles()
    },
    addItem () {
      this.filterSearch.dateRange.push({
        time: []
      })
    },
    delItem (item, index) {
      this.filterSearch.dateRange.splice(index, 1)
    }
    // async fetchUpload () {
    //   if (!this.file) return this.$_message.error('请先选择文件')
    //   this.uploading = true
    //   let param = new window.FormData()
    //   param.append('file', this.file)
    //   try {
    //     if (this.batchUploadDialog.type === 1) {
    //       let res = await BusinessPrincipalApi.productArpuImport(param)
    //       if (res.data.respCode === '1000') {
    //         this.$_message.success('上传成功')
    //         this.uploading = false
    //         this.getTableData()
    //         this.batchUploadDialog.show = false
    //       } else {
    //         this.$_message.error(res.data.respMsg)
    //         this.uploading = false
    //       }
    //     }
    //     if (this.batchUploadDialog.type === 2) {
    //       let res = await BusinessPrincipalApi.productUvClickLimitImport(param)
    //       if (res.data.respCode === '1000') {
    //         this.$_message.success('上传成功')
    //         this.uploading = false
    //         this.getTableData()
    //         this.batchUploadDialog.show = false
    //       } else {
    //         this.$_message.error(res.data.respMsg)
    //         this.uploading = false
    //       }
    //     }
    //   } catch (error) {
    //     this.uploading = false
    //   }
    // }
  }
}
</script>

<style lang="scss" scoped>
  .topBox{
    margin-bottom: 10px;
  }
  .bg{
    background-color: rgba(242, 242, 242, 0.388235294117647);
    margin-bottom:20px;
  }
  .add-btn {
    margin-bottom: 10px;
  }

  .el-table {
    .el-input-number--small {
      width: 100px;
    }
  }

  // td超出省略
  .name-wrapper {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fs-14{
    padding-left:8px;
    font-size:14px
  }
</style>
