import platform from './platform'
export { platform }
