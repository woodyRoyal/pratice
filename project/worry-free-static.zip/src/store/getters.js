const getters = {
  pkg: state => state.pkg,
  sidebar: state => state.app.sidebar,
  visitedViews: state => state.app.visitedViews,

  // 登陆用户信息
  userId: state => state.loginUser.userId,
  username: state => state.loginUser.username,
  displayName: state => state.loginUser.displayName,
  token: state => state.loginUser.token,
  roleList: state => state.loginUser.roleList,
  menuList: state => state.loginUser.menuList,
  permissionList: state => state.loginUser.permissionList,
  systemList: state => state.loginUser.systemList,
  // 菜单权限
  permissionRouters: state => state.permission.routers,
  addRouters: state => state.permission.addRouters,
  menuPathList: state => state.permission.menuPathList
}
export default getters
