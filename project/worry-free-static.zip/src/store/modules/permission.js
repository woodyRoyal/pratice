import { lastRouterConst, constantRouterMap, asyncRouterMapObj } from 'src/router'
// import { lastRouterConst, constantRouterMap, asyncRouterMapTree } from 'src/router'

function addRouterAttribute (menu) {
  if (!asyncRouterMapObj[menu.path]) {
    return menu
  }
  if (asyncRouterMapObj[menu.path].component) {
    menu.component = asyncRouterMapObj[menu.path].component
  }
  // menu.name = asyncRouterMapObj[menu.path].name
  if (asyncRouterMapObj[menu.path].icon) {
    menu.icon = asyncRouterMapObj[menu.path].icon
  }
  if (asyncRouterMapObj[menu.path].noDropdown) {
    menu.noDropdown = asyncRouterMapObj[menu.path].noDropdown
  }
  if (asyncRouterMapObj[menu.path].hidden) {
    menu.hidden = asyncRouterMapObj[menu.path].hidden
  }
  if (asyncRouterMapObj[menu.path].redirect) {
    menu.redirect = asyncRouterMapObj[menu.path].redirect
  }
  if (asyncRouterMapObj[menu.path].meta) {
    menu.meta = asyncRouterMapObj[menu.path].meta
  }
  if (menu.children && menu.children.length > 0) {
    menu.children = menu.children.map((item) => addRouterAttribute(item))
  }
  return menu
}

// 菜单树转换为菜单数组
function menuTreeToList (source, target, parentPath) {
  if (!source) {
    return target
  }
  let path = ''
  if (parentPath === '') {
    path = source.path
  } else {
    path = parentPath + '/' + source.path
  }

  target.push(path)
  // 递归处理子菜单
  if (source.children && source.children.length > 0) {
    source.children.map((item) => menuTreeToList(item, target, path))
  }
  return target
}

let cacheMenuPath = window.localStorage.getItem('Free-MenuPath')
const permission = {
  state: {
    routers: constantRouterMap,
    addRouters: [],
    menuPathList: cacheMenuPath ? JSON.parse(cacheMenuPath) : [],
  },

  mutations: {
    SET_ROUTERS: (state, routers) => {
      state.addRouters = routers
      state.routers = constantRouterMap.concat(routers).concat(lastRouterConst)

      // 获取菜单路径
      let menuPathList = []
      for (let j = 0, len = state.routers.length; j < len; j++) {
        menuTreeToList(state.routers[j], menuPathList, '')
      }
      state.menuPathList = menuPathList
      window.localStorage.setItem('Free-MenuPath', JSON.stringify(menuPathList))
    },
    CLEAR_ROUTERS: (state) => {
      state.routers = constantRouterMap
      state.addRouters = []
      state.menuPathList = []
    },
  },

  actions: {
    GenerateRoutes ({commit}, data) {
      return new Promise((resolve) => {
        const {menuList} = data
        const accessedRouters = menuList.length ? menuList.map((item) => addRouterAttribute(item)) : []
        console.log(accessedRouters)
        commit('SET_ROUTERS', accessedRouters)
        // commit('SET_ROUTERS', asyncRouterMapTree)
        resolve()
      })
    },
    // 清空路由
    ClearRouters ({commit}) {
      commit('CLEAR_ROUTERS')
    },
  },
}

export default permission
