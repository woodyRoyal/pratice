import api from '../../api/planMsg/channel'
const ispMap = {
  1: '移动',
  2: '联通',
  3: '电信',
}
const planMsgConfig = {
  state: {
    // 运营商列表
    ispList: {
      //移动
      1: [],
      // 联通
      2: [],
      // 电信
      3: [],
      // 通道集合 用来用翻译
      total: [],
    },
  },
  mutations: {
    // 移动运营商列表
    SET_ISP (state, total) {
      let isp = {
        1: [],
        2: [],
        3: [],
        total: [],
      }
      state.ispList = isp
      const arr = [1, 2, 3]
      // 把获取到的通道按运营商分类
      total.forEach((t) => {
        arr.forEach((item) => {
          if (t.isp === item) {
            isp[item].push({
              ...t,
              label: `${t.passageName}-${ispMap[t.isp]}`,
            })
          }
        })
      })
      state.ispList = {
        ...isp,
        total: isp[1].concat(isp[2], isp[3]),
      }
    },
  },
  actions: {
    async fetchISP ({ commit }, data) {
      let res = await api.getConfigList(data)
      if (res.data.respCode === '1000') {
        commit('SET_ISP', res.data.body.list)
      }
    },
  },
}

export default planMsgConfig
