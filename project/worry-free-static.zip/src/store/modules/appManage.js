const appManage = {
  state: {
    openAdvertise: {
      show: false,
    },
    picDialog:{
      show:false,
    },
  },
  mutations: {
    changeOpenAdvertise: (state, pra) => {
      state.openAdvertise.show = pra
    },
    changePicDialog: (state, pra) => {
      state.picDialog.show = pra
    },
  },
  actions: {

  },
}

export default appManage
