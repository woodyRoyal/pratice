import {
  loginByUsername,
  logout,
  getUserInfo,
  getUcenterUserInfo,
  logoutUcenter,
  loginByUsernameAndToken,
} from 'api/login'
import Cookies from 'js-cookie'

// 权限树转换为权限数组
function permissionTreeToList (source, target) {
  target.push(source.permission)
  // 递归处理子菜单
  if (source.children && source.children.length > 0) {
    source.children.map((item) => permissionTreeToList(item, target))
  }
  return target
}

// 清除缓存数据
function clearAllCacheData () {
  // 清除本域名下所有cookie数据
  const cookies = Cookies.get()
  for (let key in cookies) {
    Cookies.remove(key)
  }

  // 清除本域名下所有localStorage数据
  const storage = window.localStorage
  storage.clear()
}

let cacheUser = window.localStorage.getItem('Free-User')
if (!cacheUser) {
  cacheUser = {
    id: '',
    username: '',
    displayName: '',
    token: '',
    rbacUserRoleList: [],
  }
} else {
  cacheUser = JSON.parse(cacheUser)
}

const cacheMenu = window.localStorage.getItem('Free-Menu')
const cachePermission = window.localStorage.getItem('Free-Permission')
const cacheSys = window.localStorage.getItem('UC-SystemList')
const cacheButton = window.localStorage.getItem('tabButtonPerms')
const cacheUserId = window.localStorage.getItem('userId')

const loginUser = {
  state: {
    userId: cacheUserId ? Number(cacheUserId) : null,
    username: cacheUser.username,
    displayName: cacheUser.displayName,
    token: Cookies.get('Free-Token'),
    roleList: cacheUser.rbacUserRoleList,
    menuList: cacheMenu ? JSON.parse(cacheMenu) : [],
    permissionList: cachePermission ? JSON.parse(cachePermission) : [],
    systemList: cacheSys ? JSON.parse(cacheSys) : [],
    tabButtonPerms: cacheButton ? JSON.parse(cacheButton) : [],
  },

  mutations: {
    SET_USER_ID: (state, userId) => {
      state.userId = userId
      window.localStorage.setItem('userId', userId)
    },
    SET_USERNAME: (state, username) => {
      state.username = username
    },
    SET_DISPLAY_NAME: (state, displayName) => {
      state.displayName = displayName
    },
    SET_TOKEN: (state, token) => {
      state.token = token
      Cookies.set('Free-Token', token)
    },
    SET_ROLE_LIST: (state, rbacUserRoleList) => {
      state.roleList = rbacUserRoleList
    },
    SET_MENU_LIST: (state, rbacMenuList) => {
      state.menuList = rbacMenuList
      window.localStorage.setItem('Free-Menu', JSON.stringify(rbacMenuList))
    },
    SET_BUTTON_LIST: (state, tabButtonPerms) => {
      state.tabButtonPerms = tabButtonPerms
      window.localStorage.setItem('tabButtonPerms', JSON.stringify(tabButtonPerms))
    },
    SET_PERMISSION_LIST: (state, rbacPermissionList) => {
      let permissionList = []
      rbacPermissionList.map((item) => permissionTreeToList(item, permissionList))
      state.permissionList = permissionList
      window.localStorage.setItem('Free-Permission', JSON.stringify(permissionList))
    },
    SET_SYSTEM_LIST: (state, systemList) => {
      state.systemList = systemList
      window.localStorage.setItem('UC-SystemList', JSON.stringify(systemList))
    },

    LOGOUT_USER: (state) => {
      state.userId = ''
      state.username = ''
      state.displayName = ''
      state.token = ''
      state.roleList = []
      state.menuList = []
      state.tabButtonPerms = []
      state.permissionList = []
      state.systemList = []
    },
  },

  actions: {
    // 作为独立系统的登录（暂时不用，后端该接口已关闭）
    LoginByUsername ({dispatch, commit}, userInfo) {
      const username = userInfo.username.trim()
      return new Promise((resolve, reject) => {
        loginByUsername(username, userInfo.password).then((response) => {
          const data = response.data
          if (data.errorCode === 0) {
            dispatch('GetUserInfo').then(() => {
              resolve()
            }).catch((error) => {
              resolve(error.message)
            })
          } else {
            resolve(data.errorMsg)
          }
        }).catch((error) => {
          reject(error)
        })
      })
    },

    // 退出该系统（暂时不用，后端该接口已关闭）
    Logout ({commit}) {
      return new Promise((resolve, reject) => {
        logout().then((response) => {
          const data = response.data
          if (data.errorCode === 0) {
            commit('LOGOUT_USER')
            Cookies.remove('Free-Token')
            // window.localStorage.removeItem('Free-User')
            // 清除本系统下所有localStorage数据
            const storage = window.localStorage
            if (storage && storage.length > 0) {
              for (let i = 0; i < storage.length; i++) {
                // key(i)获得相应的键，再用getItem()方法获得对应的值
                if (storage.key(i).startsWith('Free-')) {
                  window.localStorage.removeItem(storage.key(i))
                }
              }
            }
            commit('CLEAR_ROUTERS')
            resolve()
          } else {
            resolve(data.errorMsg)
          }
        }).catch((error) => {
          reject(error)
        })
      })
    },
    // username、token登录
    LoginByUsernameAndToken ({dispatch, commit}, {user}) {
      commit('LOGOUT_USER') // 重置登录信息
      commit('CLEAR_ROUTERS') // 清除路由
      return new Promise((resolve, reject) => {
        loginByUsernameAndToken(user.username, user.token).then((response) => {
          const res = response.data
          if (res.respCode === '1000') {
            // 存储token
            commit('SET_USER_ID', res.body.sysUser.id)
            if (res.body.tabButtonPerms && res.body.tabButtonPerms) {
              commit('SET_BUTTON_LIST', res.body.tabButtonPerms)
            }
            commit('SET_TOKEN', user.token)
            if (res.body && res.body.menu && res.body.menu.length) {
              commit('SET_MENU_LIST', res.body.menu)
            } else {
              resolve('该角色没有分配菜单，请找管理员分配！')
            }
            // commit('SET_USER_ID', res.body.userInfo.id)
            commit('SET_USERNAME', res.body.sysUser.username)
            // commit('SET_DISPLAY_NAME', res.body.userInfo.displayName)
            // commit('SET_SYSTEM_LIST', res.body.validSystemByUsername)
            // let rbacUser = {
            //   id: res.body.userInfo.id,
            //   username: res.body.userInfo.username,
            //   displayName: res.body.userInfo.displayName,
            //   token: user.token
            // }
            // window.localStorage.setItem('Free-User', JSON.stringify(rbacUser))
            // 后端无法实现从互金后台拿取用户信息和导航信息，暂时从url里面取出username

            commit('SET_DISPLAY_NAME', res.body.sysUser.displayName)
            let rbacUser = {
              displayName: res.body.sysUser.displayName,
              username: res.body.sysUser.username,
            }
            window.localStorage.setItem('Free-User', JSON.stringify(rbacUser))
            resolve()
          } else {
            resolve(res.respMsg)
          }
        }).catch((error) => {
          reject(error)
        })
      })
    },

    // 获取用户信息
    GetUserInfo ({commit, state}) {
      return new Promise((resolve, reject) => {
        if (!(document.cookie || navigator.cookieEnabled)) {
          window.alert('Cookie已被禁用')
        }
        getUserInfo().then((response) => {
          const res = response.data
          if (res.code === '0' && res.isSuccess === 'success') {
            if (!res.data.rbacMenuList || res.data.rbacMenuList.length === 0) {
              // throw new Error('请联系管理员分配该系统的权限')
              console.log('请联系管理员分配该系统的权限')
            }
            commit('SET_USER_ID', res.data.rbacUser.id)
            commit('SET_USERNAME', res.data.rbacUser.username)
            commit('SET_DISPLAY_NAME', res.data.rbacUser.displayName)

            if (!res.data.token) {
              throw new Error('会话过期')
            } else {
              commit('SET_TOKEN', res.data.token)
            }
            commit('SET_MENU_LIST', res.data.rbacMenuList)
            commit('SET_PERMISSION_LIST', res.data.rbacPermissionList)
            window.localStorage.setItem('Free-User', JSON.stringify(res.data.rbacUser))
          }
          resolve(response)
        }).catch((error) => {
          reject(error)
        })
      })
    },
    // 从用户中心获取用户信息
    GetUcenterUserInfo ({commit, state}) {
      return new Promise((resolve, reject) => {
        getUcenterUserInfo().then((response) => {
          const data = response.data
          if (data.rtn === '000' && data.result.user) {
            if (!data.result.systemList || data.result.systemList.length === 0) {
              throw new Error('无可用系统')
            }
            if (!data.result.menuTree || data.result.menuTree.length === 0) {
              throw new Error('无可用菜单')
            }
            commit('SET_SYSTEM_LIST', data.result.systemList)
          }
          resolve(response)
        }).catch((error) => {
          reject(error)
        })
      })
    },
    // 登出用户中心
    LogoutUcenter ({commit}) {
      return new Promise((resolve, reject) => {
        logoutUcenter().then((response) => {
          const data = response.data
          if (data.rtn === '000') {
            commit('LOGOUT_USER')
            commit('CLEAR_ROUTERS')

            // 先清除缓存
            clearAllCacheData()

            resolve()
          } else {
            resolve(data.errorMsg)
          }
        }).catch((error) => {
          reject(error)
        })
      })
    },
    // 拦截器登出到login
    FilterLogout ({commit}) {
      return new Promise((resolve) => {
        commit('LOGOUT_USER')
        commit('CLEAR_ROUTERS')

        // 先清除缓存
        clearAllCacheData()
        resolve()
      })
    },
    // 重置
    ResetMsg ({commit}) {
      commit('LOGOUT_USER')
      commit('CLEAR_ROUTERS')
      // 先清除缓存
      clearAllCacheData()
    },

    // 刷新页面请求
    RefreshLoad ({dispatch, commit}) {
      let user = {
        username: Cookies.get('UC-Username'),
        token: Cookies.get('UC-Token'),
      }
      return new Promise((resolve, reject) => {
        loginByUsernameAndToken(user.username, user.token).then((response) => {
          const res = response.data
          if (res.code === '0' && res.isSuccess === 'success') {
            commit('SET_TOKEN', user.token)
            commit('SET_USERNAME', user.username)
            resolve()
          } else {
            resolve(res.message)
          }
        }).catch((error) => {
          reject(error)
        })
      })
    },
  },
}

export default loginUser
