import Moment from 'moment'

function pluralize (time, label) {
  if (time === 1) {
    return time + label
  }
  return time + label + 's'
}
export function timeAgo (time) {
  const between = Date.now() / 1000 - Number(time)
  if (between < 3600) {
    return pluralize(~~(between / 60), ' minute')
  } else if (between < 86400) {
    return pluralize(~~(between / 3600), ' hour')
  } else {
    return pluralize(~~(between / 86400), ' day')
  }
}
// 日期格式化
export function parseTime (value, pattern) {
  if (!value) {
    return ''
  }
  if (typeof value === 'string') {
    value = new Date(value)
  }
  pattern = pattern || 'YYYY-MM-DD HH:mm:ss'
  return Moment(value).format(pattern)
}

export function formatTime (time, option) {
  time = +time * 1000
  const d = new Date(time)
  const now = Date.now()

  const diff = (now - d) / 1000

  if (diff < 30) {
    return '刚刚'
  } else if (diff < 3600) {
    // less 1 hour
    return Math.ceil(diff / 60) + '分钟前'
  } else if (diff < 3600 * 24) {
    return Math.ceil(diff / 3600) + '小时前'
  } else if (diff < 3600 * 24 * 2) {
    return '1天前'
  }
  if (option) {
    return parseTime(time, option)
  } else {
    return d.getMonth() + 1 + '月' + d.getDate() + '日' + d.getHours() + '时' + d.getMinutes() + '分'
  }
}

/* 数字 格式化 */
export function nFormatter (num, digits) {
  const si = [{ value: 1e18, symbol: 'E' }, { value: 1e15, symbol: 'P' }, { value: 1e12, symbol: 'T' }, { value: 1e9, symbol: 'G' }, { value: 1e6, symbol: 'M' }, { value: 1e3, symbol: 'k' }]
  for (let i = 0; i < si.length; i++) {
    if (num >= si[i].value) {
      return (num / si[i].value + 0.1).toFixed(digits).replace(/\.0+$|(\.[0-9]*[1-9])0+$/, '$1') + si[i].symbol
    }
  }
  return num.toString()
}

export function html2Text (val) {
  const div = document.createElement('div')
  div.innerHTML = val
  return div.textContent || div.innerText
}

export function toThousandslsFilter (num) {
  return (+num || 0).toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')
}

/**
 * 秒转为 天小时分秒
 * @param sec
 * @return
 */
export function formatSecond (seconds) {
  if (seconds === 0) {
    return '0秒'
  }
  if (!seconds) {
    return '-'
  }
  if (isNaN(seconds)) {
    return '-'
  }
  let sec = parseInt(seconds)
  let timeStr = sec + '秒'
  if (sec > 60) {
    let second = sec % 60
    let min = parseInt(sec / 60)
    timeStr = min + '分' + second + '秒'
    if (min > 60) {
      min = parseInt(sec / 60) % 60
      let hour = parseInt(sec / 3600)
      timeStr = hour + '小时' + min + '分' + second + '秒'
      if (hour > 24) {
        hour = parseInt(sec / 3600) % 24
        let day = parseInt(sec / 3600 / 24)
        timeStr = day + '天' + hour + '小时' + min + '分' + second + '秒'
      }
    }
  }
  return timeStr
}

/**
 * 毫秒转为 天小时分秒
 * @param millisecond
 * @return
 */
export function formatMillisecond (millisecond) {
  if (millisecond === 0) {
    return '0秒'
  }
  if (!millisecond) {
    return '-'
  }
  if (isNaN(millisecond)) {
    return '-'
  }
  let sec = parseInt(millisecond / 1000)
  let timeStr = sec + '秒'
  if (sec > 60) {
    let second = sec % 60
    let min = parseInt(sec / 60)
    timeStr = min + '分' + second + '秒'
    if (min > 60) {
      min = parseInt(sec / 60) % 60
      let hour = parseInt(sec / 3600)
      timeStr = hour + '小时' + min + '分' + second + '秒'
      if (hour > 24) {
        hour = parseInt(sec / 3600) % 24
        let day = parseInt(sec / 3600 / 24)
        timeStr = day + '天' + hour + '小时' + min + '分' + second + '秒'
      }
    }
  }
  return timeStr
}

/**
 * 平台:0-全部 1-花钱无忧 2-大圣钱包 3-无忧钱包 4-贷款王 5-H5聚合页 8-立即借 9-无忧钱袋
 * @param msg
 * @return
 */
export function platformToMsg (platform) {
  switch (Number(platform)) {
  case 0:
    return '全部'
  case 1:
    return '花钱无忧'
  case 2:
    return '大圣钱包'
  case 3:
    return '无忧钱包'
  case 4:
    return '贷款王'
  case 5:
    return 'H5聚合页'
  case 8:
    return '立即借'
  case 9:
    return '无忧钱袋'
  }
}

/**
 * 端: 1.官网 2.APP
 * @param msg
 * @return
 */
export function sourceToMsg (platform) {
  switch (Number(platform)) {
  case 1:
    return '官网'
  case 2:
    return 'APP'
  }
}
/**
 * 短信通道解析
 */
export function passageWay (msg) {
  const passageWay = {
    ZD: '智鼎',
    AW: '昂网',
    YR: '云融',
    YXT: '一信通',
  }
  if (!msg) return ''
  return passageWay[msg]
}

/**
 * 节点
 * @param {*} msg
 */
export function nodeFilter (msg) {
  const nodeObj = {
    101: '注册N分钟未登录',
  }
  if (!msg) return ''
  return nodeObj[msg]
}

/**
 * 环节
 * @param {*} msg
 */
export function segmentFilter (msg) {
  const segmentObj = {
    1: '注册后',
  }
  if (!msg) return ''
  return segmentObj[msg]
}

/**
 * 运营商
 */
export function ispFilter (msg) {
  const isp = ['未知', '移动', '联通', '电信']
  if (!msg) return ''
  let arr = (msg + '').split(',')
  let arr1 = arr.map((item) => isp[item])
  return arr1 + ''
}
/**
 * 平台名称
 */
export function platformFilter (msg) {
  const obj = {
    1: '花钱无忧',
    2: '大圣钱包',
    3: '无忧钱包',
    4: '贷款王',
    8: '立即借',
  }
  if (!msg) return ''
  return obj[msg]
}

// 金额过滤器，将单位为分的转化为元
export const amount = (num, len = 2) => {
  // 分转化为元
  let res = (Number(num) || 0) / 100
  return Math.round(res * Math.pow(10, len)) / Math.pow(10, len)
}