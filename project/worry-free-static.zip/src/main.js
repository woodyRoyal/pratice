// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import ElementUI from 'element-ui'
import { MessageBox } from 'element-ui'
import { Message } from 'element-ui';
// import 'element-ui/lib/theme-default/index.css'
import 'element-ui/lib/theme-chalk/index.css'
import NProgress from 'nprogress' // Progress 进度条
import 'nprogress/nprogress.css'// Progress 进度条 样式
import 'normalize.css/normalize.css'// normalize.css 样式格式化
import 'styles/index.scss' // 全局自定义的css样式
import * as filters from './filters' // 全局vue filter
// import vueWaves from './directive/waves'// 水波纹指令
import errLog from 'store/errLog'// error log组件
import VueClipboard from 'vue-clipboard2' // 复制到剪贴板
import Cookies from 'js-cookie'
import { getQueryString } from 'utils/index'

// import './mock/index.js'  // 该项目请求使用mockjs模拟
// register globally
Vue.use(ElementUI)
// Vue.use(vueWaves)
Vue.use(VueClipboard)

// register global utility filters.
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})
// 封装一个全局方法调用tips
Vue.prototype.$_message = function (config,type) {
  if(typeof config=='string') {
    let data = {
      showClose: true,
          message: config,
          type: type
        }
      Message(data)
    }
    if(typeof config=='object') {
      Message(config)
    }
  }
  Vue.prototype.$_message.error = function (config,type) {
    if(typeof config=='string') {
      let data = {
        showClose: true,
            message: config,
            type: 'error'
          }
        Message(data)
      }
      if(typeof config=='object') {
        Message(config)
      }
    }
    Vue.prototype.$_message.success = function (config,type) {
      if(typeof config=='string') {
        let data = {
          showClose: true,
              message: config,
              type: 'success'
            }
          Message(data)
        }
        if(typeof config=='object') {
          Message(config)
        }
      }
      Vue.prototype.$_message.warning = function (config,type) {
        if(typeof config=='string') {
          let data = {
            showClose: true,
                message: config,
                type: 'warning'
              }
            Message(data)
          }
          if(typeof config=='object') {
            Message(config)
          }
        }
  
Number.prototype.toFixed = function (s) {
  var times = Math.pow(10, s);
  var des = this * times + 0.5;
  des = parseInt(des, 10) / times;
  let myString = des.toString()
  if(myString.indexOf('.')<0) {
    return myString + '.00'
  } else {
    const ldot = myString.indexOf('.')
    const type = myString.substring(ldot+1,myString.length)
    if(type.length === 1) {
      return myString + '0'
    } else {
      return myString
    }
  }
  
  // if(myString.indexOf('.')<0) {
  //   return des + '.00'
  // } else if(){

  // } else {
  //   return des + ''
  // }
}

function hasRouter (routers, path) {
  if (path === '/') {
    return true
  }
  if (!routers) return true
  return routers.indexOf(path) >= 0
}

// 花钱无忧后台域名't1-admin.huaqianwy.com'
// 互金后台域名't1-managerdaikuan.2345.com'
//
// 花钱无忧后台域名 暂无
// 互金后台域名'managerdaikuan.2345.com'
// 域名不相同，从互金后台存的UC-Token和UC-Username获取不到，需要通过URL再获取并存到cookie中
let urlUsername = getQueryString('username')
let urlToken = getQueryString('token')
let ucToken = ''
let ucUsername = ''
if (!urlToken || !urlUsername) {
  ucToken = Cookies.get('UC-Token')
  ucUsername = Cookies.get('UC-Username')
  console.log('ucToken: ' + ucToken + ', ucUsername: ' + ucUsername)
} else {
  ucUsername = urlUsername
  ucToken = urlToken
  store.dispatch('ResetMsg')
  Cookies.set('UC-Token', ucToken)
  Cookies.set('UC-Username', ucUsername)
}


router.beforeEach((to, from, next) => {  
  NProgress.start() // 开启Progress
  // 每次路由的跳转，先检测ucUser、ucToken、ucUsername是否失效，失效后需要重新登录
  // if (process.env.NODE_ENV !== 'development') {
  if (process.env.NODE_ENV) {
    if (ucToken && ucUsername) {
      console.log('ucToken、ucUsername都存在')
    } else {
      console.log('路由跳转，检测到ucToken、ucUsername其中一个或多个失效')
      MessageBox.alert('用户信息已过期, 请重新登录', '提示', {
        confirmButtonText: '确定',
        type: 'warning',
        callback: action => {
          // 登出并返回到登录页
          window.location.href = process.env.UCENTER_API + '#/login'
        }
      })
      return false
    }
  }
  if (to.path === '/login') {
    window.location.href = process.env.UCENTER_API + '#/login'
  } else {
    if (store.getters.token) { // 判断是否有token
      if (store.getters.addRouters.length === 0) { // 判断当前用户是否已有可访问的路由表
        const menuList = store.getters.menuList
        store.dispatch('GenerateRoutes', {menuList}).then(() => { // 生成可访问的路由表
          router.addRoutes(store.getters.addRouters) // 动态添加可访问路由表
          if (store.getters.addRouters.length === 0) {
            next()
          } else {
            next(to.path) // hack方法 确保addRoutes已完成
          }
        })
      } else {
        // 没有动态改变权限的需求可直接next() 删除下方权限判断
        if (hasRouter(store.getters.menuPathList, to.path)) {
          next()
        } else {
          if (/^preview-data|channelDetail|pushConfig|planMsgConfig|$/.test(to.path)) {
            next()
          } else {
            next({ path: '/home/index' })
          }
        }
      } 
    } else { // 无token
      let user = {
        username: ucUsername,
        token: ucToken
      }
      store.dispatch('LoginByUsernameAndToken', {user}).then(res => {
        if (res) {
          MessageBox.alert(res, '提示', {
            confirmButtonText: '确定',
            type: 'warning',
            callback: action => {
              // todo 登出并返回到登录页
              window.location.href = process.env.UCENTER_API + '#/login'
            }
          })
          return false
        } else {
          next({
            path: '/home/index',
            // query: {redirect: to.fullPath}  // 将跳转的路由path作为参数，登录成功后跳转到该路由
          })
        }
      }).catch(err => {
        console.log(err)
      })
    }
  }
  NProgress.done() // 在hash模式下 改变手动改变hash 重定向回来 不会触发afterEach 暂时hack方案 ps：history模式下无问题，可删除该行！
})

router.afterEach(() => {
  NProgress.done() // 结束Progress
})

// window.onunhandledrejection = e => {
//     console.log('unhandled', e.reason, e.promise);
//     e.preventDefault()
// };

// 生产环境错误日志
if (process.env === 'production') {
  Vue.config.errorHandler = function (err, vm) {
    console.log(err, window.location.href)
    errLog.pushLog({
      err,
      url: window.location.href,
      vm
    })
  }
}

// window.onerror = function (msg, url, lineNo, columnNo, error) {
//   console.log('window')
//   console.log(msg)
// }
//
// console.error = (function (origin) {
//   return function (errorlog) {
//     // handler();//基于业务的日志记录及数据报错
//     console.log('console' + errorlog)
//     origin.call(console, errorlog)
//   }
// })(console.error)

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
