/* 本地测试环境 */
module.exports = {
  NODE_ENV: '"development"',
  DOWN_URL: '"http://dev-img.huaqianwy.com"',
  // BASE_API: '"http://dev-admin.huaqianwy.com/api/mc"',
  // BASE_API: '"http://d1-admin.huaqianwy.com/api/mc"',
  BASE_API: '"/api/mc"',
  // BASE_API: '"http://172.17.16.167:8091/mc"', // 欧阳金生
  // BASE_API: '"http://172.17.16.114:8091/mc"', // 何波
  // BASE_API: '"http://172.17.16.169:8091/mc"',
  // UCENTER_SERVER_API: '"http://t1-managerdaikuan.2345.com/ucenter-server/userCenter/"', // 用户中心服务端地址
  UCENTER_SERVER_API: '"/ucenter-server/userCenter/"', // 用户中心服务端地址
  // UCENTER_API: '"http://t1-managerdaikuan.2345.com/ucenter/"' // 用户中心前端地址
  UCENTER_API: '"/ucenter/"' // 用户中心前端地址
}
