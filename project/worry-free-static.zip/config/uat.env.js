/*
 * 线上测试环境
 * 花钱无忧后台域名：http://t1-admin.huaqianwy.com/
 * 互金后台域名：http://t1-managerdaikuan.2345.com/
 * 不同域名时需写明
 * */
module.exports = {
  NODE_ENV: '"uat"',
  DOWN_URL: '"http://t1-img.huaqianwy.com"',
  BASE_API: '"/api/mc"',
  UCENTER_SERVER_API: '"http://t1-managerdaikuan.2345.com/ucenter-server/userCenter/"', // 互金后台服务端地址
  UCENTER_API: '"http://t1-managerdaikuan.2345.com/ucenter/"' // 互金后台前端地址
}
