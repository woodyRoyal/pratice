/*
 * 线上生产环境
 * 互金后台域名：https://managerdaikuan.2345.com
 * 不同域名时需写明
 * */
module.exports = {
  NODE_ENV: '"production"',
  DOWN_URL: '"http://img.huaqianwy.com/wfree_upload"',
  BASE_API: '"/api/mc"',
  UCENTER_SERVER_API: '"https://managerdaikuan.2345.com/ucenter-server/userCenter/"', // 互金后台服务端地址
  UCENTER_API: '"https://managerdaikuan.2345.com/ucenter/"' // 互金后台前端地址
}
