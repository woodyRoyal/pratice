### Install iView

Using npm:
```
npm install hyapp-ui --save
```

### 组件示例打包
```
npm run dist:examples
```

### 组件使用文档打包
```
npm run docs:build
```

### 打包上传
看gitlab note
