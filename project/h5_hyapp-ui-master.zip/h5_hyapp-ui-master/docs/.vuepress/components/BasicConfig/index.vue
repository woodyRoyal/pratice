<template>
    <div>
        basic-config 配置参考
    </div>
</template>

<script>
export default {

}
</script>

