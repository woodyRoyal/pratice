# 发布日志

### <span style="color: #22ab28;">V2.4.5</span>

---

#### input

-   <demos-label>feature</demos-label>新增 input 组件

### <span style="color: #22ab28;">V2.3.8</span>

---

#### textarea

-   <demos-label>feature</demos-label>新增 textarea 组件

### <span style="color: #22ab28;">V2.3.5</span>

---

#### picker

-   <demos-label>feature</demos-label>新增 picker 组件

### <span style="color: #22ab28;">V2.3.4</span>

---

#### address

-   <demos-label>feature</demos-label>移除默认地址，如需使用，手动引入 <span style="color: #900;">city.json</span>

### <span style="color: #22ab28;">V2.3.2</span>

---

#### scratch-card

-   <demos-label>feature</demos-label>新增刮刮卡组件

### <span style="color: #22ab28;">V2.3.1</span>

---

#### actionSheet

-   <demos-label type="fix">fix</demos-label>修复不支持 hyapp-header 插槽问题

### <span style="color: #22ab28;">V2.3.0</span>

---

#### address

-   <demos-label>feature</demos-label>新增地址组件

#### date-picker

-   <demos-label>feature</demos-label>新增日期组件

#### swiper

-   <demos-label>feature</demos-label>新增 swiper 组件
