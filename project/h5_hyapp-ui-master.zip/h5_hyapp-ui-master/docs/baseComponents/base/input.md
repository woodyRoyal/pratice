# input

##### [demo 原始链接](http://172.17.16.112:8888/examples/#/from-input) | [demo 源码](http://172.16.0.245:2345/Finance_H5/H5_hyapp-ui/blob/develop/examples/routers/from-input.vue) | [组件源码](http://172.16.0.245:2345/Finance_H5/H5_hyapp-ui/tree/develop/src/packages/from-input)

---

> 最低兼容版本：**2.4.6**

## 安装

局部注册

```js{1,5}
import { HyFromInput } from 'hyapp-ui'

export default {
    components: {
        HyFromInput
    }
}
```

## 使用

### VUE

```vue
<!-- 引入组件 -->
<HyFromInput :type="'tel'" @checkHandler="checkHandler" v-model="form.mobilePhone" :validate="validate.mobilePhone" :maxLength="11" :placeholder="'请填写真实有效的手机号'"></HyFromInput>
<HyFromInput :type="'tel'" @checkHandler="checkHandler" v-model="form.code" :validate="validate.code" :maxLength="6" :placeholder="'请填写短信验证码'">
            <HyButton class="getSmsCode">获取验证码</HyButton>
        </HyFromInput>
<HyFromInput :type="'tel'" label="工号" @checkHandler="checkHandler" :blurHasError="true" v-model="form.jobNumbe" :validate="validate.jobNumbe" :maxLength="4" :placeholder="'请填写4位工号'"></HyFromInput>
<HyButton style="margin-top:30px">登录{{isCheck}}</HyButton>
```

### JS

```js
export default {
    data() {
        return {
            form: {
                mobilePhone: '',
                code: '',
                jobNumbe: ''
            },
            validate: {
                // 校验
                mobilePhone: {
                    name: 'mobilePhone', // 校验的key必须和v-model一致
                    rule: /^((\+?86)|(\(\+86\)))?1[3,4,5,6,7,8,9]\d{9}$/, // 校验的规则
                    message: '请输入合法的手机号码', // 错误的提示
                    trigger: ['change'], // 触发校验的时机
                    isCheck: false // 校验是否通过，true 通过
                },
                code: {
                    name: 'code',
                    rule: /^\d{6}$/,
                    message: '请输入有效的验证码',
                    trigger: ['change'],
                    isCheck: false
                },
                jobNumbe: {
                    name: 'jobNumbe',
                    rule: /^\d{4}$/,
                    message: '请填写4位工号',
                    trigger: ['change'],
                    isCheck: false
                }
            }
        }
    },
    methods: {
        checkHandler(options) {
            this.validate[options.name].isCheck = options.isCheck
        }
    },
    computed: {
        isCheck() {
            return Object.values(this.validate).every(v => v.isCheck)
        }
    }
}
```

## 属性

| 属性             | 类型    | 默认值  | 说明                                    | 版本要求 |
| ---------------- | ------- | ------- | --------------------------------------- | -------- |
| value            | String  | 空      | v-model 必须是对象数据                  |          |
| label            | String  | 空      | 填写的说明                              |
| maxLength        | Number  | 10      | 最大的填写字数                          |
| type             | String  | text    | input 类型                              |
| placeholder      | String  | 空      | 描述                                    |
| validate         | Object  | 空      | 必填项                                  |
| blurHasError     | Boolean | false   | 校验不通过是否在 input 下方展示错误信息 |
| hasErrorColor    | String  | red     | 错误提示的颜色                          |
| borderrColor     | String  | #e6e6e6 | 默认 input 边框的颜色                   |
| blurBorderrColor | String  | #ff601a | 得到焦点后 input 边框的颜色             |
| isBorderBottom   | String  | #ff601a | 得到焦点后 input 边框的颜色             |
| caretColor       | String  | #ff601a | 光标色                                  |
| isCheck          | Boolean | false   | 是否通过校验                            |

-   validate 说明

```js
validate: {
    // 校验
    mobilePhone: {
        name: 'mobilePhone',
        rule: /^((\+?86)|(\(\+86\)))?1[3,4,5,6,7,8,9]\d{9}$/,
        message: '请输入合法的手机号码',
        trigger: ['change'],
        isCheck: false
    },
    code: {
        name: 'code',
        rule: /^\d{6}$/,
        message: '请输入有效的验证码',
        trigger: ['change'],
        isCheck: false
    },
    jobNumbe: {
        name: 'jobNumbe',
        rule: /^\d{4}$/,
        message: '请填写4位工号',
        trigger: ['change'],
        isCheck: false
    }
}
```

## 事件

| 名字          | 参数 | 说明           | 版本要求 |
| ------------- | ---- | -------------- | -------- |
| @checkHandler | --   | 改变校验的结果 |

## 发布日志

-   [V2.4.6](/baseComponents/base/_changelog.html#v2-4-6) 新增 input 组件
