# hyapp-utils

> 手动初始化从 **2.0.3** 版本开始支持

## 安装

使用 `npm` 直接安装或者更新

```
npm install hyapp-utils --save
```

## 代码示例

### main.js 中调用

#### 自动初始化 jsBridge

---

```js
import hyapp from 'hyapp-utils'

Vue.use(hyapp.Tools)
```

#### 手动初始化 jsBridge

---

```js
import hyapp from 'hyapp-utils'

Vue.use(hyapp.ToolsManual)

// 手动初始化jsBridge，初始化完成执行回调
window.setupWebViewJavascriptBridge(bridge => {
    callback(bridge) // jsBridge初始化完成回调
})
```

## 暴露方法及使用

### 提供方法

---

```js
Vue.prototype.$appInvoked = appInvoked // 调用jsbridge方法
Vue.prototype.$appGetInvoked = appGetInvoked // 注册jsbrige方法
Vue.prototype.$needRefreshData = needRefreshData // 刷新机制
Vue.prototype.$lodash = lodash // 暴露lodash
```

### 项目中使用

---

```js
this.$appInvoked(funcName, jsonParams, () => {})
this.$appGetInvoked(funcName, rst => {})
this.$needRefreshData(lasttime)
this.$lodash.Function()
```

## 监控 Sdk 接入

### 在 errorLog.js 中引入依赖，并调用(最终引入 mian.js)

-   因为需要配合 vue 使用，推荐单独创建一个 errorLog.js 来做配置，方便管理和移植

```js
import Vue from 'vue'

import hyapp from 'hyapp-utils'

if (process.env.NODE_ENV === 'production') {
    hyapp.ErrorCatch.init(data => {
        // 异步调用上报，不阻塞业务代码加载
        setTimeout(() => {})
    })

    // 资源加载错误上报
    hyapp.ErrorResource.init(data => {
        // 异步调用上报，不阻塞业务代码加载
        setTimeout(() => {})
    })

    // 接口异常上报
    hyapp.XhrHook.init(data => {
        // 异步调用上报，不阻塞业务代码加载
        setTimeout(() => {})
    })
    Vue.config.errorHandler = (err, vm, info, a) => {
        // 异步调用上报，不阻塞业务代码加载
        setTimeout(() => {})
    }
}
```

### main.js 中调用（不推荐）

```js
import hyapp from 'hyapp-utils'

// js错误上报
hyapp.ErrorCatch.init(data => {
    // 调用上报
})

// 资源加载错误上报
hyapp.ErrorResource.init(data => {
    // 调用上报
})

// 接口异常上报
hyapp.XhrHook.init(data => {
    // 调用上报
})
```

## ErrorCatch data 属性说明

| 属性           | 类型   | 说明               | 版本要求 |
| -------------- | ------ | ------------------ | -------- |
| col            | Number | 报错的行           |          |
| row            | Number | 报错的列           |          |
| content        | String | 堆栈信息           |          |
| message        | String | 报错的描述         |          |
| name           | String | 名字               |          |
| resourceUrl    | String | 报错的 js 文件     |          |
| type           | String | 类型               |          |
| userAgent      | String | userAgent          |          |
| \_columnNumber | String | 堆栈报错的行       |          |
| \_errorMessage | String | 堆栈报错的描述     |          |
| \_lineNumber   | String | 堆栈报错的列       |          |
| \_route        | String | 当前页面           |          |
| \_scriptURI    | String | 堆栈报错的 js 文件 |          |

::: tip ErrorCatch 说明
无法监控.vue 报错的异常(即使打包后 vue 文件全部编译成 .js 文件),因为 vue 内部上层已经拦截过，到 window.onerror 就无法捕捉
解决方法通过 vue 提供的 errorHandler
:::

## ErrorResource data 属性说明

| 属性          | 类型   | 说明             | 版本要求 |
| ------------- | ------ | ---------------- | -------- |
| downlink      | String | 估算的下行速度   |          |
| effectiveType | String | 估算的往返时间   |          |
| message       | String | 错误描述         |          |
| outerHTML     | String | 引入源码         |          |
| route         | String | 当前页面         |          |
| rtt           | String | 有效网络连接类型 |          |
| type          | String | 类型             |          |
| userAgent     | String | userAgent        |          |
| url           | String | 资源地址         |          |

## XhrHook data 属性说明

| 属性         | 类型    | 说明                                                             | 版本要求 |
| ------------ | ------- | ---------------------------------------------------------------- | -------- |
| duration     | String  | 请求响应时间                                                     |          |
| event        | String  | 事件类型 load->页面加载完成 error->ajax 内部错误 abort->请求取消 |          |
| method       | String  | 请求的类型                                                       |          |
| requestData  | String  | 请求的入参                                                       |          |
| requestSize  | Number  | 请求参数的长度                                                   |          |
| responseSize | Number  | 响应参数的长度                                                   |          |
| route        | String  | 当前页面                                                         |          |
| status       | boolean | 状态码                                                           |          |
| type         | String  | 类型                                                             |          |
| url          | String  | 接口地址                                                         |          |
| userAgent    | String  | userAgent                                                        |          |

::: tip XhrHook 说明
只上报异常的接口
:::

::: tip lodash 使用说明
lodash 使用参照[lodash 使用说明](https://www.lodashjs.com/docs/latest)
:::
