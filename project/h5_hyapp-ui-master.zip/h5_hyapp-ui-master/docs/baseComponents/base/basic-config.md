# basic-config 配置参考

<Common-Democode title="基本用法" description="配置参考">
  <BasicConfig-index></BasicConfig-index>
  <highlight-code slot="codeText" lang="vue">
    <template>
      <div>
         basic-config 配置参考 
      </div>
    </template>
  </highlight-code>
</Common-Democode>
