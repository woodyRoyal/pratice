<template>
    <div>
        <hy-button :styleSwitch="true" :buttonColor="'#f00'"></hy-button>
    </div>
</template>
<script>
    export default {
        methods: {
            hc (data) {
                console.log(data);
            }
        }
    };
</script>
<style>
</style>
