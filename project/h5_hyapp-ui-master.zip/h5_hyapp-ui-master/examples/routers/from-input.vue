<template>
    <div>
        <HyFromInput :type="'tel'"
                     @checkHandler="checkHandler"
                     v-model="form.mobilePhone"
                     :validate="validate.mobilePhone"
                     :maxLength="11"
                     :placeholder="'请填写真实有效的手机号'"></HyFromInput>
        <HyFromInput :type="'tel'"
                     @checkHandler="checkHandler"
                     v-model="form.code"
                     :validate="validate.code"
                     :maxLength="6"
                     :placeholder="'请填写短信验证码'">
            <HyButton class="getSmsCode">获取验证码</HyButton>
        </HyFromInput>
        <HyFromInput :type="'tel'"
                     label='工号'
                     @checkHandler="checkHandler"
                     :blurHasError="true"
                     v-model="form.jobNumbe"
                     :validate="validate.jobNumbe"
                     :maxLength="4"
                     :placeholder="'请填写4位工号'"></HyFromInput>
        <HyButton style="margin-top:30px">登录{{isCheck}}</HyButton>
    </div>
</template>

<script type="text/ecmascript-6">
export default {
    data () {
        return {
            form: {
                mobilePhone: '',
                code: '',
                jobNumbe: '',
            },
            validate: { // 校验
                mobilePhone: {
                    name: 'mobilePhone',
                    rule: /^((\+?86)|(\(\+86\)))?1[3,4,5,6,7,8,9]\d{9}$/,
                    message: '请输入合法的手机号码',
                    trigger: ['change'],
                    isCheck: false,
                },
                code: {
                    name: 'code',
                    rule: /^\d{6}$/,
                    message: '请输入有效的验证码',
                    trigger: ['change'],
                    isCheck: false,
                },
                jobNumbe: {
                    name: 'jobNumbe',
                    rule: /^\d{4}$/,
                    message: '请填写4位工号',
                    trigger: ['change'],
                    isCheck: false,
                }
            },
        };
    },
    methods: {
        // 检验信息
        checkHandler (options) {
            this.validate[options.name].isCheck = options.isCheck;
        },
    },
    computed: {
        isCheck () {
            return Object.values(this.validate).every(v => v.isCheck);
        },
    },
};
</script>

<style lang="less" scoped>
.getSmsCode {
  width: 30%;
}
</style>
