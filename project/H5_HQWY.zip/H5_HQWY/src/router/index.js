import Vue from 'vue'
import Router from 'vue-router'
import userData from './userData'
import openAccount from './openAccount'
import mine from './mine'
// import loan from './loan'
// import order from './order'
import ljj from './ljj'

Vue.use(Router)
Router.prototype.goBack = function () {
  this.isBack = true
  window.history.go(-1)
}

const router = new Router({
  routes: [
    {
      path: '/home',
      component: (resolve) => require.ensure([], () => resolve(require('../views/home.vue')), 'home'),
      meta: {
        title: '首页',
      },
      children: [
        //首页
        {
          path: '/',
          name: 'index',
          component: (resolve) => require.ensure([], () => resolve(require('../views/index.vue')), 'index'),
          meta: {
            title: '首页',
          },
        },
        //贷款大全
        {
          path: '/productlist',
          name: 'productlist',
          component: (resolve) => require.ensure([], () => resolve(require('../views/productlist.vue')), 'productlist'),
          meta: {
            title: '贷款大全',
          },
        },
        {
          path: '/guessborrow',
          name: 'guessborrow',
          component: (resolve) => require.ensure([], () => resolve(require('../views/guessBorrow.vue')), 'guessborrow'),
          meta: {
            title: '猜你可贷',
            mescroll: true,
          },
        },
        {
          path: '/mycenter',
          name: 'mycenter',
          component: (resolve) => require.ensure([], () => resolve(require('../views/mycenter.vue')), 'mycenter'),
          meta: {
            title: '我的',
            mescroll: true,
          },
        },
      ],
    },
    //商品分类列表
    {
      path: '/prolist',
      name: 'prolist',
      component: (resolve) => require.ensure([], () => resolve(require('../views/prolist.vue')), 'prolist'),
      meta: {
        keepAlive: true,
      },
    },
    //我的优惠券
    {
      path: '/mycoupon',
      name: 'mycoupon',
      component: (resolve) => require.ensure([], () => resolve(require('../views/mycoupon.vue')), 'mycoupon'),
      meta: {
        title: '我的优惠券',
      },
    },
    //智能推荐，信息填写
    {
      path: '/fillinfo',
      name: 'fillinfo',
      component: (resolve) => require.ensure([], () => resolve(require('../views/fillinfo.vue')), 'fillinfo'),
      meta: {
        title: '智能推荐',
      },
    },
    //完善贷款信息
    {
      path: '/loanInfo',
      name: 'loanInfo',
      component: (resolve) => require.ensure([], () => resolve(require('../views/loanInfo.vue')), 'loanInfo'),
      meta: {
        title: '完善贷款信息',
      },
    },
    //关于我们
    {
      path: '/aboutUs',
      name: 'aboutUs',
      component: (resolve) => require.ensure([], () => resolve(require('../views/aboutUs.vue')), 'aboutUs'),
      meta: {
        title: '关于我们',
      },
    },
    //浏览记录
    {
      path: '/browseRecord',
      name: 'browseRecord',
      component: (resolve) => require.ensure([], () => resolve(require('../views/browseRecord.vue')), 'browseRecord'),
      meta: {
        title: '浏览记录',
      },
    },
    // 为你推荐
    {
      path: '/recommendlist',
      name: 'recommendList',
      component: (resolve) => require.ensure([], () => resolve(require('../views/recommendList1')), 'recommendList'),
      meta: {
        title: '为您推荐',
      },
    },
    // 为你推荐1
    {
      path: '/recommendList1',
      name: 'recommendList1',
      component: (resolve) => require.ensure([], () => resolve(require('../views/recommendList')), 'recommendList1'),
      meta: {
        title: '为您推荐',
      },
    },
    //用户服务协议
    {
      path: '/userServiceAgreement',
      name: 'userServiceAgreement',
      component: (resolve) => require.ensure([], () => resolve(require('../views/userServiceAgreement')), 'userServiceAgreement'),
      meta: {
        title: '用户服务协议',
      },
    },
    // 隐私政策
    {
      path: '/yszc',
      name: 'yszc',
      component: (resolve) => require.ensure([], () => resolve(require('../views/yszc')), 'yszc'),
      meta: {
        title: '隐私政策',
      },
    },
    {
      path: '/',
      redirect: '/home',
    },
    {
      path: '/productDetail/:category/:prdId',
      name: 'productDetail',
      component: (resolve) => require.ensure([], () => resolve(require('../views/productDetail.vue')), 'productDetail'),
      meta: {
        title: '产品详情',
      },
    },
    {
      path: '/productDetailBlank/:category/:prdId',
      name: 'productDetailBlank',
      component: (resolve) => require.ensure([], () => resolve(require('../views/product/blank.vue')), 'productDetailBlank'),
      meta: {
        title: '产品详情',
      },
    },
    {
      // 撞库页
      path: '/loanHit',
      name: 'loanHit',
      component: (resolve) => require.ensure([], () => resolve(require('../views/product/loanHit.vue')), 'loanHit'),
      meta: {
        title: '加载中',
      },
    },
    {
      // 审核中页面
      path: '/inAudit',
      name: 'inAudit',
      component: (resolve) => require.ensure([], () => resolve(require('../views/product/inAudit.vue')), 'inAudit'),
      meta: {
        title: '订单审核中',
      },
    },
    {
      // APP跳转详情页面
      path: '/appToProduct',
      name: 'appToProduct',
      component: (resolve) => require.ensure([], () => resolve(require('../views/product/appToProduct.vue')), 'appToProduct'),
      meta: {
        title: '',
      },
    },
    {
      // 登录
      path: '/login',
      name: 'login',
      component: (resolve) => require.ensure([], () => resolve(require('../views/login/index.vue')), 'login'),
      meta: {
        title: '登录',
      },
    },
    {
      // 注册
      path: '/register',
      name: 'register',
      component: (resolve) => require.ensure([], () => resolve(require('../views/register/index.vue')), 'register'),
      meta: {
        title: '注册',
      },
    },
    // {
    //   // 忘记密码 验证手机号
    //   path: '/validateMobile/:type',
    //   name: 'validateMobile',
    //   component: (resolve) => require.ensure([], () => resolve(require('../views/register/index.vue')), ''),
    //   meta: {
    //     title: '验证手机号',
    //   },
    // },
    {
      path: '/setPassword/:serialNumber/:mobilePhone/:code',
      name: 'setPassword',
      component: (resolve) => require.ensure([], () => resolve(require('../views/setPassword/index.vue')), 'setPassword'),
      meta: {
        title: '设置密码',
      },
    },
    // 信用卡
    {
      path: '/creditCardHome',
      name: 'creditCardHome',
      component: (resolve) => require.ensure([], () => resolve(require('../views/creditCard/home.vue')), 'creditCardHome'),
      meta: {
        title: '信用卡',
        mescroll: true,
      },
    },
    // 信用卡大全
    {
      path: '/creditCardList',
      name: 'creditCardList',
      component: (resolve) => require.ensure([], () => resolve(require('../views/creditCard/list.vue')), 'creditCardList'),
      meta: {
        title: '信用卡大全',
        mescroll: true,
      },
    },
    // 信用卡进度查询
    {
      path: '/creditCardProgress',
      name: 'creditCardprogress',
      component: (resolve) => require.ensure([], () => resolve(require('../views/creditCard/progress.vue')), 'creditCardprogress'),
      meta: {
        title: '信用卡大全',
        mescroll: true,
      },
    },
    // 通用公告页
    {
      path: '/notice',
      name: 'notice',
      component: (resolve) => require.ensure([], () => resolve(require('../views/notice.vue')), 'notice'),
      meta: {
        title: '公告',
        mescroll: true,
      },
    },
    ...userData, // 开户用户信息相关
    ...openAccount, // 开户流程
    ...mine, // 我的订单
    // ...loan, // API全流程--借款
    // ...order, // 订单页面
    ...ljj, // 立即借特有页面
  ],
})

router.afterEach((to, from) => {
  if (to.meta.title) {
    document.title = to.meta.title
  }
  if (to.path.indexOf('prolist') > -1 || from.path.indexOf('prolist') > -1) {
    return
  }
  !from.meta.title || window.vm.$appInvoked('appOnPageEnd', { pageName: from.meta.title })
  !to.meta.title || window.vm.$appInvoked('appOnPageBegin', { pageName: to.meta.title })
})

export default router
