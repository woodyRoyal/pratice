export default [
  // {
  //   path: '/order',
  //   name: 'order',
  //   component: (resolve) => require.ensure([], () => resolve(require('@/views/mine/myOrder')), 'order'),
  //   meta: {
  //     title: '我的订单',
  //   },
  // },
  {
    path: '/fillLoanInfo',
    name: 'fillLoanInfo',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/mine/fillLoanInfo')), 'fillLoanInfo'),
    meta: {
      title: '完善贷款信息',
    },
  },
  {
    path: '/myMore',
    name: 'myMore',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/mine/myMore')), 'myMore'),
    meta: {
      title: '更多',
    },
  },
  // {
  //   path: '/orderDetail',
  //   name: 'orderDetail',
  //   component: (resolve) => require.ensure([], () => resolve(require('@/views/order/orderDetail')), 'orderDetail'),
  //   meta: {
  //     title: '订单详情',
  //   },
  // },
  {
    path: '/myBankList',
    name: 'myBankList',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/bankPage/bankList.vue')), 'myBankList'),
    meta: {
      title: '我的银行卡',
    },
  },
  // {
  //   /**
  //  productId: this.$route.query.productId,//产品Id
  //  applyNo: this.$route.query.applyNo,//进件订单编号
  //  loanNo: this.$route.query.loanNo,//借款订单号
  //  stage: this.$route.query.stage //1：借款阶段 2：还款阶段
  //  */
  //   path: '/addBank',
  //   name: 'addBank',
  //   component: (resolve) => require.ensure([], () => resolve(require('@/views/bankPage/addBank.vue')), 'addBank'),
  //   meta: {
  //     title: '添加银行卡',
  //   },
  // },
]
