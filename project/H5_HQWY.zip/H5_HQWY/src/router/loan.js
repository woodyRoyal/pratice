export default [
  {
    path: '/loan/inAudit',
    name: 'loanInAudit',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/loan/inAudit.vue')), 'loanInAudit'),
    meta: {
      title: '审核中',
    },
  },
  {
    path: '/loan/auditResult',
    name: 'loanAuditResult',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/loan/auditResult.vue')), 'loanAuditResult'),
    meta: {
      title: '放款结果',
    },
  },
  {
    path: '/loan/submitOrder',
    name: 'loanSubmitOrder',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/loan/submitOrder.vue')), 'loanSubmitOrder'),
    meta: {
      title: '待提交订单',
    },
  },
  {
    path: '/loan/confirmLoan',
    name: 'loanConfirmLoan',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/loan/confirmLoan.vue')), 'loanConfirmLoan'),
    meta: {
      title: '待确认用款',
    },
  },
  {
    path: '/loan/onLoan',
    name: 'loanOnLoan',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/loan/onLoan.vue')), 'loanOnLoan'),
    meta: {
      title: '放款中',
    },
  },
  {
    path: '/order-periodDetail',
    name: 'order-periodDetail',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/order/periodDetail.vue')), 'orderPeriodDetail'),
    meta: {
      title: '当期详情',
    },
  },
]
