export default [
  {
    path: '/order/periodDetail',
    name: 'orderPeriodDetail',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/order/periodDetail.vue')), 'orderPeriodDetail'),
    meta: {
      title: '当期详情',
    },
  },
  {
    path: '/order/detail',
    name: 'orderDetail',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/order/orderDetail')), 'orderDetail'),
    meta: {
      title: '订单详情',
    },
  },
  {
    path: '/order/repayResult',
    name: 'repayResult',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/order/repayResult.vue')), 'orderRepayResult'),
    meta: {
      title: '还款结果',
    },
  },
]
