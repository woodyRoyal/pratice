export default [
  {
    path: '/ljj/updateNoticeDetail',
    name: 'updateNoticeDetail',
    component: (resolve) => require.ensure([], () => resolve(require('../profiles/ljj/views/updateNoticeDetail.vue')), 'ljj/updateNoticeDetail'),
    meta: {
      title: '公告详情',
      mescroll: true,
    },
  },
]
