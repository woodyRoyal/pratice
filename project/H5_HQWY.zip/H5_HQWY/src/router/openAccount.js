export default [
  {
    path: '/identityAuth',
    name: 'identityAuth',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/openAccount/identityAuth.vue')), 'identityAuth'),
    meta: {
      title: '身份认证',
    },
  },
  {
    path: '/emergencyContact',
    name: 'emergencyContact',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/openAccount/emergencyContact.vue')), 'emergencyContact'),
    meta: {
      title: '紧急联系人',
    },
  },
  {
    path: '/otherInfo',
    name: 'otherInfo',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/openAccount/otherInfo.vue')), 'otherInfo'),
    meta: {
      title: '补充信息',
    },
  },
  {
    path: '/checkResult',
    name: 'checkResult',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/openAccount/checkResult.vue')), 'checkResult'),
    meta: {
      title: '审核结果',
    },
  },
]
