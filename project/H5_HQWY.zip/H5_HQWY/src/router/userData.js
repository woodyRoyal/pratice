export default [
  {
    path: '/basicInfo',
    name: 'basicInfo',
    component: (resolve) => require.ensure([], () => resolve(require('@/views/userData/basicInfo')), 'basicInfo'),
    meta: {
      title: '基础信息',
    },
  },
]
