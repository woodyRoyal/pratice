import { config } from '{APP_PROFILE}/config/index'
import * as merge from 'lodash.merge'
// import * as _env from '@/assets/js/util/env'

const validEnvNames = ['t1', 't2', 't3', 'd1', 'd2', 'dev', 'prod']

function _implementFallback (config) {
  void ['t1', 't2', 't3', 'd1', 'd2'].forEach((item) => {
    config[item] = merge({}, config.test, config[item])
  })

  // dev -> ??
  const _options = config._options || {}
  const devFallbackTo = _options.devFallbackTo || 't1'
  config.dev = merge({}, config[devFallbackTo], config.dev)

  // * -> base
  validEnvNames.forEach((item) => {
    config[item] = merge({}, config.base, config[item])
  })

  return config
}

function _implementVariable (val, variableConfig) {
  if (!/{[-\w]+}/.test(val)) return val

  let varNames = Object.keys(variableConfig)
  varNames.forEach((varName) => {
    let varValue = variableConfig[varName]
    val = val.split(varName).join(varValue)
  })
  return val
}

export function get (configKey, specifiedEnv) {
  if (!configKey) return
  if (specifiedEnv && validEnvNames.indexOf(specifiedEnv) === -1) return
  let segments = configKey.split('.')
  if (!segments.length) return
  const allConfig = _implementFallback(config)
  const env = specifiedEnv || allConfig.base.env

  const currentConfig = allConfig[env]
  if (!currentConfig) return

  let result = currentConfig
  for (let i = 0; i < segments.length; i++) {
    let seg = segments[i]
    result = result[seg]
    if (!result) break
  }

  result = _implementVariable(result, currentConfig.variable)
  return result
}
