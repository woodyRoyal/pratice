/* eslint-disable camelcase */
import { requestClickReport, requestUserInfo } from '../api/controller/common'
import {
  loanEntryQueryApi,
  // getBasicInfoApi,
  // submitAuthStatusApi,
} from '../api/controller/openAccount/index'
import { collectEventApi } from '../api/controller/common'
// import eventCtr from "../../static/js/eventCtr"
import store from '../vuex/store'
let Mixins = {
  methods: {
    // 参数验签
    appSignParams (params, isJson, cb) {
      let p = ''
      if (isJson) {
        p = JSON.stringify(params)
      } else {
        // 参数排序
        let sortObj = (obj) => {
          var temArr = Object.getOwnPropertyNames(obj).sort(function (s1, s2) {
            let x1 = s1.toString().toLowerCase()
            let x2 = s2.toString().toLowerCase()
            return x1 < x2 ? -1 : x1 > x2 ? 1 : 0
          })
          var temObj = {}
          temArr.forEach(function (item) {
            if (obj[item]) {
              temObj[item] = obj[item]
            }
          })
          return temObj
        }
        params = sortObj(params)
        for (let i in params) {
          p += i + '=' + params[i] + '&'
        }
        p = p.slice(0, -1)
      }
      this.$appInvoked('appSignParams', { params: p }, (res) => {
        cb && cb(res)
      })
    },
    // toast弹框
    toast (msg) {
      this.$appInvoked('appToastMessage', { message: msg })
    },
    /**
     * 调用原生loading
     * @param {Number} type loading类型。1-钱包动画，2-转圈动画
     * @param {String} content type为2时，loading提示内容
     */
    loading (type = 1, content = '努力加载中...') {
      let params = { type }
      if (type === 2) {
        params.content = content
      }
      this.$appInvoked('appShowLoadingDialog', params)
    },
    // 关闭loading
    closeLoading (type = 1) {
      this.$appInvoked('appDismissLoadingDialog', { type })
    },
    // 判断对象是否为空
    isEmptyObject (obj) {
      for (let key in obj) {
        return false
      }
      return true
    },
    // 服务端上报埋点用
    clickReport (prdId, category, eventId, header = {}) {
      if (!eventId) {
        return
      }
      let additionHeader = {
        headers: {
          clickEvent: eventId,
          ...header,
        },
      }
      this.$appInvoked('appGetMobilephone', {}, (phone) => {
        // 如果手机号码为空证明未登录，此时不上报
        if (!phone || phone.length <= 0) {
          return
        }
        let requestParams = {
          category: category,
          mobilePhone: phone,
          productId: prdId,
          userId: store.state.baseInfo.headerInfo.userId,
        }
        if (isIos) {
          requestParams.idfa = store.state.baseInfo.headerInfo.idfa
        } else {
          requestParams.imei = store.state.baseInfo.headerInfo.imei
        }
        requestClickReport(requestParams, additionHeader)
      })
    },
    // 服务端事件埋点
    collectEventMD (params) {
      collectEventApi(params)
    },
    // 非产品点击，点击事件埋点（武林榜、TD、服务端）
    mdAll (eventId) {
      if (!eventId) {
        return
      }
      this.$appInvoked('appExecStatistic', { eventId: eventId });
      this.collectEventMD({
        eventId: eventId,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
      })
    },
    /**
     * 拦截原生物理返回键（安卓）
     *    每个页面activated时执行此方法，根据页面是否实现backClickHandle。
     *    若实现，则拦截物理返回键执行backClickHandle方法；若未实现，则执行原生默认返回
     * @param {Function} loginCb 登录回调
     *    打开登录弹窗时，拦截物理返回键；点击返回关闭登录弹窗，还原页面原本的物理返回键执行逻辑
     */
    interceptAppBack () {
      if (isIos) {
        return
      }
      let isMainPage = ['/home', '/productlist', '/guessborrow', '/mycenter'].indexOf(this.$route.path) > -1
      // let shouldNotifyBack = hasSetLeftHandle || isLoginCb
      this.$appInvoked('appSetNative', {
        shouldNotifyBack: !isMainPage,
      })
      if (isMainPage) {
        this.$appInvoked('appCleanWeb', { history: true })
      } else {
        this.$appGetInvoked('htmlBackPress', () => {
          if (typeof this.backClickHandle === 'function') {
            this.backClickHandle()
          } else {
            this.$routerGo(-1)
          }
        })
      }
    },
    // 先登录再执行操作
    needUserLogin (w, cb) {
      // 判断是否登录后执行回调
      let setLoginCb = (isLogin) => {
        if (isLogin) {
          cb && cb()
        } else {
          if (cb) {
            window.loginSuccessCallback = cb
          } else {
            window.loginSuccessCallback = null
          }
          this.collectEventMD({
            eventEndTime: '',
            eventId: 'jr1001',
            eventResult: 1,
            eventStartTime: new Date().getTime(),
            productId: '',
          })
          this.$routerPush(`/login?w=${w}&type=1`)
        }
      }
      if (isIos || isAndroid) {
        this.$appInvoked('appIsLogin', {}, (isLogin) => {
          setLoginCb(isLogin)
        })
      } else {
        let isLogin = false
        setLoginCb(isLogin)
      }
    },
    // 格式化产品列表
    formateProductList (list, page) {
      if (!list || list.length === 0) {
        return []
      }
      let redDotList = JSON.parse(localStorage.getItem('RED_DOT_DATA') || '[]') // 需展示小红点产品列表
      let needRedDot = false
      let noClickList = [] // 未点击产品列表
      if (page === 'zntjjgy' && Math.min(list.length, redDotList.length) > 0) {
        // 智能推荐结果页展示小红点
        needRedDot = true
        for (let i = 0; i < redDotList.length; i++) {
          if (!redDotList[i].check) {
            noClickList.push(redDotList[i].id)
          }
        }
      }
      for (let i = 0, l = list.length; i < l; i++) {
        let item = list[i]
        /**
         * 产品列表扩展字段说明（以 fm_ 开头）：
         *  fm_tipsIcon 补充描述模块图标。mxz：API产品免下载，ysq：已申请，tips：提示（默认）
         *  fm_applyTipsType 名额展示文言。
         *    0-严格控量，额度未满。“已申请45%”，并有进度条
         *    1-严格控量，额度已满，不隐藏。“明日开放申请”，产品整个置灰
         *    2-非严格控量。“23473已申请”，超过10万展示为“12.1万已申请
         */
        if (item.supportApiLoan) {
          // API产品
          list[i].fm_tipsIcon = 'mxz'
        } else if (item.blackListFlag) {
          // 黑名单
          list[i].fm_tipsIcon = 'hmd'
          list[i].bottomTip = '您的资质暂不符合机构借款要求'
        } else {
          // 文言类型。1-申请记录 2-特别提示 3-放款时间
          switch (item.bottomType) {
            case 1:
              list[i].fm_tipsIcon = 'sqjl'
              break
            case 2:
              list[i].fm_tipsIcon = 'tbts'
              break
            case 3:
              list[i].fm_tipsIcon = 'fksj'
              break
          }
        }
        // uvLimitFlag：是否严格控量。0-不严格控量,1-严格控量
        if (item.uvLimitFlag === 1) {
          list[i].fm_applyTipsType = item.fullFlag ? 1 : 0
        } else {
          list[i].fm_applyTipsType = 2
        }

        // 是否展示小红点
        if (needRedDot && noClickList.indexOf(item.id) > -1) {
          list[i].fm_showRedDot = true
        }
      }
      return list
    },
    /**
     * 智能推荐
     * @param {String} source 点击来源，默认为空。1-原生导航栏右上角智能推荐，2-资料填写页面挽留弹窗，重新智能推荐
     */
    globalRecommendClick (w = 1003, source) {
      let that = this
      // 点击智能推荐 重新调用城市方法
      this.$appInvoked('appExecLocation', {})
      this.needUserLogin(w, () => {
        // let career // career职业
        let borrowAmount // borrowAmount借多少
        let borrowPeriod // borrowPeriod借多久
        let creditScore // creditScore芝麻分
        let phoneUseTime // phoneUseTime手机号使用时长
        let creditCardFlag // creditCardFlag是否有信用卡
        let fundFlag // fundFlag是否缴纳公积金
        // 用户是否点击过：true-点击过，false-未点击
        let isFill = localStorage.getItem('isFill') ? 'true' : 'false'
        //获取用户有没有填写推荐信息
        requestUserInfo({}).then(
          (data) => {
            if (data.respCode === '1000') {
              data = data.body
              // career = data.career // 我是
              borrowAmount = data.borrowAmount // 借多少
              creditCardFlag = data.creditCardFlag // 是否有信用卡
              fundFlag = data.fundFlag // 是否缴纳公积金
              phoneUseTime = data.phoneUseTime // 手机号是否使用超过6个月
              borrowPeriod = data.borrowPeriod // 借多久
              creditScore = data.creditScore // 芝麻分
              // let totalNum = localStorage.getItem('redPointAll')
              // let redPointArr = localStorage.getItem('redPoint') ? localStorage.getItem('redPoint') : ''
              // let redNumber = totalNum - (redPointArr.split(',').length - 1)
              // if (redNumber != undefined && parseInt(redNumber) > 0) {
              //   redPrd = true
              // } else {
              //   redPrd = false
              // }
              let newArr = JSON.parse(localStorage.getItem('RED_DOT_DATA') || '[]')
              let num = 0
              for (let i = 0; i < newArr.length; i++) {
                if (!newArr[i].check) {
                  num++
                }
              }
              // let url = `/recommendList1?occupation=${career}&amount=${borrowAmount}&deadline=${borrowPeriod}&zhima=${creditScore}&creditCard=${creditCardFlag}&fund=${fundFlag}&phoneNumServiceTime=${phoneUseTime}&w=${w}`
              let url = `/recommendList1?amount=${borrowAmount}&deadline=${borrowPeriod}&zhima=${creditScore}&creditCard=${creditCardFlag}&fund=${fundFlag}&phoneNumServiceTime=${phoneUseTime}&w=${w}`
              if (source === '2') {
                that.$routerReplace(url)
              } else {
                // 用户填写完整
                // if (career !== null && borrowAmount !== null && borrowPeriod !== null && creditScore !== null && phoneUseTime !== null && creditCardFlag !== null && fundFlag !== null) {
                if (borrowAmount !== null && borrowPeriod !== null && creditScore !== null && phoneUseTime !== null && creditCardFlag !== null && fundFlag !== null) {
                  if (isFill === 'false' || num === 0) {
                    // 没有点击过“一键智能推荐”或者没有智能推荐结果页无小红点产品
                    url = `/fillinfo?w=${w}`
                  }
                } else {
                  // 用户未填写完整
                  url = `/fillinfo?w=${w}`
                }
                if (source === '1') {
                  that.$routerReplace(url)
                } else {
                  that.$routerPush(url)
                }
              }
            }
          }, () => {
            that.reloadText = {
              reloadText: '网络异常',
              defaultImg: this.getCachedImages('loadFailIcon'),
            }
            that.isShow = true
          }
        )
      })
    },
    // 打开帮助中心
    openHelpcenter (w, cb) {
      this.needUserLogin(w, () => {
        cb && cb()
        this.$appInvoked('appGetAjaxHeader', {}, (rst) => {
          this.$appInvoked('appOpenWebview', {
            url: `${window.$config.get('url.helpcenterHome')}&productId=${window.$config.get('productId')}&token=${rst.token}&version=${rst.version}`,
            enableBackHistory: true,
            nav: {
              title: {
                text: '帮助与反馈',
              },
            },
          })
        })
      })
    },

    // 判断下一项待填写资料
    checkNextFillInfos (w, source) {
      let self = this
      source = source || self.$route.query.source // 页面来源。0-我的>完善贷款信息，1-API产品详情，2-重新智能推荐
      if (source === '1') {
        self.$routerGo(-1)
        return
      }
      self.getNextFillInfos(w, source, (nextPage) => {
        if (nextPage === 'FINISH') {
          if (source === '2') {
            self.$routerReplace(`/fillInfo?sourcePage=FINISH&w=${w}`)
          } else {
            self.$routerGo(-1)
          }
        } else if (nextPage === 'ERROR') {
          console.log('ERROR')
          // } else if (nextPage === 'MOP') {
          //   self.fillMopInfo('', w, () => {
          //     self.checkNextFillInfos(w, source)
          //   })
        } else if (source === '2' && nextPage.indexOf('/basicInfo') > -1) {
          self.$routerPush(nextPage)
        } else {
          self.$routerReplace(nextPage)
        }
      })
    },
    /**
     * 获取下一个待填写资料项
     * @param {String} source 页面来源。0-我的>完善贷款信息，1-API产品详情，2-重新智能推荐
     * @param {Function} cb 回调
     */
    getNextFillInfos (w, source, cb) {
      if (source === '2') {
        let nameIdcardEditAll = localStorage.getItem('nameIdcardEditAll') === 'true'
        if (!nameIdcardEditAll) {
          cb && cb(`/basicInfo?source=${source}&w=${w}`)
          return
        }
      }
      this.loading()
      loanEntryQueryApi({ materialType: '' }).then(
        (data) => {
          this.closeLoading()
          if (data.respCode === '1000') {
            data = data.body
            let authObj = {}
            for (let i = 0; i < data.length; i++) {
              authObj[data[i].authType] = data[i].authStatus
            }
            if (source !== '2') {
              if (authObj['JCZL'] !== 1) {
                cb && cb(`/loanInfo?source=${source}&w=${w}`)
                return
              }
            }
            let nextPage = ''
            if (authObj['CA'] !== 1) {
              nextPage = `/identityAuth?source=${source}&w=${w}`
            } else if (authObj['CON'] !== 1) {
              nextPage = `/emergencyContact?source=${source}&w=${w}`
              // 隐藏运营商判断
              // } else if (authObj['MOP'] !== 1) {
              //   // 运营商认证未完成，需做单独处理，调用运营商认证jsbridge
              //   nextPage = 'MOP'
            } else if (authObj['OTH'] !== 1) {
              nextPage = `/otherInfo?source=${source}&w=${w}`
            } else {
              // 所有资料已完成
              nextPage = 'FINISH'
            }
            cb && cb(nextPage)
          }
        },
        () => {
          this.closeLoading()
          cb && cb('ERROR')
        }
      )
    },
    /**
     * 运营商认证
     * @param {String} productId 产品id。产品详情页调用时传入，用户服务端事件统计
     * @param {Function} cb 运营商认证成功回调
     */
    // fillMopInfo (productId, w, cb) {
    //   let that = this
    //   let store = that.$store.state.baseInfo
    //   if (store.userIdcard && store.userName) {
    //     that.appStartOperatorFunc(w, store.userIdcard, store.userName, store.phoneNumber, productId, cb)
    //   } else {
    //     getBasicInfoApi({}).then((data) => {
    //       if (data.respCode === '1000') {
    //         let name = data.body.userName || ''
    //         let idCard = data.body.identityCard || ''
    //         that.$store.commit('USER_NAME', name)
    //         that.$store.commit('USER_IDCARD', idCard)
    //         if (name !== '' && idCard !== '') {
    //           eventCtr.$emit('nameIdcardEditAll', true)
    //         } else {
    //           eventCtr.$emit('nameIdcardEditAll', false)
    //         }
    //         that.appStartOperatorFunc(w, idCard, name, store.phoneNumber, productId, cb)
    //       }
    //     })
    //   }
    // },
    // 调用运营商认证
    // appStartOperatorFunc (w, userIdcard, userName, phoneNumber, productId, cb) {
    //   let that = this
    //   if (w) {
    //     this.collectEventMD({
    //       eventId: `ly1007,w${w}`,
    //       eventResult: 1,
    //       eventStartTime: new Date().getTime(),
    //     })
    //   }
    //   // 客户端埋点
    //   this.collectEventMD({
    //     eventStartTime: new Date().getTime(),
    //     eventId: '1008',
    //     eventResult: 1,
    //     productId: productId,
    //   })
    //   this.$appInvoked(
    //     'appStartOperator',
    //     {
    //       editable: true,
    //       identityCard: userIdcard,
    //       identityName: userName,
    //       phone: phoneNumber,
    //     },
    //     function (data) {
    //       let status = data.status
    //       // 0：认证失败 ，1：认证成功 ，2：认证中，3：用户取消
    //       // eslint-disable-next-line eqeqeq
    //       if (!status || status == 0) {
    //         that.toast('认证未通过')
    //         // 客户端埋点
    //         that.collectEventMD({
    //           eventStartTime: new Date().getTime(),
    //           eventId: '1009',
    //           eventResult: 2,
    //           productId: productId,
    //         })
    //         // eslint-disable-next-line eqeqeq
    //       } else if (status == 1 || status == 2) {
    //         that.toast('运营商认证成功')
    //         // that.authStatusObj['MOP'] = 1
    //         // that.computeCurIdx(that.authStatusObj)
    //         submitAuthStatusApi({ riskType: 2, status: 1 }).then(() => {
    //           // 认证成功回调
    //           cb && cb()
    //         })
    //         // 客户端埋点
    //         that.collectEventMD({
    //           eventStartTime: new Date().getTime(),
    //           eventId: '1009',
    //           eventResult: 1,
    //           productId: productId,
    //         })
    //       }
    //     }, () => {
    //       // 客户端埋点
    //       that.collectEventMD({
    //         eventStartTime: new Date().getTime(),
    //         eventId: '1009',
    //         eventResult: 0,
    //         productId: productId,
    //       })
    //     }
    //   )
    // },
    // 点击跳转指定链接
    jrcsOpenAppPage (w, url, title, params) {
      let that = this
      params = params || '{}'
      try {
        params = JSON.parse(params)
      } catch (e) {
        // 
      }
      let urls = {
        JRCS_SY: '/home', // 首页
        JRCS_DKDQ: '/productlist', // 贷款大全
        JRCS_CNKD: '/guessborrow', // 猜你可贷
        JRCS_WD: '/mycenter', // 我的
        JRCS_WDYHQ: '/myCoupon', // 我的-优惠券
        JRCS_WDWSDKXX: '/fillLoanInfo', // 我的-完善贷款信息
        JRCS_XYK: '/creditCardHome', // 信用卡
      }
      // 首页分类-产品列表页
      if (urls[url]) {
        that.$routerPush(urls[url] + `?w=${w}`)
      } else if (url === 'JRCS_SYFLCPLB') {
        // 首页分类-产品列表
        that.$routerPush(`/prolist?className=${params.className || params.text}&category=${params.category}`)
      } else if (url === 'JRCS_ZNTJ') {
        // 智能推荐
        that.globalRecommendClick(w)
      } else {
        if (url.indexOf(`${this.$config.get('fullPath')}#/notice?position=`) > -1) {
          // 判断是公告详情页，直接进行路由跳转，不开新的webView
          url = url.replace(`${this.$config.get('fullPath')}#`, '')
          this.$routerPush(url)
        } else {
          this.$appInvoked('appOpenWebview', {
            url: url,
            nav: {
              title: {
                text: title,
              },
            },
          })
        }
      }
    },
    /**
     * 设置异常缺省页信息（页面需定义一下字段：showErrorPage-是否展示错误页面，errorPageInfo-错误页面信息）
     * @param {String} errorPageType 错误页面类型。offline-无网络，noData-无数据
     * @param {Object} errorPageInfo 错误页面展示信息
     */
    initDefaultErrorPageInfos (errorPageType, errorPageInfo) {
      let that = this
      let isDKDQ = this.$route.path === '/productlist'
      switch (errorPageType) {
        case 'offline':
          this.errorPageInfo = {
            title: '信号可能跑累了，歇会儿就好',
            icon: 'qsy_jzsb.png',
            btnTxt: '唤醒它',
            btnClick: () => {
              that.$appInvoked('appExecStatistic', { eventId: 'wwl;hxt;w347' })
              location.reload()
            },
          }
          break
        case 'noData':
          this.errorPageInfo = {
            title: '很遗憾！根据您的资质和借款需求，<br>暂时没有匹配到合适的产品！',
            icon: 'qsy_wtj.png',
            btnTxt: isDKDQ ? '' : '去借款',
            btnClick: () => {
              if (!isDKDQ) {
                this.$routerPush("/productlist")
              }
            },
          }
          break
        default:
          this.errorPageInfo = errorPageInfo
          break
      }
      this.showErrorPage = true
    },
    getCachedImages (type) {
      var cachedImages = {}
      var cachedImage = localStorage.getItem('kCachedImages')
      if (cachedImage != null && cachedImage !== '{}' && cachedImage.length > 0) {
        cachedImages = JSON.parse(cachedImage)
      } else {
        this.$appInvoked('appGetImageSource', {}, function (images) {
          localStorage.setItem('kCachedImages', JSON.stringify(images))
        })
      }
      if (type === 'loadingIcon') {
        return cachedImages[type] ? 'data:image/gif;base64,' + cachedImages[type] : ''
      }
      return cachedImages[type] ? 'data:image/png;base64,' + cachedImages[type] : ''
    },
    /**
     * 产品点击--打开第三方注册页
     */
    openThirdRegisterPage (name, url, productId, w, p, category, linkSeqId, rank, fromDetailPage = 0) {
      let eventId = `chanpin1;w${w};p${p};c${productId};l${linkSeqId};t${rank}`;
      this.clickReport(productId, category, eventId)
      this.$appInvoked("appOpenWebview", {
        copyMobile: true,
        category: category,
        url: url,
        // needLogin: true,
        // productClickEventId: eventId,
        productId: productId,
        nav: {
          title: { text: name },
          // right: { text: "智能推荐", callback: "topPreRecommend('" + w + "')" },
          right: { text: "智能推荐", callback: "topPreRecommend()" },
        },
        needBackDialog: false,
        needDownloadList: true,
        locate: w,
        sort: p,
        fromDetailPage: fromDetailPage,
        linkSeqId: linkSeqId,
      });
    },
    /**
     * 通用广告位点击
     * @param {Object} item 产品对象，ProductCategoryVO
     * @param {String} category 产品分类
     * @param {String} w 埋点w字段
     * @param {String} p 埋点p字段，表示列表中的排序，从1开始
     * @param {Boolean} needBackDialog 是否需要挽留弹窗
     */
    // globalADClick (item, category, w, p, needBackDialog) {
    //   let that = this
    //   that.needUserLogin(() => {
    //     if (item.clickType == 2) {
    //       // 跳指定链接
    //       if (!item.advertiseConfigVO || !item.advertiseConfigVO.linkAddress) {
    //         return
    //       }
    //       let url = item.advertiseConfigVO.linkAddress
    //       let eventId =
    //       this.openThirdUrl(item, category, w, p, needBackDialog, url, eventId)
    //     } else {}
    //   })
    // },
    /**
     * 通用产品点击事件
     * @param {Object} item 产品对象，ProductCategoryVO
     * @param {String} category 产品分类
     * @param {String} w 埋点w字段
     * @param {String} p 埋点p字段，表示列表中的排序，从1开始
     * @param {Boolean} needBackDialog 是否需要挽留弹窗
     * @param {Boolean} closeOldReport 只有首页API_BANNER使用传true，其他不传默认false
     */
    // globalProductClick(item, category, w, p, needBackDialog, closeOldReport) {
    //   let that = this
    //   that.needUserLogin(() => {
    //     let productId = item.id
    //     let name = item.name
    //     if (item.supportApiLoan) {
    //       // 支持API全流程
    //       let uri = `?category=${category}&productId=${productId}&productName=${name}&p=${p}&w=${w}&supportJoinLogin=${item.supportJoinLogin}&t=${item.rank}`
    //       let eventId = `chanpin0;w${w};p${p};c${productId};l${window.$config.get('events.linkSeqId')};t${item.rank}`
    //       if (!closeOldReport) { // API_banner只添加新增埋点，去掉旧的产品点击埋点
    //         that.clickReport(productId, category, eventId)
    //         this.$appInvoked("appExecStatistic", {
    //           eventId: eventId,
    //           eventType: 2
    //         })
    //       }
    //     }
    //   })
    // },
  },
}
export default Mixins
