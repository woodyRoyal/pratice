import PageView from '@/components/PageView'
const plugin = {
  install (Vue) {
    Vue.component('PageView', PageView)
    Vue.directive('focus', {
      inserted: function (el, { value }) {
        if (value) {
          el.focus()
        }
      },
      componentUpdated: function (el, { value }) {
        if (value) {
          el.focus()
        }
      },
    })
  },
}
export default plugin
