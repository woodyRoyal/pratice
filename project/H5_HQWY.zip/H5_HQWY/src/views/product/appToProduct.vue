<template>
  <PageView id="hqwy-mescroll"
            type="mescroll"
            :title="$route.query.name">
    <!-- 花钱无忧Loading -->
    <VLoad :isload="true"></VLoad>
    <BasicInfo ref="basicInfo"></BasicInfo>
  </PageView>
</template>
<script>
import VLoad from "../../components/load"
import BasicInfo from "../../components/basicInfo/index"
// import utils from "../../util/utils"
import eventCtr from "../../../static/js/eventCtr"


export default {
  components: {
    VLoad,
    BasicInfo,
  },
  data () {
    return {
      nameIdcardEditAll: false, // 姓名身份证号已填写标识
      fromapp: this.$route.query.fromapp || 1, // 是否app直接打开此页面：1-是，0-否
    }
  },
  activated () {
    let that = this
    // 默认隐藏该页面原生导航栏
    that.$appInvoked('appSetNavigationBar', {
      nav: {
        hide: true,
      },
    })
    let query = that.$route.query
    that.fromapp = query.fromapp || 1
    let name = query.name,
      url = query.address || '',
      productId = query.proId,
      w = query.w,
      p = query.p,
      type = query.type || 0,
      category = query.category,
      linkSeqId = query.linkSeqId,
      supportJoinLogin = query.supportJoinLogin === 'true' || query.supportJoinLogin === '1',
      supportApiLoan = query.supportApiLoan === 'true' || query.supportApiLoan === '1';
    that.proListClick(name, url, productId, w, p, type, true, category, linkSeqId, supportJoinLogin, supportApiLoan)
  },
  mounted () {
    // 获取姓名和身份证是否已填写
    eventCtr.$on("nameIdcardEditAll", (msg) => {
      this.nameIdcardEditAll = msg
    })
  },
  methods: {
    // 点击产品列表
    proListClick (
      name,
      url,
      productId,
      w,
      p,
      goFlag,
      needBackDialog,
      category,
      linkSeqId,
      supportJoinLogin, supportApiLoan
    ) {
      let that = this;

      let l = supportApiLoan ? window.$config.get('events.linkSeqId') : linkSeqId;
      let eventId = `chanpin0;w${w};p${p};c${productId};l${l};t${that.$route.query.rank || 0}`;

      that.needUserLogin(w, () => {
        that.clickReport(productId, category, eventId);
        that.$appInvoked("appExecStatistic", {
          eventId: eventId,
          eventType: 2,
        }); //添加埋点
        // 是否是新版本 是否支持api
        if (supportApiLoan) {
          let uri = `?category=${category}&productId=${productId}&productName=${name}&p=${p}&w=${w}&supportJoinLogin=${supportJoinLogin}&fromapp=${that.$route.query.fromapp || 1}&t=${that.$route.query.rank || 0}`;
          // 姓名和身份证号是否已填写
          if (!that.nameIdcardEditAll) {
            that.$refs.basicInfo.getBasicInfoFun((nameIdcardEditAll) => {
              if (nameIdcardEditAll) {
                // 已填写 去撞库
                that.$routerReplace('/loanHit' + uri)
              } else {
                // 未填写去基本信息补充页
                that.$routerReplace('/basicInfo' + uri)
              }
            });
          } else {
            // 已填写 去撞库
            that.$routerReplace('/loanHit' + uri)
          }
        } else {
          that.$routerReplace(`/productDetail/${category}/${productId}?p=${p}&w=${w}&supportJoinLogin=${supportJoinLogin}&t=${that.$route.query.rank || 0}`);
          that.$appInvoked("appOnPageEnd", { pageName: that.$route.meta.title });
          window.currentPageName = that.$route.meta.title;
        }
      })
    },
  },
}
</script>

