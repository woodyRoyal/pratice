<template>
  <PageView id="hqwy-mescroll"
            class="mescroll"
            :title="$route.query.productName">
    <!-- 花钱无忧Loading -->
    <VLoad :isload="true"></VLoad>
  </PageView>
</template>
<script>
import VLoad from "../../components/load"
import utils from "../../util/utils";

import { loanHitApi } from '../../api/controller/common/index'
import { queryRecentOrderApi } from '../../api/controller/product'
// import { orderCheckApi } from '../../api/controller/mine/order'
import { prescreenApi } from '../../api/controller/api/index'
import { requestLoanResultQueryApi } from '../../api/controller/loan/index'
/* eslint-disable eqeqeq */
export default {
  components: {
    VLoad,
  },
  data () {
    return {}
  },
  computed: {
    // 是否为立即贷API产品
    isLJDAPI () {
      // eslint-disable-next-line eqeqeq
      return window.$config.get('LJDPRODUCTID') == this.$route.query.productId
    },
  },
  activated () {
    let that = this;
    let checkStatus = that.$route.query.checkStatus; // 0-不执行查询（基础信息），其他执行查询
    if (checkStatus && checkStatus === '0') {
      that.loanHitFunc();
    } else {
      // 执行查询接口
      that.queryRecentOrderFunc();
    }
  },
  methods: {
    // 撞库之前先预筛
    loanHitFunc () {
      let that = this
      let query = that.$route.query
      that.prescreenFunc((rst) => {
        if (rst) {
          that.loanHitApiFunc();
        } else { // 资质不符
          // 产品详情页面
          let productDetailPage = `/productDetail/${query.category}/${query.productId}?p=${query.p}&w=${query.w}&supportJoinLogin=${query.supportJoinLogin || false}&fromapp=${query.fromapp}&t=${query.t}&pstatus=2`;
          that.$routerReplace(productDetailPage);
        }
      })
    },
    // 撞库接口
    loanHitApiFunc () {
      let that = this;
      let query = that.$route.query;
      let isLJDAPI = that.isLJDAPI;

      /**
       * 页面所需参数
       * category
       * productId
       * p
       * w
       * productName
       * supportJoinLogin
       */
      // 产品详情页面
      let productDetailPage = `/productDetail/${query.category}/${query.productId}?p=${query.p}&w=${query.w}&supportJoinLogin=${query.supportJoinLogin || false}&fromapp=${query.fromapp}&t=${query.t}&pstatus=`;
      // 审核中页面
      let inAuditPage = `/inAudit?productName=${query.productName}&productId=${query.productId}&fromapp=${query.fromapp}`;
      // let checkResultPage = `/checkResult?productName=${query.productName}&status=2&applyTime=${data.applyTime}&applyNeedTime=${data.applyNeedTime}`;
      let params = {
        productId: query.productId,
      }
      if (!isLJDAPI) {
        params.hitVersion = '2.0'
      }
      loanHitApi(params).then((data) => {
        data = data.body;
        // 1-不可申请用户 2-简化申请用户 3-正常申请用户
        let hitStatus = data.hitStatus;
        // let page = '';
        if (hitStatus == 1) {
          that.$routerReplace(productDetailPage + 2);
        } else if (hitStatus == 2) {
          that.$routerReplace(inAuditPage);
        } else if (hitStatus == 3) {
          that.$routerReplace(productDetailPage + 1);
        } else {
          that.$routerReplace(productDetailPage + 3);
        }
      }, () => {
        // 响应失败，跳转出错啦
        that.$routerReplace(productDetailPage + 3);
      });
    },
    // 根据产品ID查询产品最新订单状态
    queryRecentOrderFunc () {
      let that = this;
      let query = that.$route.query;
      let isLJDAPI = that.isLJDAPI;
      queryRecentOrderApi({
        productId: query.productId,
      }).then((data) => {
        data = data.body;

        let orderStatus = data.orderStatus;
        let commonParams = `orderNo=${data.orderId}&productName=${data.productName}&productId=${query.productId}&fromapp=${query.fromapp}`

        // 立即贷审核中、审核失败页面
        let checkResultPage = `/checkResult?productName=${data.productName}&nextApplyTime=${data.nextApplyTime}&applyTime=${data.applyTime}&applyNeedTime=${data.applyNeedTime}&fromapp=${query.fromapp}&status=`;
        // API产品-审核中页面
        let loanInAuditPage = `/loan/inAudit?${commonParams}`
        // API产品-待提交订单
        let submitOrderPage = `/loan/submitOrder?${commonParams}&loanOrderNo=${data.loanOrderNo}`
        // API产品-确认用款
        let confirmLoanPage = `/loan/confirmLoan?${commonParams}&loanOrderNo=${data.loanOrderNo}`
        // API产品-放款中
        let onLoanPage = `/loan/onLoan?${commonParams}&loanOrderNo=${data.loanOrderNo}`
        // API产品-放款成功、失败
        let auditResultPage = `/loan/auditResult?${commonParams}&loanOrderNo=${data.loanOrderNo}&status=`
        // 订单详情页面
        let orderDetailPage = `/order/detail?${commonParams}&loanOrderNo=${data.loanOrderNo}&category=12&p=${query.p}&w=${query.w}`;

        // 101-资料提交中做审核中处理，审核中（103）、待提现（201）、待还款（301）、已逾期（401）、已结清（402）、审核失败（202）
        if (orderStatus == 103 || orderStatus == 101) {
          // 审核中，查看审批结果
          if (isLJDAPI) {
            that.$routerReplace(checkResultPage + 2);
          } else {
            that.$routerReplace(loanInAuditPage)
          }
        } else if (orderStatus == 201) {
          // 待提现，再次撞库
          if (isLJDAPI) {
            that.loanHitFunc();
          } else {
            that.$routerReplace(submitOrderPage)
          }
        } else if ([301, 302, 401, 402].indexOf(Number(orderStatus)) > -1) {
          // 待还款、放款失败、已逾期、已结清跳转订单详情
          if (orderStatus == 402 && !data.undercarriage) {
            utils.toastMsg('产品已下架，请浏览其它产品')
          } else if (orderStatus == 402) {
            that.loanHitFunc()
          } else {
            that.$routerReplace(orderDetailPage)
          }
          //   // 待还款、已逾期，查询订单状态
          //   let params = {
          //     orderNo: data.orderId,
          //     productId: data.productId
          //   };
          //   orderCheckApi(params).then(data1 => {
          //     data1 = data1.body;
          //     this.$appInvoked('appOpenWebview', {
          //       url: data1.link,
          //       nav: {
          //         title: {
          //           text: data.productName
          //         }
          //       }
          //     });
          //     setTimeout(() => {
          //       that.$routerGo(-1);
          //     }, 1);
          //   });
          // } else if(orderStatus == 402) {
          //   // 已结清，再次撞库
          //   if(data.undercarriage) {
          //     that.loanHitFunc();
          //   } else {
          //     utils.toastMsg('产品已下架，请浏览其它产品');
          //   }
        } else if (orderStatus == 202) {
          // 审核失败，<=30天 审核失败页，>30天，再次撞库
          if (!data.undercarriage) {
            utils.toastMsg('产品已下架，请浏览其它产品');
          } else if (data.storehouse) {
            that.loanHitFunc();
          } else {
            // 审核失败页
            that.$routerReplace(checkResultPage + 1);
          }
        } else if (orderStatus == 303) {
          // 待确认用款
          that.$routerReplace(confirmLoanPage)
        } else if (orderStatus == 304) {
          // 放款中，调用接口查询放款状态
          requestLoanResultQueryApi({
            loanOrderNo: data.loanOrderNo,
            orderNo: data.orderId,
          }).then((resp) => {
            resp = resp.body
            let loanStatus = resp.loanStatus // 0：放款中 1：成功 2：失败
            if (loanStatus == 1) {
              that.$routerReplace(auditResultPage + 2)
            } else if (loanStatus == 2) {
              that.$routerReplace(auditResultPage + `1&loanStatusDesc=${resp.loanStatusDesc}`)
            } else {
              that.$routerReplace(onLoanPage)
            }
          })
        } else {
          // 无订单
          that.loanHitFunc();
          // that.prescreenFunc(rst => {
          //   if (rst) {
          //     that.loanHitFunc();
          //   } else { // 资质不符
          //     // 产品详情页面
          //     let productDetailPage = `/productDetail/${query.category}/${query.productId}?p=${query.p}&w=${query.w}&supportJoinLogin=${query.supportJoinLogin||false}&fromapp=${query.fromapp}&t=${query.t}&pstatus=2`;
          //     that.$routerReplace(productDetailPage);
          //   }
          // })
        }
      }, () => {
        that.loanHitFunc();
      })
    },
    // 预筛选
    prescreenFunc (cb) {
      let that = this
      prescreenApi({
        productId: that.$route.query.productId,
      }).then((data) => {
        // let data = true
        data = data.body
        cb && cb(data)
      })
    },
  },
}
</script>
<style lang="scss" scoped>
.mescroll {
  background-color: #fff;
}
</style>


