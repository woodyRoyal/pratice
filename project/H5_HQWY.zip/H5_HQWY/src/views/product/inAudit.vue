<template>
  <PageView id="hqwy-mescroll"
            class="mescroll"
            :title="$route.query.productName">
    <!-- 审核中页面主体 -->
    <div class="in-audit">
      <img :src="require('APP_IMG/global_spz.gif')"
           class="audit-page-icon">
      <div class="audit-page-title">
        订单审核中
      </div>
      <div class="audit-page-tips">
        预计需要10~20秒，请耐心等待~
      </div>
    </div>
    <!-- 失败页面 -->
    <ErrorPage v-show="showErrorPage"></ErrorPage>
  </PageView>
</template>
<script>
import ErrorPage from '../../components/error.vue'
// import utils from "../../util/utils";
import { orderCheckApi } from "../../api/controller/mine/order";
// import { faceCompareApi } from '../../api/controller/openAccount';
export default {
  name: 'InAudit',
  components: {
    ErrorPage,
  },
  data () {
    return {
      name: this.$route.query.productName,
      id: this.$route.query.productId,
      showErrorPage: false,
      startTime: new Date().getTime(),
    }
  },
  activated () {
    let that = this;
    let query = that.$route.query;
    let name = query.productName;
    // that.perfectInfoQueryFunc();
    // 原生上传风控数据
    // that.$appInvoked('appUploadRiskData', {
    //   node: 204,
    //   pageName: ''
    // }, data => {
    // 上传成功后查询
    orderCheckApi({ productId: that.$route.query.productId }).then((data) => {
      // 客户端埋点
      that.collectEventFunc('7001', 1);
      data = data.body;
      let link = data.link;
      if (link) {
        that.$appInvoked('appOpenWebview', {
          url: link,
          nav: {
            title: {
              text: name,
            },
          },
        });
        setTimeout(() => {
          that.$routerGo(-1);
        }, 1);
      } else {
        that.$routerReplace(`/checkResult?status=1&productName=${name}&nextApplyTime=${data.nextApplyTime}&fromapp=${query.fromapp}`);
      }
    }, () => {
      // 客户端埋点
      that.collectEventFunc('7001', 2);
      that.showErrorPage = true;
    });
    // }, err => {
    //   that.showErrorPage = true;
    //   that.collectEventFunc('7001', 0);
    // })
  },
  methods: {
    // 客户端埋点
    collectEventFunc (eventId, eventResult) {
      let that = this;
      that.collectEventMD({
        eventId: eventId, // 0:异常（无响应），1:成功，2:失败
        eventStartTime: that.startTime,
        eventEndTime: new Date().getTime(),
        eventResult: eventResult,
      });
    },
  },
}
</script>
<style lang="scss" scoped>
.mescroll {
  background-color: #fff;
}
.in-audit {
  text-align: center;
  padding: rc(0 30);
  .audit-page-icon {
    width: rc(230);
    height: rc(230);
    margin-top: rc(148);
  }
  .audit-page-title {
    font-size: rc(32);
    color: #333;
    margin-top: rc(40);
    font-weight: bold;
  }
  .audit-page-tips {
    font-size: rc(28);
    color: #666;
    margin-top: rc(13);
  }
}
</style>

