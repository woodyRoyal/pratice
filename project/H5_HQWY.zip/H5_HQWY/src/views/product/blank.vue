<template>
  <PageView id="hqwy-mescroll"
            class="mescroll"
            title="产品详情">
    <!-- 花钱无忧Loading -->
    <VLoad :isload="true"></VLoad>
  </PageView>
</template>
<script>
import VLoad from "../../components/load"
export default {
  components: {
    VLoad,
  },
  data () {
    return {}
  },
  activated () {
    let that = this;
    let fullPath = that.$route.fullPath;
    fullPath = fullPath.replace(/productDetailBlank/, 'productDetail');
    that.$routerReplace(fullPath);
  },
}
</script>
<style lang="scss" scoped>
.mescroll {
  background-color: #fff;
}
</style>


