<template>
  <PageView id="hqwy-mescroll"
            type="mescroll"
            title="还款结果"
            right-txt="客服/帮助"
            @rightClick="rightClickHandle">
    <div>
      <div v-if="status == 100"
           class="hqwy-check-result">
        <div class="result-icon result-icon-doing"></div>
        <div class="result-money">
          {{ repayInfo.repayMoney }}
        </div>
        <div class="result-txt">
          还款中
        </div>
      </div>
      <div v-else-if="status == 200"
           class="hqwy-check-result">
        <div class="result-icon result-icon-success"></div>
        <div class="result-money">
          {{ repayInfo.repayMoney }}元
        </div>
        <div class="result-txt">
          还款成功
        </div>
      </div>
      <div v-else
           class="hqwy-check-result">
        <div class="result-icon result-icon-fail"></div>
        <div class="result-money">
          {{ repayInfo.repayMoney }}
        </div>
        <div class="result-txt">
          还款失败
        </div>
        <div class="result-tips">
          <p>失败原因：{{ repayInfo.resultDesc }}</p>
        </div>
      </div>
      <div class="hqwy-btns">
        <CommonButton :btn-data="{activeFlag: true, txt: status==100 ? '刷新还款结果' : '确定'}"
                      @click.native="btnClick"></CommonButton>
      </div>
    </div>
    <!-- 右上角“客服/帮助” -->
    <HelpCenter ref="helpCenterModule"
                :product-id="productId"
                :product-name="productName || repayInfo.productName"></HelpCenter>

    <Loading v-show="showLoading"></Loading>
  </PageView>
</template>
<script>
import CommonButton from "../../components/button"
import Loading from "../../components/loading/loading"
// import loanCard from '../../components/card'
import HelpCenter from '@/components/HelpCenter'
import { queryRepayResult } from '../../api/controller/repay/repay'
import utils from '../../util/utils'

export default {
  components: {
    // loanCard,
    HelpCenter,
    Loading,
    CommonButton,
  },
  data () {
    let query = this.$route.query

    return {
      orderInfo: {
        loanOrderNo: query.loanOrderNo,//	借款订单号
        orderNo: query.orderNo,//	申请订单号
        period: query.periodList,//还款期数
        repayOrderNo: query.repayOrderNo,//	还款订单号
      },
      status: query.status, // 100: 还款中 200: 还款成功 其他：失败
      productId: query.productId, // 产品id
      productName: query.productName,
      repayInfo: {
        resultDesc: query.resultDesc, //失败描述
        repayMoney: query.repayMoney,
      },
      showLoading: false,
    }
  },
  activated () {
    let that = this
    let query = that.$route.query

    that.showLoading = false
    that.$refs.helpCenterModule.hide()

    that.orderInfo = {
      loanOrderNo: query.loanOrderNo, //	借款订单号
      orderNo: query.orderNo, //	申请订单号
      period: query.periodList, //还款期数
      repayOrderNo: query.repayOrderNo, //	还款订单号
    }
    that.status = query.status // 100= 还款中 200= 还款成功 其他：失败
    that.productId = query.productId // 产品id
    that.productName = query.productName
    that.repayInfo = {
      resultDesc: query.resultDesc, //失败描述
      repayMoney: query.repayMoney,
    }
  },
  methods: {
    rightClickHandle () {
      this.appExecStatistic('bzan;bztc;w236')
      this.$refs.helpCenterModule.show()
    },
    btnClick () {
      let that = this
      // eslint-disable-next-line eqeqeq
      if (that.status == 100) { //还款中
        that.appExecStatistic('hkjg;sxjg;w224')
        that.refreshRepayStatus()
        return
        // eslint-disable-next-line eqeqeq
      } else if (that.status == 200) { //还款成功
        that.appExecStatistic('hkjg;cg;w222')
      } else { // 还款失败
        that.appExecStatistic('hkjg;sb;w223')
      }
      that.$routerGo(-1);
    },
    appExecStatistic (eventId) {
      // 点击统计
      this.$appInvoked("appExecStatistic", {
        eventId: eventId,
        eventType: 0,
      })
    },
    // 刷新还款结果（防刷，1s内只能点击一次）
    refreshRepayStatus: utils.debouce(function () {
      let that = this
      that.showLoading = true
      queryRepayResult(that.orderInfo).then((data) => {
        that.showLoading = false
        let body = data.body;
        that.status = body.repayResultCode
        that.repayInfo.repayMoney = body.repayMoney
        that.repayInfo.resultDesc = body.repayResultMsg
      }).catch(() => {
        that.showLoading = false
      })
    }, 1000, true),
  },
}
</script>
<style lang="scss" scoped>
$rem-base: 750; // 计算rem的基数，默认16根据字体大小，当值超过320的将根据设计稿宽度
$Response: true; // 是否使用自适应系统，默认为false
@import '../../../static/_source/_function/mobile-mixin';
#hqwy-mescroll {
  background-color: #fff;
}
.hqwy-check-result {
  text-align: center;
  padding-top: rc(80);
  .result-icon {
    margin: 0 auto rc(10);
    width: rc(210);
    height: rc(180);
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-position: 0 0;
  }
  .result-icon-fail {
    background-image: url('../../../static/images/#{$APP_NAME}/state_img_hksb.png');
  }
  .result-icon-success {
    background-image: url('../../../static/images/#{$APP_NAME}/state_img_hkcg.png');
  }
  .result-icon-doing {
    background-image: url('../../../static/images/#{$APP_NAME}/state_img_hkz.png');
  }
  .result-money {
    margin-top: rc(43);
    font-size: rc(54);
    line-height: rc(75);
    font-weight: bold;
  }
  .result-txt {
    margin-top: rc(10);
    margin-bottom: rc(20);
    font-size: rc(32);
    line-height: rc(45);
    color: #333333;
  }
  .result-tips {
    // margin-top: rc(45);
    font-size: rc(32);
    line-height: rc(45);
    color: #999999;
  }
  .result-stip {
    margin-bottom: rc(20);
    font-size: rc(24);
    line-height: rc(34);
    color: #777;
  }
}

.hqwy-btns {
  padding: rc(60) rc(75) rc(185);
}
</style>

