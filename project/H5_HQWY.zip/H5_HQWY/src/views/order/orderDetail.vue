<template>
  <PageView :title="title"
            :is-back-page="false"
            right-txt="客服/帮助"
            @backClick="backClickHandle"
            @rightClick="rightClickHandle">
    <div id="hqwy-mescroll"
         ref="orderDetailRef"
         class="mescroll">
      <!-- 顶部banner信息 -->
      <div class="od-head-bg"
           :class="'order-status-' + order.orderStatus">
        <div class="ohb-title">
          状态
        </div>
        <div class="ohb-status">
          <span v-text="orderStatusCfg.txt"></span>
          <i v-if="order.orderStatus == 302 && order.loanFailReason"
             class="ohb-tips"
             @click="showTips('ddxq;jksbyyan;w217')"></i>
        </div>
        <div class="ohb-icon"></div>
      </div>
      <!-- 订单信息 -->
      <HeadInfo type="info-card"
                :icon="order.productLog"
                :name="order.productName"
                :tips="'该产品由' + order.productName + '提供，最终到账金额和息费解释以对方合同为准'">
        <div class="card-content-infos">
          <LoanCell title="借款金额"
                    :is-link="false">
            &yen;{{ order.loanMoney }}
          </LoanCell>
          <LoanCell title="借款期限"
                    :is-link="false">
            {{ order.loanLimit }}
          </LoanCell>
          <LoanCell title="期数"
                    :is-link="false">
            {{ order.loanPeriod }}期
          </LoanCell>
          <LoanCell title="借款日期"
                    :is-link="false">
            {{ order.applyTime }}
          </LoanCell>
          <LoanCell v-if="!isLJDAPI"
                    title="借款银行卡"
                    :is-link="false">
            {{ order.loanBankCard | formateBank(order.loanBankName) }}
          </LoanCell>
          <LoanCell v-if="!isLJDAPI"
                    title="还款银行卡"
                    :is-link="showChangeBank">
            <div class="repay-bank">
              {{ order.repayBankCard | formateBank(order.repayBankName) }}
            </div>
            <div v-if="showChangeBank"
                 class="repay-bank-change"
                 @click="changeRepayBank('ddxq;ghhkyhk;w214')">
              更换
            </div>
          </LoanCell>
        </div>
      </HeadInfo>
      <!-- 还款计划(借款失败不展示) -->
      <LoanCard v-if="order.orderStatus != 302"
                type="repay-plan">
        <LoanCell title="还款计划"
                  :is-link="false"
                  :border-type="1"></LoanCell>
        <table class="repay-plan-table">
          <thead>
            <tr>
              <td>应还日期</td>
              <td>应还总额</td>
              <td>已还金额</td>
              <td>状态</td>
            </tr>
          </thead>
          <tbody v-if="repayPlan && repayPlan.length > 0">
            <tr v-for="(i, index) in repayPlan"
                :key="index">
              <td class="rp-c2"
                  v-text="i.repayTime"></td>
              <td v-text="i.money"></td>
              <td v-text="i.repaidMoney"></td>
              <td v-cloak
                  :class="['rp-c' + i.status, isLJDAPI?'':'show-arrow']"
                  @click="periodClick(i.period)">
                {{ i.status | formatePlayStatus }}
              </td>
            </tr>
          </tbody>
          <tbody v-if="noRepayPlan">
            <tr class="no-repay-plan">
              <td colspan="4">
                还款计划生成中,请稍后~
              </td>
            </tr>
          </tbody>
        </table>
      </LoanCard>
      <!-- 其他信息 -->
      <LoanCard v-if="!isLJDAPI"
                type="other-infos">
        <LoanCell title="其他信息"
                  :is-link="true"
                  :border-type="1"
                  :direction="showAllOtherInfo?'up':'down'"
                  @click.native="switchOtherInfo()"></LoanCell>
        <div v-show="showAllOtherInfo"
             class="other-infos-content">
          <LoanCell v-if="!isLJDAPI"
                    title="到账金额"
                    :is-link="false">
            &yen;{{ order.arriveMoney }}
          </LoanCell>
          <LoanCell v-if="!isLJDAPI"
                    title="相关协议">
            <div @click="showContracts('ddxq;xy;w216')">
              点击查看
            </div>
          </LoanCell>
          <!-- <loan-cell title="商品状态"><div>未配送</div></loan-cell>
        <loan-cell title="到账金额" :isLink="false">减五元</loan-cell> -->
        </div>
      </LoanCard>
      <!-- 底部固定按钮占位 -->
      <div class="fiexd-btn-placeholder"></div>
      <!-- 底部按钮 -->
      <div class="od-btn">
        <LoanBtn :btn-data="{activeFlag: !noRepayPlan, txt: orderStatusCfg.btnTxt}"
                 @click.native="btnClick()"></LoanBtn>
      </div>
      <!-- loading -->
      <Loading v-show="showLoading"></Loading>
      <!-- 协议 -->
      <LoanActionSheet :loan-action-sheet="contracts"
                       :close="closeProtocolPopup"
                       @cell-click="goProtocol"></LoanActionSheet>
      <!-- 公共弹窗 -->
      <Confirm ref="tipsComfirm"
               :white-space="confirm.whiteSpace"
               :title="confirm.title"
               :sure-txt="confirm.sureTxt"
               :txt="confirm.txt"
               :txt-style="confirm.txtStyle"
               @on-confirm="confirm.onConfirm"></Confirm>
      <!-- 短信验证码弹窗 -->
      <Confirm ref="dynamicCodeConfirm"
               title="请输入短信验证码"
               sure-txt="提交"
               cancel-txt="取消"
               :close-on-confirm="false"
               @on-confirm="dynamicCodeConfirmFun('ddxq;yzmtj;w221')"
               @on-cancel="dynamicCodeCancelFun('ddxq;yzmqx;w220')">
        <div class="cardList"
             style="padding:0;">
          <ul class="cardList-tb">
            <li class="vux-1px-b">
              <input v-model.trim="dynamicNum"
                     type="text"
                     maxlength="6"
                     placeholder="请输入验证码">
              <a v-show="sendAgainFlag"
                 class="btnAgain"
                 href="javascript:"
                 @click="getDynamicCodeFun('ddxq;hqyzm;w219')">重新发送</a>
              <em v-show="!sendAgainFlag"
                  class="countDown">{{ countDownTime }}秒后重试</em>
            </li>
          </ul>
        </div>
        <aside class="setTip">
          {{ order.name }}已发送验证码到<span>{{ phoneNum | formatePhone }}</span>，请查看并填写。
        </aside>
      </Confirm>
      <!-- 更换还款银行卡 -->
      <ActionBank ref="actionBank"
                  :action-id="bankCfg.actionId"
                  :pd-info="bankCfg.pdInfo"
                  :action-title="bankCfg.actionTitle"
                  @on-select="selectBank"
                  @on-addbank="addBank"></ActionBank>
      <!-- 右上角“客服/帮助” -->
      <HelpCenter ref="helpCenterModule"
                  :product-id="productId"
                  :product-name="productName || order.productName"></HelpCenter>
      <!-- 期次选择页面 -->
      <transition :name="transitionName">
        <div v-if="showPeriodChoose"
             class="period-choose">
          <div class="period-choose-title">
            选择还款期次
          </div>
          <ul class="period-list">
            <li v-for="(i, index) in repayPlan"
                :key="index"
                class="bb-1px">
              <div v-if="i.status != 2"
                   class="period-item"
                   :class="'period-sts' + i.status">
                <div class="period-select"
                     :class="i.period==minRepayPeriod?'selected':'disabled'"></div>
                <div class="period-center">
                  <div class="period-amount">
                    &yen;{{ (i.money - i.repaidMoney) | toFixed(2) }}
                  </div>
                  <div class="period-date">
                    还款日:{{ i.repayTime }}
                  </div>
                </div>
                <div class="period-right">
                  <div class="period-count">
                    第{{ i.period }}期
                  </div>
                  <div class="period-status"
                       :class="'rp-c' + i.status">
                    {{ i.status | formatePlayStatus }}
                  </div>
                </div>
                <!-- <img class="period-arrow" src="../../../static/images/arrow.png" alt=""> -->
              </div>
            </li>
          </ul>
          <div class="period-repay-bottom">
            <div class="period-select-all disabled"></div>
            <div class="period-select-all-tips">
              全选
            </div>
            <div class="period-amount-total">
              总计: <span v-text="repayInfos.repayAmount"></span>
            </div>
            <div class="period-repay-btn"
                 @click="periodChooseRepayFunc">
              还款
            </div>
          </div>
        </div>
      </transition>
    </div>
  </PageView>
</template>
<script>
import LoanCard from '@/components/card/index'
import HeadInfo from '@/components/card/headInfo'
import LoanCell from '@/components/cell/index'
import Confirm from '@/components/confirm/index'
import LoanBtn from '@/components/button/index'
import Loading from "@/components/loading/loading"
import LoanActionSheet from "@/views/loan/components/loanActionSheet"
import ActionBank from '@/components/actionBank/ActionBank'
import HelpCenter from '@/components/HelpCenter'

import { getDetailOrRepayPlanApi, applyRepayApi } from '@/api/controller/api/index.js'
import { requestApplyLoanProtocolApi } from '@/api/controller/loan/index.js'
import { orderCheckApi } from "@/api/controller/mine/order"
import utils from '../../util/utils'
/* eslint-disable eqeqeq */
export default {
  components: {
    LoanCard, HeadInfo, LoanCell, Confirm, LoanBtn,
    Loading, LoanActionSheet, ActionBank, HelpCenter,
  },
  filters: {
    formatePlayStatus (status) {
      status += ''
      switch (status) {
        case '1':
          return '待还款'
        case '2':
          return '已结清'
        case '3':
          return '已逾期'
      }
    },
    formatePhone (val) {
      if (val) {
        return val.substr(0, 3) + '****' + val.substr(7, 4)
      } else {
        return ''
      }
    },
    formateBank (card, name) {
      if (card) {
        return name + '(' + card.substr(card.length - 4) + ')'
      } else {
        return name
      }
    },
    toFixed (val, n) {
      val = Number(val)
      return val.toFixed(n)
    },
  },
  data () {
    let query = this.$route.query
    return {
      title: '订单详情',
      pageType: 'detail', // 当前页面：detail-订单详情，period-多期产品还款页面
      isLJDAPI: window.$config.get('LJDPRODUCTID') == query.productId, // 是否是立即贷API产品，用于做立即贷兼容
      productId: query.productId, // 产品id
      productName: query.productName,
      loanOrderNo: query.loanOrderNo, // 借款订单号
      orderNo: query.orderNo, // 进件申请订单号
      p: query.p,
      w: query.w,
      category: query.category || 12,
      showLoading: false,
      order: { //订单详情
        applyTime: "", // 申请时间 yyyy-MM-dd
        arriveMoney: "", // 到账金额
        loanBankCard: "", // 借款银行卡
        loanBankName: "", // 借款银行名称
        loanFailReason: "", // 借款失败原因
        loanLimit: "", // 借款期限
        loanMoney: "", // 借款金额
        loanPeriod: "", // 借款期数
        // orderStatus: '', // 订单状态 0-借款失败，1-待还款，2-已结清，3-逾期
        orderStatus: '', // 订单状态 302-借款失败，301-待还款，402-已结清，401-逾期
        preferActivities: "", // 优惠活动
        repayBankCard: "", // 还款银行卡
        repayBankName: "", // 还款银行名称
        productName: '', // 产品名称
        productLog: '', // 产品logo
      },
      /*
        money: "", // 应还金额
        period: "", // 期次
        repaidMoney: "", // 已还金额
        repayFeeInterest: "", // 应还费息
        repayOverdueFee: "", // 应还逾期费息
        repayPrincipal: "", // 应还本金
        repayTime: "", // 应还日期
        settleTime: "", // 结清时间
        status: "" // 状态：1:待还款 2:结清 3:逾期
      */
      repayPlan: [], // 还款计划
      contracts: {
        show: false,
        title: '贷款相关协议',
        list: [],
      }, // 相关协议
      showChangeBank: false, // 是否展示更换还款银行卡按钮
      showAllOtherInfo: true, // 是否展示其他信息，true-展示，false-收起
      confirm: { // 弹窗配置
        whiteSpace: false,
        title: '温馨提示',
        sureTxt: '确认',
        onConfirm: function () {
          // 
        },
        txt: '',
        txtStyle: 'left',
      },
      phoneNum: this.$store.state.baseInfo.phoneNumber,
      countDownTime: 60, // 验证码倒计时
      sendAgainFlag: false, // 重新发送Flag
      dynamicNum: '', // 短信验证码
      dynamicCodeFlag: true, // 验证码弹框确定Flag
      timer: null,
      bankCfg: {
        actionId: "",
        pdInfo: {
          productId: query.productId,//产品Id
          applyNo: query.orderNo,//进件订单编号
          loanNo: query.loanOrderNo,//借款订单号
          stage: 2,//1：借款阶段 2：还款阶段
        },
        actionTitle: "选择银行卡",
      },
      showPeriodChoose: false, // 多期展示期次选择页面
      transitionName: 'slide-right',
      // activeFlag: true, // 底部立即还款按钮是否可点击
      noRepayPlan: false, // 是否无还款计划
      minRepayPeriod: '', // 多期最小还款期次
      selectPeriodIdx: '', // 多期已选择的期次index
      repayInfos: {
        repayAmount: '', // 实际还款金额，应还金额（money）- 已还金额（repaidMoney）
        repayPeriod: '', // 还款期次，多期的话期次逗号隔开
        shouldAmount: '', // 应还金额，多期为多期的应还金额（money）之和
      },
    }
  },
  beforeRouteLeave (to, from, next) {
    let that = this
    that.contracts.show = false
    that.$refs.actionBank.hide()
    that.$refs.dynamicCodeConfirm.hide()
    that.$refs.tipsComfirm.hide()
    that.$refs.helpCenterModule.hide()
    // if (this.$refs.orderDetailRef != undefined) {
    //   global.storage.set("orderDetailScrollTop", this.$refs.orderDetailRef.scrollTop);
    // }
    next()
  },
  beforeRouteEnter (to, from, next) {
    // let pathList = ['/mycenter', '/home', '/order']
    // if (pathList.indexOf(from.path) > -1) {
    //   global.storage.set("orderDetailScrollTop", 0);
    // }
    next((vm) => {
      vm.showPeriodChoose = false
      vm.transitionName = 'slide-right'
      // setTimeout(() => {
      //   if (vm.$refs.orderDetailRef != undefined) {
      //     vm.$refs.orderDetailRef.scrollTop =
      //       global.storage.get("orderDetailScrollTop") || 0;
      //   }
      // }, 0);
    })
  },
  computed: {
    orderStatusCfg () {
      let that = this
      let txt // 状态文言
      let btnTxt // 按钮文言
      let btnEventId // 按钮埋点事件id
      let status = that.order.orderStatus + ''
      switch (status) {
        case '302':
          txt = '借款失败'
          btnTxt = '再借一笔'
          btnEventId = 'ddxq;zjyb;w212'
          that.showChangeBank = false
          break
        case '301':
          txt = '待还款'
          btnTxt = '立即还款'
          btnEventId = 'ddxq;hk;w213'
          that.showChangeBank = true
          break
        case '402':
          txt = '已结清'
          btnTxt = '再借一笔'
          btnEventId = 'ddxq;zjyb;w212'
          that.showChangeBank = false
          break
        case '401':
          txt = '已逾期'
          btnTxt = '立即还款'
          btnEventId = 'ddxq;hk;w213'
          that.showChangeBank = true
          break
      }
      return {
        txt: txt,
        btnTxt: btnTxt,
        btnEventId: btnEventId,
      }
    },
  },
  // 页面开启的时候调用
  activated () {
    this.interceptAppBack()
    let that = this
    // that.$refs.helpCenterModule.show()
    that.setHeader('detail')
    let query = that.$route.query
    let isLJDAPI = window.$config.get('LJDPRODUCTID') == query.productId
    that.isLJDAPI = isLJDAPI
    that.productId = query.productId
    that.productName = query.productName
    that.loanOrderNo = query.loanOrderNo
    that.orderNo = query.orderNo
    that.p = query.p
    that.w = query.w
    that.category = query.category || 12

    if (that.$store.state.baseInfo.phoneNumber != '') {
      that.phoneNum = that.$store.state.baseInfo.phoneNumber
    } else {
      that.$appInvoked("appGetMobilephone", {}, (data) => {
        that.phoneNum = data
        that.$store.commit("PHONE_NUMBER", data);
      })
    }
    // 客户端埋点
    that.collectEventMD({
      eventId: '11004',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
      productId: that.productId,
    })
    // activated生命周期中，使用setTimeout替代$nextTick，避免$nextTick不触发问题
    // that.$nextTick(() => {
    that.showLoading = false
    that.contracts.list = []
    setTimeout(() => {
      that.getOrderDetail()
      if (!isLJDAPI) {
        that.getContracts()
      }
    }, 100)
    // })
  },
  methods: {
    backClickHandle () {
      let that = this
      let type = that.pageType
      if (type === 'period') {
        that.$refs.dynamicCodeConfirm.hide()
        that.$refs.tipsComfirm.hide()
        that.$refs.helpCenterModule.hide()
        that.switchPeriodChooseShow(false)
      } else {
        if (that.$route.query.fromapp === '1') {
          that.$appInvoked("appExecBack", {});
        } else {
          that.$routerGo(-1);
        }
      }
    },
    rightClickHandle () {
      let that = this
      that.contracts.show = false
      that.$refs.actionBank.hide()
      that.$refs.dynamicCodeConfirm.hide()
      that.$refs.tipsComfirm.hide()
      that.md50td('bzan;bztc;w236')
      that.$refs.helpCenterModule.show()
    },
    // 更换银行卡
    changeRepayBank (eventId) {
      let that = this
      that.md50td(eventId)
      that.$refs.actionBank.show()
    },
    // 选择银行卡
    selectBank (bank) {
      let that = this
      that.bankCfg.actionId = bank.cardNo
      that.order.repayBankName = bank.bankName
      that.order.repayBankCard = bank.cardNo
    },
    // 添加银行卡
    addBank () {
      // let that = this
    },
    // 点击当期详情
    periodClick (period) {
      let that = this
      if (that.isLJDAPI) {
        return
      }
      let eventId = `ddxq;hkqc${period};w215`
      that.md50td(eventId)
      let url = `/order/periodDetail?loanOrderNo=${that.loanOrderNo}&orderNo=${that.orderNo}&period=${period}&productId=${that.productId}&productName=${that.productName}`
      that.$routerPush(url)
    },
    // 相关协议点击
    showContactClick (eventId) {
      let that = this
      that.md50td(eventId)
    },
    // 顶部按钮点击
    btnClick () {
      let that = this
      that.md50td(that.orderStatusCfg.btnEventId)
      let status = that.order.orderStatus + ''
      if (['302', '402'].indexOf(status) > -1) { // 再借一笔
        that.loanAgainFunc()
      } else if (['301', '401'].indexOf(status) > -1) { // 立即还款
        that.repayNowFunc()
      }
    },
    // 再借一笔
    loanAgainFunc () {
      let that = this
      // if (that.isLJDAPI) { // 立即贷再次撞库
      // 撞库页面
      let loanHitPage = `/loanHit?category=${that.category}&productId=${that.productId}&productName=${that.productName}&p=${that.p}&w=${that.w}`
      that.$routerPush(loanHitPage)
      // }
    },
    // 立即还款
    repayNowFunc () {
      let that = this
      let loanPeriod = that.order.loanPeriod
      if (that.isLJDAPI) {
        that.showLoading = true
        // 待还款、已逾期，查询订单状态
        let params = {
          orderNo: that.orderNo,
          productId: that.productId,
        };
        orderCheckApi(params).then((data) => {
          that.showLoading = false;
          data = data.body;
          that.$appInvoked('appOpenWebview', {
            url: data.link,
            nav: {
              title: {
                text: that.productName,
              },
            },
          });
        }, () => {
          that.showLoading = false
        });
      } else if (that.noRepayPlan) {
        return
      } else if (loanPeriod == 1) { // 单期产品
        // 还款
        that.computedRepayInfos(that.repayPlan, () => {
          that.applyRepayFunc()
        })
      } else if (loanPeriod > 1) {
        // 多期产品，点击进入期次选择页面
        let repay = []
        repay.push(that.repayPlan[that.selectPeriodIdx])
        that.computedRepayInfos(repay, () => {
          that.switchPeriodChooseShow(true)
        })
      }
    },
    // 还款期次页面点击还款
    periodChooseRepayFunc () {
      let that = this
      let repay = []
      repay.push(that.repayPlan[that.selectPeriodIdx])
      that.computedRepayInfos(repay, () => {
        that.applyRepayFunc()
      })
    },
    // 调用还款接口
    applyRepayFunc (repayVerifyCode) {
      let that = this
      that.showLoading = true
      let repay = that.repayInfos
      let params = {
        loanOrderNo: that.loanOrderNo,
        loanPeriod: that.order.loanPeriod,
        orderNo: that.orderNo,
        repayAmount: repay.repayAmount,
        repayPeriod: repay.repayPeriod,
        repayVerifyCode: repayVerifyCode || '',
        shouldAmount: repay.shouldAmount,
      }
      applyRepayApi(params).then((data) => {
        that.showLoading = false
        if (data.respCode === '1000') {
          data = data.body
          let code = data.repayResultCode
          // 100:处理中 102:请输入已发送的验证码重新请求 200:还款成功 401:银行卡余额不足
          // 402:银行卡支付次数已达上限，请更换银行卡重试或明天重试
          // 403:银行卡支付额度已达上限，请更换银行卡重试或明天重试 404:短信验证码错误，请重新输入
          // 505：其它还款失败原因，直接透传机构返回的提示文案
          let repayResultPage = `/order/repayResult?status=${code}&repayMoney=${data.repayMoney}&loanOrderNo=${that.loanOrderNo}&orderNo=${that.orderNo}&periodList=${repay.period}&repayOrderNo=${data.repayOrderNo}&resultDesc=${data.repayResultMsg}&productId=${that.productId}&productName=${that.productName}&p=${that.p}&w=${that.w}&category=${that.category}`
          if (code == 404) {
            // 验证码错误直接提示
            utils.toastMsg('短信验证码错误，请重新输入')
          } else if (code == 102) {
            // 展示验证码输入弹窗
            that.$refs.dynamicCodeConfirm.show()
            that.timeCountDownFunc()
          } else {
            that.$refs.dynamicCodeConfirm.hide()
            that.closeDynamicConfirm()
            // 100-到还款中页面，200-到还款成功页面，其他-到还款失败页面
            that.$routerPush(repayResultPage)
          }
        }
      }, (err) => {
        that.showLoading = false
        let code = err.respCode
        // 有订单在还款中
        if (code === "1103") {
          // 对不起，该笔订单有一笔还款还在确认中，请稍后重试
          let msg = err.respMsg
          if (that.order.loanPeriod > 1) {
            msg += `<p>还款金额：&yen;${repay.repayAmount}</p><p>还款期次：第${repay.repayPeriod}期</p>`
          }
          // alert(msg + '-----' + JSON.stringify(repay))
          that.showConfirm({
            txt: msg,
            sureTxt: '我知道了',
          })
        } else if (code === '1220') {
          // 还款计划有更新，请查看
          that.getOrderDetail()
          if (that.showPeriodChoose) {
            that.switchPeriodChooseShow(false)
          }
        }
      })
    },
    // 查询获取验证码
    getDynamicCodeFun (eventId) {
      let that = this
      that.md50td(eventId)
      that.applyRepayFunc()
    },
    // 展示借款失败原因
    showTips (eventId) {
      let that = this
      that.md50td(eventId)
      that.showConfirm({
        onConfirm: function () {
          that.md50td('ddxq;jksbyytc;w218')
        },
        txt: that.order.loanFailReason,
        txtStyle: 'center',
      })
    },
    // 其他信息展示隐藏
    switchOtherInfo () {
      let that = this
      that.showAllOtherInfo = !that.showAllOtherInfo
    },
    // 点击查看相关协议
    showContracts (eventId) {
      let that = this
      that.md50td(eventId)
      that.contracts.show = true
    },
    // 关闭协议弹窗
    closeProtocolPopup () {
      this.contracts.show = false
    },
    // 点击查看协议
    goProtocol (url, title) {
      this.closeProtocolPopup()
      this.$appInvoked("appOpenWebview", {
        url: url,
        nav: {
          title: {
            text: title,
          },
        },
      })
    },
    dynamicCodeConfirmFun (eventId) {
      let that = this
      that.md50td(eventId)
      let dynamicNum = that.dynamicNum
      if (dynamicNum.length === 0) {
        utils.toastMsg('短信验证码不能为空')
      } else {
        that.applyRepayFunc(dynamicNum)
      }
    },
    dynamicCodeCancelFun (eventId) {
      let that = this
      that.md50td(eventId)
      that.closeDynamicConfirm()
    },
    // 关闭验证码弹窗时，初始化定时器状态
    closeDynamicConfirm () {
      let that = this
      if (that.timer) {
        clearInterval(that.timer)
      }
      that.sendAgainFlag = false
      that.countDownTime = 60
    },
    // 获取订单详情
    getOrderDetail () {
      let that = this
      // console.error('getOrderDetail')
      that.showLoading = true
      let params = {
        loanOrderNo: that.loanOrderNo,
        orderNo: that.orderNo,
        queryPartner: 1,
        productId: that.productId,
      }
      // console.error(JSON.stringify(params))
      getDetailOrRepayPlanApi(params).then((data) => {
        data = data.body
        that.showLoading = false
        // data = {
        //   orderDetailVo: { //订单详情
        //     applyTime: "2019-03-13", // 申请时间 yyyy-MM-dd
        //     arriveMoney: "3700", // 到账金额
        //     loanBankCard: "62235625255145251", // 借款银行卡
        //     loanBankName: "工商银行", // 借款银行卡
        //     loanFailReason: "借款失败原因", // 借款失败原因
        //     loanLimit: "7", // 借款期限
        //     loanMoney: "5000", // 借款金额
        //     loanPeriod: "5", // 借款期数
        //     orderStatus: 401, // 订单状态 302：借款失败 301:待还款 402：已结清 401：逾期
        //     preferActivities: "", // 优惠活动
        //     repayBankCard: "62235625255145252", // 还款银行卡
        //     repayBankName: "建设银行", // 还款银行卡
        //     productName: '小鹅贷',
        //     productLog: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201809/3ba0972f5870f7690880ed040fd0a3b1.png'
        //   },
        //   pageRepayPlanVo: [
        //     { money: "1032.23", period: 1, repaidMoney: "1032.23", repayTime: "2019-05-01", settleTime: "2015-05-03", status: 2 },
        //     { money: "1032.23", period: 2, repaidMoney: "1032.23", repayTime: "2019-05-01", settleTime: "2015-05-03", status: 2 },
        //     { money: "1032.23", period: 3, repaidMoney: "0", repayTime: "2019-05-01", settleTime: "2015-05-03", status: 3 },
        //     { money: "1032.23", period: 4, repaidMoney: "0", repayTime: "2019-05-01", settleTime: "2015-05-03", status: 1 },
        //     { money: "1032.23", period: 5, repaidMoney: "0", repayTime: "2019-05-01", settleTime: "2015-05-03", status: 1 }
        //   ]
        // }
        // data.pageRepayPlanVo =
        //     [{ money: "1032.23", period: 1, repaidMoney: "1032.23", repayTime: "2019-05-01", settleTime: "2015-05-03", status: 2 },
        //     { money: "1032.23", period: 2, repaidMoney: "0", repayTime: "2019-05-01", settleTime: "2015-05-03", status: 2 },
        //     { money: "1032.23", period: 3, repaidMoney: "0", repayTime: "2019-05-01", settleTime: "2015-05-03", status: 3 },
        //     { money: "1032.23", period: 4, repaidMoney: "0", repayTime: "2019-05-01", settleTime: "2015-05-03", status: 1 },
        //     { money: "1032.23", period: 5, repaidMoney: "0", repayTime: "2019-05-01", settleTime: "2015-05-03", status: 1 }]
        // data.orderDetailVo.loanPeriod = '5'
        let repayPlan = data.pageRepayPlanVo
        that.order = data.orderDetailVo
        that.productName = data.orderDetailVo.productName
        that.bankCfg.actionId = data.orderDetailVo.repayBankCard
        that.repayPlan = repayPlan
        if (!repayPlan || repayPlan.length === 0) {
          that.noRepayPlan = true
        } else {
          that.noRepayPlan = false
          that.computedMinRepayPeriod(repayPlan)
        }
      }, () => {
        that.showLoading = false
      })

      // setTimeout(() => {
      //   that.showLoading = false
      // }, 20000)
    },
    // 获取协议
    getContracts () {
      let that = this
      // console.error('getContracts')
      // console.error(JSON.stringify({
      //   applyNo: that.orderNo,
      //   loanNo: that.loanOrderNo,
      //   type: 4,
      //   productId: that.productId
      // }))
      that.showLoading = true
      requestApplyLoanProtocolApi({
        applyNo: that.orderNo,
        loanNo: that.loanOrderNo,
        type: 4,
        productId: that.productId,
      }).then((data) => {
        data = data.body
        // let data = [
        //   {agreeName: '注册协议1', agreeUrl: 'https://www.baidu.com'},
        //   {agreeName: '注册协议2', agreeUrl: 'https://www.baidu.com'},
        //   {agreeName: '注册协议3', agreeUrl: 'https://www.baidu.com'},
        //   {agreeName: '注册协议4', agreeUrl: 'https://www.baidu.com'}
        // ]

        // let contracts = []
        // for (let i = 0; i < data.length; i++) {
        //   contracts.push({title: data[i].agreeName, url: data[i].agreeUrl})
        // }
        that.contracts.list = data
        that.showLoading = false
      }, () => {
        that.showLoading = false
      })
      // setTimeout(() => {
      //   that.showLoading = false
      // }, 20000)
    },
    // 验证码倒计时
    timeCountDownFunc: function () {
      let that = this
      let timer = that.timer
      that.sendAgainFlag = false
      clearInterval(timer)
      that.countDownTime = 60
      that.dynamicNum = ''
      that.timer = setInterval(() => {
        that.countDownTime--
        if (that.countDownTime <= 0) {
          that.sendAgainFlag = true
          that.countDownTime = 60
          clearInterval(that.timer)
        }
      }, 1000)
    },
    // 展示弹窗
    showConfirm (confirm) {
      let that = this
      confirm = Object.assign({}, {
        whiteSpace: false,
        title: '温馨提示',
        sureTxt: '确认',
        onConfirm: function () {
          // 
        },
        txt: '',
        txtStyle: 'left',
      }, confirm)
      that.confirm = confirm
      that.$nextTick(function () {
        that.$refs.tipsComfirm.show()
      })
    },
    // 武林榜 & TD埋点
    md50td (eventId, type) {
      type = type || 0 // 0或者没有eventType参数代表上传TD和移动武林榜； 1 上传TD； 2 上传移动武林榜；
      if (eventId) {
        this.$appInvoked('appExecStatistic', { eventId: eventId, eventType: type });
      }
    },
    // 设置头部方法：type：detail-订单详情头，period-期次选择头
    setHeader (type) {
      let that = this
      that.title = type === 'period' ? '还款' : '订单详情'
      that.pageType = type
    },
    // 期次选择切换动画
    switchPeriodChooseShow (bol) {
      if (bol) {
        this.transitionName = 'slide-right'
        this.$nextTick(() => {
          this.showPeriodChoose = true
          this.setHeader('period')
        })
      } else {
        this.transitionName = 'slide-left'
        this.$nextTick(() => {
          this.showPeriodChoose = false
          this.setHeader('detail')
        })
      }
    },
    // 计算当前最小还款期次
    computedMinRepayPeriod (repayPlan) {
      let that = this
      let minRepayPeriod
      // let repay
      let selectPeriodIdx
      for (let i = 0; i < repayPlan.length; i++) {
        if (repayPlan[i].status != 2) {
          // 不是未结清
          minRepayPeriod = repayPlan[i].period
          selectPeriodIdx = i
          // repay = repayPlan[i]
          break
        }
      }
      // that.repayInfos = {
      //   repayAmount: Number(repay.money - repay.repaidMoney).toFixed(2), // 实际还款金额，应还金额（money）- 已还金额（repaidMoney）
      //   repayPeriod: repay.period, // 还款期次，多期的话期次逗号隔开
      //   shouldAmount: repay.money // 应还金额，多期为多期的应还金额（money）之和
      // }
      that.minRepayPeriod = minRepayPeriod
      that.selectPeriodIdx = selectPeriodIdx
    },
    // 计算还款信息
    computedRepayInfos (repayPlan, cb) {
      let that = this
      let repayAmount = 0 //实际还款金额
      let repayPeriod = [] // 还款期次
      let shouldAmount = 0 // 应还金额
      for (let i = 0; i < repayPlan.length; i++) {
        let repay = repayPlan[i]
        repayAmount += Number(repay.money - repay.repaidMoney)
        repayPeriod.push(repay.period)
        shouldAmount += Number(repay.money)
      }
      let repayInfos = {
        repayAmount: repayAmount.toFixed(2),
        repayPeriod: repayPeriod.join(','),
        shouldAmount: shouldAmount.toFixed(2),
      }
      that.repayInfos = repayInfos
      that.$nextTick(() => {
        cb && cb(repayInfos)
      })
    },
  },
}
</script>
<style lang="scss" scoped>
.od-head-bg {
  position: relative;
  height: rc(350);
  padding-left: rc(30);
  padding-top: rc(60);
  box-sizing: border-box;
  color: #fff;
  background-image: linear-gradient(83deg, #ff7523 0%, #ffbd74 100%);
  &.order-status {
    &-302 {
      background-image: linear-gradient(90deg, #6794f8 0%, #abc3fe 100%);
      .ohb-icon {
        background-image: url(../../../static/images/order_img_fail.png);
      }
    }
    &-301 {
      background-image: linear-gradient(83deg, #ff7523 0%, #ffbd74 100%);
      .ohb-icon {
        background-image: url(../../../static/images/order_img_normal.png);
      }
    }
    &-402 {
      background-image: linear-gradient(90deg, #d9d9d9 0%, #b2b1af 100%);
      .ohb-icon {
        background-image: url(../../../static/images/order_img_over.png);
      }
    }
    &-401 {
      background-image: linear-gradient(90deg, #ffb08d 0%, #fd5a47 100%);
      .ohb-icon {
        background-image: url(../../../static/images/order_img_overdue.png);
      }
    }
  }
  .ohb-title {
    font-size: rc(26);
    line-height: rc(37);
  }
  .ohb-status {
    margin-top: rc(15);
    font-size: rc(54);
    line-height: rc(75);
    font-weight: bold;
    display: flex;
    align-items: center;
    .ohb-tips {
      width: rc(74);
      height: rc(75);
      background: url(../../../static/images/ask.png) no-repeat center;
      background-size: rc(38 38);
    }
  }
  .ohb-icon {
    width: rc(150);
    height: rc(150);
    background-repeat: no-repeat;
    background-position: center center;
    background-size: 100% 100%;
    position: absolute;
    top: rc(50);
    right: rc(50);
  }
}
.info-card {
  margin-top: rc(-110);
}
.hqwy-card {
  .hy-1px-b:last-child::after {
    border-bottom: 0;
  }
}
.card-head-infos {
  padding: rc(40 30);
  display: flex;
  align-items: flex-start;
  .chi-left {
    width: rc(80);
    height: rc(80);
    border-radius: rc(12);
    border: solid 1px #e6e6e6;
    margin-right: rc(30);
  }
  .chi-right {
    flex: 1;
  }
  .chir-title {
    font-size: rc(30);
    line-height: rc(42);
    font-weight: bold;
    color: #111111;
  }
  .chir-tips {
    margin-top: rc(7);
    font-size: rc(24);
    line-height: rc(33);
    color: #999;
  }
}
.repay-bank-change {
  font-size: rc(30);
  color: #ff601a;
  margin-left: rc(20);
}
.split-dotted-half-circle {
  height: 1px;
  border-bottom: 1px dotted #e5e5e5;
  margin: rc(0 30);
  position: relative;
  &::before,
  &::after {
    content: '';
    position: absolute;
    width: rc(10);
    height: rc(20);
    top: 50%;
    transform: translateY(-50%);
    background-color: #f2f2f2;
  }
  &::before {
    left: rc(-30);
    border-radius: rc(0 20 20 0);
  }
  &::after {
    right: rc(-30);
    border-radius: rc(20 0 0 20);
  }
}
.od-btn {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  padding: rc(20 30);
  background-color: #f5f5f5;
}
.fiexd-btn-placeholder {
  height: rc(136);
}
.repay-plan,
.other-infos {
  margin-top: rc(20);
}
.repay-plan-table {
  width: 100%;
  font-size: rc(28);
  tr {
    line-height: rc(80);
    &.no-repay-plan {
      line-height: rc(200);
      font-size: rc(28);
      color: #aaa;
    }
    td {
      text-align: center;
    }
  }
  thead {
    background-color: #f9f9f9;
  }
  .show-arrow {
    padding-right: rc(30);
    position: relative;
    &::after {
      content: '';
      position: absolute;
      top: 50%;
      right: rc(30);
      transform: translateY(-50%);
      background: url(../../../static/images/arrow.png) no-repeat center;
      background-size: 100% 100%;
      width: rc(15);
      height: rc(26);
    }
  }
}
#loading.loading {
  position: fixed !important;
  bottom: 0;
}
.cardList {
  padding: rc(0 36);
  margin-top: rc(40);
  li {
    height: rc(98);
    display: flex;
    align-items: center;
    position: relative;
    width: 100%;
    font-size: rc(30);
    > span {
      width: rc(170);
      color: #444;
    }
    > input {
      flex: 1;
    }
  }
  .countDown {
    font-size: rc(26);
    color: #aaa;
    text-align: right;
    display: block;
    position: absolute;
    right: 0;
    top: rc(30);
  }
  .btnAgain {
    font-size: rc(26);
    color: #1473ff;
    text-align: right;
    position: absolute;
    right: 0;
    top: rc(30);
  }
  & + .setTip {
    font-size: rc(26);
    color: #777777;
    text-align: left;
    font-size: rc(26);
    margin-top: rc(20);
    span {
      color: #ff9d00;
    }
  }
}
.period-choose {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #f2f2f2;
  z-index: 98;
  overflow-y: auto;
  transition: all 0.6s cubic-bezier(0.55, 0, 0.1, 1);
  .period-choose-title {
    font-size: rc(32);
    line-height: rc(45);
    margin: rc(28 30 15);
  }
}
.period-list {
  background-color: #fff;
  padding-left: rc(30);
  margin-bottom: rc(126);
  .period-item {
    display: flex;
    align-items: center;
    height: rc(166);
    padding-right: rc(30);
  }
  li.bb-1px:last-child::after {
    border: 0;
  }
  .period-center {
    flex: 1;
  }
  .period-amount {
    font-size: rc(36);
    line-height: rc(50);
    margin-bottom: rc(11);
  }
  .period-date,
  .period-count,
  .period-status {
    color: #999;
    font-size: rc(26);
    line-height: rc(37);
  }
  .period-status {
    margin-top: rc(17);
  }
  .period-right {
    text-align: right;
  }
  // .period-arrow {
  //   width: rc(14);
  //   margin-left: rc(19);
  // }
}
.period-repay-bottom {
  position: fixed;
  z-index: 99;
  left: 0;
  right: 0;
  bottom: 0;
  height: rc(96);
  display: flex;
  align-items: center;
  background-color: #fff;
  padding-left: rc(30);
  .period-select-all-tips {
    font-size: rc(30);
  }
  .period-amount-total {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    font-size: rc(30);
    span {
      font-size: rc(40);
    }
  }
  .period-repay-btn {
    margin-left: rc(22);
    font-size: rc(36);
    color: #fff;
    text-align: center;
    width: rc(230);
    line-height: rc(96);
    // height: 100%;
    background-image: linear-gradient(90deg, #ff5b00 0%, #ff8f00 100%);
  }
}
.period-select {
  margin-right: rc(39);
}
.period-select-all {
  margin-right: rc(22);
}
.period-select,
.period-select-all {
  width: 22px;
  height: 22px;
  background: url(../../../static/images/#{$APP_NAME}/order_check_normal.png) no-repeat center;
  background-size: 100% 100%;
  &.disabled {
    background-image: url(../../../static/images/order_check_disabled.png);
  }
  &.selected {
    background-image: url(../../../static/images/#{$APP_NAME}/order_check_selected.png);
  }
}
.rp-c {
  &1 {
    color: #ff601a !important;
  }
  &2 {
    color: #999 !important;
  }
  &3 {
    color: #f94336 !important;
  }
}
</style>
