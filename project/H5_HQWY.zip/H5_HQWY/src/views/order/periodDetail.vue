<template>
  <PageView id="hqwy-mescroll"
            type="mescroll"
            title="当期详情"
            right-txt="客服/帮助"
            @rightClick="rightClickHandle">
    <!-- 顶部banner信息 -->
    <div class="od-head-bg"
         :class="'order-status-' + orderStatus">
      <div class="ohb-title">
        状态
      </div>
      <div class="ohb-status">
        <span v-text="orderStatusCfg.txt"></span>
      </div>
      <div class="ohb-icon"></div>
    </div>
    <!-- 期次详情 -->
    <LoanCard type="info-card">
      <div class="bottom-card">
        <OrderCell title="期次"
                   :is-link="false">
          <div>第{{ orderDetail.period }}期</div>
        </OrderCell>
        <OrderCell title="应还日期"
                   :is-link="false">
          <div>{{ orderDetail.repayTime }}</div>
        </OrderCell>
        <OrderCell title="应还本金"
                   :is-link="false">
          <div>{{ "&yen; " +orderDetail.repayPrincipal }}</div>
        </OrderCell>
        <OrderCell title="应还息费"
                   :is-link="false">
          <div>{{ "&yen; " +orderDetail.repayFeeInterest }}</div>
        </OrderCell>
        <OrderCell v-if="orderDetail.repayOverdueFee > 0"
                   title="应还逾期息费"
                   :is-link="false">
          <div>{{ "&yen; " +orderDetail.repayOverdueFee }}</div>
        </OrderCell>
        <OrderCell title="已还金额"
                   :is-link="false">
          <div>{{ "&yen; " + orderDetail.repaidMoney }}</div>
        </OrderCell>
        <OrderCell title="剩余应还金额"
                   :is-link="false">
          <div>{{ "&yen; " + leftRepaidMoney }}</div>
        </OrderCell>
        <OrderCell v-if="orderStatus == 2"
                   title="结清时间"
                   :is-link="false">
          <div>{{ orderDetail.settleTime }}</div>
        </OrderCell>
      </div>
    </LoanCard>
    <Loading v-show="showLoading"></Loading>
    <!-- 右上角“客服/帮助” -->
    <HelpCenter ref="helpCenterModule"
                :product-id="productId"
                :product-name="productName"></HelpCenter>
  </PageView>
</template>
<script>
import LoanCard from "@/components/card/index";
import OrderCell from "@/components/cell/order";
import Loading from "../../components/loading/loading";
import utils from "../../util/utils";
import HelpCenter from '@/components/HelpCenter'


import { getDetailOrRepayPlanApi } from '@/api/controller/api/index.js'

export default {
  components: {
    LoanCard,
    OrderCell,
    Loading,
    HelpCenter,
  },
  data () {
    return {

      // 订单详情	object	查询订单详情时有
      orderDetail: {
        money: "0.00", //	应还金额	string	必填
        period: "0", //	期次	string	查询订单详情时无
        repaidMoney: "0.00", //	已还金额	string	必填
        repayFeeInterest: "0.00", //	应还费息	string	查询订单详情时无
        repayOverdueFee: "0.00", //	应还逾期费息		查询还款计划时有，还款计划状态为待还款时无
        repayPrincipal: "0.00", //	应还本金	string	查询订单详情时无
        repayTime: "", //	应还日期	string	yyyy-MM-dd
        settleTime: "", //	结清时间	string	yyyy-MM-dd 查询还款计划时有，还款计划状态为已结清时有
        status: "", //	状态	string	必填 1:待还款 2:结清 3:逾期
      },

      orderStatus: 1,

      showLoading: false,

      productName: "",
      productId: "",
    };
  },
  computed: {
    leftRepaidMoney () {
      let orderDetail = this.orderDetail
      let tempMoney =
        this.safeParseFloat(orderDetail.repayPrincipal) +
        this.safeParseFloat(orderDetail.repayFeeInterest) +
        this.safeParseFloat(orderDetail.repayOverdueFee) -
        this.safeParseFloat(orderDetail.repaidMoney)
      return tempMoney.toFixed(2)
    },
    orderStatusCfg () {
      let that = this
      let txt // 状态文言
      let btnTxt // 按钮文言
      let btnEventId // 按钮埋点事件id
      let status = that.orderDetail.status + ''
      switch (status) {
        case '1':
          txt = '待还款'
          btnTxt = '再借一笔'
          btnEventId = 'ddxq;zjyb;w212'
          that.showChangeBank = false
          break
        case '2':
          txt = '已结清'
          btnTxt = '立即还款'
          btnEventId = 'ddxq;hk;w213'
          that.showChangeBank = true
          break
        case '3':
          txt = '已逾期'
          btnTxt = '立即还款'
          btnEventId = 'ddxq;hk;w213'
          that.showChangeBank = true
          break
      }
      return {
        txt: txt,
        btnTxt: btnTxt,
        btnEventId: btnEventId,
      }
    },
  },
  beforeRouteLeave (to, from, next) {
    this.$refs.helpCenterModule.hide()
    next()
  },
  // 页面开启的时候调用
  activated () {

    this.productId = this.$route.query.productId
    this.productName = this.$route.query.productName

    setTimeout(() => {
      this.requestData()
    }, 50)
    // this.updateNavigationBar()
    // 进入当前详情埋点
    this.collectEventMD({
      eventId: '11005',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
    });
  },
  methods: {
    rightClickHandle () {
      this.$appInvoked('appExecStatistic', { eventId: 'bzan;bztc;w236', eventType: 0 })
      this.$refs.helpCenterModule.show()
    },
    safeParseFloat (value) {
      let tempValue = !isNaN(parseFloat(value)) ? parseFloat(value) : 0.0
      return tempValue
    },
    requestData () {

      this.showLoading = true

      var params = {
        "loanOrderNo": this.$route.query.loanOrderNo,
        "orderNo": this.$route.query.orderNo,
        "period": this.$route.query.period,
        "productId": this.$route.query.productId,
        "queryPartner": "1",
      }

      getDetailOrRepayPlanApi(params).then(
        (data) => {
          this.showLoading = false
          if (data.respCode !== "1000") {
            utils.toastMsg(data.respMsg)
            return
          }
          data = data.body
          // this.orderDetail = data.pageRepayPlanVo[0]
          let plan = data.pageRepayPlanVo
          let period = params.period
          for (let i = 0; i < plan.length; i++) {
            // eslint-disable-next-line eqeqeq
            if (period == plan[i].period) {
              this.orderDetail = plan[i]
              break
            }
          }
          this.orderStatus = this.orderDetail.status
        },
        () => {
          this.showLoading = false
        }
      )
      // setTimeout(() => {
      //   this.showLoading = false
      // }, 20000)
    },
  },
};

</script>
<style lang="scss" scoped>
.info-card {
  margin-top: rc(-110);
}
.font-bold {
  font-weight: bold;
}
.pd-header {
  width: 100%;
  height: rc(350);
  background-image: linear-gradient(83deg, #ff7523 0%, #ffbd74 100%);
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-direction: row;
  text-align: left;
}
.od-head-bg {
  position: relative;
  height: rc(350);
  padding-left: rc(30);
  padding-top: rc(60);
  box-sizing: border-box;
  color: #fff;
  &.order-status {
    &-3 {
      background-image: linear-gradient(90deg, #ffb08d 0%, #fd5a47 100%);
      .ohb-icon {
        background-image: url(../../../static/images/order_img_overdue.png);
      }
    }
    &-1 {
      background-image: linear-gradient(83deg, #ff7523 0%, #ffbd74 100%);
      .ohb-icon {
        background-image: url(../../../static/images/order_img_normal.png);
      }
    }
    &-2 {
      background-image: linear-gradient(90deg, #d9d9d9 0%, #b2b1af 100%);
      .ohb-icon {
        background-image: url(../../../static/images/order_img_over.png);
      }
    }
  }
  .ohb-title {
    font-size: rc(26);
    line-height: rc(37);
  }
  .ohb-status {
    margin-top: rc(15);
    font-size: rc(54);
    line-height: rc(75);
    font-weight: bold;
    display: flex;
    align-items: center;
    .ohb-tips {
      width: rc(74);
      height: rc(75);
      background: url(../../../static/images/ask.png) no-repeat center;
      background-size: rc(38 38);
    }
  }
  .ohb-icon {
    width: rc(150);
    height: rc(150);
    background-repeat: no-repeat;
    background-position: center center;
    background-size: 100% 100%;
    position: absolute;
    top: rc(50);
    right: rc(50);
  }
}
.info-card {
  padding: rc(28 0);
}
</style>
