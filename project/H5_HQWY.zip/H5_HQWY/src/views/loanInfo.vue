<template>
  <PageView title="基础信息"
            :is-back-page="false"
            :show-error-page="showErrorPage"
            :error-page-info="errorPageInfo"
            @backClick="backClickHandle">
    <div v-if="!showErrorPage"
         key="normal"
         class="loadInfoCon hyapp-page-content">
      <Tip txt="填写真实信息，为您智能推荐产品，通过率高达95%！"></Tip>
      <section class="content">
        <ul>
          <li class="info-item bb-1px"
              :class="{'info-item-line-normal':!userNameLineError, 'info-item-line-error':userNameLineError}">
            <div>姓名</div>
            <div style="position: relative;"
                 class="user-name">
              <input v-if="!idValidated"
                     v-model="userName"
                     class="align-right"
                     :class="{'info-item-text-normal':!userNameTextError, 'info-item-text-error':userNameTextError}"
                     type="text"
                     placeholder="请填写姓名"
                     :readonly="idValidated"
                     @input="userNameTextError = false"
                     @focus="userNameLineError = false">
              <span v-if="idValidated">{{ userName | formateUserName }}</span>
            </div>
            <div v-if="idValidated == true"
                 class="auth-status">
              已实名
            </div>
          </li>
          <li class="info-item bb-1px"
              :class="{'info-item-line-normal':!userIdLineError, 'info-item-line-error':userIdLineError}">
            <div>身份证号</div>
            <div style="position: relative;"
                 class="identity-card">
              <input v-if="!idValidated"
                     v-model="userId"
                     class="align-right"
                     type="text"
                     :class="{'info-item-text-normal':!userIdTextError, 'info-item-text-error':userIdTextError}"
                     placeholder="请输入18位身份证号"
                     :readonly="idValidated"
                     @input="userIdTextError = false"
                     @focus="userIdLineError = false">
              <span v-if="idValidated">{{ userId | formateUserId }}</span>
            </div>
            <div v-if="idValidated == true"
                 class="auth-status">
              已实名
            </div>
          </li>
          <li v-for="(item,index) in showInfo.section[0]"
              :key="index"
              class="info-item bb-1px"
              :class="{'info-item-line-normal':!item.lineError, 'info-item-line-error':item.lineError}"
              @click="openActionSheet(0,index,item.title)">
            <div class="color-333">
              {{ item.title }}
            </div>
            <div :class="['align-right','dis-flex-row','flex-1','dis-inline ','item-detail',item.value != '-1' && item.value != null ? 'color-333':'color-bbb']">
              <span v-if="item.value == null || item.value == -1">请选择</span>
              <span v-for="(tmp,index1) in item.actionList"
                    :key="index1">
                <span v-if="tmp.dictValue == item.value">{{ tmp.dictName }}</span>
              </span>
              <img src="../../static/images/arrow.png"
                   alt>
            </div>
          </li>
        </ul>
        <ul>
          <li v-for="(item,index) in showInfo.section[1]"
              :key="index"
              class="info-item bb-1px"
              :class="{'info-item-line-normal':!item.lineError, 'info-item-line-error':item.lineError}"
              @click="openActionSheet(1,index,item.title)">
            <div class="color-333">
              {{ item.title }}
            </div>
            <div :class="['align-right','dis-flex-row','flex-1','dis-inline ','item-detail',item.value != '-1' && item.value != null ? 'color-333':'color-bbb']">
              <span v-if="item.value == null || item.value == -1">请选择</span>
              <span v-for="(tmp,index1) in item.actionList"
                    v-else
                    :key="index1">
                <span v-if="tmp.dictValue == item.value">{{ tmp.dictName }}</span>
              </span>
              <img src="../../static/images/arrow.png"
                   alt>
            </div>
          </li>
        </ul>
      </section>
      <div class="apply-button">
        <div class="jrcs-btn"
             :class="btnAvailable"
             @click="commitAction">
          下一步
        </div>
      </div>
    </div>
    <div v-if="!showErrorPage"
         slot="dialog"
         key="dialog">
      <!-- 信息确认弹窗 -->
      <Confirm ref="sureComfirm"
               title="确认身份信息"
               cancel-txt="修改"
               sure-txt="确认"
               :btn-same-color="true"
               :close-flag="true"
               @on-confirm="saveLoanInfo()">
        <div class="sure-info">
          <ul class="info-list">
            <li>
              <span class="name">姓名</span>
              <span class="value">{{ userName }}</span>
            </li>
            <li>
              <span class="name">身份证号</span>
              <span class="value"
                    style="white-space: nowrap;">{{ userId }}</span>
            </li>
          </ul>
          <Tip :txt="'确认后无法修改，请务必保证正确'"></Tip>
        </div>
      </Confirm>
      <!-- 信息确认弹窗 end-->
      <!-- 返回挽留弹窗 -->
      <FillInfoBackConfirm ref="backComfirm"
                           :source="source"></FillInfoBackConfirm>
      <!-- 返回挽留弹窗 end -->
      <VLoad :isload="isLoad"></VLoad>
      <Loading v-show="showInfo.isLoading"></Loading>
      <ActionSheet :is-show="isShow"
                   :action-title="actionTitle"
                   :action-list="actionList"
                   @onHideAction="actionHide"
                   @onSelectItem="actionSheetOnSelectItem"></ActionSheet>
    </div>
  </PageView>
</template>
<script>
import ActionSheet from "../components/action-sheet";
import VLoad from "../components/load.vue";
import Confirm from "../components/confirm/index";
import FillInfoBackConfirm from "../components/confirm/FillInfoBackConfirm";
// eslint-disable-next-line no-unused-vars
import idcard from "../../static/js/idcard";
import Loading from "../components/loading/loading";
import Tip from "@/components/tip/index"
import {
  requestCommonDict,
  requestUserInfo,
  requestSaveData,
} from "../../src/api/controller/common";
import utils from "../util/utils.js";

/* eslint-disable eqeqeq */
export default {
  name: "LoanInfo",
  components: {
    VLoad,
    ActionSheet,
    Confirm,
    FillInfoBackConfirm,
    // vAbnor,
    Loading,
    Tip,
  },
  filters: {
    formateUserId: function (str) {
      let frontLen = 4
      let endLen = 4
      var len = str.length - frontLen - endLen;
      if (len <= 0 && str.length > 1) {
        return '*' + str.substring(0, frontLen)
      }
      var star = '';
      for (var i = 0; i < len; i++) {
        star += '*';
      }
      return str.substring(0, frontLen) + star + str.substring(str.length - endLen)
    },
    formateUserName: function (str) {
      let frontLen = 0
      let endLen = 1
      var len = str.length - frontLen - endLen;
      if (len <= 0 && str.length > 1) {
        return '*' + str.substring(0, frontLen)
      }
      var star = '';
      for (var i = 0; i < len; i++) {
        star += '*';
      }
      return str.substring(0, frontLen) + star + str.substring(str.length - endLen)
    },
  },
  data () {
    return {
      isMjb: false, // 是否马甲包
      source: this.$route.query.source, // 页面来源。0-我的>完善贷款信息，1-API产品详情，2-重新智能推荐
      // 用户身份证信息是否禁用
      idValidated: false,
      // 用户 id 格式是否正确
      userIdLineError: false,
      userIdTextError: false,
      // 用户名称格式是否正确
      userNameLineError: false,
      userNameTextError: false,
      // 按钮是否可点
      btnAvaliable: false,

      isShow: false,
      isLoad: "none",
      showInfo: {
        isLoading: false,
        section: [
          [{
            title: "月收入",
            actionList: [],
            value: -1,
            lineError: false,
          },
          {
            title: "学历",
            actionList: [],
            value: -1,
            lineError: false,
          }],
          [{
            title: "芝麻分",
            actionList: [],
            value: -1,
            lineError: false,
          },
          {
            title: "手机号使用时长",
            actionList: [],
            value: -1,
            lineError: false,
          },
          {
            title: "是否有信用卡",
            actionList: [],
            value: -1,
            lineError: false,
          },
          {
            title: "是否缴纳公积金",
            actionList: [],
            value: -1,
            lineError: false,
          }],
        ],
      },
      selectPos: {
        section: "",
        index: "",
      },
      actionList: [],
      actionTitle: "",
      userName: "",
      userId: "",
      showErrorPage: false,
      errorPageInfo: {},
      // reloadText: {
      //   reloadText: "网络异常",
      //   defaultImg: this.getCachedImages("loadFailIcon")
      // },
      userData: "",
    };
  },
  computed: {
    // 提交按钮是否可点击
    btnAvailable () {
      if (
        this.userName != null &&
        this.userName.length > 0 &&
        (this.userId != null && this.userId.length > 0) &&
        (this.showInfo.section[0][0].value != null &&
          this.showInfo.section[0][0].value != -1) &&
        (this.showInfo.section[0][1].value != null &&
          this.showInfo.section[0][1].value != -1) &&
        (this.showInfo.section[1][0].value != null &&
          this.showInfo.section[1][0].value != -1) &&
        (this.showInfo.section[1][1].value != null &&
          this.showInfo.section[1][1].value != -1) &&
        (this.showInfo.section[1][2].value != null &&
          this.showInfo.section[1][2].value != -1) &&
        (this.showInfo.section[1][3].value != null &&
          this.showInfo.section[1][3].value != -1)
      ) {
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        this.btnAvaliable = true;
        return "";
      }
      // eslint-disable-next-line vue/no-side-effects-in-computed-properties
      this.btnAvaliable = false;
      return "disabled";
    },
  },
  activated () {
    this.interceptAppBack()
    this.showErrorPage = false

    let w = this.$route.query.w
    if (w) {
      this.collectEventMD({
        eventId: `ly1006,w${w}`,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
      })
    }
    this.source = this.$route.query.source

    this.$refs.backComfirm && this.$refs.backComfirm.hide()

    // window.loanInfoBack = this.loanInfoBack;
    this.getdictList();
    this.setUpUI();
    this.$appInvoked("appGetBundleId", {}, (rst) => {
      this.isMjb = (rst === 'com.sl.hhsc') || (+rst > 1000) || (+rst < 0);
    })
  },
  mounted () {
    this.collectEventFun('1013')
  },
  methods: {
    // 进入页面事件统计
    collectEventFun (id) {
      let params = {
        eventEndTime: '',
        eventId: id,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
        productId: this.$route.query.productId || '',
      }
      this.collectEventMD(params)
    },
    // 检查 id 有效性
    checkName () {
      // 先去除空格再校验
      this.userName = this.userName.replace(/\s*/g, "");
      // 只能输入中文和点
      let reg = /^[\u4e00-\u9fa5·]+$/
      if (reg.test(this.userName)) {
        return true;
      } else {
        return false;
      }
    },
    // 身份证校验
    checkIdNum () {
      // 去除空格
      this.userId = this.userId.replace(/\s*/g, "");
      // x转X
      this.userId = this.userId.replace("x", "X");
      if (_$id.checkCardNumber(this.userId)) {
        return true;
      } else {
        return false;
      }
    },

    // UI 初始化
    setUpUI () {
      var self = this;
      // 样式初始化
      self.userIdLineError = false;
      self.userIdTextError = false;
      self.userNameLineError = false;
      self.userNameTextError = false;
      // 数据初始化
      self.userName = "";
      self.userId = "";
      self.showInfo.section[0][0].value = -1;
      self.showInfo.section[0][1].value = -1;
      self.showInfo.section[1][0].value = -1;
      self.showInfo.section[1][1].value = -1;
      self.showInfo.section[1][2].value = -1;
      self.showInfo.section[1][3].value = -1;

      for (var i in self.showInfo.section) {
        for (var j in self.showInfo.section[i]) {
          self.showInfo.section[i][j].lineError = false;
        }
      }
    },
    //数据字典接口
    getdictList () {
      var self = this;
      // this.isLoad = "block"; //开始loading
      requestCommonDict({}).then(
        (data) => {
          self.isLoad = "none";
          self.requestUserInfo();
          var repData = data;
          if (repData.respCode === "1000") {
            self.showInfo.section[0][0].actionList = repData.body.income;
            self.showInfo.section[0][1].actionList = repData.body.education;
            self.showInfo.section[1][0].actionList = repData.body.creditScore;
            self.showInfo.section[1][1].actionList = repData.body.phoneUseTime;
            self.showInfo.section[1][2].actionList = repData.body.creditCardFlag;
            self.showInfo.section[1][3].actionList = repData.body.fundFlag;
          }
        },
        () => {
          self.isLoad = "none";
          // self.showErrorPage = true;
          self.initDefaultErrorPageInfos('offline')
        }
      );
    },
    requestUserInfo: function () {
      var self = this;

      requestUserInfo({}).then(
        (data) => {
          var repData = data;
          // console.log("ssslklkdl");
          self.isLoad = "none";
          if (repData.respCode === "1000") {
            self.showErrorPage = false;
            self.idValidated = repData.body.authStatus == 1
            self.userData = repData.body;
            self.userName = repData.body.userName || '';
            self.userId = repData.body.identityCard || ''
            self.showInfo.section[0][0].value = repData.body.income;
            self.showInfo.section[0][1].value = repData.body.education;
            self.showInfo.section[1][0].value = repData.body.creditScore;
            self.showInfo.section[1][1].value = repData.body.phoneUseTime;
            self.showInfo.section[1][2].value = repData.body.creditCardFlag;
            self.showInfo.section[1][3].value = repData.body.fundFlag;

            self.$store.commit("USER_NAME", self.userName)
            self.$store.commit("USER_IDCARD", self.userId)
          }
        },
        () => {
          self.isLoad = "none";
          // self.showErrorPage = true;
          self.initDefaultErrorPageInfos('offline')
        }
      );
    },
    commitAction: function () {
      var self = this;

      self.$appInvoked("appExecStatistic", {
        eventId: "jczl;bc;w201",
        eventType: 0,
      }); //埋点

      if (self.btnAvaliable) {
        // 按钮可点击
        var checkNameFlag = true;
        var checkIDFlag = true;
        if (
          self.userId == null ||
          self.userId.length === 0 ||
          !self.checkIdNum()
        ) {
          self.userIdTextError = true;
          checkIDFlag = false;
        } else {
          self.userIdTextError = false;
        }

        if (
          self.userName == null ||
          self.userName.length == 0 ||
          !self.checkName()
        ) {
          self.userNameTextError = true;
          checkNameFlag = false;
        } else {
          self.userNameTextError = false;
        }

        if (!checkNameFlag) {
          utils.toastMsg("请填写正确的姓名");
          return;
        }

        if (!checkIDFlag) {
          utils.toastMsg("请填写正确的身份证号");
          return;
        }

      } else {
        // 按钮不可点击 线变红
        var checkFlag = true;
        if (self.userId == null || self.userId.length === 0) {
          self.userIdLineError = true;
          checkFlag = false;
        } else {
          self.userIdLineError = false;
        }

        if (self.userName == null || self.userName.length === 0) {
          self.userNameLineError = true;
          checkFlag = false;
        } else {
          self.userNameLineError = false;
        }

        for (var i = 0; i < self.showInfo.section.length; i++) {
          var temp = self.showInfo.section[i];
          for (var j = 0; j < temp.length; j++) {
            if (
              self.showInfo.section[i][j].value == null ||
              self.showInfo.section[i][j].value == -1
            ) {
              self.showInfo.section[i][j].lineError = true;
              checkFlag = false;
            } else {
              self.showInfo.section[i][j].lineError = false;
            }
          }
        }

        if (!checkFlag) {
          return;
        }
      }
      if (self.validInputInfo()) {
        if (!this.idValidated) {
          this.$refs.sureComfirm.show()
        } else {
          self.saveLoanInfo();
        }

      } else {
        utils.toastMsg("请至少选择1个条件");
      }
    },
    saveLoanInfo: function () {
      var self = this;
      self.showInfo.isLoading = true;
      var params = {
        userName: self.userName,
        fundFlag: self.showInfo.section[1][3].value,
        creditCardFlag: self.showInfo.section[1][2].value,
        identityCard: self.userId,
        source: 1,
        phoneUseTime: self.showInfo.section[1][1].value,
        income: self.showInfo.section[0][0].value,
        creditScore: self.showInfo.section[1][0].value,
        career: null,
        education: self.showInfo.section[0][1].value,
        // -1 要转成 null
        borrowAmount: self.userData.borrowAmount == -1 ? null : self.userData.borrowAmount,
        borrowPeriod: self.userData.borrowPeriod == -1 ? null : self.userData.borrowPeriod,
        car: self.userData.car == -1 ? null : self.userData.car,
        house: self.userData.house == -1 ? null : self.userData.house,
        socialSecurityFlag: self.userData.socialSecurityFlag == -1 ? null : self.userData.socialSecurityFlag,
      };

      requestSaveData(params).then(
        (resp) => {
          // self.$routerBack(-1);
          self.showInfo.isLoading = false;
          if (resp.respCode == "1000") {
            // this.$appInvoked('appToastMessage', {
            //   'message': '保存成功！'
            // })
            utils.toastMsg('保存成功')
            if (self.isMjb) {
              self.$routerGo(-1)
            } else {
              self.checkNextFillInfos(self.$route.query.w)
            }
          } else {
            utils.toastMsg("保存失败！请重试");
          }
        },
        () => {
          self.showInfo.isLoading = false;
          // this.$appInvoked("appDismissLoadingDialog", "", ""); //关闭loading
          // utils.toastMsg("保存失败！请重试");
        }
      );
    },
    validInputInfo () {
      var self = this;
      if (self.userName || self.userId) {
        return true;
      }
      for (var index in self.showInfo.section) {
        for (var index1 in self.showInfo.section[index]) {
          // console.log(self.showInfo.section[index][index1]);
          var val = self.showInfo.section[index][index1].value;
          // console.error(val);
          if (val != null && val != -1) {
            return true;
          }
        }
      }
      return false;
    },
    // inputHasOnceSave () {
    //   var self = this;
    //   if (self.userName || self.userId) {
    //     return true;
    //   }
    //   for (var index in self.showInfo.section) {
    //     for (var index1 in self.showInfo.section[index]) {
    //       var val = self.showInfo.section[index][index1].value;
    //       // console.error(val);
    //       if (val != null && val != -1) {
    //         return true;
    //       }
    //     }
    //   }
    //   return false;
    // },
    actionSheetOnSelectItem: function (item, index) {
      var self = this;
      this.isShow = false;
      if (index < 0) {
        return;
      }
      this.showInfo.section[self.selectPos.section][
        self.selectPos.index
      ].value = item.dictValue;
    },
    actionHide: function () {
      this.isShow = false;
      // localStorage.setItem('loaninfo',JSON.stringify(this.showInfo));
    },
    openActionSheet: function (section, index, title) {
      this.showInfo.section[section][index].lineError = false;
      this.selectPos.section = section;
      this.selectPos.index = index;
      this.actionList = this.showInfo.section[section][index].actionList;
      this.actionTitle = title
      this.isShow = true;
    },
    // 返回展示挽留弹窗
    backClickHandle () {
      this.isShow = false;
      if (!this.showErrorPage) {
        this.$refs.backComfirm.show()
      } else {
        this.$routerGo(-1)
      }
      // if (this.inputHasOnceSave()) {
      //   this.isShow = false;
      //   this.$refs.backComfirm.show();
      // } else {
      //   this.backConfirmCancel();
      // }
    },
    // 挽留确认放弃
    // backConfirmCancel () {
    //   if (this.source === '2') {
    //     // 重新推荐逻辑
    //     this.globalRecommendClick('2')
    //   } else {
    //     this.$routerGo(-1);
    //   }
    // },
    formateStar (str, frontLen, endLen) {
      var len = str.length - frontLen - endLen;
      if (len <= 0 && str.length > 1) {
        return '*' + str.substring(0, frontLen)
      }
      var star = '';
      for (var i = 0; i < len; i++) {
        star += '*';
      }
      return str.substring(0, frontLen) + star + str.substring(str.length - endLen);
    },
  },
};
</script>
<style lang="scss">
.loadInfoCon {
  .loading {
    bottom: 0 !important;
  }
}
</style>
<style scoped lang="scss">
.loadInfoCon {
  overflow-y: scroll; //margin-bottom: rc(160);
}

// .content {
//   margin-bottom: rc(160);
// }

.info-item {
  align-items: center;
  display: flex;
  flex-direction: row;

  &.bb-1px:last-child::after {
    border-bottom: 0;
  }
}

.color-bbb {
  color: #bbb;
}

.info-item > div {
  line-height: rc(84);
  font-size: rc(30);
}

.color-333 {
  color: #333;
}

.info-item .align-right {
  flex: 1;
  text-align: right;
  font-size: rc(30);
}

.user-name {
  flex: 1;
  text-align: right;
  font-size: rc(26);
}

.identity-card {
  flex: 1;
  text-align: right;
  font-size: rc(26);
}

section > ul {
  margin-bottom: rc(20);
  background-color: #fff;
  padding-left: rc(30);
}

section > ul:last-child {
  margin-bottom: rc(100);
}

ul > li {
  padding-right: rc(30);
}

ul > li img {
  width: rc(15);
  height: rc(26);
  margin-left: rc(16);
  margin-top: -1px;
}

input {
  width: 100%;
  color: #333;
  height: 100%;
}

.apply-button {
  // position: fixed;
  // bottom: 0;
  // left: 0;
  // right: 0;
  margin-top: rc(60);
  height: rc(96);
  text-align: center;
  // background: #f2f2f2;
  padding: rc(22) rc(30);
  div.jrcs-btn {
    border-radius: rc(100);
    color: #ffffff;
    font-size: rc(34);
    height: 100%;
  }
}

.vertical-middle {
  display: flex;
  /*justify-content: center;*/
  align-items: center;
  margin: 0 auto;
}

.info-item-line-normal:after {
  border-color: #e6e6e6;
}

.info-item-line-error:after {
  border-color: #ff4c4c;
}

.info-item-text-normal {
  color: #333333;
}

.info-item-text-error {
  color: #ff4c4c;
}

.info-item {
  .auth-status {
    margin-left: rc(16);
    text-align: center;
    color: #ff601a;
    border: 1px solid #ff601a;
    border-radius: rc(20);
    width: rc(104);
    font-family: PingFangSC-Regular;
    font-size: rc(22);
    font-weight: normal;
    font-stretch: normal;
    line-height: rc(36);
    height: rc(36);
  }
}

.sure-info {
  font-size: rc(30);
  line-height: rc(32);

  li {
    display: flex;

    &:first-child {
      margin-bottom: rc(24);
    }
  }

  .name {
    width: rc(150);
  }

  p {
    padding: 0;
  }

  .hqwy-tip {
    margin-top: rc(26);
    padding-right: rc(5);
    background-color: #fff;
  }
}
</style>
