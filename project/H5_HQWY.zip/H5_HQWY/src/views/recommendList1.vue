<template>
  <div>
    <VLoad :isload="show.isLoad"></VLoad>
  </div>
</template>

<script>
import VLoad from "../components/load.vue";
import { mapState } from "vuex";
// import { requestUserInfo } from "../../src/api/controller/common";

export default {
  name: "RecommentList1",
  components: {
    VLoad,
    // vAbnor
  },
  data () {
    return {
      show: {
        isLoad: "block",
      },
    };
  },
  computed: {
    ...mapState({
      career: (state) => state.loaninfo.userData.career,
      borrowAmount: (state) => state.loaninfo.userData.borrowAmount,
      borrowPeriod: (state) => state.loaninfo.userData.borrowPeriod,
      creditScore: (state) => state.loaninfo.userData.creditScore,
      phoneUseTime: (state) => state.loaninfo.userData.phoneUseTime,
      creditCardFlag: (state) => state.loaninfo.userData.creditCardFlag,
      fundFlag: (state) => state.loaninfo.userData.fundFlag,
    }),
  },
  activated () {
    // this.queryUserInfo();
    this.globalRecommendClick(1003, '1')
  },
  methods: {
    // queryUserInfo() {
    //   var self = this;
    //   var redPrd; //是否有小红点产品  false没有  true有
    //   var career; //career职业
    //   var borrowAmount; //borrowAmount借多少
    //   var borrowPeriod; // borrowPeriod借多久
    //   var creditScore; // creditScore芝麻分
    //   var phoneUseTime; //phoneUseTime手机号使用时长
    //   var creditCardFlag; //creditCardFlag是否有信用卡
    //   var fundFlag; //fundFlag是否缴纳公积金
    //   var isFill; //用户是否点击过 true点击过   false未点击
    //   if (localStorage.getItem("isFill") == null) {
    //     isFill = "false";
    //   } else {
    //     isFill = localStorage.getItem("isFill");
    //   }
    //   //获取用户有没有填写推荐信息
    //   requestUserInfo({}).then(
    //     data => {
    //       var repData = data;
    //       self.show.isLoad = "none";
    //       //							alert(JSON.stringify(data));
    //       if (repData.respCode == "1000") {
    //         career = repData.body.career; //我是
    //         borrowAmount = repData.body.borrowAmount; //借多少
    //         creditCardFlag = repData.body.creditCardFlag; //是否有信用卡
    //         fundFlag = repData.body.fundFlag; //是否缴纳公积金
    //         phoneUseTime = repData.body.phoneUseTime; //手机号是否使用超过6个月
    //         borrowPeriod = repData.body.borrowPeriod; //借多久
    //         creditScore = repData.body.creditScore; //芝麻分
    //         var totalNum = localStorage.getItem("redPointAll");
    //         var redPointArr = "";
    //         if (localStorage.getItem("redPoint") != null) {
    //           redPointArr = localStorage.getItem("redPoint");
    //         }
    //         var redNumber = totalNum - (redPointArr.split(",").length - 1);
    //         if (redNumber != undefined && parseInt(redNumber) > 0) {
    //           redPrd = true;
    //         } else {
    //           redPrd = false;
    //         }
    //         if (
    //           career != null &&
    //           borrowAmount != null &&
    //           borrowPeriod != null &&
    //           creditScore != null &&
    //           phoneUseTime != null &&
    //           creditCardFlag != null &&
    //           fundFlag != null &&
    //           isFill == "false"
    //         ) {
    //           //用户填写完整 没有点击过
    //           self.$routerReplace("/fillinfo?fromeApp=true");
    //         } else if (
    //           career != null &&
    //           borrowAmount != null &&
    //           borrowPeriod != null &&
    //           creditScore != null &&
    //           phoneUseTime != null &&
    //           creditCardFlag != null &&
    //           fundFlag != null &&
    //           isFill == "true"
    //         ) {
    //           //用户填写完整 点击过
    //           self.$routerReplace(
    //             "/recommendList1?fromeApp=true&occupation=" +
    //               career +
    //               "&amount=" +
    //               borrowAmount +
    //               "&deadline=" +
    //               borrowPeriod +
    //               "&zhima=" +
    //               creditScore +
    //               "&creditCard=" +
    //               creditCardFlag +
    //               "&fund=" +
    //               fundFlag +
    //               "&phoneNumServiceTime=" +
    //               phoneUseTime
    //           );
    //         } else if (
    //           (career != null ||
    //             borrowAmount != null ||
    //             borrowPeriod != null ||
    //             creditScore != null ||
    //             phoneUseTime != null ||
    //             creditCardFlag != null ||
    //             fundFlag != null) &&
    //           redPrd == false
    //         ) {
    //           //没有填写完整 并且没有小红点产品
    //           self.$routerReplace("/fillinfo?fromeApp=true");
    //         } else if (
    //           (career != null ||
    //             borrowAmount != null ||
    //             borrowPeriod != null ||
    //             creditScore != null ||
    //             phoneUseTime != null ||
    //             creditCardFlag != null ||
    //             fundFlag != null) &&
    //           redPrd == true
    //         ) {
    //           //没有填写完整 有小红点产品
    //           self.$routerReplace(
    //             "/recommendList1?fromeApp=true&occupation=" +
    //               career +
    //               "&amount=" +
    //               borrowAmount +
    //               "&deadline=" +
    //               borrowPeriod +
    //               "&zhima=" +
    //               creditScore +
    //               "&creditCard=" +
    //               creditCardFlag +
    //               "&fund=" +
    //               fundFlag +
    //               "&phoneNumServiceTime=" +
    //               phoneUseTime
    //           );
    //         } else {
    //           self.$routerReplace("/fillinfo?fromeApp=true");
    //         }
    //       } else {
    //         self.show.isAbnomal = true;
    //       }
    //     },
    //     err => {
    //       self.show.isAbnomal = true;
    //     }
    //   );
    // }
  },
};
</script>

<style scoped>
</style>
