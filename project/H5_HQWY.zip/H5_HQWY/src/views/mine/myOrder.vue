<template>
  <PageView id="hqwy-mescroll"
            type="mescroll"
            title="我的订单">
    <!-- TAB -->
    <ul class="mo-tab">
      <li v-for="(tab, index) in tabList"
          :key="index"
          class="mo-tab-item bb-1px"
          @click="switchTab(tab.remarkType)">
        <div class="mo-tab-name"
             :class="{'cur-tab':curTabType==tab.remarkType}"
             v-text="tab.remarkName">
             <!-- <span class="mo-tab-title yuqi" v-if="tab.remarkType==3&&overdueMark" v-text="tab.remarkName"></span>
          <span class="mo-tab-title" v-else :class="{'dot': tabSts[tab.remarkType]==1}" v-text="tab.remarkName"></span> -->
        </div>
      </li>
    </ul>
    <!-- 页面主体内容 -->
    <section class="mo-content">
      <!-- 订单列表 -->
      <div id="mescroll"
           ref="orderListRef"
           class="mescroll">
        <ul v-if="orderList && orderList.length > 0"
            class="mo-order">
          <li v-for="(order, index) in orderList"
              :key="index"
              class="mo-order-item"
              @click="orderClick(order, index)">
            <div class="mo-order-top bb-1px">
              <!-- <img class="mo-order-top-logo" v-lazy="{src: order.productLogo, error: productIcon, loading: productIcon}"> -->
              <img class="mo-order-top-logo"
                   :src="order.productLogo">
              <div class="mo-order-top-name"
                   v-text="order.productName"></div>
              <!-- 审核中（103）、待提现（201）、待还款（301）、已逾期（401）、已结清（402）、审核失败（202） -->
              <div class="mo-order-top-sts"
                   v-text="order.orderStatusTxt"></div>
            </div>
            <div class="mo-order-content">
              <!-- 待提现展示3栏，其他2栏 -->
              <div class="mo-order-info">
                <div v-for="(i, index) in order.infos"
                     :key="index"
                     class="mo-order-info-item">
                  <div class="mo-order-info-value"
                       v-html="i.value"></div>
                  <div class="mo-order-info-key"
                       v-text="i.key"></div>
                </div>
                <div class="mo-order-btn b-1px"
                     :class="order.btn.style"
                     v-text="order.btn.txt"></div>
              </div>
            </div>
            <div class="mo-order-bottom"
                 v-text="order.bottomTxt"></div>
          </li>
        </ul>
      </div>
      <!-- 无订单状态 -->
      <div v-if="showNoData"
           class="no-order">
        <img class="no-order-icon"
             :src="require('APP_IMG/qsy_wdd.png')">
        <p class="no-order-tips">
          给自己定个小目标，先借它一笔
        </p>
        <p class="no-order-btn jrcs-btn"
           @click="applyNow()">
          去借款
        </p>
      </div>
    </section>
    <!-- Loading -->
    <Loading v-show="showLoading"></Loading>
    <!-- 花钱无忧Loading -->
    <!-- <v-load :isload="false"></v-load> -->
  </PageView>
</template>
<script>
import Loading from "../../components/loading/loading"
// import vLoad from "../../components/load"

import MeScroll from "mescroll.js"

import utils from "../../util/utils"

import {
  getOrderListApi,
  // orderCheckApi,
} from "../../api/controller/mine/order";
import { updateStatusApi } from "../../api/controller/common/index";
import { requestLoanResultQueryApi } from '@/api/controller/loan/index'
/* eslint-disable eqeqeq */
export default {
  name: 'OrderCenter',
  components: {
    Loading,
    // vLoad,
  },
  data () {
    return {
      showLoading: false,
      productIcon: this.getCachedImages("productIcon") || require("APP_IMG/default.png"), //产品缩略占位图,
      /**
       * tab列表
       * remarkType：0:全部 1:审核中 2:待提现 3:待还款 4:已结束
       * remarkStatus：0 未标记，1 已标记
       */
      tabList: [
        { remarkType: 0, remarkName: '全部' },
        { remarkType: 1, remarkName: '审核中' },
        { remarkType: 2, remarkName: '待提现' },
        { remarkType: 3, remarkName: '待还款' },
        { remarkType: 4, remarkName: '已结束' },
      ],
      // tabSts: {0: 0, 1: 0, 2: 0, 3: 0, 4: 0}, // tab标记状态，默认均为未标记
      w: { 0: 202, 1: 203, 2: 204, 3: 205, 4: 206 }, // 埋点字段
      curTabType: this.$route.query.type || 0, // 当前tab
      // overdueMark: false, // 是否有逾期：布尔类型
      // remark: false, // 是否有小红点
      showNoData: false, // 是否展示无订单空状态

      orderList: [], // 订单列表
      pageSize: 10,
      mescroll: null,
    };
  },
  computed: {},
  watch: {
    '$route' (to, from) {
      let that = this;
      if (from.name === 'mycenter' && to.name === 'order') {
        // 初始化页面数据
        let curTabType = this.$route.query.type || 0;
        that.curTabType = curTabType
        // that.overdueMark = false;
        that.showNoData = false;
        that.orderList = [];
        if (that.mescroll) {
          that.mescroll.setPageNum(1);
        }
        that.getOrderListFunc(curTabType, 1);
      } else if (to.name === 'order') {
        // 从订单详情返回，刷新列表数据
        that.getOrderListFunc(that.curTabType, 1);
      }
    },
  },
  beforeRouteLeave (to, from, next) {
    if (this.$refs.orderListRef != undefined) {
      global.storage.set("orderScrollTop", this.$refs.orderListRef.scrollTop);
    }
    next();
  },
  beforeRouteEnter (to, from, next) {
    if (from.path === "/mycenter") {
      global.storage.set("orderScrollTop", 0);
    }
    next((vm) => {
      setTimeout(() => {
        if (vm.$refs.orderListRef != undefined) {
          vm.$refs.orderListRef.scrollTop =
            global.storage.get("orderScrollTop") || 0;
        }
      }, 0);
    });
  },
  updated () {
    this.$nextTick(() => {
      if (this.$refs.orderListRef != undefined) {
        this.$refs.orderListRef.scrollTop = global.storage.get(
          "orderScrollTop"
        );
      }
    });
  },
  activated () {
    let that = this;
    if (!that.mescroll) {
      that.initMescroll();
    }
  },
  // mounted() {
  //   let that = this;
  //   that.initMescroll();
  // },
  methods: {
    // tab切换
    switchTab (remarkType) {
      let that = this;
      // 重复点击当前tab不重新请求接口
      if (that.curTabType == remarkType) {
        return;
      }
      that.showLoading = true;
      that.curTabType = remarkType;
      that.orderList = [];
      that.mescroll.endUpScroll(false);
      that.getOrderListFunc(remarkType, 1);
      // if(remarkType==3 && that.overdueMark) {
      //   let curDate = new Date();
      //   localStorage.setItem('hideOverdueMarkDate', curDate.getFullYear() + '-' + (curDate.getMonth() + 1) + '-' + curDate.getDate());
      //   that.overdueMark = false;
      //   that.$store.commit('orderDotRemark', {
      //     overDue: false,
      //     remark: that.remark
      //   });
      // }
      if (remarkType == 4) {
        // 调用接口标记小红点已读
        updateStatusApi({ remarkType: remarkType, remarkStatus: 0 });
      }
    },
    // 订单点击
    orderClick (order, index) {
      let that = this;
      // 是否为立即贷API产品
      let isLJDAPI = window.$config.get('LJDPRODUCTID') == order.productId
      // let curTabType = that.curTabType;
      let eventId = `chanpin0;w${that.w[that.curTabType]};p${index + 1};c${order.productId};l${window.$config.get('events.linkSeqId')};t0`;
      that.$appInvoked('appExecStatistic', { eventId: eventId, eventType: 2 });
      that.clickReport(order.productId, '12', eventId);
      let orderStatus = order.orderStatus;
      let commonParams = `orderNo=${order.orderId}&productName=${order.productName}&productId=${order.productId}`

      // 撞库页面
      let loanHitPage = `/loanHit?${commonParams}&category=12&p=${index + 1}&w=${that.w[that.curTabType]}`;
      // 立即贷审核中、审核失败页面
      let checkResultPage = `/checkResult?productName=${order.productName}&nextApplyTime=${order.nextApplyTime}&applyTime=${order.applyTime}&applyNeedTime=${order.applyNeedTime}&status=`;
      // API产品-审核中页面
      let loanInAuditPage = `/loan/inAudit?${commonParams}`
      // API产品-待提交订单
      let submitOrderPage = `/loan/submitOrder?${commonParams}&loanOrderNo=${order.loanOrderNo}`
      // API产品-确认用款
      let confirmLoanPage = `/loan/confirmLoan?${commonParams}&loanOrderNo=${order.loanOrderNo}`
      // API产品-放款中
      let onLoanPage = `/loan/onLoan?${commonParams}&loanOrderNo=${order.loanOrderNo}`
      // API产品-放款成功、失败
      let auditResultPage = `/loan/auditResult?${commonParams}&loanOrderNo=${order.loanOrderNo}&status=`
      // 订单详情页面
      let orderDetailPage = `/order/detail?${commonParams}&loanOrderNo=${order.loanOrderNo}&category=12&p=${index + 1}&w=${that.w[that.curTabType]}`;
      // 101-资料提交中做审核中处理，审核中（103）、待提现（201）、待还款（301）、已逾期（401）、已结清（402）、审核失败（202）
      // 302：放款失败、303：待确认用款、304：放款中、104：待补充资料、403：订单自动完结（自动失效订单，不会返回，无需处理）
      if (orderStatus == 103 || orderStatus == 101) {
        // 审核中，查看审批结果
        if (isLJDAPI) {
          that.$routerPush(checkResultPage + 2);
        } else {
          that.$routerPush(loanInAuditPage)
        }
      } else if (orderStatus == 201) {
        // 待提现，再次撞库
        if (isLJDAPI) {
          that.$routerPush(loanHitPage);
        } else {
          that.$routerPush(submitOrderPage)
        }
      } else if ([301, 302, 401, 402].indexOf(Number(orderStatus)) > -1) {
        // 待还款、放款失败、已逾期、已结清跳转订单详情
        if (orderStatus == 402 && !order.undercarriage) {
          utils.toastMsg('产品已下架，请浏览其它产品')
          return
        }
        that.$routerPush(orderDetailPage)
        // } else if([301, 401].indexOf(orderStatus) > -1) {
        //   that.showLoading = true;
        //   // 待还款、已逾期，查询订单状态
        //   let params = {
        //     orderNo: order.orderId,
        //     productId: order.productId
        //   };
        //   orderCheckApi(params).then(data => {
        //     data = data.body;
        //     this.$appInvoked('appOpenWebview', {
        //       url: data.link,
        //       nav: {
        //         title: {
        //           text: order.productName
        //         }
        //       }
        //     });
        //     that.showLoading = false;
        //   }, err => {
        //     that.showLoading = false;
        //   });
        // } else if(orderStatus == 402) {
        //   // 已结清，再次撞库
        //   if(order.undercarriage) {
        //     that.$routerPush(loanHitPage);
        //   } else {
        //     utils.toastMsg('产品已下架，请浏览其它产品');
        //   }
      } else if (orderStatus == 202) {
        // 审核失败，<=30天 审核失败页，>30天，再次撞库
        if (!order.undercarriage) {
          utils.toastMsg('产品已下架，请浏览其它产品');
        } else if (order.storehouse) {
          that.$routerPush(loanHitPage);
        } else {
          // 审核失败页
          that.$routerPush(checkResultPage + 1);
        }
      } else if (orderStatus == 303) {
        // 待确认用款
        that.$routerPush(confirmLoanPage)
      } else if (orderStatus == 304) {
        // 放款中，调用接口查询放款状态
        that.showLoading = true
        requestLoanResultQueryApi({
          loanOrderNo: order.loanOrderNo,
          orderNo: order.orderId,
        }).then((data) => {
          that.showLoading = false
          data = data.body
          let loanStatus = data.loanStatus // 0：放款中 1：成功 2：失败
          if (loanStatus == 1) {
            that.$routerPush(auditResultPage + 2)
          } else if (loanStatus == 2) {
            that.$routerPush(auditResultPage + `1&loanStatusDesc=${data.loanStatusDesc}`)
          } else {
            that.$routerPush(onLoanPage)
          }
        }, () => {
          that.showLoading = false
        })
      } else if (orderStatus == 104) {
        // 待补充资料撞库
        that.$routerPush(loanHitPage)
      }
    },
    // 无订单立即申请
    applyNow () {
      let that = this;
      that.$appInvoked('appExecStatistic', { eventId: 'wddd;ljsq;w207' });
      that.$routerPush('/productlist');
    },
    // 查询小红点状态
    // queryStatusFunc() {
    //   let that = this;
    //   queryStatusApi().then(data => {
    //     data = data.body;
    //     let remark = false;
    //     // 刷新时清除小红点
    //     for(var i in that.tabSts) {
    //       that.tabSts[i] = 0;
    //     }

    //     for(let i = 0, l = data.redRemarkList.length; i < l; i++) {
    //       let item = data.redRemarkList[i];
    //       that.tabSts[item.remarkType] = item.remarkStatus;
    //       if(item.remarkStatus == 1) {
    //         remark = true;
    //       }
    //     }
    //     let overdueMark = data.overdueMark;
    //     let hideOverdueMarkDate = localStorage.getItem('hideOverdueMarkDate');
    //     let curDate = new Date();
    //     curDate = curDate.getFullYear() + '-' + (curDate.getMonth() + 1) + '-' + curDate.getDate();
    //     if(hideOverdueMarkDate == curDate) {
    //       overdueMark = false;
    //     }
    //     that.$store.commit('orderDotRemark', {
    //       overDue: overdueMark,
    //       remark: remark
    //     });
    //     that.overdueMark = overdueMark;
    //     that.remark = remark;
    //   });
    // },
    // 获取订单列表
    getOrderListFunc (statusTab, pageNo) {
      let that = this;
      let params = {
        pageIndex: pageNo,
        pageSize: that.pageSize,
        statusTab: statusTab,
      };
      // console.log('----->>>>>>>>>', statusTab, '---', pageNo);
      getOrderListApi(params).then((data) => {
        that.showLoading = false;
        data = data.body;

        // let data = {
        //   "productOrderList": [{
        //     "productId": 354,
        //     "productName": "立即贷",
        //     "productLogo": "http://img.huaqianwy.com/wfree2.0_image/20180322155007_119_5d54c482.png",
        //     "productAmount": "5.00-50.00",
        //     "productLimit": "15天",
        //     "productRate": "日利率:0.065%",
        //     "orderId": "284406238412800001",
        //     "orderStatus": 402,
        //     "applyTime": 1545737331000,
        //     "applyNeedTime": null,
        //     "creditAmount": null,
        //     "creditRate": null,
        //     "presentLimit": null,
        //     "creditTime": null,
        //     "storehouse": null,
        //     "nextApplyTime": null,
        //     "orderAmount": 700.00,
        //     "orderLimit": "14日",
        //     "orderDueDate": 1546876800000,
        //     "orderRepayTime": 1545738309000,
        //     "undercarriage": true
        //   }],
        //   "currentIndex": 1,
        //   "totalCount": 1,
        //   "totalPage": 1
        // }

        let list = that.formateOrderListData(data.productOrderList);
        let hasNextPage = false;
        if (pageNo < data.totalPage) {
          hasNextPage = true;
        }
        if (pageNo > 1) {
          list = that.orderList.concat(list);
        } else {
          that.mescroll.setPageNum(2);
        }
        if (list && list.length > 0) {
          that.showNoData = false;
        } else {
          that.showNoData = true;
        }
        that.orderList = list;
        that.mescroll.endSuccess(that.pageSize, hasNextPage);
      }, () => {
        that.showLoading = false;
        that.mescroll.endErr();
      });
    },
    // 格式化订单展示数据
    formateOrderListData (list) {
      if (list && list.length > 0) {
        for (let i = 0, l = list.length; i < l; i++) {
          let item = list[i];
          let sts = item.orderStatus;
          if (sts == '103' || sts == '101') {
            item.orderStatusTxt = '审核中';
            item.bottomTxt = '申请时间：' + utils.formateDate(item.applyTime, 'YYYY-MM-DD hh:mm');
            item.infos = [
              { key: '申请额度', value: '&yen;' + item.productAmount },
              { key: '期限', value: item.productLimit },
            ];
            item.btn = {
              txt: '查看',
              style: 'btn1',
            };
          } else if (sts == '201') {
            item.orderStatusTxt = '待提现';
            let creditRate = item.creditRate || item.productRate || ':';
            item.infos = [
              { key: '可借额度', value: '&yen;' + item.creditAmount },
              { key: '期限', value: item.presentLimit || item.productLimit },
              { key: creditRate.split(':')[0], value: creditRate.split(':')[1] },
            ];
            item.btn = {
              txt: '立即提现',
              style: 'btn2 ',
            };
          } else if (sts == '301') {
            item.orderStatusTxt = '待还款';
            item.bottomTxt = '应还日期：' + utils.formateDate(item.orderDueDate, 'YYYY-MM-DD');
            item.infos = [
              { key: '借款金额', value: '&yen;' + item.orderAmount },
              { key: '期限', value: item.orderLimit },
            ];
            item.btn = {
              txt: '立即还款',
              style: 'btn3 ',
            };
          } else if (sts == '401') {
            item.orderStatusTxt = '已逾期';
            item.bottomTxt = '应还日期：' + utils.formateDate(item.orderDueDate, 'YYYY-MM-DD');
            item.infos = [
              { key: '借款金额', value: '&yen;' + item.orderAmount },
              { key: '期限', value: item.orderLimit },
            ];
            item.btn = {
              txt: '立即还款',
              style: 'btn2 ',
            };
          } else if (sts == '402') {
            item.orderStatusTxt = '已结清';
            item.bottomTxt = '还款时间：' + utils.formateDate(item.orderRepayTime, 'YYYY-MM-DD hh:mm');
            item.infos = [
              { key: '借款金额', value: '&yen;' + item.orderAmount || '' },
              { key: '期限', value: item.orderLimit },
            ];
            item.btn = {
              txt: '查看',
              style: 'btn1 ',
            };
          } else if (sts == '202') {
            item.orderStatusTxt = '审核失败';
            item.bottomTxt = '审核时间：' + utils.formateDate(item.creditTime, 'YYYY-MM-DD hh:mm');
            item.infos = [
              { key: '申请额度', value: '&yen;' + item.productAmount },
              { key: '期限', value: item.productLimit },
            ];
            item.btn = {
              txt: '查看',
              style: 'btn1',
            };
          } else if (sts == '303') {
            item.orderStatusTxt = '待确认用款';
            item.bottomTxt = '申请时间：' + utils.formateDate(item.applyTime, 'YYYY-MM-DD hh:mm');
            item.infos = [
              { key: '借款金额', value: '&yen;' + item.orderAmount },
              { key: '期限', value: item.orderLimit },
            ];
            item.btn = {
              txt: '去完成',
              style: 'btn2 ',
            };
          } else if (sts == '304') {
            item.orderStatusTxt = '放款中';
            item.bottomTxt = '申请时间：' + utils.formateDate(item.applyTime, 'YYYY-MM-DD hh:mm');
            item.infos = [
              { key: '借款金额', value: '&yen;' + item.orderAmount },
              { key: '期限', value: item.orderLimit },
            ];
            item.btn = {
              txt: '查看',
              style: 'btn1 ',
            };
          } else if (sts == '302') {
            item.orderStatusTxt = '放款失败';
            item.bottomTxt = '申请时间：' + utils.formateDate(item.applyTime, 'YYYY-MM-DD hh:mm');
            item.infos = [
              { key: '借款金额', value: '&yen;' + item.orderAmount },
              { key: '期限', value: item.orderLimit },
            ];
            item.btn = {
              txt: '查看',
              style: 'btn1 ',
            };
          } else if (sts == '104') {
            // 303：待确认用款 304：放款中  104：待补充资料
            item.orderStatusTxt = '待补充资料';
            let productRate = item.productRate || ':';
            item.infos = [
              { key: '可借额度', value: '&yen;' + item.creditAmount },
              { key: '期限', value: item.productLimit },
              { key: productRate.split(':')[0], value: productRate.split(':')[1] },
            ];
            item.btn = {
              txt: '立即补充',
              style: 'btn2 ',
            };
          } else {
            item.orderStatusTxt = '';
            item.bottomTxt = '';
            item.infos = [];
            item.btn = {};
          }
        }
        return list;
      } else {
        return [];
      }
    },
    // 初始化下拉组件
    initMescroll () {
      let that = this;
      that.mescroll = new MeScroll('mescroll', {
        down: {
          // use: false,
          auto: false,
          callback: this.downCallback,
        },
        up: {
          auto: true,
          isBounce: false,
          noMoreSize: 5,
          page: {
            num: 0, //当前页 默认0,回调之前会加1; 即callback(page)会从1开始
            size: that.pageSize, //每页数据条数,默认10
          },
          callback: this.upCallback,
          htmlLoading: `<div id="databottom" class="data-bottom">
                      <div class="load">
                        <img src="./static/images/loding.gif">
                      </div>
                      <div class="text" id="bottomtext">上拉查看下一页</div>
                    </div>`,
          htmlNodata: `<div class="no-data no-other">
                          <div class="no-datas">
                            <div class="no-datas-text">已经到底啦</div>
                          </div>
                      </div>`,
        },
      });
    },
    downCallback () {
      let that = this;
      // 下拉刷新时，清除记录页面滚动位置
      global.storage.set("orderScrollTop", 0);
      // that.queryStatusFunc();
      if (that.mescroll) {
        that.mescroll.setPageNum(1);
        that.mescroll.endUpScroll(false);
      }
      that.getOrderListFunc(that.curTabType, 1);
    },
    upCallback (page) {
      var that = this;
      let pageNo = page.num;
      that.getOrderListFunc(that.curTabType, pageNo);
    },
  },
};
</script>
<style lang="scss" scoped>
.mescroll {
  overflow-x: hidden;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}
.split-block {
  height: rc(20);
  background-color: #f5f5f5;
}
#loading {
  bottom: 0;
}
.mo-tab {
  position: absolute;
  z-index: 3;
  top: 0;
  left: 0;
  right: 0;
  height: rc(88);
  display: flex;
  background-color: #fff;
  font-size: rc(30);
  color: #333;
  font-weight: bold;
  box-sizing: border-box;
  &-item {
    flex: 1;
    text-align: center;
    height: rc(88);
    line-height: rc(88);
    box-sizing: border-box;
    &::after {
      border-bottom-color: #e7e7e7;
    }
  }
  &-name {
    display: inline-block;
    &.cur-tab {
      color: $color-main;
      position: relative;
      &::after {
        content: '';
        position: absolute;
        left: 0;
        right: 0;
        bottom: 0;
        height: 0;
        border-bottom: rc(3) solid $color-main;
        z-index: 1;
      }
    }
  }
  &-title {
    position: relative;
    padding: rc(0 12);
    // &.dot::after {
    //   content: '';
    //   position: absolute;
    //   top: 0;
    //   right: 0;
    //   width: rc(12);
    //   height: rc(12);
    //   border-radius: 50%;
    //   background-color: #ff4c4c;
    //   background-clip: padding-box;
    // }
    // &.yuqi::after {
    //   content: '逾期';
    //   line-height: 1.5;
    //   position: absolute;
    //   top: rc(-18);
    //   left: 100%;
    //   margin-left: rc(-10);
    //   padding: rc(2 10);
    //   // border: 1px solid #fff;
    //   border-radius: rc(18);
    //   border-bottom-left-radius: 0;
    //   background-color: #ff4c4c;
    //   color: #fff;
    //   font-size: rc(20);
    //   word-break: keep-all;
    // }
  }
}
.mo-content {
  padding-top: rc(88);
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  -webkit-overflow-scrolling: touch;
  position: relative;
}
#mescroll {
  width: 100%;
  height: 100%;
}
.mo-order {
  margin-bottom: rc(48);
  &-item {
    background-color: #fff;
    margin-top: rc(20);
  }
  &-top {
    padding: rc(0 30);
    display: flex;
    height: rc(96);
    align-items: center;
    &-logo {
      width: rc(50);
      height: rc(50);
      border-radius: rc(12);
    }
    &-name {
      font-size: rc(30);
      color: #111;
      margin-left: rc(16);
      flex: 1;
    }
    &-sts {
      font-size: rc(28);
      color: $color-remind;
    }
  }
  &-content {
    padding: rc(28 30 34);
  }
  &-info {
    display: flex;
    align-items: center;
    &-item {
      margin-right: rc(20);
      flex: 3;
      text-align: center;
      width: 0;
      color: #999;
      .mo-order-info-key {
        font-size: rc(26);
      }
      .mo-order-info-value {
        font-size: rc(30);
        margin-bottom: rc(9);
      }
      &:first-child {
        flex: 4;
        text-align: left;
        .mo-order-info-value {
          font-size: rc(40);
          color: $color-remind;
          margin-bottom: rc(2);
        }
      }
    }
  }
  &-btn {
    width: rc(166);
    height: rc(69);
    line-height: rc(69);
    border-radius: rc(100);
    text-align: center;
    font-size: rc(28);
    margin-left: rc(20);
    &::after {
      border-radius: rc(200);
    }
    &.btn1 {
      color: #333;
      background-color: #fff;
      &::after {
        border-color: #ccc;
      }
    }
    &.btn2 {
      color: #fff;
      background-color: $color-main;
      &::after {
        border-color: $color-main;
      }
    }
    &.btn3 {
      color: $color-main;
      background-color: #fff;
      &::after {
        border-color: $color-main;
      }
    }
  }
  &-bottom {
    padding: rc(0 30);
    line-height: rc(60);
    font-size: rc(26);
    color: #999;
    background-color: #fafafa;
  }
}
.no-order {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  text-align: center;
  z-index: 2;
  background-color: #fff;
  &-icon {
    width: rc(300);
    height: rc(300);
    margin: rc(228 0 94);
  }
  &-tips {
    color: #666;
    font-size: rc(28);
    // font-weight: bold;
  }
  &-btn {
    width: rc(240);
    height: rc(68);
    // line-height: rc(68);
    // background-image: linear-gradient(90deg, #ff5b00 0%, #ff8f00 100%);
    border-radius: rc(100);
    font-size: rc(28);
    color: #fff;
    text-align: center;
    margin: rc(30) auto;
  }
}
</style>
<style lang="scss">
#mescroll {
  .data-bottom {
    margin-top: rc(21);
    // margin-bottom: -20px;
    margin-bottom: rc(26);
    font-size: rc(24);
    color: #777;
    display: flex;
    display: -webkit-flex;
    text-align: center;
    .load {
      width: rc(34);
      height: rc(34);
      margin-left: rc(281);
      img {
        width: rc(34);
        height: rc(34);
      }
    }
    .text {
      margin-left: rc(10);
    }
  }
  .no-data {
    margin-bottom: -20px;
    margin-top: rc(30);
    font-size: rc(24);
    color: #777777;
    text-align: center;
    height: rc(96);
    .no-datas {
      height: rc(33);
      width: 50%;
      margin-left: 25%;
      border-bottom: 1px solid #979797;
      position: relative;
      /*line-height:rc(33);*/
      .no-datas-text {
        width: 40%;
        margin-left: 30%;
        background: #f6f6f6;
        position: absolute;
        top: rc(16);
      }
    }
    &.no-other {
      padding-bottom: 0;
    }
  }
}
</style>
