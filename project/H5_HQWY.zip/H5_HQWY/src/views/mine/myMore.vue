<template>
  <PageView title="更多">
    <div class="myMore">
      <div class="content">
        <ul>
          <li v-show="quitShow"
              class="bb-1px"
              @click="modPwd('wd;xgmm;w115')">
            <img class="img"
                 src="../../../static/images/password.png" />
            <span>修改密码</span>
            <div class="right">
              <img src="../../../static/images/arrow.png">
            </div>
          </li>
          <li class="bb-1px"
              @click="getNextPage('/aboutUs','wd;gywm;w117')">
            <img class="img"
                 src="../../../static/images/about.png" />
            <span>关于我们</span>
            <div class="right">
              <img src="../../../static/images/arrow.png">
            </div>
          </li>
          <li v-if="!isMjb"
              class="bb-1px"
              @click="checkupdate('wd;jcgx;w118')">
            <img class="img"
                 src="../../../static/images/update.png" />
            <span>检查更新</span>
            <div class="right">
              <span>{{ appVersion }}</span><img src="../../../static/images/arrow.png">
            </div>
          </li>
          <li v-if="quitShow"
              class="bb-1px"
              @click="cancelAccountCheck()">
            <img class="img"
                 src="../../../static/images/mine_logout.png" />
            <span>注销账号</span>
            <div class="right">
              <img src="../../../static/images/arrow.png">
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div v-if="quitShow"
         class="quit"
         @click="quitLogin('wd;aqtc;w119', true)">
      安全退出
    </div>
    <!-- <VLoad :isload="isLoad"></VLoad> -->
    <Loading v-show="isNetLoading"></Loading>
    <!-- 注销确认弹窗 -->
    <Confirm ref="sureComfirm"
             title="温馨提示"
             sure-txt="我再想想"
             cancel-txt="确认注销"
             @on-confirm="appExecStatistic('gd;zxzh;wzxx;w253')"
             @on-cancel="cancelAccountFunc()">
      <div class="sure-info">
        注销后将移除账号，并删除账号所有信息，删除后无法恢复！
      </div>
    </Confirm>

    <!-- 不能注销提示弹窗 -->
    <Confirm ref="failComfirm"
             title="温馨提示"
             sure-txt="我知道了"
             @on-confirm="appExecStatistic('gd;zxzh;wzdl;w251')">
      <div class="sure-info">
        <span class="name">{{ reason }}</span>
      </div>
    </Confirm>
  </PageView>
</template>

<script>

import utils from "../../util/utils"
// import VLoad from "../../components/load.vue";
import Loading from "../../components/loading/loading"
import Confirm from "../../components/confirm/index"
import { mapActions } from "vuex";
import { cancelAccountCheckApi, cancelAccountApi, logoutApi } from "../../api/controller/mine/mine";

export default {
  components: {
    // VLoad,
    Loading,
    Confirm,
  },
  data () {
    return {
      isMjb: false, // 是否马甲包
      quitShow: false,
      token: "",
      phone: "",
      reason: "",
      couponCount: "", //优惠券数量
      // isLoad: "none", //默认页面没有loading动画
      isNetLoading: false, //默认页面没有loading动画
      appVersion: "",
      loginClicked: false,
    };
  },
  computed: {
    isLogin () {
      return this.$store.state.login.isLogin;
    },
  },
  activated () {
    var self = this;
    this.$refs.sureComfirm && this.$refs.sureComfirm.hide()
    this.$refs.failComfirm && this.$refs.failComfirm.hide()

    self.$nextTick(function () {
      self.$appInvoked("appGetUserToken", {}, function (data) {
        self.token = data;
        if (data !== "" && data != null) {
          self.quitShow = true;
        } else {
          self.quitShow = false;
        }
      });
      self.$appInvoked("appGetMobilephone", {}, function (data) {
        self.phone = data;
        self.$store.commit("PHONE_NUMBER", data);
      });
      // console.warn("-------->" + self.isLogin);
    });

    self.$appInvoked("appGetVersion", {}, function (appVersion) {
      if (appVersion) {
        self.appVersion = "V " + appVersion;
        self.$store.commit("APP_VERSION", appVersion);
      }
    });
    // console.warn(this.$store.state)
    // this.$store.commit('userName','aaa')
    window.vueApp = this;
    self.$appInvoked("appGetBundleId", {}, (rst) => {
      self.isMjb = (rst === 'com.sl.hhsc') || (+rst > 1000) || (+rst < 0);
    })
  },
  methods: {
    //jsbridge在原生生命周期中会调这个方法，如果从原生跳回h5刷选刷新数据可以在这个方法中调用
    webviewWillAppear () {
      // console.log("---->webviewWillAppear");
      var self = this;

      self.$nextTick(function () {
        self.$appInvoked("appGetUserToken", {}, function (data) {
          self.token = data;
          if (data !== "" && data != null) {
            self.quitShow = true;
          } else {
            self.quitShow = false;
          }
        });

        // console.warn("-------->" + self.isLogin);
      });
    },
    ...mapActions(["setHeaderInfo"]),
    getNextPage (pageName, eventid) {
      var self = this;
      self.$appInvoked("appExecStatistic", {
        eventId: eventid,
        eventType: 0,
      }); //埋点
      self.$routerPush(pageName);
    },
    appExecStatistic (eventId) { // 埋点
      this.$appInvoked("appExecStatistic", {
        eventId: eventId,
        eventType: 0,
      }); //埋点
    },
    cancelAccountCheck () {// 注销账号检查
      let self = this;
      self.appExecStatistic('gd;zxzh;w250')  // 埋点
      self.isNetLoading = true
      cancelAccountCheckApi().then((data) => {
        self.isNetLoading = false
        if (data.respCode === '1000') {
          let body = data.body
          if (body.checkFlag) {
            // 校验通过 展示确认弹窗
            this.$refs.sureComfirm.show()
          } else {
            // 校验不通过 展示失败提示弹窗
            self.reason = body.reason
            this.$refs.failComfirm.show()
          }
        } else {
          utils.toastMsg(data.respMsg)
        }
      }, () => {
        self.isNetLoading = false
      })
    },
    cancelAccountFunc () {// 注销账号
      let self = this;
      self.appExecStatistic('gd;zxzh;qrzx;w252')  // 埋点
      self.isNetLoading = true
      cancelAccountApi().then((data) => {
        if (data.respCode === '1000') {
          let body = data.body
          if (body.closeFlag) {
            // 注销成功
            utils.toastMsg('注销账号成功！')
            self.quitLogin()
          } else {
            // 注销失败
            utils.toastMsg(body.failReason)
          }
        } else {
          utils.toastMsg(data.respMsg)
        }
      }, () => {
        self.isNetLoading = false
      })
    },
    modPwd (eventid) {
      let self = this;
      if (this.loginClicked) {
        return;
      }
      this.loginClicked = true;
      setTimeout(() => {
        this.loginClicked = false;
      }, 500);
      self.$appInvoked("appExecStatistic", {
        eventId: eventid,
        eventType: 0,
      }); //埋点
      self.$routerPush('/register?from=validateMobile&sourcePage=myMore')
    },
    //检查更新
    checkupdate (eventid) {
      this.$appInvoked("appExecStatistic", {
        eventId: eventid,
        eventType: 0,
      }); //埋点
      this.$appInvoked("appCheckUpdate", {});
    },
    //退出登录
    quitLogin (eventid, needLogout) {
      var self = this;
      self.$store.commit("PHONE_NUMBER", "");
      eventid && self.$appInvoked("appExecStatistic", {
        eventId: eventid,
        eventType: 0,
      }); //埋点
      // 调用退出登录接口，并清除原生数据
      self.isNetLoading = true
      if (!needLogout) {
        self.$appInvoked('appClearUser', {})
        localStorage.clear();
        localStorage.setItem('loginoutnow', 1);
        self.$routerGo(-1);
        return
      }
      logoutApi().then((data) => {
        self.isNetLoading = false
        if (data.respCode === '1000') {
          self.$appInvoked('appClearUser', {})
          localStorage.clear();
          localStorage.setItem('loginoutnow', 1);
          self.$routerGo(-1);
        } else {
          utils.toastMsg(data.respMsg)
        }
      }, () => {
        self.isNetLoading = false
      })
      // self.$appInvoked("appExecLogout", {}, function (data) {
      //   // eslint-disable-next-line eqeqeq
      //   if (data == true) {
      //     localStorage.clear();
      //     // ajaxHeaders.token = "";

      //     localStorage.setItem('loginoutnow', 1);
      //     self.$routerGo(-1);
      //   }
      // });
    },
  },
};
</script>

<style lang="scss" scoped="scoped">
.title {
  background: #fff;
  width: 100%;
  height: rc(152);
  padding-left: rc(30);
  .logoStatus {
    /*padding-top: rc(20);*/
    display: flex;
    display: -webkit-flex;
    .status-left img {
      height: rc(122);
      width: rc(122);
    }
    .status-right {
      margin-left: rc(50);
      .status-right-top {
        margin-top: rc(18);
        font-size: rc(40);
        color: #333333;
        letter-spacing: 0;
      }
      .status-right-mid {
        opacity: 0.99;
        font-size: rc(28);
        color: #999999;
        letter-spacing: 0;
        text-align: right;
        margin-top: rc(10);
      }
    }
    .status-right2 {
      margin-top: rc(18);
      margin-left: rc(30);
      font-size: rc(30);
      color: #333333;
      letter-spacing: 0;
    }
  }
}

.content {
  background: #fff;
  margin-top: rc(20);
  padding-left: rc(30);
  font-size: rc(28);
  li {
    padding-right: rc(30);
    height: rc(96);
    line-height: rc(96);
    display: flex;
    display: -webkit-flex;
    font-size: rc(30);
    color: #333333;
    letter-spacing: 0;
    &.bb-1px:last-child::after {
      border-bottom: 0;
    }
    .img {
      height: rc(40);
      width: rc(40);
      margin-top: rc(28);
      margin-right: rc(20);
    }
    .right {
      flex: 1;
      -webkit-flex: 1;
      text-align: right;
      font-size: rc(26);
      color: #999;
      letter-spacing: 0;
      img {
        margin-left: rc(20);
        width: rc(15);
        height: rc(26);
      }
    }
  }
}
.sure-info {
  font-size: rc(30);
  line-height: rc(32);
  color: #444;
}

.last {
  border-bottom: none;
}

.quit {
  margin-top: rc(30);
  height: rc(80);
  line-height: rc(80);
  width: 100%;
  text-align: center;
  background: #fff;
  font-size: rc(28);
  color: $color-main;
  /*margin-bottom: rc(200);*/
}
</style>
