<template>
  <PageView id="hqwy-mescroll"
            type="mescroll"
            title="完善贷款信息">
    <img class="fli-top-banner"
         src="../../../static/images/banner-wszl.png"
         alt="资料越完善，申请额度越大，通过率越高哦～">
    <!-- 已过审 -->
    <ul v-if="hasAuditPass && !isMjb"
        class="fli-all-info">
      <li v-for="(auth, index) in authList"
          :key="index"
          class="fli-info"
          @click="fillLoanInfo(auth.authType, index, auth.eventId)">
        <div class="fli-info-icon"
             :style="{'background': 'url(' + auth[authStatusObj[auth.authType]==0?'authIcon0':'authIcon1'] + ') no-repeat center / 100% 100%'}"></div>
        <div class="fli-info-name"
             :class="{'no-finish': authStatusObj[auth.authType]==0}"
             v-text="auth.authName"></div>
        <div v-if="authStatusObj[auth.authType]==1"
             class="fli-info-btn sts3"
             lang="zh-CN">
          已完成
        </div>
        <div v-else
             class="fli-info-btn"
             :class="authStatusObj[auth.authType]==2 ? 'sts4' : index==curIdx ? 'sts2' : 'sts1'"
             lang="zh-CN"
             v-text="authStatusObj[auth.authType]==2 ? '已失效' : '未完成'"></div>
      </li>
    </ul>
    <!-- 未过审 -->
    <ul v-else
        class="fli-all-info">
      <li v-for="(auth, index) in authList"
          :key="index"
          class="fli-info">
        <template v-if="index === 0">
          <div @click="fillLoanInfo(auth.authType, index, auth.eventId)">
            <div class="fli-info-icon"
                 :style="{'background': 'url(' + auth[authStatusObj[auth.authType]==0?'authIcon0':'authIcon1'] + ') no-repeat center / 100% 100%'}"></div>
            <div class="fli-info-name"
                 :class="{'no-finish': authStatusObj[auth.authType]==0}"
                 v-text="auth.authName"></div>
            <div v-if="authStatusObj[auth.authType]==1"
                 class="fli-info-btn sts3"
                 lang="zh-CN">
              已完成
            </div>
            <div v-else
                 class="fli-info-btn"
                 :class="authStatusObj[auth.authType]==2 ? 'sts4' : index==curIdx ? 'sts2' : 'sts1'"
                 lang="zh-CN"
                 v-text="authStatusObj[auth.authType]==2 ? '已失效' : '未完成'"></div>
          </div>
        </template>
        <template v-else>
          <div class="fli-info-icon"
               :style="{'background': 'url(' + auth['authIcon0'] + ') no-repeat center / 100% 100%'}"></div>
          <div class="fli-info-name no-finish"
               v-text="auth.authName"></div>
          <div class="fli-info-btn sts1"
               lang="zh-CN">
            即将开放
          </div>
        </template>
      </li>
    </ul>
    <div slot="dialog">
      <!-- Loading -->
      <Loading v-show="showLoading"></Loading>
      <!-- 提示弹窗 -->
      <Confirm v-if="authList.length > curIdx"
               ref="tipsComfirm"
               :white-space="false"
               title="温馨提示"
               cancel-txt="取消"
               sure-txt="确定"
               :txt="'请先完成' + authList[curIdx].authName"
               txt-style="center"
               @on-confirm="fillLoanInfo(authList[curIdx].authType, curIdx)"></Confirm>
    </div>
    <!-- 过审判断 -->
    <AuditPass ref="auditPass"></AuditPass>
  </PageView>
</template>
<script>
import Confirm from "../../components/confirm/index"
import Loading from "../../components/loading/loading"
import AuditPass from '@/components/function/hasAuditPass'

import utils from "../../util/utils";

import { loanEntryQueryApi } from "../../api/controller/openAccount/index";
// import { loanEntryQueryApi, getBasicInfoApi, submitAuthStatusApi } from "../../api/controller/openAccount/index";
export default {
  name: 'FillLoanInfo',
  components: {
    Confirm,
    Loading,
    AuditPass,
  },
  data () {
    return {
      hasAuditPass: false, // 是否已过审
      isMjb: true,
      showLoading: false,
      /**
       * authStatus: 认证状态。0-未认证，1-已认证，2：已失效
       * authType：JCZL:基础资料 CA：身份认证；CON：联系人认证；MOP：手机运营商认证；OTH：其他信息认证
       * authName：与authType对应
       * authIcon：0未认证状态图标，1已认证状态图标
       * url：页面链接
       */
      authList: [
        { authType: 'JCZL', authName: '基础资料', url: '/loanInfo?source=0&w=196', eventId: 'wsdkxx;jcxx;w196', authIcon0: require('../../../static/images/mine_data_jcxx2.png'), authIcon1: require('../../../static/images/mine_data_jcxx.png') },
        { authType: 'CA', authName: '身份认证', url: '/identityAuth?source=0&w=197', eventId: 'wsdkxx;sfrz;w197', authIcon0: require('../../../static/images/mine_data_sf2.png'), authIcon1: require('../../../static/images/mine_data_sf.png') },
        { authType: 'CON', authName: '紧急联系人', url: '/emergencyContact?source=0&w=198', eventId: 'wsdkxx;jjlxr;w198', authIcon0: require('../../../static/images/mine_data_jjlxr2.png'), authIcon1: require('../../../static/images/mine_data_jjlxr.png') },
        // { authType: 'MOP', authName: '运营商认证', url: '', eventId: 'wsdkxx;yysrz;w199', authIcon0: require('../../../static/images/mine_data_yys2.png'), authIcon1: require('../../../static/images/mine_data_yys.png') },
        { authType: 'OTH', authName: '补充信息', url: '/otherInfo?source=0&w=200', eventId: 'wsdkxx;qtxx;w200', authIcon0: require('../../../static/images/mine_data_more2.png'), authIcon1: require('../../../static/images/mine_data_more.png') },
      ],
      // 接口获取资料完善状态
      authStatusObj: { JCZL: 0, CA: 0, CON: 0, /*MOP: 0,*/ OTH: 0 },
      // 资料填写顺序
      authOrderIdx: { JCZL: 0, CA: 1, CON: 2, /*MOP: 3,*/ OTH: 3 },
      errorIcon: this.getCachedImages("productIcon") || require("APP_IMG/default.png"), //产品缩略占位图
      curIdx: 0, // 当前待填写资料index值
    };
  },
  activated () {
    let that = this
    let w = that.$route.query.w
    if (w) {
      that.collectEventMD({
        eventId: `ly1004,w${w}`,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
      })
    }
    that.loanEntryQueryFunc();
    // 客户端埋点
    that.collectEventMD({
      eventId: '1012',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
    });
    that.$refs.auditPass.init(false, () => {
      that.hasAuditPass = true
    }, () => {
      that.hasAuditPass = false
    })

    this.$appInvoked("appGetBundleId", {}, (rst) => {
      this.isMjb = (rst === 'com.sl.hhsc') || (+rst > 1000) || (+rst < 0);
    })
  },
  methods: {
    // 点击资料项
    fillLoanInfo (authType, idx, eventId) {
      let that = this;
      // that.$routerPush(that.authList[idx].url); return;
      let curIdx = that.curIdx;
      let authStatus = that.authStatusObj[authType];
      if (eventId) {
        that.$appInvoked('appExecStatistic', { eventId: eventId });
      }
      if (idx > curIdx && authStatus !== 1) {
        that.$refs.tipsComfirm.show();
      } else if (idx === curIdx) {
        // if (authType === 'MOP') {
        //   that.fillMopInfo('', that.$route.query.w, () => {
        //     that.authStatusObj['MOP'] = 1
        //     that.computeCurIdx(that.authStatusObj)
        //     that.checkNextFillInfos(that.$route.query.w, '0')
        //   })
        // } else {
        that.$routerPush(that.authList[idx].url);
        // }
      } else if (['CA', 'MOP'].indexOf(authType) > -1 && that.authStatusObj[authType] === 1) {
        // 身份认证和运营商认证完成后不可修改
        utils.toastMsg('该项资料不可修改哦');
      } else {
        // if (authType === 'MOP') {
        //   that.fillMopInfo('', that.$route.query.w, () => {
        //     that.authStatusObj['MOP'] = 1
        //     that.computeCurIdx(that.authStatusObj)
        //     that.checkNextFillInfos(that.$route.query.w, '0')
        //   })
        // } else {
        that.$routerPush(that.authList[idx].url);
        // }
      }
    },
    // 完善贷款信息查询
    loanEntryQueryFunc () {
      let that = this;
      that.showLoading = true;
      loanEntryQueryApi({ materialType: '' }).then((data) => {
        that.showLoading = false;
        if (data.respCode === '1000') {
          data = data.body;
          // let data = [
          //   {authStatus: 1, authType: 'JCZL'},
          //   {authStatus: 1, authType: 'CA'},
          //   {authStatus: 1, authType: 'CON'},
          //   {authStatus: 2, authType: 'MOP'},
          //   {authStatus: 0, authType: 'OTH'}
          // ];
          for (let i = 0, l = data.length; i < l; i++) {
            let item = data[i];
            that.authStatusObj[item.authType] = item.authStatus;
          }
          that.computeCurIdx(that.authStatusObj);
        }
      }, () => {
        that.showLoading = false;
      });
    },
    computeCurIdx (authStatusObj) {
      let that = this;
      let authList = that.authList;
      that.curIdx = authList.length;
      for (let i = 0, l = authList.length; i < l; i++) {
        let authType = authList[i].authType;
        if (authStatusObj[authType] !== 1) {
          that.curIdx = that.authOrderIdx[authType];
          break;
        }
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.mescroll {
  background-color: #fff;
}
.split-block {
  height: rc(20);
  background-color: #f5f5f5;
}
#loading {
  bottom: 0;
}
.fli-top-banner {
  display: block;
  width: 100%;
  height: rc(180);
  background-color: $bgColor-list-order;
  margin-bottom: rc(70);
}
.fli-all-info {
  display: flex;
  flex-wrap: wrap;
  padding: rc(0 30);
}
.fli-info {
  width: 33.33%;
  text-align: center;
  margin-bottom: rc(90);
  &-icon {
    width: rc(111);
    height: rc(111);
    margin: auto;
  }
  &-name {
    margin: rc(20 0 18);
    font-size: rc(30);
    color: #333;
    &.no-finish {
      color: #aaa;
    }
  }
  &-btn {
    display: inline-block;
    font-size: rc(28);
    line-height: rc(55);
    border-radius: rc(55);
    padding: rc(0 23);
    position: relative;
    &::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      transform-origin: 0 0;
      box-sizing: border-box;
      width: 200%;
      height: 200%;
      transform: scale(0.5);
      border: 1px solid transparent;
      border-radius: rc(55);
    }
    // 未完成
    &.sts1 {
      color: #aaa;
      &::after {
        border-color: #aaa;
      }
    }
    // 未完成可点击
    &.sts2 {
      color: #fff;
      background-color: $color-main;
      &::after {
        border-color: $color-main;
      }
    }
    // 已完成
    &.sts3 {
      color: $color-main;
      &::after {
        border-color: $color-main;
      }
    }
    // 已失效
    &.sts4 {
      color: #fff;
      background-color: #ff4c4c;
      &::after {
        border-color: #ff4c4c;
      }
    }
  }
}
</style>
