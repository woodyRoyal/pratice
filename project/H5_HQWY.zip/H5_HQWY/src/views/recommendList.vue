<template>
  <PageView title="智能推荐"
            :is-back-page="false"
            class="bg-fff"
            @backClick="backClickHandle">
    <!--推荐列表-->
    <RecommendList ref="recommend"
                   :user-data="userData">
      <div v-if="rankingList.length>0"
           class="new-recommend-list">
        <div class="tip">
          根据您的资质，为您推荐以下产品
        </div>
        <!-- 主产品 -->
        <div class="main"
             @click="onProductClick(rankingList[0],0)">
          <div class="logo">
            <img :src="rankingList[0].logo"
                 alt="">
            <h2>{{ rankingList[0].name }}</h2>
          </div>
          <p class="money">
            &yen;{{ rankingList[0].limit }}
          </p>
          <p v-if="rankingList[0].passRate"
             class="sub">
            通过率高达{{ rankingList[0].passRate }}
          </p>
          <CommonButton :btn-data="apply"></CommonButton>
          <span class="top-iocn top-iocn-one"></span>
        </div>
        <!-- 优先推荐产品-->
        <div class="precedence">
          <div v-if="rankingList.length>=2"
               class="precedence-item precedence-item-one"
               @click="onProductClick(rankingList[1],1)">
            <div class="logo">
              <img :src="rankingList[1].logo"
                   alt="">
              <h2>{{ rankingList[1].name }}</h2>
            </div>
            <p class="money">
              &yen;{{ rankingList[1].limit }}
            </p>
            <button class="btn">
              立即申请
            </button>
            <span class="top-iocn top-iocn-two"></span>
          </div>
          <div v-if="rankingList.length>=3"
               class="precedence-item precedence-item-two"
               @click="onProductClick(rankingList[2],2)">
            <div class="logo">
              <img :src="rankingList[2].logo"
                   alt="">
              <h2>{{ rankingList[2].name }}</h2>
            </div>
            <p class="money">
              &yen;{{ rankingList[2].limit }}
            </p>
            <button class="btn">
              立即申请
            </button>
            <span class="top-iocn top-iocn-three"></span>
          </div>
        </div>
        <!-- 其他推荐产品 -->
        <div v-if="ismMore"
             class="module-hd">
          <h2>更多推荐</h2>
          <!-- <p>申请产品越多，通过率越高</p> -->
        </div>
      </div>
      <!--重新评估-->
      <CommonButton :btn-data="recommendBtn"
                    class="recommend-btn"
                    @click.native="cxzntjClick('jztj;wntj;zctj;w105')"></CommonButton>
    </RecommendList>
  </PageView>
</template>
<script>
// var routerFrom = ""; //来源地址
// import Vue from "vue";
import RecommendList from "../components/recommendList/recommendList";
import CommonButton from "../components/button/index"
export default {
  name: "RecommendLists",
  components: {
    CommonButton,
    RecommendList,
  },
  provide () {
    return {
      recommendResult: this,
    }
  },
  data () {
    return {
      isMjb: false, // 是否马甲包
      ismMore: false,
      rankingList: [],
      apply: {
        activeFlag: true,
        txt: '立即申请',
      },
      recommendBtn: {
        activeFlag: true,
        txt: '重新智能推荐',
      },
      userData: {
        amount: "",
        creditCard: "",
        currPageNo: 1,
        deadline: "",
        fund: "",
        occupation: "",
        phoneNumServiceTime: "",
        zhima: "",
      },
      // circleData: {},
      isShow: false, //网络异常时显示
      reloadText: "", //异常提示文案
    };
  },
  // beforeRouteEnter (to, from, next) {
  //   // console.log(from.name)
  //   // routerFrom = from.name;
  //   next();
  // },
  activated () {
    this.interceptAppBack()
    var self = this;
    self.rankingList = []
    self.$refs.recommend.lists = []
    let w = self.$route.query.w
    if (w) {
      self.collectEventMD({
        eventId: `ly1003,w${w}`,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
      })
    }
    self.collectEventMD({
      eventId: 'jr1014',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
    })

    // window.addEvent = this.addEvent;

    if (self.$route.query.amount !== '-1') {
      self.userData.amount = self.$route.query.amount;
    }
    if (self.$route.query.creditCard !== '-1') {
      self.userData.creditCard = self.$route.query.creditCard;
    }
    if (self.$route.query.deadline !== '-1') {
      self.userData.deadline = self.$route.query.deadline;
    }
    if (self.$route.query.fund !== '-1') {
      self.userData.fund = self.$route.query.fund;
    }
    if (self.$route.query.occupation !== '-1') {
      self.userData.occupation = self.$route.query.occupation;
    }
    if (self.$route.query.phoneNumServiceTime !== '-1') {
      self.userData.phoneNumServiceTime = self.$route.query.phoneNumServiceTime;
    }
    if (self.$route.query.zhima !== '-1') {
      self.userData.zhima = self.$route.query.zhima;
    }

    // window.addEvent = this.addEvent;
    var refreshTime = localStorage.getItem("refreshTime");

    if (
      self.$needRefreshData(JSON.parse(refreshTime)["recommendlist"]) &&
      document.readyState === "complete"
    ) {
      window.location.reload();
      var refreshTimeObj = JSON.parse(refreshTime);
      refreshTime["recommendlist"] = "";
      localStorage.setItem("refreshTime", JSON.stringify(refreshTimeObj));
    }
    this.$appInvoked("appGetBundleId", {}, (rst) => {
      this.isMjb = (rst === 'com.sl.hhsc') || (+rst > 1000) || (+rst < 0);
    })
  },
  methods: {
    cxzntjClick (eventid) {
      var self = this;
      // 重置红点
      localStorage.setItem("RED_DOT_DATA", '[]');
      self.$appInvoked("appExecStatistic", { eventId: eventid, eventType: 0 }); //埋点
      // self.clickReport('', '', eventid)
      self.collectEventMD({
        eventId: eventid,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
      })
      // self.$routerReplace(pageName);
      if (this.isMjb) {
        this.$routerReplace(`/fillInfo?w=105`)
      } else {
        self.checkNextFillInfos(105, '2')
      }
    },
    onProductClick (item, index) {
      this.$refs.recommend.onProductClick(item, index, true)
    },
    backClickHandle () {
      this.$appInvoked("appExecStatistic", {
        eventId: "jztj;wntj;fh;w107",
        eventType: 0,
      }); //添加返回埋点
      if (this.rankingList.length === 0) {
        this.$routerReplace('/fillinfo')
      } else {
        this.$routerGo(-1);
      }
    },
    getabnor (data) {
      this.isShow = data.isShow;
      this.reloadText = data.reloadText;
    },
  },
};
</script>
<style lang="scss" scoped>
.hqwy-prolist {
  overflow-y: hidden;
}
.new-recommend-list {
  padding: 0 rc(36);
  background: #ffffff;
  box-sizing: border-box;
}
.tip {
  height: rc(56);
  font-size: rc(26);
  line-height: rc(56);
  color: $color-text-tip;
}
.main {
  position: relative;
  background-image: linear-gradient(90deg, #fff8dd 0%, #fdfaee 100%);
  border-radius: rc(12);
  padding: rc(30);
  box-sizing: border-box;
  .hy-btn {
    width: 99.9%;
  }
}
.logo {
  display: flex;
  align-items: center;
  img {
    width: rc(46);
    height: rc(47);
    border-radius: rc(10);
    margin-right: rc(12);
  }
  h2 {
    position: relative;
    z-index: 10;
    font-weight: bold;
    font-size: rc(30);
    color: $color-text-title;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}
.money {
  text-align: center;
  font-size: rc(60);
  font-weight: bold;
  color: $color-remind;
  margin-top: rc(30);
}
.sub {
  text-align: center;
  font-size: rc(26);
  color: $color-text-tip;
  margin: rc(10) 0 rc(36) 0;
}
.hy-btn {
  margin-bottom: rc(10);
}
.top-iocn {
  display: block;
  width: rc(58);
  height: rc(58);
  position: absolute;
  top: 0;
  right: 0;
}
.top-iocn-one {
  background: url('../../static/images/top_img1.png') no-repeat center center;
  background-size: contain;
}
.top-iocn-two {
  background: url('../../static/images/top_img2.png') no-repeat center center;
  background-size: contain;
}
.top-iocn-three {
  background: url('../../static/images/top_img3.png') no-repeat center center;
  background-size: contain;
}
.precedence {
  display: flex;
  box-sizing: border-box;
  margin-top: rc(20);
}
.precedence-item {
  border-radius: rc(10);
  padding: rc(30) rc(30) 0 rc(30);
  box-sizing: border-box;
  position: relative;
  width: 50%;
  .money {
    text-align: left;
    font-size: rc(38);
    margin-top: rc(15);
  }
  .sub {
    text-align: left;
    margin-bottom: rc(20);
  }
  .btn {
    display: block;
    margin: 0 auto rc(23);
    width: rc(157);
    height: rc(56);
    text-align: center;
    line-height: rc(56);
    white-space: nowrap;
    border: solid 1px $color-main;
    box-sizing: border-box;
    border-radius: rc(61);
    font-size: rc(26);
    color: $color-main;
  }
}
.precedence-item-one {
  background-image: linear-gradient(90deg, #f0f0f0 0%, #f8fafd 100%);
}
.precedence-item-two {
  margin-left: rc(18);
  background-image: linear-gradient(90deg, #fff1eb 0%, #fcfbfa 100%);
}
.module-hd {
  margin-top: rc(40);
  display: flex;
  justify-content: space-between;
  align-items: center;
  h2 {
    font-size: rc(36);
    color: $color-text-title;
    font-weight: bold;
  }
  p {
    font-size: rc(26);
    color: $color-text-tip;
  }
}
.recommend-btn {
  position: fixed;
  width: auto !important;
  left: rc(36);
  right: rc(36);
  bottom: rc(10);
  z-index: 2;
}
</style>
