<template>
  <PageView title="产品详情"
            type="bg-fff"
            :is-back-page="false"
            :right-txt="pstatus==4?'':'智能推荐'"
            :show-error-page="showErrorPage"
            :error-page-info="errorPageInfo"
            @backClick="backClickHandle"
            @rightClick="rightClickHandle">
    <div id="hqwy-mescroll"
         class="mescroll">
      <div>
        <!-- 顶部卡片 -->
        <div class="header-card"></div>
        <ProductCardInfo type="product-info-card"
                         :icon="productDetail.logo"
                         :name="productDetail.name"
                         :tips="productDetail.subhead"
                         :label="productDetail.tagInfos || []">
          <!-- 额度、期限。产品详情及API产品详情展示 -->
          <div v-if="pstatus==0||pstatus==1"
               class="info-middle bb-1px">
            <div class="info-middle-item">
              <div class="info-title">
                额度
              </div>
              <div class="info-value">
                &yen;{{ productDetail.amount }}
              </div>
            </div>
            <div v-if="productDetail.limitTime"
                 class="info-middle-item">
              <div class="info-title">
                期限
              </div>
              <div class="info-value">
                {{ productDetail.limitTime }}
              </div>
            </div>
          </div>
          <!-- 费率试算 -->
          <div v-if="pstatus==4"
               class="info-feilv bb-1px">
            <div class="feilv-infos">
              <div class="feilv-infos-item">
                <div class="feilv-infos-title">
                  额度{{ productDetail.amount }}元
                </div>
                <div class="feilv-infos-select"
                     @click="showAction('limit')">
                  {{ feilv.limit }}元
                </div>
              </div>
              <div class="feilv-infos-item">
                <div class="feilv-infos-title">
                  期限{{ productDetail.limitTime }}
                </div>
                <div class="feilv-infos-select"
                     :class="feilv.duration==='单期'?'single':''"
                     @click="showAction('duration')">
                  {{ feilv.duration }}<span v-if="feilv.duration!=='单期'">{{ feilv.durationType===0?'天':'月' }}</span>
                </div>
              </div>
            </div>
            <div class="feilv-details">
              <div class="feilv-details-item">
                <div class="feilv-d-key">
                  到账金额(元)
                </div>
                <div class="feilv-d-value">
                  {{ feilv.limit||0 }}
                </div>
              </div>
              <div class="feilv-details-item">
                <div class="feilv-d-key feilv-d-tips">
                  利息和费用(元)<img src="../../static/images/Bitmap.png"
                               alt=""
                               @click="$refs.fymx.show()">
                </div>
                <div class="feilv-d-value">
                  {{ feilv.interest||0 }}
                </div>
              </div>
              <div class="feilv-details-item">
                <div class="feilv-d-key">
                  每{{ feilv.durationType===0?'日':'月' }}应还(元)
                </div>
                <div class="feilv-d-value">
                  {{ feilv.repayPerTime||0 }}
                </div>
              </div>
            </div>
          </div>
          <!-- 日利率、放款时间、参考通过率。产品详情及API产品详情展示 -->
          <div v-if="pstatus==0||pstatus==1||pstatus==4"
               class="info-bottom">
            <div v-if="productDetail.rate"
                 class="info-bottom-item">
              {{ productDetail.rate.split(':')[0] }}<span>{{ productDetail.rate.split(':')[1] }}</span>
            </div>
            <div class="info-bottom-item">
              <span>{{ productDetail.loanTime }}</span>放款
            </div>
            <div class="info-bottom-item">
              参考通过率<span>{{ productDetail.passRate }}</span>
            </div>
          </div>
          <!-- 资质不符 -->
          <section v-if="pstatus==2"
                   class="detail-fail">
            <img :src="require('APP_IMG/examine_fail.png')"
                 class="detail-fail-icon">
            <div class="detail-fail-tips">
              资质不符
            </div>
            <div class="detail-fail-subtitle">
              您的资质不符合该产品的申请条件，请尝试其他产品！
            </div>
          </section>
          <!-- 出错啦 -->
          <section v-if="pstatus==3"
                   class="detail-fail">
            <img :src="require('APP_IMG/global_error.png')"
                 class="detail-fail-icon">
            <div class="detail-fail-tips">
              {{ productDetail.name }}出错啦
            </div>
            <div class="detail-fail-subtitle">
              请您浏览其他的产品！
            </div>
          </section>
        </ProductCardInfo>
        <!-- 申请说明 -->
        <section v-if="(pstatus==0||pstatus==1||pstatus==4)&&applyTips.length > 0"
                 class="detail-middle">
          <div class="apply-tips">
            <p class="title">
              申请说明
            </p>
            <p class="detail"
               v-html="applyTips"></p>
          </div>
          <div v-if="littleTips.length > 0"
               class="little-tips"
               v-html="'小贴士:' + littleTips">
          </div>
        </section>
        <!-- 办理流程 -->
        <section v-if="(pstatus==0||pstatus==1||pstatus==4)&&applyFlow.length > 0"
                 class="detail-bottom">
          <div class="apply-flow">
            <p class="title">
              办理流程
            </p>
            <p class="detail"
               v-html="applyFlow"></p>
          </div>
        </section>
        <!-- 申请步骤 -->
        <section v-if="pstatus==1"
                 class="apply-step">
          <div class="split-block"></div>
          <div class="apply-step-title bb-1px">
            完成以下资料即可放款
          </div>
          <ul class="apply-step-list">
            <li v-for="(auth, index) in authList"
                :key="index"
                class="apply-step-item bb-1px">
              <img :src="auth.authIcon1"
                   class="apply-step-icon">
              <div class="apply-step-right"
                   @click="fillLoanInfo(index, auth, auth.eventId)">
                <div class="apply-step-name"
                     v-text="auth.authName"></div>
                <div v-if="auth.authStatus==1"
                     class="apply-step-btn sts3"
                     lang="zh-CN"
                     v-text="'已认证'"></div>
                <div v-else
                     class="apply-step-btn"
                     :class="auth.authStatus==2 ? 'sts4' : index==curIdx ? 'sts2' : 'sts1'"
                     lang="zh-CN"
                     v-text="auth.authStatus==2?'已失效':'未认证'"></div>
                <Arrow direction="right"
                       color="#ccc"></Arrow>
              </div>
            </li>
          </ul>
        </section>
        <!-- API全流程协议 -->
        <div v-if="pstatus==1&&protocolInfos && protocolInfos.length > 0"
             class="api-protocols"
             @click="protocolChecked=!protocolChecked">
          <div class="api-protocols-check"
               :class="protocolChecked?'checked':'nocheck'"></div>
          <div class="api-protocols-tips">
            我已阅读并同意
            <span v-for="(p, index) in protocolInfos"
                  :key="index"
                  @click.stop="openProtocol(p.address, p.name, 'cpxq;fwxy;w181')">《{{ p.name }}》</span>
          </div>
        </div>
        <!-- 为您推荐 -->
        <section v-if="(pstatus==2||pstatus==3)&&recommendProList.length>0"
                 class="detail-recommend">
          <div class="detail-recommend-title">
            为您推荐
          </div>
          <ProductList :list="recommendProList"
                       :pstatus="pstatus"
                       :category="category"></ProductList>
        </section>
        <div v-if="pstatus==0"
             key="s1"
             class="fixed-split-block-1"></div>
        <div v-else
             key="s2"
             class="fixed-split-block-2"></div>
        <!-- 立即申请按钮 -->
        <div v-show="pstatus==0&&show.applyBtn"
             class="apply-button"
             :class="{'bg-fff': needJoinLogin}">
          <p v-show="needJoinLogin">
            点击立即申请即表示您同意<span @click="openProtocol(productDetail.regAgreeUrl, '用户注册协议')">《{{ productDetail.name }}注册协议》</span>
          </p>
          <div class="button jrcs-btn"
               @click="joinLogin">
            立即申请
          </div>
        </div>
        <div v-if="pstatus==4&&extraMsg&&extraMsg.productType==1"
             class="apply-button">
          <div class="button jrcs-btn"
               @click="noPassApply()">
            立即申请
          </div>
        </div>
        <!-- 补充认证资料 -->
        <div v-if="pstatus==1"
             class="api-bottom-container">
          <div class="api-bottom-btn jrcs-btn"
               @click="apiProductSubmit(apiProductSubmitBtn.eventId)"
               v-text="apiProductSubmitBtn.txt"></div>
        </div>
        <!-- 资质不符和出错了页面，展示更多推荐按钮，点击跳转贷款大全 -->
        <div v-if="pstatus==2||pstatus==3"
             class="api-bottom-container">
          <div class="api-bottom-btn jrcs-btn"
               @click="tjMoreClick()">
            更多推荐
          </div>
        </div>
        <VLoad :isload="show.isLoad"></VLoad>
      </div>
      <Loading v-show="show.isLoading"></Loading>
    </div>
    <BasicInfo ref="basicInfo"></BasicInfo>
    <!-- 联合登录弹窗 -->
    <Confirm ref="jointLanding"
             class="joint-landing-dialog"
             title=""
             :close-flag="true"
             @on-close="jointLandingClose">
      <h2 class="title bb-1px"
          v-html="jointLandingInfos.title"></h2>
      <p class="subtitle">
        {{ jointLandingInfos.subtitle }}
      </p>
      <div v-for="(p, index) in jointLandingInfos.products"
           :key="index"
           class="content"
           @click="invokedByNative(index + 1)">
        <img :src="p.logo"
             alt="logo"
             class="logo">
        <div class="main">
          <div class="main-left">
            <span class="main-left-title">{{ p.name }}</span>
            <span v-html="p.limit"></span>
          </div>
          <p class="tip"
             v-html="p.desc"></p>
        </div>
        <!-- <span class="arrow"></span> -->
      </div>
    </Confirm>
    <!-- 费用明细 -->
    <Confirm ref="fymx"
             title="费用明细"
             sure-txt="确认">
      <div class="fymx-list">
        <div class="fymx-item">
          <div>到账金额</div>
          <div>{{ feilv.limit||0 }}元</div>
        </div>
        <div class="fymx-item">
          <div>利息</div>
          <div>{{ feilv.interest||0 }}元</div>
        </div>
        <div class="fymx-item">
          <div>手续费</div>
          <div>0元</div>
        </div>
        <div class="fymx-item">
          <div>每{{ feilv.durationType===0?'日':'月' }}应还</div>
          <div>{{ feilv.repayPerTime||0 }}元</div>
        </div>
        <div class="fymx-item">
          <div>总应还</div>
          <div>{{ feilv.totalRepay }}元</div>
        </div>
      </div>
    </Confirm>
    <ActionSheet ref="feilvAction"
                 :is-show="action.show"
                 :action-list="action.list"
                 :action-title="action.title"
                 @onHideAction="action.show=false"
                 @onSelectItem="action.onSelect"></ActionSheet>
  </PageView>
</template>

<script>
// import LoanCard from '@/components/card/index'
import ProductCardInfo from '@/components/product/ProductCardInfo'
import ProductList from "../components/productlist/list";
// import ProgressBar from "vue-radial-progress";
import VLoad from "../components/load.vue";
import ActionSheet from "../components/action-sheet"
// import bridge from "../util/jsbirdge";
import BasicInfo from "../components/basicInfo/index"
import {
  requestProductDetail,
  requestJoinLogin,
  requestLoginFailPro,
  orderSubmitApi,
} from "../api/controller/product";
import { firstPushApi } from '@/api/controller/api';
import Loading from "../components/loading/loading";
// import { getBasicInfoApi, submitAuthStatusApi } from "../api/controller/openAccount";
import utils from "../util/utils.js";
import Arrow from '../components/common/arrow.vue'
import eventCtr from "../../static/js/eventCtr"
import Confirm from "@/components/confirm/index"

/* eslint-disable eqeqeq */
export default {
  name: "ProductDetail",
  components: {
    // LoanCard,
    ProductCardInfo,
    VLoad,
    // vAbnor,
    Loading,
    ProductList,
    Arrow,
    BasicInfo,
    Confirm,
    ActionSheet,
  },
  data () {
    return {
      extraMsg: {},
      feilv: {
        limit: 0,
        interest: 0,
        repayPerTime: 0,
        totalRepay: 0,
      },
      action: {
        show: false,
        list: [],
        title: '',
        onSelect: null,
      },
      prdId: this.$route.params.prdId,
      category: this.$route.params.category || 12,
      // 页面状态：0-旧版本详情页，1-API全流程详情页，2-资质不符，3-出错啦，4-未过审详情页
      pstatus: this.$route.query.pstatus || 0,
      show: {
        isLoading: false,
        // processBarConfig: {
        //   completedSteps1: 0,
        //   completedSteps2: 0,
        //   completedSteps3: 0,
        //   totalSteps: 100,
        //   animateSpeed: 600,
        //   diameter: 76,
        //   strokeWidth: 4.5,
        //   startColor: "#FF601A",
        //   stopColor: "#ff8f00",
        //   innerStrokeColor: "#f2f2f2",
        //   timingFunc: "ease-in"
        // },
        isLoad: "block",
        applyTips: "",
        applyFlow: "",
        littleTips: "",
        applyBtn: true,
      },
      showErrorPage: false, // 网络异常
      errorPageInfo: {},
      // productInfo: {},
      productDetail: {},
      phone: "",
      w: this.$route.query.w,
      p: this.$route.query.p,
      t: this.$route.query.t || 0,
      recommendProList: [],
      productStatus: "", // 0 表示联等成功 1 表示系统维护中 2 表示已注册
      needJoinLogin:
        this.$route.query.supportJoinLogin === "true" ||
        this.$route.query.supportJoinLogin === '1', // 从url中获取的这个值是个字符串，需要转成布尔值
      buttonClicked: false,
      // 申请步骤状态信息
      stepStatusArr: {
        "0": 'ss-no ss-disabled', // 未认证 不可点击
        "1": 'ss-no', // 未认证 可点击
        "2": 'ss-yes', // 已认证
      },
      // 申请步骤
      /**
       * authStatus: 认证状态。0-未认证，1-已认证，2-已失效
       * authType：CA：身份认证；CON：联系人认证；MOP：手机运营商认证；OTH：补充信息认证
       * authName：与authType对应
       * authIcon：0未认证状态图标，1已认证状态图标
       * url：页面链接
       */
      authListDefault: [ // 默认资料项配置
        { authType: 'CA', authName: '身份认证', url: `/identityAuth?productId=${this.$route.params.prdId}&source=1&w=177`, eventId: 'cpxq;sfrz;w177', authIcon1: require('APP_IMG/details_icon_idcard.png') },
        { authType: 'CON', authName: '紧急联系人', url: `/emergencyContact?productId=${this.$route.params.prdId}&source=1&w=178`, eventId: 'cpxq;jjlxr;w178', authIcon1: require('APP_IMG/details_icon_linkman.png') },
        { authType: 'MOP', authName: '运营商认证', url: '', eventId: 'cpxq;yysrz;w179', authIcon1: require('APP_IMG/details_icon_number.png') },
        { authType: 'OTH', authName: '补充信息', url: `/otherInfo?productId=${this.$route.params.prdId}&source=1&w=180`, eventId: 'cpxq;qtxx;w180', authIcon1: require('APP_IMG/details_icon_else.png') },
      ],
      authList: [], // 申请步骤资料项
      infosFillAll: false, // 资料是否已填完
      // 接口获取资料完善状态
      // authStatusObj: {
      //   CA: 0, CON: 0, MOP: 0, OTH: 0
      // },
      // // 资料填写顺序
      // authOrderIdx: {
      //   CA: 0, CON: 1, MOP: 2, OTH: 3
      // },
      curIdx: 0, // 当前待填写资料index值
      apiProductSubmitBtn: {
        txt: '补充认证信息',
        eventId: 'cpxq;bcrzxx;w182',
      },
      protocolInfos: [], // 支持API全流程产品所有协议
      protocolChecked: true, // 支持API全流程产品协议是否勾选
      nameIdcardEditAll: false, // 姓名身份证号已填写标识
      jointLandingInfos: { // 联登弹窗数据
        products: [],
        subtitle: '',
        title: '',
      },
    };
  },
  computed: {
    applyTips: function () {
      var tips = this.productDetail.applyTips || "";
      return tips.replace(/\n/g, "<br/>");
    },
    applyFlow: function () {
      var tips = this.productDetail.applyFlow || "";
      return tips.replace(/\n/g, "<br/>");
    },
    littleTips: function () {
      var tips = this.productDetail.tips || "";
      return tips.replace(/\n/g, "<br/>");
    },
    appVersion () {
      return this.$store.state.baseInfo.appVersion.split(".").join("");
    },
  },
  watch: {
    curIdx (val) {
      let self = this;
      let l = self.authList.length
      if (val > 0 && val >= l) {
        self.infosFillAll = true;
        self.apiProductSubmitBtn = {
          txt: '提交申请',
          eventId: 'cpxq;tjsq;w183',
        };
      } else {
        self.infosFillAll = false;
        self.apiProductSubmitBtn = {
          txt: '补充认证信息',
          eventId: 'cpxq;bcrzxx;w182',
        };
      }
    },
    '$route' (to, from) {
      if (from.name === 'productDetail' && to.name === 'productDetail' && (from.path !== to.path)) {
        this.$routerGo(0);
      }
    },
  },
  created () {
    var self = this;
    self.$appInvoked("appGetMobilephone", {}, function (data) {
      self.$store.commit("PHONE_NUMBER", data);
      self.phone = data;
    });
  },
  mounted () {
    // 获取姓名和身份证是否已填写
    eventCtr.$on("nameIdcardEditAll", (msg) => {
      this.nameIdcardEditAll = msg
    })
  },
  activated () {
    this.interceptAppBack()
    this.showErrorPage = false
    var self = this;
    self.prdId = self.$route.params.prdId;
    var category = self.$route.params.category
    category = (category === 'undefined' || category === 'null') ? 12 : category
    self.category = category;
    self.t = self.$route.query.t || 0;
    self.needJoinLogin =
      self.$route.query.supportJoinLogin === "true" ||
      self.$route.query.supportJoinLogin === '1';
    self.showErrorPage = false;
    self.pstatus = self.$route.query.pstatus || 0;
    this.show.isLoad = "block";
    this.$nextTick(() => {
      if (self.pstatus == 4) {
        let extraMsg = {}
        try {
          extraMsg = JSON.parse(localStorage.getItem('no-pass-product-extraMsg'))
        } catch (error) {
          // 
        }
        self.initExtraMsg(extraMsg)
      }
      setTimeout(() => {
        self.getProDetail();
        let pstatus = self.pstatus;
        // 资质不符&出错啦展示为你推荐
        if (pstatus == '2' || pstatus == '3') {
          self.invokeLoginFail('wntj');
        } else if (pstatus == '1') {
          // 进入API全流程产品页
          self.collectEventMD({
            eventId: '1003',
            eventResult: 1,
            eventStartTime: new Date().getTime(),
            productId: self.prdId,
          });
        }
      }, 500);

      setTimeout(() => {
        this.show.isLoad = "none";
      }, 10000);
    });
    // window.goBackPage = this.goBackPage;
    // window.topPreRecommend = this.topPreRecommend;
    this.show.applyBtn = true;
    window.vueApp = this;
  },
  methods: {
    // 初始化费率计算数据
    initExtraMsg (extraMsg) {
      let limitList = []
      let durationList = []

      // 计算借款金额
      let l1 = this.createArray(extraMsg.productLimitStart, extraMsg.productLimitEnd, 1000)
      for (let i = 0; i < l1.length; i++) {
        limitList.push({ dictName: l1[i] })
      }

      // 计算借款期限
      let l2 = []
      if (extraMsg.durationType === 0) { // 0-天，1-月
        if (extraMsg.durationStart < 30) {
          l2 = ['单期']
        } else {
          l2 = this.createArray(extraMsg.durationStart, extraMsg.durationEnd, 10)
        }
      } else {
        l2 = this.createArray(extraMsg.durationStart, extraMsg.durationEnd, 1)
      }
      for (let i = 0; i < l2.length; i++) {
        durationList.push({ dictName: l2[i] })
      }

      this.feilv = {
        ...this.feilv,
        limit: extraMsg.productLimitEnd,  // 额度
        duration: l2[l2.length - 1], // 期限
        durationType: extraMsg.durationType, // 期限类型：0-天，1-月
        limitList, durationList,
      }
      this.extraMsg = extraMsg

      this.$nextTick(() => {
        this.computedFee(extraMsg.productLimitEnd, l2[l2.length - 1])
      })
    },
    // 试算
    computedFee (limit, duration) {
      // rateType: 0-日利率，1-月利率，2-年利率
      // durationType: 0-天，1-月
      // let feilv = this.feilv
      let extraMsg = this.extraMsg
      let { rateType, durationType, rateStart, rateEnd } = extraMsg
      let rateYear = 0 // 年利率，百分数，最后再除以100，避免数据太小，js计算为0
      if (rateType === 0) {
        rateYear = (rateStart + rateEnd) * 360 / 2
      } else if (rateType === 1) {
        rateYear = (rateStart + rateEnd) * 12 / 2
      } else {
        rateYear = (rateStart + rateEnd) / 2
      }
      let interest = 0 // 利息
      if (durationType === 1) {
        interest = limit * rateYear * duration / 12 / 100
      } else {
        if (duration === '单期') {
          duration = 30
        }
        interest = limit * rateYear * duration / 360 / 100
      }
      this.feilv.repayPerTime = ((limit + interest) / duration).toFixed(2)
      this.feilv.interest = interest.toFixed(2)
      this.feilv.totalRepay = (limit + interest).toFixed(2)
    },
    showAction (type) {
      let feilv = this.feilv
      if (type === 'limit') {
        this.action.title = '借款金额（元）'
        this.action.list = feilv.limitList
        this.action.onSelect = (item) => {
          feilv.limit = item.dictName
          this.computedFee(item.dictName, feilv.duration)
        }
      } else if (type === 'duration') {
        this.action.title = `借款期限（${feilv.durationType === 0 ? '天' : '月'}）`
        this.action.list = feilv.durationList
        this.action.onSelect = (item) => {
          this.feilv.duration = item.dictName
          this.computedFee(feilv.limit, item.dictName)
        }
      }
      this.action.show = true
    },
    noPassApply () {
      this.$appInvoked("appOpenWebview", {
        url: this.extraMsg.address,
        needLogin: true,
        nav: {
          title: {
            text: this.productDetail.name,
          },
        },
      })
    },
    // 创建数组
    createArray (start = 0, end = 0, step = 1) {
      let arr = []
      arr.push(start)
      for (let i = Math.floor((start + step) / step) * step; i < end; i += step) {
        if (Math.floor(i / step) * step < end) {
          arr.push(Math.floor(i / step) * step)
        }
      }
      if (end > start) {
        arr.push(end)
      }
      return arr
    },
    // 关闭联合登录弹框
    jointLandingClose () {
      let self = this
      if (self.productStatus == 2) {
        self.$appInvoked("appExecStatistic", {
          eventId: "cpxq;yjzc;gb;w168",
          eventType: 0,
        }); //添加埋点
        // self.clickReport("cpxq;yjzc;gb;w168");
      } else if (self.productStatus == 1) {
        self.$appInvoked("appExecStatistic", {
          eventId: "cpxq;xtwh;gb;w170",
          eventType: 0,
        }); //添加埋点
        // self.clickReport("cpxq;xtwh;gb;w170");
      }
      self.$refs.jointLanding.hide()
    },
    tjMoreClick () {
      this.$routerPush('/productlist')
    },
    invokedByNative (index) {
      var self = this;
      var locateId = self.productStatus == 1 ? "171" : "169";
      var proObj = self.recommendProList[index - 1];
      let w = locateId, p = index;
      self.needUserLogin(w, () => {

        let productId = proObj.id,
          name = proObj.name,
          category = proObj.category;
        if (proObj.supportApiLoan) {
          let uri = `?category=${category}&productId=${productId}&productName=${name}&p=${p}&w=${w}&supportJoinLogin=${proObj.supportJoinLogin}&t=${proObj.rank}`;
          let eventId = `chanpin0;w${w};p${p};c${productId};l${window.$config.get('events.linkSeqId')};t${proObj.rank}`;
          self.clickReport(productId, category, eventId);
          self.$appInvoked("appExecStatistic", {
            eventId: eventId,
            eventType: 2,
          }); //添加埋点
          // 姓名和身份证号是否已填写
          if (!self.nameIdcardEditAll) {
            self.$refs.basicInfo.getBasicInfoFun((nameIdcardEditAll) => {
              if (nameIdcardEditAll) {
                // 已填写 去撞库
                self.$routerPush('/loanHit' + uri)
              } else {
                // 未填写去基本信息补充页
                self.$routerPush('/basicInfo' + uri)
              }
            })
          } else {
            // 已填写 去撞库
            self.$routerPush('/loanHit' + uri)
          }
        } else {
          self.toproDetail(name, proObj.address, productId, w, p, proObj.type, false, category, proObj.linkSeqId, proObj)
        }
      })
    },
    toproDetail (
      name,
      url,
      productId,
      w,
      p,
      goFlag,
      needBackDialog,
      category,
      linkSeqId,
      proObj
    ) {
      var self = this;

      // chanpin0进入产品详情页，chanpin1进入H5落地页，chanpin2阻止用户申请
      let eventId = `chanpin0;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
      if (goFlag == 2) { // 0-产品详情，2-第三方注册页
        eventId = `chanpin1;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
        let supportJoinLogin = proObj.supportJoinLogin; // 是否支持联登
        if (supportJoinLogin) { // 支持联合登录
          self.isLoad = 'block';
          let params = {
            linkId: linkSeqId,
            productId: productId,
          };
          requestJoinLogin(params).then((data) => {
            self.isLoad = 'none';
            if (data.respCode === '1000') {
              data = data.body;
              let regStatus = data.regStatus;
              // 0-未知 1-注册失败 2-金融超市注册成功 3-失败：其他渠道已有用户
              if (regStatus == 2) {
                self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
              } else if (regStatus == 3) {
                utils.toastMsg(`您已注册过${name}，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              } else {
                utils.toastMsg(`${name}系统维护中，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              }
            } else {
              utils.toastMsg(`${name}系统维护中，请申请其他产品`);
              eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
              self.clickReport(productId, category, eventId);
            }
            self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
          }, () => {
            self.isLoad = 'none';
          });
        } else {
          // type = 1;
          // 打开第三方注册页
          self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
          self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
        }
      } else {
        self.clickReport(productId, category, eventId);
        self.$routerPush(
          "/productDetailBlank/" +
          category +
          "/" +
          productId +
          "?p=" +
          p +
          "w=" +
          w +
          "&supportJoinLogin=" +
          proObj.supportJoinLogin + '&t=' + proObj.rank
        );
        self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
      }
      self.$appInvoked("appOnPageEnd", { pageName: this.$route.meta.title });
      window.currentPageName = this.$route.meta.title;
    },
    filterProductList (type, proList) {
      var self = this;
      // console.log(type);
      var showList = proList.map((item) => {
        let pro = {};
        pro.id = item.id;
        pro.limit = "¥" + item.limit;
        pro.logo = item.logo;
        pro.name = item.name;
        pro.desc = item.rate + " | 放款时间:" + item.loanTime;
        return pro;
      });
      var title = "";
      // var subtitle = '<font color="#ff601a">' + self.productDetail.name + '</font>的用户还会申请'
      var subtitle = self.productDetail.name + "的用户还会申请";
      if (type == 1) {
        subtitle = "推荐您申请";
        title =
          '<span class="product-detail-color-remind">' +
          self.productDetail.name +
          "</span>出错啦~";
      } else {
        title =
          '您已经注册过<span class="product-detail-color-remind">' +
          self.productDetail.name +
          "</span>";
      }
      if (showList.length > 0) {
        self.jointLandingInfos = {
          products: showList,
          subtitle: subtitle,
          title: title,
        }
        self.$nextTick(() => {
          self.$refs.jointLanding.show()
        })
      } else {
        if (type == 1) {
          utils.toastMsg(self.productDetail.name + "系统维护中");
        } else {
          utils.toastMsg("您已经注册过" + self.productDetail.name);
        }
      }
    },
    invokeLoginFail (type) {
      var self = this;
      // bridge.showLoading();
      this.show.isLoading = true;
      var requestParams = {
        mobilePhone: self.$store.state.baseInfo.phoneNumber,
        topNum: 3,
      };
      requestLoginFailPro(requestParams).then(
        (data) => {
          self.show.isLoading = false;
          // bridge.hideLoading();
          if (data.respCode === "1000") {
            if (data.body.length >= 4) {
              self.recommendProList = self.formateProductList(data.body.splice(0, 3));
            } else {
              self.recommendProList = self.formateProductList(data.body);
            }
            if (type !== 'wntj') { // 不是为你推荐
              self.filterProductList(type, self.recommendProList);
            }
            // self.filterProductList(type, self.recommendProList);
          }
        },
        () => {
          // bridge.hideLoading();
          self.show.isLoading = false;
          // utils.toastMsg(err.respMsg);
        }
      );
    },
    joinLogin () {
      var self = this;
      if (this.buttonClicked) {
        return;
      }
      this.buttonClicked = true;
      setTimeout(() => {
        this.buttonClicked = false;
      }, 500);
      if (!this.needJoinLogin) {
        self.goDetail();
        return;
      }
      // bridge.showLoading();
      this.show.isLoading = true;
      setTimeout(() => {
        // bridge.hideLoading();
        self.show.isLoading = false;
      }, 1000);
      var requestParams = {
        productId: self.prdId,
        linkId: self.productDetail.linkSeqId,
      };

      let productClickEventId = `chanpin1;w158;p0;c${self.prdId};l${self.productDetail.linkSeqId};t${self.t}`;
      requestJoinLogin(requestParams).then(
        (data) => {
          var repData = data;
          // bridge.hideLoading();
          self.show.isLoading = false;
          if (repData.respCode === "1000") {
            if (data.body.regStatus == 0 || data.body.regStatus == 1) {
              // 0 未知, 1 未注册
              productClickEventId = `chanpin2;w158;p0;c${self.prdId};l${self.productDetail.linkSeqId};t${self.t}`;
              // this.$appInvoked("appGetVersion", {}, function (appVersion) {
              // if (appVersion && appVersion.split(".").join("") >= 230) {
              self.productStatus = 1;
              self.invokeLoginFail(1);
              // } else {
              //   //老版本的iOS HQDKThirdPartWebVC不支持toast，h5在此做个兼容
              //   utils.toastMsg("用户系统维护中");
              // }
              // });
            } else if (data.body.regStatus == 2) {
              // 2 已注册(金融超市导流用户)
              self.productStatus = 0;
              self.goDetail(true);
            } else if (data.body.regStatus == 3) {
              productClickEventId = `chanpin2;w158;p0;c${self.prdId};l${self.productDetail.linkSeqId};t${self.t}`;
              // 3 已注册(其他渠道导流用户)
              // this.$appInvoked("appGetVersion", {}, function (appVersion) {
              // if (appVersion && appVersion.split(".").join("") >= 230) {
              self.productStatus = 2;
              self.invokeLoginFail(2);
              // } else {
              //   //老版本的iOS HQDKThirdPartWebVC不支持toast，h5在此做个兼容
              //   utils.toastMsg("您已经注册过" + self.productDetail.name);
              // }
              // });
            } else {
              productClickEventId = `chanpin2;w158;p0;c${self.prdId};l${self.productDetail.linkSeqId};t${self.t}`;
              // 保底场景
              // this.$appInvoked("appGetVersion", {}, function (appVersion) {
              // if (appVersion && appVersion.split(".").join("") >= 230) {
              self.productStatus = 1;
              self.invokeLoginFail(1);
              // } else {
              //   //老版本的iOS HQDKThirdPartWebVC不支持toast，h5在此做个兼容
              //   utils.toastMsg("用户系统维护中");
              //   // this.$appInvoked("appToastMessage", { message: "用户系统维护中" });
              // }
              // });
            }
          } else if (repData.respCode === "1058") {
            productClickEventId = `chanpin2;w158;p0;c${self.prdId};l${self.productDetail.linkSeqId};t${self.t}`;
            // this.$appInvoked("appGetVersion", {}, function (appVersion) {
            // if (appVersion && appVersion.split(".").join("") >= 230) {
            self.productStatus = 1;
            self.invokeLoginFail(1);
            // } else {
            //   //老版本的iOS HQDKThirdPartWebVC不支持toast，h5在此做个兼容
            //   utils.toastMsg("用户系统维护中");
            // }
            // });
          } else {
            productClickEventId = `chanpin2;w158;p0;c${self.prdId};l${self.productDetail.linkSeqId};t${self.t}`;
            utils.toastMsg(data.respMsg);
          }
          self.clickReport(self.prdId || "", self.category || "", productClickEventId);
          self.$appInvoked("appExecStatistic", { eventId: productClickEventId, eventType: 2 }); //添加埋点
        },
        () => {
          // bridge.hideLoading();
          self.show.isLoading = false;
        }
      );
    },
    openProtocol (url, title, eventId) {
      var self = this;
      if (eventId) {
        self.$appInvoked('appExecStatistic', { eventId: eventId });
      }
      self.$appInvoked("appOpenWebview", {
        url: url,
        nav: {
          title: {
            text: title,
          },
        },
      });
      self.$appInvoked("appExecStatistic", {
        eventId: "cpxq;zcxy;w167",
        eventType: 0,
      }); //添加埋点
    },
    getProDetail () {
      var self = this;
      var requestParams = {
        id: self.prdId,
        category: self.category,
        supportJoinLogin: self.needJoinLogin ? 0 : 1,
      };

      requestProductDetail(requestParams).then(
        (data) => {
          self.show.isLoad = "none";
          if (data.respCode === "1000") {
            if (!data.body) return;
            self.productDetail = data.body;
            if (!self.needJoinLogin) {
              self.$set(self, "needJoinLogin", data.body.supportJoinLogin);
            }
            // self.productInfo = {
            //   logo: data.body.logo,
            //   name: data.body.name,
            //   limit: data.body.amount,
            //   rate: data.body.rate,
            //   duration: data.body.limitTime,
            //   prompt: data.body.subhead
            // };
            // var passrate = data.body.passRate.split("%")[0] / 100;
            // var lenderNumProgressBar = data.body.lenderNumProgressBar;
            // var loanTimeProgressBar = data.body.loanTimeProgressBar;
            // var formateRate = function (rate) {
            //   rate = parseInt(rate * 100);
            //   if (rate >= 95 && rate < 100) {
            //     rate = 95;
            //   }
            //   return rate;
            // }
            // self.show.processBarConfig.completedSteps1 = formateRate(lenderNumProgressBar);
            // self.show.processBarConfig.completedSteps2 = formateRate(passrate);
            // self.show.processBarConfig.completedSteps3 = formateRate(loanTimeProgressBar);

            // 申请步骤
            if (self.pstatus == 1) {
              // data.body.authInfos = [
              //   {authStatus: 1, authType: 'CA'},
              //   {authStatus: 1, authType: 'CON'},
              //   {authStatus: 2, authType: 'MOP'},
              //   {authStatus: 0, authType: 'OTH'}
              // ];
              // data.body.protocolInfos = [
              //   {name: '用户服务协议', address: 'https://www.baidu.com'},
              //   {name: '信息授权及使用协议', address: 'https://www.baidu.com'},
              //   {name: '立即贷开户协议', address: 'https://www.baidu.com'}
              // ];

              self.protocolInfos = data.body.protocolInfos;

              let authListDefault = self.authListDefault;
              let authTypeList = [], authStatusList = [];
              let authInfos = data.body.authInfos || [];
              for (let i = 0; i < authInfos.length; i++) {
                let item = authInfos[i];
                authTypeList.push(item.authType)
                authStatusList.push(item.authStatus)
              }
              self.authList = []
              let initAuthList = function (authType, authIdx) {
                let idx = authTypeList.indexOf(authType);
                if (idx > -1) {
                  let item = authListDefault[authIdx];
                  item.authStatus = authStatusList[idx];
                  self.authList.push(item);
                }
              }
              initAuthList('CA', 0);
              initAuthList('CON', 1);
              initAuthList('MOP', 2);
              initAuthList('OTH', 3);
              self.computeCurIdx();
            }
          }
        },
        () => {
          self.show.isLoad = "none";
          // self.reloadText = {
          //   reloadText: "网络异常",
          //   defaultImg: this.getCachedImages("loadFailIcon")
          // };
          // self.showErrorPage = true;
          self.initDefaultErrorPageInfos('offline')
        }
      );
    },
    computeCurIdx () {
      let that = this;
      let authList = that.authList;
      let idx = authList.length;
      for (let i = 0, l = authList.length; i < l; i++) {
        if ([0, 2].indexOf(authList[i].authStatus) > -1) {
          idx = i;
          break;
        }
      }
      that.curIdx = idx;
    },
    // 点击资料项
    fillLoanInfo (idx, auth, eventId) {
      let that = this;
      auth = auth || {};
      let authType = auth.authType;
      let curIdx = that.curIdx;
      if (eventId) {
        that.$appInvoked('appExecStatistic', { eventId: eventId });
      }
      if (idx > curIdx) {
        utils.toastMsg('请按顺序完成所有认证操作');
      } else if (idx == curIdx) {
        // if (authType === 'MOP') {
        //   that.fillMopInfo(that.prdId, that.$route.query.w, () => {
        //     let authList = that.authList
        //     for (let i = 0; i < authList.length; i++) {
        //       if (authList[i].authType === 'MOP') {
        //         that.authList[i].authStatus = 1;
        //         break
        //       }
        //     }
        //     that.$nextTick(function () {
        //       that.computeCurIdx();
        //     })
        //   });
        // } else {
        that.$routerPush(that.authList[idx].url);
        // }
      } else if (authType === 'CA' && auth.authStatus == 1) {
        // 身份认证和运营商认证完成后不可修改
        utils.toastMsg('身份认证不可修改');
        // } else if (authType === 'MOP') {
        //   // 身份认证和运营商认证完成后不可修改
        //   if ([0, 2].indexOf(auth.authStatus) > -1) {
        //     that.fillMopInfo(that.prdId, that.$route.query.w, () => {
        //       let authList = that.authList
        //       for (let i = 0; i < authList.length; i++) {
        //         if (authList[i].authType === 'MOP') {
        //           that.authList[i].authStatus = 1;
        //           break
        //         }
        //       }
        //       that.$nextTick(function () {
        //         that.computeCurIdx();
        //       })
        //     });
        //   } else {
        //     utils.toastMsg('手机运营商认证不可修改');
        //   }
      } else {
        that.$routerPush(that.authList[idx].url);
      }
    },
    // 支持API全流程产品提交按钮
    apiProductSubmit (eventId) {
      let self = this;
      if (eventId) {
        self.$appInvoked('appExecStatistic', { eventId: eventId });
      }
      if (!self.infosFillAll) {
        self.fillLoanInfo(self.curIdx, self.authList[self.curIdx]);
      } else {
        if (!self.protocolChecked) {
          utils.toastMsg('请阅读并同意申请协议');
        } else {
          let permissions = [1, 2, 4, 5]
          if (utils.isAndroid()) {
            // permissions = [4, 5]
            permissions = [4]
          } else if (utils.isIos()) {
            permissions = [2, 4]
          }
          // Android端：通讯录、短信、通话记录；iOS端：相册、通讯录
          self.$appInvoked('appAskPermissionStatus', {
            needShowPermissionAlert: true,
            permissions: permissions, // 1：相机，2：相册，3：麦克风，4：通讯录，5；短信，6：定位
          }, function (data) {
            let authList = data.permissionAuthorizationStatus;
            let noPmNo = 0;
            for (let i = 0, l = authList.length; i < l; i++) {
              if (authList[i].status != 1) {
                noPmNo++;
              }
            }
            if (noPmNo == 0) {
              self.show.isLoad = 'block';
              // 上传风控节点
              // self.$appInvoked('appUploadRiskData', { node: 203 }, function () {
              // 是否是立即贷API产品，用于做立即贷兼容
              let isLJDAPI = window.$config.get('LJDPRODUCTID') == self.prdId
              if (isLJDAPI) {
                // 调用进件接口
                orderSubmitApi({ productId: self.prdId }).then((data) => {
                  self.show.isLoad = 'none';
                  self.$routerReplace(`/checkResult?productName=${self.productDetail.name}&status=2&applyTime=${data.body.applyDate}&applyNeedTime=${data.body.applyNeedTime}`);
                }, (err) => {
                  self.show.isLoad = 'none';
                  if (err.respMsg) {
                    utils.toastMsg(err.respMsg);
                  }
                });
              } else {
                // 非立即贷API产品，调用一推接口
                firstPushApi({ productId: self.prdId }).then((data) => {
                  self.show.isLoad = 'none';
                  data = data.body
                  if (data.approved) {
                    // 一推通过，进入审核中页面
                    self.$routerReplace(`/loan/inAudit?orderNo=${data.orderNo}&productName=${self.productDetail.name}&productId=${self.prdId}&fromapp=${self.$route.query.fromapp}`)
                  } else {
                    // 返回不通过，进入审核失败页面
                    let checkResultPage = `/checkResult?productName=${self.productDetail.name}&nextApplyTime=${data.nextApplyTime}&fromapp=${self.$route.query.fromapp}&status=1`;
                    self.$routerReplace(checkResultPage);
                  }
                }, () => {
                  self.show.isLoad = 'none';
                })
              }
              // }, function () {
              //   self.show.isLoad = 'none';
              // });
            }
          });
        }
      }
    },
    goDetail (flag) {
      var self = this;
      let productId = self.prdId
      let category = self.category
      self.openThirdRegisterPage(name, self.productDetail.address, productId, self.w, self.p, category, self.productDetail.linkSeqId, self.t, 1)

      // console.warn(!flag);
      if (!flag) {
        let productClickEventId =
          "chanpin1;w158;p0;c" + productId + ";l" + self.productDetail.linkSeqId + ";t" + self.t;
        // 如果是联合登录的产品，在joinLogin里面会有调158埋点的
        self.$appInvoked("appExecStatistic", {
          eventId: productClickEventId,
          eventType: 2,
        }); //添加埋点
        self.clickReport(productId, category, productClickEventId);
      }
    },
    rightClickHandle () {
      var self = this;
      self.show.applyBtn = false;
      self.$appInvoked("appExecStatistic", {
        eventId: "cpxq;jztj;w160",
        eventType: 0,
      }); //添加埋点
      self.globalRecommendClick(160)
    },
    backClickHandle () {
      if (this.w != "2" && this.w != "25") {
        this.$appInvoked("appExecStatistic", {
          eventId: "cpxq;fh;w159",
          eventType: 0,
        }); //添加返回埋点
        this.show.applyBtn = false;
      }
      // 当前页面返回如果history大于1说明能返回，则调js返回，如果history等于1，js调返回是无法返回的，此时需要调原生方法返回
      if (this.$route.query.fromapp === '1' || history.length < 2) {
        this.$appInvoked("appExecBack", "");
      } else {
        this.$routerGo(-1);
      }
    },
  },
};
</script>
<style lang="scss">
.product-detail-color-remind {
  color: $color-remind;
}
</style>

<style lang="scss" scoped="scoped">
#hqwy-mescroll {
  height: 100%;
  width: 100%;
  box-sizing: border-box;
  overflow-x: hidden;
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch;
}

.detail-middle {
  margin-top: rc(36);
  background: #fff;
  padding-bottom: rc(36);
  .little-tips {
    color: $color-remind;
    background-color: rgba($color-remind, 0.05);
    margin: rc(13 36 0);
    padding: rc(6 23);
    font-size: rc(24);
    line-height: rc(39);
  }
}

.apply-tips,
.apply-flow {
  padding: rc(0 36);
  .title {
    font-size: rc(36);
    line-height: rc(50);
    font-weight: bold;
    color: #111;
  }
  .detail {
    font-size: rc(24);
    line-height: rc(44);
    color: $color-text-tip;
    margin-top: rc(16);
  }
}

.detail-bottom {
  background: #fff;
  padding-bottom: rc(36);
}

.apply-button {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  // height: rc(120);
  line-height: rc(96);
  text-align: center;
  padding: rc(20) rc(30);
  &.bg-fff {
    background-color: #fff;
  }
  p {
    height: rc(24);
    line-height: rc(12);
    font-size: rc(24);
    color: #777;
    margin-bottom: rc(6);
    span {
      color: $color-remind;
    }
  }
  .button {
    border-radius: rc(100);
    font-size: rc(34);
    height: rc(96);
  }
}
.apply-step {
  background: #fff;
  .split-block {
    height: rc(20);
    background-color: $bgColor;
  }
  .apply-step-title {
    padding: rc(30 36 22);
    // border-bottom: 1px solid #ddd;
    font-size: rc(36);
    line-height: rc(50);
    color: #111;
    font-weight: bold;
  }
  .apply-step-item {
    display: flex;
    align-items: center;
    padding: rc(0 36);
  }
  .apply-step-icon {
    width: rc(44);
    height: rc(44);
    margin-right: rc(16);
  }
  .apply-step-right {
    flex: 1;
    display: flex;
    align-items: center;
    height: rc(96);
  }
  .apply-step-item:last-child {
    .apply-step-right,
    .apply-step-right::after {
      border-bottom: none;
    }
  }
  .apply-step-name {
    flex: 1;
    font-size: rc(30);
  }
  .apply-step-btn {
    font-size: rc(28);
    // 未完成
    &.sts1 {
      color: #aaa;
    }
    // 未完成可点击
    &.sts2 {
      color: $color-remind;
    }
    // 已完成
    &.sts3 {
      color: #444;
    }
    // 已失效
    &.sts4 {
      color: $color-warn;
    }
  }
}
.detail-fail {
  text-align: center;
  padding-bottom: rc(73);
  .detail-fail-icon {
    width: rc(162);
    height: rc(140);
    margin: rc(34) auto rc(16);
  }
  .detail-fail-tips {
    font-size: rc(36);
    color: #444;
    line-height: rc(50);
    font-weight: bold;
  }
  .detail-fail-subtitle {
    font-size: rc(26);
    color: #777;
    margin-top: rc(10);
    line-height: rc(37);
  }
}
.detail-recommend {
  background-color: #fff;
  .detail-recommend-title {
    padding: rc(36 36 0);
    font-size: rc(36);
    line-height: rc(50);
    color: #111;
    font-weight: bold;
  }
}
.fixed-split-block {
  &-1 {
    // height: rc(164);
    height: rc(184);
  }
  &-2 {
    // height: rc(256);
    height: rc(136);
  }
}
.api-bottom-container {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  padding: rc(20 30);
}
.api-protocols {
  padding: rc(0 30);
  display: flex;
  // align-items: center;
  margin-top: rc(20);
  margin-bottom: rc(18);
  &-check {
    width: rc(30);
    height: rc(30);
    margin-right: rc(10);
    margin-top: rc(2);
    &.checked {
      background: url(../../static/images/#{$APP_NAME}/global_check_normal.png) no-repeat center;
      background-size: 100% 100%;
    }
    &.nocheck {
      background: url(../../static/images/#{$APP_NAME}/global_check_selected.png) no-repeat center;
      background-size: 100% 100%;
    }
  }
  &-tips {
    flex: 1;
    font-size: rc(24);
    color: #777;
    span {
      color: $color-remind;
    }
  }
}
.api-bottom-btn {
  height: rc(96);
  border-radius: rc(100);
  font-size: rc(34);
  color: #fff;
}
.header-card {
  width: 100%;
  height: rc(280);
  background: $linear-bgColor;
}
.product-info-card {
  margin-top: rc(-240);
  box-shadow: 0px rc(8) rc(16) 0px rgba(0, 0, 0, 0.05);
  .info-middle {
    display: flex;
    height: rc(180);
    align-items: center;
  }
  .info-middle-item {
    width: 0;
    flex: 1;
    text-align: center;
    .info-title {
      font-size: rc(26);
      color: $color-text-tip;
    }
    .info-value {
      margin-top: rc(10);
      font-weight: bold;
      font-size: rc(40);
      color: $color-remind;
    }
  }
  .info-bottom {
    display: flex;
    align-items: center;
    justify-content: space-between;
    line-height: rc(90);
    padding: rc(0 30);
    font-size: rc(24);
    color: $color-text-tip;
    .info-bottom-item {
      position: relative;
      padding-left: rc(42);
      span {
        color: $color-remind;
      }
      &::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: rc(40);
        height: 100%;
        background: url(../../static/images/list_icon_pass.png) no-repeat left center;
        background-size: rc(30 30);
      }
    }
  }
}
.joint-landing-dialog {
  .title {
    font-size: rc(36);
    font-weight: bold;
    text-align: center;
    padding-bottom: rc(35);
  }
  .hy-confirm-content {
    width: 85%;
    box-sizing: border-box;
  }
  .hy-confirm-center {
    padding: 0 0 rc(36);
  }
  .subtitle {
    height: rc(67);
    line-height: rc(67);
    // padding-left: rc(40);
    color: $color-text-sub;
    font-size: rc(26);
  }
  .content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: rc(130);
    // padding: 0 rc(40);
    box-sizing: border-box;
    overflow: hidden;
  }
  .logo {
    width: rc(80);
    height: rc(80);
    border-radius: rc(12);
  }
  .main {
    flex: 1;
    margin-left: rc(19);
    width: 0;
  }
  .main-left {
    display: flex;
    justify-content: space-between;
    color: $color-remind;
    font-size: rc(34);
    overflow: hidden;
  }
  .main-left-title {
    font-size: rc(30);
    color: $color-text-title;
    font-weight: bold;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    flex: 1;
  }
  .tip {
    font-size: rc(24);
    color: $color-text-tip;
  }
  .arrow {
    display: block;
    width: rc(15);
    height: rc(25);
    background: url(../../static/images/arrow.png) no-repeat;
    background-size: contain;
    margin-left: rc(20);
  }
}
.info-feilv {
  padding: rc(42 30 30);
}
.feilv-infos {
  display: flex;
  .feilv-infos-item {
    width: 50%;
    text-align: center;
  }
  .feilv-infos-title {
    font-size: rc(26);
    line-height: rc(37);
    color: #999;
  }
  .feilv-infos-select {
    margin-top: rc(9);
    font-size: rc(40);
    height: rc(56);
    font-weight: bold;
    color: $color-remind;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    &.single {
      font-size: rc(36);
    }
    &::after {
      content: '';
      width: 0;
      height: 0;
      border-width: 5px 5px 0;
      border-radius: 1px;
      border-style: solid;
      border-color: #b8b8b8 transparent transparent;
      margin-left: 2px;
    }
  }
}
.feilv-details {
  margin-top: rc(23);
  height: rc(124);
  background-color: #f9f9f9;
  display: flex;
  align-items: center;
  justify-content: center;
  .feilv-details-item {
    width: 0;
    flex: 1;
    text-align: center;
  }
  .feilv-d-key {
    font-size: rc(24);
    line-height: rc(33);
    color: #999;
  }
  .feilv-d-tips {
    display: flex;
    align-items: center;
    img {
      width: rc(24);
      margin-left: rc(2);
    }
  }
  .feilv-d-value {
    font-size: rc(28);
    line-height: rc(40);
    color: #444;
    margin-top: rc(4);
  }
}
.fymx-list {
  font-size: rc(30);
  line-height: rc(70);
  .fymx-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
}
</style>
