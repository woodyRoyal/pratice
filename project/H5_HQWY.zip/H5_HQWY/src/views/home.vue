<template>
  <div>
    <div class="content">
      <keep-alive>
        <router-view class="child-view"></router-view>
      </keep-alive>
    </div>
    <VFooter></VFooter>
  </div>
</template>

<script>
import VFooter from "../components/footer.vue";

export default {
  name: "App",
  components: {
    VFooter,
  },
  data () {
    return {};
  },
  created () {
    window.onRelogin = this.onRelogin;
  },
  activated () {
    // console.warn("------> home activated");
  },
  methods: {
    onRelogin () {
      this.needUserLogin('', () => {
        window.location.reload();
      })
      // this.$appInvoked("appNeedUserLogin", {}, function(data) {
      //   if (data == true) {
      //     window.location.reload();
      //   } else {
      //     this.$routerPush("/home");
      //   }
      // });
    },
  },
};
</script>
