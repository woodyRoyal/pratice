<template>
  <PageView title=""
            :show-logo="true"
            :show-left="false"
            :class="{'activity-index':isActivityDialog}"
            :show-error-page="showErrorPage"
            :error-page-info="errorPageInfo"
            :has-tabbar="true"
            :right-txt="$config.get('module.sytsfk') ? '投诉/反馈' : ''"
            :right-class="$config.get('module.sytsfk') ? 'tsfk-icon' : ''"
            type="bg-fff"
            @rightClick="rightClickHandle">
    <div id="aa"
         ref="indexList"
         class="mescroll"
         style="width: 100%;height: 100%;overflow-y: auto;-webkit-overflow-scrolling: touch;">
      <div v-cloak
           id="bb"
           style="background-color: #fff">
        <!-- 首页公告小黄条 -->
        <div v-if="showGgTips"
             class="gg-tips">
          <div class="gg-tips-txt"
               @click="toGgDetail()">
            “立即贷”已全新升级为“立即借”啦！
          </div>
          <div class="gg-tips-close"
               @click="closeGgTipsHandler()"></div>
        </div>
        <!--跑马灯-->
        <div v-show="hasAuditPass&&horselist&&horselist.length>0"
             class="horse">
          <div class="horse-container">
            <div class="horse-left">
              <img :src="require('APP_IMG/horn.png')">
            </div>
            <div id="horse"
                 class="swiper-container swiper-no-swiping">
              <div class="swiper-wrapper horse-center">
                <div v-for="(hor,index) in horselist"
                     :key="index"
                     class="swiper-slide">
                  <!-- <div v-if="hor.type==1"
                       @click="getproList('热门产品',11,1,'sy;pmd;w32',{},4,32)">
                    据统计，申请<span>5个以上</span>产品，贷款成功率超过95%
                  </div> -->
                  <div v-if="hor.type==0 || hor.type==2"
                       @click="proListClick(hor.description,hor.address,hor.id,'33',index+1,hor.type,false,'11',hor.linkSeqId,hor)">
                    {{ hor.mobilephone }}刚刚在<span>{{ hor.description }}</span>成功借款{{ hor.price }}元
                  </div>
                </div>
              </div>
            </div>
            <div class="horse-right">
              <img src="../../static/images/arrow.png" />
            </div>
          </div>
        </div>
        <!-- banner -->
        <div v-if="bannerList && bannerList.length > 0"
             class="banner"
             :class="bannerType">
          <div id="banner"
               :class="'swiper-container swiper-container-' + bannerType">
            <div class="swiper-wrapper">
              <div v-for="(banner,index) in bannerList"
                   :key="index"
                   class="swiper-slide"
                   :class="bannerType=='api'?'api-banner':''">
                <!-- 普通banner -->
                <img v-if="bannerType=='common'"
                     v-lazy="{src:banner.banner,error:bannerIcon,loading:bannerIcon}"
                     class="common-banner"
                     :src="banner.banner"
                     :onerror="errorBanner" />
                <!-- APIbanner -->
                <div v-else-if="bannerType=='api'"
                     class="api-banner-container"
                     :class="bannerType=='api'?'banner-' + index % 5:''">
                  <div class="api-banner-top">
                    <div class="api-banner-name"
                         v-text="banner.name"></div>
                    <!-- 马上去借展示 -->
                    <div v-if="banner.apiProductInfo.status==1"
                         class="api-banner-sub"
                         v-text="banner.subhead"></div>
                    <div v-if="banner.apiProductInfo.status==1"
                         class="api-banner-title">
                      <img src="../../static/images/global_ic_app_white.png"
                           alt="">
                      <span v-text="banner.apiProductInfo.title"></span>
                    </div>
                  </div>
                  <div class="api-banner-content">
                    <div class="api-banner-left">
                      <div class="api-banner-amount"
                           v-text="banner.apiProductInfo.amountLine"></div>
                      <div v-if="banner.apiProductInfo.status==1"
                           class="api-banner-amount-tips">
                        申请额度/元
                      </div>
                      <div v-else-if="banner.apiProductInfo.status==2"
                           class="api-banner-amount-tips">
                        可借额度/元
                      </div>
                    </div>
                    <div class="api-banner-content-right">
                      <div v-if="banner.apiProductInfo.status==2"
                           class="api-banner-title2">
                        <img src="../../static/images/global_ic_success.png"
                             alt="">
                        <span v-text="banner.apiProductInfo.title"></span>
                      </div>
                      <div v-if="banner.apiProductInfo.status==1"
                           class="api-banner-btn"
                           lang="zh-CN">
                        马上去借
                      </div>
                      <div v-else-if="banner.apiProductInfo.status==2"
                           class="api-banner-btn"
                           lang="zh-CN">
                        立即提现
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="swiper-pagination"></div>
          </div>
        </div>
        <!-- 还款入口 -->
        <!-- <div class="repay-list"
             v-show="repayList && repayList.length > 0">
          <div id="repay"
               class="swiper-container">
            <div class="swiper-wrapper repay-center">
              <div :key="index"
                   class="swiper-slide repay-item"
                   v-for="(item,index) in repayList">
                <div class="repay-productname"
                     v-text="item.productName"></div>
                <div class="repay-splitline"></div>
                <div class="repay-date">{{item.dueDate | formateDate('M月D号')}}</div>
                <div class="repay-price"
                     v-cloak>应还&yen;{{item.dueAmount | toFixed(2)}}</div>
                <div class="repay-status-text"
                     :class="item.status==3?'rstc1':''"
                     v-text="item.status==3?'已逾期':'立即还款'"></div>
                <img class="repay-arrow"
                     src="../../static/images/arrow.png" />
              </div>
            </div>
          </div>
        </div> -->
        <!--分类-->
        <div v-show="hasAuditPass"
             class="class-list">
          <div v-for="(cate,index) in categorlist"
               :key="index"
               class="class-item"
               @click="getproList(cate.text, cate.category, cate.type, 'sy;fl;w'+(26+index+1), cate, index,(26+index+1))">
            <img :key="cate.logo"
                 v-lazy="{src:cate.logo,error:productIcon,loading:productIcon}"
                 class="item-img">
            <div class="item-text">
              {{ cate.text }}
            </div>
          </div>
        </div>
        <!--中部banner-->
        <div v-show="hasAuditPass"
             v-if="recommend && recommend.length > 0"
             class="mid-banner">
          <div v-for="(mb, index) in recommend"
               :key="index"
               class="mid-banner-item"
               @click="midBannerClick(mb, index)">
            <!-- 取接口返回值 -->
            <div class="mid-banner-tips">
              <div class="mid-banner-title">
                {{ mb.mainTitle }}
              </div>
              <div class="mid-banner-subtitle">
                {{ mb.subTitle }}
              </div>
            </div>
            <img :src="mb.img"
                 alt=" ">
          </div>
        </div>
        <!--预估可贷-->
        <div v-show="show.showGuessLoan && guessLoanList.length > 0 && hasAuditPass"
             class="guess-loan">
          <div class="guess-loan-title">
            <div class="guess-loan-title-left">
              你可能贷到的额度
            </div>
            <div class="guess-loan-ignore"
                 @click="ignoreGuessLoan">
              忽略
            </div>
          </div>
          <div id="guessLoad"
               class="swiper-container">
            <div class="swiper-wrapper">
              <div v-for="(item,index) in guessLoanList"
                   :key="index"
                   class="swiper-slide guess-slide b-1px"
                   @click="proListClick(item.name,item.address,item.id,156,index+1,item.type,true,'22',item.linkSeqId,item)">
                <!-- <guess-loan :itemInfo="item"></guess-loan> -->
                <div class="guess-top">
                  <img :key="item.logo"
                       v-lazy="{src:item.logo,error:productIcon,loading:productIcon}">
                  <div class="guess-name"
                       v-text="item.name"></div>
                </div>
                <div class="guess-price">
                  &yen;{{ item.averagePrice }}
                </div>
                <div class="guess-time"
                     v-text="'最快' + item.loanTime + '放款'"></div>
              </div>
              <div class="swiper-slide guess-slide b-1px guess-tj"
                   @click="guessNoClick()">
                <div class="guess-tj-tips">
                  都不合适?
                </div>
                <img class="guess-tj-icon"
                     :src="require('APP_IMG/global_icon_recommend2.png')">
                <div class="guess-tj-txt">
                  智能推荐
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--精选贷款-->
        <div class="pro">
          <div class="pro-title">
            精选贷款
          </div>
          <!-- 产品列表 -->
          <ProductList :list="proList"
                       :ad-infos="listAdInfos"
                       @on-click="onProductClick"
                       @ad-click="onAdClick"></ProductList>
          <img ref="imgLoad"
               src="../../static/images/loding.gif"
               style="display: none" />
        </div>
      </div>
      <!-- <div v-if="showErrorPage">
        <v-abnor :abnorText="reloadText"></v-abnor>
      </div> -->
    </div>
    <VLoad :isload="isLoad"></VLoad>

    <!--首页悬浮广告-->
    <div v-show="isShowAd && hasAuditPass"
         ref="imgAdd"
         class="susp-ad"
         style="visibility: hidden;">
      <img ref="suspAd"
           :src="adInfo.imgUrl"
           @click="suspAdClick(adInfo)" />
      <div class="ad-close"
           @click="closeAd()"></div>
    </div>
    <BasicInfo ref="basicInfo"></BasicInfo>
    <!-- <get-api-data ref="getApiData"></get-api-data> -->
    <!-- 过审判断 -->
    <AuditPass ref="auditPass"
               @begin-request="dataQuerySuccess=true"></AuditPass>
    <div slot="dialog">
      <!-- 活动弹窗 -->
      <div v-if="isActivityDialog"
           class="activity-dialog">
        <div class="activity-dialog-item">
          <img :src="activityInfos.imgUrl"
               alt=""
               @click="activityHandler(activityInfos)">
          <span class="activity-close-btn"
                @click="activityClose"></span>
        </div>
      </div>
    </div>
  </PageView>
</template>
<script>
import VLoad from "../components/load.vue";
import MeScroll from "mescroll.js";
// import MySwiper from "../../static/swiper-4.3.3.min";
import {
  requesHomeInfo,
  requestADSearchV2,
  requestCarousel,
  requestHomePage,
} from "../../src/api/controller/home";
import {
  requestCitys,
  requestSaveCity,
} from "../../src/api/controller/citylist";
import { requestJoinLogin } from "../../src/api/controller/product";
import BasicInfo from "../components/basicInfo/index"
import eventCtr from "../../static/js/eventCtr"
import utils from '../util/utils';
import AuditPass from '@/components/function/hasAuditPass'
import ProductList from '@/components/product/ProductList'
import { timeToDate } from '@/filters'

// var token = window.config.token;
/* eslint-disable eqeqeq */
export default {
  components: {
    // vAbnor,
    VLoad,
    BasicInfo,
    // getApiData,
    AuditPass,
    ProductList,
    // confirm,
    // DiversionConfirm,
  },
  filters: {
    formateDate (date, fmt) {
      return utils.formateDate(date, fmt)
    },
    toFixed (val, n) {
      val = Number(val)
      return val.toFixed(n)
    },
  },
  data () {
    return {
      showGgTips: false, // 展示提示小黄条
      deactivated: false, // 离开页面
      listAdInfos: {}, // 精选贷款列表硬广位信息
      bottomAdInfos: {}, // 底部硬广位信息
      isActivityDialog: false, // 是否展示活动
      activityInfos: '', // 活动弹窗信息
      // activityImgUrl: '', // 活动图
      // isNextPage: true,
      isLoadMore: false,
      mescroll: null,
      errorImg01:
        'this.src="' + require("APP_IMG/default.png") + '"',
      errorBanner:
        'this.src="' + require("APP_IMG/banner.png") + '"',
      bannerList: [], // banner
      categorlist: [], //分类
      recommend: [], //大分类列表
      proList: [], //精选产品列表
      horselist: [], //跑马灯列表
      DataList: [], //产品列表
      //分页信息
      PagePara: {
        dataover: false, //检测所有数据是否加载完
        dataloading: false, //检测是否正在加载数据
      },
      datacount: 0, //模拟数据加载次数
      // pageNum: 2, //分页从第二页开始
      showErrorPage: false, //网络异常时显示
      errorPageInfo: {},
      // reloadText: "",
      nodata: false, //没有更多数据了
      tagColor: "#568956",
      isLoad: "none", //默认页面没有loading动画,
      isShowAd: false, //首页悬浮广告 默认展示
      adInfo: "", //
      bannerSwiper: "",
      horseSwiper: "",
      repaySwiper: '',
      bannerIcon:
        this.getCachedImages("bannerIcon") ||
        require("APP_IMG/banner.png"), //banner占位图
      // noDataIcon:
      //   this.getCachedImages("noDataIcon") ||
      //   require("../../static/images/nodata.png"), //无产品图
      productIcon:
        this.getCachedImages("productIcon") ||
        require("APP_IMG/default.png"), //产品缩略占位图,
      adLoaded: false,
      show: {
        showGuessLoan: true,
      },
      guessLoanList: [],
      guessLoad: "",
      dataQuerySuccess: false,
      bannerType: 'common', // banner类型：common：原有banner，api：API_Banner
      nameIdcardEditAll: false, // 姓名身份证号已填写标识
      // repayList: [], // banner下还款入口列表
      pageSize: 10,
      hasAuditPass: false, // 是否已过审
    };
  },
  beforeRouteLeave (to, from, next) {
    this.isLoadMore = false;
    global.storage.set("indexListScrollTop", this.$refs.indexList.scrollTop);
    next();
  },
  beforeRouteEnter (to, from, next) {
    if (from.path === "/") {
      global.storage.set("indexListScrollTop", 0);
    }
    next((vm) => {
      if (
        (from.name && from.name === "cityList") ||
        from.name === "recommendList"
      ) {
        vm.isLoadMore = true;
      } else {
        vm.isLoadMore = false;
      }
      vm.$refs.indexList.scrollTop =
        global.storage.get("indexListScrollTop") || 0;
    });
  },
  activated () {
    var self = this;
    self.deactivated = false
    eventCtr.$on("maskerDownHandle", () => {
      eventCtr.$emit("maskerHandle", true)
    });
    eventCtr.$emit("maskerHandle", self.isActivityDialog)
    self.collectEventMD({
      eventId: 'jr1003',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
    })
    // 安卓点击物理返回键退出
    // if (isAndroid) {
    //   self.$appInvoked('appCleanWeb', { history: true })
    // }
    var refreshTime = localStorage.getItem("refreshTime") || {};
    if (
      self.$needRefreshData(JSON.parse(refreshTime)["home"]) &&
      document.readyState === "complete"
    ) {
      window.location.reload();
      var refreshTimeObj = JSON.parse(refreshTime);
      refreshTime["home"] = "";
      localStorage.setItem("refreshTime", JSON.stringify(refreshTimeObj));
    }
    self.updateSwiperStatus();
    setTimeout(function () {
      // self.isLoad = "none";
      self.closeLoading()
    }, 5000);

    self.$refs.suspAd.onload = () => {
      var imgAd = self.$refs.imgAdd;
      if (imgAd && imgAd.style != undefined) {
        imgAd.style.visibility = "visible";
      }
    };
    window.updateSwiperStatus = self.updateSwiperStatus;
    window.vueApp = this;
    // 获取姓名身份证
    self.$refs.basicInfo.getBasicInfoFun()

  },
  deactivated () {
    var self = this;
    self.deactivated = true
    try {
      self.horseSwiper &&
        self.horseSwiper != undefined &&
        self.horseSwiper.autoplay.stop();
      self.bannerSwiper &&
        self.bannerSwiper != undefined &&
        self.bannerSwiper.autoplay.stop();
      self.guessLoad &&
        self.guessLoad != undefined &&
        self.guessLoad.autoplay.stop()
    } catch (e) {
      self.$refs.auditPass.init(false, () => {
        window.location.reload();
      })
    }
  },
  updated () {
    this.$nextTick(function () {
      if (!this.isLoadMore) {
        this.$refs.indexList.scrollTop = global.storage.get(
          "indexListScrollTop"
        );
      }
    });
  },
  mounted () {
    var self = this;
    window.toProductlist = self.toProductlist
    // 读取项目配置：是否展示首页公告小黄条
    if (self.$config.get('module.syggTips')) {
      // 判断是否展示小黄条
      self.$appInvoked('appDataCache', {
        action: 2,
        key: 'HAS_SHOW_SY_GG',
        memoryCache: false,
      }, (rst) => {
        if (!rst) {
          self.showGgTips = true
        } else {
          self.showGgTips = false
        }
      })
    }
    self.closeLoading()
    self.loading()
    // self.isLoad = "block";
    self.$refs.auditPass.init(true, () => {
      // self.isLoad = "none";
      self.closeLoading()
      // 已过审
      self.hasAuditPass = true
      self.pageMounted()
    }, (rst, data) => {
      // self.dataQuerySuccess = true;
      // self.isLoad = "none";
      self.closeLoading()
      // 未过审
      self.hasAuditPass = false
      if (rst) {
        // 获取成功
        data = data.body
        if (data.productList.length > 0) {
          let bannerList = []
          if (data.bannerList && data.bannerList.length > 0) {
            for (let i = 0; i < data.bannerList.length; i++) {
              let item = data.productList[i]
              item.banner = data.bannerList[i]
              bannerList.push(item)
            }
          }
          self.formateBannerList(bannerList); // 顶部banner
          self.proList = self.formateProductList(data.productList.splice(0, 5)); //精选贷款列表
        } else {
          self.initDefaultErrorPageInfos('noData')
        }
        setTimeout(() => {
          self.mescroll && self.mescroll.endSuccess(self.proList.length, false);
        }, 500);
      } else {
        self.initDefaultErrorPageInfos('offline')
      }
      self.getLocationInfos()
    })
    // this.mescroll.setPageSize(1);
    var guessLoanTime = global.storage.get("guessLoanTime");

    if (guessLoanTime == null || guessLoanTime == "") {
      // 本地未存储guessLoanTime需要显示预估可贷
      global.storage.set("guessLoanTime", "");
      this.show.showGuessLoan = true;
    } else {
      var showGuessLoanDate = new Date(parseInt(guessLoanTime, 10)).getDate();
      var today = new Date().getDate();
      // 存储时间是否为当天日期?
      if (showGuessLoanDate == today) {
        // 当天则不显示
        var timestamp = new Date().getTime();
        global.storage.set("guessLoanTime", timestamp);
        this.show.showGuessLoan = false;
      } else {
        // 不是当天，则显示
        this.show.showGuessLoan = true;
        global.storage.set("guessLoanTime", "");
      }
    }
    setTimeout(() => {
      self.$refs.basicInfo.queryStatusFunc();
    }, 1000);
    // 获取姓名和身份证是否已填写
    eventCtr.$on("nameIdcardEditAll", (msg) => {
      this.nameIdcardEditAll = msg
    });
  },
  methods: {
    // 未过审产品点击
    noPassProductClick (obj, category, w, index) {
      this.needUserLogin(w, () => {
        localStorage.setItem('no-pass-product-extraMsg', JSON.stringify({ address: obj.address, ...obj.extraMsg }))
        this.$routerPush(`/productDetail/${category}/${obj.id}?pstatus=4&p=${index + 1}&w=${w}&supportJoinLogin=${obj.supportJoinLogin}&t=${obj.rank}`)
      })
    },
    toProductlist (eventid) {
      this.$appInvoked("appExecStatistic", {
        eventId: eventid,
        eventType: 0,
      }); //添加埋点
      this.$routerPush('/productlist')
    },
    // 到公告详情页
    toGgDetail () {
      this.$routerPush('/ljj/updateNoticeDetail')
    },
    // 关闭首页公告小黄条
    closeGgTipsHandler () {
      this.showGgTips = false
      this.$appInvoked('appDataCache', {
        action: 1,
        key: 'HAS_SHOW_SY_GG',
        memoryCache: false,
        value: 1,
      })
    },
    rightClickHandle () {
      if (this.$config.get('module.sytsfk')) {
        this.openHelpcenter()
      }
    },
    // 允许定位权限后，用户每次启动app进入首页或刷新页面时 保存省市信息
    getLocationInfos () {
      let that = this
      let getLocation = (isLogin) => {
        if (isLogin) {
          that.$appInvoked("appGetLocationCity", {}, function (cityInfo) {
            let currentCity
            if (!cityInfo || cityInfo.city.indexOf("定位") > -1) {
              currentCity = "定位失败"
            } else if (
              cityInfo.country.length > 0 &&
              cityInfo.country.indexOf("中国") === -1
            ) {
              currentCity = "未知位置"
            } else if (
              cityInfo.city.indexOf("香港") > -1 ||
              cityInfo.city.indexOf("澳门") > -1 ||
              cityInfo.city.indexOf("台湾") > -1
            ) {
              currentCity = "未知位置"
            } else {
              currentCity = cityInfo.city
              let cities = JSON.parse(localStorage.getItem('JRCS_ALL_CITY')) || []
              if (cities && cities.length > 0) {
                // 匹配城市ID并保存城市信息
                that.saveLocationInfos(currentCity, cities)
              } else {
                requestCitys({}).then((resp) => {
                  if (resp.respCode === "1000") {
                    cities = resp.body.cities
                    localStorage.setItem('JRCS_ALL_CITY', JSON.stringify(resp.body.cities))
                    // 匹配城市ID并保存城市信息
                    that.saveLocationInfos(currentCity, cities)
                  }
                })
              }
            }
          })
        }
      }
      if (isIos || isAndroid) {
        that.$appInvoked('appIsLogin', {}, (isLogin) => {
          getLocation(isLogin)
        })
      } else {
        let isLogin = false
        getLocation(isLogin)
      }
    },
    saveLocationInfos (currentCity, cities) {
      for (let i = 0; i < cities.length; i++) {
        if ((currentCity == cities[i].cityName || currentCity.indexOf(cities[i].cityName) > -1) && cities[i].cityNo) {
          requestSaveCity({ city: cities[i].cityNo })
          break
        }
      }
    },
    // 关闭活动弹框
    activityClose () {
      this.isActivityDialog = false;
      this.$store.commit('mainWindowAd', false)
      eventCtr.$emit("maskerHandle", false)
      this.mdAll('sy;tc;w26')
    },
    // 活动弹框点击
    activityHandler (item) {
      let that = this
      if (item.clickType == '2') {
        // 跳转指定链接
        that.needUserLogin(260, () => {
          let eventId = `zdlj;w260;p0;l${item.linkAddressId}`
          that.$appInvoked('appExecStatistic', { eventId: eventId });
          // that.clickReport(item.id, '20', eventId);
          that.collectEventMD({
            eventId: eventId,
            eventResult: 1,
            eventStartTime: new Date().getTime(),
          })
          that.isActivityDialog = false
          that.$store.commit('mainWindowAd', false)
          eventCtr.$emit("maskerHandle", false)
          that.jrcsOpenAppPage(260, item.linkAddress, item.mainTitle)
        })
      } else {
        // eslint-disable-next-line camelcase
        item.user_isActivityDialog = true
        that.proListClick(item.name, item.address, item.id, 25, 0, item.type, false, '20', item.linkSeqId, item)
      }
    },
    // 活动弹框
    homeAdAlertShow () {
      this.$appInvoked('appDataCache', { action: 2, key: 'KILL_APP', memoryCache: true }, (rst) => {
        if (rst !== '1') {
          this.$appInvoked('appDataCache', { action: 2, key: 'ACTIVITY_DIALOG', memoryCache: false }, (rst) => {
            // 逻辑:每天第一次调用pId，sort传0，调用一次后，再次调用都是上次接口的值
            let result = rst || '{}'
            const ACTIVITY_RESULT = JSON.parse(result);
            let pId = 0;
            let sort = 0;
            let time = timeToDate(new Date().getTime())
            if (ACTIVITY_RESULT && time == ACTIVITY_RESULT.time) {
              pId = ACTIVITY_RESULT.pId
              sort = ACTIVITY_RESULT.sort
            }
            requestADSearchV2({ category: 20, pId, sort }).then((res) => {
              if (res.respCode === "1000" && res.body && res.body.imgUrl) {
                this.isActivityDialog = true;
                this.$store.commit('mainWindowAd', true)
                if (!this.deactivated) {
                  eventCtr.$emit("maskerHandle", true)
                }
                this.activityInfos = res.body
                // this.activityImgUrl = res.body.imgUrl;
                this.$appInvoked('appDataCache', { action: 1, memoryCache: true, key: 'KILL_APP', value: '1' })
                this.$appInvoked('appDataCache', { action: 1, memoryCache: false, key: 'ACTIVITY_DIALOG', value: JSON.stringify({ pId: res.body.id, sort: res.body.sort, time: timeToDate(new Date().getTime()) }) })
              }
            })
          })
        }
      })
    },
    // 产品列表点击
    onProductClick (item, index) {
      if (!this.hasAuditPass) {
        this.noPassProductClick(item, 12, 36, index)
        return
      }
      this.proListClick(item.name, item.address, item.id, 36, index + 1, item.type, true, '9', item.linkSeqId, item)
    },
    // 硬广位点击
    onAdClick (item, position) {
      let that = this
      let category, w // 分类及埋点相关数据
      if (position === 'list') {
        // 列表硬广位
        category = 24
        w = 265
      } else if (position === 'bottom') {
        // 底部硬广位
        category = 25
        w = 267
        item = that.bottomAdInfos
      }
      if (item.clickType == '2') {
        // 跳转指定链接
        that.needUserLogin(w + 1, () => {
          let eventId = `zdlj;w${w + 1};p0;l${item.linkAddressId}`
          that.$appInvoked('appExecStatistic', { eventId: eventId });
          // that.clickReport(item.id, category, eventId);
          that.collectEventMD({
            eventId: eventId,
            eventResult: 1,
            eventStartTime: new Date().getTime(),
          })
          that.jrcsOpenAppPage(w + 1, item.linkAddress, item.mainTitle)
        })
      } else {
        that.proListClick(item.name, item.address, item.id, w, 0, item.type, false, category, item.linkSeqId, item)
      }
    },
    pageMounted () {
      let self = this
      window.onAdClick = self.onAdClick
      let autoRefresh = self.$route.query.autoRefresh; // 1-APP十分钟自动刷新，其他表示冷启动
      //首页悬浮广告是否展示
      self.getIndexInfo(autoRefresh);
      // self.getRepayList();
      self.gethorseList();
      self.$nextTick(() => {
        // self.isLoad = "block"; // 开始loading
        self.loading()
        setTimeout(() => {
          // self.isLoad = "none"; // 隐藏loading
          self.closeLoading()
        }, 500);
      });
      self.getad(); //首页悬浮广告
      self.getLocationInfos()
    },
    initGuessLoanSwiper () {
      var self = this;
      self.guessLoad && self.guessLoad.destroy(false);
      // size = size || self.guessLoanList.length;
      // size = size < 3 ? size : 2.5;
      self.guessLoad = new Swiper("#guessLoad", {
        direction: "horizontal",
        // slidesPerView: size,
        slidesPerView: 'auto',
        spaceBetween: 6,
        observer: true, //修改swiper自己或子元素时，自动初始化swiper
        observeParents: true, //修改swiper的父元素时，自动初始化swiper
      });
    },
    ignoreGuessLoan () {
      this.show.showGuessLoan = false;
      var timestamp = new Date().getTime();
      global.storage.set("guessLoanTime", timestamp);
      // 点击忽略埋点
      this.mdAll('sy;ygkd;hl;w157')
    },
    downCallback () {
      let self = this;
      self.$refs.auditPass.init(true, () => {
        // 已过审
        self.hasAuditPass = true
        localStorage.setItem("userLocation", ""); //下拉时候清除缓存城市
        global.storage.set("indexListScrollTop", 0);
        //松手之后执行逻辑,ajax请求数据，数据返回后隐藏加载中提示
        self.$appInvoked("appExecStatistic", {
          eventId: "sy;sx;w40",
          eventType: 0,
        }); //下拉刷新添加埋点
        self.mescroll && self.mescroll.setPageNum(2);
        self.getIndexInfo();
        // self.getRepayList();
        self.gethorseList();
        self.$nextTick(() => {
          self.$forceUpdate();
        });
        self.getLocationInfos()
      }, (rst, data) => {
        // 未过审
        self.hasAuditPass = false
        localStorage.setItem("userLocation", ""); //下拉时候清除缓存城市
        global.storage.set("indexListScrollTop", 0);
        if (rst) {
          // 获取成功
          data = data.body
          if (data.productList.length > 0) {
            let bannerList = []
            for (let i = 0; i < data.bannerList.length; i++) {
              let item = data.productList[i]
              item.banner = data.bannerList[i]
              bannerList.push(item)
            }
            self.formateBannerList(bannerList); // 顶部banner
            self.proList = self.formateProductList(data.productList.splice(0, 5)); //精选贷款列表
          } else {
            self.initDefaultErrorPageInfos('noData')
          }
          setTimeout(() => {
            self.mescroll && self.mescroll.endSuccess(self.proList.length, false);
          }, 500);
        } else {
          self.initDefaultErrorPageInfos('offline')
        }
        self.$nextTick(() => {
          self.$forceUpdate();
        });
        self.getLocationInfos()
      })
    },
    upCallback (page) {
      var self = this;
      // requestHomePage();
      let pageNum = page.num
      let requestParams = {
        currentPage: pageNum,
        pageSize: self.pageSize,
      };
      requestHomePage(requestParams).then(
        (data) => {
          var repData = data;
          var fyList = self.formateProductList(repData.body);
          self.isLoadMore = true;
          if (repData.respCode === "1000") {
            if (fyList.length < 10) {
              //没有下一页了
              // self.isNextPage = false;
              self.mescroll.endSuccess(fyList.length, false);
              self.mescroll.showNoMore();
              // self.productLoadEnd = true
            } else {
              self.mescroll.endSuccess(fyList.length, true);
              // self.productLoadEnd = false
            }
            self.proList = self.proList.concat(fyList);
          }
        },
        () => {
          self.mescroll && self.mescroll.endErr();
        }
      );
    },
    updateSwiperStatus () {
      var self = this;
      self.reinitHorseSwiper();
      self.reinitBannerSwiper();
      self.reinitRepaySwiper();
      self.initGuessLoanSwiper();
    },
    // 获取还款列表数据
    // getRepayList () {
    //   var that = this
    //   that.repayList = []
    //   that.$refs.getApiData.getRepayOrderInfo({}, data => {
    //     // let data = {
    //     //   body: [
    //     //     {dueAmount: 5000, dueDate: 1552443843441, productId: 397, productName: "立即贷", status: 2},
    //     //     {dueAmount: 6000, dueDate: 1552443843441, productId: 398, productName: "小鹅贷", status: 3},
    //     //     {dueAmount: 5000, dueDate: 1556841600000, productId: 397, productName: "立即贷", status: 0},
    //     //     {dueAmount: 5000, dueDate: 1556841600000, productId: 397, productName: "立即贷", status: 0}
    //     //   ]
    //     // }
    //     let repayList = data.body
    //     if (repayList && repayList.length > 0) {
    //       that.repayList = data.body
    //       that.$set(that.repayList, 0, data.body[0]);
    //       that.$nextTick(function () {
    //         that.reinitRepaySwiper()
    //       })
    //     }
    //   }, err => { })
    // },
    reinitHorseSwiper () {
      var self = this;
      self.horseSwiper && self.horseSwiper.destroy(false);
      if (self.horselist.length > 0) {
        self.horseSwiper = new Swiper("#horse", {
          allowTouchMove: false,
          loop: true,
          direction: "vertical",
          autoplay: {
            delay: 2000,
            stopOnLastSlide: false, //如果设置为true，当切换到最后一个slide时停止自动切换。（loop模式下无效）。
            disableOnInteraction: false, //用户操作swiper之后，是否禁止autoplay。默认为true：停止。
          },
        });
      }
    },
    reinitRepaySwiper () {
      var self = this;
      self.repaySwiper && self.repaySwiper.destroy(false);
      let repayList = self.repayList
      if (repayList && repayList.length > 0) {
        let loop = repayList.length > 1
        self.repaySwiper = new Swiper("#repay", {
          allowTouchMove: false,
          loop: true,
          direction: "vertical",
          // 如果需要分页器
          autoplay: loop ?
            {
              delay: 3500,
              stopOnLastSlide: false, //如果设置为true，当切换到最后一个slide时停止自动切换。（loop模式下无效）。
              disableOnInteraction: false, //用户操作swiper之后，是否禁止autoplay。默认为true：停止。
            } :
            false,
          on: {
            click: function () {
              var index = this.realIndex;
              self.repayClick(repayList[index], index)
            },
          },
        });
      }
    },
    repayClick (item, index) {
      var self = this
      let eventId = `huankuan;w241;p${index + 1};c${item.productId}`
      self.$appInvoked('appExecStatistic', { eventId: eventId, eventType: 2 });
      self.clickReport(item.productId, '12', eventId);
      self.$routerPush(`/order/detail?productId=${item.productId}&productName=${item.productName}&w=241&p=${index + 1}&orderNo=${item.orderNo}&loanOrderNo=${item.loanOrderNo}`)
    },
    reinitBannerSwiper () {
      var self = this;
      self.bannerSwiper && self.bannerSwiper.destroy(false);
      var bannerList = self.bannerList;
      var loop = bannerList.length > 1
      if (bannerList && bannerList.length > 0) {
        self.bannerSwiper = new Swiper("#banner", {
          loop: loop,
          direction: "horizontal",
          on: {
            click: function () {
              var index = this.realIndex;
              var banner = bannerList[index];
              self.bannerClickFunc(banner, index);
            },
          },
          // 如果需要分页器
          autoplay: loop ?
            {
              delay: 3500,
              stopOnLastSlide: false, //如果设置为true，当切换到最后一个slide时停止自动切换。（loop模式下无效）。
              disableOnInteraction: false, //用户操作swiper之后，是否禁止autoplay。默认为true：停止。
            } :
            false,
          pagination: loop ? { el: "#banner .swiper-pagination" } : false,
        });
      }
    },
    // 点击banner操作
    bannerClickFunc (banner, index) {
      let self = this;
      if (!this.hasAuditPass) {
        this.noPassProductClick(banner, 12, 259, index)
        return
      }
      // 普通banner广告位判断
      if (self.bannerType === 'common' && banner.clickType == '2') {
        self.needUserLogin(259, () => {
          let eventId = `zdlj;w259;p${index + 1};l${banner.linkAddressId}`
          self.$appInvoked('appExecStatistic', { eventId: eventId });
          // self.clickReport(banner.id, '6', eventId);
          self.collectEventMD({
            eventId: eventId,
            eventResult: 1,
            eventStartTime: new Date().getTime(),
          })
          // self.jrcsOpenAppPage(259, banner.linkAddress, banner.mainTitle)
          let linkAddress = banner.linkAddress || ''
          if (linkAddress.indexOf(`${this.$config.get('fullPath')}#/notice?position=`) > -1) {
            // 判断是公告详情页，直接进行路由跳转，不开新的webView
            linkAddress = linkAddress.replace(`${this.$config.get('fullPath')}#`, '')
            this.$routerPush(linkAddress)
          } else {
            self.$appInvoked('appOpenWebview', {
              url: linkAddress,
              nav: {
                title: {
                  text: banner.mainTitle,
                },
              },
            })
          }
        })
        return
      }
      let closeOldReport = false; // API_banner只添加新增埋点，去掉旧的产品点击埋点
      if (banner.supportApiLoan) {
        closeOldReport = true;
        let eventId = `chanpin0;w208;p${index + 1};c${banner.id};l${window.$config.get('events.linkSeqId')};t`;
        // 支持api产品，若展示为普通banner，需传梯度。APIbanner梯度默认为0
        if (self.bannerType === 'common') {
          eventId += banner.rank;
        } else {
          eventId += 0;
        }
        self.$appInvoked('appExecStatistic', { eventId: eventId, eventType: 2 });
        self.clickReport(banner.id, '6', eventId);
      }
      self.proListClick(banner.name, banner.address, banner.id, 24, index + 1, banner.type, true, "6", banner.linkSeqId, banner, closeOldReport);
    },
    //获取首页悬浮广告
    getad () {
      var self = this;
      let requestParams = {
        category: 21,
      };
      requestADSearchV2(requestParams).then(
        (data) => {
          var repData = data;
          if (repData.respCode === "1000") {
            if (repData.body != null) {
              self.adInfo = repData.body;
              if (self.adInfo.imgUrl != null && self.adInfo.imgUrl != "") {
                self.isShowAd = true;
                //判断首页悬浮广告是否点击过
                var myDate = new Date();
                var dates = myDate.toLocaleDateString();
                if (localStorage.getItem("isShowAd") == dates) {
                  self.isShowAd = false;
                } else {
                  self.isShowAd = true;
                }
              } else {
                self.isShowAd = false;
              }
            } else {
              self.isShowAd = false;
            }
          }
        },
      );
    },
    //获取首页详细信息
    getIndexInfo (autoRefresh) {
      var self = this;
      // 通知安卓，已发起接口请求
      self.dataQuerySuccess = true;
      self.loading()
      requesHomeInfo({}).then(
        (data) => {
          self.closeLoading()
          var repData = data;
          if (repData.respCode === "1000") {
            // 首页接口请求成功后再调原生弹窗，APP十分钟自动刷新机制不触发
            if (autoRefresh != 1) {
              // 展示首页弹窗广告
              self.homeAdAlertShow()
            }
            repData = repData.body;
            if (repData.banners && repData.banners.length > 0) {
              let banners = repData.banners; // 所有banner

              // banners.push({"supportApiLoan": true,"showApiBanner": true,"apiProductInfo": {"title": "无需下载","status": 1,"linkAddress": "https://www.baidu.com","amountLine": 3500},"id": 674,"name": "51开心袋","subhead": "告别被拒开心花钱开心袋","limit": "￥2000-8000","duration": "1-30天","rate": "日利率:0.03%","averagePrice": "6000","passRate": "20%","loanTime": "3分钟","applyTips": "1、年龄限制：18-45周岁；\n2、手机号使用时长：6个月以上；\n3、其他限制：身份证，实名手机号，银行卡。","applyFlow": "","tagName": "","tagColor": null,"prompt": "","detailPrompt": "","logo": "http://img.huaqianwy.com/wfree_upload/mc/sys/img/201809/34b52a38363451096a0283a974fff99a.png","banner": "http://img.huaqianwy.com/wfree_upload/mc/sys/img/201810/320ff23998bf6c5909f891576bf43cb2.jpg","midBanner": null,"address": "http://www.51kxdw.com/index.php/login/spread/cid/dkw22/num/dkw01","type": 2,"linkSeqId": 1,"supportJoinLogin": false});
              // banners.push({"supportApiLoan": true,"showApiBanner": true,"apiProductInfo": {"title": "审核已通过","status": 2,"linkAddress": "https://www.baidu.com","amountLine": 3500},"id": 674,"name": "51开心袋","subhead": "告别被拒开心花钱开心袋","limit": "￥2000-8000","duration": "1-30天","rate": "日利率:0.03%","averagePrice": "6000","passRate": "20%","loanTime": "3分钟","applyTips": "1、年龄限制：18-45周岁；\n2、手机号使用时长：6个月以上；\n3、其他限制：身份证，实名手机号，银行卡。","applyFlow": "","tagName": "","tagColor": null,"prompt": "","detailPrompt": "","logo": "http://img.huaqianwy.com/wfree_upload/mc/sys/img/201809/34b52a38363451096a0283a974fff99a.png","banner": "http://img.huaqianwy.com/wfree_upload/mc/sys/img/201810/320ff23998bf6c5909f891576bf43cb2.jpg","midBanner": null,"address": "http://www.51kxdw.com/index.php/login/spread/cid/dkw22/num/dkw01","type": 2,"linkSeqId": 1,"supportJoinLogin": false});
              // banners.push({"supportApiLoan": true,"showApiBanner": true,"apiProductInfo": {"title": "无需下载","status": 1,"linkAddress": "https://www.baidu.com","amountLine": 3500},"id": 674,"name": "51开心袋","subhead": "告别被拒开心花钱开心袋","limit": "￥2000-8000","duration": "1-30天","rate": "日利率:0.03%","averagePrice": "6000","passRate": "20%","loanTime": "3分钟","applyTips": "1、年龄限制：18-45周岁；\n2、手机号使用时长：6个月以上；\n3、其他限制：身份证，实名手机号，银行卡。","applyFlow": "","tagName": "","tagColor": null,"prompt": "","detailPrompt": "","logo": "http://img.huaqianwy.com/wfree_upload/mc/sys/img/201809/34b52a38363451096a0283a974fff99a.png","banner": "http://img.huaqianwy.com/wfree_upload/mc/sys/img/201810/320ff23998bf6c5909f891576bf43cb2.jpg","midBanner": null,"address": "http://www.51kxdw.com/index.php/login/spread/cid/dkw22/num/dkw01","type": 2,"linkSeqId": 1,"supportJoinLogin": false});
              // banners.push({"supportApiLoan": true,"showApiBanner": true,"apiProductInfo": {"title": "无需下载","status": 1,"linkAddress": "https://www.baidu.com","amountLine": 3500},"id": 674,"name": "51开心袋","subhead": "告别被拒开心花钱开心袋","limit": "￥2000-8000","duration": "1-30天","rate": "日利率:0.03%","averagePrice": "6000","passRate": "20%","loanTime": "3分钟","applyTips": "1、年龄限制：18-45周岁；\n2、手机号使用时长：6个月以上；\n3、其他限制：身份证，实名手机号，银行卡。","applyFlow": "","tagName": "","tagColor": null,"prompt": "","detailPrompt": "","logo": "http://img.huaqianwy.com/wfree_upload/mc/sys/img/201809/34b52a38363451096a0283a974fff99a.png","banner": "http://img.huaqianwy.com/wfree_upload/mc/sys/img/201810/320ff23998bf6c5909f891576bf43cb2.jpg","midBanner": null,"address": "http://www.51kxdw.com/index.php/login/spread/cid/dkw22/num/dkw01","type": 2,"linkSeqId": 1,"supportJoinLogin": false});
              // banners.push({"supportApiLoan": true,"showApiBanner": true,"apiProductInfo": {"title": "审核已通过","status": 2,"linkAddress": "https://www.baidu.com","amountLine": 3500},"id": 674,"name": "51开心袋","subhead": "告别被拒开心花钱开心袋","limit": "￥2000-8000","duration": "1-30天","rate": "日利率:0.03%","averagePrice": "6000","passRate": "20%","loanTime": "3分钟","applyTips": "1、年龄限制：18-45周岁；\n2、手机号使用时长：6个月以上；\n3、其他限制：身份证，实名手机号，银行卡。","applyFlow": "","tagName": "","tagColor": null,"prompt": "","detailPrompt": "","logo": "http://img.huaqianwy.com/wfree_upload/mc/sys/img/201809/34b52a38363451096a0283a974fff99a.png","banner": "http://img.huaqianwy.com/wfree_upload/mc/sys/img/201810/320ff23998bf6c5909f891576bf43cb2.jpg","midBanner": null,"address": "http://www.51kxdw.com/index.php/login/spread/cid/dkw22/num/dkw01","type": 2,"linkSeqId": 1,"supportJoinLogin": false});

              self.formateBannerList(banners)
            }
            self.categorlist = repData.categories; //分类
            if (repData.page.length > 0) {
              self.proList = self.formateProductList(repData.page); //精选贷款列表
            } else {
              // self.reloadText = {
              //   reloadText: "暂无数据",
              //   defaultImg: this.getCachedImages("productIcon") //无产品图
              // };
              // self.showErrorPage = true;
              self.initDefaultErrorPageInfos('noData')
            }
            let isNextPage = true
            if (repData.page.length < 10) {
              isNextPage = false;
              // self.productLoadEnd = true
            } else {
              isNextPage = true;
              // self.productLoadEnd = false
              // self.upCallback();
            }
            self.guessLoanList = repData.estimatedLoans;
            self.recommend = self.formateMidBannerList(repData.midBanners);
            setTimeout(() => {
              self.mescroll && self.mescroll.endSuccess(self.proList.length, isNextPage);
            }, 500);
            self.$nextTick(function () {
              // self.reinitBannerSwiper();
              // self.isLoad = "none"; //结束loading
              self.closeLoading()
              self.show.showGuessLoan && self.initGuessLoanSwiper(repData.estimatedLoans.length);
            });
            // 主列表硬广位插入
            let masterList = repData.masterList
            let listAdInfos = {}, bottomAdInfos = {}
            if (masterList && masterList.length > 0) {
              masterList = masterList.slice(0, 2)
              for (let i = 0; i < masterList.length; i++) {
                if (masterList[i].index > 0) {
                  listAdInfos = masterList[i]
                  // self.listAdInfos = masterList[i]
                } else if (masterList[i].index === -1) {
                  bottomAdInfos = masterList[i]
                  // self.bottomAdInfos = masterList[i]
                }
              }
            }
            self.listAdInfos = listAdInfos
            self.bottomAdInfos = bottomAdInfos
            this.mescroll && this.mescroll.destroy()
            // 初始化 mescroll
            let htmlNodata = `<div class="no-data b-1px" onclick="toProductlist('sy;dkdq;w39')">查看更多</div>`
            // 插入底部硬广位信息
            if (!self.isEmptyObject(self.bottomAdInfos)) {
              htmlNodata += `<div class="ad-position-bottom" onclick="onAdClick('', 'bottom')">
                              <img src="${self.bottomAdInfos.img}" alt="ad" class="ad-img">
                            </div>`
            }
            this.mescroll = new MeScroll("aa", {
              down: {
                auto: false,
                callback: this.downCallback,
              },
              up: {
                auto: false,
                callback: this.upCallback,
                isBounce: false,
                noMoreSize: 1,
                page: {
                  num: 1, //当前页 默认0,回调之前会加1; 即callback(page)会从1开始
                  size: self.pageSize, //每页数据条数,默认10
                },
                htmlLoading: `<div id="databottom" class="data-bottom">
                    <div class="load">
                      <img src="${this.$refs.imgLoad.src}" />
                    </div>
                    <div class="text" id="bottomtext">更多产品正在赶来</div>
                  </div>`,
                htmlNodata: htmlNodata,
              },
            });
          } else {
            setTimeout(() => {
              self.mescroll && self.mescroll.endErr();
            }, 500);
          }
        },
        () => {
          self.closeLoading()
          setTimeout(() => {
            self.mescroll && self.mescroll.endErr();
          }, 500);
          self.initDefaultErrorPageInfos('offline')
        }
      );
    },
    // 格式化中部banner数据
    formateMidBannerList (banners) {
      if (!banners || banners.length === 0) {
        return []
      }
      let w = ['34', '35', '263'] // 埋点w值
      let zdljw = ['261', '262', '264'] // 指定链接埋点w值
      let category = ['7', '8', '23'] // 分类category值
      for (let i = 0, l = banners.length; i < l; i++) {
        /* eslint-disable camelcase */
        banners[i].custom_w = w[i]
        banners[i].custom_zdljw = zdljw[i]
        banners[i].custom_category = category[i]
      }
      return banners
    },
    // 格式化banner数据
    formateBannerList (banners) {
      let self = this
      let commonBanners = []; // 默认banner
      let apiBanners = []; // api_banner
      let bannerList = [];
      for (let i = 0, l = banners.length; i < l; i++) {
        let item = banners[i];
        if (item.supportApiLoan && item.showApiBanner) {
          apiBanners.push(item);
        } else {
          commonBanners.push(item);
        }
      }
      if (apiBanners.length > 0) {
        self.bannerType = 'api';
        bannerList = apiBanners;
      } else {
        self.bannerType = 'common';
        bannerList = commonBanners;
      }
      self.$nextTick(() => {
        self.bannerList = bannerList;
        self.$set(self.bannerList, 0, bannerList[0]);
        self.$nextTick(() => {
          self.reinitBannerSwiper();
        })
      });
    },
    //获取跑马灯列表
    gethorseList () {
      var self = this;
      requestCarousel({}).then(
        (data) => {
          var repData = data;
          if (repData.respCode === "1000") {
            let horselist = []
            let list = repData.body
            for (let i = 0; i < list.length; i++) {
              if (list[i].type == 0 || list[i].type == 2) {
                horselist.push(list[i])
              }
            }
            self.horselist = horselist;
            self.$nextTick(function () {
              //跑马灯
              self.reinitHorseSwiper();
            });
          } else {
            setTimeout(() => {
              self.mescroll && self.mescroll.endErr();
            }, 500);
          }
        },
        () => {
          self.initDefaultErrorPageInfos('offline')
        }
      );
    },
    // 点击分类
    getproList (className, category, types, eventid, cate, index, w) {
      var self = this
      if (types == 2) {
        w = 31
      }
      self.needUserLogin(w, () => {
        let eventId = ['jr1007', 'jr1008', 'jr1009', 'jr1010', 'jr1011']
        self.collectEventMD({
          eventId: eventId[index],
          eventResult: 1,
          eventStartTime: new Date().getTime(),
        })
        // 1 请求分类列表 2请求H5页面
        if (types == 2) {
          self.$appInvoked("appExecStatistic", {
            eventId: "sy;fl;w31",
            eventType: 0,
          }); //埋点
          // self.$routerPush("/loanstrate");
          self.jrcsOpenAppPage(31, cate.address, cate.mainTitle)
        } else if (types == 1) {
          // 分类跳转到产品列表页
          self.mdAll(eventid)
          self.$routerPush(
            "/prolist?className=" +
            encodeURI(encodeURI(className)) +
            "&category=" +
            category
          );
        }
      })
    },
    // 中部banner点击
    midBannerClick (mb) {
      let that = this
      if (mb.clickType == '2') {
        // 跳转指定链接
        that.needUserLogin(mb.custom_zdljw, () => {
          let eventId = `zdlj;w${mb.custom_zdljw};p0;l${mb.linkAddressId}`
          that.$appInvoked('appExecStatistic', { eventId: eventId });
          // that.clickReport(mb.id, mb.custom_category, eventId);
          that.collectEventMD({
            eventId: eventId,
            eventResult: 1,
            eventStartTime: new Date().getTime(),
          })
          that.jrcsOpenAppPage(mb.custom_zdljw, mb.linkAddress, mb.mainTitle)
        })
      } else {
        that.proListClick(mb.name, mb.address, mb.id, mb.custom_w, 0, mb.type, false, mb.custom_category, mb.linkSeqId, mb)
      }
    },
    // 首页悬浮广告点击
    suspAdClick (adInfo) {
      let that = this
      if (adInfo.clickType == '2') {
        // 跳转指定链接
        that.needUserLogin(269, () => {
          let eventId = `zdlj;w269;p0;l${adInfo.linkAddressId}`
          that.$appInvoked('appExecStatistic', { eventId: eventId });
          // that.clickReport(adInfo.id, '21', eventId);
          that.collectEventMD({
            eventId: eventId,
            eventResult: 1,
            eventStartTime: new Date().getTime(),
          })
          that.jrcsOpenAppPage(269, adInfo.linkAddress, adInfo.mainTitle)
        })
      } else {
        that.proListClick(adInfo.name, adInfo.address, adInfo.id, 37, 0, adInfo.type, false, '21', adInfo.linkSeqId, adInfo)
      }
    },
    // 点击产品列表
    proListClick (
      name,
      url,
      productId,
      w,
      p,
      goFlag,
      needBackDialog,
      category,
      linkSeqId,
      proObj,
      closeOldReport,
    ) {
      let that = this
      that.needUserLogin(w, () => {
        if (proObj.user_isActivityDialog) {
          that.isActivityDialog = false
          that.$store.commit('mainWindowAd', false)
          eventCtr.$emit("maskerHandle", false)
        }
        // 是否支持api
        if (proObj.supportApiLoan) {
          let uri = `?category=${category}&productId=${productId}&productName=${name}&p=${p}&w=${w}&supportJoinLogin=${proObj.supportJoinLogin}&t=${proObj.rank}`;
          let eventId = `chanpin0;w${w};p${p};c${productId};l${window.$config.get('events.linkSeqId')};t${proObj.rank}`;
          if (!closeOldReport) {// API_banner只添加新增埋点，去掉旧的产品点击埋点
            that.clickReport(productId, category, eventId);
            that.$appInvoked("appExecStatistic", {
              eventId: eventId,
              eventType: 2,
            }); //添加埋点
          }
          // 姓名和身份证号是否已填写
          if (!that.nameIdcardEditAll) {
            that.$refs.basicInfo.getBasicInfoFun((nameIdcardEditAll) => {
              if (nameIdcardEditAll) {
                // 已填写 去撞库
                that.$routerPush('/loanHit' + uri)
              } else {
                // 未填写去基本信息补充页
                that.$routerPush('/basicInfo' + uri)
              }
            })
          } else {
            // 已填写 去撞库
            that.$routerPush('/loanHit' + uri)
          }
        } else {
          that.getproDetail(name, url, productId, w, p, goFlag, needBackDialog, category, linkSeqId, proObj)
        }
      })
    },
    //跳转到产品详情
    getproDetail (
      name,
      url,
      productId,
      w,
      p,
      goFlag,
      needBackDialog,
      category,
      linkSeqId,
      proObj
    ) {
      var self = this;
      // chanpin0进入产品详情页，chanpin1进入H5落地页，chanpin2阻止用户申请
      let eventId = `chanpin0;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
      if (goFlag == 2) { // 0-产品详情，2-第三方注册页
        eventId = `chanpin1;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
        let supportJoinLogin = proObj.supportJoinLogin; // 是否支持联登
        if (supportJoinLogin) { // 支持联合登录
          // self.isLoad = 'block';
          self.loading()
          let params = {
            linkId: linkSeqId,
            productId: productId,
          };
          requestJoinLogin(params).then((data) => {
            // self.isLoad = 'none';
            self.closeLoading()
            if (data.respCode === '1000') {
              data = data.body;
              let regStatus = data.regStatus;
              // 0-未知 1-注册失败 2-金融超市注册成功 3-失败：其他渠道已有用户
              if (regStatus == 2) {
                self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
              } else if (regStatus == 3) {
                utils.toastMsg(`您已注册过${name}，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              } else {
                utils.toastMsg(`${name}系统维护中，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              }
            } else {
              utils.toastMsg(`${name}系统维护中，请申请其他产品`);
              eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
              self.clickReport(productId, category, eventId);
            }
            self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
          }, () => {
            // self.isLoad = 'none';
            self.closeLoading()
          });
        } else {
          // type = 1;
          // 打开第三方注册页
          self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
          self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
        }
      } else {
        self.clickReport(productId, category, eventId);
        self.$routerPush(
          "/productDetail/" +
          category +
          "/" +
          productId +
          "?p=" +
          p +
          "&w=" +
          w +
          "&supportJoinLogin=" +
          proObj.supportJoinLogin + '&t=' + proObj.rank
        );
        self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
      }
      self.$appInvoked("appOnPageEnd", { pageName: this.$route.meta.title });
      window.currentPageName = this.$route.meta.title;
    },
    //重新加载
    reload: function () {
      this.showErrorPage = false
      window.location.reload()
    },
    guessNoClick () {
      let eventId = 'sy;ygkd;zntj;w324'
      this.$appInvoked('appExecStatistic', { eventId: eventId })
      this.globalRecommendClick(324)
    },
    //关闭悬浮广告
    closeAd () {
      var self = this;
      self.mdAll('sy;xf;w38')
      var myDate = new Date();
      var dates = myDate.toLocaleDateString();
      self.isShowAd = false;
      localStorage.setItem("isShowAd", dates);
    },
    // onAdImageLoad() {
    // }
  },
};
</script>
<style lang="scss">
.banner {
  .swiper-container-horizontal > .swiper-pagination-bullets,
  .swiper-pagination-custom,
  .swiper-pagination-fraction {
    .swiper-pagination-bullet {
      width: 4px;
      height: 4px;
      border-radius: 50%;
      background-color: rgba(255, 255, 255, 0.52);
    }
    .swiper-pagination-bullet-active {
      width: 10px;
      border-radius: 20px;
      background-color: #fff;
    }
  }
}

#databottom {
  margin-top: rc(21);
  margin-bottom: rc(26);
  font-size: rc(24);
  color: #777;
  text-align: center;
  .load {
    display: inline-block;
    width: rc(34);
    height: rc(34);
    img {
      width: rc(34);
      height: rc(34);
      background-size: contain;
    }
  }
  .text {
    display: inline-block;
  }
}

#aa .no-data {
  font-size: rc(28);
  margin: rc(27 36);
  height: rc(80);
  line-height: normal;
  display: flex;
  align-items: center;
  justify-content: center;
  color: $color-text-title;
  background-color: #fff;
  border-radius: rc(73);
  &::after {
    border-radius: rc(80);
  }
}
#aa .ad-position-bottom {
  .ad-img {
    width: rc(678);
    height: rc(180);
    display: block;
    margin: rc(0) auto rc(10);
    border-radius: rc(12);
  }
}
// 还款入口，暂时隐藏，勿删
// .repay-list {
//   margin: rc(28 36 0);
//   background-color: #f9f9f9;
//   border-radius: rc(12);
//   height: rc(90);
//   box-sizing: border-box;
//   .swiper-container,
//   .swiper-wrapper {
//     width: 100%;
//     height: 100%;
//   }
//   .repay-item {
//     color: #333;
//     font-size: rc(28);
//     width: 100%;
//     height: 100%;
//     box-sizing: border-box;
//     padding: rc(0 24);
//     display: flex;
//     align-items: center;
//   }
//   .repay-productname {
//     font-size: rc(30);
//     font-weight: bold;
//   }
//   .repay-splitline {
//     width: rc(2);
//     min-width: 1px;
//     height: rc(32);
//     background-color: #e7e7e7;
//     margin: 0 rc(20);
//   }
//   .repay-price {
//     margin-left: rc(14);
//     flex: 1;
//   }
//   .repay-status-text {
//     color: #ff601a;
//     &.rstc1 {
//       color: #f94336;
//     }
//   }
//   .repay-arrow {
//     width: rc(10);
//     height: auto;
//     margin-left: rc(10);
//   }
// }
</style>
<style lang="scss" scoped="scoped">
.banner {
  box-sizing: border-box;
  position: relative;
  &.common {
    padding: rc(10 36 0);
  }
  &.api .swiper-pagination-bullets {
    padding: rc(0 36 16);
    box-sizing: border-box;
  }
  .swiper-container {
    width: 100%;
    &.swiper-container-common {
      border-radius: 5px;
    }
  }

  .swiper-slide .common-banner {
    height: rc(180);
    width: 100%;
  }
  .api-banner {
    &-container {
      margin: rc(10 36 16);
      height: rc(220);
      background-image: linear-gradient(90deg, #ff7523 0%, #ffbd74 100%);
      box-shadow: rc(0 6 16 0) rgba(255, 97, 25, 0.29);
      padding: rc(22 30 24 40);
      border-radius: rc(12);
      box-sizing: border-box;
      &.banner-1 {
        background-image: linear-gradient(90deg, #4a80f9 0%, #a5cafd 100%);
        box-shadow: rc(0 6 16 0) rgba(76, 122, 254, 0.29);
        .api-banner-btn {
          color: #4a80f9;
        }
      }
      &.banner-2 {
        background-image: linear-gradient(90deg, #29c57b 0%, #7de2b2 100%);
        box-shadow: rc(0 6 16 0) rgba(41, 197, 123, 0.29);
        .api-banner-btn {
          color: #29c57b;
        }
      }
      &.banner-3 {
        background-image: linear-gradient(90deg, #8799fa 0%, #cdc3fc 100%);
        box-shadow: rc(0 6 16 0) rgba(135, 154, 250, 0.29);
        .api-banner-btn {
          color: #778bf7;
        }
      }
      &.banner-4 {
        background-image: linear-gradient(90deg, #fd5a47 0%, #ffb08d 100%);
        box-shadow: rc(0 6 16 0) rgba(253, 91, 71, 0.29);
        .api-banner-btn {
          color: #ff4127;
        }
      }
    }
    &-top {
      display: flex;
      align-items: center;
      color: #fff;
      .api-banner-name {
        font-size: rc(28);
        font-weight: bold;
      }
      .api-banner-sub {
        font-size: rc(26);
        color: rgba(255, 255, 255, 0.73);
        margin-left: rc(16);
        padding-left: rc(18);
        flex: 1;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        position: relative;
        margin-right: rc(20);
        &::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 0;
          transform: translateY(-50%);
          width: rc(2);
          min-width: 1px;
          height: rc(21);
          background-color: #fff;
        }
      }
    }
    &-content {
      display: flex;
      color: #fff;
      align-items: flex-end;
      justify-content: space-between;
      &-right {
        text-align: center;
      }
    }
    &-amount {
      font-size: rc(74);
      line-height: rc(90);
      font-weight: bold;
      margin-top: rc(9);
      &-tips {
        font-size: rc(24);
      }
    }
    &-btn {
      width: rc(200);
      line-height: rc(72);
      text-align: center;
      font-size: rc(30);
      color: #ff6a02;
      border-radius: rc(72);
      background-color: #fff;
    }
    .api-banner-title,
    .api-banner-title2,
    .api-banner-title3 {
      display: flex;
      align-items: center;
      font-size: rc(26);
      height: rc(38);
      img {
        width: 16px;
        height: 16px;
      }
      span {
        flex: 1;
        text-align: left;
        margin-left: rc(10);
      }
    }
    .api-banner-title {
      margin-right: rc(28);
    }
    .api-banner-title2,
    .api-banner-title3 {
      margin-bottom: rc(20);
    }
  }
}

.horse {
  height: rc(60);
  line-height: rc(60);
  background: #fff;
  padding-left: rc(32);
  padding-right: rc(32);
  border-radius: 3px;
}

.horse .horse-container {
  display: flex;
  border-radius: 3px;
  height: rc(60);
}

#horse {
  height: rc(60);
  line-height: rc(60);
  flex: 1;
  margin-left: rc(11);
  font-size: rc(24);
  vertical-align: middle;
  span {
    color: $color-remind;
  }
}

.horse-left {
  justify-content: center;
  align-items: center;
  img {
    width: rc(32);
    height: rc(32);
  }
}

.horse-right img {
  width: rc(10);
  height: rc(17);
  justify-content: center;
  align-items: center;
}

.horse .horse-center {
  height: rc(60);
  padding-top: rc(2);
}

.swiper-container-horizontal > .swiper-pagination-bullets,
.swiper-pagination-custom,
.swiper-pagination-fraction {
  bottom: rc(10);
}

.class-list {
  padding: rc(16);
  display: flex;
  background: #ffffff;
  .class-item {
    flex: 1;
    -webkit-flex: 1;
    text-align: center;
    margin-top: rc(14);
    .item-img {
      height: rc(87);
      width: rc(87);
    }
    .item-text {
      margin-top: rc(17);
      font-size: rc(26);
      color: #333;
    }
  }
}

/**精选贷款*/
.pro {
  .pro-title {
    height: rc(50);
    line-height: rc(50);
    padding-top: rc(30);
    font-size: rc(36);
    color: #111111;
    font-weight: bold;
    background: #ffffff;
    padding-left: rc(36);
    padding-right: rc(36);
  }
}

.data-bottom {
  margin-top: rc(21);
  margin-bottom: -20px;
  font-size: rc(24);
  color: #777;
  display: flex;
  display: -webkit-flex;
  text-align: center;
  .load {
    width: rc(34);
    height: rc(34);
    margin-left: rc(281);
    img {
      width: rc(34);
      height: rc(34);
    }
  }
  .text {
    margin-left: rc(10);
  }
}

.susp-ad {
  position: fixed;
  right: rc(20);
  bottom: rc(240);
  width: rc(160);
  height: rc(160);
  text-align: center;
  line-height: rc(28);
  display: block;
  z-index: 99;
  img {
    width: rc(160);
    height: rc(160);
  }
}
.ad-close {
  position: absolute;
  height: rc(60);
  width: rc(60);
  top: rc(-60);
  right: 0;
  background: url(../../static/images/delete.png) no-repeat right bottom;
  background-size: rc(30 30);
}
#aa {
  padding-bottom: rc(100);
  box-sizing: border-box;
}
.guess-loan {
  box-sizing: border-box;
  position: relative;
  background: #ffffff;
  margin-top: rc(30);
  .swiper-container {
    padding: rc(24 36 10);
    .swiper-wrapper {
      padding-bottom: 1px;
    }
  }
  .guess-loan-title {
    display: flex;
    align-items: center;
    padding: rc(0 36);
  }
  .guess-loan-title-left {
    flex: 1;
    font-size: rc(36);
    line-height: rc(50);
    font-weight: bold;
  }
  .guess-loan-ignore {
    height: rc(50);
    line-height: rc(50);
    color: $color-text-sub;
    font-size: rc(24);
    position: relative;
    padding-left: rc(30);
    &::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: rc(30);
      height: 100%;
      background: url(../../static/images/home_ignore.png) no-repeat left center;
      background-size: rc(20 20);
    }
  }
  .guess-slide {
    width: rc(216);
    height: rc(186);
    padding: rc(0 20);
    display: flex;
    flex-direction: column;
    justify-content: center;
    box-sizing: border-box;
    &.b-1px::after {
      border-color: $line-list-split;
      border-radius: rc(10);
    }
  }
  .guess-tj-tips {
    font-size: rc(24);
    color: $color-text-tip;
    width: rc(161);
    height: rc(51);
    text-align: center;
    line-height: rc(44);
    background: url(../../static/images/recommend_img_bubble.png) no-repeat center;
    background-size: 100% 100%;
  }
  .guess-tj {
    align-items: center;
  }
  .guess-tj-icon {
    width: rc(48);
    height: rc(48);
  }
  .guess-tj-txt {
    font-size: rc(26);
    color: $color-remind;
  }
  .guess-top {
    display: flex;
    align-items: center;
    img {
      width: rc(46);
      height: rc(46);
      border-radius: rc(10);
    }
    .guess-name {
      flex: 1;
      height: rc(40);
      line-height: rc(40);
      font-size: rc(24);
      color: #111;
      font-weight: bold;
      margin-left: rc(10);
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
  }
  .guess-price {
    font-size: rc(38);
    line-height: rc(53);
    margin-top: rc(13);
    font-weight: bold;
    color: $color-remind;
  }
  .guess-time {
    margin-top: rc(1);
    line-height: rc(33);
    font-size: rc(24);
    color: $color-text-tip;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
}

.mid-banner {
  height: rc(240);
  overflow: hidden;
  margin: rc(0 36);
  position: relative;
  .mid-banner-item {
    background-color: $bgColor-list-order;
    position: absolute;
    border-radius: rc(6);
    overflow: hidden;
    .mid-banner-tips {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      .mid-banner-title {
        font-size: rc(30);
        height: rc(42);
        line-height: rc(42);
        color: $color-remind;
        overflow: hidden;
      }
      .mid-banner-subtitle {
        font-size: rc(24);
        height: rc(34);
        line-height: rc(34);
        color: $color-text-tip;
        overflow: hidden;
      }
    }
    img {
      position: absolute;
    }
    &:nth-child(1) {
      top: 0;
      left: 0;
      width: rc(244);
      height: 100%;
      .mid-banner-tips {
        padding: rc(18 20);
      }
      img {
        width: rc(210);
        height: rc(134);
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
      }
    }
    &:nth-child(2),
    &:nth-child(3) {
      left: rc(258);
      right: 0;
      // width: rc(420);
      height: rc(114);
      .mid-banner-tips {
        padding: rc(0 30);
        display: flex;
        flex-direction: column;
        justify-content: center;
      }
      img {
        width: rc(180);
        height: rc(110);
        right: 0;
        top: 50%;
        transform: translateY(-50%);
      }
    }
    &:nth-child(2) {
      top: 0;
    }
    &:nth-child(3) {
      bottom: 0;
    }
  }
}
.activity-index {
  z-index: auto !important;
}
.activity-dialog {
  position: fixed;
  display: flex;
  align-items: center;
  justify-content: center;
  left: 0;
  top: 0;
  right: 0;
  bottom: rc(100);
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 100;
}
.activity-dialog-item {
  position: relative;
  margin: rc(0 44);
  max-width: rc(574);
  max-height: rc(640);
  img {
    width: 100%;
    height: 100%;
  }
}
.activity-close-btn {
  width: rc(60);
  height: rc(60);
  position: absolute;
  top: rc(-110);
  right: 0;
  background: url(../../static/images/public_close.png) no-repeat center;
  background-size: contain;
}
.gg-tips {
  padding: rc(0 20 0 36);
  height: rc(56);
  line-height: rc(56);
  background-color: #fff2eb;
  display: flex;
  align-items: center;
  overflow: hidden;
  font-size: rc(24);
  color: #ff6a45;
  .gg-tips-txt {
    flex: 1;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .gg-tips-close {
    width: rc(48);
    height: 100%;
    background: url(../../static/images/ljj/notice_ic_close.png) no-repeat center;
    background-size: rc(16 16);
  }
}
</style>
