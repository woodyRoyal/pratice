<template>
  <PageView title="浏览记录"
            :is-back-page="false"
            :show-error-page="showErrorPage"
            :error-page-info="errorPageInfo"
            @backClick="backClickHandle">
    <div id="hqwy-mescroll"
         class="mescroll">
      <p v-if="browseHistory.length > 0"
         class="topTip">
        最近<span>{{ browseHistory.length }}</span>条浏览记录
      </p>
      <ProductList :list="browseHistory"
                   @on-click="proListClick"></ProductList>
      <!-- <ul class="record-items">
        <li class="bb-1px"
            :key="index"
            v-for="(item,index) in browseHistory">
          <a @click="proListClick(item,index)">
            <div class="record-item-top flex">
              <div class="item-left">
                <img v-lazy="{src:item.logo,error:productIcon,loading:productIcon}"
                     :key="item.logo">
              </div>
              <div class="item-right">
                <div class="item-right-top">
                  <p class="flex1 font-bold">{{item.name}}</p>
                  <p class="flex1 font-bold">￥{{item.limit}}</p>
                </div>
                <div class="item-right-center">
                  <span class="pass-rate "
                        v-bind:style="{background:item.tagColor}"
                        v-if="item.tagName!=null && item.tagName!=''">{{item.tagName}}</span><span class="color-999"><i>{{item.rate}}</i></span><span class="splite-line color-999">|</span><span class="color-999">期限:<i>{{item.duration}}</i></span>
                </div>
                <div class="item-right-bottom"
                     v-if="item.prompt!='' && item.prompt!=null">
                  <span class="color-999">※ {{item.prompt}}</span>
                </div>
                <list-tip v-if="item.supportApiLoan"></list-tip>
              </div>
              <div class="right-arrow"><img src="../../static/images/arrow.png" /></div>
            </div>
          </a>
        </li>
      </ul> -->
      <VLoad :isload="isLoad"></VLoad>
      <div v-if="browseHistory.length>0"
           id="databottom">
        <div class="no-data">
          <div class="no-datas">
            <div class="no-datas-text">
              已经到底啦
            </div>
          </div>
          <div v-cloak
               class="other-pro"
               @click="toProductlist()">
            没有合适产品?立即进入<span>贷款大全></span>
          </div>
        </div>
      </div>
      <BasicInfo ref="basicInfo"></BasicInfo>
    </div>
  </PageView>
</template>

<script>
import VLoad from "../components/load.vue";
import utils from "../util/utils";
// import bridge from "../util/jsbirdge";
// import { requestProductDetail } from "../../src/api/controller/product";
import { requestBrowseRecord } from "../../src/api/controller/categoryLoan";
import { requestJoinLogin } from "../../src/api/controller/product";
// import listTip from "../components/tip/listTip"
import BasicInfo from "../components/basicInfo/index"
import eventCtr from "../../static/js/eventCtr"
import ProductList from '@/components/product/ProductList'
/* eslint-disable eqeqeq */
export default {
  name: "BrowseRecord",
  components: {
    VLoad,
    // vAbnor,
    // listTip,
    BasicInfo,
    ProductList,
  },
  data () {
    return {
      isLoad: "none",
      // reloadText: {
      //   defaultImg: this.getCachedImages("noDataIcon"),
      //   reloadText: "暂无记录"
      // },
      browseHistory: [],
      showErrorPage: false,
      errorPageInfo: {},
      productIcon:
        this.getCachedImages("productIcon") ||
        require("APP_IMG/default.png"), //产品缩略占位图
      nameIdcardEditAll: false, // 姓名身份证号已填写标识
    };
  },
  activated () {
    this.interceptAppBack()
    var self = this;
    this.showErrorPage = false
    self.collectEventMD({
      eventId: 'jr1017',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
    })
    // window.goBack = this.goBack;
    // window.topPreRecommend = this.topPreRecommend;
    // window.scrollTo(0, 100);
    self.$appInvoked("appGetMobilephone", {}, function (data) {
      self.$store.commit("PHONE_NUMBER", data);
      if (data && data.length > 0) {
        self.requestBrowseRecord(data);
      }
    });
    // 获取姓名身份证
    self.$refs.basicInfo.getBasicInfoFun()

    window.vueApp = this;
  },
  mounted () {
    // 获取姓名和身份证是否已填写
    eventCtr.$on("nameIdcardEditAll", (msg) => {
      this.nameIdcardEditAll = msg
    })
  },
  methods: {
    //jsbridge在原生生命周期中会调这个方法，如果从原生跳回h5刷选刷新数据可以在这个方法中调用
    webviewWillAppear () {
      var self = this;
      self.$appInvoked("appGetMobilephone", {}, function (data) {
        self.$store.commit("PHONE_NUMBER", data);
        if (data && data.length > 0) {
          self.requestBrowseRecord(data);
        }
      });
    },
    requestBrowseRecord (userMobilePhone) {
      var self = this;
      self.isLoad = "block"; //开始loading
      var params = {
        mobilePhone: userMobilePhone,
      };

      requestBrowseRecord(params).then(
        (resp) => {
          self.isLoad = "none"; //loading结束
          if (resp.respCode === "1000") {
            if (resp.body.length === 0) {
              // self.abnorText = {
              //   defaultImg: this.getCachedImages("noDataIcon"),
              //   reloadText: "暂无记录"
              // };
              // self.showErrorPage = true;
              self.initDefaultErrorPageInfos('', {
                title: '喜欢啥？别客气随便点',
                icon: 'qsy_wlljl.png',
                btnTxt: '去逛逛',
                btnClick: () => {
                  self.toProductlist()
                },
              })
            } else {
              self.browseHistory = self.formateProductList(resp.body);
              self.showErrorPage = false;
            }
          } else {
            // self.abnorText = {
            //   defaultImg: this.getCachedImages("noDataIcon"),
            //   reloadText: "暂无记录"
            // };
            // self.showErrorPage = true;
            self.initDefaultErrorPageInfos('', {
              title: '喜欢啥？别客气随便点',
              icon: 'qsy_wlljl.png',
              btnTxt: '去逛逛',
              btnClick: () => {
                self.toProductlist()
              },
            })
          }
        }, () => {
          self.isLoad = "none"; //loading结束
          // self.showErrorPage = true;
          // self.abnorText = {
          //   reloadText: "网络异常",
          //   defaultImg: this.getCachedImages("loadFailIcon")
          // };
          self.initDefaultErrorPageInfos('offline')
        }
      );
    },
    //去贷款大全页面
    toProductlist () {
      var self = this;
      self.$routerPush("/productlist");
      self.$appInvoked("appExecStatistic", {
        eventId: "lljl;dkdq;w128",
        eventType: 0,
      }); //埋点
    },
    // 点击产品列表
    proListClick (item, index) {
      let that = this
      that.needUserLogin(126, () => {
        // 是否支持api
        let category = item.category || 12
        if (item.supportApiLoan) {
          let tourl = `?category=${category}&productId=${item.id}&productName=${item.name}&p=${index + 1}&w=126&supportJoinLogin=${item.supportJoinLogin}&t=${item.rank}`
          let eventId = `chanpin0;w126;p${index + 1};c${item.id};l${window.$config.get('events.linkSeqId')};t${item.rank}`;
          that.clickReport(item.id, category, eventId);
          that.$appInvoked("appExecStatistic", {
            eventId: eventId,
            eventType: 2,
          }); //添加埋点
          // 姓名和身份证号是否已填写
          if (!that.nameIdcardEditAll) {
            that.$refs.basicInfo.getBasicInfoFun((nameIdcardEditAll) => {
              if (nameIdcardEditAll) {
                // 已填写 去撞库
                that.$routerPush('/loanHit' + tourl)
              } else {
                // 未填写去基本信息补充页
                that.$routerPush('/basicInfo' + tourl)
              }
            })
          } else {
            // 已填写 去撞库
            that.$routerPush('/loanHit' + tourl)
          }
        } else {
          // that.goDetail(item, index)
          // 浏览记录页面链接id-linkSeqId花钱无忧传 1，贷款王传 2
          that.goDetail(item.name, item.address, item.id, 126, index + 1, item.type, true, item.category || 12, item.linkSeqId, item)
        }
      })
    },
    goDetail (
      name,
      url,
      productId,
      w,
      p,
      goFlag,
      needBackDialog,
      category,
      linkSeqId,
      proObj
    ) {
      var self = this;
      // chanpin0进入产品详情页，chanpin1进入H5落地页，chanpin2阻止用户申请
      let eventId = `chanpin0;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
      if (goFlag == 2) { // 0-产品详情，2-第三方注册页
        eventId = `chanpin1;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
        let supportJoinLogin = proObj.supportJoinLogin; // 是否支持联登
        if (supportJoinLogin) { // 支持联合登录
          self.isLoad = 'block';
          let params = {
            linkId: linkSeqId,
            productId: productId,
          };
          requestJoinLogin(params).then((data) => {
            self.isLoad = 'none';
            if (data.respCode === '1000') {
              data = data.body;
              let regStatus = data.regStatus;
              // 0-未知 1-注册失败 2-金融超市注册成功 3-失败：其他渠道已有用户
              if (regStatus == 2) {
                self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
              } else if (regStatus == 3) {
                utils.toastMsg(`您已注册过${name}，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              } else {
                utils.toastMsg(`${name}系统维护中，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              }
            } else {
              utils.toastMsg(`${name}系统维护中，请申请其他产品`);
              eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
              self.clickReport(productId, category, eventId);
            }
            self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
          }, () => {
            self.isLoad = 'none'
          });
        } else {
          // type = 1;
          // 打开第三方注册页
          self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
          self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
        }
      } else {
        self.clickReport(productId, category, eventId);
        self.$routerPush(
          "/productDetail/" +
          category +
          "/" +
          productId +
          "?p=" +
          p +
          "&w=" +
          w +
          "&supportJoinLogin=" +
          proObj.supportJoinLogin + '&t=' + proObj.rank
        );
        self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
      }
      self.$appInvoked("appOnPageEnd", { pageName: this.$route.meta.title });
      window.currentPageName = this.$route.meta.title;
    },
    backClickHandle () {
      this.$appInvoked("appExecStatistic", {
        eventId: "lljl;fh;w127",
        eventType: 0,
      }); //埋点
      this.$routerGo(-1);
    },
    //给app提供一个方法
    // topPreRecommend () {
    //   this.globalRecommendClick()
    // }
  },
};
</script>

<style lang="scss" scoped>
#hqwy-mescroll {
  height: 100%;
  width: 100%;
  box-sizing: border-box;
  overflow-x: hidden;
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch;
}

.mescroll > p {
  line-height: rc(70);
  padding-left: rc(30);
  font-size: rc(24);
}

.mescroll > p > span {
  color: $color-main;
}

// .flex,
// .item-right-top {
//   display: flex;
// }

// .flex1,
// .item-right {
//   flex: 1;
// }

.font-bold {
  font-weight: bold;
}

.color-999 {
  color: #999;
}

// .item-right {
//   padding-left: rc(20);
//   overflow: auto;
// }

// .item-right-bottom,
// .item-right-center {
//   margin-top: rc(8);
//   color: #bbbbbb;
// }

// .item-right-center {
//   margin-top: rc(10);
// }

// .item-right-center i {
//   font-style: normal;
//   font-size: rc(24);
// }

// .item-right-center span {
//   font-size: rc(24);
// }

// .item-right-bottom {
//   white-space: nowrap;
//   text-overflow: ellipsis;
//   overflow: hidden;
// }

// .item-right-bottom span {
//   display: inline-block;
//   font-size: rc(24);
//   // transform: scaleY(0.917);
// }

// .item-left {
//   width: rc(100);
//   height: rc(100);
//   /*border: 1px solid #e5e5e5;*/
//   border-radius: 6px;
// }

// .item-left img {
//   display: block;
//   width: 100%;
//   height: 100%;
//   border-radius: rc(12);
// }

// .record-items {
//   padding-left: rc(30);
//   background-color: #fff;
//   li {
//     padding-right: rc(30);
//     &.bb-1px:last-child::after {
//       border-bottom: 0;
//     }
//   }
// }

// .record-items li a {
//   display: block;
//   color: #333333;
// }

// .record-item-top {
//   position: relative;
//   padding: rc(32 0 30);
//   overflow: hidden;
// }

// .pass-rate {
//   font-size: rc(22);
//   background: #f53331;
//   color: #fff;
//   padding: rc(2) rc(8);
//   border-radius: rc(4);
// }

// .item-right-top p:first-child {
//   color: #111111;
//   font-size: rc(30);
// }

// .item-right-top p:last-child {
//   color: #ff601a;
//   font-size: rc(34);
// }

// .mint-loadmore .rotate {
//   display: inline-block;
//   transition: transform 0.3s ease-in;
// }

// .mint-loadmore .rotate.active {
//   transform: rotate(180deg);
// }

// .pass-rate {
//   margin-right: rc(10);
// }

// .splite-line {
//   margin-left: rc(10);
//   margin-right: rc(10);
// }

// .right-arrow {
//   position: absolute;
//   right: 0;
//   top: 50%;
//   margin-top: rc(-13);
//   width: rc(15);
// }

// .right-arrow img {
//   display: block;
//   width: 100%;
// }

#databottom {
  margin-top: rc(21);
  margin-bottom: rc(26);
  font-size: rc(24);
  color: #777;
  text-align: center;
  .load {
    display: inline-block;
    width: rc(34);
    height: rc(34);
    img {
      width: rc(34);
      height: rc(34);
      background-size: contain;
    }
  }
  .text {
    display: inline-block;
  }
}

/*#databottom{*/
/*margin-top: rc(21);*/
/*margin-bottom: rc(26);*/
/*font-size: rc(24);*/
/*color: #777;*/
/*text-align: center;*/
/*}*/
.no-data {
  margin-top: rc(30);
  font-size: rc(24);
  color: #777777;
  text-align: center;
  height: rc(96);
  .no-datas {
    height: rc(33);
    width: 50%;
    margin-left: 25%;
    border-bottom: 1px solid #979797;
    position: relative;
    /*line-height:rc(33);*/
    .no-datas-text {
      width: 40%;
      margin-left: 30%;
      background: #f6f6f6;
      position: absolute;
      top: rc(16);
    }
  }
  .other-pro {
    margin-top: rc(30);
    span {
      color: $color-main;
    }
  }
}

.no-data.no-other {
  margin-bottom: rc(30);
  padding-bottom: rc(80);
}
</style>
