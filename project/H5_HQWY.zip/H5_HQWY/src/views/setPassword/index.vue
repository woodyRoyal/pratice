<template>
  <PageView title="设置密码"
            class="set-password">
    <div class="set-password-wrap">
      <FromInput v-model="form.loginPwd"
                 :type="'password'"
                 :validate="validate.loginPwd"
                 :max-length="20"
                 :placeholder="'6~20位数字或者字母'"
                 @checkHandler="checkHandler"></FromInput>
      <div class="sms-code">
        <FromInput v-model="form.confirmLoginPwd"
                   :type="'password'"
                   :validate="validate.confirmLoginPwd"
                   :max-length="20"
                   :placeholder="'再输入一遍'"
                   @checkHandler="checkHandler">
        </FromInput>
      </div>
      <span v-show="false">{{ isCheck }}</span>
      <CommonButton :btn-data="btnData"
                    @click.native="submitData()"></CommonButton>
    </div>
  </PageView>
</template>
<script>
// import confirm from "@/components/confirm/index";
import { pwdchgApi } from "@/api/controller/loginRegister"
import FromInput from '@/components/fromInput';
import CommonButton from "@/components/button/index"
import utils from "@/util/utils"
export default {
  components: {
    FromInput,
    CommonButton,
    // confirm,
  },
  data () {
    return {
      smsSerialNumber: '',// 短信验证
      appHeader: {},// app 头信息
      form: {
        loginPwd: '',
        confirmLoginPwd: '',
      },
      validate: { // 校验
        loginPwd: {
          name: 'loginPwd',
          rule: /^[0-9a-zA-Z]{6,20}$/,
          message: '请设置有效的密码',
          trigger: ['change'],
          isCheck: false,
        },
        confirmLoginPwd: {
          name: 'confirmLoginPwd',
          rule: /^[0-9a-zA-Z]{6,20}$/,
          message: '请设置有效的密码',
          trigger: ['change'],
          isCheck: false,
        },
      },
      // 提交按钮
      btnData: {
        activeFlag: false,
        txt: '确认',
      },
    }
  },
  computed: {
    isCheck () {// 校验是否通过
      let activeFlag = Object.values(this.validate).every((v) => v.isCheck)
      // eslint-disable-next-line vue/no-side-effects-in-computed-properties
      this.btnData.activeFlag = activeFlag
      return activeFlag
    },
  },
  deactivated: function () {
    this.form = {
      loginPwd: '',
      confirmLoginPwd: '',
    }
    this.validate.loginPwd.isCheck = false
    this.validate.confirmLoginPwd.isCheck = false
  },
  methods: {
    // 检验信息
    checkHandler (options) {
      this.validate[options.name].isCheck = options.isCheck;
    },
    submitData () {
      if (!this.validate.loginPwd.isCheck) {
        utils.toastMsg(this.validate.loginPwd.message)
        return;
      }
      if (this.form.loginPwd !== this.form.confirmLoginPwd) {
        utils.toastMsg('两次输入的密码不相同，请检查')
        return;
      }
      utils.debouce(() => {
        this.$appInvoked("appGetAjaxHeader", {}, (data) => {
          let { idfa, imei, innerVersion, projectMark } = data;
          let { code, mobilePhone, serialNumber } = this.$route.params
          let p = { loginPwd: this.form.loginPwd, code, mobilePhone, serialNumber, idfa, imei, innerVersion, projectMark }
          this.appSignParams(p, true, (rst) => {
            pwdchgApi(p, { headers: rst }).then((res) => {
              window.hideDiversionConfirm && window.hideDiversionConfirm() // 隐藏登录引导弹窗
              localStorage.removeItem('cacheAjaxHeader')
              // 修改密码成功
              let data = res.body
              // 立即借记录是否结清状态
              if (this.$config.get('productId') === 903) {
                localStorage.setItem('SHOW_LJJ_REPAY', res.body.clear)
                try {
                  // 深度复制，避免改变data.clear时，res.body.clear也改变
                  data = JSON.parse(JSON.stringify(res.body))
                } catch (error) {
                  // 
                }
                // 立即借修改密码成功后，通知原生登录成功不需要跳转还款页面，故设置clear=1
                data.clear = '1' // 是否结清。1-结清，2-未结清
              }
              this.$appInvoked('appLoginSuccess', data)
              if (this.$route.query.sourcePage === 'myMore') {
                localStorage.setItem('loginoutnow', 1);
                this.$routerGo(-3);
              } else if (Number(this.$route.query.type) === 0) {
                if (this.$route.query.isIosDkw7 === 'true') {
                  window.isLoginSuccessCloseWebview = function () {
                    window.isLoginSuccessCloseWebview = null
                    window.vm.$appInvoked('appCloseWebview', {})
                  }
                } else {
                  this.$appInvoked('appCloseWebview', {})
                }
              } else {
                this.$routerGo(-3)
              }
            })
          })
        });
      }, 1000, true)()

    },
  },
}
</script>
<style lang="scss" scoped>
.set-password {
  background: #fff !important;
}
.sms-code {
  position: relative;
  margin-bottom: rc(156);
}
.set-password-wrap {
  margin-top: rc(145);
  padding: 0 rc(30);
  box-sizing: border-box;
}

.comfirm-form {
  margin-top: rc(35);
}
</style>

