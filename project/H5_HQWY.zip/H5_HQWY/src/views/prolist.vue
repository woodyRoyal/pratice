<template>
  <PageView type="prolistpage"
            :title="title"
            :is-back-page="false"
            right-txt="智能推荐"
            @backClick="backClickHandle"
            @rightClick="rightClickHandle">
    <div class="content">
      <div ref="proList"
           class="hqwy-prolist child-view">
        <!-- <div class="hqwy-tip">
          <i class="hqwy-tip-icon"></i><span>据统计，申请5个以上产品，贷款成功率超过95%</span>
        </div> -->
        <ProList ref="ProList"
                 is-recommend="0"
                 :list-params="listParams"
                 :page-name="decodeURI(titie)"></ProList>
      </div>
    </div>
  </PageView>
</template>

<script>
import ProList from "../components/productlist/index";

/* eslint-disable eqeqeq */
export default {
  name: "ProLists",
  components: {
    // vAbnor,
    ProList,
  },
  data () {
    return {
      title: '',
      // isTipClick: false,
      // tipText: "据统计，申请5个以上产品，贷款成功率超过95%",
      listParams: {
        url: "/api/index/categoryV2", //请求的url地址
        category: "", //分类类别
        currPageNo: 1, //页面默认从第一页开始
      },
      isShow: false, //网络异常时显示
      reloadText: "", //异常提示文案
      titie: this.$route.query.className,
    };
  },
  beforeRouteLeave (to, from, next) {
    if (this.$refs.proList.children[1] != undefined) {
      global.storage.set(
        "proListScrollTop",
        this.$refs.proList.children[1].scrollTop
      );
    }
    next();
  },
  beforeRouteEnter (to, from, next) {
    if (from.path === "/") {
      global.storage.set("proListScrollTop", 0);
    }
    next((vm) => {
      setTimeout(() => {
        if (vm.$refs.proList.children[1] != undefined) {
          vm.$refs.proList.children[1].scrollTop =
            global.storage.get("proListScrollTop") || 0;
        }
      }, 10);
    });
  },
  activated () {
    this.interceptAppBack()
    var refreshTime = localStorage.getItem("refreshTime");
    if (
      this.$needRefreshData(JSON.parse(refreshTime)["prolist"]) &&
      document.readyState === "complete"
    ) {
      window.location.reload();
      var refreshTimeObj = JSON.parse(refreshTime);
      refreshTime["prolist"] = "";
      localStorage.setItem("refreshTime", JSON.stringify(refreshTimeObj));
    }
    this.$nextTick(() => {
      this.listParams.category = this.$route.query.category;
      var title = this.$route.query.className;
      if (title) {
        title = decodeURIComponent(title);
        localStorage.setItem("prolistTitle", title);
      } else {
        title = localStorage.getItem("prolistTitle");
      }
      document.title = title;
      this.title = title
    });
    // window.addEvent = this.addEvent;
    // window.topPreRecommend = this.topPreRecommend;
    this.$appInvoked("appOnPageBegin", { pageName: decodeURI(this.titie) });
    window.vueApp = this;
  },
  destroyed () {
    this.$appInvoked("appOnPageEnd", { pageName: decodeURI(this.titie) });
  },
  methods: {
    //jsbridge在原生生命周期中会调这个方法，如果从原生跳回h5刷选刷新数据可以在这个方法中调用
    // webviewWillAppear() {
    //   this.$refs.ProList.downCallback && this.$refs.ProList.downCallback();
    // },
    rightClickHandle () {
      var curType = this.$route.query.category;
      var tojztjEvent = "";
      let w
      if (curType == 1) {
        tojztjEvent = "fl1;jztj;w42";
        w = 42
      } else if (curType == 2) {
        tojztjEvent = "fl2;jztj;w49";
        w = 49
      } else if (curType == 3) {
        tojztjEvent = "fl3;jztj;w56";
        w = 56
      } else if (curType == 4) {
        tojztjEvent = "fl4;jztj;w161";
        w = 161
      } else if (curType == 11) {
        tojztjEvent = "pmd;jztj;w64";
        w = 64
      }
      this.$appInvoked("appExecStatistic", {
        eventId: tojztjEvent,
        eventType: 0,
      }); //添加埋点
      this.globalRecommendClick(w)
    },
    // tipClickHandle (text) {
    //   this.tipText = text;
    // },
    // tipsClickFun () {
    //   this.isTipClick = !this.isTipClick;
    // },
    backClickHandle () {
      //页面返回 发送统计
      var codeData = "";
      this.listParams.category = this.$route.query.category;
      if (this.listParams.category == 1) {
        codeData = "fl1;fh;w47";
      } else if (this.listParams.category == 2) {
        codeData = "fl2;fh;w54";
      } else if (this.listParams.category == 3) {
        codeData = "fl3;fh;w61";
      } else if (this.listParams.category == 4) {
        codeData = "fl4;fh;w165";
      } else if (this.listParams.category == 11) {
        codeData = "pmd;fh;w69";
      }
      this.$appInvoked("appExecStatistic", {
        eventId: codeData,
        eventType: 0,
      }); //添加返回埋点
      this.$routerGo(-1);
      // this.$routerPush('/home')
    },
    getabnor (data) {
      // console.log(data);
      this.isShow = data.isShow;
      this.reloadText = data.reloadText;
      // console.log(this.reloadText);
    },
  },
};
</script>
<style lang="scss" scoped="scoped">
#hqwy-content {
  padding-top: rc(60);
}

.hqwy-tip {
  background-color: $bgColor-list-order;
  width: 100%;
  text-align: left;
  font-size: rc(24);
  line-height: rc(60);
  color: $color-text-tip;
  padding-left: rc(30);
  z-index: 1;
}

// .hqwy-tip a {
//   color: $color-main;
// }

.hqwy-tip-icon {
  display: inline-block;
  width: rc(32);
  height: rc(32);
  background: url(../../static/images/public_horn_03.png) 0 0 no-repeat;
  background-size: contain;
  vertical-align: text-bottom;
  margin-right: 5px;
}

.hqwy-prolist {
  overflow-y: hidden;
}
</style>
