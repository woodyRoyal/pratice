<template>
  <PageView title="基础信息"
            :is-back-page="false"
            :show-error-page="showErrorPage"
            :error-page-info="errorPageInfo"
            @backClick="backClickHandle">
    <div v-if="!showErrorPage"
         class="hqwy-body-white">
      <Tip :txt="'补全本人真实信息，借款一步到位'"></Tip>
      <ul class="hqwy-mod-info">
        <li>
          <span class="name">手机号</span>
          <input v-model="phone"
                 type="text"
                 class="ipt ipt-disabled"
                 readonly>
        </li>
        <li :class="{'error': btnClickFlag[0] && userData.name == ''}">
          <span class="name">姓名</span>
          <input v-model.trim="userData.name"
                 type="text"
                 class="ipt"
                 :class="{'ipt-error': valueErrorFlag[0]}"
                 placeholder="请填写本人姓名"
                 @focus="focusFun(0)"
                 @input="changeFun(0)">
        </li>
        <li :class="{'error': btnClickFlag[1] && userData.idNum == ''}">
          <span class="name">身份证号</span>
          <input v-model.trim="userData.idNum"
                 :type="isios?'text':'tel'"
                 class="ipt"
                 :class="{'ipt-error': valueErrorFlag[1]}"
                 placeholder="请填写本人身份证号"
                 maxlength="18"
                 @focus="focusFun(1)"
                 @input="changeFun(1)">
        </li>
      </ul>
      <div class="hqwy-btns">
        <CommonButton :btn-data="btnData"
                      @click.native="btnClick()"></CommonButton>
      </div>
      <!-- 信息确认弹窗 -->
      <Confirm ref="sureComfirm"
               title="确认身份信息"
               cancel-txt="修改"
               sure-txt="确认"
               :btn-same-color="true"
               :close-flag="true"
               @on-confirm="saveUserInfo()"
               @on-cancel="editUserInfo()">
        <div class="sure-info">
          <ul class="info-list">
            <li>
              <span class="name">姓名</span>
              <span class="value">{{ userData.name }}</span>
            </li>
            <li>
              <span class="name">身份证号</span>
              <span class="value"
                    style="white-space: nowrap;">{{ idNumSpace }}</span>
            </li>
          </ul>
          <Tip :txt="'确认后无法修改，请务必保证正确'"></Tip>
        </div>
      </Confirm>
      <!-- 信息确认弹窗 end-->
      <!-- 返回挽留弹窗 -->
      <Confirm ref="backComfirm"
               title="温馨提示"
               cancel-txt="放弃并返回"
               sure-txt="继续填写"
               txt="资料尚未保存,是否放弃？"
               txt-style="center"
               @on-cancel="backConfirmCancel()"></Confirm>
      <!-- 返回挽留弹窗 end -->
      <!-- 重新智能推荐返回挽留弹窗 & 保存成功弹窗 -->
      <BackConfirm ref="confirmDialog"
                   :cancel-txt="confirmData.cancelTxt"
                   :sure-txt="confirmData.sureTxt"
                   :btn-type="confirmData.btnType"
                   :icon-type="confirmData.iconType"
                   :txt="confirmData.txt"
                   @on-cancel="confirmData.cancel"
                   @on-confirm="confirmData.confirm"></BackConfirm>
      <Loading v-show="isLoading"></Loading>
      <VLoad :isload="isLoad"></VLoad>
    </div>
  </PageView>
</template>
<script>
import utils from "../../util/utils.js"
import Tip from "../../components/tip/index"
import CommonButton from "../../components/button/index"
// eslint-disable-next-line no-unused-vars
import idcard from "../../../static/js/idcard"
import Confirm from "../../components/confirm/index"
import BackConfirm from "../../components/confirm/BackConfirm"
import Loading from "../../components/loading/loading"
import VLoad from "../../components/load.vue"
import { getBasicInfoApi, saveBasicInfoApi } from "../../../src/api/controller/openAccount"
import eventCtr from "../../../static/js/eventCtr"
export default {
  components: {
    Tip,
    CommonButton,
    Confirm,
    BackConfirm,
    Loading,
    VLoad,
    // vAbnor
  },
  data () {
    return {
      source: this.$route.query.source, // 页面来源。0-我的>完善贷款信息，1-API产品详情，2-重新智能推荐
      confirmData: { // 返回弹窗数据
        cancelTxt: '',
        sureTxt: '',
        btnType: '',
        iconType: 3,
        txt: '',
        cancel: function () {
          // 
        },
        confirm: function () {
          // 
        },
      },
      isios: false,
      isLoad: "none",
      showErrorPage: false,
      errorPageInfo: {},
      isLoading: false,
      phone: '',
      userData: {
        name: '',
        idNum: '',
      },
      btnData: {
        activeFlag: false,
        txt: '保存',
      },
      btnFlag: false, // 前端校验通过标识
      btnClickFlag: [false, false], // 记录点击状态
      valueErrorFlag: [false, false], // 校验标识
    }
  },
  computed: {
    // 信息确认弹窗身份证号带空格
    idNumSpace: function () {
      let str = this.userData.idNum.substring(0, 6) + ' ' + this.userData.idNum.substring(6, 14) + ' ' + this.userData.idNum.substring(14, 18)
      return str
    },
  },
  watch: {
    'userData': {
      handler (val) {
        if (val.name !== '' && val.idNum !== '') {
          this.btnData.activeFlag = true
        } else {
          this.btnData.activeFlag = false
        }
      },
      deep: true,
      immediate: true,
    },
  },
  activated () {
    this.interceptAppBack()
    this.showErrorPage = false
    let w = this.$route.query.w
    if (w) {
      this.collectEventMD({
        eventId: `ly1005,w${w}`,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
      })
    }
    this.btnClickFlag = [false, false]
    this.valueErrorFlag = [false, false]
    this.$refs.backComfirm && this.$refs.backComfirm.hide()
    this.$refs.confirmDialog && this.$refs.confirmDialog.hide()

    this.phone = this.$store.state.baseInfo.phoneNumber

    if (this.$store.state.baseInfo.phoneNumber !== '') {
      this.phone = this.$store.state.baseInfo.phoneNumber
    } else {
      this.$appInvoked("appGetMobilephone", {}, (data) => {
        this.phone = data
      })
    }
    this.requestUserInfo()
    this.collectEventFun('1001')
    if (this.$tools.getBrowser() === 'iOS') {
      this.isios = true
    } else {
      this.isios = false
    }
  },
  // mounted () {
  // },
  methods: {
    // 进入页面事件统计
    collectEventFun (id) {
      let params = {
        eventEndTime: '',
        eventId: id,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
        productId: this.$route.query.productId || '',
      }
      this.collectEventMD(params)
    },
    // 错误红线及错误文案逻辑
    changeFun (index) {
      this.$set(this.valueErrorFlag, index, false)
    },
    // 错误红线逻辑
    focusFun (index) {
      this.$set(this.btnClickFlag, index, false)
    },
    // 姓名校验
    checkName () {
      // 先去除空格再校验
      this.userData.name = this.userData.name.replace(/\s*/g, '')
      // 只能输入中文和点 至少要有一位中文
      let reg = /[\u4E00-\u9FA5]{1,}[·]*$/
      if (reg.test(this.userData.name)) {
        return true
      } else {
        this.$set(this.valueErrorFlag, 0, true)
        return false
      }
    },
    // 身份证校验
    checkIdNum () {
      // 去除空格
      this.userData.idNum = this.userData.idNum.replace(/\s*/g, '')
      // x转X
      this.userData.idNum = this.userData.idNum.replace('x', 'X')
      if (_$id.checkCardNumber(this.userData.idNum)) {
        return true
      } else {
        this.$set(this.valueErrorFlag, 1, true)
        return false
      }
    },
    // 获取信息
    requestUserInfo () {
      this.isLoad = 'block'
      getBasicInfoApi({}).then((data) => {
        this.isLoad = 'none'
        // let data = {
        //     "body": {
        //         "borrowAmount": 13641,
        //         "borrowPeriod": 43642,
        //         "car": 81112,
        //         "career": 80465,
        //         "creditCardFlag": 35201,
        //         "creditScore": 56406,
        //         "education": 12071,
        //         "fundFlag": 32664,
        //         "house": 21301,
        //         "identityCard": "411281199203293526",
        //         "income": 33158,
        //         "phoneUseTime": 56533,
        //         "socialSecurityFlag": 16112,
        //         "source": 64850,
        //         "userId": 4,
        //         "userName": "helloHHHH"
        //     },
        //     "respCode": "1000",
        //     "respMsg": "成功!"
        // }
        if (data.respCode === "1000") {
          this.showErrorPage = false
          this.userData.name = data.body.userName || ''
          this.userData.idNum = data.body.identityCard || ''

          this.$store.commit("USER_NAME", this.userData.name)
          this.$store.commit("USER_IDCARD", this.userData.idNum)
        }
      }).catch(() => {
        this.isLoad = 'none'
        // this.showErrorPage = true
        this.initDefaultErrorPageInfos('offline')
      })
    },
    // 保存信息
    saveUserInfo () {
      let that = this
      // 点击统计
      that.$appInvoked("appExecStatistic", {
        eventId: "jcxx;qr;w174",
        eventType: 0,
      })

      this.isLoading = true
      let params = {
        identityCard: this.userData.idNum,
        identityName: this.userData.name,
      }
      saveBasicInfoApi(params).then((data) => {
        this.isLoading = false
        if (data.respCode === "1000") {
          this.$store.commit("USER_NAME", this.userData.name)
          this.$store.commit("USER_IDCARD", this.userData.idNum)
          this.$store.commit("hasAuth", true)
          localStorage.setItem('nameIdcardEditAll', true)
          eventCtr.$emit("nameIdcardEditAll", true)
          this.$appInvoked('appToastMessage', { 'message': '保存成功！' })
          if (this.$route.query.source === '2') {
            // 重新智能推荐进入，弹窗引导继续填写资料
            this.confirmData = {
              cancelTxt: '立即重新推荐',
              sureTxt: '继续完善',
              btnType: 'tb',
              iconType: 2,
              txt: '资料越完善，推荐产品通过率越高~<br>是否继续完善？',
              cancel: function () {
                that.$appInvoked('appExecStatistic', {
                  eventId: 'jcxx;zntj;jxtxtc;w281',
                })
                // 重新推荐
                that.globalRecommendClick(281, '2')
              },
              confirm: function () {
                that.$appInvoked('appExecStatistic', {
                  eventId: 'jcxx;zntj;jxtxtc;w280',
                })
                // 继续完善
                that.checkNextFillInfos(that.$route.query.w, '2')
              },
            }
            this.$nextTick(() => {
              this.$refs.confirmDialog.show()
            })
          } else {
            // 执行信息保存并触发两要素撞库
            this.$routerReplace('/loanHit' + this.$tools.objParamsToString(Object.assign(this.$route.query, { checkStatus: 0 })))
          }
        }
      }).catch(() => {
        this.isLoading = false
        // utils.toastMsg("保存失败！请重试")
      })
    },
    // 修改信息
    editUserInfo () {
      // 点击统计
      this.$appInvoked("appExecStatistic", {
        eventId: "jcxx;xg;w173",
        eventType: 0,
      })
    },
    // 点击按钮
    btnClick () {
      // 点击统计
      this.$appInvoked("appExecStatistic", {
        eventId: "jcxx;bc;w172",
        eventType: 0,
      })
      this.userData.name === '' ? this.$set(this.btnClickFlag, 0, true) : this.$set(this.btnClickFlag, 0, false)
      this.userData.idNum === '' ? this.$set(this.btnClickFlag, 1, true) : this.$set(this.btnClickFlag, 1, false)
      // 数据校验
      if (this.btnData.activeFlag) {
        // 校验姓名 和 身份证
        let checkNameResult = this.checkName()
        let checkIdNumResult = this.checkIdNum()
        if (!checkNameResult || !checkIdNumResult) {
          utils.toastMsg('请将错误信息修改后，再提交')
          return
        }
        // 校验通过 展示确认弹窗
        this.$refs.sureComfirm.show()
      }
    },
    // 返回 有任何一项信息已录入展示挽留弹窗
    backClickHandle () {
      let that = this
      if (that.showErrorPage) {
        that.backConfirmCancel()
      } else if (that.source === '2') {
        that.confirmData = {
          cancelTxt: '立即返回',
          sureTxt: '继续完善',
          btnType: 'lr',
          iconType: 3,
          txt: '就差一步，<br>就能解锁更多<span class="remind-txt">秒批放款</span>产品！',
          cancel: function () {
            that.$appInvoked('appExecStatistic', {
              eventId: 'jcxx;zntj;fhtc;w283',
            })
            that.backConfirmCancel()
          },
          confirm: function () {
            that.$appInvoked('appExecStatistic', {
              eventId: 'jcxx;zntj;fhtc;w282',
            })
          },
        }
        that.$refs.confirmDialog.show()
      } else if (that.userData.name !== '' || that.userData.idNum !== '') {
        that.$refs.backComfirm.show()
      } else {
        that.backConfirmCancel()
      }
    },
    // 挽留确认放弃
    backConfirmCancel () {
      let that = this;
      let fromapp = that.$route.query.fromapp;
      if (fromapp === '1') {
        that.$appInvoked("appExecBack", {});
      } else {
        that.$routerGo(-1);
      }
    },
  },
}
</script>
<style lang="scss" scoped>
.hqwy-body-white {
  height: 100%;
  background-color: #fff;
}
.hqwy-mod-info {
  padding: 0 0 0 rc(30);
  font-size: rc(30);
  color: #333;
  li {
    display: flex;
    position: relative;
    padding-right: rc(30);
    height: rc(98);
    align-items: center;
    &:before {
      content: '';
      height: 1px;
      left: 0;
      position: absolute;
      right: 0;
      border-bottom: 1px solid #ddd;
      bottom: -1px;
      transform: scaleY(0.5);
      transform-origin: 0 0;
    }
    .ipt {
      flex: 1;
      height: 100%;
      text-align: right;
    }
    .ipt-disabled {
      color: #999;
    }
    .ipt-error {
      color: #ff4c4c;
    }
  }
  li.error {
    &:before {
      border-color: #ff4c4c;
    }
  }
  li.is-link {
    padding-right: rc(60);
    &:after {
      content: '';
      position: absolute;
      right: rc(30);
      top: 50%;
      margin-top: rc(-13);
      width: rc(14);
      height: rc(26);
      background-color: pink;
    }
  }
}
.hqwy-btns {
  margin: rc(80) 0 0;
  padding: 0 rc(30);
}
.sure-info {
  font-size: rc(30);
  line-height: rc(32);
  li {
    display: flex;
    &:first-child {
      margin-bottom: rc(24);
    }
  }
  .name {
    width: rc(150);
  }
  .hqwy-tip {
    margin-top: rc(26);
    padding-right: rc(5);
    background-color: #fff;
  }
}
</style>
