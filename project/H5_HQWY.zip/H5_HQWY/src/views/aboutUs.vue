<template>
  <AboutUs />
</template>
<script>
import AboutUs from '{APP_PROFILE}/views/aboutUs'
export default {
  components: {
    AboutUs,
  },
}
</script>
