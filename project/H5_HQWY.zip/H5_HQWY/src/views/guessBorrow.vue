<template>
  <PageView type="hqwy-guess"
            title="猜你可贷"
            :show-left="false"
            :show-error-page="showErrorPage"
            :error-page-info="errorPageInfo"
            :has-tabbar="true">
    <div class="bg">
      <CardSwiper ref="child"
                  :pro-list="proList"
                  @toproDetail="proListClick"></CardSwiper>
      <div v-if="hasAuditPass"
           class="guess-zntj-ctr">
        <div class="guess-zntj-tips">
          不是想要的?
        </div>
        <div class="guess-zntj-content"
             @click="guessNoClick()">
          <img class="guess-zntj-icon"
               :src="require('APP_IMG/global_icon_recommend2.png')"
               alt="">
          <div>一键智能推荐</div>
          <img class="guess-zntj-arrow"
               :src="require('APP_IMG/public_arrow_orange.png')"
               alt="">
        </div>
      </div>
    </div>
    <VLoad :isload="isLoad"></VLoad>
    <BasicInfo ref="basicInfo"></BasicInfo>
    <!-- 过审判断 -->
    <AuditPass ref="auditPass"></AuditPass>
  </PageView>
</template>

<script>
import VLoad from "../components/load.vue";
import CardSwiper from "../components/CardSwiper";
import utils from '../util/utils';
import { requestGuessLoan } from "../../src/api/controller/guessLoan";
import { requestJoinLogin } from "../../src/api/controller/product";
import BasicInfo from "../components/basicInfo/index"
import eventCtr from "../../static/js/eventCtr"
import AuditPass from '@/components/function/hasAuditPass'
/* eslint-disable eqeqeq */
export default {
  filters: {
    rate: function (rate) {
      return rate.substring(4, 20);
    },
    rateName: function (rate) {
      return rate.substring(0, 4);
    },
  },
  components: {
    // vAbnor,
    VLoad,
    CardSwiper,
    BasicInfo,
    AuditPass,
  },
  data () {
    return {
      fromLogin: false, // 是否从登录页面返回到当前页面
      errorImg01:
        'this.src="' + require("APP_IMG/default.png") + '"',
      category: "",
      proList: [],
      showErrorPage: false, //网络异常或者没有数据的时候显示
      // reloadText: "", //异常文字图片信息
      errorPageInfo: {},
      isLoad: "none", //默认页面没有loading动画
      swiper: "",
      nameIdcardEditAll: false, // 姓名身份证号已填写标识
      hasAuditPass: false, // 是否已过审
    };
  },
  beforeRouteEnter (to, from, next) {
    let fromLogin = from.path === '/login'
    next((vm) => {
      vm.fromLogin = fromLogin
    });
  },
  activated: function () {
    var self = this;
    self.collectEventMD({
      eventId: 'jr1005',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
    })
    // 安卓点击物理返回键退出
    if (isAndroid) {
      self.$appInvoked('appCleanWeb', { history: true })
    }
    self.category = 1;

    var refreshTime = localStorage.getItem("refreshTime");
    if (
      self.$needRefreshData(JSON.parse(refreshTime)["guessborrow"]) &&
      document.readyState === "complete"
    ) {
      window.location.reload();
      var refreshTimeObj = JSON.parse(refreshTime);
      refreshTime["guessborrow"] = "";
      localStorage.setItem("refreshTime", JSON.stringify(refreshTimeObj));
    }
    this.$nextTick(() => {
      this.autoSlideToNextCard()
    });

    // 获取姓名身份证
    self.$refs.basicInfo.getBasicInfoFun()

    window.vueApp = this;
  },
  mounted: function () {
    var self = this;
    self.$nextTick(function () {
      //获取猜你可贷列表
      // self.getProList();
      self.checkAuditStatus()
    });
    // 获取姓名和身份证是否已填写
    eventCtr.$on("nameIdcardEditAll", (msg) => {
      this.nameIdcardEditAll = msg
    })
  },
  methods: {
    // 未过审产品点击
    noPassProductClick (obj, category, w, index) {
      this.needUserLogin(w, () => {
        localStorage.setItem('no-pass-product-extraMsg', JSON.stringify({ address: obj.address, ...obj.extraMsg }))
        this.$routerPush(`/productDetail/${category}/${obj.id}?pstatus=4&p=${index + 1}&w=${w}&supportJoinLogin=${obj.supportJoinLogin}&t=${obj.rank}`)
      })
    },
    autoSlideToNextCard (list) {
      list = list || this.proList
      let a = parseInt(localStorage.getItem("activeIndex") || 0, 10);
      let length = list.length
      if (!this.fromLogin && length > 0) {
        if (a < length - 1) {
          a = ++a
        } else {
          a = 0
          localStorage.setItem("activeIndex", a)
        }
        setTimeout(() => {
          this.$refs.child.swiper.slideTo(a);
        }, 100)
      }
    },
    // 过审判断
    checkAuditStatus () {
      let self = this
      self.$refs.auditPass.init(true, () => {
        self.hasAuditPass = true
        self.getProList();
      }, (rst, data) => {
        self.hasAuditPass = false
        // 获取成功
        if (rst) {
          data = data.body
          if (data.productList.length > 0) {
            self.proList = data.productList.slice(0, 3); //只展示3个
            this.$nextTick(() => {
              this.autoSlideToNextCard(data.productList.slice(0, 3))
            })
          } else {
            // self.reloadText = {
            //   reloadText: "暂无数据",
            //   defaultImg: this.getCachedImages("noDataIcon")
            // };
            // self.showErrorPage = true;
            self.initDefaultErrorPageInfos('noData')
          }
        } else { // 获取失败
          // self.reloadText = {
          //   reloadText: "网络异常",
          //   defaultImg: this.getCachedImages("loadFailIcon")
          // };
          // self.showErrorPage = true;
          self.initDefaultErrorPageInfos('offline')
        }
      })
    },
    //jsbridge在原生生命周期中会调这个方法，如果从原生跳回h5刷选刷新数据可以在这个方法中调用
    webviewWillAppear () {
      // this.getProList();
      this.checkAuditStatus()
    },
    //获取商品列表
    getProList: function () {
      var self = this;
      self.isLoad = "block"; //开始loading
      let requestParams = {
        category: 13,
      };
      requestGuessLoan(requestParams).then(
        (data) => {
          self.isLoad = "none";
          var repData = data;
          if (repData.respCode === "1000") {
            if (repData.body && repData.body.length > 0) {
              self.proList = repData.body;
              this.$nextTick(() => {
                this.autoSlideToNextCard(repData.body)
              })
            } else {
              self.proList = [];
              // self.reloadText = {
              //   reloadText: "暂无数据",
              //   defaultImg: this.getCachedImages("noDataIcon")
              // };
              // self.showErrorPage = true;
              self.initDefaultErrorPageInfos('noData')
            }
          } else {
            // self.reloadText = {
            //   reloadText: "网络异常",
            //   defaultImg: this.getCachedImages("loadFailIcon")
            // };
            // self.showErrorPage = true;
            self.initDefaultErrorPageInfos('offline')
          }
        },
        () => {
          self.isLoad = "none";
          // self.reloadText = {
          //   reloadText: "网络异常",
          //   defaultImg: this.getCachedImages("loadFailIcon")
          // };
          // self.showErrorPage = true;
          self.initDefaultErrorPageInfos('offline')
        }
      );
    },
    // 点击产品列表
    proListClick (name, url, productId, w, p, goFlag, needBackDialog, category, linkSeqId, item) {
      if (!this.hasAuditPass) {
        this.noPassProductClick(item, category, w, p - 1)
        return
      }
      let that = this
      that.needUserLogin(w, () => {
        // 是否支持api
        if (item.supportApiLoan) {
          let tourl = `?category=${category}&productId=${productId}&productName=${name}&p=${p}&w=${w}&supportJoinLogin=${item.supportJoinLogin}&t=${item.rank}`
          let eventId = `chanpin0;w${w};p${p};c${productId};l${window.$config.get('events.linkSeqId')};t${item.rank}`;
          that.clickReport(productId, category, eventId);
          that.$appInvoked("appExecStatistic", {
            eventId: eventId,
            eventType: 2,
          }); //添加埋点
          // 姓名和身份证号是否已填写
          if (!that.nameIdcardEditAll) {
            that.$refs.basicInfo.getBasicInfoFun((nameIdcardEditAll) => {
              if (nameIdcardEditAll) {
                // 已填写 去撞库
                that.$routerPush('/loanHit' + tourl)
              } else {
                // 未填写去基本信息补充页
                that.$routerPush('/basicInfo' + tourl)
              }
            })
          } else {
            // 已填写 去撞库
            that.$routerPush('/loanHit' + tourl)
          }
        } else {
          that.toproDetail(name, url, productId, w, p, goFlag, needBackDialog, category, linkSeqId, item)
        }
      })
    },
    toproDetail (
      name,
      url,
      productId,
      w,
      p,
      goFlag,
      needBackDialog,
      category,
      linkSeqId,
      proObj
    ) {
      var self = this;

      // chanpin0进入产品详情页，chanpin1进入H5落地页，chanpin2阻止用户申请
      let eventId = `chanpin0;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
      if (goFlag == 2) { // 0-产品详情，2-第三方注册页
        eventId = `chanpin1;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
        let supportJoinLogin = proObj.supportJoinLogin; // 是否支持联登
        if (supportJoinLogin) { // 支持联合登录
          self.isLoad = 'block';
          let params = {
            linkId: linkSeqId,
            productId: productId,
          };
          requestJoinLogin(params).then((data) => {
            self.isLoad = 'none';
            if (data.respCode === '1000') {
              data = data.body;
              let regStatus = data.regStatus;
              // 0-未知 1-注册失败 2-金融超市注册成功 3-失败：其他渠道已有用户
              if (regStatus == 2) {
                self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
              } else if (regStatus == 3) {
                utils.toastMsg(`您已注册过${name}，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              } else {
                utils.toastMsg(`${name}系统维护中，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              }
            } else {
              utils.toastMsg(`${name}系统维护中，请申请其他产品`);
              eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
              self.clickReport(productId, category, eventId);
            }
            self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
          }, () => {
            self.isLoad = 'none';
          });
        } else {
          // type = 1;
          // 打开第三方注册页
          self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
          self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
        }
      } else {
        self.clickReport(productId, category, eventId);

        self.$routerPush(
          "/productDetail/" +
          category +
          "/" +
          productId +
          "?p=" +
          p +
          "&w=" +
          w +
          "&supportJoinLogin=" +
          proObj.supportJoinLogin + '&t=' + proObj.rank
        );
        self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
      }
      self.$appInvoked("appOnPageEnd", { pageName: this.$route.meta.title });
      window.currentPageName = this.$route.meta.title;
    },
    guessNoClick () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'cnkd;zntj;w272',
      })
      this.globalRecommendClick(272)
    },
  },
};
</script>

<style lang="scss" scoped="scoped">
.bg {
  // height: rc(684);
  width: 100%;
  height: 100%;
  background: url(../../static/images/#{$APP_NAME}/borrowbg.png) no-repeat top left;
  background-size: 100% rc(767);
  overflow-x: hidden;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  padding-bottom: rc(100);
  box-sizing: border-box;
  // padding-bottom: rc(100);
}
.guess-zntj-ctr {
  margin-top: rc(32);
  text-align: center;
  .guess-zntj-tips {
    font-size: rc(24);
    line-height: rc(33);
    color: $color-text-tip;
  }
  .guess-zntj-content {
    margin-top: rc(12);
    display: flex;
    align-items: center;
    justify-content: center;
    color: $color-remind;
    height: rc(48);
    line-height: normal;
    font-size: rc(26);
    .guess-zntj-icon {
      width: rc(48);
      height: auto;
      margin-right: rc(12);
    }
    .guess-zntj-arrow {
      width: rc(15);
      height: auto;
      margin-left: rc(12);
    }
  }
}
</style>
