<template>
  <PageView title="我的优惠券"
            :is-back-page="false"
            :show-error-page="showErrorPage"
            :error-page-info="errorPageInfo"
            @backClick="backClickHandle">
    <div id="hqwy-mescroll"
         class="mescroll">
      <div v-if="!showErrorPage"
           class="coupon">
        <div v-for="(coupon,index) in couponList"
             :key="index"
             class="coupon-list"
             @click="proListClick(coupon.name,coupon.id,124,index+1,coupon.type,coupon.address,coupon.linkSeqId,coupon)">
          <div class="coupon-left">
            <img :src="coupon.logo" />
            <div class="coupon-cont">
              <div class="top">
                {{ coupon.couponName }}
              </div>
              <div class="bottom">
                {{ coupon.subCouponName }}
              </div>
            </div>
          </div>
          <div class="coupon-middle">
            <img src="../../static/images/coupon.png">
          </div>
          <div class="coupon-right">
            <div class="money">
              <span>{{ coupon.couponContent }}</span>
            </div>
            <div v-show="!coupon.isGet"
                 class="get">
              <span>马上领取</span>
            </div>
            <div v-show="coupon.isGet"
                 class="already-get">
              已领取
            </div>
          </div>
          <!--<div  v-show="coupon.isGet">已领取</div>-->
        </div>
        <BasicInfo ref="basicInfo"></BasicInfo>
      </div>
    </div>
    <VLoad :isload="isLoad"></VLoad>
  </PageView>
</template>

<script>
import VLoad from "../components/load.vue";
import utils from '../util/utils';
import { myCouponApi } from "../../src/api/controller/categoryLoan";
import { requestJoinLogin } from "../../src/api/controller/product";
import BasicInfo from "../components/basicInfo/index"
import eventCtr from "../../static/js/eventCtr"
/* eslint-disable eqeqeq */
export default {
  components: {
    // vAbnor,
    VLoad,
    BasicInfo,
  },
  data () {
    return {
      couponList: [],
      showErrorPage: false, //网络异常时显示
      errorPageInfo: {},
      // reloadText: "",
      nameIdcardEditAll: false, // 姓名身份证号已填写标识
      isLoad: "none", //默认页面没有loading动画
    };
  },
  activated () {
    this.interceptAppBack()
    this.showErrorPage = false
    var self = this;
    this.getCouponList();
    self.collectEventMD({
      eventId: 'jr1018',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
    })
  },
  mounted () {
    // 获取姓名和身份证是否已填写
    eventCtr.$on("nameIdcardEditAll", (msg) => {
      this.nameIdcardEditAll = msg
    })
  },
  methods: {
    backClickHandle () {
      this.$appInvoked("appExecStatistic", {
        eventId: "yhq;fh;w125",
        eventType: 0,
      }); //添加返回埋点
      this.$routerGo(-1);
    },
    getCouponList () {
      var self = this;
      var param = {
        category: 14,
      };
      myCouponApi(param).then(
        (data) => {
          var repData = data;
          if (repData.respCode === "1000") {
            if (repData.body.page.length > 0) {
              var myDate = new Date();
              var dates = myDate.toLocaleDateString();
              var hasClickedObj =
                JSON.parse(localStorage.getItem("hasClickedObj")) || {};
              var hasClickedList = [];
              if (dates == hasClickedObj.date) {
                hasClickedList = hasClickedObj.list;
              }
              self.couponList = repData.body.page;
              if (hasClickedList && hasClickedList.length > 0) {
                self.couponList = self.couponList.map(function (e) {
                  if (hasClickedList.indexOf(e.id) > -1) {
                    e.isGet = true;
                  } else {
                    e.isGet = false;
                  }
                  return e;
                });
              }
            } else {
              // self.reloadText = {
              //   reloadText: "暂无优惠券",
              //   defaultImg: this.getCachedImages("productIcon")
              // };
              // self.showErrorPage = true;
              self.initDefaultErrorPageInfos('', {
                title: '据说借款次数越多，获得优惠券的几率越大',
                icon: 'qsy_wyhq.png',
                btnTxt: '去借款',
                btnClick: () => {
                  self.$routerPush("/productlist")
                },
              })
            }
          }
        },
        () => {
          // self.reloadText = {
          //   reloadText: "网络异常",
          //   defaultImg: this.getCachedImages("loadFailIcon")
          // };
          // self.showErrorPage = true;
          self.initDefaultErrorPageInfos('offline')
        }
      );
    },
    // 点击产品列表
    proListClick (name, id, w, p, goFlag, url, linkSeqId, item) {
      let that = this
      that.needUserLogin(w, () => {
        // 是否支持api
        if (item.supportApiLoan) {
          let tourl = `?category=14&productId=${id}&productName=${name}&p=${p}&w=${w}&supportJoinLogin=${item.supportJoinLogin}&t=${item.rank}`
          let eventId = `chanpin0;w${w};p${p};c${id};l${window.$config.get('events.linkSeqId')};t${item.rank}`;
          that.clickReport(id, 14, eventId);
          that.$appInvoked("appExecStatistic", {
            eventId: eventId,
            eventType: 2,
          }); //添加埋点
          // 姓名和身份证号是否已填写
          if (!that.nameIdcardEditAll) {
            that.$refs.basicInfo.getBasicInfoFun((nameIdcardEditAll) => {
              if (nameIdcardEditAll) {
                // 已填写 去撞库
                that.$routerPush('/loanHit' + tourl)
              } else {
                // 未填写去基本信息补充页
                that.$routerPush('/basicInfo' + tourl)
              }
            })
          } else {
            // 已填写 去撞库
            that.$routerPush('/loanHit' + tourl)
          }
        } else {
          that.getDetail(name, id, w, p, goFlag, url, linkSeqId, item)
        }
      })
    },
    getDetail (name, id, w, p, goFlag, url, linkSeqId, item) {
      let productId = id,
        proObj = item,
        category = 14;
      var self = this;
      var myDate = new Date();
      var dates = myDate.toLocaleDateString();

      var lists = self.couponList;
      for (var i in lists) {
        if (lists[i].id == id) {
          lists[i].isGet = true;
        }
      }
      self.couponList = lists;
      self.$forceUpdate();

      // 保存已点击项目id
      var hasClickedObj =
        JSON.parse(localStorage.getItem("hasClickedObj")) || {};
      var hasClickedList = [];
      if (dates == hasClickedObj.date) {
        hasClickedList = hasClickedObj.list;
      }
      hasClickedList.push(id);
      localStorage.setItem(
        "hasClickedObj",
        JSON.stringify({
          date: dates,
          list: Array.from(new Set(hasClickedList)),
        })
      );


      // chanpin0进入产品详情页，chanpin1进入H5落地页，chanpin2阻止用户申请
      let eventId = `chanpin0;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
      if (goFlag == 2) { // 0-产品详情，2-第三方注册页
        eventId = `chanpin1;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
        let supportJoinLogin = proObj.supportJoinLogin; // 是否支持联登
        if (supportJoinLogin) { // 支持联合登录
          self.isLoad = 'block';
          let params = {
            linkId: linkSeqId,
            productId: productId,
          };
          requestJoinLogin(params).then((data) => {
            self.isLoad = 'none';
            if (data.respCode === '1000') {
              data = data.body;
              let regStatus = data.regStatus;
              // 0-未知 1-注册失败 2-金融超市注册成功 3-失败：其他渠道已有用户

              if (regStatus == 2) {
                self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
              } else if (regStatus == 3) {
                utils.toastMsg(`您已注册过${name}，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              } else {
                utils.toastMsg(`${name}系统维护中，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              }
            } else {
              utils.toastMsg(`${name}系统维护中，请申请其他产品`);
              eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
              self.clickReport(productId, category, eventId);
            }
            self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
          }, () => {
            self.isLoad = 'none';
          });
        } else {
          // type = 1;
          // 打开第三方注册页
          self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
          self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
        }
      } else {
        self.clickReport(productId, category, eventId);
        self.$routerPush(
          "/productDetail/" +
          category +
          "/" +
          productId +
          "?p=" +
          p +
          "&w=" +
          w +
          "&supportJoinLogin=" +
          proObj.supportJoinLogin + '&t=' + proObj.rank
        );
        self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
      }
      self.$appInvoked("appOnPageEnd", { pageName: this.$route.meta.title });
      window.currentPageName = this.$route.meta.title;
    },
    //给app提供一个方法
    // topPreRecommend () {
    //   this.globalRecommendClick()
    // }
  },
};
</script>

<style lang="scss" scoped="scoped">
#hqwy-mescroll {
  height: 100%;
  width: 100%;
  box-sizing: border-box;
  overflow-x: hidden;
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch;
}

.coupon {
  /*margin-top: rc(32);*/
  /*width: rc(682);*/
  /*margin: ;*/
  /*min-height: 100%;*/
  margin: 0 rc(35) rc(35) rc(35);
  /*margin-right: rc(35);*/
  .coupon-list {
    height: rc(180);
    background: #fff;
    margin-top: rc(20);
    border-radius: rc(8);
    display: flex;
    // display: -webkit-flex;
    // box-shadow: 0 2px 4px 0 rgba(17, 17, 17, 0.1);
    .coupon-left {
      /*width: rc(420);*/
      width: 80%;
      padding-left: rc(26);
      display: flex;
      /*display:-webkit-flex;*/
      justify-content: flex-start;
      align-items: center;
      img {
        /*margin-top: rc(50);*/
        height: rc(80);
        width: rc(80);
        border-radius: 5px;
      }
    }
    .coupon-middle img {
      height: rc(180);
      width: rc(32);
    }
    .coupon-right {
      min-width: rc(250);
      height: rc(180);
      /*flex: 1;*/
      /*-webkit-flex: 1;*/
    }
  }
}

.coupon-cont {
  padding-left: rc(20);
  .top {
    /*margin-top: rc(47);*/
    font-size: rc(30);
    color: #111111;
    font-weight: bold;
    min-height: rc(40);
  }
  .bottom {
    /*margin-top: rc(10);*/
    font-size: rc(24);
    color: #999999;
    min-height: rc(40);
  }
}

.money {
  margin-top: rc(32);
  height: rc(67);
  color: $color-remind;
  text-align: center;
  line-height: rc(67);
  font-size: rc(30);
  span {
    font-size: rc(48);
  }
}

.get {
  height: rc(48);
  line-height: rc(48);
  /*width: rc(144);*/

  text-align: center;
  /*margin: 0 rc(15);*/
  /*margin-left: rc(30);*/
  /*max-width: rc(144);*/
  align-items: center;
  justify-content: center;
  span {
    background-image: $btn-default-bg;
    border-radius: rc(25);
    font-size: rc(24);
    color: #ffffff;
    width: rc(144);
    height: rc(48);
    padding: rc(8) rc(24);
    &:active {
      background-image: $btn-actived-bg;
    }
  }
}

.already-get {
  margin-top: rc(8);
  font-size: rc(24);
  color: #999999;
  text-align: center;
}
</style>
