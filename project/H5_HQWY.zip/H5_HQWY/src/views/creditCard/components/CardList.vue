<template>
  <div v-if="show"
       class="recommend hy-1px-b">
    <img :src="listItem.logo"
         class="recommend-left">
    <div class="recommend-right">
      <div class="recommend-right-title">
        <h2>{{ listItem.name }}</h2>
        <HyTag v-if="listItem.hot"
               class="recommend-right-hot"
               :text="listItem.hot"
               :custom-made-style="{backgroundColor:'#ea3323',color:'#ffffff'}"></HyTag>
      </div>

      <p class="recommend-right-subtitle">
        {{ listItem.desc }}
      </p>
      <HyLabel v-if="listItem.tip"
               class="hy-label"
               :title="listItem.tip"
               :color="'#ff601a'"
               type="product-tag"></HyLabel>
    </div>
  </div>
</template>
<script>
// import MeScroll from "mescroll.js";
import HyTag from "@/components/tag/index";
import HyLabel from '@/components/HyLabel'
export default {
  components: {
    HyTag,
    HyLabel,
    // MeScroll
  },
  props: {
    listItem: {
      type: Object,
      default: () => ({}),
    },
    show: {
      type: Boolean,
      default: true,
    },
  },
  data () {
    return {
      mescroll: null,
      dataList: [],
    }
  },
  // mounted () {

  // },
  // methods: {

  // },
}
</script>
<style lang="scss" scoped>
.recommend {
  display: flex;
  padding: rc(38) rc(36);
  box-sizing: border-box;
}
.recommend-left {
  width: rc(247);
  height: rc(156);
  margin-right: rc(28);
  border-radius: rc(10);
  background: $bgColor;
}
.recommend-right {
  flex: 1;
  position: relative;
  h2 {
    position: relative;
    font-size: rc(34);
    color: $color-text-title;
  }
}
.recommend-right-hot {
  position: static !important;
  height: rc(40);
  margin: rc(-15) 0 0 rc(10);
}
.recommend-right-title {
  display: flex;
  h2 {
    font-weight: bold;
  }
}
.recommend-right-subtitle {
  font-size: rc(28);
  color: $color-text-tip;
  margin-top: 2px;
}
.hy-label {
  height: rc(51) !important;
  line-height: rc(51);
  position: absolute;
  margin-left: rc(0) !important;
  bottom: 0;
}
.recommend-tag {
  top: 0 !important;
}
</style>
