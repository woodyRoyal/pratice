<template>
  <PageView type="prolistpage"
            title="信用卡">
    <div ref="homeMescroll"
         class="mescroll credit-card-home">
      <div>
        <header class="header">
          <div class="header-item"
               @click="findInfo(0, 306)">
            <span class="header-item-ico"></span>
            <span>进度查询</span>
          </div>
          <div class="header-item"
               @click="findInfo(1, 307)">
            <span class="header-item-ico header-item-ico-b"></span>
            <span>全部卡片</span>
          </div>
        </header>
        <section>
          <div class="module-hd">
            <h2 class="module-hd-left">
              热门银行
            </h2>
            <span v-if="hotBankList.length>8"
                  class="module-hd-right"
                  @click="open">{{ !isOpen?'展开更多':'收起更多' }}<i :class="[!isOpen?'arrow-down':'arrow-up']"></i></span>
          </div>
          <div class="hot-bank-grop"
               :class="{'hot-bank-grop-auto':isOpen}">
            <div v-for="(item, index) in hotBankList"
                 :key="item.id"
                 class="hot-bank-grop-item"
                 @click="goHotBank(item, index)">
              <div class="hot-bank-grop-item-wrap">
                <img :src="item.logo"
                     class="hot-bank-grop-item-img">
                <HyTag v-if="item.hot"
                       :text="item.hot"
                       :custom-made-style="{color:'#ff601a',borderColor:'#ff601a'}"></HyTag>
              </div>
              <span>{{ item.name }}</span>
            </div>
          </div>
          <div class="module-hd module-hd-padding">
            <h2 class="module-hd-left">
              推荐卡片
            </h2>
          </div>
          <div class="credit-card-list">
            <CardList v-for="(item, index) in cardList"
                      :key="item.id"
                      :show="item.recommend"
                      :list-item="item"
                      @click.native="cardListhandler(item, index)"></CardList>
          </div>
        </section>

        <img ref="imgLoad"
             src="../../../static/images/loding.gif"
             style="display: none" />
        <button class="btn"
                @click="toFindCard()">
          查看全部信用卡
        </button>
      </div>
    </div>
  </PageView>
</template>
<script>
import MeScroll from 'mescroll.js'
import HyTag from "@/components/tag/index";
import { hotList, cardList } from './bank'
import CardList from './components/CardList'
export default {
  components: {
    HyTag,
    CardList,
  },
  data () {
    return {
      mescroll: null,
      isOpen: false,
      hotBankList: hotList,
      cardList: cardList,
    }
  },
  mounted () {
    this.mescroll = new MeScroll(this.$refs.homeMescroll, {
      down: {
        use: false,
        auto: false,
      },
      up: {
        auto: false,
        callback: this.upCallback,
        isBounce: false,
        noMoreSize: 1,
        htmlLoading: `<div id="databottom" class="data-bottom">
                    <div class="load">
                      <img src="${this.$refs.imgLoad.src}" />
                    </div>
                    <div class="text" id="bottomtext">更多产品正在赶来</div>
                  </div>`,
        htmlNodata: `<div class="no-data"></div>`,
      },
    });
    this.mescroll.endSuccess(1, false);
  },
  activated () {
    this.collectEventMD({
      eventId: 'jr1019',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
    })
  },
  methods: {
    upCallback (page) {
      console.log(page)
    },
    // 0进度 1卡片查询
    findInfo (type, w) {
      this.needUserLogin(w, () => {
        if (type) {
          this.$appInvoked("appExecStatistic", {
            eventId: 'xyk;qbkp;w307',
          });
          this.$routerPush('/creditCardList/?id=-1')
        } else {
          this.$appInvoked("appExecStatistic", {
            eventId: 'xyk;jdcx;w306',
          });
          this.$routerPush('/creditCardProgress')
        }
      })
    },
    // 热门银行
    goHotBank (item, index) {
      this.needUserLogin(308, () => {
        this.$appInvoked("appExecStatistic", {
          eventId: `xyk;rmyh;w308;p${index + 1};y${item.id}`,
        });
        this.$routerPush(`/creditCardList/?id=${item.id}&index=${index + 1}&name=${item.name}`)
      })
    },
    // 查看更多
    open () {
      this.isOpen = !this.isOpen
    },
    // 跳转查询更多卡
    toFindCard () {
      this.needUserLogin(311, () => {
        this.$appInvoked("appExecStatistic", {
          eventId: 'xyk;tjkp;w311',
        });
        this.$routerPush('/creditCardList?id=-1')
      })
    },
    cardListhandler (item, index) {
      this.needUserLogin(310, () => {
        let linkId = this.$config.get('events.creditCardlinkId')
        let eventId = `chanpin1;w310;p${index + 1};c${item.id};l${linkId};t0`
        this.$appInvoked("appExecStatistic", {
          eventId: eventId,
          eventType: 2,
        });
        this.clickReport(item.id, 5, eventId)
        this.$appInvoked("appOpenWebview", {
          copyMobile: true,
          url: item.link,
          nav: {
            title: {
              text: item.name,
            },
          },
        })
      })

    },
  },
}
</script>
<style lang="scss" scoped>
.mescroll {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}
.header {
  display: flex;
  box-sizing: border-box;
  padding: rc(45) 0;
  background: #ffffff;
  margin-bottom: rc(20);
}
.header-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: $color-text-title;
  font-size: rc(28);
}
.header-item-ico {
  position: relative;
  width: rc(98);
  height: rc(98);
  display: inline-block;
  margin-bottom: rc(20);
  background: url('../../../static/images/card_icon_schedule.png') no-repeat;
  background-size: rc(98) rc(98);
}
.header-item-ico-b {
  background: url('../../../static/images/card_icon_all.png') no-repeat;
  background-size: rc(98) rc(98);
}
section {
  box-sizing: border-box;
  background: #ffffff;
}
.module-hd {
  display: flex;
  padding: rc(40) rc(36) rc(53);
  justify-content: space-between;
  align-items: center;
}
.module-hd-padding {
  padding: 0 rc(36) 0;
}
.module-hd-left {
  color: $color-text-title;
  font-size: rc(36);
  line-height: rc(38);
}
.module-hd-right {
  display: flex;
  align-items: center;
  font-size: rc(26);
  color: $color-text-sub;
}
.arrow-down {
  width: rc(17);
  height: rc(9);
  margin-left: rc(5);
  display: inline-block;
  background: url('../../../static/images/public_arrow_unfold.png') no-repeat;
  background-size: rc(17) rc(9);
  transform: rotate(360deg);
  animation: down 0.3s ease-out;
}
@keyframes down {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
.arrow-up {
  @extend .arrow-down;
  background: url('../../../static/images/public_arrow_retract.png') no-repeat;
  background-size: rc(17) rc(9);
  animation: up 0.3s ease-out;
}
@keyframes up {
  from {
    transform: rotate(360deg);
  }
  to {
    transform: rotate(0);
  }
}
.hot-bank-grop {
  padding: 0 rc(36) rc(0);
  box-sizing: border-box;
  display: flex;
  flex-wrap: wrap;
  max-height: rc(430);
  overflow: hidden;
}
.hot-bank-grop-auto {
  max-height: none;
}
.hot-bank-grop-item {
  width: 33.333333%;
  height: rc(213);
  text-align: center;
  box-sizing: border-box;
  span {
    font-size: rc(28);
  }
}
.hot-bank-grop-item-img {
  width: rc(96);
  height: rc(96);
}
.hot-bank-grop-item-wrap {
  width: rc(96);
  height: rc(96);
  margin: 0 auto rc(20);
  position: relative;
}
.btn {
  width: 90%;
  display: block;
  margin: rc(30) auto;
  height: rc(80);
  line-height: rc(80);
  color: $color-text-title;
  font-size: rc(26);
  text-align: center;
  background: #ffffff;
  border-radius: 50px;
}
</style>
<style lang="scss">
.credit-card-home {
  .data-bottom {
    margin-top: rc(21);
    margin-bottom: -20px;
    font-size: rc(24);
    color: #777;
    display: flex;
    display: -webkit-flex;
    text-align: center;
    .load {
      width: rc(34);
      height: rc(34);
      margin-left: rc(281);
      img {
        width: rc(34);
        height: rc(34);
      }
    }
    .text {
      margin-left: rc(10);
    }
  }
}
</style>
