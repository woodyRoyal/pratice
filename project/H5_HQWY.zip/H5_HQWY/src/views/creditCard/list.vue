<template>
  <PageView :title="title"
            :right-txt="rightTxt"
            @rightClick="rightHandle">
    <div v-if="cardListResult.length>=0"
         ref="listMescroll"
         key="noEmpty"
         class="mescroll credit-card-list">
      <div class="credit-card-list-content">
        <CardList v-for="(item, index) in cardListResult"
                  :key="item.id"
                  :class="{'hy-1px-t': index === 0}"
                  :list-item="item"
                  @click.native="cardListhandler(item, index)"></CardList>
        <img ref="imgLoad"
             src="../../../static/images/loding.gif"
             style="display: none" />
      </div>
    </div>
    <div v-if="cardListResult.length<=0"
         key="empty"
         class="empty">
      <img :src="require('APP_IMG/qsy_wxyk.png')"
           alt="">
      <p>很遗憾！暂无满足您要求的信用卡，请重新选择！</p>
    </div>
    <div v-show="ishotBank"
         class="bank-grop"
         @click="ishotBank=!ishotBank">
      <div class="bank-grop-list">
        <div v-for="(item,i) in hotBankList"
             :key="item.id"
             class="bank-grop-list-item"
             @click.stop="findBank(item,i)">
          <span class="bank-grop-list-item-btn"
                :class="{'activation':hotBankIndex==i}">{{ item.name }}</span>
        </div>
      </div>
    </div>
  </PageView>
</template>
<script>
import CardList from './components/CardList'
import MeScroll from 'mescroll.js'
import { hotList, cardList } from './bank'
/* eslint-disable eqeqeq */
export default {
  components: {
    CardList,
  },
  data () {
    return {
      hotIndex: 0,
      rightTxt: '',
      title: '',
      ishotBank: false, // 控制筛选展示隐藏
      hotBankIndex: 0, // 控制筛选
      currentBanId: -1, // 当前选择的id
      mescroll: null, // 加载更多
      hotBankList: [{ id: -1, name: '全部' }, ...hotList],
      cardList: cardList, // 列表
    }
  },
  computed: {
    cardListResult () {
      let result = this.cardList.filter((v) => v.hotListId == this.currentBanId)
      if (this.currentBanId == -1) {
        return this.cardList;
      } else {
        return result
      }
    },
  },
  mounted () {
    this.mescroll = new MeScroll(this.$refs.listMescroll, {
      down: {
        use: false,
        auto: false,
      },
      up: {
        auto: false,
        callback: this.upCallback,
        isBounce: false,
        noMoreSize: 5,
        htmlLoading: `<div id="databottom" class="data-bottom">
                    <div class="load">
                      <img src="${this.$refs.imgLoad.src}" />
                    </div>
                    <div class="text" id="bottomtext">更多产品正在赶来</div>
                  </div>`,
        htmlNodata: `<div class="no-data"><span></span>已经到底啦<span></span></div>`,
      },
    });
  },
  activated () {
    this.hotBankIndex = 0
    this.ishotBank = false;
    let productId = this.$route.query.id
    this.hotIndex = String(this.$route.query.index)
    if (productId != -1) {
      this.rightTxt = ''
      this.title = this.$route.query.name || '信用卡大全'
    } else {
      this.rightTxt = '筛选'
      this.title = '信用卡大全'
    }
    this.currentBanId = productId;
    this.collectEventMD({
      eventId: 'jr1020',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
    })
  },
  methods: {
    upCallback () {
      this.mescroll.endSuccess(5, false);
    },
    // 筛选
    rightHandle () {
      this.needUserLogin(317, () => {
        this.$appInvoked("appExecStatistic", {
          eventId: 'xyk;xykdq;sx;w317',
        });
        this.ishotBank = true;
      })
    },
    // 列表点击处理
    cardListhandler (item, index) {
      let w = '319'
      // 热门银行入口
      if (this.rightTxt !== '筛选') {
        w = `100${this.hotIndex}`
      }
      this.needUserLogin(w, () => {

        let linkId = this.$config.get('events.creditCardlinkId')
        let eventId = `chanpin1;w${w};p${index + 1};c${item.id};l${linkId};t0`
        this.$appInvoked("appExecStatistic", {
          eventId: eventId,
          eventType: 2,
        });
        this.clickReport(item.id, 5, eventId)
        this.$appInvoked("appOpenWebview", {
          copyMobile: true,
          url: item.link,
          nav: {
            title: {
              text: item.name,
            },
          },
        })
      })
    },
    // 筛选列表点击
    findBank (item, i) {
      this.needUserLogin(i === 0 ? 316 : 318, () => {
        if (i === 0) {
          this.$appInvoked("appExecStatistic", {
            eventId: 'xyk;xykdq;sx;w316',
          });
        } else {
          this.$appInvoked("appExecStatistic", {
            eventId: `xyk;xykdq;sx;w318;y${item.id}`,
          });
        }
        this.hotBankIndex = i;
        this.currentBanId = item.id;
        this.ishotBank = false;
      })

    },
  },
}
</script>
<style lang="scss" scoped>
.hyapp-header {
  border: 1px solid #dddddd;
}
.mescroll {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}
.credit-card-list-content {
  background: #ffffff;
}
.bank-grop {
  width: 100%;
  height: 100%;
  // padding-top: 44px;
  box-sizing: border-box;
  position: absolute;
  background: rgba(0, 0, 0, 0.5);
  top: 0;
  z-index: 1;
}
.bank-grop-list {
  padding: rc(45) 0 rc(36) 0;
  display: flex;
  flex-wrap: wrap;
  background: #ffffff;
}
.bank-grop-list-item {
  width: 33.33%;
  box-sizing: border-box;
  margin-bottom: rc(30);
}
.bank-grop-list-item-btn {
  margin: 0 auto;
  width: rc(210);
  display: block;
  height: rc(80);
  line-height: rc(80);
  text-align: center;
  border: 1px solid #dddddd;
  color: $color-text-title;
  box-sizing: border-box;
  font-size: rc(34);
  border-radius: 50px;
}
.bank-grop-list-item-btn.activation {
  color: $color-main;
  border: 1px solid $color-main;
}
.empty {
  position: fixed;
  z-index: 1;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
  p {
    text-align: center;
    color: $color-text-sub;
    font-size: rc(28);
    margin-top: rc(52);
  }
  img {
    width: rc(300);
    height: rc(300);
  }
}
</style>
<style lang="scss">
.credit-card-list {
  // .recommend {
  //   border-bottom: 0 !important;
  //   margin: 0 !important;
  //   padding: rc(38) rc(36) !important;
  // }
  .data-bottom {
    margin-top: rc(21);
    margin-bottom: -20px;
    font-size: rc(24);
    color: #777;
    display: flex;
    text-align: center;
    .load {
      width: rc(34);
      height: rc(34);
      margin-left: rc(281);
      img {
        width: rc(34);
        height: rc(34);
      }
    }
    .text {
      margin-left: rc(10);
    }
  }
  .no-data {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: rc(24);
    text-align: center;
    color: $color-text-tip;
    margin: rc(37) 0 rc(56) 0;
    span {
      width: rc(40);
      height: 1px;
      margin: 0 rc(12);
      background: $color-text-tip;
      display: block;
    }
  }
}
</style>
