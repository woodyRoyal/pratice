<template>
  <page-view title="进度查询">
    <div ref="progressMescroll"
         class="mescroll credit-card-progress">
      <div v-for="(item, index) in hotList"
           :key="item.id"
           class="credit-card-progress-content hy-1px-t">
        <div class="logo">
          <img :src="item.logo"
               alt="">
          <h2>{{ item.name }}</h2>
        </div>
        <div>
          <a v-if="item.tel"
             :href="'tel:'+item.tel"
             class="tel">
            <img class="tel-icon"
                 :src="require(`../../../static/images/card_icon_phone.png`)"
                 alt=""
                 @click="finInfo(0, item, index)">
          </a>
          <img v-if="item.link"
               class="tel-icon"
               :src="require(`../../../static/images/card_icon_url.png`)"
               alt=""
               @click="finInfo(1, item, index)">
        </div>
        <img ref="imgLoad"
             src="../../../static/images/loding.gif"
             style="display: none" />
      </div>
    </div>
  </page-view>
</template>
<script>
// import CardList from './components/CardList'
import MeScroll from 'mescroll.js'
import { hotList } from './bank'
/* eslint-disable eqeqeq */
export default {
  // components: {
  //   CardList,
  // },
  data () {
    return {
      mescroll: null,
      hotList: hotList,
    }
  },
  mounted () {
    this.mescroll = new MeScroll(this.$refs.progressMescroll, {
      down: {
        use: false,
        auto: false,
      },
      up: {
        auto: false,
        callback: this.upCallback,
        isBounce: false,
        noMoreSize: 5,
        htmlLoading: `<div id="databottom" class="data-bottom">
                    <div class="load">
                      <img src="${this.$refs.imgLoad.src}" />
                    </div>
                    <div class="text" id="bottomtext">更多产品正在赶来</div>
                  </div>`,
        htmlNodata: `<div class="no-data"><span></span>已经到底啦<span></span></div>`,
      },
    });

  },
  methods: {
    upCallback () {
      this.mescroll && this.mescroll.endSuccess(4, false);
    },
    finInfo (type, item, index) {
      this.needUserLogin(type == 0 ? 312 : 315, () => {
        // type 0 拨电话
        if (type) {
          this.$appInvoked("appExecStatistic", {
            eventId: `xyk;jdcx;gw;w315;p${index + 1};y${item.id}`,
          });
          this.$appInvoked("appOpenWebview", {
            // copyMobile: true,
            url: item.link,
            nav: {
              title: {
                text: item.name,
              },
            },
          })
        } else {
          this.$appInvoked("appExecStatistic", {
            eventId: `xyk;jdcx;dh;w312;p${index + 1};y${item.id}`,
          });
        }
      })

    },
  },
}
</script>
<style lang="scss" scoped>
.mescroll {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}
.credit-card-progress-content {
  height: rc(140);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 rc(36) 0 rc(23);
  box-sizing: border-box;
  background: #ffffff;
}
.logo {
  display: flex;
  align-items: center;
  h2 {
    font-size: rc(34);
    font-weight: bold;
    color: $color-text-title;
  }
  img {
    margin-right: rc(20);
    width: rc(100);
    height: rc(100);
  }
}
.tel {
  display: inline-block;
}
.tel-icon {
  width: rc(56);
  height: rc(56);
  margin-left: rc(30);
}
</style>
<style lang="scss">
.credit-card-progress {
  .data-bottom {
    margin-top: rc(21);
    margin-bottom: -20px;
    font-size: rc(24);
    color: #777;
    display: flex;
    text-align: center;
    .load {
      width: rc(34);
      height: rc(34);
      margin-left: rc(281);
      img {
        width: rc(34);
        height: rc(34);
      }
    }
    .text {
      margin-left: rc(10);
    }
  }
  .no-data {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: rc(24);
    text-align: center;
    color: $color-text-tip;
    margin: rc(37) 0 rc(56) 0;
    span {
      width: rc(40);
      height: 1px;
      margin: 0 rc(12);
      background: $color-text-tip;
      display: block;
    }
  }
}
</style>
