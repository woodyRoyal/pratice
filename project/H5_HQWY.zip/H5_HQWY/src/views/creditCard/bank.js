// 热门银行
const hotList = [
  // {
  //   name: '浦发银行',
  //   id: '1',
  //   logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/3c7846790e2dad411340524806a1262f.png',
  //   hot: '高额度',
  //   tel: '95528',
  //   link: 'https://www.spdb.com.cn/',
  //   sort: 1
  // },
  {
    name: '工商银行',
    id: '2',
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/d348a6c021741a5bd1616ac4ce55bd83.png',
    hot: '',
    tel: '95588',
    link: 'http://www.icbc.com.cn/icbc/',
    sort: 2
  },
  {
    name: '中信银行',
    id: '3',
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/2ab4f62c0ba00caa58efc20b67599383.png',
    hot: '',
    tel: '95558',
    link: 'http://www.citicbank.com/',
    sort: 3
  },
  {
    name: '上海银行',
    id: '4',
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/52ce87eb298ddbd35db3d4a93a2888c7.png',
    hot: '',
    tel: '95594',
    link: 'http://www.bosc.cn/',
    sort: 4
  },
  // {
  //   name: '华夏银行',
  //   id: '5',
  //   logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/0f420841fdfd99ef336ae39a090f2640.png',
  //   hot: '',
  //   tel: '95577',
  //   link: 'http://www.hxb.com.cn/',
  //   sort: 5
  // }
]

// 信用卡大全
const cardList = [
  // {
  //   name: '浦发信用卡合集',
  //   id: '100001',
  //   hotListId: '1',
  //   hot: '',
  //   desc: '免年费，天天享5折美食',
  //   tip: '',
  //   recommend: true,
  //   logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201905/8578fd916609a5b2ea8a8ece047bd74f.png',
  //   link: 'https://ecentre.spdbccc.com.cn/creditcard/indexActivity.htm?data=ZF2867036&itemcode=0000021390',
  //   sort: 1
  // },
  {
    name: '工商故宫联名蓝金卡',
    id: '100002',
    hotListId: '2',
    hot: '',
    desc: '故宫图书、文创品9折',
    tip: '',
    recommend: false,
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201905/8cfb10ce4eb36e3290caf56fd524dc1a.jpg',
    link: 'https://elife.icbc.com.cn/OFSTCARDWEB/dist/#/apply/detail/460000517/109YQXXYQXX000900000000000',
    sort: 2
  },
  {
    name: '工商故宫联名红金卡',
    id: '100003',
    hotListId: '2',
    hot: '',
    desc: '限时赢故宫迎春礼盒',
    tip: '',
    recommend: false,
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201905/f83b43e8ad4790e072da4435295e9bc5.jpg',
    link: 'https://elife.icbc.com.cn/OFSTCARDWEB/dist/#/apply/detail/460000523/109YQXXYQXX000900000000000',
    sort: 3
  },
  {
    name: '工商宇宙星座金卡',
    id: '100004',
    hotListId: '2',
    hot: '',
    desc: '生日消费10倍积分',
    tip: '',
    recommend: false,
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/01d1496d084ffaa77f9222edb5441141.jpg',
    link: 'https://elife.icbc.com.cn/OFSTCARDWEB/dist/#/apply/detail/460000327/109YQXXYQXX000900000000000',
    sort: 4
  },
  {
    name: '工商小黄人信用卡',
    id: '100005',
    hotListId: '2',
    hot: '',
    desc: '国内首款正版授权，免年费',
    tip: '',
    recommend: false,
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/a83b8055a80d5b5053ca1a01693ce4dc.jpg',
    link: 'https://elife.icbc.com.cn/OFSTCARDWEB/dist/#/apply/detail/460000353/109YQXXYQXX000900000000000',
    sort: 5
  },
  {
    name: '工商爱宠大机密卡',
    id: '100006',
    hotListId: '2',
    hot: '',
    desc: '免年费，有机会得卡面同款抱枕',
    tip: '',
    recommend: false,
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/f574b5aae00c9f917d66121747a3cedb.jpg',
    link: 'https://elife.icbc.com.cn/OFSTCARDWEB/dist/#/apply/detail/460000397/109YQXXYQXX000900000000000',
    sort: 6
  },
  {
    name: '工商信用卡合集',
    id: '100007',
    hotListId: '2',
    hot: '',
    desc: '几十款卡片随心选',
    tip: '',
    recommend: true,
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201907/acff9eb2a92463745582e963f4687287.jpg',
    link: 'https://elife.icbc.com.cn/OFSTCARD/creditCard/apply.do?channel=109YQXXYQXX000900000000000&paraPromoCode=EW000400080526YQ010',
    sort: 7
  },
  {
    name: '中信信用卡合集',
    id: '100008',
    hotListId: '3',
    hot: '',
    desc: '支持个性定制',
    tip: '',
    recommend: true,
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201907/b3f9f2268b59a5fe4dfed2d418a815f7.png',
    link: 'https://creditcard.ecitic.com/h5/shenqing/index.html?sid=SJ51GJA03#/home/popularity',
    sort: 8
  },
  {
    name: '中信i白金信用卡',
    id: '100009',
    hotListId: '3',
    hot: '',
    desc: '免首年年费，交易12次免次年',
    tip: '',
    recommend: false,
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/ec2d59430e57b8d4a54534831b3a1827.jpg',
    link: 'https://cs.creditcard.ecitic.com/citiccard/cardshopcloud/standardcard-h5/index.html?pid=CS0083&cls=SJWAPIBJ01&sid=SJ51GJA03#/baseInfo',
    sort: 9
  },
  {
    name: '中信移动联名卡',
    id: '100010',
    hotListId: '3',
    hot: '',
    desc: '永久免年费',
    tip: '',
    recommend: false,
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/438979ad3ef1598ce5d8e7709d379017.png',
    link: 'https://creditcard.ecitic.com/h5/shenqing/yidong_visa/index.html?cls=SJWAPYDTV02&sid=SJ51GJA03',
    sort: 10
  },
  {
    name: '上海银行VISA金卡',
    id: '100011',
    hotListId: '4',
    hot: '',
    desc: '双币种，享受上海银行红利积分',
    tip: '',
    recommend: true,
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/f3fbd382a4824249f027f79017519a72.jpg',
    link: 'https://mbank.bankofshanghai.com/pweixin/static/index.html?_TransactionId=CreditCardApply&_CardType=0300001391&YLLink=620239',
    sort: 11
  },
  {
    name: '中信中民积分宝卡',
    id: '100015',
    hotListId: '3',
    hot: '',
    desc: '新户刷卡99元享原瓶进口红酒',
    tip: '',
    recommend: false,
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201908/da729e3f9c60db1b9311219a677167fc.png',
    link: 'https://m.zm123.com/ZXCredit/Index?sid=SJUSHY72&pid=CS0484',
    sort: 12
  },
  {
    name: '中信银联标准IC金卡',
    id: '100016',
    hotListId: '3',
    hot: '',
    desc: '中信首张IC芯片卡，刷卡免年费',
    tip: '',
    recommend: false,
    logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201909/fb7c03f67aa2b9f99b9aca2a85ca8a06.jpg',
    link: 'https://m.zm123.com/ZXCredit/Index?sid=SJUSHY72&pid=CS0482',
    sort: 13
  },
  // {
  //   name: '华夏银行信用卡合集',
  //   id: '100012',
  //   hotListId: '5',
  //   hot: '',
  //   desc: '专享福利',
  //   tip: '',
  //   recommend: true,
  //   logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/6053ceb892eda5bf0b75ccfff9040a9b.png',
  //   link: 'https://creditapply.hxb.com.cn/sanfang/cardChoice.html?requestId=649&requestPage=2714',
  //   sort: 12
  // },
  // {
  //   name: '华夏爱奇艺悦看卡',
  //   id: '100013',
  //   hotListId: '5',
  //   hot: '',
  //   desc: '刷卡达标享爱奇艺VIP',
  //   tip: '',
  //   recommend: false,
  //   logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/d67be0755fb683c259924b00a2c7e653.png',
  //   link: 'https://creditapply.hxb.com.cn/sanfang/aiqiyi.html?_locale=zh_CN&requestId=649&requestPage=2714&choiceFrom=cardChoice&channelId=sanfang',
  //   sort: 13
  // },
  // {
  //   name: '华夏虾米音乐联名卡',
  //   id: '100014',
  //   hotListId: '5',
  //   hot: '',
  //   desc: '首刷送12个月虾米音乐SVIP',
  //   tip: '',
  //   recommend: false,
  //   logo: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201906/1fc47e41b2235737e8c5cc553ba9f994.png',
  //   link: 'https://creditapply.hxb.com.cn/hxbank/WSCradapply.do?_locale=zh_CN&ShowCards=0119&cdfrm=LM28&CardName=%E5%8D%8E%E5%A4%8F%E8%99%BE%E7%B1%B3%E9%9F%B3%E4%B9%90%E8%81%94%E5%90%8D%E4%BF%A1%E7%94%A8%E5%8D%A1&CardImg=https://creditapply.hxb.com.cn/images/cardimage/0119/LM28.jpg&requestId=649&requestPage=2714&choiceFrom=cardChoice&channelId=sanfang',
  //   sort: 14
  // }
]
export { hotList, cardList }
