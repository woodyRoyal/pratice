<template>
  <PageView id="hqwy-mescroll"
            type="mescroll"
            :title="$route.query.productName"
            right-txt="客服/帮助"
            @rightClick="rightClickHandle">
    <div v-if="status == 1"
         class="hqwy-check-result">
      <div class="result-icon result-icon-fail"></div>
      <div class="result-txt">
        放款失败
      </div>
      <div class="result-tips">
        <p>{{ loanStatusDesc }}</p>
      </div>
    </div>
    <div v-if="status == 2"
         class="hqwy-check-result">
      <div class="result-icon result-icon-success"></div>
      <div class="result-txt">
        放款成功
      </div>
    </div>
    <div class="hqwy-btns">
      <CommonButton :btn-data="btnData"
                    @click.native="btnClick()"></CommonButton>
    </div>

    <!-- 右上角“客服/帮助” -->
    <HelpCenter ref="helpCenterModule"
                :product-id="productId"
                :product-name="productName"></HelpCenter>
  </PageView>
</template>
<script>
// import utils from "../../util/utils.js"
import CommonButton from "../../components/button/index"
// import LoanCard from '@/components/card/index'
import HelpCenter from '@/components/HelpCenter'

/* eslint-disable eqeqeq */
export default {
  components: {
    // LoanCard,
    HelpCenter,
    CommonButton,
  },
  data () {
    return {
      status: this.$route.query.status, // 1:失败 2：成功
      loanStatusDesc: this.$route.query.loanStatusDesc,//失败原因
      category: this.$route.query.category,
      productName: this.$route.query.productName,
      productId: this.$route.query.productId,
      loanOrderNo: this.$route.query.loanOrderNo,
      orderNo: this.$route.query.orderNo,
      p: this.$route.query.p,
      w: this.$route.query.w,
      btnData: {
        activeFlag: true,
        txt: '',
      },
    }
  },
  beforeRouteLeave (to, from, next) {
    this.$refs.helpCenterModule.hide()
    next()
  },
  activated () {
    let that = this
    let query = that.$route.query
    that.status = query.status
    that.loanStatusDesc = query.loanStatusDesc
    that.category = query.category
    that.productName = query.productName
    that.productId = query.productId
    that.loanOrderNo = query.loanOrderNo
    that.orderNo = query.orderNo
    that.p = query.p
    that.w = query.w
    if (query.status == 1) {
      that.btnData.txt = '重新借款'
      that.eventId = "jkjg;sb;w211"
    } else if (query.status == 2) {
      that.btnData.txt = '确认'
      that.eventId = "jkjg;cg;w210"
    }
  },
  methods: {
    rightClickHandle () {
      this.md50td('bzan;bztc;w236')
      this.$refs.helpCenterModule.show()
    },
    btnClick () {
      let that = this;
      // 点击统计
      that.$appInvoked("appExecStatistic", {
        eventId: this.eventId,
        eventType: 0,
      })

      if (that.status == 1) {
        // 撞库页面
        let loanHitPage = `/loanHit?category=${that.category}&productId=${that.productId}&productName=${that.productName}&p=${that.p}&w=${that.w}`
        that.$routerReplace(loanHitPage)
      } else if (this.status == 2) {
        let commonParams = `orderNo=${that.orderNo}&productName=${that.productName}&productId=${that.productId}&fromapp=${that.$route.query.fromapp}`
        // 订单详情页面
        let orderDetailPage = `/order/detail?${commonParams}&loanOrderNo=${that.loanOrderNo}&category=${that.category}&p=${that.p}&w=${that.w}`;
        this.$routerReplace(orderDetailPage)
      }
    },
    // 武林榜 & TD埋点
    md50td (eventId, type) {
      type = type || 0 // 0或者没有eventType参数代表上传TD和移动武林榜； 1 上传TD； 2 上传移动武林榜；
      if (eventId) {
        this.$appInvoked('appExecStatistic', { eventId: eventId, eventType: type });
      }
    },
    goBackFunc () {
      let that = this;
      let fromapp = that.$route.query.fromapp;
      if (fromapp == 1) {
        that.$appInvoked("appExecBack", {});
      } else {
        that.$routerGo(-1);
      }
    },
  },
}
</script>
<style lang="scss" scoped>
#hqwy-mescroll {
  background-color: #fff;
}
.hqwy-check-result {
  text-align: center;
  padding-top: rc(100);
  .result-icon {
    margin: 0 auto rc(10);
    height: rc(190);
    width: rc(190);
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-position: 0 0;
  }
  .result-icon-fail {
    background-image: url('../../../static/images/#{$APP_NAME}/state_img_fksb.png');
  }
  .result-icon-success {
    background-image: url('../../../static/images/#{$APP_NAME}/state_img_fkcg.png');
  }
  .result-txt {
    margin-top: rc(30);
    font-size: rc(46);
    line-height: rc(65);
    font-weight: bold;
  }
  .result-tips {
    margin-top: rc(8);
    font-size: rc(32);
    line-height: rc(45);
    color: #999;
  }
  .result-stip {
    margin-bottom: rc(20);
    font-size: rc(24);
    line-height: rc(34);
    color: #777;
  }
}

.hqwy-btns {
  margin-top: rc(64);
  padding: 0 rc(30) rc(185);
}
</style>

