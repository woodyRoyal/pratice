<template>
  <PageView id="hqwy-mescroll"
            type="mescroll"
            :title="productName"
            right-txt="客服/帮助"
            @rightClick="rightClickHandle">
    <LoanProcess :process="process"></LoanProcess>
    <HeadInfo type="info-card"
              :icon="productLogo"
              :name="productName"
              :tips="'该产品由' + productName + '提供，最终到账金额和息费解释以对方合同为准'">
      <div class="card-content-infos">
        <LoanCell class="cell-first"
                  title="借款金额"
                  :is-link="actions['loanAmount'].length > 1">
          <div :class="{'bc-unchoose':loanAmount.value == ''}"
               @click="openActionSheet('loanAmount', '请选择借款金额')">
            {{ loanAmount.value
              != "" ? ("&yen; " + loanAmount.value) : "请选择" }}
          </div>
        </LoanCell>
        <LoanCell title="借款期限"
                  :is-link="actions['loanTerm'].length > 1">
          <div :class="{'bc-unchoose':loanTerm.value == ''}"
               @click="openActionSheet('loanTerm', '请选择借款期限')">
            {{ loanTerm.value
              != "" ? loanTerm.value : "请选择" }}
          </div>
        </LoanCell>
        <LoanCell v-if="actions['termNum'].length > 1"
                  title="期数"
                  :is-link="true">
          <div :class="{'bc-unchoose':termNum.value == ''}"
               @click="openActionSheet('termNum', '请选择期数')">
            {{ termNum.value
              != "" ? termNum.value : "请选择" }}
          </div>
        </LoanCell>
        <LoanCell title="借还款银行卡"
                  :is-link="true">
          <div :class="{'bc-unchoose':loanBankCard == ''}"
               @click="clickBankCard()">
            {{ loanBankCard != "" ? loanBankCard
              : "请添加" }}
          </div>
        </LoanCell>
        <LoanCell title="费用与还款计划"
                  :is-link="true">
          <div @click="loanTrailClick()">
            点击查看
          </div>
        </LoanCell>
        <LoanCell title="相关协议"
                  :is-link="true">
          <div @click="checkPtotocol()">
            点击查看
          </div>
        </LoanCell>
        <div class="apply-button">
          <div @click="submitBtn()">
            提交订单
          </div>
        </div>
      </div>
    </HeadInfo>
    <!-- 借款试算弹窗 -->
    <!-- <confirm ref="sureComfirm" title="费用与还款计划" sureTxt="确定" :btnSameColor="false" :closeFlag="false"> -->
    <LoanTrail ref="sureComfirm"
               :loan-amount="loanAmount.key"
               :order-no="orderNo"
               :loan-order-no="loanOrderNo"
               :term="loanTerm.key.split(' ')[0]"
               :term-unit="loanTerm.key.split(' ')[1]"
               :total-period="termNum.key"></LoanTrail>
    <!-- </confirm> -->
    <!--查看贷款相关协议-->
    <LoanActionSheet :loan-action-sheet="loanActionSheet"
                     :close="closeProtocolPopup"
                     @cell-click="goProtocol"></LoanActionSheet>
    <Loading v-show="isLoading"></Loading>
    <ActionSheet :is-show="isShowActionSheet"
                 :action-title="curActionTitle"
                 :action-list="curActionList"
                 @onHideAction="actionSheetHide"
                 @onSelectItem="actionSheetOnSelectItem"></ActionSheet>
    <!-- 更换还款银行卡 -->
    <ActionBank ref="actionBank"
                :action-id="bankCard.cardNo"
                :pd-info="bankCard.pdInfo"
                :action-title="bankCard.actionTitle"
                @on-select="selectBank"></ActionBank>
  </PageView>
</template>
<script>
import ActionSheet from "@/components/action-sheet";
import LoanProcess from './components/process'
// import LoanCard from '@/components/card/index'
import LoanCell from '@/components/cell/index'
// import CommonButton from "../../components/button/index"
import HeadInfo from '@/components/card/headInfo'
import LoanActionSheet from "./components/loanActionSheet"
import Loading from "../../components/loading/loading"
import utils from "../../util/utils"
// import confirm from "../../components/confirm/index"
import LoanTrail from '@/components/loan/loanTrail'
import ActionBank from '@/components/actionBank/ActionBank'

import {
  // 请求获取借款订单号
  requestLoanOrderNoQueryApi,
  // 提交借款信息
  requestSubmitLoanInfoApi,
  // 查询审核结果
  requestApprovalResultApi,
  // 查看协议
  requestApplyLoanProtocolApi,
} from "../../../src/api/controller/loan";
import {
  myselfBankCardApi,
} from '@/api/controller/bankCtr/index'

/* eslint-disable eqeqeq */
export default {
  components: {
    LoanProcess,
    // LoanCard,
    LoanCell,
    ActionSheet,
    HeadInfo,
    LoanActionSheet,
    Loading,
    // confirm,
    LoanTrail,
    ActionBank,
  },
  data () {
    return {
      loanActionSheet: {
        list: [],
        show: false,
        title: "贷款相关协议",
      },

      process: {
        title: '待提交订单',
        tips: '请确认订单金额、期限，并绑定银行卡~',
        process: ['审核', '提交订单', '确认用款', '放款'],
        curIdx: 1,
      },

      // 借款金额
      loanAmount: {
        key: "",
        value: "",
      },
      // 借款期限 期限 + 期限单位
      loanTerm: {
        key: "",
        value: "",
      },
      // 借款期数
      termNum: {
        key: "",
        value: "",
      },

      curActionList: [],
      curActionTitle: "请选择",
      curActionKey: "",
      isShowActionSheet: false,

      isLoading: false,

      bankCard: {
        bankCardName: "",
        cardNo: "",
        pdInfo: {
          productId: "", //产品Id
          applyNo: "", //进件订单编号
          loanNo: "", //借款订单号
          stage: "1", //1：借款阶段 2：还款阶段
        },
        actionTitle: "选择银行卡",
      },

      actions: {
        loanAmount: [],
        loanTerm: [],
        termNum: [],
      },

      productId: "",
      productName: "",
      productLogo: "",

      loanOrderNo: "",
      orderNo: "",
    }
  },

  computed: {
    loanBankCard: function () {
      if (this.bankCard.bankCardName === "" || this.bankCard.bankCardName == null || this.bankCard.cardNo === "" ||
        this.bankCard.cardNo == null) {
        return ""
      }
      return this.bankCard.bankCardName + "(" + this.bankCard.cardNo.substr(-4) + ")"
    },
  },
  beforeRouteLeave (to, from, next) {
    this.cleanAllPopup()
    next()
  },
  // 页面打开的时候调用
  activated () {

    this.orderNo = this.$route.query.orderNo
    this.loanOrderNo = this.$route.query.loanOrderNo
    this.productId = this.$route.query.productId
    this.productName = this.$route.query.productName

    // 配置银行卡信息
    this.bankCard.pdInfo.productId = this.$route.query.productId
    this.bankCard.pdInfo.applyNo = this.orderNo
    this.bankCard.pdInfo.loanNo = this.loanOrderNo
    // this.updateNavigationBar()
    this.cleanAllPopup()
    setTimeout(() => {
      this.requestData()
      this.getBankCard()
    }, 50)
  },
  methods: {
    // 清理所有弹窗
    cleanAllPopup () {
      this.$refs.sureComfirm.hide()
      this.isShowActionSheet = false
      this.loanActionSheet.show = false
      this.$refs.actionBank.hide()
    },
    rightClickHandle () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'bzan;jrbzzx;w235',
        eventType: 0,
      })
      this.cleanAllPopup()
      this.openHelpcenter(235)
    },
    // 选择银行卡
    selectBank (bank) {
      let that = this
      that.bankCard.cardNo = bank.cardNo
      that.bankCard.bankCardName = bank.bankName
    },
    // 格式化期限
    formatTimeNum (value, index) {

      var unitMap = {
        "1": "天",
        "2": "周",
        "3": "个月",
        "4": "年",
      }

      var unitName = unitMap[String(value["unit"])]

      var param = {
        "dictValue": value["times"] + " " + value["unit"],
        "dictName": value["times"] + unitName,
        "dictSort": index,
      }
      return param
    },
    // 格式化期数
    formatTermNum (value, index) {
      var param = {
        "dictValue": value["termNum"],
        "dictName": value["termNum"] + "期",
        "dictSort": index,
      }
      return param
    },
    // 切割借款金额数组
    cutAmount (fromValue, toValue, granularity) {

      if (toValue <= fromValue) {
        return [{
          "dictValue": toValue,
          "dictName": toValue,
          "dictSort": 0,
        }]
      }
      var tempArray = []
      for (var i = fromValue; i < toValue + granularity; i += granularity) {
        var dic = {
          "dictValue": String(i),
          "dictName": String(i),
          "dictSort": tempArray.length,
        }
        tempArray.push(dic)
      }
      return tempArray
    },
    collectSubmitOrderEvent (status) {
      // 客户端埋点
      this.collectEventMD({
        eventId: '10003',
        eventResult: status,
        eventStartTime: new Date().getTime(),
      });
    },
    // 提交订单
    submitBtn () {
      let that = this
      if (that.loanAmount.key == "" || that.loanAmount.key == null) {
        utils.toastMsg("请选择借款金额")
        return
      }

      if (that.loanTerm.key == "" || that.loanTerm.key == null) {
        utils.toastMsg("请选择借款期限")
        return
      }

      if (that.termNum.key == "" || that.termNum.key == null) {
        utils.toastMsg("请选择期数")
        return
      }

      if (that.bankCard.bankCardName == "" || that.bankCard.bankCardName == null) {
        utils.toastMsg("请添加借还款银行卡")
        return
      }
      that.requestLoanOrderNoQueryFunc((loanOrderNo) => {
        var params = {
          "orderNo": that.$route.query.orderNo,
          "bankName": that.bankCard.bankCardName,
          "cardNo": that.bankCard.cardNo,
          "loanAmount": that.loanAmount.key,
          "loanOrderNo": loanOrderNo,
          "term": that.loanTerm.key.split(" ")[0],
          "termUnit": that.loanTerm.key.split(" ")[1],
          "totalPeriod": that.termNum.key,
        }

        that.isLoading = true
        requestSubmitLoanInfoApi(params).then((data) => {
          that.collectSubmitOrderEvent(2)
          that.isLoading = false
          if (data.respCode !== "1000") {
            utils.toastMsg(data.respMsg)
            return
          }
          that.collectSubmitOrderEvent(1)
          that.$routerReplace(
            `/loan/confirmLoan?orderNo=${this.orderNo}&productName=${this.productName}&productId=${this.productId}&loanOrderNo=${this.loanOrderNo}`
          )
        }, (err) => {
          that.isLoading = false
          utils.toastMsg(err.respMsg)
          that.collectSubmitOrderEvent(0)
        })
      })
    },
    requestData () {
      let that = this
      that.isLoading = true
      var params = {
        "orderNo": that.$route.query.orderNo,
      }
      requestApprovalResultApi(params).then(
        (data) => {
          that.isLoading = false
          if (data.respCode !== "1000") {
            utils.toastMsg(data.respMsg)
            return
          }
          data = data.body

          that.actions["loanAmount"] = that.cutAmount(data.loanAmountMin, data.creditLineSurplus, data.granularity)
          that.actions["loanTerm"] = data.loanTermList.map(this.formatTimeNum)
          that.actions["termNum"] = data.loanTermList.map(this.formatTermNum)
          this.productName = data.productName
          this.productLogo = data.productLogo

          if (that.actions["loanTerm"].length <= 1) {
            that.loanTerm.value = that.actions["loanTerm"][0]["dictName"]
            that.loanTerm.key = that.actions["loanTerm"][0]["dictValue"]
          }

          if (that.actions["termNum"].length <= 1) {
            that.termNum.value = that.actions["termNum"][0]["dictName"]
            that.termNum.key = that.actions["termNum"][0]["dictValue"]
          }

          if (that.actions["loanAmount"].length <= 1) {
            that.loanAmount.value = that.actions["loanAmount"][0]["dictName"]
            that.loanAmount.key = that.actions["loanAmount"][0]["dictValue"]
          }
        },
        () => {
          that.isLoading = false
        }
      )

      // setTimeout(() => {
      //   that.isLoading = false
      // }, 20000)
    },
    openActionSheet: function (key, title) {

      this.cleanAllPopup()
      this.curActionKey = key
      this.curActionList = this.actions[key]

      if (this.curActionList.length > 1) {
        this.isShowActionSheet = true
        this.curActionTitle = title
      }
    },
    actionSheetOnSelectItem: function (item, index) {
      this.isShowActionSheet = false;

      if (this.curActionKey === "loanAmount") {
        this.loanAmount.value = this.curActionList[index]["dictName"]
        this.loanAmount.key = this.curActionList[index]["dictValue"]
      } else if (this.curActionKey === "loanTerm") {
        this.loanTerm.value = this.curActionList[index]["dictName"]
        this.loanTerm.key = this.curActionList[index]["dictValue"]
      } else if (this.curActionKey === "termNum") {
        this.termNum.value = this.curActionList[index]["dictName"]
        this.termNum.key = this.curActionList[index]["dictValue"]
      }
    },
    actionSheetHide: function () {
      this.isShowActionSheet = false;
    },

    // 查询银行卡点击
    clickBankCard () {
      this.cleanAllPopup()
      this.$refs.actionBank.show()
    },
    // 关闭协议弹框
    closeProtocolPopup () {
      this.loanActionSheet.show = false;
    },
    // 跳转到协议详情
    goProtocol (url, title) {
      this.closeProtocolPopup()
      this.$appInvoked("appOpenWebview", {
        url: url,
        nav: {
          title: {
            text: title,
          },
        },
      })
    },
    // 查看协议
    checkPtotocol () {

      this.cleanAllPopup()
      this.isLoading = true
      this.requestLoanOrderNoQueryFunc((loanOrderNo) => {
        // 请求协议
        var param = {
          "applyNo": this.orderNo,
          "loanNo": loanOrderNo,
          "type": "3",
          "productId": this.productId,
        }

        requestApplyLoanProtocolApi(param).then(
          (data) => {
            this.isLoading = false;
            if (data.respCode !== "1000") {
              utils.toastMsg(data.respMsg);
              return;
            }

            this.loanActionSheet.list = data.body
            this.loanActionSheet.show = true
          },
          () => {
            this.isLoading = false;
          }
        );
      })
    },
    loanTrailClick () {
      this.cleanAllPopup()
      this.requestLoanOrderNoQueryFunc(() => {
        this.$refs.sureComfirm.show()
      })
    },
    // 获取借款订单号
    requestLoanOrderNoQueryFunc (cb) {
      let that = this
      if (that.loanOrderNo && that.loanOrderNo != 'null') {
        return cb && cb(that.loanOrderNo)
      }
      that.isLoading = true
      requestLoanOrderNoQueryApi({
        orderNo: that.$route.query.orderNo,
      }).then((data) => {
        that.isLoading = false
        that.loanOrderNo = data.body.loanOrderNo
        that.bankCard.pdInfo.loanNo = data.body.loanOrderNo
        cb && cb(data.body.loanOrderNo)
      }, () => {
        that.isLoading = false
      })
    },
    // 获取借还款银行卡
    getBankCard () {
      let that = this
      that.requestLoanOrderNoQueryFunc((loanOrderNo) => {
        that.isLoading = true
        myselfBankCardApi({
          canUseFlow: 1,
          loanOrderNo: loanOrderNo,
        }).then((data) => {
          that.isLoading = false
          let bankCard = data.body.myBankCardList[0]
          if (bankCard) {
            that.bankCard.bankCardName = bankCard.bankName
            that.bankCard.cardNo = bankCard.cardNo
          }
        }, () => {
          that.isLoading = false
        })
      })
    },
  },
}

</script>
<style lang="scss" scoped>
.bc-hidden {
  display: none;
}

.apply-button {
  height: rc(96);
  line-height: rc(96);
  text-align: center;
  background: #f2f2f2;
  margin: rc(60) rc(45) rc(0);
  border-radius: rc(100);
  color: white;
  background-image: linear-gradient(90deg, #ff5b00 0%, #ff8f00 100%);
  font-size: rc(34);
}

.cell-first {
  margin-top: rc(10);
}

.hc-tips {
  font-family: PingFangSC-Regular;
  font-size: rc(26);
  font-weight: normal;
  font-stretch: normal;
  letter-spacing: 0px;
  color: #ff601a;
  margin: rc(21) rc(32) rc(46);
}

.bc-unchoose {
  font-family: PingFangSC-Regular;
  font-size: rc(30);
  font-weight: normal;
  font-stretch: normal;
  letter-spacing: 0px;
  color: #aaaaaa;
}

.card-content-infos {
  padding-bottom: rc(70);
}
</style>
