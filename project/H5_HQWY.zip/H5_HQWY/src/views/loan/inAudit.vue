<template>
  <PageView id="hqwy-mescroll"
            type="mescroll"
            :title="productName"
            right-txt="客服/帮助"
            @rightClick="rightClickHandle">
    <LoanProcess :process="process"></LoanProcess>
    <HeadInfo type="info-card"
              :icon="productLogo"
              :name="productName"
              :tips="'该产品由' + productName + '提供，最终到账金额和息费解释以对方合同为准'">
      <div class="card-content-infos">
        <LoanCell title="申请额度"
                  :is-link="false">
          {{ applyLine != "" ? "&yen; " + applyLine : "" }}
        </LoanCell>
        <LoanCell title="期限"
                  :is-link="false">
          {{ term }}
        </LoanCell>
        <LoanCell title="申请时间"
                  :is-link="false">
          {{ applyDate }}
        </LoanCell>
        <LoanCell title="相关协议">
          <div @click="checkPtotocol()">
            点击查看
          </div>
        </LoanCell>
        <p class="bc-tips">
          提示: 审核结果会及时通知您, 您也可以随时在“
          <span class="bc-focus-tips">我的订单</span>”里查询申请结果
        </p>
        <div class="apply-button">
          <div @click="submitBtn()">
            申请其他产品
          </div>
        </div>
      </div>
    </HeadInfo>
    <Loading v-show="isLoading"></Loading>
    <!--查看贷款相关协议-->
    <LoanActionSheet :loan-action-sheet="loanActionSheet"
                     :close="closeProtocolPopup"
                     @cell-click="goProtocol"></LoanActionSheet>
  </PageView>
</template>
<script>
// import LoanCard from '@/components/card/index'
import HeadInfo from '@/components/card/headInfo'
import LoanCell from '@/components/cell/index'
import LoanProcess from "./components/process"
// import CommonButton from "../../components/button/index"
import Loading from "../../components/loading/loading"
import utils from "../../util/utils"
import LoanActionSheet from "./components/loanActionSheet"
import {
  queryRecentOrderApi,
} from '../../../src/api/controller/product'

import {
  // 请求获取借款订单号
  // requestLoanOrderNoQueryApi,
  // 获取协议
  requestApplyLoanProtocolApi,
} from "../../../src/api/controller/loan";

export default {
  components: {
    LoanProcess,
    Loading,
    // LoanCard,
    HeadInfo,
    LoanCell,
    // Loading,
    LoanActionSheet,
  },
  data () {
    return {
      loanActionSheet: {
        list: [],
        show: false,
        title: "贷款相关协议",
      },
      process: {
        title: "审核中",
        tips: "",
        process: ["审核", "提交订单", "确认用款", "放款"],
        curIdx: 0,
      },
      // 借款期限
      term: "",
      // 申请时间
      applyDate: "",
      // 申请额度
      applyLine: "",
      // 订单 id
      orderNo: "1234567",
      show: {
        protocolPopupShow: false,
      },

      productName: "",
      productId: "",
      productLogo: "",

      isLoading: false,

      loanOrderNo: "",
    };
  },
  beforeRouteLeave (to, from, next) {
    this.cleanAllPopup()
    next()
  },
  // 页面开启的时候调用
  activated () {
    this.productId = this.$route.query.productId || ""
    this.productName = this.$route.query.productName || ""

    // this.updateNavigationBar()
    this.cleanAllPopup()
    setTimeout(() => {
      this.requestData()
    }, 50)
  },
  methods: {
    rightClickHandle () {
      let that = this
      that.loanActionSheet.show = false
      that.$appInvoked('appExecStatistic', {
        eventId: 'bzan;jrbzzx;w235',
        eventType: 0,
      })
      that.cleanAllPopup()
      that.openHelpcenter(235)
    },
    cleanAllPopup () {
      this.loanActionSheet.show = false
    },
    // 查看协议
    checkPtotocol () {

      this.cleanAllPopup()
      this.isLoading = true;

      // 请求协议
      var param = {
        applyNo: this.$route.query.orderNo,
        loanNo: this.$route.query.loanOrderNo,
        type: 1,
        productId: this.productId,
      };

      requestApplyLoanProtocolApi(param).then(
        (data) => {
          // console.log(data);
          this.isLoading = false;
          if (data.respCode !== "1000") {
            utils.toastMsg(data.respMsg);
            return;
          }

          data = data.body
          this.loanActionSheet.list = data;
          this.loanActionSheet.show = true;

        },
        () => {
          this.isLoading = false;
        }
      );
    },
    // 关闭协议弹框
    closeProtocolPopup () {
      this.loanActionSheet.show = false;
    },
    submitBtn () {
      this.$routerPush(`/productlist`)
    },
    requestData () {

      let params = {
        "productId": this.$route.query.productId,
      }

      this.isLoading = true
      queryRecentOrderApi(params).then(
        (data) => {
          this.isLoading = false
          if (data.respCode !== "1000") {
            utils.toastMsg(data.respMsg)
            return
          }
          data = data.body

          // this.applyDate = this.formatDateTime(data.applyTime)
          this.applyDate = utils.formateDate(Number(data.applyTime), 'YYYY-MM-DD hh:mm')
          this.term = data.productLimit
          this.applyLine = data.productAmount
          this.process.tips = data.approvalPageRemind
          // this.process.tips = '预计15分钟完成审核' || data.approvalPageRemind
          this.productName = data.productName
          this.productLogo = data.productLogo
        },
        () => {
          this.isLoading = false
        }
      )

      // setTimeout(() => {
      //   this.isLoading = false
      // }, 20000)
    },
    // 跳转到协议详情
    goProtocol (url, title) {
      this.closeProtocolPopup()
      this.$appInvoked("appOpenWebview", {
        url: url,
        nav: {
          title: {
            text: title,
          },
        },
      })
    },
  },
};

</script>
<style lang="scss" scoped>
.apply-button {
  height: rc(96);
  line-height: rc(96);
  text-align: center;
  background: #f2f2f2;
  margin: rc(0) rc(45) rc(0);
  border-radius: rc(100);
  color: white;
  background-image: linear-gradient(90deg, #ff5b00 0%, #ff8f00 100%);
  font-size: rc(34);
}

.bc-tips {
  font-family: PingFangSC-Regular;
  font-size: rc(24);
  font-weight: normal;
  font-stretch: normal;
  letter-spacing: 0px;
  color: #999999;
  margin: rc(21) rc(32) rc(46);
}

.bc-focus-tips {
  color: #ff601a;
}

.card-content-infos {
  padding-bottom: rc(70);
}
</style>
