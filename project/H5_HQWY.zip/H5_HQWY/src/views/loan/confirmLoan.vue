<template>
  <PageView id="hqwy-mescroll"
            type="mescroll"
            :title="productName"
            right-txt="客服/帮助"
            @rightClick="rightClickHandle">
    <LoanProcess :process="process"></LoanProcess>
    <HeadInfo type="info-card"
              :icon="productLogo"
              :name="productName"
              :tips="'该产品由' + productName + '提供，最终到账金额和息费解释以对方合同为准'">
      <div class="card-content-infos">
        <LoanCell title="借款金额"
                  :is-link="false">
          {{ loanAmount == "" ? loanAmount : "&yen; " + loanAmount }}
        </LoanCell>
        <LoanCell title="借款期限"
                  :is-link="false">
          {{ term }}{{ termUnit | unitName }}
        </LoanCell>
        <LoanCell title="借还款银行卡"
                  :is-link="false">
          {{ loanBankCard }}
        </LoanCell>
        <LoanCell title="到账金额"
                  :is-link="false">
          {{ receiveAmount == "" ? receiveAmount : "&yen; " + receiveAmount }}
        </LoanCell>
        <LoanCell title="相关协议">
          <div @click="checkPtotocol()">
            点击查看
          </div>
        </LoanCell>
        <p class="hc-tips"
           v-html="remind"></p>
        <div class="apply-button">
          <div @click="submitBtn('qryk;qr;w209')">
            确定
          </div>
        </div>
      </div>
    </HeadInfo>
    <!--查看贷款相关协议-->
    <LoanActionSheet :loan-action-sheet="loanActionSheet"
                     :close="closeProtocolPopup"
                     @cell-click="goProtocol">
    </LoanActionSheet>
    <Loading v-show="isLoading"></Loading>
  </PageView>
</template>
<script>
import HeadInfo from '@/components/card/headInfo'
import LoanProcess from './components/process'
// import LoanCard from '@/components/card/index'
import LoanCell from '@/components/cell/index'
// import CommonButton from "../../components/button/index"
import LoanActionSheet from "./components/loanActionSheet"
import Loading from "../../components/loading/loading"
import utils from "../../util/utils"

import {
  requestSubmitLoanApplyApi,
  requestLoanApplyInfoApi,
  // 查看协议
  requestApplyLoanProtocolApi,
} from "../../../src/api/controller/loan"

export default {
  components: {
    LoanProcess,
    // LoanCard,
    LoanCell,
    LoanActionSheet,
    Loading,
    HeadInfo,
  },
  filters: {
    unitName (value) {
      var unitMap = {
        "1": "天",
        "2": "周",
        "3": "个月",
        "4": "年",
      }
      return unitMap[String(value)]
    },
  },
  data () {
    return {
      loanActionSheet: {
        list: [],
        show: false,
        title: "贷款相关协议",
      },
      process: {
        title: '待确认用款',
        tips: '请完成用款确认，确认后才能放款哦~',
        process: ['审核', '提交订单', '确认用款', '放款'],
        curIdx: 2,
      },

      loanAmount: "",
      totalPeriod: "",
      cardNo: "",
      bankName: "",
      term: "",
      termUnit: "",
      receiveAmount: "",
      remind: "",

      isLoading: false,

      productName: "",
      productId: "",
      productLogo: "",

      orderNo: "",
      loanOrderNo: "",

    }
  },
  computed: {
    loanBankCard: function () {
      if (this.bankName === "" ||
        this.bankName == null ||
        this.cardNo === "" ||
        this.cardNo == null) {
        return ""
      }
      return this.bankName + "(" + this.cardNo.substr(-4) + ")"
    },
  },
  beforeRouteLeave (to, from, next) {
    this.cleanAllPopup()
    next()
  },
  activated () {
    this.productId = this.$route.query.productId
    this.productName = this.$route.query.productName
    this.productLogo = this.$route.query.productLogo
    this.orderNo = this.$route.query.orderNo
    this.loanOrderNo = this.$route.query.loanOrderNo

    this.cleanAllPopup()
    // this.updateNavigationBar()
    window.openThirdUrl = this.openThirdUrl
    setTimeout(() => {
      this.requestData()
    }, 50)
  },
  methods: {
    rightClickHandle () {
      let that = this
      that.$appInvoked('appExecStatistic', {
        eventId: 'bzan;jrbzzx;w235',
        eventType: 0,
      })
      that.cleanAllPopup()
      that.openHelpcenter(235)
    },
    // 客户端埋点
    collectConfirmLoanEvent (status) {
      this.collectEventMD({
        eventId: '10004',
        eventResult: status,
        eventStartTime: new Date().getTime(),
      });
    },
    cleanAllPopup () {
      this.loanActionSheet.show = false
    },
    requestData () {

      this.isLoading = true

      var params = {
        "loanOrderNo": this.loanOrderNo,
        "orderNo": this.orderNo,
      }
      requestLoanApplyInfoApi(params).then(
        (data) => {
          this.isLoading = false
          if (data.respCode !== "1000") {
            utils.toastMsg(data.respMsg)
            return
          }
          data = data.body
          this.loanAmount = data.loanAmount
          this.bankName = data.bankName
          this.cardNo = data.cardNo
          this.receiveAmount = data.receiveAmount
          this.term = data.term
          this.termUnit = data.termUnit
          this.totalPeriod = data.totalPeriod
          this.remind = this.matchRemind(data.remind)
          this.productName = data.productName
          this.productLogo = data.productLogo
        },
        (err) => {
          this.isLoading = false
          utils.toastMsg(err.respMsg)
        }
      )
      // setTimeout(() => {
      //   this.isLoading = false
      // }, 20000)
    },
    // 查看协议
    checkPtotocol () {

      this.cleanAllPopup()

      this.isLoading = true;

      // 请求协议
      var param = {
        "applyNo": this.orderNo,
        "loanNo": this.loanOrderNo,
        "type": "3",
        "productId": this.productId,
      };

      requestApplyLoanProtocolApi(param).then(
        (data) => {
          this.isLoading = false;
          if (data.respCode !== "1000") {
            utils.toastMsg(data.respMsg);
            return;
          }
          data = data.body
          this.loanActionSheet.list = data
          this.loanActionSheet.show = true
        },
        () => {
          this.isLoading = false;

        }
      );
    },
    // 跳转到协议详情
    goProtocol (url, title) {
      this.closeProtocolPopup()
      this.$appInvoked("appOpenWebview", {
        url: url,
        nav: {
          title: {
            text: title,
          },
        },
      })
    },
    // 关闭协议弹框
    closeProtocolPopup () {
      // console.log("协议关闭按钮点击")
      this.loanActionSheet.show = false;
    },
    submitBtn (eventid) {
      //   埋点统计
      this.$appInvoked("appExecStatistic", {
        eventId: eventid,
        eventType: 0,
      })
      this.isLoading = true

      var param = {
        "bankName": this.bankName,
        "cardNo": this.cardNo,
        "loanAmount": this.loanAmount,
        "loanOrderNo": this.loanOrderNo,
        "orderNo": this.orderNo,
        "term": this.term,
        "termUnit": this.termUnit,
        "totalPeriod": this.totalPeriod,
      }
      requestSubmitLoanApplyApi(param).then(
        (data) => {
          this.isLoading = false
          if (data.respCode !== "1000") {
            this.collectConfirmLoanEvent(2)
            utils.toastMsg(data.respMsg)
            return
          }
          this.collectConfirmLoanEvent(1)
          this.$routerReplace(
            `/loan/onLoan?orderNo=${this.orderNo}&productName=${this.productName}&productId=${this.productId}&loanOrderNo=${this.loanOrderNo}`
          )
        },
        () => {
          this.isLoading = false
          this.collectConfirmLoanEvent(0)
        }
      )
    },
    // 格式化提示文言，匹配网址
    matchRemind (remind) {
      if (remind) {
        let reg = /((http)s?:\/\/)([0-9a-z.]+)(:[0-9]+)?([/0-9a-z.]+)?(\?[0-9a-z&=]+)?(#[0-9-a-z]+)?/ig
        let result = remind.match(reg)
        if (result && result.length > 0) {
          for (let i = 0; i < result.length; i++) {
            remind = remind.replace(result[i], `<span onClick="openThirdUrl('${result[i]}')">${result[i]}</span>`)
          }
        }
        return remind
      }
      return ''
    },
    // 打开url
    openThirdUrl (url) {
      let that = this
      that.$appInvoked("appOpenWebview", {
        url: url,
        nav: {
          title: {
            text: that.productName,
          },
        },
      })
    },
  },
}

</script>
<style lang="scss" scoped>
.apply-button {
  height: rc(96);
  line-height: rc(96);
  text-align: center;
  background: #f2f2f2;
  margin: rc(0) rc(45) rc(0);
  border-radius: rc(100);
  color: white;
  background-image: linear-gradient(90deg, #ff5b00 0%, #ff8f00 100%);
  font-size: rc(34);
}

.hc-tips {
  font-family: PingFangSC-Regular;
  font-size: rc(26);
  font-weight: normal;
  font-stretch: normal;
  letter-spacing: 0px;
  color: #ff601a;
  margin: rc(21) rc(32) rc(46);
  word-break: break-all;
}

.card-content-infos {
  padding-bottom: rc(70);
}
</style>
