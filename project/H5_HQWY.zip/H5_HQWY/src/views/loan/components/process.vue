<template>
  <div class="loan-process">
    <div class="lp-title"
         v-text="process.title"></div>
    <div class="lp-tips"
         v-text="process.tips"></div>
    <div class="lp-process-tab">
      <ul class="lp-process lp-process-icon">
        <li v-for="(item, index) in process.process"
            :key="index"
            class="lp-process-item"
            :class="{'cur': index === process.curIdx, 'finished': process.curIdx > index}">
          <div class="icon"></div>
        </li>
      </ul>
      <ul class="lp-process lp-process-text">
        <li v-for="(item, index) in process.process"
            :key="index"
            class="lp-process-item"
            v-text="item"></li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Process',
  props: {
    process: {
      type: Object,
      default: () => ({}),
    },
  },
  // data () {
  //   return {}
  // },
}
</script>
<style lang="scss" scoped>
.loan-process {
  box-sizing: border-box;
  min-height: rc(450);
  padding-bottom: rc(142);
  background-image: linear-gradient(83deg, #ff7523 0%, #ffbd74 100%);
  color: #fff;
  .lp-title {
    text-align: center;
    height: rc(84);
    line-height: rc(84);
    font-size: rc(60);
    font-weight: bold;
    padding: rc(53 30 13);
  }
  .lp-tips {
    text-align: center;
    min-height: rc(45);
    line-height: rc(45);
    font-size: rc(30);
    margin-bottom: rc(39);
    padding: rc(0 30);
  }
  .lp-process-tab {
    height: rc(74);
  }
  .lp-process {
    display: flex;
    align-items: center;
    justify-content: center;
    .lp-process-item {
      flex: 1;
      position: relative;
      text-align: center;
    }
    &.lp-process-icon {
      height: rc(30);
      margin-bottom: rc(7);
      .lp-process-item {
        &::before,
        &::after {
          content: '';
          position: absolute;
          top: 50%;
          margin-top: -1px;
          width: 28.6%;
          height: 1px;
          background-color: #feddbb;
        }
        &::before {
          left: 0;
        }
        &::after {
          right: 0;
        }
        &:first-child {
          &:before {
            width: 0;
          }
          &.cur {
            &:before {
              width: 0;
            }
          }
        }
        &:last-child {
          &:after {
            width: 0;
          }
          &.cur {
            &:after {
              width: 0;
            }
          }
        }
        .icon {
          margin: 0 auto;
          width: rc(30);
          height: rc(32);
          background-image: url('../../../../static/images/order_progressbar3.png');
          background-repeat: no-repeat;
          background-size: rc(30 30);
          background-position: center;
        }
        &.cur {
          .icon {
            background-image: url('../../../../static/images/order_progressbar2.png');
          }
        }
        &.finished {
          .icon {
            background-image: url('../../../../static/images/order_progressbar1.png');
          }
        }
      }
    }
    .lp-process-text {
      font-size: rc(26);
      line-height: rc(37);
    }
  }
}
</style>


