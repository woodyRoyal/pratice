<template>
  <div v-show="loanActionSheet.show"
       class="cover">
    <div class="hy-confirm-mask"
         @click="closePopup()"></div>
    <div class="hy-confirm-content actionsheet-anim-up">
      <div class="display-flex popup-header bb-1px bg-color-fff">
        <div @click="closePopup">
          <i class="popup-close flex-2"></i>
        </div>
        <div class="popup-title flex-2 font-bold">
          {{ loanActionSheet.title }}
        </div>
      </div>
      <ul v-if="loanActionSheet.list.length>0"
          class="popup-list bg-color-fff">
        <li v-for="(item, index) in loanActionSheet.list"
            :key="index"
            class="bb-1px"
            @click="clickCell(item.agreeUrl, item.agreeName)">
          <div class="display-flex">
            <div class="flex-2">
              {{ item.agreeName }}
            </div>
            <div>
              <img class="arrow"
                   src="../../../../static/images/arrow.png"
                   alt>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
// import {
//   PopupPicker,
//   TransferDom,
//   Popup,
// } from "vux"

export default {
  name: 'LoanActionSheet',
  // components: {
  //   Popup,
  //   TransferDom,
  //   PopupPicker,
  // },
  props: {
    loanActionSheet: {
      type: Object,
      default: () => ({}),
    },
    close: {
      type: Function,
      default: null,
    },
    click: {
      type: Function,
      default: null,
    },
  },
  // data () {
  //   return {}
  // },
  methods: {
    closePopup () {
      this.close()
    },
    clickCell (agreeUrl, agreeName) {
      this.$emit('cell-click', agreeUrl, agreeName)
    },
  },
}

</script>
<style lang="scss" scoped>
.cover {
  z-index: 999;
  width: 100%;
  height: 100%;
  bottom: 0;
  position: fixed;
}

.hy-confirm-mask {
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 1;
}

.hy-confirm-content {
  .popup-title {
    text-align: center;
    font-size: rc(30);
  }

  .popup-header {
    /*display: inline;*/
    height: rc(96);
    line-height: rc(96);
    padding-left: 0;
    padding-right: rc(96);
  }

  .popup-close {
    background: url(../../../../static/images/ic_btn_dialog_close.png) no-repeat center center;
    background-size: rc(25 25);
    display: inline-block;
    width: rc(96);
    height: 100%;
  }
}

.font-bold {
  font-weight: bold;
}

.popup-list {
  li {
    padding: rc(0) rc(36);
  }
}

.arrow {
  width: rc(13);
  height: rc(24);
}

ul > li {
  min-height: rc(96);
  // border-bottom: solid rc(1) #eee;
  line-height: rc(96);
  font-size: rc(30);
}

ul > li:last-child {
  border-bottom: none;
}

.hy-confirm-content {
  -webkit-overflow-scrolling: touch;
  // -webkit-animation-fill-mode: both;
  // animation-fill-mode: both;
  -webkit-animation-duration: 0.2s;
  animation-duration: 0.2s;
  z-index: 2;
  width: 100%;
  bottom: 0;
  position: absolute;
}

@keyframes actionsheet-anim-up {
  0% {
    opacity: 0;
    -webkit-transform: translateY(800px);
    transform: translateY(800px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    transform: translateY(0);
  }
}

.actionsheet-anim-up {
  -webkit-animation-name: actionsheet-anim-up;
  animation-name: actionsheet-anim-up;
}
</style>
