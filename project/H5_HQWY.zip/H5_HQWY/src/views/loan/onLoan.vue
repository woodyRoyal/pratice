<template>
  <PageView id="hqwy-mescroll"
            type="mescroll onLoan"
            :title="productName"
            right-txt="客服/帮助"
            @rightClick="rightClickHandle">
    <LoanProcess :process="process"></LoanProcess>
    <HeadInfo type="info-card"
              :icon="productLogo"
              :name="productName"
              :tips="'该产品由' + productName + '提供，最终到账金额和息费解释以对方合同为准'">
      <div class="card-content-infos">
        <LoanCell class="cell-first"
                  title="借款金额"
                  :is-link="false">
          <div>&yen;{{ loanAmount }}</div>
        </LoanCell>
        <LoanCell title="借款期限"
                  :is-link="false">
          <div>{{ term }}{{ termUnit | unitName }}</div>
        </LoanCell>
        <LoanCell title="借还款银行卡"
                  :is-link="false">
          <div>{{ bankCard }}</div>
        </LoanCell>
        <LoanCell title="相关协议">
          <div @click="checkPtotocol()">
            点击查看
          </div>
        </LoanCell>
      </div>
    </HeadInfo>
    <!--查看贷款相关协议-->
    <LoanActionSheet :loan-action-sheet="loanActionSheet"
                     :close="closeProtocolPopup"
                     @cell-click="goProtocol"></LoanActionSheet>
    <Loading v-show="isLoading"></Loading>
    <!-- 右上角“客服/帮助” -->
    <HelpCenter ref="helpCenterModule"
                :product-id="productId"
                :product-name="productName"></HelpCenter>
  </PageView>
</template>
<script>

// import LoanCard from '@/components/card/index'
import HeadInfo from '@/components/card/headInfo'
import LoanCell from '@/components/cell/index'
import LoanProcess from "./components/process"
// import CommonButton from "../../components/button/index"
import Loading from "../../components/loading/loading"
// import utils from "../../util/utils"
import LoanActionSheet from "./components/loanActionSheet"
import HelpCenter from '@/components/HelpCenter'

import {
  requestLoanResultQueryApi,
  requestApplyLoanProtocolApi,
} from "../../../src/api/controller/loan";

export default {
  components: {
    LoanProcess,
    Loading,
    // LoanCard,
    HeadInfo,
    LoanCell,
    // Loading,
    LoanActionSheet,
    HelpCenter,
  },

  filters: {
    unitName (value) {
      var unitMap = {
        "1": "天",
        "2": "周",
        "3": "个月",
        "4": "年",
      }
      return unitMap[String(value)]
    },
  },
  data () {
    return {
      loanActionSheet: {
        list: [],
        show: false,
        title: "贷款相关协议",
      },
      process: {
        title: '放款中',
        tips: '系统放款中，预计需要几分钟到账~',
        process: ['审核', '提交订单', '确认用款', '放款'],
        curIdx: 3,
      },
      loanAmount: "",
      term: "",
      termUnit: "",
      bankCard: "",
      protocols: "",
      show: {
        protocolPopupShow: false,
      },

      isLoading: false,

      productName: "",
      productId: "",
      productLogo: "",
    }
  },
  beforeRouteLeave (to, from, next) {
    this.$refs.helpCenterModule.hide()
    this.loanActionSheet.show = false
    next()
  },
  // 页面打开的时候调用
  activated () {
    this.productName = this.$route.query.productName
    this.productId = this.$route.query.productId
    this.productLogo = this.$route.query.productLogo
    this.orderNo = this.$route.query.orderNo
    this.loanOrderNo = this.$route.query.loanOrderNo

    setTimeout(() => {
      this.requestData()
    }, 50)
  },
  methods: {
    rightClickHandle () {
      this.loanActionSheet.show = false
      this.md50td('bzan;jrbzzx;w235')
      this.openHelpcenter(235)
    },
    // 跳转到协议详情
    goProtocol (url, title) {
      this.closeProtocolPopup()
      this.$appInvoked("appOpenWebview", {
        url: url,
        nav: {
          title: {
            text: title,
          },
        },
      })
    },
    // 武林榜 & TD埋点
    md50td (eventId, type) {
      type = type || 0 // 0或者没有eventType参数代表上传TD和移动武林榜； 1 上传TD； 2 上传移动武林榜；
      if (eventId) {
        this.$appInvoked('appExecStatistic', { eventId: eventId, eventType: type });
      }
    },
    // 关闭协议弹框
    closeProtocolPopup () {
      this.loanActionSheet.show = false;
    },
    // 查看协议
    checkPtotocol () {
      this.isLoading = true;

      // 请求协议
      var param = {
        "applyNo": this.orderNo,
        "loanNo": this.loanOrderNo,
        "type": "3",
        "productId": this.productId,
      };

      requestApplyLoanProtocolApi(param).then(
        (data) => {
          this.isLoading = false;
          this.loanActionSheet.list = data.body
          this.loanActionSheet.show = true
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    requestData () {
      let params = {
        "orderNo": this.orderNo,
        "loanOrderNo": this.loanOrderNo,
      }

      this.isLoading = true
      requestLoanResultQueryApi(params).then(
        (data) => {
          this.isLoading = false

          let body = data.body

          this.loanAmount = body.loanAmount;
          if (body.cardNo && body.cardNo.length > 4) {
            let cardNo = body.cardNo.substr(body.cardNo.length - 4, 4);
            this.bankCard = body.bankName + "(" + cardNo + ")";
          }

          this.term = body.term
          this.termUnit = body.termUnit
          this.totalPeriod = body.totalPeriod

          this.productName = body.productName
          this.productLogo = body.productLogo
        },
        () => {
          this.isLoading = false
        }
      )

      // setTimeout(() => {
      //   this.isLoading = false
      // }, 20000)
    },
  },
}
</script>
<style lang="scss" scoped>
.card-head-infos {
  padding: rc(40 30);
  display: flex;
  align-items: flex-start;
  .chi-left {
    width: rc(80);
    height: rc(80);
    border-radius: rc(12);
    border: solid 1px #e6e6e6;
    margin-right: rc(30);
  }
  .chi-right {
    flex: 1;
  }
  .chir-title {
    font-size: rc(30);
    line-height: rc(42);
    font-weight: bold;
    color: #111111;
  }
  .chir-tips {
    margin-top: rc(7);
    font-size: rc(24);
    line-height: rc(33);
    color: #999;
  }
}
.split-dotted-half-circle {
  height: 1px;
  border-bottom: 1px dotted #e5e5e5;
  margin: rc(0 30);
  position: relative;
  &::before,
  &::after {
    content: '';
    position: absolute;
    width: rc(10);
    height: rc(20);
    top: 50%;
    transform: translateY(-50%);
    background-color: #f2f2f2;
  }
  &::before {
    left: rc(-30);
    border-radius: rc(0 20 20 0);
  }
  &::after {
    right: rc(-30);
    border-radius: rc(20 0 0 20);
  }
}

.popup-list {
  li {
    padding: rc(0) rc(36);
  }
}
.arrow {
  width: rc(13);
  height: rc(24);
}

ul > li {
  min-height: rc(96);
  border-bottom: solid rc(1) #eee;
  line-height: rc(96);
  font-size: rc(30);
}
ul > li:last-child {
  border-bottom: none;
}
</style>

<style lang="scss">
//todo wyg 这里去除最后一行的分割线
// .onLoan .cell-last.hy-1px-b::after {
//   border-bottom: 0;
// }
</style>
