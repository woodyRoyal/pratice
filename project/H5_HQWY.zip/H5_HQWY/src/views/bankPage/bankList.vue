<template>
  <PageView title="我的银行卡"
            :show-error-page="showErrorPage"
            :error-page-info="errorPageInfo">
    <div class="wrap">
      <ul v-if="userBankCard && userBankCard.length > 0"
          class="bankCardList">
        <li v-for="(item, index) in userBankCard"
            :key="index">
          <div class="bankTop"
               :style="`backgroundColor: ${bankLogoFun(item.bankCode).bg}`">
            <span class="bankIcon"><img :src="require(`../../assets/images/${bankLogoFun(item.bankCode).logo}`)" /></span>
            <aside class="bankMsg">
              <h4>{{ item.bankName }}</h4>
              <span>{{ item.cardMode == 1 ? '储蓄卡' : '信用卡' }}</span>
              <p class="bankNum">
                **** **** **** {{ item.cardNo.substr(item.cardNo.length - 4) }}
              </p>
            </aside>
          </div>
          <div class="bankTag">
            <div v-for="(tag, tagIndex) in item.prodTags"
                 :key="tagIndex">
              {{ tag }}
            </div>
            <div v-show="item.prodTags.length % 4 > 0 && 4 - item.prodTags.length % 4 > 0"></div>
            <div v-show="item.prodTags.length % 4 > 0 && 4 - item.prodTags.length % 4 > 1"></div>
            <div v-show="item.prodTags.length % 4 > 0 && 4 - item.prodTags.length % 4 > 2"></div>
          </div>
        </li>
      </ul>
      <!-- <div v-if="userBankCard === null  || userBankCard.length === 0"
           class="hyapp-bank-empty">
        <img class="empty-img"
             src="../../../static/images/mine_card_no.png"
             alt="">
        <p>您还没有绑定过银行卡哦~</p>
      </div> -->
    </div>

    <Loading v-show="showLoading"></Loading>
  </PageView>
</template>

<script>
import utils from "../../util/utils"
import Loading from "../../components/loading/loading"
// import ActionBank from "../../components/actionBank/ActionBank";
// import commonButton from "../../components/button/index"

import { myselfBankCardApi } from '../../api/controller/bankCtr/index'
import { getBankImageByCode } from '../../assets/js/bankImages'

export default {
  components: {
    Loading,
    // ActionBank,
    // commonButton
  },
  data () {
    return {
      showLoading: false,
      // 用户绑定的银行卡列表
      userBankCard: [
      ],
      showErrorPage: false,
      errorPageInfo: {},
    }
  },
  computed: {
  },
  activated () {
    let that = this
    that.userBankCard = []
    that.showLoading = false
    that.showErrorPage = false
    that.getUserBankFun()
  },
  // mounted() {
  // },
  methods: {
    // 获取用户绑定的银行卡
    getUserBankFun () {
      let that = this
      that.showLoading = true
      myselfBankCardApi().then((data) => {
        that.showLoading = false
        var cardList = data.body.myBankCardList;
        for (let index = 0; index < cardList.length; index++) {
          cardList[index].prodTags = that.splitProdNames(cardList[index].prodNames)
        }
        that.userBankCard = cardList
        if (!cardList || cardList.length === 0) {
          that.initDefaultErrorPageInfos('', {
            title: '一卡在手，天下我有',
            icon: 'qsy_wyhk.png',
          })
        } else {
          that.showErrorPage = false
        }
      }).catch((err) => {
        that.showLoading = false
        utils.toastMsg(err.errMessage)
        that.initDefaultErrorPageInfos('offline')
      })
    },
    // 银行logo
    bankLogoFun (bankCode) {
      return getBankImageByCode(bankCode)
    },
    splitProdNames (val) {
      if (val) {
        return val.split(',')
      } else {
        return []
      }
    },
  }, // methods
}
</script>
<style lang="scss" scoped>
.wrap {
  padding: 0 rc(30);
}

.color-red-light {
  color: #ff6a45 !important;
}

.hyapp-action-content {
  padding: rc(36);
  display: flex;
  flex-direction: column;
  align-items: center;

  .img-warn {
    width: rc(96);
    height: rc(96);
    margin-top: rc(34);
  }

  h2 {
    font-size: rc(15);
    color: #444444;
    font-weight: bolder;
    line-height: rc(21);
    margin-top: rc(20);
  }

  p {
    font-size: rc(13);
    color: #777777;
    line-height: rc(18);
    margin-top: rc(14);
    margin-bottom: rc(14);
    padding: 0 rc(39);
    text-align: center;
  }

  .hyapp-action-close {
    position: absolute;
    left: rc(36);
    top: rc(36);

    img {
      width: rc(24);
      height: rc(24);
    }
  }
}

.hyapp-sheet-action {
  height: rc(96);
  display: flex;
  align-items: center;

  span {
    flex: 1;
    text-align: center;
    font-size: rc(15);
    color: #444444;
    height: 100%;
    line-height: rc(96);
  }
}

.bankCardList {
  overflow: hidden;

  li {
    box-shadow: rc(0 0 16 0) rgba(0, 0, 0, 0.06);
    border-radius: rc(16);
    margin-top: rc(40);
    box-sizing: border-box;
    overflow: hidden;
    position: relative;
  }

  .bankTop {
    padding: rc(30) rc(30) rc(20);
    box-sizing: border-box;
    overflow: hidden;
    position: relative;
  }

  .bankTag {
    background-color: #fff;
    padding: rc(15 43 23);
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    box-sizing: border-box;
    overflow: hidden;
    font-size: rc(24);
    color: #999999;
    position: relative;
    div {
      width: calc(100% / 4);
      margin-top: rc(13);
      white-space: nowrap;
    }
  }

  @at-root {
    .bankIcon {
      width: rc(80);
      height: rc(80);
      float: left;
      margin-right: rc(16);
      overflow: hidden;
      border-radius: rc(50);

      img {
        width: 100%;
        display: block;
      }
    }

    .bankMsg {
      overflow: hidden;
      color: #fff;
      font-size: rc(12);

      h4 {
        font-size: rc(32);
        line-height: rc(45);
      }
      span {
        color: rgba(255, 255, 255, 0.6);
        font-size: rc(28);
      }
    }

    .btnModify {
      width: rc(120);
      height: rc(56);
      line-height: rc(56);
      text-align: center;
      border-radius: rc(56);
      border: solid 1px #ffffff;
      font-size: rc(24);
      color: #fff;
      position: absolute;
      right: rc(30);
      top: rc(30);
      box-sizing: border-box;
    }

    .bankNum {
      margin-top: rc(22);
      height: rc(56);
      line-height: rc(56);
      color: #fff;
      font-size: rc(36);
    }
  }
}

.hyapp-bank-empty {
  display: flex;
  padding: rc(110 0 0);
  align-items: center;
  flex-direction: column;
  // position: fixed;
  // top: rc(150);
  // bottom: 0;
  // left: 0;
  width: 100%;
  height: 100%;

  .empty-img {
    width: rc(340);
    height: rc(300);
  }

  p {
    margin: rc(70) 0 rc(30);
    text-align: center;
    width: 100%;
    font-weight: bold;
    font-size: rc(32);
  }
}
.hqwy-btns {
  padding: rc(60) rc(75) rc(185);
}
</style>
