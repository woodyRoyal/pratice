<template>
  <PageView title="添加银行卡"
            right-txt="客服/帮助"
            @rightClick="rightClickHandle">
    <Tip :txt="'必须绑定本人的储蓄卡, 否则将无法通过验证'"></Tip>
    <div>
      <div class="add-conent">
        <LoanCell title="银行卡号"
                  :is-link="false">
          <div v-cloak
               class="bank-num-show"
               :class="{'bank-num-ph': cardNum.length === 0, 'opacity1': cardNumBlur}">
            {{ cardNum | formateCreditCard }}
          </div>
          <input v-model.trim="cardNum"
                 class="oa-ipt-hidden"
                 :class="{'opacity1': !cardNumBlur}"
                 type="tel"
                 placeholder="请输入银行卡号"
                 maxlength="19"
                 @keyup="canSubmit()"
                 @blur="whichBankFun()"
                 @focus="cardNumBlur=false">
        </LoanCell>
        <LoanCell title="开户银行">
          <input v-model="openBankData.openBankName[0]"
                 class="ip-tar"
                 readonly
                 placeholder="请选择"
                 @click="bankClick" />
          <PopupPicker v-show="showBank"
                       ref="bankPickFlag"
                       v-model="openBankData.openBankName"
                       class="popupStyle"
                       confirm-text="确定"
                       title=""
                       :data="openBankData.openBankList"
                       @on-hide="bankHide"
                       @on-change="getBankId(openBankData.openBankName)"></PopupPicker>
        </LoanCell>
        <LoanCell title="银行卡预留手机号"
                  :is-link="false">
          <input v-model.trim="phoneNum"
                 class="ip-tar"
                 type="tel"
                 :class="{'ipt-error': phoneNumErr}"
                 maxlength="11"
                 placeholder="请输入预留手机号"
                 @keyup="canSubmit()"
                 @blur="checkPhone()"
                 @focus="phoneNumErr=false">
        </LoanCell>
      </div>
      <div class="bottom-tips">
        银行卡用于借款和还款, 绑卡不回产生任何费用
      </div>
      <div class="hqwy-btns">
        <CommonButton :btn-data="btnData"
                      @click.native="submitData('tjyhk;tj;w230')"></CommonButton>
      </div>

      <div class="bottom-bank-tips">
        <span>温馨提示: 当前仅支持以下银行，请勿绑定其他银行卡</span>
        <ul class="bankTag">
          <li v-for="(item, index) in supportBankDisp"
              :key="index"
              lang="zh-CN"
              v-html="item"></li>
        </ul>
      </div>
    </div>

    <!-- 请输入短信验证码 begin -->
    <Confirm ref="msgPopFlag"
             title="请输入短信验证码"
             :close-on-confirm="false"
             cancel-txt="取消"
             sure-txt="确定"
             style="z-index: 10; position: relative"
             @on-cancel="confirmCancel('ddxq;yzmqx;w233')"
             @on-confirm="dynamicCodeFun('ddxq;yzmtj;w234')">
      <div class="cardList"
           style="padding:0;">
        <ul class="cardList-tb">
          <li class="hy-1px-b">
            <input v-model.trim="dynamicNum"
                   type="text"
                   maxlength="6"
                   placeholder="请输入验证码">
            <a v-show="sendAgainFlag"
               class="btnAgain"
               href="javascript:"
               @click="getDynamicCodeFun('ddxq;hqyzm;w232')">重新发送</a>
            <em v-show="!sendAgainFlag"
                class="countDown">{{ countDownTime }}秒后重试</em>
          </li>
        </ul>
      </div>
      <aside class="setTip">
        验证码已发送至手机<span>{{ phoneNum.substr(0, 3) }}****{{ phoneNum.substr(7, 11) }}</span>，请查看并填写。
      </aside>
    </Confirm>
    <!-- 请输入短信验证码 end -->

    <Loading v-show="showLoading"></Loading>
  </PageView>
</template>

<script>
import utils from "../../util/utils"
import LoanCell from '@/components/cell/index'
import { PopupPicker } from "vux";
import Confirm from "../../components/confirm/index"
import CommonButton from "../../components/button/index"
import Tip from "../../components/tip/index"
import Loading from "../../components/loading/loading"
import { getSupportBankApi, bankcardBindApi, cardbinApi } from '../../api/controller/bankCtr/index'
/* eslint-disable eqeqeq */
export default {
  components: {
    LoanCell,
    PopupPicker,
    CommonButton,
    Confirm,
    Tip,
    Loading,
  },
  filters: {
    formateCreditCard (card) {
      let result = ''
      if (card && card.length > 0) {
        card = card.split('')
        for (let i = 0; i < card.length; i++) {
          result += card[i]
          if (i % 4 === 3 && i !== card.length - 1) {
            result += ' '
          }
        }
      } else {
        result = '请输入银行卡号'
      }
      return result
    },
  },
  data () {
    let query = this.$route.query

    return {
      // 选择开户银行
      openBankData: {
        openBankName: [], // 开户银行名称
        openBankList: [], // 开户银行列表
      },
      supportBankData: [
      ], // 支持的银行列表
      supportBankDisp: [
      ], // 支持的银行列表
      bankName: '',
      cardNum: '',
      bankData: {
        bankCode: '', // 银行id
      },
      cardNumBlur: false,
      phoneNum: '',
      phoneNumErr: false,
      countDownTime: 60, // 验证码倒计时
      sendAgainFlag: false, // 重新发送Flag
      dynamicNum: '', // 短信验证码
      dynamicCodeFlag: true, // 验证码弹框确定Flag
      timer: null,
      btnData: {
        activeFlag: false,
        txt: '保存',
      },
      pdInfo: {
        productId: query.productId,//产品Id
        applyNo: query.applyNo,//进件订单编号
        loanNo: query.loanNo,//借款订单号
        stage: query.stage, //1：借款阶段 2：还款阶段
      },
      showBank: false,
      showLoading: false,
    }
  },
  activated () {
    let that = this
    let query = this.$route.query
    that.showLoading = false
    that.showBank = false

    that.openBankData = {
      openBankName: [], // 开户银行名称
      openBankList: [], // 开户银行列表
    }
    that.supportBankData = [] // 支持的银行列表
    that.supportBankDisp = [] // 支持的银行列表
    that.bankName = ''
    that.cardNum = ''
    that.bankData = {
      bankCode: '', // 银行id
    }
    that.cardNumBlur = false
    that.phoneNum = ''
    that.phoneNumErr = false
    that.countDownTime = 60 // 验证码倒计时
    that.sendAgainFlag = false // 重新发送Flag
    that.dynamicNum = '' // 短信验证码
    that.dynamicCodeFlag = true // 验证码弹框确定Flag
    that.timer = null
    that.btnData = {
      activeFlag: false,
      txt: '保存',
    }
    that.pdInfo = {
      productId: query.productId,//产品Id
      applyNo: query.applyNo,//进件订单编号
      loanNo: query.loanNo,//借款订单号
      stage: query.stage, //1：借款阶段 2：还款阶段
    }

    that.$refs.msgPopFlag.hide()
    that.$refs.bankPickFlag.onHide()
    setTimeout(() => {
      that.getSupportBankListFun()
    }, 50)
  },
  // mounted () {
  // },
  methods: {
    rightClickHandle () {
      this.$refs.bankPickFlag.onHide()
      this.eventFun('bzan;jrbzzx;w235')
      this.openHelpcenter(235)
    },
    // 通过用户输入的银行卡号判断是哪个银行的
    whichBankFun () {
      let that = this
      that.cardNumBlur = true
      let formData = {
        bankCardNo: that.cardNum,
      }
      if (that.cardNum.length >= 6) {
        cardbinApi(formData).then((data) => {
          // 先清空，否则会有多个
          that.openBankData.openBankName = []
          if (data.body.bankName) {
            that.openBankData.openBankName.push(data.body.bankName)
            that.bankData = data.body
          }
        }, (err) => {
          console.log(err)
        })
      }
    },
    // 获取支持银行列表 和 获取银行列表（同一个接口）
    getSupportBankListFun () {
      let that = this
      let formData = {
        productId: that.pdInfo.productId,
      }
      getSupportBankApi(formData).then((data) => {
        that.supportBankData = data.body
        let bankListData = []
        for (let i in data.body) {
          bankListData.push(data.body[i].bankName)
        }
        that.openBankData.openBankList = []
        that.openBankData.openBankList.push(bankListData)

        that.supportBankDisp = []
        while (bankListData.length % 3 !== 0) {
          bankListData.push('&nbsp;')
        }
        that.supportBankDisp = bankListData
      }, (err) => {
        console.log(err)
      })
    },
    // 记录用户选择的字典值
    getBankId (val) {
      for (var i in this.supportBankData) {
        if (val.toString() === this.supportBankData[i].bankName) {
          this.bankData.bankCode = this.supportBankData[i].bankCode
          this.bankData.bankName = this.supportBankData[i].bankName
          return
        }
      }
    },
    checkPhone () {
      let that = this
      if (!(/^1[3456789]\d{9}$/.test(that.phoneNum))) {
        that.phoneNumErr = true
      } else {
        that.phoneNumErr = false
      }
    },
    confirmCancel (eventId) {
      let that = this
      that.eventFun(eventId)
    },
    // 短信验证码确定按钮
    dynamicCodeFun (eventId) {
      let that = this
      that.eventFun(eventId)
      if (that.isdynamicCode() && that.dynamicCodeFlag) {
        that.showLoading = true
        that.dynamicCodeFlag = false
        let formData = {
          applyNo: that.pdInfo.applyNo,
          bankCode: that.bankData.bankCode,
          bankMobilePhone: that.phoneNum,
          bankName: that.bankData.bankName,
          cardMode: '1',
          cardNo: that.cardNum,
          loanNo: that.pdInfo.loanNo,
          stage: that.pdInfo.stage,
          verifyCode: that.dynamicNum,
        }

        bankcardBindApi(formData).then((data) => {
          that.showLoading = false
          that.dynamicCodeFlag = true
          let status = data.body.status
          if (status == 200) {
            that.$refs.msgPopFlag.hide()
            that.dynamicNum = ''
            that.$routerGo(-1)
          } else if (405 == status || 100 == status) {//验证码错误，验证码发送成功
            if (status == 100) {
              that.timeCountDownFunc()
            } else {
              utils.toastMsg(data.body.detail)
            }
            that.$refs.msgPopFlag.show()
            that.dynamicNum = ''
          } else {
            utils.toastMsg(data.body.detail)
            that.$refs.msgPopFlag.hide()
          }
        }, () => {
          that.showLoading = false
          that.dynamicCodeFlag = true
        })
      }
    },
    // 检查短信验证码
    isdynamicCode () {
      if (this.dynamicNum.length === 0) {
        // this.errorMsgFlag = true
        // this.errorMsg = '短信验证码不能为空'
        utils.toastMsg('短信验证码不能为空')
      } else if (this.dynamicNum.length < 6) {
        // this.errorMsgFlag = true
        // this.errorMsg = '请完整输入验证码'
        utils.toastMsg('请完整输入验证码')
      } else {
        return true
      }
    },
    submitData (eventId) {
      let that = this

      if (that.cardNum.length == 0) {
        utils.toastMsg('请输入银行卡号')
        return
      }

      if (that.bankData.bankCode.length == 0) {
        utils.toastMsg('请选择开户银行')
        return
      }

      if (that.phoneNum.length == 0) {
        utils.toastMsg('请输入银行卡预留手机号码')
        return
      }

      if (that.bankData.cardMode == 2) {
        utils.toastMsg('不支持信用卡，请绑定储蓄卡')
        return
      }

      if (that.btnData.activeFlag && that.isPhoneNum()) {
        that.getDynamicCodeFun(eventId)
      }
    },
    bankHide (closeType) {
      let that = this
      that.$refs.showBank = false
      if (closeType) {
        that.eventFun('tjyhk;khyhqr;w231')
      }
      that.canSubmit()
    },
    bankClick () {
      let that = this
      that.$refs.showBank = true
      that.$refs.bankPickFlag.onClick()
    },
    canSubmit () {
      let that = this
      if (that.cardNum.length >= 13 && that.phoneNum.length === 11 && /^1[3456789]\d{9}$/.test(that.phoneNum) && that.bankData.bankCode) {
        that.phoneNumErr = false
        that.btnData.activeFlag = true
      } else {
        that.btnData.activeFlag = false
      }
    },
    // 添加银行卡，获取验证码
    getDynamicCodeFun (eventId) {
      let that = this
      that.showLoading = true
      that.eventFun(eventId)
      let formData = {
        applyNo: that.pdInfo.applyNo,
        bankCode: that.bankData.bankCode,
        bankMobilePhone: that.phoneNum,
        bankName: that.bankData.bankName,
        cardMode: '1',
        cardNo: that.cardNum,
        loanNo: that.pdInfo.loanNo,
        stage: that.pdInfo.stage,
      }
      bankcardBindApi(formData).then((data) => {
        that.showLoading = false
        that.dynamicCodeFlag = true
        let status = data.body.status
        if (status == 200) {
          // 绑卡成功
          that.$refs.msgPopFlag.hide()
          that.dynamicNum = ''
          that.dynamicCodeFlag = true
          that.$routerGo(-1)
        } else if (405 == status || 100 == status) {//验证码错误，验证码发送成功
          if (status == 100) {
            that.timeCountDownFunc()
          } else {
            utils.toastMsg(data.body.detail)
          }
          that.$refs.msgPopFlag.show()
          that.dynamicNum = ''
          that.dynamicCodeFlag = true
        } else {
          utils.toastMsg(data.body.detail)
          that.$refs.msgPopFlag.hide()
        }
      }, () => {
        that.showLoading = false
        that.dynamicCodeFlag = true
      })
    },
    // 校验手机号格式
    isPhoneNum () {
      var reg = /^1[3456789]\d{9}$/
      if (reg.test(this.phoneNum)) {
        return true
      } else {
        // this.errorMsgFlag = true
        // this.errorMsg = '您的手机号有误'
        utils.toastMsg('您的手机号有误')
        return false
      }
    },
    // 验证码倒计时
    timeCountDownFunc: function () {
      let that = this
      let timer = that.timer
      that.sendAgainFlag = false
      clearInterval(timer)
      that.countDownTime = 60
      that.dynamicNum = ''
      that.timer = setInterval(() => {
        that.countDownTime--
        if (that.countDownTime <= 0) {
          that.sendAgainFlag = true
          that.countDownTime = 60
          clearInterval(that.timer)
        }
      }, 1000)
    },
    // 埋点
    eventFun (eventId) {
      if (eventId) {
        this.$appInvoked('appExecStatistic', { eventId: eventId })
      }
    },
  }, // methods
}
</script>
<style lang="scss" scoped>
.bottom-tips {
  margin: rc(72 0 0);
  text-align: center;
  font-size: rc(24);
  color: #777777;
}

.add-conent {
  background-color: #fff;
}

.hqwy-btns {
  margin: rc(22 0 0);
  padding: 0 rc(30);
}

.ip-tar {
  text-align: right;
}

.bank-num-show {
  font-size: rc(30);
  text-align: right;
  flex: 1;
  opacity: 0;
  font-family: Arial;
}

.bank-num-ph {
  color: #aaa;
}

.opacity1 {
  opacity: 1 !important;
}

.oa-ipt-hidden {
  text-align: right;
  position: absolute;
  font-size: rc(30);
  top: 0;
  right: 0;
  width: 100%;
  height: 100%;
  opacity: 0;
}

.cardList {
  padding: rc(0 36);
  margin-top: rc(40);
  font-size: rc(30);

  li {
    height: rc(98);
    display: flex;
    align-items: center;
    position: relative;
    width: 100%;

    > span {
      width: rc(170);
      color: #444;
    }

    > input {
      flex: 1;
    }
  }

  .countDown {
    font-size: rc(26);
    color: #aaa;
    text-align: right;
    display: block;
    position: absolute;
    right: 0;
    top: rc(30);
  }

  .btnAgain {
    font-size: rc(26);
    color: #ff5b00;
    text-align: right;
    position: absolute;
    right: 0;
    top: rc(30);
  }
}

.setTip {
  font-size: rc(26);
  color: #777777;
  text-align: left;
  margin-top: rc(20);

  span {
    color: #ff9d00;
  }
}
.msgPopFlag {
  z-index: 10;
}
.bottom-bank-tips {
  margin: rc(280 30 30);
  font-size: rc(26);
  color: #777777;

  .bankTag {
    margin: rc(20 0 0);
    background-color: #fff;
    display: flex;
    flex-wrap: wrap;
    overflow: hidden;
    position: relative;

    li {
      width: 33.33%;
      line-height: rc(55);
      text-align: center;
      white-space: nowrap;
      position: relative;

      &::before {
        content: ' ';
        position: absolute;
        right: 0;
        top: 0;
        width: 1px;
        bottom: 0;
        border-right: 1px solid #e7e7e7;
        color: #e7e7e7;
        transform-origin: 100% 0;
        transform: scaleX(0.5);
      }

      &::after {
        content: ' ';
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        height: 1px;
        color: #e7e7e7;
        border-top: 1px solid #e7e7e7;
        transform-origin: 0 100%;
        transform: scaleY(0.5);
      }

      &:nth-child(3n) {
        &::before {
          border-right: 0;
        }
      }

      &:nth-child(1),
      &:nth-child(2),
      &:nth-child(3) {
        &::after {
          border-top: 0;
        }
      }
    }
  }
}

.color-red-light {
  color: #ff6a45 !important;
}

.bc-unchoose {
  font-family: PingFangSC-Regular;
  font-size: rc(30);
  font-weight: normal;
  font-stretch: normal;
  letter-spacing: 0px;
  color: #aaaaaa;
}
.hy-1px-b {
  position: relative;
  &::after {
    content: ' ';
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: 1px;
    color: #e7e7e7;
    border-bottom: 1px solid #e7e7e7;
    transform-origin: 0 100%;
    transform: scaleY(0.5);
  }
}
</style>
