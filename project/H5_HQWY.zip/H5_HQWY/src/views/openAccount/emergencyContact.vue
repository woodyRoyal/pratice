<template>
  <PageView title="紧急联系人"
            :is-back-page="false"
            :show-error-page="showErrorPage"
            :error-page-info="errorPageInfo"
            @backClick="backClickHandle">
    <div key="normal"
         class="hqwy-body-white">
      <Tip :txt="'请添加两位联系人，并修改联系人姓名为真实姓名'"></Tip>
      <div class="hqwy-mod-hasinfo">
        <div class="info-des">
          直系亲属联系人
        </div>
        <ul class="hqwy-mod-info">
          <li :class="{'error': btnClickFlag[0] && contactData[0].relation.value == ''}"
              @click="openActionSheet(0,0,0)">
            <span class="name">与本人关系</span>
            <input v-model="contactData[0].relation.value"
                   type="text"
                   class="ipt"
                   placeholder="请选择"
                   readonly>
            <Arrow direction="right"
                   color="#ccc"></Arrow>
          </li>
          <li :class="{'error': btnClickFlag[2] && contactData[0].phone == ''}"
              class="default-nobb">
            <span v-if="contactData[0].phone == '' && inputMode != 1"
                  class="name"
                  @click="getContactCheckPermission(0, 2)">紧急联系人</span>
            <div v-else
                 class="name-result bb-1px"
                 :class="{'name-result-error': btnClickFlag[1] && contactData[0].name == ''}">
              <input v-model="contactData[0].name"
                     type="text"
                     class="ipt-name"
                     placeholder="联系人姓名"
                     :class="{'ipt-error': valueErrorFlag[0]}"
                     @focus="focusFun(1)"
                     @input="changeFun(0)">
            </div>
            <input v-model="contactData[0].phone"
                   type="tel"
                   class="ipt"
                   :placeholder="inputMode==1?'联系人电话':'请选择'"
                   :readonly="inputMode!=1"
                   maxlength="11"
                   @click="getContactCheckPermission(0, 2)">
            <Arrow v-if="inputMode!=1"
                   direction="right"
                   color="#ccc"
                   @click.native="getContactCheckPermission(0, 2)"></Arrow>
          </li>
        </ul>
        <div class="info-des">
          其他联系人
        </div>
        <ul class="hqwy-mod-info">
          <li :class="{'error': btnClickFlag[3] && contactData[1].relation.value == ''}"
              @click="openActionSheet(0,1,3)">
            <span class="name">与本人关系</span>
            <input v-model="contactData[1].relation.value"
                   type="text"
                   class="ipt"
                   placeholder="请选择"
                   readonly>
            <Arrow direction="right"
                   color="#ccc"></Arrow>
          </li>
          <li :class="{'error': btnClickFlag[5] && contactData[1].phone == ''}">
            <span v-if="contactData[1].phone == '' && inputMode!=1"
                  class="name"
                  @click="getContactCheckPermission(1, 5)">紧急联系人</span>
            <div v-else
                 class="name-result bb-1px"
                 :class="{'name-result-error': btnClickFlag[4] && contactData[1].name == ''}">
              <input v-model="contactData[1].name"
                     type="text"
                     class="ipt-name"
                     placeholder="联系人姓名"
                     :class="{'ipt-error': valueErrorFlag[1]}"
                     @focus="focusFun(4)"
                     @input="changeFun(1)">
            </div>
            <input v-model="contactData[1].phone"
                   type="tel"
                   class="ipt"
                   :placeholder="inputMode==1?'联系人电话':'请选择'"
                   :readonly="inputMode!=1"
                   maxlength="11"
                   @click="getContactCheckPermission(1, 5)">
            <Arrow v-if="inputMode!=1"
                   direction="right"
                   color="#ccc"
                   @click.native="getContactCheckPermission(1, 5)"></Arrow>
          </li>
        </ul>
      </div>
      <div class="hqwy-btns">
        <CommonButton :btn-data="btnData"
                      @click.native="btnClick()"></CommonButton>
      </div>
    </div>
    <div v-if="!showErrorPage"
         slot="dialog"
         key="dialog">
      <!-- 返回挽留弹窗 -->
      <FillInfoBackConfirm ref="backComfirm"
                           :source="source"
                           page="JJLXR"></FillInfoBackConfirm>
      <!-- 返回挽留弹窗 end -->
      <!-- 下拉框 -->
      <ActionSheet :is-show="isShow"
                   action-title="与本人关系"
                   :action-list="actionList"
                   @onHideAction="isShow = false"
                   @onSelectItem="actionSheetOnSelectItem"></ActionSheet>
      <!-- 下拉框 end-->
      <!-- 权限弹窗 -->
      <PermissionConfirm ref="PermissionConfirm"
                         pt="jjlxr"
                         :permissions="[4]"
                         txt="为确保您填写的联系人信息真实有效，请授权以下权限！"
                         @on-confirm="backConfirmSure('jjlxr;qxgztc;w292')"></PermissionConfirm>
      <Loading v-show="showInfo.isLoading"></Loading>
      <VLoad :isload="isLoad"></VLoad>
    </div>
  </PageView>
</template>
<script>
import utils from "../../util/utils.js"
import Tip from "../../components/tip/index"
import CommonButton from "../../components/button/index"
// import confirm from "../../components/confirm/index"
import PermissionConfirm from "../../components/confirm/PermissionConfirm"
import FillInfoBackConfirm from "../../components/confirm/FillInfoBackConfirm"
import Arrow from '../../components/common/arrow.vue'
import ActionSheet from "../../components/action-sheet"
import Loading from "../../components/loading/loading"
import VLoad from "../../components/load.vue"
import { requestCommonDict } from "../../../src/api/controller/common"
import { getContactInfoApi, saveContactInfoApi } from "../../../src/api/controller/openAccount"
export default {
  components: {
    Tip,
    Arrow,
    CommonButton,
    // confirm,
    FillInfoBackConfirm,
    ActionSheet,
    Loading,
    VLoad,
    // vAbnor,
    PermissionConfirm,
  },
  data () {
    return {
      inputMode: 0, // 输入模式：0-未知，1-手动输入，2-通讯录选择输入
      source: this.$route.query.source, // 页面来源。0-我的>完善贷款信息，1-API产品详情，2-重新智能推荐
      isShow: false,
      isLoad: "none",
      showErrorPage: false,
      errorPageInfo: {},
      curSelect: null, // 记录用户当前选的是哪一个
      showInfo: {
        isLoading: false,
        section: [
          [
            {
              title: "职业身份",
              actionList: [],
              value: -1,
            },
            {
              title: "月收入范围",
              actionList: [],
              value: -1,
            },
          ],
        ],
      },
      selectPos: {
        section: "",
        index: "",
      },
      actionList: [],
      contactData: [
        {
          relation: {
            value: '', // 用户选择的值
            id: null, // 用户选择的值对应的id
          },
          name: '',
          phone: '',
        },
        {
          relation: {
            value: '',
            id: null,
          },
          name: '',
          phone: '',
        },
      ],
      btnData: {
        activeFlag: false,
        txt: '下一步',
      },
      btnClickFlag: [false, false, false, false, false, false], // 记录点击状态
      valueErrorFlag: [false, false], // 名字格式错误
      onConfirm: null, // 权限弹窗确认事件
    }
  },
  watch: {
    'contactData': {
      handler (val) {
        if (val[0].name !== '' && val[0].phone !== '' && val[0].relation.value !== '' && val[1].name !== '' && val[1].phone !== '' && val[1].relation.value !== '') {
          this.btnData.activeFlag = true
        } else {
          this.btnData.activeFlag = false
        }
      },
      deep: true,
      immediate: true,
    },
  },
  activated () {
    this.interceptAppBack()
    this.inputMode = 0
    this.showErrorPage = false
    let w = this.$route.query.w
    if (w) {
      this.collectEventMD({
        eventId: `ly1009,w${w}`,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
      })
    }
    this.source = this.$route.query.source
    // 数据初始化
    this.btnClickFlag = [false, false, false, false, false, false]
    this.valueErrorFlag = [false, false]
    this.$refs.backComfirm && this.$refs.backComfirm.hide()
    this.$refs.PermissionConfirm && this.$refs.PermissionConfirm.hide()

    this.getdictList()
    this.collectEventFun('1006')
  },
  // mounted () {
  // },
  methods: {
    backConfirmSure (eventId) {
      this.mdAll(eventId)
    },
    // 进入页面事件统计
    collectEventFun (id) {
      let params = {
        eventEndTime: '',
        eventId: id,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
        productId: this.$route.query.productId || '',
      }
      this.collectEventMD(params)
    },
    //数据字典接口
    getdictList () {
      var self = this;
      self.isLoad = "block"; //开始loading
      requestCommonDict({}).then(
        (repData) => {
          self.isLoad = "none";
          if (repData.respCode === "1000") {
            self.showInfo.section[0][0].actionList = repData.body.immediateFamily
            self.showInfo.section[0][1].actionList = repData.body.otherContacts
            // console.log(self.showInfo.section[0])
          }
          self.requestUserInfo();
        },
        () => {
          self.isLoad = "none"
          // self.showErrorPage = true
          self.initDefaultErrorPageInfos('offline')
        }
      );
    },
    // 关系返显
    relationTranslate (index, obj) {
      // index 是数组索引 obj是对应的赋值对象
      this.showInfo.section[0][index].actionList.forEach((element) => {
        if (element.dictValue === obj.id) {
          obj.value = element.dictName
        }
      })
    },
    actionSheetOnSelectItem: function (item, index) {
      this.isShow = false;
      if (index < 0) {
        return;
      }
      this.contactData[this.curSelect].relation.value = item.dictName
      this.contactData[this.curSelect].relation.id = item.dictValue
    },
    openActionSheet: function (section, index, num) {
      this.isShow = true;
      this.curSelect = index
      this.selectPos.section = section;
      this.selectPos.index = index;
      this.actionList = this.showInfo.section[section][index].actionList;
      this.$set(this.btnClickFlag, num, false)
    },
    getContactCheckPermission (index, num) {
      let that = this
      if (that.inputMode === 1) {
        return
      }
      this.$refs.PermissionConfirm.show({
        callback: function () {
          that.getContact(index, num)
        },
      })
    },
    // 调用原生打开通讯录
    getContact (index, num) {
      let that = this
      that.$set(this.btnClickFlag, num, false)
      that.$appInvoked("appOpenContacts", {}, function (rst) {
        that.inputMode = 2
        let data = rst.contacts[0]
        // 手机号去除空格去除+86去除-()（）
        let phone = data.phones[0].replace(/\(|\)|-|\+86|（|）|\s*/g, '')
        if (that.difPhone(phone, index) && that.checkPhone(phone)) {
          that.contactData[index].name = data.name
          that.contactData[index].phone = phone
        }
      }, function () {
        utils.toastMsg("请先开启联系人访问权限")
        that.inputMode = 1
      })
    },
    // 两位联系人的手机号不能相同
    difPhone (num, index) {
      if (num !== this.contactData[index].phone && (num === this.contactData[0].phone || num === this.contactData[1].phone)) {
        utils.toastMsg("此号码已添加，请重新选择")
        return false
      } else {
        return true
      }
    },
    // 手机号校验
    checkPhone (num) {
      let reg = /^1[3546789]\d{9}$/
      if (reg.test(num)) {
        return true
      } else {
        utils.toastMsg("请选择正确的手机号码")
        return false
      }
    },
    // 获取联系人信息
    requestUserInfo () {
      getContactInfoApi({}).then((data) => {
        this.showErrorPage = false
        if (data.respCode === "1000" && data.body.contactVoList.length > 0) {
          data.body.contactVoList.forEach((element) => {
            if (element.contactBigType > 0) {
              this.contactData[element.contactBigType - 1].name = element.contactName
              this.contactData[element.contactBigType - 1].phone = element.contactMobilePhone
              this.contactData[element.contactBigType - 1].relation.id = element.contactSmallType
              this.relationTranslate(element.contactBigType - 1, this.contactData[element.contactBigType - 1].relation)
            }
          })
        } else {
          this.contactData.forEach((el) => {
            // console.log(el)
            el.name = ''
            el.phone = ''
            el.relation.id = null
            el.relation.value = ''
          })
        }
      }).catch(() => {
        // this.showErrorPage = true
        this.initDefaultErrorPageInfos('offline')
      })
    },
    saveUserInfo () {
      // 上传风控节点
      // this.$appInvoked('appUploadRiskData', { node: 201 })

      this.showInfo.isLoading = true
      let inputMode = this.inputMode
      let params = {
        contactVoList: [{
          contactBigType: 1,
          contactMobilePhone: this.contactData[0].phone,
          contactName: this.contactData[0].name,
          contactSmallType: this.contactData[0].relation.id,
          inputMode: inputMode,
        }, {
          contactBigType: 2,
          contactMobilePhone: this.contactData[1].phone,
          contactName: this.contactData[1].name,
          contactSmallType: this.contactData[1].relation.id,
          inputMode: inputMode,
        }],
      }
      saveContactInfoApi(params).then((data) => {
        this.showInfo.isLoading = false
        if (data.respCode === "1000") {
          // utils.toastMsg("保存成功！")
          this.$appInvoked('appToastMessage', { 'message': '保存成功！' })
          // 保存成功，判断下一项待填写资料
          this.checkNextFillInfos(this.$route.query.w)
          // this.$routerGo(-1)
        }
      }).catch((error) => {
        this.showInfo.isLoading = false
        if (error.respCode !== '1001') {
          utils.toastMsg(error.respMsg)
        }
      })
    },
    // 点击按钮
    btnClick () {
      // 点击统计
      this.$appInvoked("appExecStatistic", {
        eventId: "jjlxr;bc;w190",
        eventType: 0,
      })
      // 非空校验
      this.clickFlagFun(this.contactData[0].relation.value, 0)
      this.clickFlagFun(this.contactData[0].name, 1)
      this.clickFlagFun(this.contactData[0].phone, 2)
      this.clickFlagFun(this.contactData[1].relation.value, 3)
      this.clickFlagFun(this.contactData[1].name, 4)
      this.clickFlagFun(this.contactData[1].phone, 5)
      // 数据校验
      if (this.btnData.activeFlag) {
        // 校验姓名
        let checkNameResult0 = this.checkName(0, this.contactData[0].name)
        let checkNameResult1 = this.checkName(1, this.contactData[1].name)
        if (!checkNameResult0 || !checkNameResult1) {
          utils.toastMsg('请将错误信息修改后，再提交')
          return
        }
        // 校验通过保存信息
        this.saveUserInfo()
      }
    },
    // 记录点击状态
    clickFlagFun (obj, index) {
      obj === '' ? this.$set(this.btnClickFlag, index, true) : this.$set(this.btnClickFlag, index, false)
    },
    // 错误文案逻辑
    changeFun (index) {
      this.$set(this.valueErrorFlag, index, false)
    },
    // 红线逻辑
    focusFun (index) {
      this.$set(this.btnClickFlag, index, false)
    },
    // 姓名校验
    checkName (index, value) {
      // 必须要有汉字 汉字、字母、数字这三类合法字符加起来字符长度必须≥2
      let emojiReg = /\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g
      let reg1 = /[\u4E00-\u9FA5]/g
      let reg2 = /[0-9a-zA-Z]/g
      let len1 = value.match(reg1) ? value.match(reg1).length : 0
      let len2 = value.match(reg2) ? value.match(reg2).length : 0
      if (!emojiReg.test(value) && len1 > 0 && (len1 + len2) > 1) {
        return true
      } else {
        this.$set(this.valueErrorFlag, index, true)
        return false
      }
    },
    // 返回展示挽留弹窗
    backClickHandle () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'jjlxr;fh;w289',
      })
      if (!this.showErrorPage) {
        this.$refs.backComfirm.show()
      } else {
        this.$routerGo(-1)
      }
      // if (this.contactData[0].relation.value !== '' || this.contactData[0].name !== '' || this.contactData[0].phone || this.contactData[1].relation.value !== '' || this.contactData[1].name !== '' || this.contactData[1].phone) {
      //   this.$refs.backComfirm.show()
      // } else {
      //   this.backConfirmCancel()
      // }
    },
  },
}
</script>
<style lang="scss" scoped>
@import 'css/index.scss';
.hqwy-body-white {
  height: 100%;
  background-color: #fff;
}
.hqwy-mod-info {
  padding: 0 0 0 rc(30);
  font-size: rc(30);
  color: #333;
  .name {
    width: rc(210);
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
  }
  li {
    display: flex;
    position: relative;
    padding-right: rc(30);
    height: rc(98);
    align-items: center;
    overflow: hidden;
    &:before {
      content: '';
      height: 1px;
      left: 0;
      position: absolute;
      right: 0;
      border-bottom: 1px solid #ddd;
      bottom: -1px;
      transform: scaleY(0.5);
      transform-origin: 0 0;
    }
    .ipt {
      flex: 1;
      height: 100%;
      text-align: right;
    }
    .ipt-disabled {
      color: #999;
    }
    .ipt-error {
      color: #ff4c4c;
    }
    .placeholder-error {
      &::-webkit-input-placeholder {
        color: red;
      }
    }
    .frontIpt {
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      height: rc(98);
      opacity: 0;
      z-index: 2;
    }
  }
  li.default-nobb {
    &::before {
      border-color: #fff;
    }
  }
  li.error {
    &:before {
      border-color: #ff4c4c;
    }
  }
  li.is-link {
    padding-right: rc(60);
    &:after {
      content: '';
      position: absolute;
      right: rc(30);
      top: 50%;
      margin-top: rc(-13);
      width: rc(14);
      height: rc(26);
      background-color: pink;
    }
  }
}
.info-des {
  font-size: rc(30);
  padding-left: rc(30);
  height: rc(80);
  line-height: rc(80);
  color: #999;
  background-color: #f5f5f5;
}
.hqwy-mod-hasinfo {
  .hqwy-mod-info {
    // li {
    //   &:last-child {
    //     &::before {
    //       // border: none;
    //     }
    //   }
    // }
    .name-result {
      width: rc(210);
      height: 100%;
      .ipt-name {
        width: 100%;
        height: 100%;
      }
      &::after {
        border-color: #333;
      }
    }
    .name-result-error {
      &::after {
        border-color: #ff4c4c;
      }
    }
  }
}
.hqwy-btns {
  margin-top: rc(80);
  padding: 0 rc(30);
}
</style>
<style lang="scss">
.hqwy-mod-info {
  .frontIpt {
    .weui-cell {
      height: 100%;
    }
  }
}
.hqwy-mod-hasinfo {
  .bb-1px {
    &:after {
      bottom: 0;
    }
  }
}
</style>


