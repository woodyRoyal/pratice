<template>
  <PageView id="hqwy-mescroll"
            type="mescroll bg-fff"
            title="身份认证"
            :is-back-page="false"
            @backClick="backClickHandle">
    <!-- <div>必须使用本人身份证，将联网公安部进行认证</div> -->
    <Tip txt="必须使用本人身份证，将联网公安部进行认证"></Tip>
    <!-- 身份证正反面扫描 -->
    <section class="ia-card">
      <div class="ia-card-container">
        <div class="ia-card-title">
          身份证人像面
        </div>
        <div class="ia-card-ctr"
             @click="ocrClickCheckPermission('front', 'sfrz;rxm;w184')">
          <div v-if="idFront.has"
               class="ia-card-content">
            <img class="ia-card-img"
                 :src="infos.frontFullImage"
                 alt>
            <div class="ia-card-mask"></div>
          </div>
          <div class="ia-card-layer">
            <img :src="require('APP_IMG/id_scan.png')"
                 class="ia-card-icon">
            <div class="ia-card-tips"
                 :class="idFront.tips.style"
                 v-text="idFront.tips.text"></div>
          </div>
        </div>
      </div>
      <div class="ia-card-container">
        <div class="ia-card-title">
          身份证国徽面
        </div>
        <div class="ia-card-ctr"
             @click="ocrClickCheckPermission('back', 'sfrz;ghm;w185')">
          <div v-if="idBack.has"
               class="ia-card-content">
            <img class="ia-card-img"
                 :src="infos.backFullImage"
                 alt>
            <div class="ia-card-mask"></div>
          </div>
          <div class="ia-card-layer">
            <img :src="require('APP_IMG/id_scan.png')"
                 class="ia-card-icon">
            <div class="ia-card-tips"
                 :class="idBack.tips.style"
                 v-text="idBack.tips.text"></div>
          </div>
        </div>
      </div>
    </section>
    <!-- 身份证信息 -->
    <section v-if="idFront.has"
             class="ia-info">
      <div class="ia-info-item bb-1px">
        <div class="ia-info-left">
          姓名
        </div>
        <div class="ia-info-right"
             v-text="infos.identityName"></div>
      </div>
      <div class="ia-info-item bb-1px">
        <div class="ia-info-left">
          身份证号
        </div>
        <div class="ia-info-right"
             v-text="infos.identityCard"></div>
      </div>
    </section>
    <!-- 分隔符 -->
    <div class="split-block"></div>
    <!-- 人脸识别 -->
    <section class="ia-info"
             @click="ocrClick('rlsb', 'sfrz;rlsb;w186')">
      <div class="ia-info-item bb-1px">
        <div class="ia-info-left">
          人脸识别
        </div>
        <div class="ia-info-right"
             :class="rlsb.stsColor"
             v-text="rlsb.stsTxt"></div>
        <div class="ia-info-arrow"></div>
        <Arrow direction="right"
               color="#ccc"></Arrow>
      </div>
    </section>
    <section class="ia-submit">
      <CommonButton :btn-data="btnData"
                    @click.native="submitData()"></CommonButton>
    </section>
    <section class="ia-bottom-tips">
      <img src="../../../static/images/safe.png"
           alt="">银行级数据加密防护
    </section>
    <div slot="dialog">
      <!-- 人脸识别提示弹窗 -->
      <Confirm ref="pconfirm"
               :white-space="false"
               title="请按照提示完成操作"
               sure-txt="立即认证"
               :close-flag="true"
               @on-confirm="authNow()"
               @on-close="closeRlsbConfirm()">
        <div class="auth-ctr">
          <div class="auth-item">
            <img class="auth-icon"
                 :src="require('APP_IMG/alert_iphone.png')">
            <div class="auth-tips">
              正对手机
            </div>
          </div>
          <div class="auth-item">
            <img class="auth-icon"
                 :src="require('APP_IMG/alert_light.png')">
            <div class="auth-tips">
              光线充足
            </div>
          </div>
          <div class="auth-item">
            <img class="auth-icon"
                 :src="require('APP_IMG/alert_time.png')">
            <div class="auth-tips">
              放慢动作
            </div>
          </div>
        </div>
      </Confirm>
      <!-- 返回挽留弹窗 -->
      <FillInfoBackConfirm ref="backComfirm"
                           :source="source"
                           page="SFRZ"></FillInfoBackConfirm>
      <!-- 手机号占用弹窗 -->
      <Confirm ref="tipsConfirm"
               :white-space="false"
               sure-txt="我知道了">
        <div class="tips-confirm"
             v-text="submitFailMsg"></div>
      </Confirm>
      <!-- 权限弹窗 -->
      <PermissionConfirm ref="PermissionConfirm"
                         pt="sfrz"
                         :permissions="permissions"
                         txt="为核查您身份信息的真实性，请授权以下权限！"
                         @on-confirm="backConfirmSure('sfrz;qxgztc;w286')"></PermissionConfirm>
      <!-- Loading -->
      <Loading v-show="showLoading"></Loading>
    </div>
  </PageView>
</template>
<script>
import Arrow from '../../components/common/arrow.vue'
import CommonButton from "../../components/button/index"
import Confirm from "../../components/confirm/index"
import PermissionConfirm from '../../components/confirm/PermissionConfirm'
import FillInfoBackConfirm from "../../components/confirm/FillInfoBackConfirm"
import Loading from "../../components/loading/loading"
import Tip from "../../components/tip/index"

import utils from "../../util/utils";

import { getProviderInfoApi, faceCompareApi } from "../../../src/api/controller/openAccount";
/* eslint-disable eqeqeq */
export default {
  name: 'IdentityAuth',
  components: {
    Arrow,
    CommonButton,
    Confirm,
    FillInfoBackConfirm,
    Loading,
    Tip,
    PermissionConfirm,
  },
  data () {
    return {
      permissions: isAndroid ? [1] : [1, 2], // 安卓-相机，iOS-相机、相册
      source: this.$route.query.source, // 页面来源。0-我的>完善贷款信息，1-API产品详情，2-重新智能推荐
      productId: this.$route.query.productId,
      providerInfo: '', // 供应商信息
      // 身份证正面信息
      idFront: {
        has: false, // 是否扫描成功
        tips: {
          text: '点击扫描',
          style: 'color-default',
        },
      },
      idBack: {
        // 身份证背面信息
        has: false,
        tips: {
          text: '点击扫描',
          style: 'color-default',
        },
      },
      infos: {
        address: '', // 住址
        frontFullImage: '', // 人像面图片
        identityCard: '', // 公民身份号码
        identityName: '', // 姓名
        nation: '', // 民族
        sex: '', // 性别
        birth: '', // 出生年月日
        code: '', // 识别结果码
        orderNo: '', // 核身订单号
        warningCode: '', // 识别结果警告码
        authority: '', // 签发机关
        backFullImage: '', // 国徽面图片
        validDate: '', // 有效期限
      },
      // 提交按钮
      btnData: {
        activeFlag: false,
        txt: '下一步',
      },
      // 人脸识别
      rlsb: {
        stsTxt: '未认证',
        stsColor: 'c1',
        status: 0, // 0-未认证，1-已认证，2-未通过
      },
      showLoading: false,
      submitFailMsg: '', // 提交失败文言：该身份证号已绑定了手机号为156****1476的账户，不能重复绑定。
    };
  },
  // computed: {},
  watch: {
    'idFront.has' (val) {
      let that = this;
      if (val) {
        that.idFront.tips = {
          text: '扫描成功',
          style: 'color-success',
        };
      } else {
        that.idFront.tips = {
          text: '点击扫描',
          style: 'color-default',
        };
      }
    },
    'idBack.has' (val) {
      let that = this;
      if (val) {
        that.idBack.tips = {
          text: '扫描成功',
          style: 'color-success',
        };
      } else {
        that.idBack.tips = {
          text: '点击扫描',
          style: 'color-default',
        };
      }
    },
    // 检测身份证号变化
    'infos.identityCard' (newVal, oldVal) {
      let that = this;
      // console.log(newVal, ',', oldVal);
      if (oldVal) { // 已识别后重新识别，身份证有变化
        that.idBack.has = false;
        that.rlsb.stsTxt = '未认证';
        that.rlsb.stsColor = 'c1';
        that.rlsb.status = 0;
      }
    },
    'rlsb.status' (val) {
      let that = this;
      if (val == 1) { // 已认证
        that.btnData.activeFlag = true;
      } else {
        that.btnData.activeFlag = false;
      }
    },
  },
  beforeRouteLeave (to, from, next) {
    let that = this;
    // 清除活检和ocr缓存
    that.$appInvoked('appCleanIdentityInfo', {});
    that.idFront.has = false;
    that.idBack.has = false;
    next();
  },
  activated () {
    this.interceptAppBack()
    let that = this
    let w = this.$route.query.w
    if (w) {
      this.collectEventMD({
        eventId: `ly1008,w${w}`,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
      })
    }
    that.hasShowPermissionConfirm = false
    that.source = that.$route.query.source
    that.$refs.PermissionConfirm && that.$refs.PermissionConfirm.hide()
    that.productId = that.$route.query.productId
    // 获取供应商
    that.getProviderInfoFunc();
    // 客户端埋点
    that.collectEventMD({
      eventId: '1004',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
      productId: that.productId,
    });
  },
  methods: {
    backConfirmSure (eventId) {
      this.mdAll(eventId)
    },
    // 获取供应商
    getProviderInfoFunc (cb) {
      let that = this;
      let params = {
        provider: 'FACE_ID',
        versionCode: '1.0',
      };
      getProviderInfoApi(params).then((data) => {
        data = data.body;

        // data = '4mwp9T2aMs3gaqOh1U7fCEguLoPNCFqnSvhOSTSiqcF3xKfLwj4KTUeQ1qinTDx2YoOsgEN72yzHjkeakzR1p+SE88plbZa887+4bVkEzzvjGrTlODi5PdDUx9f4f9dI7w7e//s+EGilSZyhfcOMKiIyd2EqXMqrNJA/TxT/2FeED2l161h0SqzdNX8IZRsk3DsCwKlmALQ=';

        that.providerInfo = data;
        that.infos.orderNo = data.orderNo;
        cb && cb(data);
      });
    },
    ocrClickCheckPermission (type, eventId) {
      let that = this
      this.$refs.PermissionConfirm.show({
        callback: function () {
          that.ocrClick(type, eventId)
        },
      })
    },
    // 点击调用原生方法，传入供应商数据
    ocrClick: utils.debouce(function (type, eventId) {
      let that = this;
      if (eventId) {
        that.$appInvoked('appExecStatistic', { eventId: eventId });
      }
      let providerInfo = that.providerInfo;
      if (!providerInfo) {
        that.getProviderInfoFunc(function (data) {
          that.openAppFunc(type, data);
        });
      } else {
        that.openAppFunc(type, providerInfo);
      }
    }, 500, true),
    // H5调用原生交互
    openAppFunc (type, data) {
      let that = this;
      if (type === 'front') {
        that.frontClick(data);
      } else if (type === 'back') {
        that.backClick(data);
      } else if (type === 'rlsb') {
        that.rlsbClick(data);
      }
    },
    // 点击身份证人像面
    frontClick (providerInfo) {
      let that = this;
      that.$appInvoked('appStartIDCardOCR', {
        data: providerInfo,
        type: 0,
      }, (data) => {
        that.idFront.has = true;
        that.infos.address = data.address;
        that.infos.frontFullImage = data.frontSmallImage;
        that.infos.identityCard = data.identityCard;
        that.infos.identityName = data.identityName;
        that.infos.nation = data.nation;
        that.infos.sex = data.sex;
        that.infos.birth = data.birth;
        // that.infos.code;
        // that.infos.orderNo;
        // that.infos.warningCode;
        that.collectEventMD({
          productId: that.productId,
          eventStartTime: new Date().getTime(),
          eventId: '2002',
          eventResult: 1,
        });
      }, (err) => {
        if (err.code && err.code != '400101') {
          if (err.message) {
            utils.toastMsg(err.message);
          }
          // 400101用户取消
          that.collectEventMD({
            productId: that.productId,
            eventStartTime: new Date().getTime(),
            eventId: '2002',
            eventResult: 2,
          });
        }
      });
    },
    // 点击身份证国徽面
    backClick (providerInfo) {
      let that = this;
      if (!that.idFront.has) {
        utils.toastMsg('请按顺序完成认证操作');
        return;
      }
      that.$appInvoked('appStartIDCardOCR', {
        data: providerInfo,
        type: 1,
      }, (data) => {
        that.idBack.has = true;
        that.infos.authority = data.authority;
        that.infos.backFullImage = data.backSmallImage;
        that.infos.validDate = data.validDate;
        that.collectEventMD({
          productId: that.productId,
          eventStartTime: new Date().getTime(),
          eventId: '2004',
          eventResult: 1,
        });
      }, (err) => {
        if (err.code && err.code != '400101') {
          if (err.message) {
            utils.toastMsg(err.message);
          }
          // 400101用户取消
          that.collectEventMD({
            productId: that.productId,
            eventStartTime: new Date().getTime(),
            eventId: '2004',
            eventResult: 2,
          });
        }
      });
    },
    // 点击人脸识别
    rlsbClick () {
      let that = this;
      // 判断点击顺序，若身份证正反面未完成，toast提示
      if (!that.idFront.has || !that.idBack.has) {
        utils.toastMsg('请按顺序完成认证操作');
        return;
      }
      // 先调用相机相册权限弹窗，若有权限，继续执行操作，展示提示弹窗
      that.$appInvoked('appAskPermissionStatus', {
        needShowPermissionAlert: true,
        permissions: [1, 2], // 1：相机，2：相册，3：麦克风，4：通讯录，5；短信，6：定位
      }, function (data) {
        let authList = data.permissionAuthorizationStatus;
        let noPmNo = 0;
        for (let i = 0, l = authList.length; i < l; i++) {
          if (authList[i].status != 1) {
            noPmNo++;
          }
        }
        if (noPmNo == 0) {
          that.$refs.pconfirm.show(); // 展示提示弹窗
        }
      });
    },
    // 关闭人脸识别引导框
    closeRlsbConfirm () {
      this.$appInvoked('appExecStatistic', { eventId: 'sfrz;ydkgb;w188' });
    },
    // 立即认证
    authNow () {
      let that = this;
      that.$appInvoked('appExecStatistic', { eventId: 'sfrz;ydkrz;w189' });
      let providerInfo = that.providerInfo;
      that.$appInvoked('appStartFaceRecognition', {
        data: providerInfo,
        type: 1,
      }, () => {
        that.showLoading = true;
        let params = {
          identityCard: that.infos.identityCard,
          identityName: that.infos.identityName,
          orderNo: that.infos.orderNo,
        };
        faceCompareApi(params).then(() => {
          that.showLoading = false;
          that.rlsb.stsTxt = '已认证';
          that.rlsb.stsColor = 'c2';
          that.rlsb.status = 1;
        }, (err) => {
          that.showLoading = false;
          that.rlsb.stsTxt = '未通过';
          that.rlsb.stsColor = 'c3';
          that.rlsb.status = 2;
          if (['1067', '1202'].indexOf(err.respCode) > -1) {
            // 1067-手机号占用，1202-OCR身份证号与同盾实名认证的身份证号不一致
            if (err.respMsg) {
              that.submitFailMsg = err.respMsg;
              that.$nextTick(function () {
                that.$refs.tipsConfirm.show();
                if (err.respCode === '1202') {
                  // 与实名信息不符时，清除ocr人像面信息
                  that.clearFrontInfos()
                }
              });
            }
          }
        });
      }, (err) => {
        if (err.code && err.code != '400101') {
          if (err.message) {
            utils.toastMsg(err.message);
          }
        }
      });
    },
    // 清除人像面信息
    clearFrontInfos () {
      let that = this
      that.idFront.has = false
      that.infos.frontFullImage = ''
      that.identityCard = ''
      that.identityName = ''
    },
    // 返回
    backClickHandle () {
      let that = this;
      that.$refs.pconfirm.hide();
      that.$refs.backComfirm.show();
      // if (that.idFront.has) {
      //   that.$refs.backComfirm.show();
      // } else {
      //   that.$routerGo(-1);
      // }
    },
    // 提交
    submitData () {
      let that = this;
      that.$appInvoked('appExecStatistic', { eventId: 'sfrz;tjan;w187' });
      if (that.rlsb.status != 1) { // 人脸识别不是已认证状态
        return;
      }
      // that.showLoading = true;
      // 上传风控节点
      // that.$appInvoked('appUploadRiskData', { node: 200 });
      that.$appInvoked('appUploadOCRInfo', {
        data: that.providerInfo,
      }, () => {
        // that.showLoading = false;
        // that.$routerGo(-1);
        // 保存成功，判断下一项待填写资料
        that.checkNextFillInfos(that.$route.query.w)
      }, (err) => {
        // that.showLoading = false;
        try {
          err = JSON.parse(err);
        } catch (error) {
          // 
        }
        let data = err.result;
        if (data.respCode && ['1067', '1202'].indexOf(data.respCode) > -1 && data.respMsg) {
          // 1067-手机号占用，1202-OCR身份证号与同盾实名认证的身份证号不一致
          that.submitFailMsg = data.respMsg;
          that.$nextTick(function () {
            that.$refs.tipsConfirm.show();
            if (data.respCode === '1202') {
              // 与实名信息不符时，清除ocr人像面信息
              that.clearFrontInfos()
            }
          });
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
@import 'css/index.scss';
.mescroll {
  background-color: #fff;
}
.split-block {
  height: rc(20);
  background-color: #f5f5f5;
}
#loading {
  bottom: 0;
}
.c1 {
  color: #aaa;
} // 未认证
.c2 {
  color: #333;
} // 已认证
.c3 {
  color: #ff6a6a;
} // 未通过
.color-success {
  color: #fff;
}
.color-default {
  color: $color-main;
}
.ia-card {
  display: flex;
  padding: rc(30 30 0);
  justify-content: space-between;
  line-height: 1.5;
  &-container {
    margin-bottom: rc(30);
    text-align: center;
    width: rc(321);
    &:first-child {
      margin-right: rc(48);
    }
  }
  &-title {
    font-size: rc(30);
    margin-bottom: rc(32);
  }
  &-ctr {
    width: 100%;
    height: rc(200);
    background-color: #f8f8f8;
    border-radius: rc(10);
    position: relative;
  }
  &-content {
    width: 100%;
    height: 100%;
  }
  &-img {
    width: 100%;
    height: 100%;
    border-radius: rc(10);
  }
  &-layer,
  &-mask {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 10;
  }
  &-layer {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }
  &-mask {
    border-radius: rc(10);
    background-color: rgba(0, 0, 0, 0.4);
  }
  &-icon {
    width: rc(80);
    height: rc(80);
  }
  &-tips {
    font-size: rc(26);
    margin-top: rc(10);
  }
}
.ia-info {
  font-size: rc(30);
  padding-left: rc(30);
  &-item {
    height: rc(98);
    display: flex;
    align-items: center;
    padding-right: rc(30);
  }
  &-left {
    flex: 1;
  }
}
.ia-submit {
  margin: rc(70 30 25);
}
.ia-bottom-tips {
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: rc(24);
  color: #ff601a;
  img {
    width: rc(44);
    height: auto;
  }
}
.auth {
  &-ctr {
    padding: rc(30 14 14);
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  &-item {
    text-align: center;
  }
  &-icon {
    width: rc(66);
    height: rc(66);
  }
  &-tips {
    font-size: rc(26);
    color: #333;
    margin-top: rc(22);
  }
}
.tips-confirm {
  font-size: rc(30);
  word-break: break-all;
  text-align: center;
}
</style>
