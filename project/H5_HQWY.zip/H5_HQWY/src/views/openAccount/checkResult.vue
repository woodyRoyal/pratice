<template>
  <PageView type="hqwy-body-white"
            :title="productName">
    <div v-if="status == 1"
         class="hqwy-check-result">
      <div class="result-icon result-icon-fail"></div>
      <div class="result-txt">
        审核失败
      </div>
      <div v-if="nextApplyTime != ''"
           class="result-tips">
        <p>您还可以于<span class="orange-txt">{{ nextApplyTime }}</span>后再次申请<span class="orange-txt">{{ productName }}</span></p>
      </div>
    </div>
    <div v-if="status == 2"
         class="hqwy-check-result">
      <div class="result-icon result-icon-process"></div>
      <div class="result-txt">
        申请已提交，请等待审核结果
      </div>
      <div class="result-tips">
        <p>提交申请时间：{{ applyTime }}</p>
        <p>审核预计需要：{{ applyNeedTime }} 分钟</p>
      </div>
      <div class="result-stip">
        <p>提示：您随时可以在“<span class="orange-txt">我的订单</span>”里查询申请结果</p>
      </div>
    </div>
    <div class="hqwy-btns">
      <CommonButton :btn-data="btnData"
                    @click.native="btnClick()"></CommonButton>
    </div>
  </PageView>
</template>
<script>
import utils from "../../util/utils.js"
import CommonButton from "../../components/button/index"
export default {
  components: {
    CommonButton,
  },
  data () {
    return {
      status: null, // 1:失败 2：成功
      productName: '', // 产品名
      nextApplyTime: '', // 再次可申请时间
      applyTime: '', // 申请时间
      applyNeedTime: '', // 审核预计需要
      btnData: {
        activeFlag: true,
        txt: '申请其它产品',
      },
      eventId: '', // 申请其他产品按钮统计代码
    }
  },
  activated () {
    this.status = this.$route.query.status
    this.productName = this.$route.query.productName
    if (this.status === '1') {
      this.nextApplyTime = utils.formateDate(Number(this.$route.query.nextApplyTime), 'YYYY-MM-DD')
      this.eventId = "shsb;sqqtcp;w193"
    } else if (this.status === '2') {
      this.applyTime = utils.formateDate(Number(this.$route.query.applyTime), 'YYYY-MM-DD hh:mm')
      this.applyNeedTime = this.getApplyTime(this.$route.query.applyNeedTime, this.$route.query.applyTime)
      this.eventId = "tjcg;sqqtcp;w192"
    }
  },
  // mounted () {
  // },
  methods: {
    btnClick () {
      // 点击统计
      this.$appInvoked("appExecStatistic", {
        eventId: this.eventId,
        eventType: 0,
      })
      this.$routerPush('/productlist')
    },
    // 获取申请预计需要时间
    getApplyTime (time1, time2) {
      time1 = Number(time1)
      time2 = Number(time2)
      let time = Math.ceil((time1 - time2) / 60000)
      return time
    },
  },
}
</script>
<style lang="scss" scoped>
.hqwy-body-white {
  height: 100%;
  background-color: #fff;
}
.hqwy-check-result {
  text-align: center;
  .result-icon {
    margin: rc(60) auto rc(10);
    width: rc(162);
    height: rc(140);
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-position: 0 0;
  }
  .result-icon-fail {
    background-image: url(../../../static/images/#{$APP_NAME}/examine_fail2.png);
  }
  .result-icon-process {
    background-image: url(../../../static/images/#{$APP_NAME}/examine_ing.png);
  }
  .result-txt {
    margin-bottom: rc(20);
    font-size: rc(36);
    line-height: rc(50);
    font-weight: bold;
  }
  .result-tips {
    margin-bottom: rc(70);
    font-size: rc(26);
    line-height: rc(36);
    color: #777;
  }
  .orange-txt {
    color: $color-main;
  }
  .result-stip {
    margin-bottom: rc(20);
    font-size: rc(24);
    line-height: rc(34);
    color: #777;
  }
}
.hqwy-btns {
  padding: 0 rc(30);
}
</style>
