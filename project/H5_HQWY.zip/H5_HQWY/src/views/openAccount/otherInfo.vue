<template>
  <PageView title="补充信息"
            :is-back-page="false"
            :show-error-page="showErrorPage"
            :error-page-info="errorPageInfo"
            @backClick="backClickHandle">
    <div class="hqwy-body-white">
      <Tip txt="详细、真实的信息可加快审核，提高额度"></Tip>
      <ul class="hqwy-mod-info">
        <li :class="{'error': btnClickFlag[0] && otherInfo.occur.value == ''}"
            @click="openActionSheet(0,0)">
          <span class="name">职业身份</span>
          <input v-model="otherInfo.occur.value"
                 type="text"
                 class="ipt"
                 placeholder="请选择"
                 readonly>
          <Arrow direction="right"
                 color="#ccc"></Arrow>
        </li>
        <li :class="{'error': btnClickFlag[1] && otherInfo.companyName == ''}"
            class="li-lines">
          <span class="name">单位名称</span>
          <!-- <textarea type="text" class="ipt ipt-lines" :class="{'ipt-error': valueErrorFlag[0], 'ipt-lines-row2': otherInfo.companyName.length > 14}" placeholder="请填写工作单位" v-model.trim="otherInfo.companyName" @input="focusFun(1, otherInfo.companyName)"></textarea> -->
          <XTextarea ref="otherInfoTextarea1"
                     v-model.trim="otherInfo.companyName"
                     name="description"
                     placeholder="请填写工作单位"
                     :autosize="true"
                     :rows="1"
                     :class="{'ipt-error': valueErrorFlag[0]}"
                     @on-change="changeFun(0)"
                     @on-focus="focusFun(1)"></XTextarea>
        </li>
        <li :class="{'error': btnClickFlag[2] && otherInfo.companyCity.name == ''}">
          <span class="item">单位所在城市</span>
          <input v-model="otherInfo.companyCity.name"
                 type="text"
                 class="ipt"
                 readonly
                 placeholder="请选择">
          <XAddress v-model="otherInfo.companyCity.value"
                    :list="addressData"
                    :title="'地址'"
                    class="frontIpt"
                    @on-hide="getName(otherInfo.companyCity)"
                    @on-show="focusFun(2)"></XAddress>
          <Arrow direction="right"
                 color="#ccc"></Arrow>
        </li>
        <li :class="{'error': btnClickFlag[3] && otherInfo.companyDetailAddress == '', 'default-nobb': !addressTips[0]}"
            class="li-lines">
          <span class="name">单位详细地址</span>
          <!-- <textarea type="text" class="ipt ipt-lines" :class="{'ipt-error': valueErrorFlag[1]}" placeholder="请填写详细地址" v-model.trim="otherInfo.companyDetailAddress" @input="focusFun(3, otherInfo.companyDetailAddress)" @focus="addressFocus(0)" @blur="addressBlur(0)"></textarea> -->
          <XTextarea ref="otherInfoTextarea2"
                     v-model.trim="otherInfo.companyDetailAddress"
                     name="description"
                     placeholder="请填写详细地址"
                     :autosize="true"
                     :rows="1"
                     :class="{'ipt-error': valueErrorFlag[1]}"
                     @on-change="changeFun(1)"
                     @on-focus="focusFun(3)"
                     @on-blur="addressBlur(0)"></XTextarea>
        </li>
      </ul>
      <div v-show="addressTips[0]"
           class="address-tips">
        <Tip txt="地址需精确到门牌号，例：幸福路6号幸福小区6幢601室"></Tip>
      </div>
      <div class="hqwy-space"></div>
      <ul class="hqwy-mod-info">
        <li :class="{'error': btnClickFlag[4] && otherInfo.houseCity.name == ''}">
          <span class="item">居住城市</span>
          <input v-model="otherInfo.houseCity.name"
                 type="text"
                 class="ipt"
                 readonly
                 placeholder="请选择">
          <XAddress v-model="otherInfo.houseCity.value"
                    :list="addressData"
                    :title="'地址'"
                    class="frontIpt"
                    @on-hide="getName(otherInfo.houseCity)"
                    @on-show="focusFun(4)"></XAddress>
          <Arrow direction="right"
                 color="#ccc"></Arrow>
        </li>
        <li :class="{'error': btnClickFlag[5] && otherInfo.houseDetailAddress == ''}"
            class="li-lines">
          <span class="name">居住详细地址</span>
          <!-- <textarea type="text" class="ipt ipt-lines" :class="{'ipt-error': valueErrorFlag[2]}" placeholder="请填写详细地址" v-model.trim="otherInfo.houseDetailAddress" @input="focusFun(5, otherInfo.houseDetailAddress)" @focus="addressFocus(1)" @blur="addressBlur(1)"></textarea> -->
          <XTextarea ref="otherInfoTextarea3"
                     v-model.trim="otherInfo.houseDetailAddress"
                     name="description"
                     placeholder="请填写详细地址"
                     :autosize="true"
                     :rows="1"
                     :class="{'ipt-error': valueErrorFlag[2]}"
                     @on-change="changeFun(2)"
                     @on-focus="focusFun(5)"
                     @on-blur="addressBlur(1)"></XTextarea>
        </li>
      </ul>
      <div v-show="addressTips[1]"
           class="address-tips">
        <Tip txt="地址需精确到门牌号，例：幸福路6号幸福小区6幢601室"></Tip>
      </div>
      <div class="hqwy-btns">
        <CommonButton :btn-data="btnData"
                      @click.native="btnClick()"></CommonButton>
      </div>
      <div slot="dialog">
        <!-- 下拉框 -->
        <ActionSheet :is-show="isShow"
                     action-title="职业身份"
                     :action-list="actionList"
                     @onHideAction="isShow = false"
                     @onSelectItem="actionSheetOnSelectItem"></ActionSheet>
        <!-- 下拉框 end-->
        <!-- 返回挽留弹窗 -->
        <FillInfoBackConfirm ref="backComfirm"
                             :source="source"
                             page="QTXX"></FillInfoBackConfirm>
        <!-- 返回挽留弹窗 end -->
        <Loading v-show="showInfo.isLoading"></Loading>
        <VLoad :isload="isLoad"></VLoad>
      </div>
    </div>
  </PageView>
</template>
<script>
import utils from "../../util/utils.js"
import Tip from "../../components/tip/index"
import CommonButton from "../../components/button/index"
import FillInfoBackConfirm from "../../components/confirm/FillInfoBackConfirm"
import Arrow from '../../components/common/arrow.vue'
import ActionSheet from "../../components/action-sheet"
import Loading from "../../components/loading/loading"
import VLoad from "../../components/load.vue"
import { requestCommonDict } from "../../../src/api/controller/common"
import { XTextarea, XAddress, Value2nameFilter as value2name } from 'vux'
import { getOtherInfoApi, saveOtherInfoApi, getCityDataApi } from "../../../src/api/controller/openAccount"
export default {
  components: {
    Tip,
    Arrow,
    CommonButton,
    FillInfoBackConfirm,
    ActionSheet,
    XAddress,
    Loading,
    VLoad,
    // vAbnor,
    XTextarea,
  },
  data () {
    return {
      source: this.$route.query.source, // 页面来源。0-我的>完善贷款信息，1-API产品详情，2-重新智能推荐
      isShow: false,
      isLoad: "none",
      showErrorPage: false,
      errorPageInfo: {},
      showInfo: {
        isLoading: false,
        section: [
          [
            {
              title: "职业身份",
              actionList: [],
              value: -1,
            },
          ],
        ],
      },
      selectPos: {
        section: "",
        index: "",
      },
      actionList: [],
      addressData: [], // 地址数据
      otherInfo: {
        occur: {
          value: '', // 用户选择的值
          id: null, // 用户选择的值对应的id
        },
        companyName: '',
        companyDetailAddress: '',
        houseDetailAddress: '',
        companyCity: {
          value: [],
          name: '',
        },
        houseCity: {
          value: [],
          name: '',
        },
      },
      btnData: {
        activeFlag: false,
        txt: '完成',
      },
      btnClickFlag: [false, false, false, false, false, false], // 记录点击状态
      valueErrorFlag: [false, false, false], // 输入内容格式错误
      addressTips: [false, false], // 详细地址提示
    }
  },
  watch: {
    'otherInfo': {
      handler (val) {
        if (val.occur.value !== '' && val.companyName !== '' && val.companyCity.name !== '' && val.companyDetailAddress !== '' && val.houseCity.name !== '' && val.houseDetailAddress !== '') {
          this.btnData.activeFlag = true
        } else {
          this.btnData.activeFlag = false
        }
      },
      deep: true,
      immediate: true,
    },
  },
  activated () {
    this.interceptAppBack()
    this.showErrorPage = false
    let w = this.$route.query.w
    if (w) {
      this.collectEventMD({
        eventId: `ly1010,w${w}`,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
      })
    }
    this.source = this.$route.query.source
    // 数据重置 不然ui会被缓存
    this.btnClickFlag = [false, false, false, false, false, false]
    this.valueErrorFlag = [false, false, false]
    this.otherInfo.companyName = ''
    this.otherInfo.companyDetailAddress = ''
    this.otherInfo.houseDetailAddress = ''
    this.$refs.backComfirm && this.$refs.backComfirm.hide()
    // 获取城市并缓存
    if (localStorage.getItem('provinceCityArea') == null) {
      this.getCityDataFun()
    }
    this.getdictList()
    this.collectEventMD({
      eventEndTime: '',
      eventId: '1010',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
      productId: this.$route.query.productId || '',
    })
  },
  created: function () {
    let addressDataTimer = setInterval(() => {
      if (localStorage.getItem('provinceCityArea')) {
        // 从本地存储获取地址源数据
        this.addressData = JSON.parse(localStorage.getItem('provinceCityArea'))
        clearInterval(addressDataTimer)
      }
    }, 10)
  },
  methods: {
    // 获取城市数据
    getCityDataFun () {
      this.isLoad = "block";
      getCityDataApi({}).then((data) => {
        this.isLoad = "none";
        if (data.respCode === "1000") {
          let allArr = data.body
          let provinceArr = []
          let cityArr = []
          let areaArr = []
          let cityArrAll = []
          let areaArrAll = []
          let resultArr = []
          for (let i = 0; i < allArr.length; i++) {
            provinceArr[i] = {
              name: allArr[i].name,
              value: allArr[i].provinceId + '',
            }
            for (let j = 0; j < allArr[i].cityInfoList.length; j++) {
              cityArr[j] = {
                name: allArr[i].cityInfoList[j].cityName,
                value: allArr[i].cityInfoList[j].cityId + '',
                parent: allArr[i].provinceId + '',
              }
              cityArrAll = cityArrAll.concat(cityArr[j])
              for (let z = 0; z < allArr[i].cityInfoList[j].districtInfoList.length; z++) {
                areaArr[z] = {
                  name: allArr[i].cityInfoList[j].districtInfoList[z].districtName,
                  value: allArr[i].cityInfoList[j].districtInfoList[z].districtId + '',
                  parent: allArr[i].cityInfoList[j].cityId + '',
                }
                areaArrAll = areaArrAll.concat(areaArr[z])
              }
            }
          }
          resultArr = resultArr.concat(provinceArr).concat(cityArrAll).concat(areaArrAll)
          localStorage.setItem('provinceCityArea', JSON.stringify(resultArr))
        }
      }).catch(() => {
        this.isLoad = "none";
      })
    },
    // 城市地址转换
    getName (obj) {
      obj.name = value2name(obj.value, this.addressData)
    },
    //数据字典接口
    getdictList () {
      var self = this;
      self.isLoad = "block"; //开始loading
      requestCommonDict({}).then(
        (repData) => {
          self.isLoad = "none";
          if (repData.respCode === "1000") {
            self.showInfo.section[0][0].actionList = repData.body.career;
          }
          self.requestUserInfo();
        },
        () => {
          self.isLoad = "none";
          // self.showErrorPage = true;
        }
      );
    },
    // 关系返显
    relationTranslate (index, obj) {
      // index 是数组索引 obj是对应的赋值对象
      if (obj.id !== null) {
        this.showInfo.section[0][index].actionList.forEach((element) => {
          if (element.dictValue === obj.id) {
            obj.value = element.dictName
          }
        })
      } else {
        obj.value = ''
      }
    },
    actionSheetOnSelectItem: function (item, index) {
      this.isShow = false;
      if (index < 0) {
        return;
      }
      this.otherInfo.occur.value = item.dictName
      this.otherInfo.occur.id = item.dictValue
    },
    openActionSheet: function (section, index) {
      this.isShow = true;
      this.curSelect = index
      this.selectPos.section = section;
      this.selectPos.index = index;
      this.actionList = this.showInfo.section[section][index].actionList;
      this.$set(this.btnClickFlag, index, false)
    },
    // 错误文案逻辑
    changeFun (index) {
      this.$set(this.valueErrorFlag, index, false)

      this.$refs.otherInfoTextarea1.updateAutosize()
      this.$refs.otherInfoTextarea2.updateAutosize()
      setTimeout(() => {
        this.$refs.otherInfoTextarea3.updateAutosize()
      }, 5)
    },
    // 错误红线逻辑
    focusFun (index) {
      this.$set(this.btnClickFlag, index, false)
      if (index === 3) {
        this.$set(this.addressTips, 0, true)
      } else if (index === 5) {
        this.$set(this.addressTips, 1, true)
      }
    },
    addressBlur (index) {
      this.$set(this.addressTips, index, false)
    },
    // 获取联系人信息
    requestUserInfo () {
      getOtherInfoApi({}).then((data) => {
        this.showErrorPage = false
        if (data.respCode === "1000") {
          let workInfo = data.body.otherInfoVo.workInfoVo
          let homeInfo = data.body.otherInfoVo.homeInfoVo
          this.otherInfo.occur.id = workInfo.career
          this.otherInfo.companyName = workInfo.unitsName || ''
          this.otherInfo.companyDetailAddress = workInfo.unitsAddress || ''
          this.otherInfo.houseDetailAddress = homeInfo.homeAddress || ''
          this.relationTranslate(0, this.otherInfo.occur)
          this.otherInfo.companyCity.value[0] = workInfo.unitsProvince ? workInfo.unitsProvince + '' : ''
          this.otherInfo.companyCity.value[1] = workInfo.unitsCity ? workInfo.unitsCity + '' : ''
          this.otherInfo.companyCity.value[2] = workInfo.unitsDistrict ? workInfo.unitsDistrict + '' : ''
          this.otherInfo.houseCity.value[0] = homeInfo.homeProvince ? homeInfo.homeProvince + '' : ''
          this.otherInfo.houseCity.value[1] = homeInfo.homeCity ? homeInfo.homeCity + '' : ''
          this.otherInfo.houseCity.value[2] = homeInfo.homeDistrict ? homeInfo.homeDistrict + '' : ''
          // 城市反显
          let addressDataTimer = setInterval(() => {
            if (this.addressData && this.addressData.length > 0) {
              this.getName(this.otherInfo.companyCity)
              this.getName(this.otherInfo.houseCity)
              clearInterval(addressDataTimer)
            }
          }, 100)

          this.$refs.otherInfoTextarea1.updateAutosize()
          this.$refs.otherInfoTextarea2.updateAutosize()
          setTimeout(() => {
            this.$refs.otherInfoTextarea3.updateAutosize()
          }, 5)

          this.showErrorPage = false
        }
      }).catch(() => {
        this.showErrorPage = true
        this.initDefaultErrorPageInfos('offline')
      })
    },
    saveUserInfo () {
      // 上传风控节点
      // this.$appInvoked('appUploadRiskData', { node: 202 })

      this.showInfo.isLoading = true
      let params = {
        otherInfoVo: {
          homeInfoVo: {
            homeAddress: this.otherInfo.houseDetailAddress,
            homeCity: this.otherInfo.houseCity.value[1],
            homeCityMsg: this.otherInfo.houseCity.name.split(' ')[1],
            homeDistrict: this.otherInfo.houseCity.value[2],
            homeDistrictMsg: this.otherInfo.houseCity.name.split(' ')[2],
            homeProvince: this.otherInfo.houseCity.value[0],
            homeProvinceMsg: this.otherInfo.houseCity.name.split(' ')[0],
          },
          workInfoVo: {
            career: this.otherInfo.occur.id,
            unitsAddress: this.otherInfo.companyDetailAddress,
            unitsCity: this.otherInfo.companyCity.value[1],
            unitsCityName: this.otherInfo.companyCity.name.split(' ')[1],
            unitsDistrict: this.otherInfo.companyCity.value[2],
            unitsDistrictName: this.otherInfo.companyCity.name.split(' ')[2],
            unitsName: this.otherInfo.companyName,
            unitsProvince: this.otherInfo.companyCity.value[0],
            unitsProvinceName: this.otherInfo.companyCity.name.split(' ')[0],
          },
        },
      }
      saveOtherInfoApi(params).then((data) => {
        this.showInfo.isLoading = false
        if (data.respCode === "1000") {
          // 返回至“产品详情页” todo
          this.$appInvoked('appToastMessage', { 'message': '保存成功！' })
          // 保存成功，判断下一项待填写资料
          this.checkNextFillInfos(this.$route.query.w)
          // this.$routerGo(-1);
        }
      }).catch((error) => {
        this.showInfo.isLoading = false
        if (error.respCode !== '1001') {
          utils.toastMsg(error.respMsg)
        }
        // utils.toastMsg("保存失败！请重试")
      })
    },
    // 点击按钮
    btnClick () {
      // 点击统计
      this.$appInvoked("appExecStatistic", {
        eventId: "qtxx;bc;w191",
        eventType: 0,
      })
      // 非空校验
      this.clickFlagFun(this.otherInfo.occur.value, 0)
      this.clickFlagFun(this.otherInfo.companyName, 1)
      this.clickFlagFun(this.otherInfo.companyCity.name, 2)
      this.clickFlagFun(this.otherInfo.companyDetailAddress, 3)
      this.clickFlagFun(this.otherInfo.houseCity.name, 4)
      this.clickFlagFun(this.otherInfo.houseDetailAddress, 5)
      // 数据校验
      if (this.btnData.activeFlag) {
        // 校验单位名称、详细地址
        let checkCompanyNameResult = this.checkRule(2, 0, this.otherInfo.companyName)
        let checkCompanyDetailAddressResult = this.checkRule(4, 1, this.otherInfo.companyDetailAddress)
        let checkHouseDetailAddressResult = this.checkRule(4, 2, this.otherInfo.houseDetailAddress)
        if (!checkCompanyNameResult || !checkCompanyDetailAddressResult || !checkHouseDetailAddressResult) {
          utils.toastMsg('请将错误信息修改后，再提交')
          return
        }
        // 校验通过 保存信息
        this.saveUserInfo()
      }
    },
    // 记录点击状态
    clickFlagFun (obj, index) {
      obj === '' ? this.$set(this.btnClickFlag, index, true) : this.$set(this.btnClickFlag, index, false)
    },
    // 单位姓名校验
    checkRule (len, index, value) {
      // len 字符长度
      // index 对应的valueErrorFlag的索引
      // value 要校验的
      // 汉字、字母、数字这三类合法字符加起来字符长度必须>len
      // 单位名称需要大于2 详细地址需要大于4
      let emojiReg = /\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g
      let reg = /[\u4E00-\u9FA50-9a-zA-Z]/g
      if (!emojiReg.test(value) && value.match(reg) && value.match(reg).length > len) {
        return true
      } else {
        this.$set(this.valueErrorFlag, index, true)
        return false
      }
    },
    // 返回展示挽留弹窗
    backClickHandle () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'qtxx;fh;w301',
      })
      this.$refs.backComfirm.show()
      // if (this.otherInfo.occur.value !== '' || this.otherInfo.companyName !== '' || this.otherInfo.companyCity.name !== '' || this.otherInfo.companyDetailAddress !== '' || this.otherInfo.houseCity.name !== '' || this.otherInfo.houseDetailAddress !== '') {
      //   this.$refs.backComfirm.show()
      // } else {
      //   this.backConfirmCancel()
      // }
    },
  },
}
</script>
<style lang="scss" scoped>
.hqwy-body-white {
  height: 100%;
  background-color: #fff;
}
.hqwy-space {
  height: rc(20);
  background-color: #f5f5f5;
}
.hqwy-mod-info {
  padding: 0 0 0 rc(30);
  font-size: rc(30);
  color: #333;
  .name {
    width: rc(210);
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
  }
  li {
    display: flex;
    position: relative;
    padding-right: rc(30);
    height: rc(98);
    align-items: center;
    overflow: hidden;
    &::before {
      content: '';
      height: 1px;
      left: 0;
      position: absolute;
      right: 0;
      border-bottom: 1px solid #ddd;
      bottom: 0;
      transform: scaleY(0.5);
      transform-origin: 0 0;
    }
    .ipt {
      flex: 1;
      width: rc(480);
      height: 100%;
      text-align: right;
    }

    .ipt-disabled {
      color: #999;
    }
    .ipt-error {
      color: #ff4c4c;
    }
    .placeholder-error {
      &::-webkit-input-placeholder {
        color: red;
      }
    }
    .frontIpt {
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      height: rc(98);
      opacity: 0;
      z-index: 2;
    }
  }
  li.default-nobb {
    &::before {
      border-color: #fff;
    }
  }
  li.error {
    &::before {
      border-color: #ff4c4c;
    }
  }
  li.is-link {
    padding-right: rc(60);
    &:after {
      content: '';
      position: absolute;
      right: rc(30);
      top: 50%;
      margin-top: rc(-13);
      width: rc(14);
      height: rc(26);
      background-color: pink;
    }
  }
  li.li-lines {
    padding-top: rc(25);
    padding-bottom: rc(25);
    min-height: rc(46);
    height: auto;
    align-items: flex-start;
    .ipt-lines::-webkit-input-placeholder {
      color: #aaa;
    }
    .ipt-lines-row2 {
      padding-bottom: rc(20);
    }
  }
}
.address-tips {
  padding-top: rc(6);
  .hqwy-tip {
    background-color: #fff;
  }
}
.hqwy-btns {
  margin-top: rc(80);
  padding: 0 rc(30);
}
</style>
<style lang="scss">
.li-lines .vux-x-textarea.weui-cell {
  flex: 1;
  padding: 0;
  &::before {
    border-top: 0;
  }
  .weui-textarea {
    text-align: right;
  }
}
.scroller-item {
  white-space: nowrap;
}
</style>
