<template>
  <PageView title=""
            :show-left="false"
            class="mycenterpage">
    <div class="mycenter mescroll">
      <header class="header"
              :class="{'header-fixed': topFixed}">
        <img :src="quitShow?loginAvatar:logoutAvatar"
             :class="[topFixed?'avater':'avater-big']"
             alt="">
        <div @click="loginClickHandler('wd;ljdl;w111', 111)">
          <h2>
            {{ quitShow?numberOne:'登录' }}<span v-if="!quitShow"
                                               class="arrowhead"></span>
          </h2>
          <p v-show="!topFixed"
             class="tip">
            {{ quitShow?'亲爱的用户，你好！':'立即登录，解锁更多功能' }}
          </p>
        </div>
        <span class="more"
              @click="getNextPage('/myMore', '', '')"></span>
      </header>
      <div :class="{'order-content-top':topFixed}"></div>
      <!-- <div class="content order-content"
           :class="{'order-content-top':topFixed}">
        <div class="my-order">
          <ul>
            <li class="order-title">
              <span class="order-title-left">我的订单</span>
              <div class="order-title-right"
                   @click="getNextPage('/order?type=0','wd;wddd;qb;w244', 244)"><span>全部</span><i></i></div>
            </li>
          </ul>
          <div class="order-type-list">
            <div class="order-type"
                 v-for="(item, index) in tabList"
                 v-show="index > 0"
                 :key="index"
                 @click="getNextPage('/order?type=' + item.remarkType, item.point, item.w)">
              <div class="order-type-icon">
                <img :src="item.icon"
                     alt="">
                <div class="over-due"
                     v-if="item.remarkType==3&&overDue"></div>
                <div class="order-type-count"
                     v-else-if="item.count > 0&&item.remarkType!=0"
                     v-text="item.count > 99 ? 99 : item.count"
                     lang="zh-CN"></div>
              </div>
              <div class="order-type-title"
                   v-text="item.remarkName"></div>
            </div>
          </div>
        </div>
      </div> -->
      <!-- 逾期 -->
      <!-- <repay-order type="repay-order-list"
                    :list="repayList"
                    @repayClick="repayClick"></repay-order> -->
      <!-- 原立即贷还款（立即借特有） -->
      <transition name="fade">
        <div class="ljd-repay-box">
          <div v-if="quitShow && showLjdRepay && !isMjb"
               class="ljd-repay-ctr">
            <div class="jrcs-left">
              <p class="jrcs-tip">
                <img class="img"
                     :src="require('APP_IMG/prompt.png')" />温馨提示
              </p>
              <p>您原立即贷有一笔借款待还！</p>
            </div>
            <div class="jrcs-btn"
                 @click="ljdRepayClick()">
              立即还款
            </div>
          </div>
        </div>
      </transition>
      <div :class="['content', 'content-tools', {'mt20': !(quitShow && showLjdRepay)}]">
        <!--<div class="module-hd">-->
        <!--<h2>常用工具</h2>-->
        <!--</div>-->
        <ul>
          <li @click="getNextPage('/myBankList','wd;wdyhk;w243', 243)">
            <img class="img"
                 :src="require('APP_IMG/mine_icon_card.png')" />
            <span>我的银行卡</span>
          </li>
          <li @click="getNextPage('/fillLoanInfo','wd;wsdkxx;w195', 195)">
            <img class="img"
                 :src="require('APP_IMG/mine_icon_data.png')" />
            <span>完善信息</span>
            <div class="right">
              <HyTag :text="dataInvalid?'已失效':'高通过'"
                     :custom-made-style="{color:'#fff',backgroundColor:'#EA3323'}"></HyTag>
            </div>
          </li>
          <li v-show="hasAuditPass"
              @click="getNextPage('/browseRecord','wd;lljl;w114', 114)">
            <img class="img"
                 :src="require('APP_IMG/mine_icon_record.png')" />
            <span>浏览记录</span>
          </li>
          <!-- <li v-show="hasAuditPass"
              @click="openThirdPage('信用报告', creditReport)">
            <img class="img"
                 :src="require('APP_IMG/mine_icon_report.png')" />
            <span>信用报告</span>
          </li>
          <li v-show="hasAuditPass"
              @click="openThirdPage('被拒查询', blackCheck)">
            <img class="img"
                 :src="require('APP_IMG/mine_icon_blacklist.png')" />
            <span>被拒查询</span>
          </li> -->
          <li v-show="hasAuditPass"
              @click="toHelpCenter(342,'wd;wyts;w342','helpcenterAsk')">
            <img class="img"
                 :src="require('APP_IMG/mine_icon_complain.png')" />
            <span>我要投诉</span>
          </li>
          <li v-show="hasAuditPass"
              @click="getNextPage('/mycoupon','wd;yhq;w113', 113)">
            <img class="img"
                 :src="require('APP_IMG/mine_icon_coupon.png')" />
            <span>我的优惠券</span>
            <HyTag v-if="quitShow && couponCount>0"
                   :text="couponCount"
                   :custom-made-style="{color:'#fff',backgroundColor:'#EA3323'}"></HyTag>
          </li>
          <li @click="toHelpCenter(242,'wd;yjfk;w242','helpcenterHome')">
            <img class="img"
                 :src="require('APP_IMG/mine_icon_help.png')" />
            <span>帮助与反馈</span>
          </li>
        </ul>
      </div>
      <div v-if="hasAuditPass && !isEmptyObject(advertisement)"
           class="bg-color-fff">
        <img class="advertisement"
             :src="advertisement.img"
             alt=""
             @click="onAdClick(advertisement)">
      </div>
      <div v-if="hasAuditPass && lists.length>0"
           class="recommend"
           :class="{'mt20': isEmptyObject(advertisement)}">
        <div class="module-hd">
          <h2>为您推荐</h2>
          <div class="module-hd-r"
               @click="goProductlist">
            <span>更多</span>
            <i></i>
          </div>
        </div>
        <ProductList :list="lists"
                     @on-click="onProductClick"></ProductList>
      </div>
    </div>
    <VLoad :isload="isLoad"></VLoad>
    <BasicInfo ref="basicInfo"></BasicInfo>
    <!-- <get-api-data ref="getApiData"></get-api-data> -->
    <!-- 过审判断 -->
    <AuditPass ref="auditPass"></AuditPass>
  </PageView>
</template>

<script>
import ProductList from '@/components/product/ProductList'
import HyTag from "@/components/tag/index";
import VLoad from "@/components/load.vue";
import BasicInfo from "@/components/basicInfo/index"
// import repayOrder from "@/components/order/repay.vue";
import { mapActions } from "vuex";
import { requestCategory } from "@/api/controller/categoryLoan";
// import getApiData from '@/components/function/getRepayOrderInfo'
import {
  // queryStatusApi,
  updateStatusApi,
} from "@/api/controller/common/index";
import { loanEntryQueryApi } from "@/api/controller/openAccount/index";
import AuditPass from '@/components/function/hasAuditPass'
// import { requestRecommendList } from "@/api/controller/recommendList";
import { mytabApi } from '@/api/controller/home'
import { ljdAllClearApi } from "@/api/controller/repay/repay";
import { requestJoinLogin } from "@/api/controller/product";
import utils from "../util/utils.js";
import eventCtr from "../../static/js/eventCtr"
/* eslint-disable eqeqeq */
export default {
  components: {
    ProductList,
    HyTag,
    VLoad,
    BasicInfo,
    // repayOrder,
    // getApiData,
    AuditPass,
  },
  data () {
    return {
      isMjb: false, // 是否马甲包
      showLjdRepay: false, // 展示立即贷还款入口
      nameIdcardEditAll: false, // 姓名身份证号已填写标识
      advertisement: {}, // 硬广位信息
      blackCheck: { // 黑名单检测
        address: '',
        linkId: '',
        productId: '',
      },
      creditReport: { // 信用报告
        address: '',
        linkId: '',
        productId: '',
      },
      topFixed: false,
      lists: [],
      quitShow: false, // 是否登录
      token: "",
      phone: "",
      couponCount: "", //优惠券数量
      isLoad: "none", //默认页面没有loading动画
      // appVersion: "",
      loginAvatar:
        require('APP_IMG/mine_img_head2.png'),
      logoutAvatar:
        require("../../static/images/mine_img_head1.png"),
      loginClicked: false,
      // orderDotRemark: {
      //   remark: false,
      //   overDue: false
      // },
      repayList: [], // 待还款订单列表
      overDue: false,
      tabList: [
        { remarkType: 0, remarkName: '全部', count: 0, point: 'wd;wddd;qb;w244', icon: '' },
        { remarkType: 1, remarkName: '审核中', count: 0, point: 'wd;wddd;shz;w245', w: 245, icon: require(`APP_IMG/mine_order_examine.png`) },
        { remarkType: 2, remarkName: '待提现', count: 0, point: 'wd;wddd;dtx;w246', w: 246, icon: require(`APP_IMG/mine_order_loan.png`) },
        { remarkType: 3, remarkName: '待还款', count: 0, point: 'wd;wddd;dhk;w247', w: 247, icon: require(`APP_IMG/mine_order_repayment.png`) },
        { remarkType: 4, remarkName: '已结束', count: 0, point: 'wd;wddd;yjs;w248', w: 248, icon: require(`APP_IMG/mine_order_end.png`) },
      ],
      dataInvalid: false, // 完善贷款信息资料失效
      hasAuditPass: false, // 是否已过审
    };
  },
  computed: {
    numberOne () {
      return this.phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
    },
    isLogin () {
      return this.$store.state.login.isLogin;
    },
  },
  activated () {
    this.topFixed = false
    var self = this;
    // self.lists = []
    // self.advertisement = {}
    self.collectEventMD({
      eventId: 'jr1006',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
    })
    // 安卓点击物理返回键退出
    if (isAndroid) {
      self.$appInvoked('appCleanWeb', { history: true })
    }
    let loginoutnow = localStorage.getItem('loginoutnow');
    if (loginoutnow && loginoutnow == 1) {
      localStorage.removeItem('loginoutnow');
      location.reload();
      setTimeout(() => {
        // 延迟1秒再去取，防止页面没有初始化好
        self.$appInvoked("appGetAjaxHeader", {}, function (data) {
          self.setHeaderInfo && self.setHeaderInfo(data);
        });
      }, 1000);
    }
    self.$nextTick(function () {
      // self.getMyTab()
      self.$appInvoked("appGetUserToken", {}, function (data) {
        self.token = data;
        if (data != "" && data != null) {
          self.quitShow = true;
          self.getCouponCount(); //获取优惠券数量
          // self.$refs.basicInfo.queryStatusFunc();
          // self.getRepayList()
          // self.queryOrderStatus()
          self.loanEntryQueryFunc()
        } else {
          self.quitShow = false;
        }
      });
      self.$appInvoked("appGetMobilephone", {}, function (data) {
        self.phone = data;
        self.$store.commit("PHONE_NUMBER", data);
      });
    });

    window.vueApp = this;

    // let orderDotRemark = self.$store.state.redPoint.orderDotRemark;
    // self.orderDotRemark = orderDotRemark;

    self.$refs.auditPass.init(false, () => {
      self.hasAuditPass = true
      self.getMyTab()
    }, () => {
      self.hasAuditPass = false
    })

    this.$appInvoked("appGetBundleId", {}, (rst) => {
      this.isMjb = (rst === 'com.sl.hhsc') || (+rst > 1000) || (+rst < 0);
    })
  },
  mounted () {
    let that = this;
    // 获取姓名和身份证是否已填写
    eventCtr.$on("nameIdcardEditAll", (msg) => {
      this.nameIdcardEditAll = msg
    });
    let scrollTop = 0;
    document.querySelector('.hyapp-content').onscroll = function () {
      scrollTop = this.scrollTop
      if (scrollTop == 0) {
        that.topFixed = false
      } else {
        that.topFixed = true;
      }
    }
    if (that.$config.get('productId') === 903) {
      that.showLjdRepay = localStorage.getItem('SHOW_LJJ_REPAY') === '2'
    }
  },
  methods: {
    ljdRepayClick () {
      let that = this
      that.checkAllClear((rst) => {
        that.showLjdRepay = rst.clear === '2'
        localStorage.setItem('SHOW_LJJ_REPAY', rst.clear)
        if (rst.clear === '1') {
          utils.toastMsg('您的原立即贷借款已还清')
        } else {
          that.$appInvoked('appOpenWebview', {
            url: rst.url,
            nav: {
              hide: true,
            },
          })
        }
      })
    },
    checkAllClear (cb) {
      ljdAllClearApi({}).then((repData) => {
        if (repData.respCode === "1000") {
          cb && cb(repData.body)
        }
      })
    },
    // 硬广位点击
    onAdClick (item) {
      let that = this
      let category = 28, w = 273 // 分类及埋点相关数据
      if (item.clickType == '2') {
        // 跳转指定链接
        that.mineNeedUserLogin(w + 1, () => {
          let eventId = `zdlj;w${w + 1};p0;l${item.linkAddressId}`
          that.$appInvoked('appExecStatistic', { eventId: eventId });
          // that.clickReport(item.id, category, eventId);
          that.collectEventMD({
            eventId: eventId,
            eventResult: 1,
            eventStartTime: new Date().getTime(),
          })
          that.jrcsOpenAppPage(w + 1, item.linkAddress, item.mainTitle)
        })
      } else {
        that.proListClick(item.name, item.address, item.id, w, 1, item.type, category, item.linkSeqId, item)
      }
    },
    goProductlist () {
      this.$routerPush('/productlist')
    },
    onProductClick (item, index) {
      this.proListClick(item.name, item.address, item.id, 327, (index + 1), item.type, 12, item.linkSeqId, item)
    },
    // 点击产品列表
    proListClick (name, url, id, w, p, goFlag, category, linkSeqId, item) {
      let that = this
      category = category || 12
      that.mineNeedUserLogin(w, () => {
        // 是否支持api
        if (item.supportApiLoan) {
          let tourl = `?category=${category}&productId=${id}&productName=${name}&p=${p}&w=${w}&supportJoinLogin=${item.supportJoinLogin}&t=${item.rank}`
          let eventId = `chanpin0;w${w};p${p};c${id};l${window.$config.get('events.linkSeqId')};t${item.rank}`;
          that.clickReport(id, category, eventId);
          that.$appInvoked("appExecStatistic", {
            eventId: eventId,
            eventType: 2,
          }); //添加埋点
          // 姓名和身份证号是否已填写
          // console.log(that.nameIdcardEditAll)
          if (!that.nameIdcardEditAll) {
            that.$refs.basicInfo.getBasicInfoFun((nameIdcardEditAll) => {
              if (nameIdcardEditAll) {
                // 已填写 去撞库
                that.$routerPush('/loanHit' + tourl)
              } else {
                // 未填写去基本信息补充页
                that.$routerPush('/basicInfo' + tourl)
              }
            })
          } else {
            // 已填写 去撞库
            that.$routerPush('/loanHit' + tourl)
          }
        } else {
          that.clickFun(name, url, id, w, p, goFlag, category, linkSeqId, item)
        }
      })
    },
    clickFun (name, url, productId, w, p, goFlag, category, linkSeqId, proObj) {
      var self = this;
      //url 产品跳转链接
      //id 产品id
      //eventid 统计代码
      category = category || 12;
      // chanpin0进入产品详情页，chanpin1进入H5落地页，chanpin2阻止用户申请
      let eventId = `chanpin0;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
      if (goFlag == 2) { // 0-产品详情，2-第三方注册页
        eventId = `chanpin1;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
        let supportJoinLogin = proObj.supportJoinLogin; // 是否支持联登
        if (supportJoinLogin) { // 支持联合登录
          self.isLoad = 'block';
          let params = {
            linkId: linkSeqId,
            productId: productId,
          };
          requestJoinLogin(params).then((data) => {
            self.isLoad = 'none';
            if (data.respCode === '1000') {
              data = data.body;
              let regStatus = data.regStatus;
              // 0-未知 1-注册失败 2-金融超市注册成功 3-失败：其他渠道已有用户
              if (regStatus == 2) {
                self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
              } else if (regStatus == 3) {
                utils.toastMsg(`您已注册过${name}，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              } else {
                utils.toastMsg(`${name}系统维护中，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              }
            } else {
              utils.toastMsg(`${name}系统维护中，请申请其他产品`);
              eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
              self.clickReport(productId, category, eventId);
            }
            self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
          }, () => {
            self.isLoad = 'none';
          });
        } else {
          // type = 1;
          // 打开第三方注册页
          self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
          self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
        }
      } else {
        self.clickReport(productId, category, eventId);
        self.$routerPush(
          "/productDetail/" +
          category +
          "/" +
          productId +
          "?p=" +
          p +
          "&w=" +
          w +
          "&supportJoinLogin=" +
          proObj.supportJoinLogin + '&t=' + proObj.rank
        );
        self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
      }
      self.$appInvoked("appOnPageEnd", { pageName: this.$route.meta.title });
      window.currentPageName = this.$route.meta.title;
    },
    // 打开第三方页面
    openThirdPage (name, item) {
      let that = this
      let w = ''
      // 1：黑名单检测 2：信用报告
      if (item.type === 1) {
        w = 276
      } else if (item.type === 2) {
        w = 275
      }
      that.mineNeedUserLogin(w, () => {
        if (w) {
          let eventId = `chanpin1;w${w};p0;c${item.productId};l${item.linkId};t0`
          that.clickReport(item.productId, 12, eventId);
          that.$appInvoked("appExecStatistic", {
            eventId: eventId,
            eventType: 2,
          })
        }
        that.$appInvoked('appOpenWebview', {
          url: item.address,
          nav: {
            title: {
              text: name,
            },
          },
        })
      })
    },
    //jsbridge在原生生命周期中会调这个方法，如果从原生跳回h5刷选刷新数据可以在这个方法中调用
    webviewWillAppear () {
      // console.log("---->webviewWillAppear");
      var self = this;
      // self.$nextTick(function () {
      self.$appInvoked("appGetUserToken", {}, function (data) {
        self.token = data;
        if (data != "" && data != null) {
          self.quitShow = true;
          // self.getCouponCount(); //获取优惠券数量
          // self.$refs.basicInfo.queryStatusFunc();
          //
          // 立即借判断是否展示还款入口
          if (self.$config.get('productId') === 903 && localStorage.getItem('SHOW_LJJ_REPAY') == '2') {
            self.showLjdRepay = true
          } else {
            self.showLjdRepay = false
          }
        }
      });
      self.$appInvoked("appGetMobilephone", {}, function (data) {
        self.phone = data;
        self.$store.commit("PHONE_NUMBER", data);
      });

      // console.warn("-------->" + self.isLogin);
      // });
    },
    ...mapActions(["setHeaderInfo"]),
    getNextPage (pageName, eventid, w) {

      var self = this;
      if (eventid) {
        self.$appInvoked("appExecStatistic", {
          eventId: eventid,
          eventType: 0,
        }); //埋点
      }
      if (['/fillLoanInfo', '/browseRecord', '/mycoupon', '/order', '/myBankList'].indexOf(pageName) > -1 || pageName.indexOf('/order?type=') > -1) {
        //完善贷款信息 要先判断登录是否
        self.mineNeedUserLogin(w, () => {
          if (pageName === '/order?type=4') { // 已结束，标记已读
            self.updateStatus(4, () => {
              self.tabList[4].count = 0
            })
          } else if (pageName === '/fillLoanInfo') {
            pageName += `?w=195`
          }
          self.$routerPush(pageName)
        })
      } else {
        self.$routerPush(pageName);
      }
    },
    loginClickHandler (eventid, w) {
      if (this.loginClicked) {
        return;
      }
      this.loginClicked = true;
      setTimeout(() => {
        this.loginClicked = false;
      }, 500);
      this.$appInvoked("appExecStatistic", {
        eventId: eventid,
        eventType: 0,
      }); //埋点
      if (this.quitShow) {
        // 已登录
        return
      }
      this.needUserLogin(w, () => {
        setTimeout(() => {
          window.location.reload()
        }, 1000)
      })
    },
    // 打开帮助中心和我要投诉
    toHelpCenter (w, eventId, name) {
      this.$appInvoked("appExecStatistic", {
        eventId: eventId,
        eventType: 0,
      });
      name = `url.${name}`
      this.mineNeedUserLogin(w, () => {
        this.$appInvoked('appGetAjaxHeader', {}, (rst) => {
          this.$appInvoked('appOpenWebview', {
            url: `${window.$config.get(name)}&productId=${window.$config.get('productId')}&token=${rst.token}&version=${rst.version}`,
            enableBackHistory: true,
            nav: {
              title: {
                text: '帮助与反馈',
              },
            },
          })
        })
      })
    },
    // 我的页面调用登录判断，需调用当前页面的webviewWillAppear更新页面状态
    mineNeedUserLogin (w, cb) {
      this.needUserLogin(w, () => {
        this.webviewWillAppear()
        cb && cb()
      })
    },
    //获取优惠券数量
    getCouponCount () {
      var self = this;
      var param = {
        category: 14,
      };
      var myDate = new Date();
      var dates = myDate.toLocaleDateString();
      var couponCountObj = JSON.parse(localStorage.getItem("hasClickedObj")) || {}
      var listLength = couponCountObj['date'] === dates ? couponCountObj['list'].length : 0
      requestCategory(param).then(
        (data) => {
          var repData = data;
          if (repData.respCode === "1000") {
            if (repData.body != null && repData.body.page.length > 0) {
              self.couponCount = repData.body.page.length - listLength;
            } else {
              self.couponCount = "";
              // self.reloadText = {
              // 	"reloadText": "暂无优惠券",
              // 	"defaultImg": this.getCachedImages('productIcon')
              // };
              // self.isShow = true;
            }
          }
        }
      );
      setTimeout(function () {
        self.isLoad = "none"; //loading结束
      }, 500);
    },
    repayClick (item, index) {
      var self = this
      let eventId = `huankuan;w249;p${index + 1};c${item.productId}`
      self.$appInvoked('appExecStatistic', { eventId: eventId, eventType: 2 });
      self.clickReport(item.productId, '12', eventId);
      self.$routerPush(`/order/detail?productId=${item.productId}&productName=${item.productName}&w=249&p=${index + 1}&orderNo=${item.orderNo}&loanOrderNo=${item.loanOrderNo}`)
    },
    // 获取还款列表数据
    // getRepayList () {
    //   var that = this
    //   that.repayList = []
    //   that.$refs.getApiData.getRepayOrderInfo({}, data => {
    //     let repayList = data.body
    //     if (repayList && repayList.length > 0) {
    //       that.repayList = repayList
    //       that.$set(that.repayList, 0, data.body[0]);
    //     }
    //   }, err => { })
    // },
    // 我的页面接口
    getMyTab () {
      let that = this
      mytabApi({ mobilePhone: that.phone }).then((data) => {
        data = data.body || {}
        that.advertisement = data.advertisement // 硬广位信息
        let list = data.page // 产品列表
        if (list && list.length > 0) {
          that.lists = that.formateProductList(list)
        }
        let tools = data.blackCheckCreditReportVOList || [] // 黑名单检测和信用报告获取的相关信息
        for (let i = 0; i < tools.length; i++) {
          // 1：黑名单检测 2：信用报告
          if (tools[i].type === 1) {
            that.blackCheck = tools[i]
          } else if (tools[i].type === 2) {
            that.creditReport = tools[i]
          }
        }
      })
    },
    // 查询订单数量
    // queryOrderStatus () {
    //   let that = this
    //   queryStatusApi().then(data => {
    //     data = data.body
    //     // data = {
    //     //   overDue: true,
    //     //   redRemarkList: [
    //     //     {remarkType: 0, remarkStatus: 1, num: 2},
    //     //     {remarkType: 1, remarkStatus: 1, num: 3},
    //     //     {remarkType: 2, remarkStatus: 1, num: 4},
    //     //     {remarkType: 3, remarkStatus: 1, num: 5},
    //     //     {remarkType: 4, remarkStatus: 1, num: 0},
    //     //   ]
    //     // }
    //     let redRemarkList = data.redRemarkList
    //     let remark = false
    //     for (let i = 1; i < 5; i++) {
    //       that.tabList[i].count = 0
    //     }
    //     for (let i = 0; i < redRemarkList.length; i++) {
    //       let item = redRemarkList[i]
    //       let remarkType = item.remarkType
    //       if ([1, 2, 3, 4].indexOf(Number(remarkType)) > -1) {
    //         that.tabList[remarkType].count = item.num
    //       } else if (item.remarkType == 0 && item.remarkStatus == 1) {
    //         remark = true
    //       }
    //     }
    //     let overDue = data.overdueMark;
    //     that.overDue = overDue;
    //     if (overDue) {
    //       let hideOverdueMarkDate = localStorage.getItem('hideOverdueMarkDate');
    //       if (hideOverdueMarkDate) {
    //         let curDate = new Date();
    //         curDate = curDate.getFullYear() + '-' + (curDate.getMonth() + 1) + '-' + curDate.getDate();
    //         if (curDate == hideOverdueMarkDate) {
    //           overDue = false;
    //         }
    //       }
    //     }
    //     that.$store.commit('orderDotRemark', {
    //       overDue: overDue,
    //       remark: remark
    //     });
    //   })
    // },
    // 标记小红点已读
    updateStatus (remarkType, cb) {
      updateStatusApi({ remarkType: remarkType, remarkStatus: 0 }).then((data) => {
        cb && cb(data)
      });
    },
    // 完善贷款信息查询
    loanEntryQueryFunc () {
      let that = this;
      loanEntryQueryApi({ materialType: '' }).then((data) => {
        if (data.respCode === '1000') {
          data = data.body;
          // data = [
          //   {authStatus: 1, authType: 'JCZL'},
          //   {authStatus: 1, authType: 'CA'},
          //   {authStatus: 1, authType: 'CON'},
          //   {authStatus: 2, authType: 'MOP'},
          //   {authStatus: 0, authType: 'OTH'}
          // ];
          let dataInvalidCount = 0
          for (let i = 0, l = data.length; i < l; i++) {
            if (data[i].authStatus == 2) {
              dataInvalidCount++
              break;
            }
          }
          if (dataInvalidCount > 0) {
            that.dataInvalid = true;
          } else {
            that.dataInvalid = false;
          }
        }
      });
    },
  },
};
</script>
<style lang="scss">
.repay-order-list .repay-item {
  margin-bottom: rc(10);
}
.mycenterpage {
  .hyapp-bar {
    display: none;
  }
  // .hyapp-content {
  //   top: rc(10) !important;
  // }
}
</style>
<style lang="scss" scoped="scoped">
.mycenter {
  padding-bottom: rc(100);
}
.title {
  background: #fff;
  width: 100%;
  height: rc(152);
  padding-left: rc(30);
  .logoStatus {
    /*padding-top: rc(20);*/
    display: flex;
    display: -webkit-flex;
    .status-left img {
      height: rc(122);
      width: rc(122);
    }
    .status-right {
      margin-left: rc(50);
      .status-right-top {
        margin-top: rc(18);
        font-size: rc(40);
        color: #333333;
        letter-spacing: 0;
      }
      .status-right-mid {
        opacity: 0.99;
        font-size: rc(28);
        color: #999999;
        letter-spacing: 0;
        text-align: right;
        margin-top: rc(10);
      }
    }
    .status-right2 {
      margin-top: rc(18);
      margin-left: rc(30);
      font-size: rc(30);
      color: #333333;
      letter-spacing: 0;
    }
  }
}

.content {
  background: #fff;
  padding-left: rc(30);
  // padding-right: rc(30);
  font-size: rc(28);
  padding-top: rc(71.5);
  padding-bottom: rc(10);
  &.mt20 {
    margin-top: rc(20);
  }
  // li.bb-1px:last-child::after {
  //   border-bottom: 0;
  // }
  li {
    padding-right: rc(30);
    height: rc(96);
    display: flex;
    font-size: rc(30);
    color: #333333;
    align-items: center;
    line-height: normal;
    // .img {
    //   height: rc(40);
    //   width: rc(40);
    //   margin-right: rc(20);
    // }
    .right {
      flex: 1;
      text-align: right;
      font-size: rc(26);
      color: #999;
      img {
        margin-left: rc(20);
        width: rc(15);
        height: rc(26);
      }
    }
    .dot {
      display: block;
      position: relative;
      padding: rc(12 12 12 0);
      &::after {
        content: '';
        position: absolute;
        right: 0;
        top: 0;
        transform: translateY(rc(12));
        width: rc(12);
        height: rc(12);
        border-radius: 50%;
        background-color: #ff4c4c;
        background-clip: padding-box;
      }
    }
  }
  &.content-tools {
    ul {
      display: flex;
      flex-wrap: wrap;
    }
    li {
      display: block;
      text-align: center;
      // display: flex;
      position: relative;
      // flex-direction: column;
      width: 33.333%;
      padding-right: 0 !important;
      margin-bottom: rc(60);
      img {
        width: rc(60) !important;
        height: rc(60) !important;
        // margin-right: 0 !important;
        display: block;
        margin: auto;
      }
      span {
        font-size: rc(28);
        line-height: rc(40);
        color: $color-text-title;
        margin-top: rc(23);
        display: block;
      }
    }
  }
}
.module-hd {
  color: $color-text-title;
  padding-top: rc(50);
  margin-bottom: rc(20);
  display: flex;
  align-items: center;
  justify-content: space-between;
  h2 {
    font-size: rc(36);
    font-weight: bold;
  }
  .module-hd-r {
    display: flex;
    span {
      font-size: rc(26);
      color: $color-text-sub;
      line-height: normal;
    }
    b {
      width: rc(9);
      height: rc(17);
      background: url(../../static/images/public_arrow_black.png) no-repeat center;
      background-size: contain;
      margin-left: rc(10);
    }
  }
}
.last {
  border-bottom: none;
}

.quit {
  margin-top: rc(30);
  height: rc(80);
  line-height: rc(80);
  width: 100%;
  text-align: center;
  background: #fff;
  font-size: rc(28);
  color: $color-main;
  /*margin-bottom: rc(200);*/
}
// .order-content {
//   padding: rc(0 0 20);
//   .order-title {
//     position: relative;
//     padding: rc(10 0 0 30);
//     justify-content: space-between;
//     .order-title-left {
//       font-size: rc(34);
//       color: #ffffff;
//       font-weight: bold;
//     }
//     .order-title-right {
//       width: rc(130);
//       height: rc(50);
//       display: flex;
//       align-items: center;
//       justify-content: center;
//       background-color: rgba(255, 255, 255, 0.15);
//       border-radius: rc(28) 0 0 rc(28);
//       color: #ffffff;
//       line-height: normal;
//       i {
//         width: rc(9);
//         height: rc(17);
//         background: url(../../static/images/public_arrow_white.png) center center no-repeat;
//         margin-left: rc(10);
//         background-size: contain;
//       }
//     }
//   }
//   .repay-order-list {
//     margin-top: rc(27);
//   }
// }
.order-content-top {
  padding-top: rc(130);
}
// .order-type-list {
//   margin-top: rc(27);
//   display: flex;
//   align-items: center;
//   justify-content: space-around;
//   .order-type {
//     display: flex;
//     flex-direction: column;
//     justify-content: center;
//     align-items: center;
//   }
//   .order-type-icon {
//     width: rc(60);
//     height: rc(60);
//     position: relative;
//     img {
//       width: 100%;
//       height: 100%;
//       display: inline-block;
//     }
//     .order-type-count {
//       position: absolute;
//       top: 0;
//       left: 0;
//       transform: translate(rc(40), rc(-8));
//       width: rc(31);
//       height: rc(31);
//       font-size: rc(20);
//       color: $color-main;
//       background-color: #ffffff;
//       border-radius: 50%;
//       text-align: center;
//       line-height: rc(31);
//       display: flex;
//       align-items: center;
//       justify-content: center;
//       // box-sizing: border-box;
//       letter-spacing: 0;
//       background: url(../../static/images/#{$APP_NAME}/order_number.png) no-repeat;
//       background-size: rc(31) rc(31);
//       // background-color: #fff;
//       // border-radius: 50%;
//       // background-clip: padding-box;
//       // border: 1px solid #ff601a;
//       box-sizing: border-box;
//       // &::after {
//       //   border-width: 2px;
//       //   border-color: #ff601a;
//       //   border-radius: 50%;
//       //   box-sizing: border-box;
//       // }
//     }
//     .over-due {
//       // position: relative;
//       &::after {
//         content: '';
//         width: rc(56);
//         height: rc(33);
//         background: url(../../static/images/ic_remind.png) no-repeat center;
//         background-size: 100% 100%;
//         // line-height: rc(28);
//         position: absolute;
//         top: rc(-8);
//         left: 100%;
//         margin-left: rc(-8);
//         // content: '逾期';
//         // line-height: 1.5;
//         // position: absolute;
//         // top: rc(-18);
//         // left: 100%;
//         // transform: translateX(rc(-20));
//         // padding: rc(2 10);
//         // border: 1px solid #fff;
//         // border-radius: rc(18);
//         // border-bottom-left-radius: 0;
//         // background-color: #ff4c4c;
//         // color: #fff;
//         // font-size: rc(20);
//         // word-break: keep-all;
//       }
//     }
//   }
//   .order-type-title {
//     margin-top: rc(10);
//     font-size: rc(28);
//     line-height: rc(40);
//     color: #ffffff;
//   }
// }
.data-invalid {
  color: #ff601a;
}
.header {
  width: 100%;
  display: flex;
  position: relative;
  z-index: 10;
  box-sizing: border-box;
  padding: rc(40 36 35);
  align-items: center;
  background: #fff;
  .avater {
    width: rc(60);
    height: rc(60);
    margin-right: rc(36);
    transition: 0.3s all ease;
  }
  .avater-big {
    width: rc(130);
    height: rc(130);
    margin-right: rc(36);
    transition: 0.3s all ease;
  }
  h2 {
    font-size: rc(36);
    color: $color-text-title;
    font-weight: bold;
    line-height: normal;
  }
  .tip {
    font-size: rc(28);
    color: rgba(51, 51, 51, 0.99);
  }
  .arrowhead {
    width: rc(15);
    height: rc(25);
    display: inline-block;
    background: url(../../static/images/public_arrow_black.png) no-repeat center;
    background-size: 100% 100%;
    margin-left: rc(10);
  }
}
.header-fixed {
  position: fixed;
  z-index: 10;
  height: 44px;
  padding: rc(0 36 0);
}
.more {
  width: rc(48);
  height: rc(48);
  display: block;
  background: url(../../static/images/statusbar_iocn_setup.png) no-repeat center;
  background-size: 100% 100%;
  position: absolute;
  top: rc(18);
  right: rc(36);
  z-index: 11;
}
.my-order {
  margin: 0 rc(36);
  padding-bottom: rc(28);
  border-radius: rc(12);
  box-shadow: rc(0 6 16 0) rgba($color-main, 0.2);
  background-image: $linear-bgColor;
}

.tag {
  left: rc(128) !important;
  top: rc(-15) !important;
}
.recommend {
  box-sizing: border-box;
  background: #ffffff;
  &.mt20 {
    margin-top: rc(20);
  }
  .module-hd {
    padding: rc(36 36 0);
  }
  .module-hd-r {
    display: flex;
    align-items: center;
    span {
      font-size: rc(26);
      color: $color-text-sub;
    }
    i {
      display: inline-block;
      width: rc(9);
      height: rc(18);
      background: url(../../static/images/public_arrow_black.png) no-repeat;
      background-size: rc(9) rc(15);
      margin-left: rc(10);
    }
  }
}
.advertisement {
  display: block;
  // width: 100%;
  width: rc(678);
  height: rc(180);
  margin: auto;
  border-radius: rc(12);
}
.ljd-repay-box {
  padding-left: rc(35);
  padding-right: rc(35);
  background: #fff;
}
.ljd-repay-ctr {
  background: #f8f8f8;
  border-radius: 6px;
  padding: rc(30) rc(36);
  display: flex;
  align-items: center;
  .jrcs-left {
    flex: 1;
    p {
      font-size: rc(28);
      color: #333;
      &.jrcs-tip {
        color: #ff601a;
        display: flex;
        align-items: center;
        img {
          width: rc(30);
          height: rc(30);
          margin-right: rc(10);
        }
      }
    }
  }
  .jrcs-btn {
    width: rc(166);
    height: rc(60);
    font-size: rc(26);
    border-radius: rc(60);
    line-height: normal;
  }
}
// .fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}
// .fade-enter,
.fade-leave-to {
  opacity: 0;
}
</style>
