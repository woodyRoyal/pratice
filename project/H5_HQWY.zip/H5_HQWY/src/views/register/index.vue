<template>
  <PageView :title="title"
            class="register">
    <div class="register-wrap">
      <FromInput v-model="form.mobilePhone"
                 :type="'tel'"
                 :validate="validate.mobilePhone"
                 :max-length="11"
                 :placeholder="'请填写真实有效的手机号'"
                 @checkHandler="checkHandler"></FromInput>
      <div class="sms-code">
        <FromInput v-model="form.code"
                   :type="'tel'"
                   :validate="validate.code"
                   :max-length="6"
                   :placeholder="'请填写短信验证码'"
                   @checkHandler="checkHandler">
          <button class="get-sms-code"
                  :class="{'sms-code-activation':form.mobilePhone.length==11 && code.s==code.maxTime}"
                  @click="getSmsCode">
            {{ code.message }}
          </button>
        </FromInput>
      </div>
      <span v-show="false">{{ isCheck }}</span>
      <CommonButton :btn-data="btnData"
                    @click.native="submitData()"></CommonButton>
      <div v-if="smsType==$config.get('parameter.smsType')"
           class="protocol-group">
        <div class="api-protocols-check api-protocols"
             :class="protocolChecked?'checked':'nocheck'"
             @click="checkedProtocol"></div>
        <p class="protocol">
          我已阅读并同意<span @click="openProtocol('fwxy')">《用户服务协议》</span>和<span @click="openProtocol('yszc')">《隐私政策》</span>
        </p>
      </div>
    </div>
    <Confirm ref="backComfirm"
             :close-on-confirm="false"
             title="安全校验"
             cancel-txt="取消"
             sure-txt="确认"
             txt-style="center"
             @on-confirm="backConfirmConfirm()"
             @on-cancel="confirmCancel()">
      <FromInput v-model="form.imgCode"
                 class="comfirm-form"
                 :is-border-bottom="false"
                 :caret-color="'#444444'"
                 :blur-borderr-color="'#e6e6e6'"
                 :validate="validate.imgCode"
                 :max-length="4"
                 :placeholder="'请填写图形验证码'"
                 @checkHandler="checkHandler">
        <img :src="imgCodeUrl"
             class="img-code"
             @click="getImageCode" />
      </FromInput>
    </Confirm>
  </PageView>
</template>
<script>
import Confirm from '@/components/confirm/index'
import { sendCodeApi, getImageCodeApi, validateImageCodeApi, validateSmsCodeApi, loginCodeApi } from '@/api/controller/loginRegister'
import FromInput from '@/components/fromInput'
import CommonButton from '@/components/button/index'
import utils from '@/util/utils'
export default {
  components: {
    FromInput,
    CommonButton,
    Confirm,
  },
  data () {
    return {
      title: '注册',
      smsType: this.$config.get('parameter.smsType'),// 21 登录注册 31 找回密码
      protocolChecked: false,
      isProtocolClick: false, // 是否点击协议跳转
      isSenCode: false, // 是否调用发短信接口
      imgCodeUrl: '', // 图形验证码
      serialNumber: '', // 图形验证
      smsSerialNumber: '', // 短信验证
      appHeader: {}, // app 头信息
      code: {
        disabled: true,
        timer: null,
        s: 60, // 倒计时
        maxTime: 60,
        message: '获取验证码',
      },
      form: {
        mobilePhone: '',
        code: '',
        imgCode: '',
      },
      validate: { // 校验
        mobilePhone: {
          name: 'mobilePhone',
          rule: /^((\+?86)|(\(\+86\)))?1[3,4,5,6,7,8,9]\d{9}$/,
          message: '请输入合法的手机号码',
          trigger: ['change'],
          isCheck: false,
        },
        code: {
          name: 'code',
          rule: /^\d{6}$/,
          message: '请输入有效的验证码',
          trigger: ['change'],
          isCheck: false,
        },
        imgCode: {
          name: 'imgCode',
          rule: /^[0-9A-Za-z]{4}$/,
          message: '请输入4位有效的图形验证码',
          trigger: ['change'],
          isCheck: false,
        },
      },
      // 提交按钮
      btnData: {
        activeFlag: false,
        txt: '注册',
      },
    }
  },
  computed: {
    isCheck () { // 校验是否通过
      let activeFlag = (Object.values(this.validate).filter((v) => (v.name !== 'imgCode')).every((v) => v.isCheck)) && this.protocolChecked
      // eslint-disable-next-line vue/no-side-effects-in-computed-properties
      this.btnData.activeFlag = activeFlag
      return activeFlag
    },
  },
  activated () {
    this.isProtocolClick = false
    if (this.$route.query.from === 'validateMobile') {
      this.smsType = this.$config.get('parameter.passSmsType')
      this.title = "验证手机号"
      this.btnData.txt = '下一步'
      this.protocolChecked = true
      this.$appInvoked('appGetLastLoginMobilePhone', {}, (mobile) => {
        this.form.mobilePhone = mobile
        this.validate.mobilePhone.isCheck = true
      })
    } else {
      this.title = '注册'
      this.btnData.txt = '注册'
      this.smsType = this.$config.get('parameter.smsType')
    }
    this.collectEventMD({
      eventId: 'jr1002',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
    })
  },
  deactivated: function () {
    if (!this.isProtocolClick) {
      this.reset()
    }
  },
  methods: {
    checkedProtocol () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'dlzc;zcy;gxxy;w257',
      })
      this.protocolChecked = !this.protocolChecked
    },
    // 打开协议。fwxy-用户服务协议，yszc-隐私政策（目前只有立即借有）
    openProtocol (type) {
      this.isProtocolClick = true
      if (type === 'fwxy') {
        this.$routerPush('/userServiceAgreement')
      } else if (type === 'yszc') {
        this.$routerPush('/yszc')
      }
    },
    backConfirmConfirm () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'dlzc;aqjy;w8',
      })
      if (!this.validate.imgCode.isCheck) {
        utils.toastMsg(this.validate.imgCode.message)
      } else {
        // 校验图形验证码
        this.loading(2)
        validateImageCodeApi({
          imageCode: this.form.imgCode,
          serialNumber: this.serialNumber,
          mobilePhone: this.form.mobilePhone,
        }).then(() => {
          this.closeLoading(2)
          this.$refs.backComfirm.hide()
          this.sendCode()
          this.form.imgCode = ''
        }, () => {
          this.closeLoading(2)
        })
      }
    },
    confirmCancel () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'dlzc;aqjy;w9',
      })
    },
    // 检验信息
    checkHandler (options) {
      this.validate[options.name].isCheck = options.isCheck
    },
    // 获取短信前期验证码
    getSmsCode () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'dlzc;yzmdl;hqyzm;w5',
      })
      if (!this.validate.mobilePhone.isCheck) {
        utils.toastMsg(this.validate.mobilePhone.message)
      } else {
        if (this.code.disabled) {
          this.code.disabled = false
          this.sendCode()
        }
      }
    },
    // 发送短信验证码
    sendCode () {
      let p = { mobilePhone: this.form.mobilePhone, smsType: this.smsType }
      this.appSignParams(p, false, (rst) => {
        this.loading(2)
        sendCodeApi(p, { headers: rst }).then((res) => {
          this.closeLoading(2)
          utils.toastMsg('短信验证码已发送～')
          this.isSenCode = true
          this.code.disabled = false
          this.smsSerialNumber = res.body
          utils.codeCountdown(this)
        }, (err) => {
          this.closeLoading(2)
          if (err.respCode === '1063') {
            // 图片验证码
            this.$refs.backComfirm.show()
            this.getImageCode()
          }
          this.code.disabled = true
        })
      })
    },
    // 获取图形验证
    getImageCode () {
      this.loading(2)
      getImageCodeApi().then((res) => {
        this.closeLoading(2)
        if (res.body) {
          this.imgCodeUrl = `data:image/png;base64,${res.body.outputImage}`
          this.serialNumber = res.body.serialNumber
        }
      }, () => {
        this.closeLoading(2)
      })
    },
    // 注册
    submitData () {
      if (!this.validate.mobilePhone.isCheck) {
        utils.toastMsg(this.validate.mobilePhone.message)
        return
      }
      if (!this.isSenCode) {
        utils.toastMsg('请先获取验证码')
        return
      }
      if (!this.validate.code.isCheck) {
        utils.toastMsg(this.validate.code.message)
        return
      }
      if (!this.protocolChecked) {
        utils.toastMsg('请阅读并同意用户服务协议')
        return
      }
      utils.debouce(() => {
        this.$appInvoked("appGetAjaxHeader", {}, (data) => {
          let { idfa, imei, innerVersion, projectMark } = data;
          if (this.smsType === this.$config.get('parameter.passSmsType')) {
            let p = { smsType: this.smsType, code: this.form.code, mobilePhone: this.form.mobilePhone, serialNumber: this.smsSerialNumber }
            this.appSignParams(p, false, (rst) => {
              this.loading(2)
              validateSmsCodeApi(p, { headers: rst }).then(() => {
                this.closeLoading(2)
                // 设置密码
                this.$routerPush(`/setPassword/${this.smsSerialNumber}/${this.form.mobilePhone}/${this.form.code}?sourcePage=${this.$route.query.sourcePage}&type=${this.$route.query.type}&isIosDkw7=${this.$route.query.isIosDkw7}`)
              }, () => {
                this.closeLoading(2)
              })
            })
          } else {
            let p = { registerType: 1, code: this.form.code, mobilePhone: this.form.mobilePhone, serialNumber: this.smsSerialNumber, idfa, imei, innerVersion, projectMark }
            this.appSignParams(p, true, (rst) => {
              this.$appInvoked('appExecStatistic', {
                eventId: 'dlzc;zcy;dl;w256',
              })
              this.loading(2)
              loginCodeApi(p, { headers: rst }).then((res) => {
                window.hideDiversionConfirm && window.hideDiversionConfirm() // 隐藏登录引导弹窗
                // 注册成功
                this.closeLoading(2)
                localStorage.removeItem('cacheAjaxHeader')
                // 立即借记录是否结清状态
                if (this.$config.get('productId') === 903) {
                  localStorage.setItem('SHOW_LJJ_REPAY', res.body.clear)
                }
                this.$appInvoked('appLoginSuccess', res.body)
                // this.$routerReplace('/mycenter')
                if (Number(this.$route.query.type) === 0) {
                  if (this.$route.query.isIosDkw7 === 'true') {
                    window.isLoginSuccessCloseWebview = function () {
                      window.isLoginSuccessCloseWebview = null
                      window.vm.$appInvoked('appCloseWebview', {})
                    }
                  } else {
                    this.$appInvoked('appCloseWebview', {})
                  }
                } else {
                  this.$routerGo(-2)
                }
              }, () => {
                this.closeLoading(2)
              })
            })
          }
        })
      }, 1000, true)()
    },
    reset () {
      clearTimeout(this.code.timer)
      this.validate.mobilePhone.isCheck = false
      this.validate.code.isCheck = false
      this.validate.imgCode.isCheck = false

      this.form.mobilePhone = ''
      this.form.code = ''
      this.form.loginPwd = ''
      this.form.imgCode = ''
      this.isSenCode = false
      this.protocolChecked = false
      this.code = {
        disabled: true,
        timer: null,
        s: 60, // 倒计时
        maxTime: 60,
        message: '获取验证码',
      }
    },
  },
}
</script>
<style lang="scss" scoped>
.register {
  background: #fff !important;
}
.sms-code {
  position: relative;
  margin-bottom: rc(156);
}
.get-sms-code {
  height: 100%;
  display: block;
  color: #bbbbbb;
  font-size: rc(30);
  margin-left: rc(60);
}
.sms-code-activation {
  color: $color-main;
}
.register-wrap {
  margin-top: rc(145);
  padding: 0 rc(30);
  box-sizing: border-box;
}
.protocol {
  margin-top: rc(40);
  text-align: center;
  font-size: rc(26);
  color: $color-text-tip;
  span {
    color: $color-main;
  }
}
.comfirm-form {
  margin-top: rc(35);
}
.img-code {
  height: 50px;
  width: rc(200);
  display: block;
  margin-left: rc(20);
}
.protocol-group {
  display: inline-block;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
}
.api-protocols {
  left: rc(-40);
  bottom: rc(5);
  position: absolute;
  &-check {
    width: rc(30);
    height: rc(30);
    &.checked {
      background: url(../../../static/images/#{$APP_NAME}/global_check_normal.png) no-repeat center;
      background-size: 100% 100%;
    }
    &.nocheck {
      background: url(../../../static/images/#{$APP_NAME}/global_check_selected.png) no-repeat center;
      background-size: 100% 100%;
    }
  }
}
</style>
<style lang="scss">
.comfirm-form {
  .input-content-item {
    width: 100%;
    padding-left: 8px;
    box-sizing: border-box;
  }
}
</style>
