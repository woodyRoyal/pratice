<template>
  <PageView title="公告"
            right-txt="投诉反馈"
            @rightClick="rightClickHandle">
    <div class="jrcs-notice-detail">
      <div class="jrcs-notice-title"
           v-html="linkTargeTitle"></div>
      <div class="jrcs-notice-content"
           v-html="linkTargeContext"></div>
    </div>
    <div slot="dialog"
         class="tsfk-container">
      <div v-show="showTsfk"
           class="tsfk-mask"
           :style="{opacity: showTsfk?1:0}"
           @click="showTsfk=false"></div>
      <transition name="hy-popup-animate-bottom">
        <div v-show="showTsfk"
             class="tsfk-content">
          <div class="tsfk-title bb-1px">
            <div>投诉反馈</div>
            <div class="tsfk-cancel"
                 @click="closeTsfk('ggy;tsfk;gb;w346')">
              取消
            </div>
          </div>
          <div class="tsfk-list">
            <div class="tsfk-item b-1px"
                 @click="openOnlineKf()">
              <img src="../../static/images/complain_icon_service.png"
                   alt="">
              在线客服
            </div>
            <a class="tsfk-item b-1px"
               :href="`tel:${$config.get('tel.kf')}`"
               @click="closeTsfk('ggy;tsfk;kfdh;w345')">
              <img src="../../static/images/complain_icon_iphone.png"
                   alt="">
              客服电话
            </a>
          </div>
        </div>
      </transition>
    </div>
  </PageView>
</template>
<script>
import { getNoticeLinkApi } from '../api/controller/common/index'
export default {
  data () {
    return {
      linkTargeContext: '',
      linkTargeTitle: '',
      showTsfk: false,
    }
  },
  activated () {
    this.showTsfk = false
    this.getNoticeLink()
  },
  methods: {
    getNoticeLink () {
      let params = {
        item: 2, // 端: 1.官网 2.APP
        linkAddress: `${this.$config.get('fullPath')}#${this.$route.path}?position=${this.$route.query.position}`,
        platform: this.$config.get('platform'),
      }
      // console.log(params)
      getNoticeLinkApi(params).then((data) => {
        if (data.respCode === '1000') {
          data = data.body
          // let data = {
          //   linkName: '公告1',
          //   linkTargeTitle: '在线产品合规化检查公示\r\n7月15日-7月21日',
          //   linkTargeContext: '<ol class=" list-paddingleft-2" style="list-style-type: decimal;"><li><p style="text-align: left;">需求背景</p><p style="text-align: left;"><span style="font-size: 24px;">配合立即贷APP转型为贷款超市APP立即借，<span style="color: rgb(49, 133, 155);"><strong>金融超市运营后台做相应功能支持</strong></span>；一期已满足立即借APP配置相关功能，二期需完善所有剩余功能，包括短信营销及市场推广相关的功能改造</span><br/></p></li><li><p style="text-align: left;">需求内容</p><p style="text-align: left;">如下图：</p><p style="text-align: left;"><img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1564650630765&di=0d3a218bbedc4dea4dc9f687db029077&imgtype=0&src=http://p1.ifengimg.com/fck/2018_01/4b3586c88209a81_w640_h429.jpg" /></p><p style="text-align: left;">表格如下：</p><p style="text-align: left;"><br/></p><table><tbody><tr class="firstRow"><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>序号</strong></td><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>分类</strong></td><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>需求内容</strong></td><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>需求描述</strong></td><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>优先级</strong></td><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>备注</strong></td></tr><tr><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>1</strong></td><td width="112" valign="top" style="word-break: break-all;">运营后台</td><td width="112" valign="top" style="word-break: break-all;">1、新增字段产品线，用于标记渠道号所属的产品线<br/>2、历史已添加渠道号数据产品线字段初始化</td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td></tr><tr><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>2</strong></td><td width="112" valign="top" style="word-break: break-all;">运营后台<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td></tr><tr><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>3</strong></td><td width="112" valign="top" style="word-break: break-all;">运营后台<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td></tr><tr><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>4</strong></td><td width="112" valign="top" style="word-break: break-all;">运营后台<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td></tr><tr><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>5</strong></td><td width="112" valign="top" style="word-break: break-all;">运营后台<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td></tr><tr><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>6</strong></td><td width="112" valign="top" style="word-break: break-all;">渠道推广<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td></tr><tr><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>7</strong></td><td width="112" valign="top" style="word-break: break-all;">渠道推广<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td></tr><tr><td width="112" valign="top" style="word-break: break-all;" align="center"><strong>8</strong></td><td width="112" valign="top" style="word-break: break-all;">渠道推广</td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td><td width="112" valign="top" style="word-break: break-all;">可筛选并导出符合条件的立即借用户手机号码<br/></td></tr></tbody></table></li><li><p style="text-align: left;">关联系统<br/></p></li></ol>'
          // }
          // document.title = data.linkName || '公告'
          // this.linkName = data.linkName
          this.linkTargeContext = data.linkTargeContext
          this.linkTargeTitle = data.linkTargeTitle.replace(/\\r\\n/g, '<br>').replace(/\r\n/g, '<br>').replace(/\n/g, '<br>')
        }
      })
    },
    rightClickHandle () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'ggy;tsfk;w343',
      })
      this.showTsfk = true
    },
    openOnlineKf () {
      this.needUserLogin('', () => {
        this.$appInvoked('appExecStatistic', {
          eventId: 'ggy;tsfk;zxkf;w344',
        })
        this.showTsfk = false
        this.$appInvoked('appGetAjaxHeader', {}, (rst) => {
          this.$appInvoked('appOpenWebview', {
            url: `${window.$config.get('url.helpcenterQsList')}&productId=${window.$config.get('productId')}&token=${rst.token}&version=${rst.version}`,
            enableBackHistory: true,
            nav: {
              title: {
                text: '帮助与反馈',
              },
            },
          })
        })
      })
    },
    closeTsfk (eventId) {
      this.$appInvoked('appExecStatistic', {
        eventId: eventId,
      })
      this.showTsfk = false
    },
  },
}
</script>
<style lang="scss">
.jrcs-notice-detail {
  padding: rc(40 36);
  background-color: #fff;
  .jrcs-notice-title {
    font-size: rc(40);
    color: #111111;
    line-height: rc(50);
    text-align: center;
  }
  .jrcs-notice-content {
    color: #111111;
    margin-top: rc(20);
    font-size: rc(30) !important;
    line-height: rc(50) !important;
    * {
      font-size: rc(30) !important;
      line-height: rc(50) !important;
    }
    img {
      display: block;
      max-width: 100%;
      height: auto;
      margin: rc(30) auto;
    }
    table {
      width: 100%;
      td,
      th {
        height: rc(80) !important;
        text-align: center;
        border: solid 1px #eeeeee;
        font-size: rc(26) !important;
        color: #333;
      }
      th {
        background: #eee;
        font-weight: bold;
      }
    }
    strong {
      font-weight: bold;
    }
  }
  blockquote {
    display: block;
    border-left: 8px solid #d0e5f2;
    padding: 5px 10px;
    margin: 10px 0;
    line-height: 1.4;
    font-size: 100%;
    background-color: #f1f1f1;
  }
}
.tsfk-container {
  .tsfk-mask {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.4);
    z-index: 400;
    opacity: 0;
    transition: opacity 0.4s ease-in;
  }
  .tsfk-content {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #fff;
    z-index: 401;
    font-size: rc(34);
    transition-property: transform;
    transition-duration: 300ms;
    max-height: 100%;
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
  }
  .tsfk-title {
    height: rc(100);
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    &::after {
      border-bottom-color: #ddd;
    }
    .tsfk-cancel {
      color: $color-text-sub;
      position: absolute;
      padding: rc(10 36);
      top: 50%;
      right: 0;
      transform: translateY(-50%);
    }
  }
  .tsfk-list {
    padding: rc(70 36);
    .tsfk-item {
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: rc(40);
      height: rc(96);
      color: $color-text-title;
      img {
        width: rc(50);
        margin-right: rc(20);
      }
      &:last-child {
        margin-bottom: 0;
      }
      &::after {
        border-radius: rc(96);
        border-color: $line-btn-border;
      }
    }
  }
}
.hy-popup-animate-bottom-enter,
.hy-popup-animate-bottom-leave-active {
  -webkit-transform: translate3d(0, 100%, 0);
  transform: translate3d(0, 100%, 0);
}
</style>
