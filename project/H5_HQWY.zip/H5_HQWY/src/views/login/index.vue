<template>
  <div class="login-register"
       :class="[{isIOS: $tools.getBrowser() === 'iOS'}]">
    <div class="login-register-wrap">
      <div class="close"
           @click="closeEvent"></div>
      <div class="tabs">
        <span class="tabs-item "
              :class="{'tabs-activation':!tabCurrent}"
              @click="tabHandler(0)">验证码登录</span>
        <span class="tabs-item"
              :class="{'tabs-activation':tabCurrent}"
              @click="tabHandler(1)">密码登录
        </span>
      </div>
      <FromInput v-model="form.mobilePhone"
                 :type="'tel'"
                 :validate="validate.mobilePhone"
                 :max-length="11"
                 :placeholder="'请填写真实有效的手机号'"
                 @checkHandler="checkHandler"></FromInput>
      <div v-show="!tabCurrent"
           class="sms-code">
        <FromInput v-model="form.code"
                   :type="'tel'"
                   :validate="validate.code"
                   :max-length="6"
                   :placeholder="'请填写短信验证码'"
                   @checkHandler="checkHandler">
          <button class="get-sms-code"
                  :class="{'sms-code-activation':form.mobilePhone.length==11 && code.s==code.maxTime}"
                  @click="getSmsCode">
            {{ code.message }}
          </button>
        </FromInput>
      </div>
      <div v-show="tabCurrent">
        <FromInput v-model="form.loginPwd"
                   :type="'password'"
                   :validate="validate.loginPwd"
                   :max-length="20"
                   :placeholder="'请填写登录密码'"
                   @checkHandler="checkHandler"></FromInput>
      </div>
      <div class="forget-pass">
        <span @click="goRegister">注册</span>
        <span v-show="tabCurrent"
              @click="forgetPass">忘记密码？</span>
      </div>
      <span v-show="false">{{ isCheck }}</span>
      <CommonButton :btn-data="btnData"
                    @click.native="submitData()"></CommonButton>
      <p class="protocol">
        登录即表示您同意<span @click="openProtocol('fwxy')">《用户服务协议》</span>和<span @click="openProtocol('yszc')">《隐私政策》</span>
      </p>
    </div>

    <Confirm ref="backComfirm"
             :close-on-confirm="false"
             title="安全校验"
             cancel-txt="取消"
             sure-txt="确认"
             txt-style="center"
             @on-confirm="backConfirmConfirm()"
             @on-cancel="confirmCancel()">
      <FromInput v-model="form.imgCode"
                 class="comfirm-form"
                 :is-border-bottom="false"
                 :caret-color="'#444444'"
                 :blur-borderr-color="'#e6e6e6'"
                 :validate="validate.imgCode"
                 :max-length="4"
                 :placeholder="'请填写图形验证码'"
                 @checkHandler="checkHandler">
        <img :src="imgCodeUrl"
             class="img-code"
             @click="getImageCode" />
      </FromInput>
    </Confirm>
  </div>
</template>
<script>
import Confirm from '@/components/confirm/index'
import { sendCodeApi, getImageCodeApi, validateImageCodeApi, loginPasswordApi, loginCodeApi } from '@/api/controller/loginRegister'
import FromInput from '@/components/fromInput'
import CommonButton from '@/components/button/index'
import utils from '@/util/utils'
export default {
  components: {
    FromInput,
    CommonButton,
    Confirm,
  },
  data () {
    return {
      tabCurrent: 0, // tabs
      isSenCode: false, // 是否调用发短信接口
      imgCodeUrl: '', // 图形验证码
      serialNumber: '', // 图形验证
      smsSerialNumber: '', // 短信验证
      code: {
        disabled: true,
        timer: null,
        s: 60, // 倒计时
        maxTime: 60,
        message: '获取验证码',
      },
      form: {
        mobilePhone: '',
        code: '',
        loginPwd: '',
        imgCode: '',
      },
      validate: { // 校验
        mobilePhone: {
          name: 'mobilePhone',
          rule: /^((\+?86)|(\(\+86\)))?1[3,4,5,6,7,8,9]\d{9}$/,
          message: '请输入合法的手机号码',
          trigger: ['change'],
          isCheck: false,
        },
        code: {
          name: 'code',
          rule: /^\d{6}$/,
          message: '请输入有效的验证码',
          trigger: ['change'],
          isCheck: false,
        },
        loginPwd: {
          name: 'loginPwd',
          rule: /^[0-9A-Za-z]{6,20}$/,
          message: '请输入正确的登录密码',
          trigger: ['change'],
          isCheck: false,
        },
        imgCode: {
          name: 'imgCode',
          rule: /^[0-9A-Za-z]{4}$/,
          message: '请输入4位有效的图形验证码',
          trigger: ['change'],
          isCheck: false,
        },
      },
      // 提交按钮
      btnData: {
        activeFlag: false,
        txt: '登录',
      },
      loginSuccessCallback: null, // 登录成功回调
      closeCallback: null, // 关闭回调
      type: 0, // 0 原生调用 1 H5
      // show: false, // 是否展示
      // animateShow: false, // 动画
      appVersion: '',
      isIosDkw7: false, // iOS贷款王7.0.0版本
    }
  },
  computed: {
    isCheck () { // 校验是否通过
      let filterKey = 'loginPwd'
      if (this.tabCurrent) {
        filterKey = 'code'
      }
      let activeFlag = Object.values(this.validate).filter((v) => (v.name !== filterKey) && (v.name !== 'imgCode')).every((v) => v.isCheck)
      // eslint-disable-next-line vue/no-side-effects-in-computed-properties
      this.btnData.activeFlag = activeFlag
      return activeFlag
    },
  },
  mounted () {
    this.getLastMobilePhone()
  },
  activated () {
    this.interceptAppBack()
    // this.getLastMobilePhone()
    let { type = 0, w } = this.$route.query
    this.type = +type
    this.w = w
    if (w) {
      this.collectEventMD({
        eventId: `ly1001,w${w}`,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
      })
    }
    // iOS贷款王7.0.0版本，webView关闭有问题，调用关闭时关闭最上层，故做特殊处理
    if (isIos && this.$config.get('productId') === 901) {
      if (this.appVersion) {
        this.isIosDkw7 = this.appVersion === '7.0.0'
      } else {
        this.$appInvoked("appGetVersion", {}, (data) => {
          this.appVersion = data
          this.isIosDkw7 = data === '7.0.0'
        })
      }
    }
    // Android系统用户进入登录页弹窗提示告知需获取设备信息
    if (isAndroid) {
      this.$appInvoked('appAskPermissionStatus', {
        needShowPermissionAlert: true,
        permissions: [8], // // 1：相机，2：相册，3：麦克风，4：通讯录，5；短信，6：定位，7：通话记录，8：设备信息
      })
    }
  },
  methods: {
    getLastMobilePhone () {
      this.$appInvoked('appGetLastLoginMobilePhone', {}, (mobile) => {
        this.form.mobilePhone = mobile || ''
        if (this.form.mobilePhone) {
          this.validate.mobilePhone.isCheck = true
        } else {
          this.validate.mobilePhone.isCheck = false
        }
      })
    },
    // 登录切换
    tabHandler (index) {
      let eventId = 'dlzc;yzmdl;w4'
      if (index) {
        eventId = 'dlzc;mmdl;w10'
      }
      this.$appInvoked('appExecStatistic', {
        eventId,
      })
      this.tabCurrent = index
    },
    // 打开协议。fwxy-用户服务协议，yszc-隐私政策（目前只有立即借有）
    openProtocol (type) {
      let eventId = '', url = ''
      if (type === 'fwxy') {
        eventId = 'dlzc;yzmdl;fwxy;w7'
        if (this.tabCurrent) {
          eventId = 'dlzc;mmdl;fwxy;w12'
        }
        url = '/userServiceAgreement'
      } else if (type === 'yszc') {
        url = '/yszc'
      }
      eventId && this.$appInvoked('appExecStatistic', {
        eventId,
      })
      this.$routerPush(url)
      // this.$appInvoked('appOpenWebview', {
      //   url: url,
      //   nav: {
      //     hide: true
      //   }
      // })
    },
    backConfirmConfirm () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'dlzc;aqjy;w8',
      })
      if (!this.validate.imgCode.isCheck) {
        utils.toastMsg(this.validate.imgCode.message)
      } else {
        // 校验图形验证码
        this.loading(2)
        validateImageCodeApi({
          imageCode: this.form.imgCode,
          serialNumber: this.serialNumber,
          mobilePhone: this.form.mobilePhone,
        }).then(() => {
          this.closeLoading(2)
          this.$refs.backComfirm.hide()
          this.sendCode()
          this.form.imgCode = ''
        }, () => {
          this.closeLoading(2)
        })
      }
    },
    confirmCancel () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'dlzc;aqjy;w9',
      })
    },
    // 忘记密码
    forgetPass () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'dlzc;mmdl;wjmm;w13',
      })
      this.$routerPush(`/register?from=validateMobile&type=${this.type}&isIosDkw7=${this.isIosDkw7}`)
      // this.animateShow = false
      // this.show = false
      // this.reset()
      // window.location.hash = `/validateMobile/validateMobile?type=${this.type}&isIosDkw7=${this.isIosDkw7}`
    },
    // 注册
    goRegister () {
      let eventId = 'dlzc;yzmdl;zc;w254'
      if (this.tabCurrent) {
        eventId = 'dlzc;mmdl;zc;w255'
      }
      this.$appInvoked('appExecStatistic', {
        eventId,
      })
      this.$routerPush(`/register?type=${this.type}&isIosDkw7=${this.isIosDkw7}`)
      // this.animateShow = false
      // this.show = false
      // this.reset()
      // window.location.hash = `/register?type=${this.type}&isIosDkw7=${this.isIosDkw7}`
    },
    // 检验信息
    checkHandler (options) {
      this.validate[options.name].isCheck = options.isCheck
    },
    // 获取短信前期验证码
    getSmsCode () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'dlzc;yzmdl;hqyzm;w5',
      })
      if (!this.validate.mobilePhone.isCheck) {
        utils.toastMsg(this.validate.mobilePhone.message)
      } else {
        if (this.code.disabled) {
          this.code.disabled = false
          this.sendCode()
        }
      }
    },
    // 发送短信验证码
    sendCode () {
      let p = { mobilePhone: this.form.mobilePhone, smsType: this.$config.get('parameter.smsType') }
      this.appSignParams(p, false, (rst) => {
        this.loading(2)
        sendCodeApi(p, { headers: rst }).then((res) => {
          this.closeLoading(2)
          utils.toastMsg('短信验证码已发送～')
          this.isSenCode = true
          this.code.disabled = false
          this.smsSerialNumber = res.body
          utils.codeCountdown(this)
        }, (err) => {
          this.closeLoading(2)
          if (err.respCode === '1063') {
            // 图片验证码
            this.$refs.backComfirm.show()
            this.getImageCode()
          }
          this.code.disabled = true
        })
      })
    },
    // 获取图形验证
    getImageCode () {
      this.loading(2)
      getImageCodeApi().then((res) => {
        this.closeLoading(2)
        if (res.body) {
          this.imgCodeUrl = `data:image/png;base64,${res.body.outputImage}`
          this.serialNumber = res.body.serialNumber
        }
      }, () => {
        this.closeLoading(2)
      })
    },
    // 登录注册
    submitData () {
      let that = this
      if (!this.validate.mobilePhone.isCheck) {
        utils.toastMsg(this.validate.mobilePhone.message)
        return
      }
      if (this.tabCurrent) {
        // 密码登录
        that.$appInvoked('appExecStatistic', {
          eventId: 'dlzc;mmdl;dl;w11',
        })
        if (!this.validate.loginPwd.isCheck) {
          utils.toastMsg(this.validate.loginPwd.message)
          return
        }
        utils.debouce(() => {
          that.$appInvoked('appGetAjaxHeader', {}, (data) => {
            let { idfa, imei, innerVersion, projectMark } = data
            let p = { loginPwd: this.form.loginPwd, mobilePhone: this.form.mobilePhone, idfa, imei, innerVersion, projectMark }
            this.appSignParams(p, true, (rst) => {
              this.loading(2)
              loginPasswordApi(p, { headers: rst }).then((res) => {
                window.hideDiversionConfirm && window.hideDiversionConfirm() // 隐藏登录引导弹窗
                this.closeLoading(2)
                localStorage.removeItem('cacheAjaxHeader')
                // 立即借记录是否结清状态
                if (this.$config.get('productId') === 903) {
                  localStorage.setItem('SHOW_LJJ_REPAY', res.body.clear)
                }
                that.$appInvoked('appLoginSuccess', res.body)
                this.close(true, true)
              }, () => {
                this.closeLoading(2)
              })
            })
          })
        }, 1000, true)()
      } else {
        // 短信登录
        that.$appInvoked('appExecStatistic', {
          eventId: 'dlzc;yzmdl;dl;w6',
        })
        if (!this.isSenCode) {
          utils.toastMsg('请先获取验证码')
          return
        }
        if (!this.validate.code.isCheck) {
          utils.toastMsg(this.validate.code.message)
          return
        }
        utils.debouce(() => {
          that.$appInvoked('appGetAjaxHeader', {}, (data) => {
            let { idfa, imei, innerVersion, projectMark } = data
            let p = { registerType: 1, code: this.form.code, mobilePhone: this.form.mobilePhone, serialNumber: this.smsSerialNumber, idfa, imei, innerVersion, projectMark }
            this.appSignParams(p, true, (rst) => {
              this.loading(2)
              loginCodeApi(p, { headers: rst }).then((res) => {
                window.hideDiversionConfirm && window.hideDiversionConfirm() // 隐藏登录引导弹窗
                this.closeLoading(2)
                localStorage.removeItem('cacheAjaxHeader')
                // 立即借记录是否结清状态
                if (this.$config.get('productId') === 903) {
                  localStorage.setItem('SHOW_LJJ_REPAY', res.body.clear)
                }
                that.$appInvoked('appLoginSuccess', res.body)
                this.close(true, true)
              }, () => {
                this.closeLoading(2)
              })
            })
          })
        }, 1000, true)()
      }
    },
    reset () {
      clearTimeout(this.code.timer)
      this.tabCurrent = 0
      this.form.code = ''
      this.form.loginPwd = ''
      this.form.imgCode = ''
      this.isSenCode = false
      this.validate.code.isCheck = false
      this.validate.loginPwd.isCheck = false
      this.validate.imgCode.isCheck = false
      this.getLastMobilePhone()
      this.code = {
        disabled: true,
        timer: null,
        s: 60, // 倒计时
        maxTime: 60,
        message: '获取验证码',
      }
    },
    // 关闭弹框 isAnimate true 有动画
    close (from) {
      if (this.type === 0) {
        if (from !== 'left' && this.isIosDkw7) {
          window.isLoginSuccessCloseWebview = function () {
            window.isLoginSuccessCloseWebview = null
            // main.js调用时this不存在，故使用window.vm
            window.vm.$appInvoked('appCloseWebview', {})
          }
        } else {
          this.$appInvoked('appCloseWebview', {})
        }
      } else {
        this.reset()
        this.$routerBack()
      }
      // this.animateShow = false
      // if (isAnimate) {
      //   setTimeout(() => {
      //     this.show = false
      //   }, 0.6 * 1000)
      // } else {
      //   this.show = false
      // }
      // if (isLogin) {
      //   this.loginSuccessCallback && this.loginSuccessCallback()
      // } else {
      //   this.closeCallback && this.closeCallback()
      // }
    },
    closeEvent () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'dlzc;w14',
      })
      this.close('left')
    },
    backClickHandle () {
      this.close()
    },
    // 只关闭弹窗，用于短信、推送打开APP时，关闭登录弹窗
    // closeDialog () {
    //   this.show = false
    // }
  },
}
</script>
<style lang="scss" scoped>
.login-register {
  width: 100%;
  height: 100%;
  position: fixed;
  background: #ffffff;
  z-index: 1000;
  // transform: translate3d(0, 100%, 0);
}
// .login-native {
//   // transform: translate3d(0, 0, 0);
// }
.close {
  margin-top: 20px;
  width: rc(40);
  height: rc(40);
  background: url(../../../static/images/dialong_close.png) no-repeat left top;
  background-size: rc(40) rc(40);
}
.tabs {
  display: flex;
  font-size: rc(36);
  margin-bottom: rc(140);
  justify-content: space-around;
  color: #bbbbbb;
}
.tabs-activation {
  color: $color-main;
  border-bottom: rc(4) solid $color-main;
}
.sms-code {
  position: relative;
}
.get-sms-code {
  height: 100%;
  display: block;
  color: #bbbbbb;
  font-size: rc(30);
  margin-left: rc(60);
}
.sms-code-activation {
  color: $color-main;
}
.login-register-wrap {
  padding: 0 rc(30);
  box-sizing: border-box;
}
.protocol {
  margin-top: rc(40);
  text-align: center;
  font-size: rc(26);
  color: $color-text-tip;
  span {
    color: $color-main;
  }
}
.forget-pass {
  display: flex;
  justify-content: space-between;
  margin: rc(35) 0 rc(80) 0;
  font-size: rc(30);
  color: $color-main;
}
.comfirm-form {
  margin-top: rc(35);
}
.img-code {
  height: 50px;
  width: rc(200);
  display: block;
  margin-left: rc(20);
}
// .login-register-in {
//   animation: animate-in 0.6s ease;
//   animation-fill-mode: forwards;
// }
// @keyframes animate-in {
//   0% {
//     transform: translate3d(0, 100%, 0);
//   }
//   100% {
//     transform: translate3d(0, 0, 0);
//   }
// }
// .login-register-out {
//   animation: animate-out 0.6s ease;
//   animation-fill-mode: forwards;
// }
// @keyframes animate-out {
//   0% {
//     transform: translate3d(0, 0, 0);
//   }
//   100% {
//     transform: translate3d(0, 100%, 0);
//   }
// }
// iphoneX、iphoneXs
@media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
  .isIOS .close {
    margin-top: 84px;
  }
}
// iphone Xs Max
@media only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) {
  .isIOS .close {
    margin-top: 84px;
  }
}
// iphone XR
@media only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2) {
  .isIOS .close {
    margin-top: 84px;
  }
}
</style>
<style lang="scss">
.comfirm-form {
  .input-content-item {
    width: 100%;
    padding-left: 8px;
    box-sizing: border-box;
  }
}
</style>
