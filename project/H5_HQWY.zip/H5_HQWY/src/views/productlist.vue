<template>
  <PageView title="贷款大全"
            :show-left="false"
            :right-txt="hasAuditPass ? '智能推荐' : ''"
            @rightClick="rightClickHandle">
    <div class="hqwy-pro-list">
      <!--pro列表-->
      <div ref="tagList"
           class="hqwy-main"
           :class="[hasAuditPass?'':'no-pass']">
        <!--遮罩层-->
        <div v-show="isNavShow"
             class="hqwy-masker dkdq-masker"
             @click="maskerHandle"></div>
        <!--筛选-->
        <div v-show="hasAuditPass"
             class="hqwy-fliter">
          <form ref="filterForm"
                action="javascript:;"
                name="filterForm">
            <section class="hqwy-filter-box">
              <ul>
                <li>
                  <input type="radio"
                         value="1"
                         name="filterStatus"
                         :checked="filterForm.filterStatus==1"
                         @click="radioFun($event, '1','dkdq;px;w73')"><a href="javascript:;">高通过 </a>
                </li>
                <li>
                  <input type="radio"
                         value="2"
                         name="filterStatus"
                         :checked="filterForm.filterStatus==2"
                         @click="radioFun($event, '2','dkdq;px;w74')"><a href="javascript:;">放款快</a>
                </li>
                <li>
                  <input type="radio"
                         value="3"
                         name="filterStatus"
                         :checked="filterForm.filterStatus==4"
                         @click="radioFun($event, '4','dkdq;px;w75')"><a href="javascript:;">额度高</a>
                </li>
              </ul>
              <div class="hqwy-fliter-btn"
                   :class="{'active':filterForm.filterMoney != 4 || filterForm.filterYear != 5 || filterForm.filterLabel != 0}"
                   @click="navSlideHandle('dkdq;sx;w76')">
                <hr />
                筛选 <i class="hqwy-filter-icon"></i><i v-if="isNavShow"
                                                      class="hqwy-trigon-icon"><span></span></i>
              </div>
            </section>
            <section class="hqwy-filter-slide"
                     :class="{'active': isNavShow == true}">
              <article class="hqwy-article">
                <h2>借款金额</h2>
                <ul>
                  <li @click="submitSeletedCodeFun('0','sx;je;w82')">
                    <input v-model="filterForm.filterMoney"
                           type="radio"
                           value="4"
                           name="filterMoney"><span>不限</span>
                  </li>
                  <li v-for="(item,index) in labelData.borrowAmount"
                      :key="index"
                      @click="submitSeletedCodeFun('0','sx;je;w'+(83+index))">
                    <input v-model="filterForm.filterMoney"
                           type="radio"
                           :value="item.dictValue"
                           name="filterMoney"><span v-text="item.dictName"></span>
                  </li>
                </ul>
              </article>
              <article class="hqwy-article">
                <h2>借款期限</h2>
                <ul>
                  <li @click="submitSeletedCodeFun('1','sx;qx;w87')">
                    <input v-model="filterForm.filterYear"
                           type="radio"
                           value="5"
                           name="filterYear"><span>不限</span>
                  </li>
                  <li v-for="(item,index) in labelData.borrowPeriod"
                      :key="index"
                      @click="submitSeletedCodeFun('1','sx;qx;w'+(88+index))">
                    <input v-model="filterForm.filterYear"
                           type="radio"
                           :value="item.dictValue"
                           name="filterYear"><span v-text="item.dictName"></span>
                  </li>
                </ul>
              </article>
              <article class="hqwy-article">
                <h2>特色标签</h2>
                <ul>
                  <li v-for="(item,index) in labelData.specialTag"
                      :key="index"
                      @click="submitSeletedCodeFun('2','sx;bq;w'+(93+index))">
                    <input v-model="filterForm.filterLabel"
                           type="radio"
                           :value="item.dictValue"
                           name="filterLabel"><span v-text="item.dictName"></span>
                  </li>
                </ul>
              </article>
              <article class="hqwy-btns flex">
                <span class="hqwy-reset"
                      :class="{'hqwy-reset-active':resetFlag == true}"
                      @click="resetHandle('sx;an;w99')">重置</span>
                <span class="hqwy-submit"
                      @click="submitHandle('sx;an;w100')">确定</span>
              </article>
            </section>
          </form>
        </div>
        <!-- <div v-show="hasAuditPass"
             class="hqwy-tip">
          <i class="hqwy-tip-icon"></i><span>据统计，申请5个以上产品，贷款成功率超过95%</span>
        </div> -->
        <ProList ref="ProList"
                 :list-params="filterForm"
                 is-recommend="1"
                 @to-abnor="getabnor"
                 @to-totalCount="gettotalCount"
                 @update-auditSts="updateAuditSts"
                 @ad-loaded="topAdLoaded">
          <div slot="banner">
            <div class="column-banner-ctr">
              <img v-if="hasAuditPass && !isEmptyObject(topAdInfos)"
                   :src="topAdInfos.img"
                   alt="topAd"
                   class="column-banner"
                   @click="topAdClick(topAdInfos, 'top')">
              <!--智能推荐-->
              <DialogDrag v-if="hasAuditPass">
                <Recommend @click.native="codeFun('dkdq;jztj;w80')"></Recommend>
              </DialogDrag>
            </div>
          </div>
        </ProList>
      </div>
      <!--<div class="toast" v-text="toastTxt" v-if="toastShow"></div>-->
      <VLoad :isload="isLoad"></VLoad>
      <!-- 过审判断 -->
      <!-- <audit-pass ref="auditPass"></audit-pass> -->
    </div>
  </PageView>
</template>
<script>
import ProList from "../components/productlist/index";
import eventCtr from "../../static/js/eventCtr";
import VLoad from "../components/load";
// import {} from "../../src/api/controller/prolist";

import { requestCommonDict } from "../../src/api/controller/common";
import utils from "../util/utils";
// import auditPass from '@/components/function/hasAuditPass'
import Recommend from "@/components/productlist/recommend";
import DialogDrag from '@/components/dialogDrag';
// var token = window.config.token;
/* eslint-disable eqeqeq */
export default {
  name: "ProductList",
  components: {
    // vAbnor,
    ProList,
    VLoad,
    Recommend,
    DialogDrag,
    // auditPass
  },
  data () {
    return {
      topAdInfos: {}, // 顶部硬广位信息
      backClickHandle: null, // 安卓物理返回键返回处理
      // tipText: "据统计，申请5个以上产品，贷款成功率超过95%",
      // isTipClick: false,
      isTipTextChange: false,
      isNavShow: false,
      isLoad: "none",
      status: 0, // 筛选状态 0/全部 1/高通过 2/放贷快 3/利息低
      filterForm: {
        url: "/api/product/filterV2",
        filterStatus: 0, //排序
        filterMoney: 4, // 价格筛选
        filterYear: 5, // 借款期限
        filterLabel: 0, //特色标签,
        currPageNo: 1, //页面默认从第一页开始
        category: "12", //分类类别
      },
      isShow: false, //网络异常时显示
      reloadText: "", //异常提示文案
      labelData: {
        borrowAmount: [],
        borrowPeriod: [],
        specialTag: [],
      },
      selectedCode: ["sx;je;w82", "sx;qx;w87", "sx;bq;w93"],
      // toastShow: false, //toast提示 默认隐藏
      toastTxt: "", //toast提示文案
      submitFlag: false, //是筛选或者排序拿到的结果
      resetFlag: false, //重置按钮是否可用
      // navParams: {
      //   nav: {
      //     backKeyHide: true,
      //     hide: true,
      //     title: {
      //       text: "贷款大全"
      //     },
      //     right: {
      //       text: "智能推荐",
      //       callback: "topPreRecommend()"
      //     },
      //     left: {
      //       hide: false
      //     }
      //   }
      // },
      hasAuditPass: false, // 是否已过审
    };
  },
  watch: {
    // 观察状态的变化
    /*'filterForm.filterStatus' (val, oldVal) {
        this.$refs.ProList.getProListsHandle();
      },*/
    filterForm: {
      //深度监听，可监听到对象、数组的变化
      handler (val) {
        if (
          val.filterMoney != 4 ||
          val.filterYear != 5 ||
          val.filterLabel != 0
        ) {
          this.resetFlag = true;
        } else {
          this.resetFlag = false;
        }
        //console.log(val.filterMoney, oldVal.filterMoney);//但是这两个值打印出来却都是一样的
      },
      deep: true,
    },
  },
  beforeRouteLeave (to, from, next) {
    if (this.$refs.tagList != undefined) {
      global.storage.set("scrollTop", this.$refs.tagList.children[1].scrollTop);
    }
    next();
  },
  beforeRouteEnter (to, from, next) {
    if (from.path === "/") {
      global.storage.set("scrollTop", 0);
    }
    next((vm) => {
      // console.log('end:', vm.$refs.tagList.children)
      setTimeout(() => {
        if (vm.$refs.tagList != undefined) {
          vm.$refs.tagList.children[1].scrollTop =
            global.storage.get("scrollTop") || 0;
        }
      }, 0);
    });
  },
  updated () {
    this.$nextTick(() => {
      if (!this.isTipTextChange && this.$refs.tagList.children != undefined) {
        this.$refs.tagList.children[1].scrollTop = global.storage.get(
          "scrollTop"
        );
      }
    });
  },
  activated () {
    this.interceptAppBack()
    var self = this;
    eventCtr.$on("maskerDownHandle", () => {
      this.maskerHandle();
    });
    if (self.isNavShow) {
      eventCtr.$emit("maskerHandle", true)
    } else {
      eventCtr.$emit("maskerHandle", false)
    }
    self.collectEventMD({
      eventId: 'jr1004',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
    })
    self.backClickHandle = null
    // 安卓点击物理返回键退出
    if (isAndroid) {
      self.$appInvoked('appCleanWeb', { history: true })
    }
    var refreshTime = localStorage.getItem("refreshTime");
    if (
      self.$needRefreshData(JSON.parse(refreshTime)["productlist"]) &&
      document.readyState === "complete"
    ) {
      window.location.reload();
      var refreshTimeObj = JSON.parse(refreshTime);
      refreshTime["productlist"] = "";
      localStorage.setItem("refreshTime", JSON.stringify(refreshTimeObj));
    }
    window.addEvent = this.addEvent;
    // window.topPreRecommend = this.topPreRecommend;
    window.vueApp = this;
  },
  created () {
    var self = this;
    global.storage.set("scrollTop", 0);
    this.isLoad = "block"; //开始loading
    setTimeout(function () {
      self.isLoad = "none";
    }, 2000);

    // this.getLabel();
    var refreshTime = localStorage.getItem("refreshTime");
    if (
      self.$needRefreshData(JSON.parse(refreshTime)["productlist"]) &&
      document.readyState === "complete"
    ) {
      window.location.reload();
      var refreshTimeObj = JSON.parse(refreshTime);
      refreshTime["productlist"] = "";
      localStorage.setItem("refreshTime", JSON.stringify(refreshTimeObj));
    }
  },
  mounted () {
    let self = this
    self.getLabel();
  },
  methods: {
    topAdLoaded (adInfos) {
      this.topAdInfos = adInfos
    },
    rightClickHandle () {
      if (this.hasAuditPass) {
        this.topPreRecommend()
      }
    },
    topAdClick (item, position) {
      this.$refs.ProList.onAdClick(item, position)
    },
    updateAuditSts (status) {
      this.hasAuditPass = status
    },
    //jsbridge在原生生命周期中会调这个方法，如果从原生跳回h5刷选刷新数据可以在这个方法中调用
    // webviewWillAppear() {
    //   if (token != window.config.token) {
    //     // this.$refs.ProList.downCallback && this.$refs.ProList.downCallback();
    //   }
    // },
    // tipClickHandle (text) {
    //   this.isTipTextChange = true;
    //   this.tipText = text;
    // },
    // tipsClickFun () {
    //   this.isTipClick = !this.isTipClick;
    // },
    //给app提供一个方法
    topPreRecommend () {
      this.$appInvoked("appExecStatistic", {
        eventId: "dkdq;jztj;w72",
        eventType: 0,
      }); //添加埋点
      this.globalRecommendClick(72)
    },
    // 下拉筛选
    navSlideHandle (eventid) {
      var self = this;
      this.isNavShow = !this.isNavShow;
      // var left = {
      //   hide: false,
      //   callback: "addEvent()"
      // };
      // self.navParams.nav.left = left;
      self.backClickHandle = self.addEvent
      eventCtr.$emit("maskerHandle", this.isNavShow);
      this.codeFun(eventid);
    },
    // 提交筛选
    submitHandle (eventid) {
      this.isNavShow = false;
      if (isAndroid) {
        this.backClickHandle = null
      }
      eventCtr.$emit("maskerHandle", false);
      //console.log(this.filterForm.filterMoney, this.filterForm.filterYear, this.filterForm.filterLabel)
      this.getResultList();
      this.codeFun(eventid);
      this.submitFlag = true;
      var self = this;
      for (var i = 0; i < self.selectedCode.length; i++) {
        self.mdAll(self.selectedCode[i]);
      }
    },
    //确定时被选中的元素执行统计事件
    submitSeletedCodeFun (type, code) {
      this.selectedCode[type] = code;
    },
    // 点击遮罩层
    maskerHandle () {
      this.isNavShow = false;
      eventCtr.$emit("maskerHandle", false);
      if (isAndroid) {
        this.backClickHandle = null
      }
      //console.log(this.filterForm.filterMoney, this.filterForm.filterYear, this.filterForm.filterLabel)
    },
    //重置
    resetHandle (eventid) {
      this.filterForm.filterMoney = 4;
      this.filterForm.filterYear = 5;
      this.filterForm.filterLabel = 0;
      this.codeFun(eventid);
    },
    //获取筛选或排序结果
    getResultList () {
      //this.isShow = false;
      this.$refs.ProList.resetUpScrollHandle();
      /*var self = this;
        var formData = {
          amount: self.filterForm.filterMoney,
          category: self.filterForm.filterLabel,
          deadline: self.filterForm.filterYear,
          sortType: self.filterForm.filterStatus
        }*/
    },
    codeFun (eventid) {
      this.$appInvoked("appExecStatistic", {
        eventId: eventid,
        eventType: 0,
      }); //添加埋点
    },
    addEvent () {
      var self = this;
      if (self.isNavShow) {
        self.isNavShow = false;
        self.backClickHandle = null
        eventCtr.$emit("maskerHandle", false);
      }
    },
    getabnor (data) {
      this.isShow = data.isShow;
      this.reloadText = data.reloadText;
    },
    //排序
    radioFun (event, value, eventid) {
      //this.isShow = false;
      this.isNavShow = false;
      eventCtr.$emit("maskerHandle", false);
      if (this.filterForm.filterStatus == value) {
        this.filterForm.filterStatus = 0;
      } else {
        this.filterForm.filterStatus = value;
      }
      this.mdAll(eventid);
      this.submitFlag = false;
    },
    getLabel () {
      var self = this;
      requestCommonDict({}).then((rst) => {
        // self.isLoad = "none"; //开始loading
        if (rst.respCode === "1000") {
          self.labelData.borrowAmount = rst.body.borrowAmount;
          self.labelData.borrowPeriod = rst.body.borrowPeriod;
          self.labelData.specialTag = rst.body.specialTag;
        }
      });
    },
    //获取结果条数
    gettotalCount (data) {
      var self = this;
      if (self.submitFlag) {
        self.toastTxt = "查询到" + data + "条产品";
        utils.toastMsg(self.toastTxt);
        // self.toastShow = true;

        setTimeout(function () {
          // self.toastShow = false;
          self.submitFlag = false;
        }, 2000);
      }
    },
  },
};
</script>
<style lang="scss" scoped="scoped">
.hqwy-masker.dkdq-masker {
  bottom: rc(100);
}
.column-banner-ctr {
  background-color: #fff;
  padding-top: rc(10);
}
.column-banner {
  display: block;
  width: 100%;
  width: rc(678);
  height: rc(180);
  border-radius: rc(12);
  margin: auto;
}

.hqwy-fliter {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  width: 100%;
  line-height: rc(80);
  height: rc(80);
  z-index: 4;
  font-size: rc(28);
  border-bottom: 1px solid #e6e6e6;
  background-color: #ffffff;
}
.hqwy-filter-box,
.flex {
  display: flex;
}

.hqwy-btns {
  height: rc(88);
  line-height: rc(88);
  background-color: #e6e6e6;
}

.hqwy-btns .hqwy-submit {
  background-color: $color-main;
  color: #ffffff;
  height: 100%;
  width: 100%;
  border-top: 1px solid $color-main;
}

.hqwy-btns span {
  flex: 1;
  color: #999999;
  font-size: rc(30);
  text-align: center;
}

.hqwy-fliter .hqwy-filter-box ul {
  flex: 1;
  display: flex;
}

.hqwy-fliter .hqwy-filter-box ul li {
  flex: 1;
  text-align: center;
  position: relative;
}

.hqwy-fliter li a {
  color: #333333;
}

.hqwy-fliter .hqwy-fliter-btn {
  width: rc(188);
  /*border-left: 1px solid #e6e6e6;*/
  text-align: center;
}

.hqwy-fliter .hqwy-fliter-btn hr {
  transform: rotate(90deg);
  position: absolute;
  width: rc(30);
  top: rc(25);
  height: 1px;
  color: #e6e6e6;
  border-top: 1px solid #e6e6e6;
  border-left: none;
  border-right: none;
  border-bottom: none;
}

.hqwy-fliter .hqwy-fliter-btn.active {
  color: $color-main;
}

.hqwy-filter-slide {
  position: absolute;
  top: rc(81);
  width: 100%;
  left: 0;
  display: none;
  overflow: hidden;
  background-color: #fff;
  z-index: 1001;
  transition: all 0.3s ease-in-out;
}

.hqwy-filter-slide.active {
  display: block;
}

.hqwy-main {
  // padding-top: rc(140);
  padding-top: rc(80);
  padding-bottom: rc(100);
  &.no-pass {
    padding-top: 0;
  }
}
.hqwy-pro-list .hqwy-main {
  position: absolute;
  overflow-x: hidden;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}

.hqwy-article {
  margin-top: rc(30);
  margin-bottom: rc(30);
  padding: rc(0 30);
}

.hqwy-article h2 {
  font-size: rc(28);
  line-height: rc(42);
  margin-bottom: rc(20);
}

.hqwy-article ul {
  overflow: hidden;
  font-size: 0;
}

.hqwy-article li {
  position: relative;
  line-height: rc(70);
  height: rc(70);
  //width: rc(220);
  float: left;
  margin: 0 2% rc(20) 0;
  width: 32%;
  //display: inline-block;
  font-size: rc(26);
  text-align: center;
  &:nth-child(3n) {
    margin-right: 0;
  }
}

.hqwy-article li input,
.hqwy-filter-box li input {
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  z-index: 2;
  border-radius: 0;
}

.hqwy-filter-box li span {
  color: #333;
}

.hqwy-filter-box input:checked + a,
.hqwy-article li input:checked + span {
  color: $color-main;
}
.hqwy-filter-box input:checked + a:after {
  content: '';
  height: 3px;
  width: rc(60);
  position: absolute;
  bottom: 0;
  left: 50%;
  margin-left: rc(-30);
  background-color: $color-main;
  border-radius: 1.5px;
}

.border1px {
  border-width: 1px;
}

@media (-webkit-min-device-pixel-ratio: 2) {
  .border1px {
    border-width: 0.6px;
  }
}

.hqwy-article li input {
  border-style: solid;
  border-color: #e8e8e8;
  border-radius: rc(36);
  /*@extend .border1px;*/
  border-width: 1px;
  box-sizing: border-box;
}

.hqwy-article li input:checked {
  background-color: rgba($color-main, 0.1);
  border-radius: rc(36);
  border-color: $color-main;
}

.hqwy-filter-icon {
  background: url('../../static/images/public_horn_01.png') 0px 0px no-repeat;
  width: rc(28);
  height: rc(28);
  display: inline-block;
  background-size: contain;
  vertical-align: middle;
}

.hqwy-fliter-btn.active .hqwy-filter-icon {
  background-image: url('../../static/images/#{$APP_NAME}/public_horn_02.png');
}

.hqwy-trigon-icon {
  width: 0;
  height: 0;
  border-width: 0 rc(24) rc(24);
  border-style: solid;
  border-color: transparent transparent #e8e8e8;
  position: absolute;
  right: rc(82);
  bottom: rc(-10);
}

.hqwy-trigon-icon span {
  display: block;
  width: 0;
  height: 0;
  border-width: 0 rc(20) rc(20);
  border-style: solid;
  border-color: transparent transparent #ffffff;
  position: absolute;
  bottom: rc(-22);
  left: rc(-20);
}

.other-pro {
  display: none;
}

.toast {
  position: fixed;
  left: 50%;
  top: 50%;
  border-radius: rc(16);
  background-color: rgba(0, 0, 0, 0.7);
  width: rc(480);
  height: rc(90);
  margin-left: rc(-240);
  margin-top: rc(-45);
  line-height: rc(90);
  text-align: center;
  color: #fff;
  font-size: rc(30);
}

.hqwy-reset {
  background-color: #f2f2f2;
  color: #999;
  border-top: 1px solid #e6e6e6;
}

.hqwy-btns .hqwy-reset-active {
  background: #fff;
  color: #333;
}

.hqwy-tip {
  background-color: $bgColor-list-order;
  z-index: 2;
  position: absolute;
  width: 100%;
  top: rc(82);
  text-align: left;
  font-size: rc(24);
  line-height: rc(60);
  color: $color-text-tip;
  padding-left: rc(30);
}

.hqwy-tip-icon {
  display: inline-block;
  width: rc(32);
  height: rc(32);
  background: url(../../static/images/public_horn_03.png) 0 0 no-repeat;
  background-size: contain;
  vertical-align: text-bottom;
  margin-right: 5px;
}
</style>
