<template>
  <PageView type="fillinfo-page"
            title="填写信息，一键贷款"
            :is-back-page="false"
            @backClick="backClickHandle">
    <div class="fillInfoCon">
      <img class="fillinfo-banner"
           src="../../static/images/banner-zntj.png"
           alt="智能贷款推荐。真实信息，成功率更高">
      <!-- <div class="ident">
        <div class="ident-title">
          我是
        </div>
        <ul>
          <li v-for="(ident,index) in identList"
              :key="index"
              class="b-1px fillinfo-label"
              :class="{active:occupation==ident.dictValue}"
              @click="changeIdent(ident.dictValue)">
            {{ ident.dictName }}
          </li>
        </ul>
      </div> -->
      <div class="count">
        <div class="count-title">
          借多少(元)
        </div>
        <ul>
          <li v-for="(count,index) in countList"
              :key="index"
              class="b-1px fillinfo-label"
              :class="{active:amount==count.dictValue}"
              @click="changeCount(count.dictValue,count.dictName)">
            {{ count.dictName }}
          </li>
        </ul>
      </div>
      <div class="count">
        <div class="count-title">
          借多久
        </div>
        <ul>
          <li v-for="(borrow,index) in borrowList"
              :key="index"
              class="b-1px fillinfo-label"
              :class="{active:deadline==borrow.dictValue}"
              @click="getBorrow(borrow.dictValue)">
            {{ borrow.dictName }}
          </li>
        </ul>
      </div>
      <div class="input-info">
        <!-- <div class="items bb-1px">
          <div class="items-left">
            借多久
          </div>
          <div class="items-right borrow"
               @click="borrow">
            <span :class="{intocolor:borrowText!='借款期限'}">{{ borrowText }}</span>
            <img src="../../static/images/arrow.png">
          </div>
        </div> -->
        <div class="items bb-1px">
          <div class="items-left">
            芝麻分
          </div>
          <div class="items-right sesame"
               @click="sesame">
            <span :class="{intocolor:sesameText!='请选择'}">{{ sesameText }}</span>
            <img src="../../static/images/arrow.png">
          </div>
        </div>
        <div class="items bb-1px">
          <div class="items-left">
            手机号使用时长
          </div>
          <div class="items-right phone">
            <ul>
              <li v-for="(phone,index) in phoneUse"
                  :key="index"
                  class="b-1px fillinfo-label"
                  :class="{active:phoneNumServiceTime==phone.dictSort}"
                  @click="getPhone(phone.dictValue)">
                {{ phone.dictName }}
              </li>
            </ul>
          </div>
        </div>
        <div class="items bb-1px">
          <div class="items-left">
            是否有信用卡
          </div>
          <div class="items-right phone">
            <ul>
              <li v-for="(card,index) in cardList"
                  :key="index"
                  :class="{active:creditCard==card.dictValue}"
                  class="yesno b-1px fillinfo-label"
                  @click="getCard(card.dictValue)">
                {{ card.dictName }}
              </li>
            </ul>
          </div>
        </div>
        <div class="items">
          <div class="items-left">
            是否缴纳公积金
          </div>
          <div class="items-right phone">
            <ul>
              <li v-for="(fu,index) in fundList"
                  :key="index"
                  :class="{active:fund==fu.dictValue}"
                  class="yesno b-1px fillinfo-label"
                  @click="getFunds(fu.dictValue)">
                {{ fu.dictName }}
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="apply-button">
        <div class="jrcs-btn"
             :class="disabled?'disabled':''"
             @click="recommonBtn('jztj;txxx;wntj;w101')">
          一键智能推荐
        </div>
      </div>
      <div v-if="isShowBorrow || isShowSesame"
           class="mask"
           @click="close"></div>
      <!--借多久弹框-->
      <!-- <div v-if="isShowBorrow"
           class="borrow-pro">
        <div class="tip-content">
          <div class="borrow-title">
            借款期限
          </div>
          <ul>
            <li v-for="(borrow,index) in borrowList"
                :key="index"
                @click="getBorrow(borrow.dictName,borrow.dictValue)">
              {{ borrow.dictName }}
            </li>
          </ul>
        </div>
        <div class="cancelBorrow"
             @click="cancelBorrow">
          取消
        </div>
      </div> -->
      <!--芝麻分弹框-->
      <div v-if="isShowSesame"
           class="sesame-pro">
        <div class="tip-content">
          <div class="sesame-title">
            芝麻分
          </div>
          <ul>
            <li v-for="(score,index) in scoreList"
                :key="index"
                @click="getSesame(score.dictName,score.dictValue)">
              {{ score.dictName }}
            </li>
          </ul>
        </div>
        <div class="cancelSesame"
             @click="cancelSesame">
          取消
        </div>
      </div>
    </div>
    <div slot="dialog">
      <VLoad :isload="isLoad"></VLoad>
      <Loading v-show="show.isLoading"></Loading>
      <BackConfirm ref="backComfirm"
                   title
                   cancel-txt="确认放弃"
                   sure-txt="我要领取"
                   txt-style="center"
                   txt="成功率高达<span class='remind-txt'>90%</span>的产品求领取！<br>确认放弃？"
                   @on-cancel="backConfirmCancel()"
                   @on-confirm="backConfirmConfirm()">
      </BackConfirm>
    </div>
  </PageView>
</template>

<script>
import VLoad from "../components/load.vue"; //页面loading组件
import Loading from "../components/loading/loading";
import BackConfirm from "../components/confirm/BackConfirm";
import {
  requestUserInfo,
  requestSaveData,
  requestCommonDict,
} from "../../src/api/controller/common";
import utils from "../util/utils.js";
/* eslint-disable eqeqeq */
export default {
  components: {
    // vAbnor,
    VLoad,
    Loading,
    BackConfirm,
  },
  data () {
    return {
      disabled: true, // 按钮是否可点击
      isShowBorrow: false,
      isShowSesame: false,
      // borrowText: "借款期限",
      sesameText: "请选择",
      //我是
      // identList: [],
      //借多少
      countList: [],
      //借多久
      borrowList: [],
      //芝麻分
      scoreList: [],
      //手机号使用时长
      phoneUse: [],
      //是否有信用卡
      cardList: [],
      //是否缴纳公积金
      fundList: [],
      // occupation: -1, //我是
      amount: -1, //借多少
      deadline: -1, //借多久
      zhima: -1, //芝麻分
      creditCard: -1, //是否有信用卡
      fund: -1, //是否缴纳公积金
      phoneNumServiceTime: -1, //手机号是否使用超过6个月
      isLoad: "none", //默认页面没有loading动画
      userName: "",
      userData: "",
      show: {
        isLoading: false,
      },
    };
  },
  activated () {
    this.interceptAppBack()
    var self = this;
    // alert(self.$route.query.w)
    let w = self.$route.query.w
    if (w) {
      self.collectEventMD({
        eventId: `ly1002,w${w}`,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
      })
    }
    self.isLoad = "block"; //开始loading
    self.collectEventMD({
      eventId: 'jr1012',
      eventResult: 1,
      eventStartTime: new Date().getTime(),
    })

    // window.showDialog = this.showDialog;
    self.$nextTick(function () {
      self.getdictList();
    });
  },
  methods: {
    //数据字典接口
    getdictList () {
      var self = this;

      requestCommonDict({}).then((data) => {
        var repData = data;
        if (repData.respCode === "1000") {
          // self.identList = repData.body.career; //身份
          self.countList = repData.body.borrowAmount; //借多少
          self.borrowList = repData.body.borrowPeriod; //借款期限
          self.scoreList = repData.body.creditScore; //芝麻分
          self.phoneUse = repData.body.phoneUseTime; //手机号使用时长
          self.cardList = repData.body.creditCardFlag; //是否使用信用卡
          self.fundList = repData.body.fundFlag; //是否缴纳公积金
          self.getfillInfo();
        }
      })
    },
    //页面信息回显
    getfillInfo () {
      var self = this;

      requestUserInfo({}).then(
        (data) => {
          var repData = data;
          self.isLoad = "none"; //结束loading
          self.userData = repData.body;
          //                   var repData=JSON.parse('{"respCode":"1000","respMsg":"成功!","body":{"source":null,"userId":null,"userName":null,"identityCard":null,"career":1,"income":null,"education":null,"borrowAmount":0,"borrowPeriod":3,"creditScore":1,"phoneUseTime":1,"creditCardFlag":0,"fundFlag":1,"socialSecurityFlag":null,"car":null,"house":null}}');
          if (repData.respCode === "1000") {
            let sourcePage = self.$route.query.sourcePage // FINISH表示点击“重新智能推荐”，切所有资料填写完成。此时借款金额和借款期限字段需置为空
            // if (repData.body.career != null) {
            //   self.occupation = repData.body.career; //我是
            // } else {
            //   self.occupation = -1; //我是
            // }
            if (repData.body.borrowAmount != null && sourcePage !== 'FINISH') {
              self.amount = repData.body.borrowAmount; //借多少
            } else {
              self.amount = -1; //借多少
            }
            if (repData.body.creditCardFlag != null) {
              self.creditCard = repData.body.creditCardFlag; //是否有信用卡
            } else {
              self.creditCard = -1; //是否有信用卡
            }
            if (repData.body.fundFlag != null) {
              self.fund = repData.body.fundFlag; //是否缴纳公积金
            } else {
              self.fund = -1;
            }
            if (repData.body.phoneUseTime != null) {
              self.phoneNumServiceTime = repData.body.phoneUseTime; //手机号是否使用超过6个月
            } else {
              self.phoneNumServiceTime = -1; //手机号是否使用超过6个月
            }
            if (repData.body.borrowPeriod != null && sourcePage !== 'FINISH') {
              self.deadline = repData.body.borrowPeriod; //借多久
            } else {
              self.deadline = -1; //借多久
            }
            if (repData.body.creditScore != null) {
              self.zhima = repData.body.creditScore; //芝麻分
            } else {
              self.zhima = -1; //芝麻分
            }
            //						console.log("借多久：" + self.deadline)
            // let borrowList = self.borrowList
            // self.borrowText = '借款期限'
            // for (let i = 0; i < borrowList.length; i++) {
            //   if (borrowList[i].dictValue == self.deadline) {
            //     self.borrowText = self.borrowList[i].dictName
            //     break
            //   }
            // }
            //						console.log("芝麻分：" + self.zhima)
            let scoreList = self.scoreList
            self.sesameText = '请选择'
            for (let j = 0; j < scoreList.length; j++) {
              if (self.scoreList[j].dictValue == self.zhima) {
                self.sesameText = self.scoreList[j].dictName
                break
              }
            }
            self.$nextTick(() => {
              self.checkBtnStatus()
            })
          }
        },
        () => {
          self.isLoad = 'none'
          // self.reloadText = {
          //   reloadText: "网络异常",
          //   defaultImg: this.getCachedImages("loadFailIcon")
          // };
          // self.isShow = true;
        }
      );
      // setTimeout(function() {
      // 	self.isLoad = "none"; //结束loading
      // }, 2000)
    },
    //用户填写信息提交
    // addUserInfo() {
    //   var self = this;
    //   var borrowAmount;
    //   if (self.amount != -1) {
    //     borrowAmount = parseInt(self.amount);
    //   } else {
    //     borrowAmount = "";
    //   }
    //   var creditCardFlag;
    //   if (self.creditCard != -1) {
    //     creditCardFlag = parseInt(self.creditCard);
    //   } else {
    //     creditCardFlag = "";
    //   }
    //   var borrowPeriod;
    //   if (self.deadline != -1) {
    //     borrowPeriod = parseInt(self.deadline);
    //   } else {
    //     borrowPeriod = "";
    //   }
    //   var fundFlag;
    //   if (self.fund != -1) {
    //     fundFlag = parseInt(self.fund);
    //   } else {
    //     fundFlag = "";
    //   }
    //   var career;
    //   if (self.occupation != -1) {
    //     career = parseInt(self.occupation);
    //   } else {
    //     career = "";
    //   }
    //   var phoneUseTime;
    //   if (self.phoneNumServiceTime != -1) {
    //     phoneUseTime = parseInt(self.phoneNumServiceTime);
    //   } else {
    //     phoneUseTime = "";
    //   }
    //   var creditScore;
    //   if (self.zhima != -1) {
    //     creditScore = parseInt(self.zhima);
    //   } else {
    //     creditScore = "";
    //   }
    //   let requestParams = {
    //     borrowAmount: borrowAmount,
    //     borrowPeriod: borrowPeriod,
    //     car: self.formateParam(self.userData.car),
    //     career: career,
    //     creditCardFlag: creditCardFlag,
    //     creditScore: creditScore,
    //     education: self.formateParam(self.userData.education),
    //     fundFlag: fundFlag,
    //     house: self.formateParam(self.userData.house),
    //     identityCard: self.userData.identityCard || "",
    //     income: self.formateParam(self.userData.income),
    //     phoneUseTime: phoneUseTime,
    //     socialSecurityFlag: self.formateParam(self.userData.socialSecurityFlag),
    //     source: 2,
    //     userName: self.userData.userName || ""
    //   };
    //   requestSaveData(requestParams).then(
    //     data => {
    //       var repData = data;
    //       if (repData.respCode == "1000") {
    //         localStorage.setItem("redPoint", "");
    //       } else {
    //         utils.toastMsg(repData.respMsg);
    //       }
    //     },
    //     err => {
    //       self.reloadText = {
    //         reloadText: "网络异常",
    //         defaultImg: this.getCachedImages("loadFailIcon")
    //       };
    //       self.isShow = true;
    //     }
    //   );
    // },
    backConfirmCancel () {
      var self = this;
      // self.addUserInfo(); // 确认放弃，保存用户填写信息
      self.$appInvoked("appExecStatistic", {
        eventId: "jztj;txxx;fhtc;w104",
        eventType: 0,
      }); //添加埋点
      self.$routerGo(-1);
    },
    backConfirmConfirm () {
      this.$appInvoked("appExecStatistic", {
        eventId: "jztj;txxx;fhtc;w103",
        eventType: 0,
      }); //添加埋点
    },
    backClickHandle () {
      var self = this;
      if (self.isShowBorrow || self.isShowSesame) {
        self.isShowBorrow = false;
        self.isShowSesame = false;
        return;
      }
      self.$appInvoked("appExecStatistic", {
        eventId: "jztj;txxx;fh;w102",
        eventType: 0,
      }); //添加返回埋点
      self.$refs.backComfirm.show();
    },
    formateParam (param) {
      if (param != null && param != -1) {
        return param;
      } else {
        return -1;
      }
    },
    // borrow () {
    //   this.isShowBorrow = true
    // },
    sesame () {
      this.isShowSesame = true
    },
    // cancelBorrow () {
    //   this.isShowBorrow = false
    // },
    cancelSesame () {
      this.isShowSesame = false
    },
    close () {
      // this.isShowBorrow = false
      this.isShowSesame = false
    },
    getBorrow (val) {
      this.deadline = val
      // this.borrowText = data
      // this.isShowBorrow = false
      this.checkBtnStatus()
    },
    getSesame (data, id) {
      this.zhima = id
      this.sesameText = data
      this.isShowSesame = false
      this.checkBtnStatus()
    },
    //获取手机号使用时长
    getPhone (isPhone) {
      this.phoneNumServiceTime = isPhone
      this.checkBtnStatus()
    },
    //获取是否有信用卡
    getCard (isCard) {
      this.creditCard = isCard
      this.checkBtnStatus()
    },
    //获取是否缴纳公积金
    getFunds (isFund) {
      this.fund = isFund
      this.checkBtnStatus()
    },
    //选择用户身份
    // changeIdent (index) {
    //   this.occupation = index
    //   this.checkBtnStatus()
    // },
    //选择借多少
    changeCount (index) {
      this.amount = index
      this.checkBtnStatus()
    },
    // 判断按钮是否可点击
    checkBtnStatus () {
      if (
        this.fund !== -1
        && this.creditCard !== -1
        && this.phoneNumServiceTime !== -1
        && this.zhima !== -1
        && this.deadline !== -1
        && this.amount !== -1
        // && this.occupation !== -1
      ) {
        this.disabled = false
      } else {
        this.disabled = true
      }
    },
    //填写信息提交
    recommonBtn (eventid) {
      var self = this;
      self.$appInvoked("appExecStatistic", {
        eventId: eventid,
        eventType: 0,
      }); //添加埋点
      self.collectEventMD({
        eventId: eventid,
        eventResult: 1,
        eventStartTime: new Date().getTime(),
      })
      // self.clickReport('', '', eventid)
      // if (self.occupation === -1) {
      //   utils.toastMsg("请填写职业身份");
      // } else 
      if (self.amount === -1) {
        utils.toastMsg("请填写借款金额");
      } else if (self.deadline === -1) {
        utils.toastMsg("请填写借款期限");
      } else if (self.zhima === -1) {
        utils.toastMsg("请填写芝麻分");
      } else if (self.phoneNumServiceTime === -1) {
        utils.toastMsg("请填写手机号使用时长");
      } else if (self.creditCard === -1) {
        utils.toastMsg("请填写信用卡信息");
      } else if (self.fund === -1) {
        utils.toastMsg("请填写公积金缴纳信息");
      } else {
        self.show.isLoading = true;
        localStorage.setItem("isFill", true);
        var borrowAmount;
        if (self.amount !== -1) {
          borrowAmount = parseInt(self.amount, 10);
        } else {
          borrowAmount = "";
        }
        var creditCardFlag;
        if (self.creditCard !== -1) {
          creditCardFlag = parseInt(self.creditCard, 10);
        } else {
          creditCardFlag = "";
        }
        var borrowPeriod;
        if (self.deadline !== -1) {
          borrowPeriod = parseInt(self.deadline, 10);
        } else {
          borrowPeriod = "";
        }
        var fundFlag;
        if (self.fund !== -1) {
          fundFlag = parseInt(self.fund, 10);
        } else {
          fundFlag = "";
        }
        // var career;
        // if (self.occupation !== -1) {
        //   career = parseInt(self.occupation, 10);
        // } else {
        //   career = "";
        // }
        var phoneUseTime;
        if (self.phoneNumServiceTime !== -1) {
          phoneUseTime = parseInt(self.phoneNumServiceTime, 10);
        } else {
          phoneUseTime = "";
        }
        var creditScore;
        if (self.zhima !== -1) {
          creditScore = parseInt(self.zhima, 10);
        } else {
          creditScore = "";
        }
        //保存用户信息

        let requestParams = {
          borrowAmount: borrowAmount,
          borrowPeriod: borrowPeriod,
          car: self.formateParam(self.userData.car),
          // career: career,
          creditCardFlag: creditCardFlag,
          creditScore: creditScore,
          education: self.formateParam(self.userData.education),
          fundFlag: fundFlag,
          house: self.formateParam(self.userData.house),
          identityCard: self.userData.identityCard || "",
          income: self.formateParam(self.userData.income),
          phoneUseTime: phoneUseTime,
          socialSecurityFlag: self.formateParam(
            self.userData.socialSecurityFlag
          ),
          source: 2,
          userName: self.userData.userName || "",
        };
        requestSaveData(requestParams).then(
          (data) => {
            var repData = data;
            self.show.isLoading = false;
            if (repData.respCode === "1000") {
              localStorage.setItem("redPoint", "");
              self.$routerReplace(
                "/recommendList1" +
                // "?occupation=" + career +
                "?amount=" + borrowAmount +
                "&deadline=" + borrowPeriod +
                "&zhima=" + creditScore +
                "&creditCard=" + creditCardFlag +
                "&fund=" + fundFlag +
                "&phoneNumServiceTime=" + phoneUseTime +
                "&w=" + self.$route.query.w
              );
            } else {
              utils.toastMsg(repData.respMsg);
            }
          },
          () => {
            self.show.isLoading = false;
            // self.reloadText = {
            //   reloadText: "网络异常",
            //   defaultImg: this.getCachedImages("loadFailIcon")
            // };
            // self.isShow = true;
          }
        );
      }
    },
  },
};
</script>

<style lang="scss">
.fillInfoCon {
  .loading {
    bottom: 0 !important;
  }
}
.fillinfo-page {
  .hy-confirm-center {
    position: relative;
  }
}
</style>
<style lang="scss" scoped="scoped">
.fillinfo-banner {
  width: 100%;
  height: rc(200);
  background-color: $bgColor-list-order;
  display: block;
}

.input-info {
  margin-top: rc(20);
  background: #fff;
  /*margin-bottom: rc(100);*/
  .items {
    padding: rc(0 30);
    height: rc(96);
    line-height: rc(96);
    display: flex;
    display: -webkit-flex;
    font-size: rc(30);
    color: #333333;
    letter-spacing: 0;
    .items-left {
      flex: 1;
      -webkit-flex: 1;
    }
    .items-right {
      text-align: right;
      font-size: rc(26);
      color: #333;
      letter-spacing: 0;
      span {
        color: #aaa;
      }
      .intocolor {
        color: #333;
      }
      img {
        margin-left: rc(15);
        width: rc(15);
        height: rc(26);
      }
    }
  }
}

// .ident {
//   width: 100%;
//   height: rc(204);
//   background: #fff;
//   padding-top: rc(10);
//   .ident-title {
//     height: rc(90);
//     line-height: rc(90);
//     font-size: rc(30);
//     color: #111111;
//     padding-left: rc(30);
//     font-weight: bold;
//   }
//   ul {
//     white-space: nowrap;
//     padding: rc(10 30 0);
//     display: flex;
//     li {
//       flex: 1;
//       width: rc(160);
//       //margin-left: rc(13);
//       margin-right: rc(13);
//       &:last-child {
//         margin-right: 0;
//       }
//     }
//   }
// }
li.b-1px.fillinfo-label {
  height: rc(60);
  line-height: normal;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: rc(26);
  border-radius: rc(100);
  &::after {
    top: 0;
    left: 0;
  }
  &.active {
    background-color: rgba($color-main, 0.1);
    color: $color-main;
    &::after {
      border-color: $color-main;
    }
  }
}

.count {
  width: 100%;
  height: rc(300);
  background: #fff;
  .count-title {
    height: rc(90);
    line-height: rc(90);
    font-size: rc(30);
    color: #111111;
    padding-left: rc(30);
    font-weight: bold;
  }
  ul {
    padding: rc(10 30 0);
    overflow: hidden;
    li {
      float: left;
      margin: rc(20) 1.4% rc(1) 0;
      width: 32.4%;
      box-sizing: border-box;
      &:nth-child(3n) {
        margin-right: 0;
      }
    }
  }
}

.apply-button {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: rc(96);
  text-align: center;
  background: #fff;
  padding: rc(20) rc(30);
  .jrcs-btn {
    border-radius: rc(100);
    color: white;
    font-size: rc(34);
    height: 100%;
  }
}

.mask {
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  z-index: 99;
  background: #000000;
  opacity: 0.4;
}

.borrow-pro,
.sesame-pro {
  width: 100%;
  position: fixed;
  bottom: 0;
  text-align: center;
  z-index: 100;
  background: #f8f8f8;
  min-height: rc(100);
  ul {
    border-radius: 3px;
    li {
      height: rc(96);
      line-height: rc(96);
      border-bottom: 1px solid #eeeeee;
      background: #fff;
      font-size: rc(30);
      color: #333333;
      letter-spacing: 0;
    }
    li:last-child {
      border-bottom: none;
    }
  }
  .cancelBorrow,
  .cancelSesame {
    margin-top: rc(20);
    height: rc(96);
    line-height: rc(96);
    background: #fff;
    font-size: rc(30);
    color: #333333;
    letter-spacing: 0;
  }
  .borrow-title,
  .sesame-title {
    height: rc(96);
    line-height: rc(96);
    background: #fff;
    border-bottom: 1px solid #eeeeee;
    font-size: rc(30);
    color: #999999;
    letter-spacing: 0;
  }
}

.phone {
  ul {
    text-align: right;
    li {
      float: left;
      width: rc(160);
      margin-top: rc(18);
      margin-left: rc(20);
      &:first-child {
        margin-left: 0;
      }
    }
    .yesno {
      width: rc(160);
      text-align: center;
    }
  }
}

.fillInfoCon {
  width: 100%;
  overflow: hidden;
  margin-bottom: rc(160);
}
</style>
