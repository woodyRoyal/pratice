import Vue from 'vue'
import Vuex from 'vuex'
import loginModule from './modules/loginModule'
import loaninfoModule from './modules/loaninfoModule'
import redPointModule from './modules/redPointModule'
import baseInfoModule from './modules/baseInfoModule'
import dialogModule from './modules/dialogModule'

Vue.use(Vuex)

const vuex = new Vuex.Store({
  modules: {
    login: loginModule,
    loaninfo: loaninfoModule,
    redPoint: redPointModule,
    baseInfo: baseInfoModule,
    dialog: dialogModule,
  },
})

export default vuex
