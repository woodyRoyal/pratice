const state = {
  mainWindowAd: { // 首页弹窗广告
    show: false,
  },
}
const mutations = {
  mainWindowAd (state, show) {
    state.mainWindowAd.show = show
  },
}
export default { state, mutations }
