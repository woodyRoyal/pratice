const state = {
  userName: '',
  userId: '',
  userData: {},
}

const mutations = {
  USER_NAME (state, userName) {
    state.userName = userName
  },
  USER_ID (state, idNumber) {
    state.userId = idNumber
  },
  USER_DATA (state, userData) {
    state.userData = userData
  },
}

const actions = {
  USER_DATA (obj) {
    obj.commit('userData')
  },
}

export default { state, mutations, actions }
