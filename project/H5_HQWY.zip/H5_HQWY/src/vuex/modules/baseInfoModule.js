const SET_HEADER_INFO = 'SET_HEADER_INFO'
const state = {
  appVersion: '',
  phoneNumber: '',
  headerInfo: {},
  userName: '',
  userIdcard: '',
  hasAuth: false, // 姓名身份证号是否通过同盾认证
}

const mutations = {
  APP_VERSION (state, version) {
    state.appVersion = version
  },
  PHONE_NUMBER (state, phone) {
    state.phoneNumber = phone
  },
  [SET_HEADER_INFO] (state, obj) {
    state.headerInfo = obj
  },
  USER_NAME (state, str) {
    state.userName = str
  },
  USER_IDCARD (state, str) {
    state.userIdcard = str
  },
  hasAuth (state, bol) {
    state.hasAuth = bol
  },
}

const actions = {
  setHeaderInfo ({ commit }, rst) {
    commit(SET_HEADER_INFO, rst)
  },
}

const getters = {
  headerInfo (state) {
    return state.headerInfo
  },
}

export default { state, mutations, actions, getters }
