const state = {
  mineTab: {
    lastShowTime: '',
    isShow: false,
  },
  loaninfoItem: {
    lastShowTime: '',
    isShow: false,
  },
  orderDotRemark: {
    // 0-不展示，1-展示
    overDue: false, // 是否有逾期
    remark: false, // 是否展示小红点
  },
}
const mutations = {
  mineTab (state, payload) {
    state.mineTab.lastShowTime = payload.lastShowTime
    state.mineTab.isShow = payload.isShow
  },
  loaninfoItem (state, payload) {
    state.loaninfoItem.lastShowTime = payload.lastShowTime
    state.loaninfoItem.isShow = payload.isShow
  },
  orderDotRemark (state, payload) {
    state.orderDotRemark.overDue = payload.overDue
    state.orderDotRemark.remark = payload.remark
  },
}
export default { state, mutations }
