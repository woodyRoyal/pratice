const state = {
  userToken: '',
  isLogin: false,
}
const mutations = {
  USER_TOKEN (state, payload) {
    state.userToken = payload
    if (payload !== '') {
      state.isLogin = true
    } else {
      state.isLogin = false
    }
  },
}
export default { state, mutations }
