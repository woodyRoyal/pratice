/* eslint-disable eqeqeq */
import axios from 'axios'
import qs from 'qs'
import utils from '../util/utils'
import store from '../vuex/store'

// jsonContentTypeList 中的接口需要特殊处理
let jsonContentTypeList = [
  '/mem/user/join/register',
  // '/api/index/recommend',
  '/mem/userinfo/saveData',
  // '/api/product/filter',
  '/mem/order/redRemark/queryStatus',
  '/mem/order/redRemark/updateStatus',
  '/mem/user/join/loan/hit',
  '/mem/collect/collectEvent',
  '/mem/loanEntry/query',
  '/mem/order/list',
  '/mem/order/getLoanUrlOrRepayUrl',
  '/mem/ocr/saveOcrInfo',
  '/mem/ocr/getProviderInfo',
  '/mem/ocr/faceCompare',
  '/mem/loanEntry/queryContacts',
  '/mem/loanEntry/saveContacts',
  '/mem/loanEntry/queryOtherInfo',
  '/mem/loanEntry/saveOtherInfo',
  '/mem/userinfo/getData',
  '/mem/userinfo/saveBaseInfo',
  '/mem/index/getAllDistricts',
  '/mem/order/submit',
  '/mem/loanEntry/submitAuthStatus',
  '/mem/order/queryRecentOrder',
]

// axios全局配置
axios.defaults.withCredentials = true
axios.defaults.timeout = 20000
axios.defaults.retry = 1
axios.defaults.retryDelay = 1000

/**
 * 获取请求头设置
 *
 * @param config
 * @returns {Promise<any>}
 */
function reqInterceptor (config) {
  return new Promise((resolve) => {
    let cacheAjaxHeader = localStorage.getItem('cacheAjaxHeader') || ''
    if (window.vm.$tools.getBrowser() === 'android' && cacheAjaxHeader) {
      cacheAjaxHeader = JSON.parse(cacheAjaxHeader)
      if (new Date().getTime() - cacheAjaxHeader.time > 3000) {
        appGetAjaxHeaderCb(config, resolve)
      } else {
        let rst = cacheAjaxHeader.ajaxHeader
        if (rst.os === 'iOS') rst.os = 'ios' // 这里统一一下os字段
        if (config.url === '/api/product/click/report') {
          config.headers.appVersionCode = rst.innerVersion
          config.headers.projectSymbol = rst.projectMark
        }
        config.headers = Object.assign({}, config.headers, rst)
        if (config.method === 'post' && config.data && config.data.type === 'upload') {
          config.data = config.data.form
        }
        return resolve(config)
      }
    } else {
      appGetAjaxHeaderCb(config, resolve)
    }
    // window.vm.$appInvoked('appGetAjaxHeader', {}, rst => {
    //   localStorage.setItem('cacheAjaxHeader', JSON.stringify({
    //     time: new Date().getTime(),
    //     ajaxHeader: rst
    //   }))
    //   if (rst.os == 'iOS') rst.os = 'ios' // 这里统一一下os字段
    //   config.headers = Object.assign({}, config.headers, rst)
    //   if (config.method === 'post' && config.data && config.data.type === 'upload') {
    //     config.data = config.data.form
    //   }
    //   return resolve(config)
    // })
  })
}
function appGetAjaxHeaderCb (config, resolve) {
  window.vm.$appInvoked('appGetAjaxHeader', {}, (rst) => {
    localStorage.setItem('cacheAjaxHeader', JSON.stringify({
      time: new Date().getTime(),
      ajaxHeader: rst,
    }))
    if (rst.os === 'iOS') rst.os = 'ios' // 这里统一一下os字段
    if (config.url === '/api/product/click/report') {
      config.headers.appVersionCode = rst.innerVersion
      config.headers.projectSymbol = rst.projectMark
    }
    config.headers = Object.assign({}, config.headers, rst)
    if (config.method === 'post' && config.data && config.data.type === 'upload') {
      config.data = config.data.form
    }
    return resolve(config)
  })
}

// 请求拦截
axios.interceptors.request.use(
  function (config) {
    let isApp = window.vm.$tools.getBrowser() === 'iOS' || window.vm.$tools.getBrowser() === 'android'
    if (jsonContentTypeList.indexOf(config.url) > -1) {
      config.headers['Content-Type'] = 'application/json;charset=utf-8'
    }
    if (isApp) {
      // 过审判断
      let precise = localStorage.getItem('AUDIT-PASS')
      if (precise == 0 && ['/api/product/click/report', '/mem/collect/collectEvent'].indexOf(config.url) > -1) {
        config.headers['precise'] = 0
      }
      return reqInterceptor(config).then((rst) => rst)
    } else {
      if (config.method === 'post' && config.data && config.data.type === 'upload') {
        config.data = config.data.form
      }
      // config.headers = Object.assign({}, config.headers, {
      //   token: '2CFAD3B63C3B50D2C21D5759F63098CA7271A558828B529049DA7ADB632F01E24C34B7EFF180779830D87A66025820CB',
      //   version: '3.0.0',
      //   pid: 902
      // })
      return config
    }
  },
  (error) => Promise.reject(error)
)
let timestamp1 = Date.parse(new Date())
// 接口异常监控参数
let exceptionData = {
  errorContent: '', // 错误内容
  errorType: '', // 错误类型 string
  requestUrl: '', // 接口url string
  requestUrlFunction: '', // 接口url - 标识 string
  responseTime: '', // 响应时间 string
  mobile: '',
}

// 返回拦截
axios.interceptors.response.use(
  function (rst) {
    if (rst.data.respCode === '1000' || rst.data.respCode === '1058') {
      return Promise.resolve(rst.data)
    } else if (rst.data.respCode === '1001') {
      let timestamp2 = Date.parse(new Date())
      let errContent = {}
      if (rst.config.url === '/mem/collect/collectEvent') {
        let requestParams = params2Json(rst.config.data)
        errContent.eId = requestParams.eventId
      }
      errContent.code = rst.data.respCode
      errContent.msg = rst.data.respMsg
      errContent.ph = rst.config.headers['productHidden']
      if (store.state.baseInfo.appVersion.split('.').join('') <= 230) {
        let httpHeader = rst.config.headers
        errContent.uid = httpHeader['userId']
      }
      let url = rst.config.url || rst.request.responseURL
      exceptionData.errorContent = JSON.stringify(errContent).substr(0, 200)
      exceptionData.errorType = '30'
      exceptionData.requestUrl = url
      exceptionData.requestUrlFunction = rst.config.url || ''
      exceptionData.responseTime = timestamp2 - timestamp1
      exceptionData.mobile = store.state.baseInfo.phoneNumber
      window.vm.$appInvoked('appUrlExceptionMonitor', exceptionData, '')
      // console.log("---->接口异常了" + JSON.stringify(exceptionData));
      // console.error(exceptionData.errContent)
      utils.toastMsg(rst.data.respMsg)
      return Promise.reject(rst.data)
    } else if (['1103', '1202', '1063'].indexOf(rst.data.respCode) > -1) {
      return Promise.reject(rst.data)
    } else if (['1004', '1057'].indexOf(rst.data.respCode) > -1) {
      // token失效或账户被注销
      utils.toastMsg('登录失效')
      window.vm.$appInvoked('appClearUser', {})
      localStorage.clear()
      window.vm.$routerReplace('/home')
      // window.vm.$appInvoked('appExecLogout', '', function (data) {
      //   if (data == true) {
      //     localStorage.clear()
      //     window.vm.$router.replace('/index')
      //   }
      // })
      return Promise.reject(rst.data)
    }
    utils.toastMsg(rst.data.respMsg)
    return Promise.reject(rst.data)
  },
  function (error) {
    let timestamp2 = Date.parse(new Date())
    let httpHeader = error.config.headers
    if (error.code === 'ECONNABORTED' && error.message.indexOf('timeout') !== -1) {
      exceptionData.errorType = '10'
    } else if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      exceptionData.errorType = '20'
    } else if (error.request) {
      // The request was made but no response was received
      // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
      // http.ClientRequest in node.js
      exceptionData.errorType = '11'
    } else {
      // Something happened in setting up the request that triggered an Error
      exceptionData.errorType = '11'
    }
    let errContent = {}
    if (error.config.url === '/mem/collect/collectEvent') {
      let requestParams = params2Json(error.config.data)
      errContent.eId = requestParams.eventId
    }
    errContent.code = exceptionData.errorType == '10' ? 'timeout' : error.response.status || ''
    errContent.ph = httpHeader['productHidden']
    if (store.state.baseInfo.appVersion.split('.').join('') <= 230) {
      errContent.uid = httpHeader['userId']
    }
    exceptionData.errorContent = JSON.stringify(errContent).substr(0, 200)
    // console.error(exceptionData.errContent)

    let url = error.config.url
    exceptionData.requestUrl = url
    exceptionData.requestUrlFunction = error.config.url || ''
    exceptionData.responseTime = timestamp2 - timestamp1
    exceptionData.mobile = store.state.baseInfo.phoneNumber
    window.vm.$appInvoked('appUrlExceptionMonitor', exceptionData, '')
    // console.log("---->接口异常了" + JSON.stringify(exceptionData));
    // utils.toastMsg(error.message);
    utils.toastMsg('页面加载失败，请重试')
    return Promise.reject(error)
  }
)

/**
 * get请求
 * @param url
 * @param config
 * @returns {Promise<any>}
 */
function getMethod (url, data = {}, config = {}) {
  return new Promise((resolve, reject) => {
    axios
      .get(url + '?' + qs.stringify(data), config)
      .then((rst) => resolve(rst))
      .catch((error) => reject(error))
  })
}

/**
 * post 请求
 * @param url
 * @param data
 * @param config
 * @returns {Promise<any>}
 */
function postMethod (url, data = {}, config = {}) {
  return new Promise((resolve, reject) => {
    let requestData = qs.stringify(data)
    // (funcName == "" || funcName == "" || funcName == ""
    if (jsonContentTypeList.indexOf(url) >= 0) {
      requestData = data
    }
    axios
      .post(url, requestData, config)
      .then((rst) => resolve(rst))
      .catch((error) => reject(error))
  })
}
function postJsonMethod (
  url,
  data = {},
  config = {
    headers: {
      'Content-Type': 'application/json;charset=utf-8',
    },
  }
) {
  return new Promise((resolve, reject) => {
    axios
      .post(url, data, config)
      .then((rst) => resolve(rst))
      .catch((error) => reject(error))
  })
}

/**
 * all
 * @param arr
 * @returns {Promise<any>}
 */
function allMethod (arr) {
  return new Promise((resolve, reject) => {
    axios
      .all(arr)
      .then((...rsts) => resolve(rsts))
      .catch((error) => reject(error))
  })
}

function params2Json (str) {
  let jsonObj = {}
  if (typeof str === 'object') {
    return str
  } else {
    try {
      jsonObj = JSON.parse(str)
    } catch (error) {
      let params = str.split('&')
      for (let i = 0, l = params.length; i < l; i++) {
        let pair = params[i].split('=')
        jsonObj[pair[0]] = pair[1]
      }
    }
    return jsonObj
  }
}

export default {
  get: getMethod,
  post: postMethod,
  post1: postJsonMethod,
  all: allMethod,
}
