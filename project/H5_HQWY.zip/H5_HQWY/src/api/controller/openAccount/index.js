import http from '../../http'
import { getUrl } from '../../env'

const ajaxUrl = {
  // 上传身份证信息
  saveOcrInfoUrl: getUrl('/mem/ocr/saveOcrInfo'),
  // 获取供应商
  getProviderInfoUrl: getUrl('/mem/ocr/getProviderInfo'),
  // 人脸比对
  faceCompareUrl: getUrl('/mem/ocr/faceCompare'),
  // 查询紧急联系人信息
  getContactInfoUrl: getUrl('/mem/loanEntry/queryContacts'),
  // 保存紧急联系人信息
  saveContactInfoUrl: getUrl('/mem/loanEntry/saveContacts'),
  // 查询其他信息
  getOtherInfoUrl: getUrl('/mem/loanEntry/queryOtherInfo'),
  // 保存其他信息
  saveOtherInfoUrl: getUrl('/mem/loanEntry/saveOtherInfo'),
  // 获取基础信息
  getBasicInfoUrl: getUrl('/mem/userinfo/getData'),
  // 保存基础信息
  saveBasicInfoUrl: getUrl('/mem/userinfo/saveBaseInfo'),
  // 获取城市
  getCityDataUrl: getUrl('/api/index/getAllDistricts'),
  // 我的页面-完善贷款信息查询
  loanEntryQueryUrl: getUrl('/mem/loanEntry/query'),
  // 提交手机运营商状态接口
  submitAuthStatusUrl: getUrl('/mem/loanEntry/submitAuthStatus'),
}

export function saveOcrInfoApi (params = {}, config = {}) {
  return http.post(ajaxUrl.saveOcrInfoUrl, params, config)
}
export function getProviderInfoApi (params = {}, config = {}) {
  return http.post(ajaxUrl.getProviderInfoUrl, params, config)
}
export function faceCompareApi (params = {}, config = {}) {
  return http.post(ajaxUrl.faceCompareUrl, params, config)
}
export function getContactInfoApi (params = {}, config = {}) {
  return http.post(ajaxUrl.getContactInfoUrl, params, config)
}
export function saveContactInfoApi (params = {}, config = {}) {
  return http.post(ajaxUrl.saveContactInfoUrl, params, config)
}
export function getOtherInfoApi (params = {}, config = {}) {
  return http.post(ajaxUrl.getOtherInfoUrl, params, config)
}
export function saveOtherInfoApi (params = {}, config = {}) {
  return http.post(ajaxUrl.saveOtherInfoUrl, params, config)
}
export function getBasicInfoApi (params = {}, config = {}) {
  return http.post(ajaxUrl.getBasicInfoUrl, params, config)
}
export function saveBasicInfoApi (params = {}, config = {}) {
  return http.post(ajaxUrl.saveBasicInfoUrl, params, config)
}
export function getCityDataApi (config = {}) {
  return http.get(ajaxUrl.getCityDataUrl, config)
}
export function loanEntryQueryApi (config = {}) {
  return http.post(ajaxUrl.loanEntryQueryUrl, config)
}
export function submitAuthStatusApi (config = {}) {
  return http.post(ajaxUrl.submitAuthStatusUrl, config)
}
