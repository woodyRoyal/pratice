import http from '../../http'
import { getUrl } from '../../env'

const ajaxUrl = {
  // 查询进件订单信息
  applyOrderInfo: getUrl('/mem/user/apply/order'),
  // 协议查询
  applyLoanProtocol: getUrl('/mem/contract/getContract'),
  // 借款试算
  trialUrl: getUrl('/mem/loan/member/loan/loan/trial'),
  // 查询审核结果
  approvalResult: getUrl('/mem/loan/member/loan/approvalResult/query'),
  // 查询借款信息
  loanApplyInfo: getUrl('/mem/loan/member/loan/loanApply/query'),
  // 提交借款信息
  submitLoanInfo: getUrl('/mem/loan/member/loan/loanApply/submit'),
  // 提交借款申请
  submitLoanApply: getUrl('/mem/loan/member/loan/loan/submit'),
  // 查询放款结果
  loanResultQueryUrl: getUrl('/mem/loan/member/loan/loanResult/query'),
  // 查询借款订单号
  loanOrderNoUrl: getUrl('/mem/loan/member/loan/loanNo/apply'),
}

export function requestApplyOrderInfoApi (params = {}, config = {}) {
  return http.post(ajaxUrl.applyOrderInfo, params, config)
}

export function requestApplyLoanProtocolApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.applyLoanProtocol, params, config)
}

export function trialApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.trialUrl, params, config)
}

export function requestApprovalResultApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.approvalResult, params, config)
}

export function requestLoanApplyInfoApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.loanApplyInfo, params, config)
}

export function requestSubmitLoanInfoApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.submitLoanInfo, params, config)
}

export function requestSubmitLoanApplyApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.submitLoanApply, params, config)
}

export function requestLoanResultQueryApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.loanResultQueryUrl, params, config)
}

export function requestLoanOrderNoQueryApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.loanOrderNoUrl, params, config)
}
