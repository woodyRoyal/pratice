import http from '../../http'
import { getUrl } from '../../env'

const ajaxUrl = {
  // 产品详情页面，详情接口
  productDetail: getUrl('/api/product/page/detail'),
  // 联合登陆接口
  joinLogin: getUrl('/mem/user/join/register'),
  // 联登失败推荐接口
  // searchPro: getUrl('/api/index/joint/list/search'),
  searchPro: getUrl('/api/product/retainV2'),
  // 提交进件接口
  orderSubmitUrl: getUrl('/mem/order/submit'),
  // 根据产品id查询产品最新订单状态
  queryRecentOrderUrl: getUrl('/mem/order/queryRecentOrder'),
  // 根据产品id查询产品信息
  productInfoUrl: getUrl('/api/product/productInfo'),
  // 获取过审中产品列表
  getUserProductListUrl: getUrl('/api/product/getUserProductListV2'),
}

export function requestProductDetail (params = {}, config = {}) {
  return http.post(ajaxUrl.productDetail, params, config)
}
export function requestJoinLogin (params = {}, config = {}) {
  return http.post(ajaxUrl.joinLogin, params, config)
}
export function requestLoginFailPro (params = {}, config = {}) {
  return http.post(ajaxUrl.searchPro, params, config)
}
export function orderSubmitApi (params = {}, config = {}) {
  return http.post(ajaxUrl.orderSubmitUrl, params, config)
}
export function queryRecentOrderApi (params = {}, config = {}) {
  return http.post(ajaxUrl.queryRecentOrderUrl, params, config)
}
export function productInfoApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.productInfoUrl, params, config)
}
export function getUserProductListApi (params = {}, config = {}) {
  return http.post(ajaxUrl.getUserProductListUrl, params, config)
}
