import http from '../../http'
import { getUrl } from '../../env'

/**
 * API全流程2.0接口
 */

// 预筛选
const prescreenUrl = getUrl('/mem/user/apply/prescreen')
// 获取还款订单详情或者还款计划
const getDetailOrRepayPlanUrl = getUrl('/mem/loan/member/repay/getDetailOrRepayPlan')
// 还款
const applyRepayUrl = getUrl('/mem/loan/member/repay/applyRepay')
// 一推接口
const firstPushUrl = getUrl('/mem/apply/firstPush')
// 获取接近还款日或逾期的订单
const getRepayOrderInfoUrl = getUrl('/mem/loan/member/repay/getRepayOrderInfo')

export function prescreenApi (params = {}, config = {}) {
  return http.post(prescreenUrl, params, config)
}
export function getDetailOrRepayPlanApi (params = {}, config = {}) {
  return http.post1(getDetailOrRepayPlanUrl, params, config)
}
export function applyRepayApi (params = {}, config = {}) {
  return http.post1(applyRepayUrl, params, config)
}
export function firstPushApi (params = {}, config = {}) {
  return http.post(firstPushUrl, params, config)
}
export function getRepayOrderInfoApi (params = {}, config = {}) {
  return http.post(getRepayOrderInfoUrl, params, config)
}
