import http from '../../http'
import { getUrl } from '../../env'

// 产品详情页面，详情接口
const ajaxUrl = {
  // 首页信息接口
  // indexHome: getUrl('/api/index/home'),
  indexHome: getUrl('/api/index/homeV2'), // V7.0替换
  // 首页列表分页接口
  indexHomePage: getUrl('/api/index/home/pageV2'),
  // 首页跑马灯接口
  indexCarousel: getUrl('/api/index/carousel'),
  // 首页悬浮广告
  // advertisingSearch: getUrl('/api/product/advertising/search'),
  // 开屏广告、悬浮广告、首页弹窗 V7.0
  advertisingSearchV2: getUrl('/api/product/advertising/searchV2'),
  // 我的页面
  mytabUrl: getUrl('/api/product/mytab'),
  // 获取登录引导信息
  getLoginGuideInfoUrl: getUrl('/api/index/getLoginGuideInfo'),
  // APP请求推送消息
  messagePushUrl: getUrl('/mem/message/push'),
}

export function requesHomeInfo (params = {}, config = {}) {
  return http.post(ajaxUrl.indexHome, params, config)
}

export function requestHomePage (params = {}, config = {}) {
  return http.post(ajaxUrl.indexHomePage, params, config)
}

export function requestCarousel (params = {}, config = {}) {
  return http.post(ajaxUrl.indexCarousel, params, config)
}

// export function requestADSearch(params = {}, config = {}) {
//   return http.post(ajaxUrl.advertisingSearch, params, config)
// }
export function requestADSearchV2 (params = {}, config = {}) {
  return http.post(ajaxUrl.advertisingSearchV2, params, config)
}
export function mytabApi (params = {}, config = {}) {
  return http.post(ajaxUrl.mytabUrl, params, config)
}
export function getLoginGuideInfoApi (params = {}, config = {}) {
  return http.post(ajaxUrl.getLoginGuideInfoUrl, params, config)
}
export function messagePushApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.messagePushUrl, params, config)
}
