import http from '../../http'
import { getUrl } from '../../env'

const ajaxUrl = {
  // 还款结果查询
  queryRepayResultUrl: getUrl('/mem/loan/member/repay/queryRepayResult'),
  // 判断用户是否在立即贷结清
  ljdAllClearUrl: getUrl('/mem/ljd/allClear'),
}

export function queryRepayResult (params = {}, config = {}) {
  return http.post1(ajaxUrl.queryRepayResultUrl, params, config)
}
export function ljdAllClearApi (params = {}, config = {}) {
  return http.post(ajaxUrl.ljdAllClearUrl, params, config)
}
