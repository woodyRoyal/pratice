import http from '../../http'
import { getUrl } from '../../env'

const ajaxUrl = {
  // 贷款大全接口
  productFilter: getUrl('/api/product/filterV2'),
}

export function requestProductFilter (params = {}, config = {}) {
  return http.post1(ajaxUrl.productFilter, params, config)
}
