/**
 * @author yangbin
 * @date 2018/12/3
 * @Description: 银行卡
 */

import http from '../../http'
import { getUrl } from '../../env'

// 获取我的银行卡列表
let myselfBankCardUrl = getUrl('/mem/bankcard/query/myself')
// 获取支持的银行卡列表
let bindlistUrl = getUrl('/mem/bankcard/query/user/banklist')
// 绑卡、发送验证码
let bankcardBindUrl = getUrl('/mem/bankcard/bind')
// 获取支持银行列表 和 获取银行列表（同一个接口）
let getSupportBankUrl = getUrl('/mem/bankcard/query/support/bank')
// 通过用户输入的银行卡号判断是哪个银行的
let cardbinUrl = getUrl('/mem/bankcard/query/cardbin')

/**
 * 获取我的银行卡
 * @param params
 * @param config
 * @returns {Promise<any>}
 */
export function myselfBankCardApi (params = {}, config = {}) {
  return http.post1(myselfBankCardUrl, params, config)
}

/**
 * 获取支持的银行卡列表
 * @param params
 * @param config
 * @returns {Promise<any>}
 */
export function getBindListApi (params = {}, config = {}) {
  return http.post(bindlistUrl, params, config)
}

/**
 * 绑卡、发送验证码
 * @params query
 * @config axios 配置项
 * @url '/getDynamicCode'
 * @returns {*}
 */
export function bankcardBindApi (params = {}, config = {}) {
  return http.post1(bankcardBindUrl, params, config)
}

// 获取支持银行列表 和 获取银行列表（同一个接口）
export function getSupportBankApi (params = {}, config = {}) {
  return http.post(getSupportBankUrl, params, config)
}

// 通过用户输入的银行卡号判断是哪个银行的
export function cardbinApi (params = {}, config = {}) {
  return http.post(cardbinUrl, params, config)
}
