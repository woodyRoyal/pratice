import http from '../../http'
import { getUrl } from '../../env'

const ajaxUrl = {
  // 猜你可贷接口
  letMeGuess: getUrl('/api/index/letMeGuessV2'),
}

export function requestGuessLoan (params = {}, config = {}) {
  return http.post(ajaxUrl.letMeGuess, params, config)
}
