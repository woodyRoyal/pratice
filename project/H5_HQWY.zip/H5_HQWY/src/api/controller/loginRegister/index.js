import http from '../../http'
import { getUrl } from '../../env'

const ajaxUrl = {
  // 发送验证码短信息
  sendCode: getUrl('/mem/sms/verification/send'),
  // 校验短信验证码
  smsCodeVerify: getUrl('/mem/sms/code/verify'),
  // 获取图形验证
  getImageCode: getUrl('/mem/login/getImageCode'),
  // 校验图形验证码
  validateImageCode: getUrl('/mem/login/validateImageCode'),
  // 密码登录
  loginPassword: getUrl('/mem/user/login/password'),
  // 验证码登录
  loginCode: getUrl('/mem/user/login/code'),
  // 设置密码
  pwdchg: getUrl('/mem/user/pwdchg'),
}

export function sendCodeApi (params = {}, config = {}) {
  return http.post(ajaxUrl.sendCode, params, config)
}

export function getImageCodeApi (params = {}, config = {}) {
  return http.post(ajaxUrl.getImageCode, params, config)
}

export function validateImageCodeApi (params = {}, config = {}) {
  return http.post(ajaxUrl.validateImageCode, params, config)
}

export function validateSmsCodeApi (params = {}, config = {}) {
  return http.post(ajaxUrl.smsCodeVerify, params, config)
}

export function loginPasswordApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.loginPassword, params, config)
}

export function loginCodeApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.loginCode, params, config)
}

export function pwdchgApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.pwdchg, params, config)
}
