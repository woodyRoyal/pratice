import http from '../../http'
import { getUrl } from '../../env'

const ajaxUrl = {
  // 获取城市列表
  indexCitys: getUrl('/api/index/city'),
  // 城市信息保存
  saveCity: getUrl('/mem/user/save/city'),
}

export function requestCitys (params = {}, config = {}) {
  return http.post(ajaxUrl.indexCitys, params, config)
}

export function requestSaveCity (params = {}, config = {}) {
  return http.post(ajaxUrl.saveCity, params, config)
}
