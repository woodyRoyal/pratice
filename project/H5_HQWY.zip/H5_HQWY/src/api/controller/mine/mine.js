import http from '../../http'
import { getUrl } from '../../env'

const ajaxUrl = {
  // 检查账号是否可以注销
  cancelAccountCheckUrl: getUrl('/mem/user/close/check'),
  // 真正注销账号
  cancelAccountUrl: getUrl('/mem/user/close/confirm'),
  // 退出登录
  logoutUrl: getUrl('/mem/user/logout'),
}

/**
 * 检查账号是否可以注销
 * @param params
 * @param config
 */
export function cancelAccountCheckApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.cancelAccountCheckUrl, params, config)
}

/**
 * 真正注销账号
 * @param params
 * @param config
 */
export function cancelAccountApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.cancelAccountUrl, params, config)
}
export function logoutApi (params = {}, config = {}) {
  return http.post(ajaxUrl.logoutUrl, params, config)
}
