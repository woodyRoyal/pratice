import http from '../../http'
import { getUrl } from '../../env'

const ajaxUrl = {
  // 我的订单，查询订单列表
  getOrderListUrl: getUrl('/mem/order/list'),
  // 获取借还款的url
  orderCheckUrl: getUrl('/mem/order/getLoanUrlOrRepayUrl'),
}

export function getOrderListApi (params = {}, config = {}) {
  return http.post(ajaxUrl.getOrderListUrl, params, config)
}

export function orderCheckApi (params = {}, config = {}) {
  return http.post(ajaxUrl.orderCheckUrl, params, config)
}
