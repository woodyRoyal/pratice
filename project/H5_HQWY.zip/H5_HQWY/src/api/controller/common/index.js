import http from '../../http'
import { getUrl } from '../../env'

const ajaxUrl = {
  // 获取需要填写的信息
  commonDict: getUrl('/mem/common/dict'),
  // 获取用户信息
  userInfo: getUrl('/mem/userinfo/getData'),
  // 保存个人信息接口
  saveData: getUrl('/mem/userinfo/saveData'),
  // 点击上报接口
  clickReport: getUrl('/api/product/click/report'),
  // 查询小红点
  queryStatusUrl: getUrl('/mem/order/redRemark/queryStatus'),
  // 小红点状态标记
  updateStatusUrl: getUrl('/mem/order/redRemark/updateStatus'),
  // 撞库
  loanHitUrl: getUrl('/mem/user/join/loan/hit'),
  // 客户端事件上传
  collectEventUrl: getUrl('/mem/collect/collectEvent'),
  // 查询公告链接
  getNoticeLinkUrl: getUrl('/api/notice/getNoticeLinkApp'),
  // APP下载信息收集
  downloadCollectionUrl: getUrl('/api/product/download/collection'),
}

export function requestCommonDict (params = {}, config = {}) {
  return http.post(ajaxUrl.commonDict, params, config)
}

export function requestUserInfo (params = {}, config = {}) {
  return http.post(ajaxUrl.userInfo, params, config)
}

export function requestSaveData (params = {}, config = {}) {
  return http.post(ajaxUrl.saveData, params, config)
}

export function requestClickReport (params = {}, config = {}) {
  return http.post(ajaxUrl.clickReport, params, config)
}

export function queryStatusApi (params = {}, config = {}) {
  return http.post(ajaxUrl.queryStatusUrl, params, config)
}

export function updateStatusApi (params = {}, config = {}) {
  return http.post(ajaxUrl.updateStatusUrl, params, config)
}

export function loanHitApi (params = {}, config = {}) {
  return http.post(ajaxUrl.loanHitUrl, params, config)
}

export function collectEventApi (params = {}, config = {}) {
  return http.post(ajaxUrl.collectEventUrl, params, config)
}

export function getNoticeLinkApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.getNoticeLinkUrl, params, config)
}

export function downloadCollectionApi (params = {}, config = {}) {
  return http.post1(ajaxUrl.downloadCollectionUrl, params, config)
}
