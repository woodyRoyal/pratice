import http from '../../http'
import { getUrl } from '../../env'

const ajaxUrl = {
  // 推荐列表页面接口
  indexRecommend: getUrl('/api/index/recommendV2'),
}

export function requestRecommendList (params = {}, config = {}) {
  return http.post1(ajaxUrl.indexRecommend, params, config)
}
