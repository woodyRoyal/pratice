import http from '../../http'
import { getUrl } from '../../env'

const ajaxUrl = {
  // 分类信息
  indexCategory: getUrl('/api/index/categoryV2'),
  // 优惠券接口
  myCouponUrl: getUrl('/api/index/category'),
  // 浏览记录接口
  browseRecord: getUrl('/api/product/browse/recordV2'),
  // 推荐列表接口
  productRetain: getUrl('/api/product/retainV2'),
}

export function requestCategory (params = {}, config = {}) {
  return http.post(ajaxUrl.indexCategory, params, config)
}

export function myCouponApi (params = {}, config = {}) {
  return http.post(ajaxUrl.myCouponUrl, params, config)
}

export function requestBrowseRecord (params = {}, config = {}) {
  return http.post(ajaxUrl.browseRecord, params, config)
}

export function requestProductRetain (params = {}, config = {}) {
  return http.post(ajaxUrl.productRetain, params, config)
}
