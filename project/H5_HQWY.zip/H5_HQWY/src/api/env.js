let env = {
  dev: '',
  // dev: "http://172.17.106.167:9094",
  // dev: 'http://172.16.0.145:10014/gateway',
  // dev: 'http://172.17.16.33:9094/gateway',
  build: '',
}

/**
 * url 配置
 * @param url
 */
export const getUrl = (url) => process.env.NODE_ENV === 'development' ? env.dev + url : env.build + url

/**
 * params 拼接
 * @param parmas
 */
export const getParams = (params) => {
  let str = ''
  for (let i in params) {
    str += i + '=' + params[i] + '&'
  }
  return str.substring(0, str.length - 1)
}
