// import { Toast } from 'mint-ui'
//获取浏览器类型
var browser = {
  versions: (function () {
    var u = navigator.userAgent
    // app = navigator.appVersion
    return {
      trident: u.indexOf('Trident') > -1, //IE内核
      presto: u.indexOf('Presto') > -1, //opera内核
      webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
      gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') === -1, //火狐内核
      mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
      ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
      android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或uc浏览器
      iPhone: u.indexOf('iPhone') > -1, //是否为iPhone或者QQHD浏览器
      iPad: u.indexOf('iPad') > -1, //是否iPad
      webApp: u.indexOf('Safari') === -1, //是否web应该程序，没有头部与底部
      weixin: u.indexOf('MicroMessenger') > -1, //是否微信
      qq: u.match(/\sQQ/i) === 'qq', //是否QQ
    }
  })(),
}

export default {
  isIos () {
    return browser.versions.ios
  },
  isAndroid () {
    return browser.versions.android
  },
  toastMsg (msg = '系统异常') {
    window.vm.$appInvoked('appToastMessage', { message: msg })
    // if (isIos || isAndroid) {
    //   window.vm.$appInvoked('appToastMessage', { message: msg })
    //   return
    // }
    // Toast({
    //   message: msg,
    //   position: 'middle',
    //   duration: 2000
    // })
  },
  // 13位ms转日期格式
  formateDate (date, fmt) {
    if (!date) {
      return ''
    }
    date = new Date(date)
    var o = {
      'M+': date.getMonth() + 1, //月份
      'D+': date.getDate(), //日
      'h+': date.getHours(), //小时
      'm+': date.getMinutes(), //分
      's+': date.getSeconds(), //秒
      'q+': Math.floor((date.getMonth() + 3) / 3), //季度
      S: date.getMilliseconds(), //毫秒
    }
    if (/(Y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
    for (var k in o) if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length))
    return fmt
  },
  // js防抖
  debouce (func, delay, immediate) {
    var timer = null
    return function () {
      var context = this
      var args = arguments
      if (timer) clearTimeout(timer)
      if (immediate) {
        //根据距离上次触发操作的时间是否到达delay来决定是否要现在执行函数
        var doNow = !timer
        //每一次都重新设置timer，就是要保证每一次执行的至少delay秒后才可以执行
        timer = setTimeout(function () {
          timer = null
        }, delay)
        //立即执行
        if (doNow) {
          func.apply(context, args)
        }
      } else {
        timer = setTimeout(function () {
          func.apply(context, args)
        }, delay)
      }
    }
  },
  codeCountdown (v) {
    v.code.s--
    v.code.message = `${v.code.s}秒后重试`
    function core () {
      v.code.timer = setTimeout(() => {
        v.code.s--
        if (v.code.s <= 0) {
          v.code.s = v.code.maxTime
          clearTimeout(v.code.timer)
          v.code.disabled = true
          v.code.message = '重新获取'
          return
        } else {
          v.code.message = `${v.code.s}秒后重试`
        }
        core()
      }, 1000)
    }
    core()
  },
}
