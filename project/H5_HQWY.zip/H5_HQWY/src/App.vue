<template>
  <div id="app">
    <transition :name="$transitionName">
      <keep-alive>
        <router-view :class="['child-view', {'mescroll': !$route.meta.mescroll}]" />
      </keep-alive>
    </transition>

    <!-- 不在首页或者首页弹窗不展示，可以展示引导弹窗和消息通知引导弹窗。因为首页弹窗广告优先级最高 -->
    <!-- 引导登录弹窗 -->
    <div v-show="canDiversionConfirmShow && (!isMainPage || !$store.state.dialog.mainWindowAd.show)">
      <DiversionConfirm ref="DiversionConfirm"></DiversionConfirm>
    </div>
    <!-- 消息通知引导弹窗 -->
    <div v-show="!isMainPage || !$store.state.dialog.mainWindowAd.show">
      <confirm ref="InformConfirm"
               title="开启消息通知"
               btn-type="tb"
               sure-txt="立即开启"
               cancel-txt="我再想想"
               @on-cancel="informCancel()"
               @on-confirm="informSure()">
        <div slot="icon"
             class="dialog-icon">
          <img class="inform-dialog-icon"
               :src="require('APP_IMG/dialog_inform.png')"
               alt="">
        </div>
        <div class="hy-txt">
          <div>开启消息推送，第一时间获取最新贷款产品，专享的高通过率产品不容错过！</div>
          <div class="inform-tips">
            设置路径：设置->通知->{{ $config.get('appNameCh') }}
          </div>
        </div>
      </confirm>
    </div>
  </div>
</template>

<script>
import utils from "./util/utils";
import { mapActions } from "vuex";
import { requestUserInfo, downloadCollectionApi } from "@/api/controller/common";
import { getLoginGuideInfoApi, messagePushApi } from "@/api/controller/home";
import { ljdAllClearApi } from "@/api/controller/repay/repay";
import DiversionConfirm from "@/components/confirm/DiversionConfirm"
import confirm from "@/components/confirm/index"
export default {
  name: "App",
  components: {
    DiversionConfirm,
    confirm,
  },
  data () {
    return {
      isMainPage: false, // 首页弹窗展示状态
      showInformConfirm: false, // 暂存打开消息通知引导弹窗展示状态
      canDiversionConfirmShow: false, // 当用户处于首页、贷款大全、猜你可贷、我的页面才弹出弹窗
      showDiversionConfirm: false, // 暂存登录引导弹窗展示状态
      openMsgDialogInterval: 3, // 两次弹窗弹出时间间隔(单位：天)
      openMsgDialogSecond: 30, // 弹出消息通知弹窗秒数
      refreshTimeObj: {
        home: "",
        productlist: "",
        prolist: "",
        guessborrow: "",
        recommendlist: "",
      },
    };
  },
  watch: {
    $route (to, from) {
      var self = this;
      var timestamp = new Date().getTime();
      switch (from.path) {
        case "/home":
          self.refreshTimeObj.home = timestamp;
          break;
        case "/productlist":
          self.refreshTimeObj.productlist = timestamp;
          break;
        case "/prolist":
          self.refreshTimeObj.prolist = timestamp;
          break;
        case "/guessborrow":
          self.refreshTimeObj.guessborrow = timestamp;
          break;
        case "/recommendlist":
          self.refreshTimeObj.recommendlist = timestamp;
          break;
        default:
          break;
      }
      localStorage.setItem("refreshTime", JSON.stringify(self.refreshTimeObj));
      if (to.path === '/home') {
        this.isMainPage = true
      } else {
        setTimeout(() => {
          this.isMainPage = false
        }, 800)
      }
      if (['/home', '/productlist', '/guessborrow', '/mycenter'].indexOf(to.path) > -1) {
        this.canDiversionConfirmShow = true
        // 物理返回键处理
        if (isAndroid) {
          this.$appInvoked('appSetNative', {
            shouldNotifyBack: false,
          })
        }
        // 路由切换至首页、贷款大全、猜你可贷、我的页面时，弹出弹窗
        if (this.showDiversionConfirm) {
          this.showDiversionConfirm = false
          this.$refs.DiversionConfirm.show()
          this.$appInvoked('appDataCache', { action: 1, memoryCache: true, key: 'LOGIN_GUIDE_DIALOG', value: '1' })
        }
      } else {
        this.canDiversionConfirmShow = false
        if (isAndroid) {
          this.$appInvoked('appSetNative', {
            shouldNotifyBack: true,
          })
          this.$appGetInvoked('htmlBackPress', () => {
            // this.$routerGo(-1)
            if (history.length < 2) {
              this.$appInvoked('appExecBack', {})
            } else {
              this.$routerBack()
            }
          })
        }
      }
      if (['/home', '/productlist', '/guessborrow'].indexOf(to.path) > -1 && this.showInformConfirm) {
        this.checkInformDialog('routerChange')
      }
    },
  },
  created () {
    window.onRelogin = this.onRelogin;
    window.topPreRecommend = this.globalRecommendClick
    this.$appInvoked("appGetImageSource", {}, function (data) {
      if (data) {
        localStorage.setItem("kCachedImages", JSON.stringify(data));
      }
    });
  },
  mounted () {
    if (this.$route.path === '/home') {
      this.isMainPage = true
    } else {
      this.isMainPage = false
    }
    if (['/home', '/productlist', '/guessborrow', '/mycenter'].indexOf(this.$route.path) > -1) {
      this.canDiversionConfirmShow = true
    } else {
      this.canDiversionConfirmShow = false
    }
    var self = this;
    window.hideDiversionConfirm = self.hideDiversionConfirm
    self.$appGetInvoked('htmlNotifyLoginSuccess', () => {
      localStorage.setItem('cacheAjaxHeader', '')
      self.$refs.DiversionConfirm.hide()
      if (window.loginSuccessCallback) {
        window.loginSuccessCallback()
        window.loginSuccessCallback = null
      }
      // 登录成功，app请求推送消息
      this.$appInvoked('appDataCache', {
        action: 2,
        key: 'APP_PUSH_REGID',
        memoryCache: true,
      }, (res) => {
        try {
          res = JSON.parse(res)
        } catch (error) {
          // 
        }
        if (res && res.deviceToken) {
          messagePushApi(res)
        }
      })
    })
    // 下载第三方 app通知
    self.$appGetInvoked('htmlDownloadOtherApp', () => {
      self.checkInformDialog('downloadApp')
    })
    // 三方点击上报（目前只有海外包使用）
    // self.$appGetInvoked('htmlReportThird', (data) => {
    //   try {
    //     data = JSON.parse(data)
    //   } catch (e) {
    //     // data = {}
    //   }
    //   // 点击上报
    //   self.clickReport(data.productId, data.category, data.header.clickEvent, data.header)
    // })
    // 三方下载
    self.$appGetInvoked('htmlDownloadThird', (data) => {
      try {
        data = JSON.parse(data)
      } catch (e) {
        // data = {}
      }
      // 下载点击上报
      downloadCollectionApi(data)
    })
    self.$appInvoked('appIsLogin', {}, (isLogin) => {
      // 立即借查询是否有未还清贷款
      if (self.$config.get('productId') === 903) {
        this.$appInvoked("appGetBundleId", {}, (rst) => {
          // 大于1000马甲包，小于0海外包
          let isMjb = (rst === 'com.sl.hhsc') || (+rst > 1000) || (+rst < 0);
          if (!isMjb) {
            self.checkLjjAllClear(isLogin)
          }
        })
      }
      // 引导登录弹窗
      getLoginGuideInfoApi({}).then((repData) => {
        if (repData.respCode === "1000") {
          let body = repData.body
          if (isLogin) { // 已登录
            // 已登录用户，在APP打开期间，若退出登录，不会弹出登录引导弹窗
            self.$appInvoked('appDataCache', { action: 1, memoryCache: true, key: 'LOGIN_GUIDE_DIALOG', value: '1' })
            // 判断“打开消息通知引导弹窗”展示逻辑
            self.openMsgDialogInterval = body.openMsgDialogInterval // 两次弹窗弹出时间间隔(单位：天)
            self.openMsgDialogSecond = body.openMsgDialogSecond // 弹出消息通知弹窗秒数
            let openMsgDialogSecond = body.openMsgDialogSecond
            openMsgDialogSecond && setTimeout(() => {
              self.checkInformDialog('openApp')
            }, openMsgDialogSecond * 1000)
          } else { // 未登录
            if (body.needLoginGuide) {
              let loginGuideSecond = body.loginGuideSecond * 1000
              self.$appInvoked('appDataCache', { action: 2, key: 'LOGIN_GUIDE_DIALOG', memoryCache: true }, (rst) => {
                if (rst !== '1') {
                  setTimeout(() => {
                    // 用户处于首页、贷款大全、猜你可贷、我的页面才弹出弹窗
                    if (['/home', '/productlist', '/guessborrow', '/mycenter'].indexOf(self.$route.path) > -1) {
                      self.showDiversionConfirm = false
                      self.$refs.DiversionConfirm.show()
                      self.$appInvoked('appDataCache', { action: 1, memoryCache: true, key: 'LOGIN_GUIDE_DIALOG', value: '1' })
                    } else {
                      self.showDiversionConfirm = true
                    }
                  }, loginGuideSecond)
                }
              })
            }
          }
        } else {
          self.$appInvoked('appDataCache', { action: 1, memoryCache: true, key: 'LOGIN_GUIDE_DIALOG', value: '1' })
        }
      }, () => {
        self.$appInvoked('appDataCache', { action: 1, memoryCache: true, key: 'LOGIN_GUIDE_DIALOG', value: '1' })
      })
    })
    if (!utils.isAndroid() && !utils.isIos()) {
      // self.$store.commit("USER_TOKEN", "FB3FB4785EC3558368724ED6F2E9B009591BB3B82BF763297FEC38763379149DCC79944CFF55FF37127FCA75818C697E");
      self.$store.commit("USER_TOKEN", "F0695B556691E7B995D8B7DE5C56447DECACB86E43ED8489EF461751CECBEAB1B5D0FF1DE6D5762DA3819548DAE7D7C0");
      self.$store.commit("APP_VERSION", "2.4.0");
      self.$store.commit("PHONE_NUMBER", "15286800000");
      // self.$store.commit('orderDotRemark', {
      //   overDue: true,
      //   remark: true
      // });

      // self.queryStatusFunc();
      // self.setHeaderInfo({
      //   channel: 'test_channel',
      //   terminalId: 'hqwyandroid',
      //   innerVersion: '20400',
      //   projectMark: 'test',
      //   idfa: '',
      //   imei: '154B8B1235E3932B40551D14176F4134',
      //   userId: '1097489',
      //   city: '021',
      //   packageName: 'com.jieqian2345',
      //   os: 'android',
      //   deviceNo: '04b167b66512',
      //   userAgent: 'Loan/2.3.1(os:android)-04b167b66512',
      //   token: 'FB3FB4785EC3558368724ED6F2E9B009591BB3B82BF763297FEC38763379149DCC79944CFF55FF37127FCA75818C697E',
      //   version: '2.4.0'
      // });
    } else {
      self.$appInvoked("appGetUserToken", {}, function (token) {
        if (token !== "" && token != null) {
          self.queryUserInfo();
          // self.queryStatusFunc();
          self.$store.commit("USER_TOKEN", token);
        }
      });
      self.$appInvoked("appGetMobilephone", {}, function (data) {
        self.$store.commit("PHONE_NUMBER", data);
      });
      self.$appInvoked("appGetAjaxHeader", {}, function (data) {
        self.setHeaderInfo(data);
      });
      // APP十分钟刷新逻辑配置
      self.$appInvoked('appPageConfig', {
        autoRefreshRouter: [
          '/index.html#/home',
          '/index.html#/productlist',
          '/index.html#/guessborrow',
          '/index.html#/mycenter',
          '/index.html#/prolist',
          '/index.html#/mycoupon',
          '/index.html#/browseRecord',
          '/index.html#/order',
          '/index.html#/recommendlist',
        ],
      })
      // 短信&推送处理
      self.$appGetInvoked('htmlHandlePush', (res) => {
        // console.error(res)
        try {
          res = JSON.parse(res)
        } catch (e) {
          // 
        }
        let { sourceType, jrcsMsgType } = res // 1-短信，2-推送。jrcsMsgType：新版本使用此字段（花钱无忧>=3.2.0，贷款王>=7.2.0，立即借>=10.2.0）
        let action = +res.action // 1-启动APP 2-内部链接 3-外部链接 4-指定页面
        let actionUrl = res.actionUrl || res.actionPath // 推送打开App指定页面
        let needLogin = res.needLogin // 是否需要登录
        needLogin = needLogin === true || +needLogin === 1 || needLogin === 'true'
        sourceType = jrcsMsgType || sourceType
        let w = +sourceType === 1 ? 1002 : 1001
        if (+jrcsMsgType === 2) {
          // TODO 推送上报
          // 跨域，待服务端提供接口
          this.toast('接收到推送，需上报。接口跨域，待服务端提供接口完成。')
        }
        if (action === 1) {
          return
        } else if (action === 3 && (isAndroid || jrcsMsgType)) {
          if (needLogin) {
            self.needUserLogin(w, () => {
              actionUrl && self.$appInvoked('appOpenBrowser', { url: actionUrl })
            })
          } else {
            actionUrl && self.$appInvoked('appOpenBrowser', { url: actionUrl })
          }
          return
        }
        if (actionUrl) {
          // this.$LoginUtils.closeDialog()
          if (this.$route.path === '/login') {
            // 如果当前在登录页，则返回
            this.$routerGo(-1)
          }
          let actionParams = (+sourceType === 1 || isIos) ? res.actionParams : res // 推送iOS取actionParams，安卓从res取。因为华为推送回去掉res对象中其他数据的大括号，服务端做了兼容出来
          if (needLogin) {
            self.needUserLogin(w, () => {
              self.jrcsOpenAppPage(w, actionUrl, '', actionParams)
            })
          } else {
            self.jrcsOpenAppPage(w, actionUrl, '', actionParams)
          }
        }
      })
      // 推送标识注册
      self.$appGetInvoked('htmlPushRegId', (res) => {
        // res: { deviceToken: '设备标识', type: '推送类型标识：XM(小米),HW(华为),YM（友盟）' }
        // app请求推送消息
        messagePushApi(res)
        // 缓存数据，待登录成功后需再次请求推送消息
        this.$appInvoked('appDataCache', {
          action: 1,
          key: 'APP_PUSH_REGID',
          memoryCache: true,
          value: JSON.stringify(res),
        })
      })
    }
  },
  methods: {
    ...mapActions(["setHeaderInfo"]),
    showInformConfirmDialog () {
      this.showInformConfirm = false
      this.$appInvoked('appDataCache', {
        action: 1, // 1-存储；2-取值；3-清除
        key: 'INFORM_DIALOG',
        memoryCache: false,
        value: new Date().getTime(),
      })
      this.$refs.InformConfirm.show()
    },
    /**
     * 判断并展示“打开消息通知引导弹窗”
     * @param {String} type 来源。
     *  openApp:用户打开APP后已登录状态浏览页面。当用户停留在首页、贷款大全、猜你可贷页面弹出引导弹窗
     *  downloadApp:监听到用户进行第三方产品APP下载。回到上级页面后在上级页面弹出引导弹窗
     *  routerChange:需要展示弹窗，路由切换回首页、贷款大全、猜你可贷页面。
     */
    checkInformDialog (type) {
      let showInformConfirm = () => {
        if (['downloadApp', 'routerChange'].indexOf(type) > -1) {
          this.showInformConfirmDialog()
        } else if (type === 'openApp') {
          if (['/home', '/productlist', '/guessborrow'].indexOf(this.$route.path) > -1) {
            this.showInformConfirmDialog()
          } else {
            this.showInformConfirm = true
          }
        }
      }
      this.$appInvoked('appNotificationEnabled', {}, (enabled) => {
        if (!enabled) { // 未打开消息通知权限
          // 判断是否展示过引导弹窗
          this.$appInvoked('appDataCache', {
            action: 2, // 1-存储；2-取值；3-清除
            key: 'INFORM_DIALOG',
            memoryCache: false,
          }, (rst) => {
            if (rst) {
              // 已展示过，判断展示时间间隔
              if (new Date().getTime() - rst > this.openMsgDialogInterval * 24 * 60 * 60 * 1000) {
                showInformConfirm()
              }
            } else {
              // 从未展示过，展示弹窗
              showInformConfirm()
            }
          })
        }
      })
    },
    informCancel () {
      this.mdAll('tzyd;tc;wzxx;w339')
    },
    informSure () {
      this.mdAll('tzyd;tc;ljkq;w338')
      // 去设置
      this.$appInvoked('appOpenSystemSetting', {})
    },
    hideDiversionConfirm () {
      this.$refs.DiversionConfirm.hide()
    },
    // 立即借查询是否有未还清贷款
    checkLjjAllClear (isLogin) {
      let that = this
      // 记录当日APP打开次数
      that.$appInvoked('appDataCache', {
        action: 2,
        key: 'TODAY_OPEN_APP_TIMES',
        memoryCache: false,
      }, (rst) => {
        let d = new Date()
        let today = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate()
        try {
          rst = JSON.parse(rst)
        } catch (error) {
          rst = {
            date: today,
            time: 0,
          }
        }
        // 立即借每天首次启动，判断是否有未结清贷款。若有，跳转还款页
        if (isLogin && (rst.date !== today || (rst.date === today && rst.time < 1))) {
          ljdAllClearApi({}).then((repData) => {
            if (repData.respCode === "1000") {
              if (repData.body && repData.body.clear === '2') { // 未结清
                // 立即借记录是否结清状态
                localStorage.setItem('SHOW_LJJ_REPAY', '2')
                that.$appInvoked('appOpenWebview', {
                  url: repData.body.url,
                  nav: {
                    hide: true,
                  },
                })
              } else {
                localStorage.setItem('SHOW_LJJ_REPAY', '1')
              }
            }
          })
        }
        let value = {
          date: today,
          time: 0,
        }
        if (rst.date === today) {
          value.time = rst.time + 1
        } else {
          value.time = 1
        }
        that.$appInvoked('appDataCache', {
          action: 1,
          key: 'TODAY_OPEN_APP_TIMES',
          memoryCache: false,
          value: JSON.stringify(value),
        })
      })
    },
    onRelogin () {
      this.needUserLogin('', () => {
        window.location.reload();
      })
      // this.$appInvoked("appNeedUserLogin", "", function (data) {
      //   if (data == true) {
      //     window.location.reload();
      //   } else {
      //     this.$routerPush("/home");
      //   }
      // });
    },
    queryUserInfo () {
      var self = this;

      requestUserInfo({}).then(
        (data) => {
          var repData = data;

          self.isLoad = "none";
          if (repData.respCode === "1000") {
            self.$store.commit("USER_NAME", repData.body.userName);
            self.$store.commit("USER_ID", repData.body.userId);
          }
        }
      );
    },
    // 获取订单小红点
    // queryStatusFunc() {
    //   let self = this;
    //   queryStatusApi().then(data => {
    //     if(data.respCode == '1000') {
    //       let body = data.body;

    //       let remark = false;
    //       for(let i = 0, l= body.redRemarkList.length; i < l; i++) {
    //         if(body.redRemarkList[i].remarkStatus == 1) {
    //           remark = true;
    //           break;
    //         }
    //       }
    //       self.$store.commit('orderDotRemark', {
    //         overDue: body.overdueMark,
    //         remark: remark
    //       });
    //     }
    //   });
    // }
  },
};
</script>

<style lang="scss">
/*导入全局的样式文件*/
@import './common/ui_base.scss';

// :not(input, textarea) {
//   -webkit-touch-callout: none;
//   -webkit-user-select: none;
//   -khtml-user-select: none;
//   -moz-user-select: none;
//   -ms-user-select: none;
//   user-select: none;
// }

html,
body {
  height: 100%;
  overflow: hidden;
}

body {
  position: relative;
}

.mescroll {
  display: block !important;
}

.child-view {
  position: absolute;
  overflow-x: hidden;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: #f6f6f6;
  box-sizing: border-box;
  transition: all 0.6s cubic-bezier(0.55, 0, 0.1, 1);
}

.slide-left-enter,
.slide-right-leave-active {
  opacity: 0;
  /*-webkit-transform: translate(-80px, 0);*/
  transform: translate3d(-80px, 0px, 0px);
}

.slide-left-leave-active,
.slide-right-enter {
  opacity: 0;
  /*-webkit-transform: translate(100%, 0);*/
  transform: translate3d(100%, 0, 0);
}
.slide-top-enter,
.slide-bottom-leave-active {
  transform: translate3d(0, 0, 0);
}
.slide-top-leave-active,
.slide-bottom-enter {
  transform: translate3d(0, 100%, 0);
}

.hqwy-masker {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  // width: 100%;
  // height: 100%;
  background-color: #000000;
  opacity: 0.5;
  z-index: 3;
}

.hqwy-content-box {
  position: absolute;
  width: 100%;
  height: 100%;
  overflow-x: hidden;
  -webkit-overflow-scrolling: touch;
  z-index: 1;
  overflow-y: scroll;
}
.mescroll-downwarp {
  height: 0;
  overflow: hidden;
}

.mescroll-downwarp-reset {
  transition: height 0.2s ease-in-out;
}

.downwarp-content {
  height: 80px;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
  text-align: center;
  /*background: #fff;*/
  /*padding: 4px;*/
}

.downwarp-progress {
  transform: none !important;
  margin: 0 auto;
  width: 75px;
  height: 50px;
  /*width: 20px;*/
  margin-bottom: 4px;
  background: url(../static/images/#{$APP_NAME}/refresh.gif) center center;
  background-size: 100% 100%;
}

.downwarp-tip {
  font-size: 10px;
  font-weight: bold;
  color: #b8b8b8;
}
.vux-1px-b {
  border-bottom: 1px solid #eee;
}

.display-flex {
  display: flex;
}
.flex-between {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  flex: 2;
}
.bg-color-fff {
  background-color: #fff;
}

.prolistpage #loading {
  height: 100%;
}
.bb-1px {
  position: relative;
  &:after {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    bottom: -1px;
    height: 0;
    border-bottom: 1px solid $line-list-split;
    transform: scaleY(0.5);
  }
}
.b-1px {
  position: relative;
  &::after {
    content: '';
    position: absolute;
    top: -1px;
    left: -1px;
    transform-origin: 0 0;
    width: 200%;
    height: 200%;
    transform: scale(0.5);
    border: 1px solid $line-btn-border;
    border-radius: rc(55);
    box-sizing: border-box;
  }
}
// 公共按钮
.jrcs-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  color: $btn-txt-color;
  background: $btn-default-bg;
  line-height: normal;
  &:active {
    background: $btn-actived-bg;
  }
  &.disabled {
    opacity: $btn-disabled-opacity;
    &:active {
      background: $btn-default-bg;
    }
  }
}
</style>
<style lang="scss" scoped>
.dialog-icon {
  margin-bottom: rc(30);
  .inform-dialog-icon {
    width: rc(262);
    height: rc(179);
    position: absolute;
    top: rc(50);
    left: 50%;
    transform: translate(-50%, -100%);
  }
}
.inform-tips {
  font-size: rc(28);
  line-height: rc(45);
  color: $color-text-tip;
  margin-top: rc(10);
}
</style>