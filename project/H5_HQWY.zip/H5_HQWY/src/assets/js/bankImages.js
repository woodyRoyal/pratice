export function getBankImages () {
  return {
    OTHOR: { logo: 'logo_other_yh.png', bg: '#ff9d00' },
    BOC: { logo: 'logo_zgyh.png', bg: '#e25151' },
    POST: { logo: 'logo_yzyh.png', bg: '#4db37a' },
    CITIC: { logo: 'logo_zxyh.png', bg: '#e57158' },
    ABC: { logo: 'logo_nyyh.png', bg: '#65a89c' },
    CEB: { logo: 'logo_gdyh.png', bg: '#945caf' },
    CIB: { logo: 'logo_xyyh.png', bg: '#585a91' },
    PAB: { logo: 'logo_payh.png', bg: '#f47f52' },
    ICBC: { logo: 'logo_gsyh.png', bg: '#c65767' },
    CCB: { logo: 'logo_jsyh.png', bg: '#4e6da1' },
    CMB: { logo: 'logo_zsyh.png', bg: '#e54552' },
    CMBC: { logo: 'logo_msyh.png', bg: '#39aeb2' },
    NBCB: { logo: 'logo_nbyh.png', bg: '#f28300' },
    BCOM: { logo: 'logo_jtyh.png', bg: '#0063a0' },
    GDB: { logo: 'logo_gfyh.png', bg: '#d22c3f' },
    SPDB: { logo: 'logo_pfyh.png', bg: '#1c5d96' },
    BOB: { logo: 'logo_bjyh.png', bg: '#e65103' },
    CBHB: { logo: 'logo_chcb.png', bg: '#C31215' },
    CZB: { logo: 'logo_czb.png', bg: '#C90918' },
    HKBANK: { logo: 'logo_hkbank.png', bg: '#0486AA' },
    HSB: { logo: 'logo_hsb.png', bg: '#E43F42' },
    HXB: { logo: 'logo_hxb.png', bg: '#CC4E55' },
    NJCB: { logo: 'logo_njcb.png', bg: '#E23744' },
  }
}
export function getBankImageByCode (bankCode) {
  const bankImages = getBankImages()
  return bankImages[bankCode] || bankImages['OTHOR']
}
