function get() {
  let env
  let hostname = location.hostname
  if (hostname.indexOf('t1-') === 0) {
    env = 't1'
  } else if (hostname.indexOf('t2-') === 0) {
    env = 't2'
  } else if (hostname.indexOf('t3-') === 0) {
    env = 't3'
  } else if (hostname.indexOf('d1-') === 0) {
    env = 'd1'
  } else if (hostname.indexOf('d2-') === 0) {
    env = 'd2'
  } else if (hostname.indexOf('172.') === 0 || hostname === '127.0.0.1' || hostname === '0.0.0.0' || hostname === 'localhost') {
    env = 'dev'
  } else {
    env = 'prod'
  }
  return env
}

export { get }
