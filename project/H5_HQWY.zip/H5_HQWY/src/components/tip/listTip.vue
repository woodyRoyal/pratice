<template>
  <div class="hqwy-list-tip"
       :class="{'txtCenter': alignStyle}">
    <span></span>
    <p>无需下载APP，一键申请</p>
  </div>
</template>
<script>
export default {
  props: {
    alignStyle: { // 弹窗中间内容文案居中方式
      type: Boolean,
      default: false,
    },
  },
}
</script>
<style lang="scss" scoped>
.hqwy-list-tip {
  margin-top: rc(15);
  display: flex;
  // height: rc(34);
  align-items: center;
  &.txtCenter {
    justify-content: center;
  }
  span {
    margin-right: rc(8);
    width: rc(34);
    height: rc(34);
    background: url('../../../static/images/global_ic_app.png') no-repeat 0 center;
    background-size: rc(32) auto;
  }
  p {
    font-size: rc(22);
    color: #ff601a;
  }
}
</style>

