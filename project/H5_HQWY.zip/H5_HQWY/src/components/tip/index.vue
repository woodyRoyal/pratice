<template>
  <div class="hqwy-tip">
    <img class="hqwy-tip-icon"
         :src="require('APP_IMG/prompt.png')"
         alt="">
    <p v-html="txt"></p>
  </div>
</template>
<script>
export default {
  props: {
    txt: {
      type: [String, Number],
      default: '',
    },
  },
}
</script>
<style lang="scss" scoped>
.hqwy-tip {
  position: relative;
  padding: rc(0 30);
  // background-image: linear-gradient(rgba($color-remind, 0.1), rgba($color-remind, 0.1)), linear-gradient(#ffffff, #ffffff);
  background: rgba($color-remind, 0.1);
  .hqwy-tip-icon {
    width: rc(32);
    // height: rc(32);
    position: absolute;
    top: rc(14);
    left: rc(30);
  }
  p {
    padding: rc(14 0 14 54);
    font-size: rc(24);
    line-height: rc(32);
    color: $color-remind;
  }
}
</style>

