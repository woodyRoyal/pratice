<template>
  <div :class="type"
       class="repay-container">
    <div v-for="(item, index) in list"
         :key="index"
         class="repay-item"
         :class="childType"
         @click="repayClick(item, index)">
      <div class="repay-productname"
           v-text="item.productName"></div>
      <div class="repay-splitline"></div>
      <div class="repay-date">
        {{ item.dueDate | formateDate('M月D号') }}
      </div>
      <div class="repay-price">
        应还&yen;{{ item.dueAmount | toFixed(2) }}
      </div>
      <div class="repay-status-text"
           :class="item.status==3?'rstc1':''"
           v-text="item.status==3?'已逾期':'立即还款'"></div>
      <img class="repay-arrow"
           src="../../../static/images/arrow.png" />
    </div>
  </div>
</template>
<script>
import utils from "../../util/utils.js";
export default {
  name: 'RepayOrder',
  filters: {
    formateDate (date, fmt) {
      return utils.formateDate(date, fmt)
    },
    toFixed (val, n) {
      val = Number(val)
      return val.toFixed(n)
    },
  },
  // props: ['type', 'list'],
  props: {
    type: {
      type: String,
      default: '',
    },
    list: {
      type: Array,
      default: () => [],
    },
  },
  computed: {
    childType () {
      return this.type === 'swiper-wrapper' ? 'swiper-slide' : ''
    },
  },
  methods: {
    repayClick (item, index) {
      this.$emit('repayClick', item, index)
    },
  },
}
</script>
<style lang="scss" scoped>
.repay-container {
  margin: rc(0 30 0);
  border-radius: rc(12);
}
.repay-item {
  color: #333;
  background-color: #f9f9f9;
  font-size: rc(28);
  // width: 100%;
  height: rc(90);
  box-sizing: border-box;
  padding: rc(0 24);
  display: flex;
  align-items: center;
  .repay-productname {
    font-size: rc(30);
    font-weight: bold;
  }
  .repay-splitline {
    width: rc(2);
    min-width: 1px;
    height: rc(32);
    background-color: #e7e7e7;
    margin: 0 rc(20);
  }
  .repay-price {
    margin-left: rc(14);
    flex: 1;
  }
  .repay-status-text {
    color: #ff601a;
    &.rstc1 {
      color: #f94336;
    }
  }
  .repay-arrow {
    width: rc(10);
    height: auto;
    margin-left: rc(10);
  }
}
</style>


