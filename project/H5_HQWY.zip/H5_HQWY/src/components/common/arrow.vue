<template>
  <!-- <div class="hy-hqwy-arrow" :class="'hy-hqwy-arrow-' + direction" :style="{'border-color': color}"></div> -->
  <img src="../../../static/images/arrow.png"
       alt=""
       class="hqwy-arrow-img-right">
</template>

<script>
export default {
  // props: {
  //   size: [String, Number],
  //   direction: String, // up, down, left, right
  //   color: [String, Number]
  // }
}
</script>

<style lang="scss">
.hqwy-arrow-img {
  &-right {
    width: rc(15);
    height: rc(26);
    margin-left: rc(16);
  }
}
// $arrowsize: rc(20); /*箭头大小*/
// $arrowColor: #cccccc;
// .hy-hqwy-arrow {
//   display: inline-block;
//   width: $arrowsize;
//   height: $arrowsize;
//   border-width: 1px 1px 0 0;
//   border-style: solid;
//   &-up {
//     transform: matrix(.71,.71,-.71,.71,0,0) rotate(-90deg);
//     transition: transform 300ms;
//   }
//   &-down {
//     transform: matrix(.71,.71,-.71,.71,0,0) rotate(90deg);
//     transition: transform 300ms;
//   }
//   &-left {
//     transform: matrix(.71,.71,-.71,.71,0,0) rotate(-180deg);
//   }
//   &-right {
//     transform: matrix(.71,.71,-.71,.71,0,0) rotate(0deg);
//   }
// }
</style>
