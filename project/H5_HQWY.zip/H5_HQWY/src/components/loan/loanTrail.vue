<template>
  <Confirm ref="sureComfirm"
           title="费用与还款计划"
           sure-txt="确定"
           :btn-same-color="false"
           :close-flag="false">
    <div id="hqwy-mescroll"
         class="mescroll calculate">
      <div class="trial">
        <div class="top-part">
          <div class="lc-top-amount">
            <p>到账金额：&yen;{{ trailInfo.receiveAmount | formatePrice }}</p>
          </div>
          <div v-if="trailInfo.serviceCharge > 0">
            <p class="lc-amount">
              服务费：&yen;{{ trailInfo.serviceCharge | formatePrice }}
            </p>
            <p class="lc-explain-tips">
              {{ trailInfo.serviceExplain }}
            </p>
          </div>
          <div v-if="trailInfo.otherCharge > 0">
            <p class="lc-amount">
              其他费用：&yen;{{ trailInfo.otherCharge | formatePrice }}
            </p>
            <p class="lc-explain-tips">
              {{ trailInfo.otherExplain }}
            </p>
          </div>
          <div v-if="totalPeriod == 1">
            <p class="lc-amount">
              到期应还：&yen;{{ trailInfo.repayTotal | formatePrice }}
            </p>
            <p class="lc-explain-tips">
              包含利息&yen;{{ trailInfo.interest | formatePrice }}
            </p>
          </div>
        </div>
        <div v-if="totalPeriod > 1"
             class="plan-list">
          <LoanCell type="plan-item plan-title"
                    title="还款计划"
                    :is-link="false"></LoanCell>
          <LoanCell type="plan-item"
                    title="预计还款日"
                    :is-link="false">
            <div>应还金额</div>
          </LoanCell>
          <ul>
            <li v-for="(plan,index) in trailInfo.repayPlanList"
                :key="index">
              <LoanCell type="plan-item"
                        :title="plan.repayTs"
                        :is-link="false">
                <div>&yen;{{ plan.repayAmount | formatePrice }}</div>
              </LoanCell>
            </li>
          </ul>
          <p class="lc-explain-tips">
            应还合计：&yen;{{ trailInfo.repayTotals | formatePrice }}，包含利息&yen;{{ trailInfo.interest | formatePrice }}
          </p>
        </div>
        <div>
          <p class="lc-bottom-tips">
            * 仅供参考, 实际账单以借款后页面显示为准
          </p>
        </div>
      </div>
    </div>
  </Confirm>
</template>
<script>
import LoanCell from '@/components/cell/index'
import Confirm from "@/components/confirm/index"
import {
  trialApi,
} from "../../../src/api/controller/loan";

export default {
  components: {
    LoanCell,
    Confirm,
  },
  filters: {
    formatePrice (val) {
      val = Number(val)
      if (isNaN(val)) {
        val = 0
      }
      return val.toFixed(2)
    },
  },
  props: {
    loanAmount: {
      type: [String, Number],
      default: '',
    },
    orderNo: {
      type: [String, Number],
      default: '',
    },
    loanOrderNo: {
      type: [String, Number],
      default: '',
    },
    term: {
      type: [String, Number],
      default: '',
    },
    termUnit: {
      type: [String, Number],
      default: '',
    },
    totalPeriod: {
      type: [String, Number],
      default: '',
    },
  },
  data () {
    return {
      trailInfo: {
        interest: 0, // 利息
        otherCharge: 0, // 其他费用
        otherExplain: '', // 其他费用说明
        receiveAmount: 0, // 到账金额
        repayPlanList: [], // 还款计划
        repayTotal: 0, // 应还总额(单期)
        serviceCharge: 0, // 服务费
        serviceExplain: '', // 服务费说明
        repayTotals: 0, // 应还合计（多期累计每期应还）
      },
    }
  },
  // 页面打开的时候调用
  activated () {
    // this.requestData();
  },
  methods: {
    show () {
      this.requestData();
      this.$refs.sureComfirm.show()
    },
    hide () {
      this.$refs.sureComfirm.hide()
    },
    // recommonBtn (eventid) {

    // },
    requestData () {
      this.isLoading = true
      var params = {
        "loanAmount": this.loanAmount,
        "orderNo": this.orderNo,
        "loanOrderNo": this.loanOrderNo,
        "term": this.term,
        "termUnit": this.termUnit,
        "totalPeriod": this.totalPeriod,
      }

      trialApi(params).then(
        (data) => {
          if (data.respCode === "1000") {
            data = data.body
            this.trailInfo = data
            if (data.repayPlanList && data.repayPlanList.length > 0) {
              let repayTotals = 0
              for (let i = 0; i < data.repayPlanList.length; i++) {
                repayTotals += Number(data.repayPlanList[i].repayAmount)
              }
              this.trailInfo.repayTotals = repayTotals
            }
          }
          this.isLoading = false;
        },
        () => {
          this.isLoading = false
          // utils.toastMsg(err.respMsg)
        }
      );
    },
  },
}
</script>
<style lang="scss" scoped>
.calculate {
  max-height: rc(716);
  overflow-y: auto;
}
.plan-list {
  padding-bottom: 0;
}

.lc-top-amount {
  padding-top: rc(18);
  font-size: rc(30);
  font-family: PingFangSC-Semibold;
  font-weight: normal;
  font-stretch: normal;
  color: #333333;
}

.lc-explain-tips {
  padding-top: rc(7);
  font-size: rc(24);
  font-weight: normal;
  font-stretch: normal;
  font-family: PingFangSC-Regular;
  color: #999999;
}

.lc-amount {
  padding-top: rc(30);
  font-size: rc(30);
  font-weight: normal;
  font-stretch: normal;
  font-family: PingFangSC-Semibold;
  color: #333333;
}

.lc-bottom-tips {
  padding-top: rc(26);
  font-size: rc(24);
  font-family: PingFangSC-Regular;
  font-weight: normal;
  font-stretch: normal;
  color: #999999;
}

.plan-list .hy-cell {
  margin-left: 0;
}
.plan-item {
  padding-top: rc(10);
  padding-bottom: rc(10);
  font-size: rc(28);
}
</style>
<style>
.plan-title.hy-cell .hy-cell-left {
  font-weight: bold;
}
</style>

