<template>
  <Confirm ref="helpCenter"
           title="客服/帮助"
           :close-flag="true">
    <div class="help-center">
      <a v-if="(name || productName) && tel && customPhoneType == 0"
         class="help-center-item b-1px"
         :href="'tel:' + tel"
         @click="telClick('bztc;lxjg;w237')">
        <img class="help-center-icon"
             src="../../static/images/help_other.png"
             alt="">
        <div class="help-center-title">联系{{ name || productName }}</div>
        <img class="help-center-arrow"
             src="../../static/images/arrow.png"
             alt="">
      </a>
      <a class="help-center-item b-1px"
         href="tel:4008216161"
         @click="telClick('bztc;lxwf;w238')">
        <img class="help-center-icon"
             src="../../static/images/help_dkw.png"
             alt="">
        <div class="help-center-title">联系{{ $config.get('appNameCh') }}</div>
        <img class="help-center-arrow"
             src="../../static/images/arrow.png"
             alt="">
      </a>
      <div class="help-center-item b-1px"
           @click="toHelpCenter('bztc;jrbzzx;w239', 239)">
        <img class="help-center-icon"
             src="../../static/images/help_service.png"
             alt="">
        <div class="help-center-title">
          帮助与反馈
        </div>
        <img class="help-center-arrow"
             src="../../static/images/arrow.png"
             alt="">
      </div>
    </div>
  </Confirm>
</template>

<script>
// import utils from '@/util/utils'
import Confirm from '@/components/confirm/index'
import { productInfoApi } from '@/api/controller/product/index'
export default {
  name: 'Helpcenter',
  components: {
    Confirm,
  },
  props: {
    productId: {
      type: [String, Number],
      default: '',
    },
    productName: {
      type: String,
      default: '',
    },
  },
  data () {
    return {
      showHelpcenter: false,
      tel: '', // 第三方电话
      customPhoneType: '', // 0-客服电话，1-其他客服
      name: this.productName,
    }
  },
  activated () {
    this.tel = ''
  },
  methods: {
    show () {
      let that = this
      if (!that.tel) {
        that.getTelByProductId()
      }
      that.$refs.helpCenter.show()
    },
    hide () {
      this.$refs.helpCenter.hide()
    },
    // 根据产品id获取联系电话
    getTelByProductId () {
      let that = this
      let productId = that.productId
      if (!productId) {
        return
      }
      productInfoApi({ productId: productId }).then((data) => {
        data = data.body
        that.tel = data.customPhone
        that.customPhoneType = data.customPhoneType
        if (data.name) {
          that.name = data.name
        }
      })
    },
    telClick (eventId) {
      let that = this
      that.md50td(eventId)
      that.$refs.helpCenter.hide()
    },
    toHelpCenter (eventId, w) {
      let that = this
      that.md50td(eventId)
      that.$refs.helpCenter.hide()
      that.openHelpcenter(w)
    },
    // 武林榜 & TD埋点
    md50td (eventId, type) {
      type = type || 0 // 0或者没有eventType参数代表上传TD和移动武林榜； 1 上传TD； 2 上传移动武林榜；
      if (eventId) {
        this.$appInvoked('appExecStatistic', { eventId: eventId, eventType: type });
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.help-center {
  padding: rc(0 35 52 44);
  &-item {
    display: flex;
    align-items: center;
    height: rc(86);
    margin-top: rc(34);
    font-size: rc(26);
    padding: rc(0 36);
    color: #444;
    &::after {
      border-color: #ddd;
      border-radius: rc(200);
    }
  }
  &-icon {
    width: rc(52);
    height: rc(52);
  }
  &-title {
    margin-left: rc(24);
    flex: 1;
  }
  &-arrow {
    width: rc(15);
  }
}
</style>

