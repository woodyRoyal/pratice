<template>
  <div class="hy-btn"
       :class="{'hy-btn-active': btnData.activeFlag, 'hy-btn-mini': btnData.mini}"
       v-html="btnData.txt"></div>
</template>
<script>
export default {
  props: {
    btnData: {
      type: Object,
      default: () => ({}),
    },
  },
  // data () {
  //   return {
  //   }
  // },
  // mounted () {
  // },
}
</script>
<style lang="scss" scoped>
.hy-btn {
  display: block;
  width: 100%;
  height: rc(96);
  line-height: rc(96);
  border-radius: rc(48);
  font-size: rc(36);
  text-align: center;
  color: $btn-txt-color;
  background-image: $btn-default-bg;
  opacity: $btn-disabled-opacity;
}
.hy-btn-active {
  opacity: 1;
  &:active {
    background-image: $btn-actived-bg;
  }
}
.hy-btn-mini {
  height: rc(56);
  line-height: rc(56);
}
</style>
