<template>
  <!-- 用来获取用户的姓名和身份证号 不需要在页面展示 列表点击跳转时姓名或身份证号有一项未填写时跳转至basicInfo-->
  <div style="display:none;"></div>
</template>
<script>
import { getBasicInfoApi } from "../../api/controller/openAccount"
import { queryStatusApi } from "../../api/controller/common";
import eventCtr from "../../../static/js/eventCtr"
// import utils from "../../util/utils.js"
/* eslint-disable eqeqeq */
export default {
  // activated () {
  //   // this.getBasicInfoFun()
  // },
  // mounted () {
  // },
  methods: {
    // 获取姓名身份证号信息，及是否通过同盾认证
    getBasicInfoFun (callback) {
      let that = this
      that.$appInvoked("appGetUserToken", {}, function (token) {
        if (token != "" && token != null) {
          if (that.$store.state.baseInfo.userName != '' && that.$store.state.baseInfo.userIdcard != '' && that.$store.state.baseInfo.hasAuth) {
            eventCtr.$emit("nameIdcardEditAll", true)
            callback && callback(true)
            return
          }
          getBasicInfoApi({}).then((data) => {
            if (data.respCode === "1000") {
              let name = data.body.userName || ''
              let idCard = data.body.identityCard || ''
              let authStatus = data.body.authStatus
              let hasAuth = authStatus == 1 || authStatus == 2
              that.$store.commit("USER_NAME", name)
              that.$store.commit("USER_IDCARD", idCard)
              that.$store.commit("hasAuth", hasAuth)
              let nameIdcardEditAll = false
              if (name != '' && idCard != '' && hasAuth) {
                nameIdcardEditAll = true
              }
              localStorage.setItem('nameIdcardEditAll', nameIdcardEditAll)
              eventCtr.$emit("nameIdcardEditAll", nameIdcardEditAll)
              callback && callback(nameIdcardEditAll)
            }
          }).catch(() => {
            // console.log('出错了')
            // utils.toastMsg(err.respMsg)
          })
        }
      })
    },
    // 获取我的小红点
    queryStatusFunc () {
      let self = this;
      self.$appInvoked("appGetUserToken", {}, function (token) {
        if (token != "" && token != null) {
          queryStatusApi().then((data) => {
            let body = data.body;

            let remark = false;
            for (let i = 0, l = body.redRemarkList.length; i < l; i++) {
              let item = body.redRemarkList[i];
              if (item.remarkType == 0 && item.remarkStatus == 1) {
                remark = true;
                break;
              }
            }
            let overDue = body.overdueMark;
            if (overDue) {
              let hideOverdueMarkDate = localStorage.getItem('hideOverdueMarkDate');
              if (hideOverdueMarkDate) {
                let curDate = new Date();
                curDate = curDate.getFullYear() + '-' + (curDate.getMonth() + 1) + '-' + curDate.getDate();
                if (curDate == hideOverdueMarkDate) {
                  overDue = false;
                }
              }
            }
            self.$store.commit('orderDotRemark', {
              overDue: overDue,
              remark: remark,
            });
          });
        }
      })
    },
  },
}
</script>


