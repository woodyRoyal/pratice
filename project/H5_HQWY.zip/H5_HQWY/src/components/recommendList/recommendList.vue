<template>
  <div id="hqwy-rcd-list"
       class="mescroll">
    <slot></slot>
    <ProductList v-if="!showErrorPage"
                 :list="lists"
                 @on-click="onProductClick"></ProductList>
    <BasicInfo ref="basicInfo"></BasicInfo>
    <VLoad :isload="isLoad"></VLoad>
    <!-- <div v-if="showErrorPage">
      <v-abnor :abnorText="reloadText"></v-abnor>
    </div> -->
    <DefaultBlankPage v-show="showErrorPage"
                      :icon="errorPageInfo.icon"
                      :title="errorPageInfo.title"
                      :btn-txt="errorPageInfo.btnTxt"
                      :btn-click="errorPageInfo.btnClick"
                      :has-tabbar="errorPageInfo.hasTabbar"></DefaultBlankPage>
    <!-- <div class="empty"
         v-if="isEmpty"
         key="empty">
      <img :src="require(`../../../static/images/hqwy/qsy_wtj.png`)"
           alt="">
      <p>很遗憾！根据您的资质和借款需求，暂时没有匹配到合适的产品！</p>
    </div> -->
  </div>
</template>

<script>
import ProductList from '@/components/product/ProductList'
import eventCtr from "../../../static/js/eventCtr";
import VLoad from "../load.vue";
// import vAbnor from "../abnormal.vue";
import MeScroll from "mescroll.js";
import utils from '../../util/utils';
import { requestRecommendList } from "../../../src/api/controller/recommendList";
import BasicInfo from "../../components/basicInfo/index"
import { requestJoinLogin } from "../../api/controller/product";
import DefaultBlankPage from '../DefaultBlankPage'
/* eslint-disable eqeqeq */
export default {
  name: "RmdList",
  components: {
    ProductList,
    // vAbnor,
    VLoad,
    BasicInfo,
    DefaultBlankPage,
  },
  props: {
    userData: {
      type: Object,
      default: () => ({}),
    },
  },
  data () {
    return {
      // isEmpty: false,
      type: 4,
      errorImg01:
        this.getCachedImages("productIcon") ||
        require("APP_IMG/default.png"), //无产品图,
      // loading: true,
      // loadingEnd: false,
      tipText: "",
      loadingText: "更多产品正在赶来",
      lists: [],
      // circleData: {},
      abnorData: {}, //异常数据
      currPageNo: 0,
      totalCount: 3,
      totalPage: 0, //总页码
      //loadimg: '../../../static/images/loading.png',
      nodata: false, //没有更多数据了,
      PagePara: {
        dataover: false, //检测所有数据是否加载完
        dataloading: false, //检测是否正在加载数据
      },
      isLoad: "none", //默认页面没有loading动画
      tipsFlag: false, //提示条状态标识 false标识用户还没有点击过任何一款产品
      userMobilePhone: "",
      showErrorPage: false,
      errorPageInfo: {},
      initFlag: false,
      nameIdcardEditAll: false, // 姓名身份证号已填写标识
    };
  },
  inject: ['recommendResult'],
  activated () {
    this.showErrorPage = false;
    // window.topPreRecommend = this.topPreRecommend;
    this.isLoad = "block"; //开始loading
    this.currPageNo = 0;
    this.upCallback();
    // 获取姓名身份证
    this.$refs.basicInfo.getBasicInfoFun()
  },
  deactivated () {
    this.initFlag = true;
    setTimeout(() => {
      this.lists = [];
    }, 500)
  },
  // destroyed() {
  // 	window.removeEventListener('scroll', this.InitLoadMore, true);
  // },
  mounted () {
    // window.addEventListener('scroll', this.InitLoadMore, true);
    //this.tipsGetFun(); //确定提示条文案
    //window.tipsGetFun = this.tipsGetFun;
    // var self = this;
    // self.getRecommendList();
    this.mescroll = new MeScroll("hqwy-rcd-list", {
      down: {
        use: false,
      },
      up: {
        auto: false,
        callback: this.upCallback,
        isBounce: false,
        noMoreSize: 1,
        htmlLoading: `<div id="databottom" class="data-bottom">
                    <div class="load">
                    </div>
                    <div class="text" id="bottomtext">更多产品正在赶来</div>
                  </div>`,
        htmlNodata: `<div class="no-data" >
                        <div class="no-datas">
                          <div class="no-datas-text">已经到底啦</div>
                        </div>
                    </div>`,
      },
    });

    // 获取姓名和身份证是否已填写
    eventCtr.$on("nameIdcardEditAll", (msg) => {
      this.nameIdcardEditAll = msg
    })
  },
  methods: {
    onProductClick (item, index, isTheFirstThree = false) {
      // eslint-disable-next-line camelcase
      item.fm_showRedDot = false
      if (!isTheFirstThree) {
        index += 3
      }
      this.proListClick(item.name, item.address, item.id, index, 106, (index + 1), item.type, item.linkSeqId, item)
    },
    // topPreRecommend () {
    //   this.globalRecommendClick()
    // },
    upCallback () {
      var self = this;
      if (this.initFlag) {
        self.currPageNo = 1;
        self.initFlag = false;
      } else {
        self.currPageNo = self.currPageNo + 1;
      }
      self.PagePara.dataloading = true;
      self.getRecommendList();
    },
    getRecommendList () {
      var self = this;
      self.userData.currPageNo = self.currPageNo;
      requestRecommendList(self.userData).then(
        (rst) => {
          self.isLoad = "none";
          if (rst.respCode === "1000" && rst.body.page.length > 0) {
            if (self.currPageNo == 1) {
              if (rst.body.page.length < 3) {
                self.mescroll.endSuccess(false);
                self.initDefaultErrorPageInfos('noData')
                return
              }
              self.redDotHanler(rst.body.page)
            }
            // self.circleData.limit = rst.body.limit;
            // self.circleData.passRate = rst.body.passRate;
            self.totalCount = rst.body.totalCount;
            self.totalPage = rst.body.totalCount / rst.body.pageSize;
            self.lists = self.lists.concat(self.formateProductList(rst.body.page, 'zntjjgy'));
            // self.redDotHanler(self.lists)
            // 分割截取前三，列表从第四个开始
            if (self.recommendResult.rankingList.length != 3) {
              self.recommendResult.rankingList = self.lists.splice(0, 3)
            }
            self.recommendResult.ismMore = self.lists.length >= 1
            // eventCtr.$emit("to-parent", self.circleData);
            //self.loadimg = '../../../static/images/loding.gif';
            self.PagePara.dataloading = false;
            //是否有下一页
            var hasNext = self.lists.length < self.totalCount;
            self.mescroll.endSuccess(rst.body.pageSize, hasNext);
          } else {
            self.mescroll.endSuccess(false);
            if (self.currPageNo < 2) {
              // self.showErrorPage = true;
              // self.isEmpty = true
              self.initDefaultErrorPageInfos('noData')
            } else {
              self.currPageNo = self.currPageNo - 1;
            }
          }
        },
        () => {
          self.mescroll.endSuccess();
          self.isLoad = "none";
          if (self.currPageNo < 2) {
            // self.showErrorPage = true;
            // self.reloadText = {
            //   reloadText: "网络异常",
            //   defaultImg: this.getCachedImages("loadFailIcon")
            // };
            self.initDefaultErrorPageInfos('offline')
          } else {
            self.currPageNo = self.currPageNo - 1;
          }
        }
      );
    },
    // 红点初始化逻辑
    redDotHanler (arr) {
      let list = arr.slice(0, 8)
      let newArr = JSON.parse(localStorage.getItem("RED_DOT_DATA") || '[]');
      // list.forEach(item => {
      //   if (newArr.length === 0) {
      //     newArr.push({ id: item.id, check: false })
      //   } else if (!newArr.some(v => v.id === item.id)) {
      //     newArr.unshift({ id: item.id, check: false })
      //   }
      // })
      // newArr = newArr.splice(0, 8)
      let hasClickArr = []
      newArr.forEach((item) => {
        if (item.check) {
          hasClickArr.push(item.id)
        }
      })
      newArr = []
      list.forEach((item) => {
        newArr.push({ id: item.id, check: hasClickArr.indexOf(item.id) > -1 })
      })
      // newArr = newArr.splice(0, 8)
      localStorage.setItem("RED_DOT_DATA", JSON.stringify(newArr));
    },
    // 点击红点逻辑
    checkRed (productId) {
      let newArr = JSON.parse(localStorage.getItem("RED_DOT_DATA"))
      let result = newArr.find((v) => v.id == productId)
      if (result && !result.check) {
        result.check = true
        localStorage.setItem("RED_DOT_DATA", JSON.stringify(newArr));
      }
    },
    // 点击产品列表
    proListClick (name, url, id, index, w, p, goFlag, linkSeqId, item) {
      let that = this
      that.needUserLogin(w, () => {
        // 红点
        that.checkRed(id)
        // 是否支持api
        if (item.supportApiLoan) {
          let tourl = `?category=12&productId=${id}&productName=${name}&p=${p}&w=${w}&supportJoinLogin=${item.supportJoinLogin}&t=${item.rank}`
          let eventId = `chanpin0;w${w};p${p};c${id};l${window.$config.get('events.linkSeqId')};t${item.rank}`;
          that.clickReport(id, 12, eventId);
          that.$appInvoked("appExecStatistic", {
            eventId: eventId,
            eventType: 2,
          }); //添加埋点
          // 姓名和身份证号是否已填写
          // console.log(that.nameIdcardEditAll)
          if (!that.nameIdcardEditAll) {
            that.$refs.basicInfo.getBasicInfoFun((nameIdcardEditAll) => {
              if (nameIdcardEditAll) {
                // 已填写 去撞库
                that.$routerPush('/loanHit' + tourl)
              } else {
                // 未填写去基本信息补充页
                that.$routerPush('/basicInfo' + tourl)
              }
            })
          } else {
            // 已填写 去撞库
            that.$routerPush('/loanHit' + tourl)
          }
        } else {
          that.clickFun(name, url, id, index, w, p, goFlag, linkSeqId, item)
        }
      })
    },
    clickFun (name, url, productId, index, w, p, goFlag, linkSeqId, proObj) {
      var self = this;
      //url 产品跳转链接
      //id 产品id
      //eventid 统计代码
      let category = 12;
      // chanpin0进入产品详情页，chanpin1进入H5落地页，chanpin2阻止用户申请
      let eventId = `chanpin0;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
      if (goFlag == 2) { // 0-产品详情，2-第三方注册页
        eventId = `chanpin1;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
        let supportJoinLogin = proObj.supportJoinLogin; // 是否支持联登
        if (supportJoinLogin) { // 支持联合登录
          self.isLoad = 'block';
          let params = {
            linkId: linkSeqId,
            productId: productId,
          };
          requestJoinLogin(params).then((data) => {
            self.isLoad = 'none';
            if (data.respCode == '1000') {
              data = data.body;
              let regStatus = data.regStatus;
              // 0-未知 1-注册失败 2-金融超市注册成功 3-失败：其他渠道已有用户
              if (regStatus == 2) {
                self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
              } else if (regStatus == 3) {
                utils.toastMsg(`您已注册过${name}，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              } else {
                utils.toastMsg(`${name}系统维护中，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
                self.clickReport(productId, category, eventId);
              }
            } else {
              utils.toastMsg(`${name}系统维护中，请申请其他产品`);
              eventId = `chanpin2;w${w};p${p};c${productId};l${linkSeqId};t${proObj.rank}`;
              self.clickReport(productId, category, eventId);
            }
            self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
          }, () => {
            self.isLoad = 'none';
          });
        } else {
          // type = 1;
          // 打开第三方注册页
          self.openThirdRegisterPage(name, url, productId, w, p, category, linkSeqId, proObj.rank, 0)
          self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
        }
      } else {
        self.clickReport(productId, category, eventId);
        self.$routerPush(
          "/productDetail/" +
          category +
          "/" +
          productId +
          "?p=" +
          p +
          "&w=" +
          w +
          "&supportJoinLogin=" +
          proObj.supportJoinLogin + '&t=' + proObj.rank
        );
        self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
      }
      self.$appInvoked("appOnPageEnd", { pageName: this.$route.meta.title });
      window.currentPageName = this.$route.meta.title;
    },
  },
};
</script>

<style lang="scss" scoped="scoped">
#hqwy-rcd-list {
  height: 100%;
  width: 100%;
  box-sizing: border-box;
  overflow-x: hidden;
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch;
  // overflow-scrolling: touch;
  padding-bottom: rc(120);
}

// .hqwy-items {
//   /*min-height: 100%;*/
// }

// .flex,
// .hqwy-right-top,
// .hqwy-right-center {
//   display: flex;
//   display: -webkit-flex;
//   overflow: hidden;
// }

// .hqwy-item-top {
//   padding: rc(32) 0 rc(30);
// }

// .flex1,
// .hqwy-right {
//   flex: 1;
//   -webkit-flex: 1;
// }

// .hqwy-right {
//   padding-left: rc(20);
// }

// .hqwy-right {
//   overflow: auto;
// }

// .hqwy-right-bottom,
// .hqwy-right-center {
//   margin-top: rc(15);
//   color: #bbbbbb;
//   line-height: rc(30);
// }

// .hqwy-right-center {
//   margin-top: rc(20);
//   color: #999999;
//   line-height: rc(33);
//   font-size: rc(24);
// }

// .hqwy-splite-line {
//   margin: rc(0 10);
//   color: #e6e6e6;
// }

// .hqwy-right-center i {
//   font-style: normal;
//   //margin-left: rc(10);
// }

// .hqwy-right-bottom {
//   white-space: nowrap;
//   text-overflow: ellipsis;
//   overflow: hidden;
// }

// .hqwy-right-bottom span {
//   display: inline-block;
//   font-size: rc(24);
//   // transform: scaleY(0.917);
// }

// .hqwy-left {
//   position: relative;
//   width: rc(100);
//   height: rc(100);
//   //border: 1px solid #e5e5e5;
//   border-radius: rc(12);
// }

// .hqwy-left img {
//   display: block;
//   width: 100%;
//   height: 100%;
//   border-radius: rc(12);
// }

// .hqwy-dot-icon {
//   position: absolute;
//   display: inline-block;
//   background-color: #ff601a;
//   width: 10px;
//   height: 10px;
//   border-radius: 50%;
//   right: -4px;
//   top: -4px;
// }

// .hqwy-items li {
//   background-color: #ffffff;
//   padding-left: rc(30);
//   padding-right: rc(30);
// }

// .hqwy-items li a {
//   display: block;

//   color: #333333;
//   border-bottom: 1px solid #e6e6e6;
// }

// .hqwy-items li a h2 {
//   color: #111111;
// }

// .hqwy-tip {
//   text-align: center;
//   font-size: rc(24);
//   line-height: rc(70);
//   color: #999999;
//   //padding-left: rc(30);
// }

// .hqwy-tip a {
//   color: $color-main;
// }

// .hqwy-pass-rate {
//   background-color: #ff4c4c;
//   color: #ffffff;
//   display: inline-block;
//   padding: 0px 2px;
//   border-radius: 4px;
//   font-size: rc(24);
//   transform: scaleY(0.8);
// }

// .hqwy-item-top {
//   position: relative;
// }

// .hqwy-right-top p {
//   color: #ff4c4c;
//   font-size: rc(34);
//   font-weight: bold;
// }

// .hqwy-arrow {
//   position: absolute;
//   right: 0;
//   top: 50%;
//   margin-top: rc(-13);
//   width: rc(14);
// }

// .hqwy-arrow img {
//   display: block;
//   width: 100%;
// }

// .hqwy-tip-icon {
//   display: inline-block;
//   width: rc(32);
//   height: rc(32);
//   background: url(../../../static/images/public_horn_03.png) 0 0 no-repeat;
//   background-size: contain;
//   vertical-align: text-bottom;
//   margin-right: 5px;
// }

// .data-bottom {
//   margin-top: rc(21);
//   margin-bottom: rc(26);
//   font-size: rc(24);
//   color: #777;
//   display: flex;
//   display: -webkit-flex;
//   text-align: center;
//   .load {
//     width: rc(34);
//     height: rc(34);
//     margin-left: rc(281);
//     img {
//       width: rc(34);
//       height: rc(34);
//     }
//   }
//   .text {
//     margin-left: rc(10);
//   }
// }

// .no-data {
//   margin-bottom: rc(30);
//   margin-top: rc(30);
//   font-size: rc(24);
//   color: #777777;
//   text-align: center;
//   height: rc(96);
//   .no-datas {
//     height: rc(33);
//     width: 50%;
//     margin-left: 25%;
//     border-bottom: 1px solid #979797;
//     position: relative;
//     /*line-height:rc(33);*/
//     .no-datas-text {
//       width: 40%;
//       margin-left: 30%;
//       background: #f6f6f6;
//       position: absolute;
//       top: rc(16);
//     }
//   }
//   .other-pro {
//     margin-top: rc(30);
//     span {
//       color: $color-main;
//     }
//   }
// }

// .abnormal {
//   top: 0;
//   padding-top: rc(200);
//   box-sizing: border-box;
// }

// .hqwy-chart {
//   position: relative;
//   z-index: 5;
// }
// .empty {
//   position: fixed;
//   z-index: 1;
//   top: 50%;
//   left: 50%;
//   transform: translate(-50%, -50%);
//   text-align: center;
//   p {
//     text-align: center;
//     color: $color-text-sub;
//     font-size: rc(28);
//     margin-top: rc(52);
//   }
//   img {
//     width: rc(300);
//     height: rc(300);
//   }
// }
</style>
<style lang="scss">
#databottom {
  margin-top: rc(21);
  margin-bottom: rc(26);
  font-size: rc(24);
  color: #777;
  text-align: center;
  .load {
    display: inline-block;
    vertical-align: top;
    width: rc(34);
    height: rc(34);
    background: url(../../../static/images/loding.gif) no-repeat 0 0;
    background-size: contain;
  }
  .text {
    display: inline-block;
  }
}

.no-data {
  margin-top: rc(30);
  font-size: rc(24);
  color: #777777;
  text-align: center;
  height: rc(96);
  .no-datas {
    height: rc(33);
    width: 50%;
    margin-left: 25%;
    border-bottom: 1px solid #979797;
    position: relative;
    /*line-height:rc(33);*/
    .no-datas-text {
      width: 40%;
      margin-left: 30%;
      background: #f6f6f6;
      position: absolute;
      top: rc(16);
    }
  }
  .other-pro {
    margin-top: rc(30);
    span {
      color: $color-main;
    }
  }
}

.no-data.no-other {
  margin-bottom: rc(30);
  padding-bottom: rc(80);
}
</style>
