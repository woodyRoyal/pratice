<template>
  <div>
    <div class="title"></div>
    <div class="banner">
      <div class="swiper-container">
        <div class="swiper-wrapper">
          <template v-if="proList.length>0">
            <div v-for="(pro, proIdx) in proList"
                 :key="proIdx"
                 class="swiper-slide"
                 @click="toproDetail(pro.name,pro.address,pro.id,'109',(proIdx+1),pro.type,true,'13',pro.linkSeqId,pro)">
              <div class="top bb-1px">
                <div class="top-left">
                  <img v-lazy="{src:pro.logo,error:productIcon,loading:productIcon}" />
                </div>
                <div class="top-right">
                  <div class="pro-name">
                    <span class="item-name">{{ pro.name }}</span>
                    <span v-if="pro.score==5"
                          class="star">
                      <img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star1.png">
                    </span>
                    <span v-if="pro.score==4.5"
                          class="star">
                      <img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star2.png">
                    </span>
                    <span v-if="pro.score==4"
                          class="star">
                      <img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star3.png">
                    </span>
                    <span v-if="pro.score==3.5"
                          class="star">
                      <img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star2.png"><img src="../../static/images/star3.png">
                    </span>
                    <span v-if="pro.score==3"
                          class="star">
                      <img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png">
                    </span>
                    <span v-if="pro.score==2.5"
                          class="star">
                      <img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star2.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png">
                    </span>
                    <span v-if="pro.score==2"
                          class="star">
                      <img src="../../static/images/star1.png"><img src="../../static/images/star1.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png">
                    </span>
                    <span v-if="pro.score==1.5"
                          class="star">
                      <img src="../../static/images/star1.png"><img src="../../static/images/star2.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png">
                    </span>
                    <span v-if="pro.score==1"
                          class="star">
                      <img src="../../static/images/star1.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png">
                    </span>
                    <span v-if="pro.score==0.5"
                          class="star">
                      <img src="../../static/images/star2.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png">
                    </span>
                    <span v-if="pro.score==0"
                          class="star">
                      <img src="../../static/images/star3.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png"><img src="../../static/images/star3.png">
                    </span>
                  </div>
                  <div class="pro-info">
                    {{ pro.subhead }}
                  </div>
                </div>
              </div>
              <div class="middle"
                   :class="{'no-other-info': !pro.rate && !pro.duration}">
                <div class="limit-title">
                  额度(元)
                </div>
                <div class="limit">
                  {{ pro.limit | delUnit }}
                </div>
                <div v-if="pro.rate || pro.duration"
                     class="other-info">
                  <div v-if="pro.rate"
                       class="other-info-left">
                    <div class="other-info-title">
                      {{ pro.rate.split(':')[0] }}:
                    </div>
                    <div class="other-info-content">
                      {{ pro.rate.split(':')[1] }}
                    </div>
                  </div>
                  <div v-if="pro.duration"
                       class="other-info-right">
                    <div class="other-info-title">
                      期限:
                    </div>
                    <div class="other-info-content">
                      {{ pro.duration }}
                    </div>
                  </div>
                </div>
                <div class="hot-tip">
                  {{ pro.prompt }}
                </div>
                <ListTip v-if="pro.supportApiLoan"
                         :align-style="true"></ListTip>
                <div class="btn jrcs-btn">
                  立即申请
                </div>
                <div v-if="pro.rate || pro.duration"
                     class="already-release">
                  最快<span>{{ pro.loanTime }}</span>放款
                </div>
              </div>
            </div>
          </template>
          <div v-else
               class="swiper-slide"></div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
// import MySwiper from "../../static/swiper-4.3.3.min"
import ListTip from "../components/tip/listTip"

export default {
  name: "App",
  components: {
    ListTip,
  },
  props: {
    proList: {
      type: Array,
      default: () => [],
    },
  },
  data () {
    return {
      swiper: "",
      index: "",
      proArray: [],
      productIcon:
        this.getCachedImages("productIcon") ||
        require("APP_IMG/default.png"), //产品缩略占位图,
    };
  },
  // activated () { },
  // deactivated () { },
  watch: {
    proList: "updateData",
  },
  mounted () {
    this.initSwiper();
  },
  methods: {
    initSwiper: function () {
      // var self = this;
      this.swiper = new Swiper(".swiper-container", {
        // initialSlide: 2,
        slidesPerView: "auto",
        centeredSlides: true,
        watchSlidesProgress: true,
        spaceBetween: 12,
        // pagination: ".swiper-pagination",
        // paginationClickable: true,
        observer: true, //修改swiper自己或子元素时，自动初始化swiper    重要
        observeParents: true, //修改swiper的父元素时，自动初始化swiper  重要
        // initialSlide:  - 1,
        noSwiping: true,
        on: {
          slideChange: function () {
            localStorage.setItem("activeIndex", this.realIndex)
          },
        },
        // onProgress: function (swiper, progress) {
        //   if (!isNaN(progress)) {
        //     for (var i = 0; i < swiper.slides.length; i++) {
        //       var slide = swiper.slides[i];
        //       var progress = slide.progress;
        //       // var scale = 1 - Math.min(Math.abs(progress * 0.2), 1)
        //       var es = slide.style;
        //       // es.opacity = 1 - Math.min(Math.abs(progress / 2), 1)
        //       es.webkitTransform = es.transform =
        //         "translate3d(0,0," + -Math.abs(progress * 30) + "px)";
        //     }
        //   } else {
        //     for (var i = 0; i < swiper.slides.length; i++) {
        //       var slide = swiper.slides[i];
        //       var progress = slide.progress;
        //       var es = slide.style;
        //       es.webkitTransform = es.transform =
        //         "translate3d(0,0," +
        //         -Math.abs(30 / swiper.slides.length) +
        //         "px)";
        //     }
        //   }
        // },
        // onSetTransition: function (swiper, speed) {
        //   for (var i = 0; i < swiper.slides.length; i++) {
        //     var es = swiper.slides[i].style;
        //     es.webkitTransitionDuration = es.transitionDuration = speed + "ms";
        //   }
        // },
        // onTouchEnd (swiper, event) {
        //   self.childFn();
        // }
      });
    },
    toproDetail (
      name,
      url,
      productId,
      w,
      p,
      goFlage,
      needBackDialog,
      category,
      linkSeqId,
      item
    ) {
      this.$emit(
        "toproDetail",
        name,
        url,
        productId,
        w,
        p,
        goFlage,
        needBackDialog,
        category,
        linkSeqId,
        item
      );
    },
    updateData () {
      this.proArray = this.proList;
    },
  },
};
</script>

<style lang="scss" scoped="scoped">
// @media screen and (min-height: 481px) {
//   .swiper-wrapper {
//     margin-top: 20px;
//   }
// }

// @media screen and (min-height: 569px) {
//   .swiper-wrapper {
//     margin-top: 40px;
//   }
// }
.title {
  height: rc(47);
}
.banner {
  position: relative;
}
.swiper-container {
  width: rc(600);
  height: rc(900);
  overflow: visible !important;
  .swiper-slide,
  .swiper-wrapper {
    width: 100%;
    height: 100%;
    position: relative;
    transform-style: preserve-3d;
  }
  .swiper-slide {
    // width: 88%;
    // height: 88%;
    // margin-top: 6%;
    border-radius: rc(20);
    background-color: #fff;
    box-shadow: 0 0 rc(20) 0 rgba($color-main, 0.2);
    border-radius: rc(30);
    // transition: 300ms;
    &:not(.swiper-slide-active) {
      transform: scaleY(0.87);
      .top,
      .middle {
        transform: scaleX(0.87);
      }
    }
  }
}
.top {
  height: rc(130);
  padding-left: rc(40);
  padding-top: rc(40);
  display: flex;
  .top-left {
    height: rc(100);
    width: rc(100);
    img {
      height: rc(100);
      width: rc(100);
      border-radius: rc(18);
    }
  }
  .top-right {
    margin-left: rc(30);
    flex: 1;
    overflow: hidden;
    .pro-name {
      margin-top: rc(10);
      height: rc(42);
      display: flex;
      align-items: center;
      overflow: hidden;
      .item-name {
        font-family: PingFangSC-Semibold;
        font-size: rc(30);
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0px;
        color: #111111;
        height: 100%;
        line-height: rc(42);
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }
    .pro-info {
      margin-top: rc(5);
      font-size: rc(24);
      font-weight: normal;
      font-stretch: normal;
      letter-spacing: 0px;
      color: $color-text-sub;
    }
  }
}

.middle {
  padding-top: rc(60);
  &.no-other-info {
    padding-top: rc(140);
  }
  .hqwy-list-tip {
    padding-top: rc(20);
  }
  .limit-title {
    font-size: rc(30);
    color: $color-text-sub;
    text-align: center;
    height: rc(42);
    line-height: rc(42);
  }
  .limit {
    margin-top: rc(18);
    font-size: rc(60);
    font-weight: bold;
    color: $color-remind;
    height: rc(67);
    line-height: rc(67);
    text-align: center;
  }
  .other-info {
    margin-top: rc(70);
    display: flex;
    height: rc(100);
    .other-info-left {
      flex: 1;
      border-right: 1px solid $line-btn-border;
    }
    .other-info-right {
      flex: 1;
    }
  }
  .other-info-title {
    text-align: center;
    height: rc(42);
    line-height: rc(42);
    font-family: PingFangSC-Regular;
    font-size: rc(30);
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0px;
    color: $color-text-sub;
  }
  .other-info-content {
    text-align: center;
    margin-top: rc(14);
    height: rc(50);
    line-height: rc(50);
    font-size: rc(36);
    font-weight: bold;
    font-stretch: normal;
    letter-spacing: 0px;
    color: $color-text-title;
  }
  .hot-tip {
    text-align: center;
    margin-top: rc(40);
    height: rc(24);
    line-height: rc(24);
    font-size: rc(24);
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0px;
    color: $color-text-tip;
  }
  .already-release {
    margin-top: rc(20);
    text-align: center;
    font-size: rc(24);
    color: $color-text-tip;
    span {
      color: $color-remind;
    }
  }
}
.btn {
  margin: rc(60) auto 0;
  width: rc(460);
  height: rc(80);
  border-radius: rc(40);
  font-size: rc(36);
}
.star {
  margin-left: rc(22);
  display: flex;
  flex-wrap: nowrap;
  img {
    margin-right: rc(8);
    height: rc(21.7);
    width: rc(22.8);
  }
}
</style>
