<template>
  <div class="hy-dialog-drag"
       :style="{left:x+'px',top:y+'px'}"
       @touchstart.stop="touchstart"
       @touchmove.stop.prevent="touchmove">
    <slot></slot>
  </div>
</template>
<script>
export default {
  name: 'DialogDrag',
  props: {
    bottomSistance: {// 初始位置与视口底部的距离
      type: Number,
      default: 80,
    },
    rightSistance: {// 初始位置与视口右边的距离
      type: Number,
      default: 18,
    },
    maxTopY: { // 距离头部的最大距离
      type: Number,
      default: 120,
    },
  },
  data () {
    return {
      clientWidth: document.documentElement.clientWidth,
      clientHeight: document.documentElement.clientHeight,
      boxWidth: 0,
      boxHeight: 0,
      maxBottomY: 0,
      maxX: 0,
      startX: 0,
      startY: 0,
      x: 0,
      y: 0,
    };
  },
  mounted () {
    let $dom = document.querySelector('.hy-dialog-drag');
    this.boxWidth = $dom.offsetWidth;
    this.boxHeight = $dom.offsetHeight;
    this.x = this.clientWidth - this.boxWidth - this.rightSistance;
    this.y = this.clientHeight - this.boxHeight - this.bottomSistance;
    this.maxX = this.clientWidth - this.boxWidth - this.rightSistance;
    this.maxBottomY = this.clientHeight - this.boxHeight - this.bottomSistance;
  },
  methods: {
    touchstart (e) {
      this.startX = e.targetTouches[0].pageX - this.x;
      this.startY = e.targetTouches[0].pageY - this.y;
    },
    touchmove (e) {
      this.x = e.targetTouches[0].pageX - this.startX;
      this.y = e.targetTouches[0].pageY - this.startY;
      if (this.x <= this.rightSistance) {
        this.x = this.rightSistance;
      } else if (this.x >= this.maxX) {
        this.x = this.maxX;
      }
      if (this.y <= this.maxTopY) {
        this.y = this.maxTopY;
      } else if (this.y >= this.maxBottomY) {
        this.y = this.maxBottomY;
      }
    },
    onDragHandler () {
      this.$emit('onDragHandler');
    },
  },
};
</script>
<style  lang="scss" scoped>
.hy-dialog-drag {
  position: fixed;
  width: rc(125);
  height: rc(125);
  border-radius: 50%;
  background: #ffffff;
  z-index: 2;
  box-shadow: rc(0 0 15 0) rgba(0, 0, 0, 0.07);
}
</style>
