<template>
  <div v-show="lists.length>0"
       :id="mescrollId"
       ref="hqwy-refresh"
       class="mescroll"
       style="width: 100%;height: 100%;overflow-x:hidden;overflow-y: auto;-webkit-overflow-scrolling: touch;">
    <slot name="banner"></slot>
    <div v-show="!showErrorPage"
         id="hqwy-content">
      <div :class="{'hqwy-list':type != 12,'hqwy-list1':type==12}">
        <ProductList :list="lists"
                     :ad-infos="listAdInfos"
                     @on-click="onProductClick"
                     @ad-click="onAdClick"></ProductList>
      </div>
      <!--智能推荐-->
      <!-- <DialogDrag v-if="isRecommend == '1' && hasAuditPass">
        <recommend @click.native="codeFun('dkdq;jztj;w80')"></recommend>
      </DialogDrag> -->
      <BasicInfo ref="basicInfo"></BasicInfo>
    </div>
    <!-- <div v-show="showErrorPage">
      <v-abnor :abnorText="reloadText"></v-abnor>
    </div> -->
    <DefaultBlankPage v-show="showErrorPage"
                      :icon="errorPageInfo.icon"
                      :title="errorPageInfo.title"
                      :btn-txt="errorPageInfo.btnTxt"
                      :btn-click="errorPageInfo.btnClick"
                      :has-tabbar="errorPageInfo.hasTabbar"></DefaultBlankPage>
    <VLoad :isload="isLoad"
           :style="loadStyle"></VLoad>
    <!-- 过审判断 -->
    <AuditPass ref="auditPass"></AuditPass>
  </div>
</template>
<script>
//获取用户还未点击过的产品
// var userNoClicked = {
//   noClickedName: "",
//   noClickedHref: "",
//   noClickedId: "",
//   type: "",
//   linkSeqId: "",
//   obj: {},
// };
//获取浏览记录接口 用来取用户最新点击过的产品
// var historyLatest = {};
// var domContainer = "";
// import Recommend from "./recommend";
// import DialogDrag from '../dialogDrag';
// import vRefresh from "../refresh.vue";
import ProductList from '@/components/product/ProductList'
import VLoad from "../load.vue";
// import vAbnor from "../abnormal.vue";
import MeScroll from "mescroll.js";
import utils from '../../util/utils';
import {
  // requestBrowseRecord,
  // requestProductRetain,
  requestCategory,
} from "../../../src/api/controller/categoryLoan";
import { requestProductFilter } from "../../../src/api/controller/prolist";
// import ListTip from "../tip/listTip"
import BasicInfo from "../basicInfo/index"
import eventCtr from "../../../static/js/eventCtr"
import { requestJoinLogin } from "../../api/controller/product";
import AuditPass from '@/components/function/hasAuditPass'
import DefaultBlankPage from '../DefaultBlankPage'

/* eslint-disable eqeqeq */
export default {
  name: "HqwyList",
  components: {
    ProductList,
    // DialogDrag,
    // Recommend,
    // vRefresh,
    VLoad,
    // vAbnor,
    BasicInfo,
    // ListTip,
    AuditPass,
    DefaultBlankPage,
  },
  // isRecommend 来源 1 贷款大全
  // props: ["isRecommend", "listParams", "isSubmit", "pageName"],
  props: {
    listParams: { type: Object, default: () => ({}) },
    pageName: { type: String, default: '' },
  },
  data () {
    return {
      listAdInfos: {}, // 贷款大全列表硬广位信息
      loadStyle: "",
      mescrollId: "hqwy-refresh" + Date.now(),
      mescroll: null,
      errorImg01: this.getCachedImages("productIcon"),
      allLoaded: false,
      // tipText: "据统计，申请5个以上产品，贷款成功率超过95%", //提示语句
      activedID: [], // 点击过的商品id
      topText: "",
      topStatus: "",
      bottomStatus: "",
      bottomText: "",
      lists: [],
      totalCount: 3, //总条数
      totalPage: 0, //总页码
      currPageNo: 0,
      pageSize: 10,
      type: "", //分类类别
      //loadimg: '../../../static/images/loading.png',
      nodata: false, //没有更多数据了,
      PagePara: {
        dataover: false, //检测所有数据是否加载完
        dataloading: false, //检测是否正在加载数据
      },
      codeData: {
        type: "", //分类类别
        tips: "", //提示条-推荐产品
        list: "", //产品列表
        todkdq: "", //进入贷款大全
        refresh: "", //下拉刷新
        tojztj: "", //右下角智能推荐icon
      },
      noclicked: {
        noClickedName: "",
        noClickedHref: "",
        noClickedId: "",
      },
      abnorData: {}, //异常数据
      prolistFormdata: {},
      isLoad: "none", //默认页面没有loading动画
      tipsFlag: false, //提示条状态标识 false标识用户还没有点击过任何一款产品
      userMobilePhone: "",
      getFlag: {
        history: false,
        clicked: false,
      },
      //refreshFlag: true, //下拉刷新flag 下拉刷新时不展示更多正在赶来
      // reloadText: {},
      showErrorPage: false,
      errorPageInfo: {},
      productIcon:
        this.getCachedImages("productIcon") ||
        require("APP_IMG/default.png"), //产品缩略占位图
      nameIdcardEditAll: false, // 姓名身份证号已填写标识
      hasAuditPass: false, // 是否已过审
    };
  },
  watch: {
    // isTipClick () {
    //   this.tipsClickFun();
    // },
    "listParams.filterStatus" (val) {
      //console.log('val:', val)
      this.prolistFormdata.sortType = val;
      this.resetUpScrollHandle();
    },
    // getFlag: {
    //   handler(val, oldVal) {
    //     if (this.getFlag.history == true && this.getFlag.clicked == true) {
    //       this.tipsTxtContent();
    //     }
    //   },
    //   deep: true
    // }
  },
  // beforeMount () {
  //   var self = this;
  // },
  created () {
    this.loadStyle = "";
    this.isLoad = "block"; //开始loading
  },
  destroyed () {
    // window.removeEventListener('scroll', this.InitLoadMore, true);
  },
  mounted () {
    // window.tipsGetFun = this.tipsGetFun;
    var self = this;
    window.toProductlist = self.toProductlist
    // 初始化 mescroll
    self.type = self.$route.query.category || "12";
    this.mescroll = new MeScroll(this.mescrollId, {
      down: {
        auto: false,
        callback: this.downCallback,
      },
      up: {
        auto: false,
        isBounce: false,
        noMoreSize: 0,
        callback: this.upCallback,
        htmlLoading: `<div id="databottom" class="data-bottom">
                    <div class="load">
                    </div>
                    <div class="text" id="bottomtext">更多产品正在赶来</div>
                  </div>`,
        htmlNodata: `<div class="no-data ${this.type != 12 ? "no-other" : ""}" >
                        <div class="no-datas">
                          <div class="no-datas-text">已经到底啦</div>
                        </div>
                        <div class="other-pro" onclick="toProductlist('${this
            .codeData.type +
          ";dkdq;w" +
          this.codeData.todkdq}')">${
          this.type != 12 ? "没有合适产品?立即进入<span>贷款大全></span>" : ""
          }</div>
                    </div>`,
      },
    });
    // 贷款大全
    // if(self.isRecommend==1){
    //   document.querySelector('.hqwy-main > .mescroll').onscroll = function(){
    //     console.log(this.scrollTop);
    //   }
    // }

    self.$refs.auditPass.init(true, () => {
      self.hasAuditPass = true
      self.$emit('update-auditSts', true)
      // 当页面是贷款大全的时候
      if (self.$route.query.category == undefined) {
        self.upCallback();
      }
    }, (rst, data) => {
      self.hasAuditPass = false
      self.$emit('update-auditSts', false)
      if (rst) {
        let length = 0
        if (data && data.body && data.body.productList) {
          length = data.body.productList.length
        }
        data = Object.assign({}, data, {
          body: {
            currPageNo: 1,
            pageSize: length,
            totalCount: length,
            page: data.body.productList,
          },
        })
        self.onRequestSucess(data)
      } else {
        self.onRequestError(data);
      }
    })
    // 获取姓名和身份证是否已填写
    eventCtr.$on("nameIdcardEditAll", (msg) => {
      this.nameIdcardEditAll = msg
    })
  },
  activated () {
    // window.topPreRecommend = this.topPreRecommend;
    // this.tipsGetFun(); //确定提示条文案
    this.initEventId(() => {
      if (this.$route.query.category != undefined) {
        this.downCallback(true);
        this.lists = [];
      }
    });
    this.showErrorPage = false
    // this.upCallback()
    // 当是分类列表页的时候
    // console.warn("----->" + this.$route.query.category != undefined);

    // 获取姓名身份证
    this.$refs.basicInfo.getBasicInfoFun()
  },
  deactivated () {
    // this.currPageNo = 0;
    // setTimeout(() => {
    //   this.lists = []
    // },500)
  },
  methods: {
    // 未过审产品点击
    noPassProductClick (obj, category, w, index) {
      this.needUserLogin(w, () => {
        localStorage.setItem('no-pass-product-extraMsg', JSON.stringify({ address: obj.address, ...obj.extraMsg }))
        this.$routerPush(`/productDetail/${category}/${obj.id}?pstatus=4&p=${index + 1}&w=${w}&supportJoinLogin=${obj.supportJoinLogin}&t=${obj.rank}`)
      })
    },
    initEventId (cb) {
      var self = this;
      self.type = self.listParams.category = self.$route.query.category || "12";
      //生成埋点数据
      if (self.type == 1) {
        self.codeData.type = "fl1";
        self.codeData.tips = "43";
        self.codeData.list = "45";
        self.codeData.todkdq = "46";
        self.codeData.refresh = "48";
      } else if (self.type == 2) {
        self.codeData.type = "fl2";
        self.codeData.tips = "50";
        self.codeData.list = "52";
        self.codeData.todkdq = "53";
        self.codeData.refresh = "55";
      } else if (self.type == 3) {
        self.codeData.type = "fl3";
        self.codeData.tips = "57";
        self.codeData.list = "59";
        self.codeData.todkdq = "60";
        self.codeData.refresh = "62";
      } else if (self.type == 4) {
        self.codeData.type = "fl4";
        self.codeData.tips = "162";
        self.codeData.list = "163";
        self.codeData.todkdq = "164";
        self.codeData.refresh = "166";
      } else if (self.type == 12) {
        self.codeData.type = "dkdq";
        self.codeData.tips = "77";
        self.codeData.list = "79";
        self.codeData.tojztj = "80";
        self.codeData.refresh = "81";
      } else if (self.type == 11) {
        self.codeData.type = "pmd";
        self.codeData.tips = "65";
        self.codeData.list = "67";
        self.codeData.todkdq = "68";
        self.codeData.refresh = "70";
      }

      //console.log(self.listParams.category)
      // if (self.type != 12) {
      //   domContainer = "hqwy-list";
      // } else {
      //   domContainer = "hqwy-list1";
      // }
      self.$nextTick(() => {
        cb && cb()
      })
    },
    downCallback (initFlag) {
      let self = this
      self.$refs.auditPass.init(true, () => {
        self.hasAuditPass = true
        self.downCallback1(initFlag)
      }, (rst, data) => {
        self.hasAuditPass = false
        if (rst) {
          let length = 0
          if (data && data.body && data.body.productList) {
            length = data.body.productList.length
          }
          data = Object.assign({}, data, {
            body: {
              currPageNo: 1,
              pageSize: length,
              totalCount: length,
              page: data.body.productList,
            },
          })
          self.onRequestSucess(data)
        } else {
          self.onRequestError(data);
        }
      })
    },
    downCallback1 (initFlag) {
      var self = this;
      let str = self.type == 12 ? "scrollTop" : "proListScrollTop";
      global.storage.set(str, 0);
      //document.getElementById('refreshDiv').style.visibility = 'visible';
      //松手之后执行逻辑,ajax请求数据，数据返回后隐藏加载中提示
      //self.refreshFlag = true;
      if (!initFlag) {
        self.codeFun(self.codeData.type + ";sx;w" + self.codeData.refresh);
      }
      self.currPageNo = 1;
      self.PagePara = {
        dataover: false, //检测所有数据是否加载完
        dataloading: true, //检测是否正在加载数据
      };
      // self.nodata = false;
      //							self.lists = [];
      //self.refreshFlag = false;
      // console.log('lists:', self.lists.length)
      if (self.lists.length >= self.pageSize) {
        self.mescroll.setPageNum(1);
      }
      self.getProListsHandle();
    },
    upCallback () {
      var self = this;
      self.PagePara.dataloading = true;
      self.currPageNo = self.currPageNo + 1;
      if (self.prolistFormdata.nextPage != undefined) {
        self.prolistFormdata.nextPage = self.currPageNo;
      } else {
        self.prolistFormdata.currPageNo = self.currPageNo;
      }
      self.getProListsHandle(true);
    },
    getParamsHandle (flag) {
      var self = this;
      if (self.listParams.filterStatus != undefined) {
        self.prolistFormdata = {
          amount: self.listParams.filterMoney,
          tagValue: self.listParams.filterLabel,
          deadLine: self.listParams.filterYear,
          sortType: self.listParams.filterStatus,
          nextPage: flag ? self.currPageNo : self.listParams.currPageNo,
        };
        self.type = self.listParams.category;
      } else {
        self.prolistFormdata = {
          category: self.type,
          currPageNo: self.currPageNo,
        };
      }
      // self.currPageNo = self.listParams.currPageNo;
    },
    resetUpScrollHandle () {
      this.loadStyle = "z-index:1";
      this.isLoad = "block";
      this.currPageNo = 0;
      this.lists = [];
      this.mescroll.resetUpScroll();
    },
    onRequestSucess (rst, flag) {
      var self = this;
      self.isLoad = "none";
      self.PagePara.dataloading = false;
      // 广告位信息
      if (rst.respCode === '1000' && rst.body) {
        // rst.body.topAdvertisement = { img: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201809/e835da992043c469d8628f2a2b7d4627.png' }
        // rst.body.listAdvertisement = { index: 12, img: 'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201809/e835da992043c469d8628f2a2b7d4627.png' }
        // if (rst.body.topAdvertisement) {
        //   self.$emit('ad-loaded', rst.body.topAdvertisement)
        // }
        // if (rst.body.listAdvertisement) {
        //   self.listAdInfos = rst.body.listAdvertisement
        // }
        self.$emit('ad-loaded', rst.body.topAdvertisement || {})
        self.listAdInfos = rst.body.listAdvertisement || {}
      }
      if (rst.respCode === "1000" && rst.body.page.length > 0) {
        self.$nextTick(() => {
          self.$forceUpdate();
        });
        self.showErrorPage = false;
        self.totalCount = rst.body.totalCount;
        self.pageSize = rst.body.pageSize;
        if (self.type == 12 && self.currPageNo == 1) {
          self.$emit("to-totalCount", self.totalCount); //传递数据出去
        }
        self.totalPage = Math.ceil(rst.body.totalCount / rst.body.pageSize);

        if (flag) {
          self.lists = self.lists.concat(self.formateProductList(rst.body.page));
        } else {
          // self.lists = rst.body.page;
          self.$set(self, "lists", self.formateProductList(rst.body.page));
        }

        //self.loadimg = '../../../static/images/loding.gif';
        if (
          rst.body.page.length < rst.body.pageSize &&
          self.currPageNo === 1 &&
          self.type != 12
        ) {
          self.nodata = true;
        } else {
          self.nodata = false;
        }
        //是否有下一页
        var hasNext = self.lists.length < self.totalCount;
        if (!flag) {
          setTimeout(() => {
            if (hasNext) {
              self.mescroll.endSuccess(rst.body.pageSize, hasNext);
            } else {
              self.mescroll.endSuccess(rst.body.pageSize, false);
            }
          }, 500);
        } else {
          if (hasNext) {
            self.mescroll.endSuccess(rst.body.pageSize, hasNext);
          } else {
            self.mescroll.endSuccess(rst.body.pageSize, false);
          }
        }
        /*setTimeout(function() {
          self.refreshFlag = true;
        }, 0)*/
      } else {
        self.nodata = false;
        self.mescroll.endSuccess(rst.body.pageSize, false);
        if (self.currPageNo < 2) {
          // self.showErrorPage = true;
          // self.reloadText = {
          //   reloadText: "暂无数据",
          //   defaultImg: this.getCachedImages("productIcon")
          // };
          self.initDefaultErrorPageInfos('noData')
          /*self.abnorData = {
            "reloadText": {
              "reloadText": "暂无数据",
              "defaultImg": "../../../static/images/nodata.png",
            },
            "showErrorPage": true
          };*/
          //self.$emit('to-abnor', self.abnorData); //传递数据出去
        } else {
          self.currPageNo = self.currPageNo - 1;
        }
      }
    },
    onRequestError () {
      var self = this;
      self.nodata = false;
      self.mescroll.endErr();
      self.isLoad = "none";
      if (self.currPageNo < 2) {
        // self.showErrorPage = true;
        // self.reloadText = {
        //   reloadText: "网络异常",
        //   defaultImg: this.getCachedImages("loadFailIcon")
        // };
        self.initDefaultErrorPageInfos('offline')
        //self.$emit('to-abnor', self.abnorData); //传递数据出去
      } else {
        self.currPageNo = self.currPageNo - 1;
      }
    },
    // 获取分类列表
    getProListsHandle (flag) {
      //flag 为true标识下拉加载
      var self = this;
      self.getParamsHandle(flag);
      if (self.currPageNo === 1) {
        self.isLoad = 'block'
      }
      if (self.listParams.url === "/api/product/filterV2") {
        requestProductFilter(self.prolistFormdata).then(
          (data) => {
            self.onRequestSucess(data, flag);
          },
          (err) => {
            if (self.currPageNo === 1) {
              self.isLoad = 'none'
            }
            self.onRequestError(err);
          }
        );
      } else {
        requestCategory(self.prolistFormdata).then(
          (data) => {
            if (self.currPageNo === 1) {
              self.isLoad = 'none'
            }
            self.onRequestSucess(data, flag);
          },
          (err) => {
            if (self.currPageNo === 1) {
              self.isLoad = 'none'
            }
            self.onRequestError(err);
          }
        );
      }
    },
    onProductClick (item, index) {
      if (!this.hasAuditPass) {
        this.noPassProductClick(item, 12, 36, index)
        return
      }
      this.proListClick(item.name, item.address, item.id, this.codeData.list, (index + 1), item.type, true, this.listParams.category, item.linkSeqId, item)
    },
    // 硬广位点击
    onAdClick (item, position) {
      let that = this
      let category, w // 分类及埋点相关数据
      if (position === 'list') {
        // 列表硬广位
        category = 27
        w = 322
      } else if (position === 'top') {
        // 底部硬广位
        category = 26
        w = 320
      }
      if (item.clickType == '2') {
        // 跳转指定链接
        that.needUserLogin(w + 1, () => {
          let eventId = `zdlj;w${w + 1};p0;l${item.linkAddressId}`
          that.$appInvoked('appExecStatistic', { eventId: eventId });
          // that.clickReport(item.id, category, eventId);
          that.collectEventMD({
            eventId: eventId,
            eventResult: 1,
            eventStartTime: new Date().getTime(),
          })
          that.jrcsOpenAppPage(w + 1, item.linkAddress, item.mainTitle)
        })
      } else {
        that.proListClick(item.name, item.address, item.id, w, 0, item.type, false, category, item.linkSeqId, item)
      }
    },
    // 点击产品列表
    proListClick (name, url, id, w, p, goFlag, needBack, category, linkSeqId, proItem) {
      let that = this
      that.needUserLogin(w, () => {
        let type = null
        if (category) {
          type = category;
        } else {
          type = 12;
        }
        // 是否支持api
        if (proItem.supportApiLoan) {
          let tourl = `?category=${type}&productId=${id}&productName=${name}&p=${p}&w=${w}&supportJoinLogin=${proItem.supportJoinLogin}&t=${proItem.rank}`
          let eventId = `chanpin0;w${w};p${p};c${id};l${window.$config.get('events.linkSeqId')};t${proItem.rank}`;
          that.clickReport(id, type, eventId);
          that.$appInvoked("appExecStatistic", {
            eventId: eventId,
            eventType: 2,
          }); //添加埋点
          // 姓名和身份证号是否已填写
          if (!that.nameIdcardEditAll) {
            that.$refs.basicInfo.getBasicInfoFun((nameIdcardEditAll) => {
              if (nameIdcardEditAll) {
                // 已填写 去撞库
                that.$routerPush('/loanHit' + tourl)
              } else {
                // 未填写去基本信息补充页
                that.$routerPush('/basicInfo' + tourl)
              }
            })
          } else {
            // 已填写 去撞库
            that.$routerPush('/loanHit' + tourl)
          }
        } else {
          that.clickFun(name, url, id, w, p, goFlag, needBack, type, linkSeqId, proItem)
        }
      })
    },
    //列表点击事件
    clickFun (name, url, id, w, p, goFlag, needBack, category, linkSeqId, proItem) {
      var self = this;

      self.getFlag.history = false;
      self.getFlag.clicked = false;
      category = category || 12

      // chanpin0进入产品详情页，chanpin1进入H5落地页，chanpin2阻止用户申请
      let eventId = `chanpin0;w${w};p${p};c${id};l${linkSeqId};t${proItem.rank}`;
      if (goFlag == 2) { // 0-产品详情，2-第三方注册页
        eventId = `chanpin1;w${w};p${p};c${id};l${linkSeqId};t${proItem.rank}`;
        let supportJoinLogin = proItem.supportJoinLogin; // 是否支持联登
        if (supportJoinLogin) { // 支持联合登录
          self.isLoad = 'block';
          let params = {
            linkId: linkSeqId,
            productId: id,
          };
          requestJoinLogin(params).then((data) => {
            self.isLoad = 'none';
            if (data.respCode == '1000') {
              data = data.body;
              let regStatus = data.regStatus;
              // 0-未知 1-注册失败 2-金融超市注册成功 3-失败：其他渠道已有用户
              if (regStatus == 2) {
                self.openThirdRegisterPage(name, url, id, w, p, category, linkSeqId, proItem.rank, 0)
              } else if (regStatus == 3) {
                utils.toastMsg(`您已注册过${name}，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${id};l${linkSeqId};t${proItem.rank}`;
                self.clickReport(id, category, eventId);
              } else {
                utils.toastMsg(`${name}系统维护中，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${id};l${linkSeqId};t${proItem.rank}`;
                self.clickReport(id, category, eventId);
              }
            } else {
              utils.toastMsg(`${name}系统维护中，请申请其他产品`);
              eventId = `chanpin2;w${w};p${p};c${id};l${linkSeqId};t${proItem.rank}`;
              self.clickReport(id, category, eventId);
            }
            self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
          }, () => {
            self.isLoad = 'none';
          });
        } else {
          // type = 1;
          // 打开第三方注册页
          self.openThirdRegisterPage(name, url, id, w, p, category, linkSeqId, proItem.rank, 0)
          self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
        }
      } else {
        self.clickReport(id, category, eventId);
        self.$routerPush(
          "/productDetail/" +
          category +
          "/" +
          id +
          "?p=" +
          p +
          "&w=" +
          w +
          "&supportJoinLogin=" +
          proItem.supportJoinLogin + '&t=' + proItem.rank
        );
        self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
      }

      self.$appInvoked("appOnPageEnd", { pageName: self.pageName });
      window.currentPageName = self.pageName;
    },
    //添加埋点
    codeFun (eventid) {
      this.$appInvoked("appExecStatistic", {
        eventId: eventid,
        eventType: 0,
      });
    },
    //去贷款大全页面
    toProductlist (eventid) {
      var self = this;
      self.$appInvoked("appExecStatistic", {
        eventId: eventid,
        eventType: 0,
      }); //添加埋点
      self.$routerPush("/productlist");
    },
    //给app提供一个方法
    // topPreRecommend (w) {
    //   this.globalRecommendClick(w)
    // }
  },
};
</script>
<style lang="scss">
// .hqwy-spinner-loading .mint-spinner-fading-circle {
//   display: inline-block;
//   vertical-align: middle;
// }

#databottom {
  margin-top: rc(21);
  margin-bottom: rc(26);
  font-size: rc(24);
  color: #777;
  text-align: center;
  .load {
    display: inline-block;
    vertical-align: top;
    width: rc(34);
    height: rc(34);
    background: url(../../../static/images/loding.gif) no-repeat 0 0;
    background-size: contain;
  }
  .text {
    display: inline-block;
  }
}

.no-data {
  margin-top: rc(30);
  font-size: rc(24);
  color: #777777;
  text-align: center;
  height: rc(96);
  .no-datas {
    height: rc(33);
    width: 50%;
    margin-left: 25%;
    border-bottom: 1px solid #979797;
    position: relative;
    /*line-height:rc(33);*/
    .no-datas-text {
      width: 40%;
      margin-left: 30%;
      background: #f6f6f6;
      position: absolute;
      top: rc(16);
    }
  }
  .other-pro {
    margin-top: rc(30);
    span {
      color: #ff601a;
    }
  }
}

.no-data.no-other {
  margin-bottom: rc(30);
  padding-bottom: rc(80);
}
</style>

<style lang="scss" scoped="scoped">
// .flex,
// .hqwy-right-top {
//   display: flex;
//   display: -webkit-flex;
// }

// .flex1,
// .hqwy-right {
//   flex: 1;
//   -webkit-flex: 1;
// }

// .hqwy-right {
//   padding-left: rc(20);
// }

/*.hqwy-right {*/
/*overflow: auto;*/
/*}*/

// .hqwy-right-bottom,
// .hqwy-right-center {
//   margin-top: rc(15);
//   color: #bbbbbb;
//   line-height: rc(30);
// }

// .hqwy-right-center {
//   margin-top: rc(20);
//   color: #999999;
//   font-size: rc(24);
//   line-height: rc(33);
// }

// .hqwy-right-center i {
//   font-style: normal; //margin-left: rc(10);
// }

// .hqwy-right-bottom {
//   white-space: nowrap;
//   text-overflow: ellipsis;
//   overflow: hidden;
// }

// .hqwy-right-bottom span {
//   display: inline-block;
//   font-size: rc(24);
//   // transform: scaleY(0.917);
// }

// .hqwy-left {
//   width: rc(100);
//   height: rc(100);
//   //border: 1px solid #e5e5e5;
//   border-radius: rc(12);
// }

// .hqwy-left img {
//   display: block;
//   width: 100%;
//   height: 100%;
//   border-radius: rc(12);
// }

// .hqwy-items {
//   background-color: #ffffff;
//   padding-left: rc(30);
//   li {
//     padding-right: rc(30);
//     &.bb-1px:last-child::after {
//       border-bottom: 0;
//     }
//   }
// }

// .hqwy-items li a {
//   display: block;
//   padding: rc(32) 0 rc(30);
//   color: #333333;
// }

// .hqwy-items li a h2 {
//   color: #111111;
// }

// .hqwy-tip {
//   background-color: #f2f2f2;
//   z-index: 2;
//   position: fixed;
//   width: 100%;
//   top: rc(82);
//   text-align: left;
//   font-size: rc(24);
//   line-height: rc(60);
//   color: #999999;
//   padding-left: rc(30);
// }

// .hqwy-tip-top0 {
//   top: 0;
// }

// .hqwy-tip a {
//   color: $color-main;
// }

// .hqwy-pass-rate {
//   background-color: #f53331;
//   margin-right: rc(10);
//   /*background-color: #ff4c4c;
//           color: #ffffff;
//           display: inline-block;
//           padding: rc(2) rc(8);
//           border-radius: rc(4);
//           font-size: rc(20);
//           line-height: 1;*/
// }

// .hqwy-right-top h2 {
//   font-weight: bold;
// }

// .hqwy-right-top p {
//   color: #ff601a;
//   font-size: rc(34);
//   font-weight: bold;
// }

// .mint-loadmore .rotate {
//   display: inline-block;
//   transition: transform 0.3s ease-in;
// }

// .mint-loadmore .rotate.active {
//   transform: rotate(180deg);
// }

// .hqwy-pass-rate {
//   /*margin-right: rc(10);*/
//   padding: rc(2) rc(8);
//   border-radius: rc(4);
//   color: #ffffff;
//   font-size: rc(24);
//   transform: scaleY(0.8);
// }

// .hqwy-splite-line {
//   margin-left: rc(10);
//   margin-right: rc(10);
//   color: #e6e6e6;
// }

// .hqwy-arrow {
//   position: relative;
//   width: rc(15);
// }

// .hqwy-arrow img {
//   position: absolute;
//   display: block;
//   width: 100%;
//   top: 50%;
//   margin-top: rc(-13);
//   // margin-top: rc(66);
// }

// .hqwy-tip-icon {
//   display: inline-block;
//   width: rc(32);
//   height: rc(32);
//   background: url(../../../static/images/public_horn_03.png) 0 0 no-repeat;
//   background-size: contain;
//   vertical-align: text-bottom;
//   margin-right: 5px;
// }

// .hqwy-list,
// .hqwy-list1 {
//   //overflow-y: scroll;
// }

/* #refreshDiv{
          margin-top: rc(60);
      } */

// .hqwy-tip-top2 {
//   /*padding-top: rc(60);*/
// }
</style>
