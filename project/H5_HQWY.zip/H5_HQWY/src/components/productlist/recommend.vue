<template>
  <div class="hqwy-recommend"
       @click="getdk()">
    <a class="hqwy-recommend-a"></a>
    <span class="hqwy-text">智能推荐</span>
    <span v-if="num > 0"
          class="total-num"><i>{{ num }}</i></span>
  </div>
</template>
<script type="text/javascript">
// import eventCtr from "../../../static/js/eventCtr";

export default {
  data () {
    return {
      // totalNum: 8,
      num: 0,
    };
  },
  computed: {
    // num: function() {
    //   console.warn('----1我要试试看'+localStorage.getItem('redPoint'))
    //   var redPointArr = "";
    //   if (localStorage.getItem("redPoint") != null) {
    //     console.warn('----我要试试看'+localStorage.getItem('redPoint'))
    //     redPointArr = localStorage.getItem("redPoint");
    //   }
    //   return this.totalNum - (redPointArr.split(",").length - 1);
    // }
  },
  mounted () {
    this.getRedDotNum()
  },
  activated () {
    this.getRedDotNum()
    // //先获取总的小红点个数
    // this.totalNum = localStorage.getItem("redPointAll");
    // var redPointArr = "";
    // // console.log("------>" + localStorage.getItem("redPoint"));
    // if (
    //   localStorage.getItem("redPoint") != null &&
    //   localStorage.getItem("redPoint") != -1
    // ) {
    //   redPointArr = localStorage.getItem("redPoint");
    //   this.num = this.totalNum - (redPointArr.split(",").length - 1);
    // } else {
    //   this.num = 0;
    // }
  },
  methods: {
    // 获取小红点数量
    getRedDotNum () {

      let newArr = JSON.parse(localStorage.getItem("RED_DOT_DATA") || '[]')
      let num = 0
      for (let i = 0; i < newArr.length; i++) {
        if (!newArr[i].check) {
          num++
        }
      }
      this.num = num
    },
    getdk () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'dkdq;jztj;w80',
        eventType: 0,
      }) //添加埋点
      this.globalRecommendClick(80)
    },
  },
};
</script>
<style lang="scss" scoped="scoped">
.hqwy-recommend {
  width: rc(120);
  height: rc(120);
  color: #333333;
  display: flex;
  line-height: normal;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  position: relative;
  .hqwy-text {
    font-size: rc(20);
  }
  .total-num i {
    font-size: rc(24);
  }
}
.hqwy-recommend .hqwy-recommend-a {
  display: block;
  width: rc(48);
  height: rc(48);
  background: url('../../../static/images/global_iocn_setup1.png') 0 0 no-repeat;
  background-size: contain;
}
.total-num {
  // width: rc(36);
  // height: rc(36);
  width: 18px;
  height: 18px;
  border-radius: 50%;
  color: #ffffff;
  // text-align: center;
  // line-height: rc(36);
  line-height: normal;
  background: #f53332;
  position: absolute;
  top: 0;
  right: rc(-10);
  display: flex;
  align-items: center;
  justify-content: center;
  i {
    font-weight: bold;
  }
}

.hqwy-recommend .hqwy-recommend-a i {
  color: #ffffff;
  //display: inline-block;
  font-size: rc(16);
  font-weight: normal;
  font-style: normal;
  //transform: scale(0.5);
}
</style>
