<template>
  <div>
    <ProductList :list="list"
                 @on-click="onProductClick"></ProductList>
    <BasicInfo ref="basicInfo"></BasicInfo>
    <VLoad :isload="isLoad"></VLoad>
  </div>
</template>
<script>
import ProductList from '@/components/product/ProductList'
import utils from '../../util/utils';
// import listTip from "../tip/listTip"
import BasicInfo from "../basicInfo/index"
import eventCtr from "../../../static/js/eventCtr"
import { requestJoinLogin } from "../../api/controller/product";
import VLoad from "../load.vue";
/* eslint-disable eqeqeq */
export default {
  name: 'ProductList',
  components: {
    ProductList,
    // listTip,
    BasicInfo,
    VLoad,
  },
  props: {
    list: {
      type: Array,
      default: () => [],
    },
    pstatus: {
      type: [String, Number],
      default: '',
    },
    category: {
      type: [String, Number],
      default: '',
    },
  },
  data () {
    return {
      productIcon: this.getCachedImages("productIcon") || require("APP_IMG/default.png"), //产品缩略占位图
      nameIdcardEditAll: false, // 姓名身份证号已填写标识
      isLoad: "none", //默认页面没有loading动画,
    };
  },
  computed: {
    w () {
      let pstatus = this.pstatus;
      // 175-资质不符，176-出错啦
      if (pstatus == 2) {
        return '175';
      } else if (pstatus == 3) {
        return '176';
      }
      return ''
    },
  },
  mounted () {
    // 获取姓名和身份证是否已填写
    eventCtr.$on("nameIdcardEditAll", (msg) => {
      this.nameIdcardEditAll = msg
    })
  },
  activated () {
    // window.topPreRecommend = this.topPreRecommend;
    // 获取姓名身份证
    this.$refs.basicInfo.getBasicInfoFun()
  },
  methods: {
    onProductClick (item, index) {
      this.proListClick(item.name, item.address, item.id, this.w, index + 1, item.type, true, item.linkSeqId, item)
    },
    // 点击产品列表
    //列表点击事件
    proListClick (name, url, id, w, p, goFlag, needBack, linkSeqId, proItem) {
      let that = this
      that.needUserLogin(w, () => {
        // 是否支持api
        if (proItem.supportApiLoan) {
          let tourl = `?category=${that.category}&productId=${id}&productName=${name}&p=${p}&w=${w}&supportJoinLogin=${proItem.supportJoinLogin}&t=${proItem.rank}`
          let eventId = `chanpin0;w${w};p${p};c${id};l${window.$config.get('events.linkSeqId')};t${proItem.rank}`;
          that.clickReport(id, that.category, eventId);
          that.$appInvoked("appExecStatistic", {
            eventId: eventId,
            eventType: 2,
          }); //添加埋点
          // 姓名和身份证号是否已填写
          if (!that.nameIdcardEditAll) {
            that.$refs.basicInfo.getBasicInfoFun((nameIdcardEditAll) => {
              if (nameIdcardEditAll) {
                // 已填写 去撞库
                that.$routerPush('/loanHit' + tourl)
              } else {
                // 未填写去基本信息补充页
                that.$routerPush('/basicInfo' + tourl)
              }
            })
          } else {
            // 已填写 去撞库
            that.$routerPush('/loanHit' + tourl)
          }
        } else {
          that.clickFun(name, url, id, w, p, goFlag, needBack, linkSeqId, proItem)
        }
      })
    },
    clickFun (name, url, id, w, p, goFlag, needBack, linkSeqId, proItem) {
      var self = this;
      let category = self.category;

      // chanpin0进入产品详情页，chanpin1进入H5落地页，chanpin2阻止用户申请
      let eventId = `chanpin0;w${w};p${p};c${id};l${linkSeqId};t${proItem.rank}`;
      if (goFlag == 2) { // 0-产品详情，2-第三方注册页
        eventId = `chanpin1;w${w};p${p};c${id};l${linkSeqId};t${proItem.rank}`;
        let supportJoinLogin = proItem.supportJoinLogin; // 是否支持联登
        if (supportJoinLogin) { // 支持联合登录
          self.isLoad = 'block';
          let params = {
            linkId: linkSeqId,
            productId: id,
          };
          requestJoinLogin(params).then((data) => {
            self.isLoad = 'none';
            if (data.respCode == '1000') {
              data = data.body;
              let regStatus = data.regStatus;
              // 0-未知 1-注册失败 2-金融超市注册成功 3-失败：其他渠道已有用户
              if (regStatus == 2) {
                self.openThirdRegisterPage(name, url, id, w, p, category, linkSeqId, proItem.rank, 0)
              } else if (regStatus == 3) {
                utils.toastMsg(`您已注册过${name}，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${id};l${linkSeqId};t${proItem.rank}`;
                self.clickReport(id, category, eventId);
              } else {
                utils.toastMsg(`${name}系统维护中，请申请其他产品`);
                eventId = `chanpin2;w${w};p${p};c${id};l${linkSeqId};t${proItem.rank}`;
                self.clickReport(id, category, eventId);
              }
            } else {
              utils.toastMsg(`${name}系统维护中，请申请其他产品`);
              eventId = `chanpin2;w${w};p${p};c${id};l${linkSeqId};t${proItem.rank}`;
              self.clickReport(id, category, eventId);
            }
            self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
          }, () => {
            self.isLoad = 'none';
          });
        } else {
          // type = 1;
          // 打开第三方注册页
          self.openThirdRegisterPage(name, url, id, w, p, category, linkSeqId, proItem.rank, 0)
          self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
        }
      } else {
        self.clickReport(id, category, eventId);
        self.$routerPush(
          '/productDetailBlank/' +
          category +
          '/' +
          id +
          '?p=' +
          p +
          '&w=' +
          w +
          '&supportJoinLogin=' +
          proItem.supportJoinLogin + '&t=' + proItem.rank
        );
        self.$appInvoked("appExecStatistic", { eventId: eventId, eventType: 2 }); //添加埋点
      }
    },
    //给app提供一个方法
    // topPreRecommend () {
    //   this.globalRecommendClick()
    // }
  },
};
</script>
<style lang="scss" scoped="scoped">
.flex,
.hqwy-right-top {
  display: flex;
  display: -webkit-flex;
}

.flex1,
.hqwy-right {
  flex: 1;
  -webkit-flex: 1;
}

.hqwy-right {
  padding-left: rc(20);
}

/*.hqwy-right {*/
/*overflow: auto;*/
/*}*/

.hqwy-right-bottom,
.hqwy-right-center {
  margin-top: rc(15);
  color: #bbbbbb;
  line-height: rc(30);
}

.hqwy-right-center {
  margin-top: rc(20);
  color: #999999;
  font-size: rc(24);
  line-height: rc(33);
}

.hqwy-right-center i {
  font-style: normal; //margin-left: rc(10);
}

.hqwy-right-bottom {
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}

.hqwy-right-bottom span {
  display: inline-block;
  font-size: rc(24);
  // transform: scaleY(0.917);
}

.hqwy-left {
  width: rc(100);
  height: rc(100);
  //border: 1px solid #e5e5e5;
  border-radius: rc(12);
}

.hqwy-left img {
  display: block;
  width: 100%;
  height: 100%;
  border-radius: rc(12);
}

.hqwy-items li {
  background-color: #ffffff;
  padding-left: rc(30);
  padding-right: rc(30);
}

.hqwy-items li a {
  display: block;
  padding: rc(32) 0 rc(30);
  color: #333333;
  border-bottom: 1px solid #e6e6e6;
}
.hqwy-items li:last-child a {
  border-bottom: none;
}

.hqwy-items li a h2 {
  color: #111111;
}

.hqwy-tip {
  background-color: #f2f2f2;
  z-index: 2;
  position: fixed;
  width: 100%;
  top: rc(82);
  text-align: left;
  font-size: rc(24);
  line-height: rc(60);
  color: #999999;
  padding-left: rc(30);
}

.hqwy-tip-top0 {
  top: 0;
}

.hqwy-tip a {
  color: #ff601a;
}

.hqwy-pass-rate {
  background-color: #f53331;
  margin-right: rc(10);
}

.hqwy-right-top h2 {
  font-weight: bold;
}

.hqwy-right-top p {
  color: #ff601a;
  font-size: rc(34);
  font-weight: bold;
}

.mint-loadmore .rotate {
  display: inline-block;
  transition: transform 0.3s ease-in;
}

.mint-loadmore .rotate.active {
  transform: rotate(180deg);
}

.hqwy-pass-rate {
  /*margin-right: rc(10);*/
  padding: rc(2) rc(8);
  border-radius: rc(4);
  color: #ffffff;
  font-size: rc(24);
  transform: scaleY(0.8);
}

.hqwy-splite-line {
  margin-left: rc(10);
  margin-right: rc(10);
  color: #e6e6e6;
}

.hqwy-arrow {
  width: rc(14);
}

.hqwy-arrow img {
  display: block;
  width: 100%;
  margin-top: rc(66);
}

.hqwy-tip-icon {
  display: inline-block;
  width: rc(32);
  height: rc(32);
  background: url(../../../static/images/public_horn_03.png) 0 0 no-repeat;
  background-size: contain;
  vertical-align: text-bottom;
  margin-right: 5px;
}
</style>
<style lang="scss">
.hqwy-spinner-loading .mint-spinner-fading-circle {
  display: inline-block;
  vertical-align: middle;
}

#databottom {
  margin-top: rc(21);
  margin-bottom: rc(26);
  font-size: rc(24);
  color: #777;
  text-align: center;
  .load {
    display: inline-block;
    vertical-align: top;
    width: rc(34);
    height: rc(34);
    background: url(../../../static/images/loding.gif) no-repeat 0 0;
    background-size: contain;
  }
  .text {
    display: inline-block;
  }
}

.no-data {
  margin-top: rc(30);
  font-size: rc(24);
  color: #777777;
  text-align: center;
  height: rc(96);
  .no-datas {
    height: rc(33);
    width: 50%;
    margin-left: 25%;
    border-bottom: 1px solid #979797;
    position: relative;
    /*line-height:rc(33);*/
    .no-datas-text {
      width: 40%;
      margin-left: 30%;
      background: #f6f6f6;
      position: absolute;
      top: rc(16);
    }
  }
  .other-pro {
    margin-top: rc(30);
    span {
      color: $color-main;
    }
  }
}

.no-data.no-other {
  margin-bottom: rc(30);
  padding-bottom: rc(80);
}
</style>
