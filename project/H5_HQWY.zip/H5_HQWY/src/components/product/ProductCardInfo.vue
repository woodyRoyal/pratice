<template>
  <HeadInfo :type="type"
            :icon="icon"
            :name="name"
            :tips="tips">
    <div slot="title"
         class="product-top-info">
      <div class="product-title">
        {{ name }}
      </div>
      <HyLabel v-for="(p, index) in label"
               :key="index"
               :title="p.tagName"
               :color="p.tagColor"></HyLabel>
    </div>
    <slot></slot>
  </HeadInfo>
</template>
<script>
import HeadInfo from '@/components/card/headInfo'
import HyLabel from '@/components/HyLabel'
export default {
  name: 'ProductCardInfo',
  components: {
    HeadInfo,
    HyLabel,
  },
  props: {
    type: {
      type: String,
      default: '',
    },
    icon: {
      type: String,
      default: '',
    },
    name: {
      type: [String, Number],
      default: '',
    },
    tips: {
      type: [String, Number],
      default: '',
    },
    label: {
      type: Array,
      default: () => [],
    },
  },
}
</script>
<style lang="scss" scoped>
.product-top-info {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  .product-title {
    font-weight: bold;
    line-height: normal;
  }
}
</style>


