<template>
  <!-- 通用产品列表 -->
  <div v-if="list && list.length > 0"
       class="common-product">
    <!-- 产品列表项 -->
    <div v-for="(p, index) in list"
         :key="index"
         class="common-item">
      <!-- 插入广告位信息 -->
      <div v-if="!isEmptyObject(adInfos) && (index === adPositionIdx)"
           class="ad-position"
           @click="onAdClick(adInfos)">
        <img :src="adInfos.img"
             alt="ad"
             class="ad-img">
        <!-- <img class="ad-img"
             v-lazy="{src:'http://img.huaqianwy.com/wfree_upload/mc/sys/img/201809/e835da992043c469d8628f2a2b7d4627.png',error:bannerIcon,loading:bannerIcon}"
             alt="ad"> -->
      </div>
      <!-- 产品内容信息 -->
      <div class="product-content"
           :class="{
             'product-full-apply': p.fm_applyTipsType === 1, // 名额已满
             'product-undercarriage': p.useStatus === 0, // 已下架
             'bb-1px': index !== adPositionIdx - 1, // 硬广位前一条不展示底边线
             'product-black': p.blackListFlag, // 黑名单
           }"
           @click.stop="onProductClick(p, index)">
        <!-- 产品信息：顶部 -->
        <div class="product-infos dfaic"
             :class="{'red-dot': p.fm_showRedDot}">
          <!-- LOGO -->
          <img :key="p.logo"
               v-lazy="{src:p.logo,error:productIcon,loading:productIcon}"
               class="product-logo">
          <!-- 名称 -->
          <div class="product-name"
               v-text="p.name"></div>
          <!-- 标签 -->
          <HyLabel v-for="(tag, tagIndex) in p.tagInfos"
                   :key="tagIndex"
                   :title="tag.tagName"
                   :color="tag.tagColor"></HyLabel>
        </div>
        <!-- 产品信息：中部 -->
        <div v-if="p.useStatus !== 0"
             key="middleInfos"
             class="product-middle">
          <!-- 额度、期限、利率 -->
          <div class="flex-1">
            <!-- 额度 -->
            <div class="product-limit">
              &yen;{{ p.limit | delUnit }}
            </div>
            <div class="dfaic">
              <!-- 利率 -->
              <div v-if="p.rate"
                   class="product-rate">
                <span class="color-tips"
                      v-text="p.rate.split(':')[0]"></span>
                <span v-text="p.rate.split(':')[1]"></span>
              </div>
              <!-- 期限 -->
              <div v-if="p.duration"
                   class="product-duration">
                <span class="color-tips">期限</span>
                <span v-text="p.duration"></span>
              </div>
            </div>
          </div>
          <!-- 名额、按钮 -->
          <div>
            <div class="product-btn jrcs-btn"
                 v-text="p.blackListFlag?'无法申请':p.fm_applyTipsType===1?'名额已满':(p.supportApiLoan?'一键申请':'立即申请')"></div>
            <div v-cloak
                 v-if="p.rate || p.duration"
                 class="product-apply-no">
              {{ p.fm_applyTipsType === 0 ? '已申请' + (p.applyCount || '1%') : p.fm_applyTipsType === 1 ? '明日开放申请' : (p.applyCount || 0) + '已申请' }}
            </div>
            <div v-if="p.fm_applyTipsType === 0"
                 class="product-apply-progress">
              <div :style="{width: (p.applyCount || '1%')}"></div>
            </div>
          </div>
        </div>
        <!-- 补充描述模块 -->
        <div v-if="p.useStatus !== 0 && (p.supportApiLoan || p.bottomTip)"
             key="descInfos"
             class="product-desc dfaic">
          <i :class="'desc-icon icon-' + p.fm_tipsIcon"></i>
          <div v-if="p.supportApiLoan"
               class="tips-mxz"
               :class="p.bottomTip ? 'has-prompt' : ''">
            免下载APP
          </div>
          <div class="tips-tip"
               v-text="p.bottomTip"></div>
        </div>
        <!-- 已下架产品展示信息 -->
        <div v-if="p.useStatus === 0">
          <div class="undercarriage-tips">
            如有任何产品问题，请联系官方客服
          </div>
          <div class="undercarriage-phone"
               v-text="(p.customPhoneType === 0 ? '客服电话：' : '') + p.customPhone"></div>
          <div v-if="p.customPhoneType === 0"
               class="undercarriage-btn jrcs-btn">
            立即拨打
          </div>
          <img class="undercarriage-icon"
               src="../../../static/images/list_img_soldout.png"
               alt="已下架">
        </div>
        <!-- 已下架产品配置客服电话 -->
        <a v-if="p.useStatus === 0 && p.customPhoneType === 0"
           class="custom-phone-call"
           :href="'tel:' + p.customPhone"></a>
      </div>
    </div>
  </div>
</template>
<script>
import HyLabel from '@/components/HyLabel'
export default {
  name: "ProductList",
  components: {
    HyLabel,
  },
  filters: {
    // 名额文言
  },
  props: {
    // 产品列表。传入时需先调用全局formateProductList方法格式化
    list: {
      type: Array,
      default: () => [],
    },
    // 硬广位信息
    adInfos: {
      type: Object,
      default: () => ({}),
    },
    // 广告位列表
    // adList: {
    //   type: Array,
    //   default: () => []
    // }
  },
  data () {
    return {
      // 默认产品图片
      productIcon:
        this.getCachedImages("productIcon") ||
        require("APP_IMG/default.png"),
      // 默认banner图片
      bannerIcon:
        require("APP_IMG/banner.png"),
    }
  },
  computed: {
    adPositionIdx () {
      return this.adInfos.index - 1
    },
  },
  methods: {
    // 硬广位点击
    onAdClick (item) {
      this.$emit('ad-click', item, 'list')
    },
    // 产品点击
    onProductClick (item, index) {
      // 已下架
      if (item.useStatus === 0) {
        // 立即拨打埋点
        if (item.customPhoneType === 0) {
          this.$appInvoked('appExecStatistic', {
            eventId: 'wd;lljl;ljbd;w277',
          })
        }
        return
      }
      // 黑名单
      if (item.blackListFlag) {
        this.toast('您不符合借款要求，您可选择其他产品。')
        return
      }
      if (item.fm_applyTipsType === 1) {
        // 严格控量产品，名额已满
        this.toast('名额已满，明日开放申请')
        return
      }
      this.$emit('on-click', item, index)
      // this.needUserLogin(() => {
      //   this.$emit('on-click', item, index)
      // })
    },
  },
}
</script>
<style lang="scss" scoped>
.dfaic {
  display: flex;
  align-items: center;
}
.flex-1 {
  flex: 1;
}
.color-tips {
  color: $color-text-tip;
}

.common-product {
  background-color: #fff;
  width: 100%;
}

// .common-item:last-child {
//   .product-content.bb-1px:last-child::after {
//     border-bottom: none;
//   }
// }

.product-content {
  padding: rc(25 36);
  // 名额已满
  &.product-full-apply,
  &.product-black {
    * {
      color: #bbb !important;
    }
    .product-apply-progress div {
      background: #bbb !important;
    }
    .product-btn,
    .hy-label {
      background: #fafafa !important;
    }
    // 图标变灰
    .product-logo,
    .desc-icon {
      filter: grayscale(100%);
    }
  }
  &.product-black {
    .desc-icon {
      filter: grayscale(0%) !important;
    }
    .tips-tip {
      color: #ea3323 !important;
    }
  }
  // 已下架
  &.product-undercarriage {
    // 图标变灰
    .product-logo {
      filter: grayscale(100%);
    }
    .product-name {
      color: #bbb;
    }
  }
}
.product-infos {
  position: relative;
  height: rc(46);
  line-height: normal;
  // overflow: hidden;
  .product-logo {
    width: rc(46);
    height: rc(46);
    border-radius: rc(10);
  }
  .product-name {
    margin-left: rc(16);
    font-size: rc(30);
    font-weight: bold;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  &.red-dot::after {
    content: '';
    position: absolute;
    top: rc(-6);
    left: rc(40);
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: $color-warn;
    z-index: 1;
  }
}
.product-middle {
  display: flex;
  .product-limit {
    font-size: rc(42);
    font-weight: bold;
    color: $color-remind;
    margin-top: rc(13);
  }
  .product-rate,
  .product-duration {
    font-size: rc(24);
    line-height: rc(34);
    margin-top: rc(13);
  }
  .product-duration {
    flex: 1;
    text-align: center;
  }
  .product-btn {
    margin: rc(14 0 15);
    width: rc(156);
    height: rc(57);
    font-size: rc(26);
    border-radius: rc(61);
  }
  .product-apply-no {
    font-size: rc(24);
    text-align: center;
    color: $color-text-tip;
  }
  .product-apply-progress {
    position: relative;
    width: rc(126);
    // height: rc(5);
    height: 3px;
    background-color: $line-btn-border;
    // border-radius: rc(6);
    border-radius: 1.5px;
    margin: rc(3) auto 0;
    div {
      position: absolute;
      top: 0;
      left: 0;
      width: 0;
      height: 100%;
      background-color: $color-main;
      // border-radius: rc(6);
      border-radius: 1.5px;
    }
  }
}
.product-desc {
  margin-top: rc(20);
  height: rc(56);
  line-height: normal;
  background-color: $bgColor-list-order;
  font-size: rc(24);
  color: $color-text-tip;
  padding: rc(0 20 0 14);
  overflow: hidden;
  border-radius: rc(4);
  .desc-icon {
    width: rc(44);
    height: rc(44);
    // margin-right: rc(6);
    background-position: center;
    background-repeat: no-repeat;
    background-size: rc(32 32);
    background-image: url(../../../static/images/list_icon_tips.png);
  }
  .icon {
    &-mxz {
      background-image: url(../../../static/images/#{$APP_NAME}/list_icon_api.png);
    }
    &-sqjl {
      background-image: url(../../../static/images/list_icon_pass.png);
    }
    &-fksj {
      background-image: url(../../../static/images/list_icon_time.png);
    }
    &-hmd {
      background-image: url(../../../static/images/list_icon_remind.png);
    }
  }
  .tips-mxz {
    color: $color-main;
    position: relative;
    padding-right: rc(22);
    margin-right: rc(20);
    &.has-prompt::after {
      content: '';
      width: 0;
      height: rc(30);
      border-right: 1px solid $line-list-split;
      position: absolute;
      top: 50%;
      right: 0;
      transform: translateY(-50%);
    }
  }
  .tips-tip {
    flex: 1;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
}
.undercarriage-tips {
  font-size: rc(24);
  line-height: rc(33);
  color: $color-text-tip;
  margin-top: rc(20);
}
.undercarriage-phone {
  font-size: rc(34);
  height: rc(48);
  line-height: rc(48);
  margin-top: rc(10);
  font-weight: bold;
}

.undercarriage-icon {
  position: absolute;
  top: 0;
  right: 0;
  width: rc(96);
  height: rc(96);
}
.undercarriage-btn {
  position: absolute;
  bottom: rc(42);
  right: rc(36);
  width: rc(156);
  height: rc(58);
  background: #fff;
  color: $color-text-title;
  font-size: rc(26);
  border-radius: rc(61);
  border: solid 1px $line-btn-border;
}
.custom-phone-call {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1;
}
.ad-position {
  .ad-img {
    // width: 100%;
    // max-width: rc(750);
    width: rc(678);
    height: rc(180);
    display: block;
    margin: auto;
    border-radius: rc(12);
  }
}
</style>


