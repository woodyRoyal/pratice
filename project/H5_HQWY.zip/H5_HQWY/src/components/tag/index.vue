<template>
  <div class="tag"
       :style="{color:privateCustomMadeStyle.color,borderColor:privateCustomMadeStyle.borderColor,background:privateCustomMadeStyle.backgroundColor}">
    {{ text }}
  </div>
</template>
<script>
const customMadeStyle = {
  color: "#333", // 字体色
  // borderColor: 'transparent', // 边框色
  backgroundColor: "#fff", // 背景色
}
export default {
  props: {
    text: { // 文本
      type: [String, Number],
      required: true,
    },
    customMadeStyle: {
      type: Object,
      default: () => customMadeStyle,
    },
  },
  data () {
    return {
      privateCustomMadeStyle: { ...customMadeStyle, ...this.customMadeStyle },
    }
  },
}
</script>
<style lang="scss" scoped>
.tag {
  white-space: nowrap;
  position: absolute;
  z-index: 1;
  top: rc(0);
  left: rc(70);
  padding: rc(2) rc(12) 0;
  font-size: rc(22);
  box-sizing: border-box;
  border-width: rc(2);
  border-style: solid;
  border-radius: rc(100) rc(100) rc(100) rc(30);
  border: 1px solid #fff;
}
</style>
