<template>
  <div v-show="show"
       class="cover"
       @click="hide()">
    <div class="actionsheet-layerchild actionsheet-anim-up actionsheet-layer-footer action-sheet">
      <div class="actionsheet-layercont">
        {{ actionTitle }}
      </div>
      <ul class="actionsheet-layerbtn">
        <li v-for="(item,index) in showData"
            :key="index"
            @click="selectedItem(item,index)">
          <span>{{ item.dictName }}</span>
        </li>
      </ul>
      <div class=" action-sheet-bottombtn bottom-btn"
           @click="hide()">
        <span>取消</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "ActionSheet",
  props: {
    isShow: {
      type: Boolean,
      default: false,
    },
    actionList: {
      type: Array,
      default: () => [],
    },
    actionTitle: {
      type: [String, Number],
      default: '',
    },
  },
  data () {
    return {
      show: false,
      showData: "",
    };
  },
  watch: {
    isShow: "updateStatus",
    actionList: "sortArray",
  },
  methods: {
    selectedItem: function (item, index) {
      this.$emit("onSelectItem", item, index);
      this.show = false;
    },
    updateStatus: function () {
      this.show = this.isShow;
    },
    hide: function () {
      this.show = false;
      this.$emit("onHideAction");
    },
    bubbleSort: function (arr) {
      var len = arr.length;
      for (var i = 0; i < len; i++) {
        for (var j = 0; j < len - 1 - i; j++) {
          if (arr[j].dictSort > arr[j + 1].dictSort) {
            //相邻元素两两对比
            var temp = arr[j + 1]; //元素交换
            arr[j + 1] = arr[j];
            arr[j] = temp;
          }
        }
      }
      return arr;
    },
    sortArray: function () {
      var arr = this.actionList;
      this.showData = this.bubbleSort(arr);
    },
  },
};
</script>

<style lang="scss" scoped>
.cover {
  z-index: 999;
  background-color: rgba(0, 0, 0, 0.5);
  width: 100%;
  height: 100%;
  bottom: 0;
  position: fixed;
}

.actionsheet-layerchild {
  width: 100%;
  bottom: 0;
  position: absolute;
  display: inline-block;
  background-color: #fff;
  font-size: 14px;
  -webkit-overflow-scrolling: touch;
  // -webkit-animation-fill-mode: both;
  // animation-fill-mode: both;
  -webkit-animation-duration: 0.2s;
  animation-duration: 0.2s;
}

@keyframes actionsheet-anim-up {
  0% {
    opacity: 0;
    -webkit-transform: translateY(800px);
    transform: translateY(800px);
  }
  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    transform: translateY(0);
  }
}

.actionsheet-anim-up {
  -webkit-animation-name: actionsheet-anim-up;
  animation-name: actionsheet-anim-up;
}

.actionsheet-layerchild h3 {
  margin: 0;
  padding: 0 rc(10);
  height: rc(60);
  line-height: rc(60);
  font-size: 16px;
  font-weight: 400;
  text-align: center;
}

.actionsheet-layerbtn span,
.actionsheet-layerchild h3 {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}

.actionsheet-layercont {
  position: relative;
  padding: 0;
  line-height: rc(96);
  text-align: center;
  font-weight: bold;
  color: #333;
  font-size: rc(30);
  &::after {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: 1px;
    border-bottom: 1px solid #ddd;
    transform: scaleY(0.5);
  }
}

.actionsheet-layerbtn,
.actionsheet-layerbtn span {
  position: relative;
  text-align: center;
}

.actionsheet-layerbtn {
  display: flex;
  display: -moz-flex;
  display: -webkit-flex;
  width: 100%;
  max-height: rc(490);
  overflow: scroll;
  // height: rc(50);
  // line-height: rc(50);
  font-size: 0;
  background-color: #f2f2f2;
  li:last-child {
    span::after {
      height: 0;
      border-bottom: none;
    }
  }
}

.actionsheet-layerbtn span {
  display: block;
  -moz-box-flex: 1;
  box-flex: 1;
  -webkit-box-flex: 1;
  line-height: rc(90);
  font-size: rc(30);
  cursor: pointer;
  color: #333;
}

.actionsheet-layerbtn span:active {
  background-color: #fff;
}

.actionsheet-layer-footer .actionsheet-layercont {
  // padding: rc(20);
  background-color: #fff;
}

.actionsheet-layer-footer .actionsheet-layerbtn {
  display: block;
  height: auto;
  background: 0 0;
  border-top: none;
}

.actionsheet-layer-footer .actionsheet-layerbtn span {
  background-color: #fff;
}

.actionsheet-layer-footer .actionsheet-layerbtn span {
  &::after {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: 1px;
    border-bottom: 1px solid #ddd;
    transform: scaleY(0.5);
  }
}

.bottom-btn {
  border-top: solid #f5f5f5 rc(20);
  position: relative;
  line-height: rc(96);
  text-align: center;
  font-size: rc(30);
  color: #333;
  &::after {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    top: -1px;
    height: 1px;
    border-bottom: 1px solid #ddd;
    transform: scaleY(0.5);
  }
}
</style>
