<template>
  <div class="loaderEnd">
    <span class="hqwy-loader-line"></span>
    <slot></slot>
  </div>
</template>

<style lang="scss" scoped="scoped">
.loaderEnd {
  text-align: center;
  padding-top: rc(13);
  padding-bottom: rc(30);
  font-size: rc(24);
  color: #777777;
}

.loaderEnd .hqwy-loader-line {
  display: inline-block;
  width: rc(360);
  position: relative;
  height: 1px;
  background-color: #d8d8d8;
}

.loaderEnd .hqwy-loader-line:after {
  position: absolute;
  content: '您已经探索到底啦';
  white-space: nowrap;
  left: 50%;
  transform: translate(-50%);
  top: rc(-17);
  height: rc(34);
  background-color: #f2f2f2;
  padding-left: rc(20);
  padding-right: rc(20);
}

.hqwy-a {
  margin-top: rc(30);
}
</style>
<style lang="scss">
.hqwy-a a {
  color: $color-main;
  text-decoration: underline;
}
</style>

