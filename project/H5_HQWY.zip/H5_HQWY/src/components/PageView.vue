<template>
  <div :class="['hyapp-page', type, {isIOS: $tools.getBrowser() === 'iOS'}]">
    <header class="hyapp-header">
      <div v-if="$tools.getBrowser() === 'iOS'"
           class="ios-header"></div>
      <div class="hyapp-bar">
        <div v-if="showLeft"
             class="hy-back"
             @click="backHandle"></div>
        <h1 class="title"
            :class="{'show-logo': showLogo}"
            v-text="showLogo ? '' : title"></h1>
        <div class="header-right"
             :class="[rightClass, {'zntj-icon': rightTxt === '智能推荐','sx-icon': rightTxt === '筛选'}]"
             @click="rightHandle">
          <slot name="right">
            {{ rightTxt }}
          </slot>
        </div>
      </div>
    </header>
    <div class="hyapp-content">
      <!-- <slot name="content">{{content}}</slot> -->
      <slot v-show="!showErrorPage"></slot>
      <!-- 错误缺省页 -->
      <DefaultBlankPage v-show="showErrorPage"
                        :icon="errorPageInfo.icon"
                        :title="errorPageInfo.title"
                        :btn-txt="errorPageInfo.btnTxt"
                        :btn-click="errorPageInfo.btnClick"
                        :has-tabbar="hasTabbar">
      </DefaultBlankPage>
    </div>
    <!-- 放弹窗等元素，避免iOS不能遮挡头部 -->
    <slot name="dialog"></slot>
  </div>
</template>
<script>
import DefaultBlankPage from './DefaultBlankPage'
export default {
  name: 'PageView',
  components: {
    DefaultBlankPage,
  },
  props: {
    showLogo: { // 标题是否展示logo。展示logo时设置title不生效
      type: Boolean,
      default: false,
    },
    title: {
      type: String,
      default: '',
      required: true,
    },
    type: { // className
      type: String,
      default: '',
    },
    rightClass: { // 右上角class
      type: String,
      default: '',
    },
    rightTxt: {
      type: String,
      default: '',
    },
    content: {
      type: String,
      default: '',
    },
    isBackPage: { // 是否返回上一页
      type: Boolean,
      default: true,
    },
    showLeft: { // 是否展示返回按钮
      type: Boolean,
      default: true,
    },
    hasTabbar: { // 是否有tabbar。首页四个页面传true
      type: Boolean,
      default: false,
    },
    showErrorPage: { // 是否展示错误页面
      type: Boolean,
      default: false,
    },
    errorPageInfo: { // 缺省页配置信息
      type: Object,
      default: () => ({}),
    },
  },
  methods: {
    // 测试环境切换
    // devCfg () {
    //   this.$appInvoked('appDeveloperConfig', {})
    // },
    backHandle () {
      if (this.isBackPage) {
        if (this.$route.query.fromapp === '1' || history.length < 2) {
          this.$appInvoked('appExecBack', {})
        } else {
          this.$routerBack()
        }
      } else {
        this.$emit('backClick')
      }
    },
    rightHandle () {
      this.$emit('rightClick')
    },
  },
}
</script>
<style lang="scss" scoped>
.hyapp-page {
  position: absolute;
  // z-index: 1;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: $bgColor;
  &.bg-fff {
    background-color: #ffffff;
  }
  .hyapp-header {
    position: fixed;
    width: 100%;
    top: 0;
    left: 0;
    z-index: 4;
  }
  .ios-header {
    width: 100%;
    height: 20px;
    background-color: #fff;
  }
  /*header样式*/
  .hyapp-bar {
    z-index: 5;
    position: relative;
    height: 44px;
    line-height: 44px;
    text-align: center;
    background-color: #fff;
    backface-visibility: hidden;
  }
  h1.title {
    font-size: 18px;
    // font-weight: 500;
    color: #333;
    font-weight: bold;
    padding: 0 42px;
    height: 100%;
    overflow: hidden;
    &.show-logo {
      background: url(../../static/images/#{$APP_NAME}/home_logo.png) no-repeat center;
      background-size: 78px 25px;
    }
  }
  .hy-back {
    position: absolute;
    left: 0px;
    top: 0px;
    width: 42px;
    height: 100%;
    background: url(../../static/images/navbar_back_01.png) no-repeat center;
    background-size: 12px 20px;
  }
  .hyapp-content {
    position: absolute;
    top: 44px;
    left: 0;
    right: 0;
    bottom: 0;
    overflow-x: hidden;
    overflow-y: scroll;
    -webkit-overflow-scrolling: touch;
    & > div.hyapp-page-content {
      width: 100%;
      height: 100%;
      overflow-y: auto;
      -webkit-overflow-scrolling: touch;
    }
  }
  &.isIOS .hyapp-content {
    top: 64px;
  }
  &.mycenterpage .hyapp-content {
    top: 0px;
  }
  &.isIOS.mycenterpage .hyapp-content {
    top: 20px;
  }
  .header-right {
    height: 100%;
    position: absolute;
    right: 0;
    top: 0;
    padding-right: 15px;
    font-size: 13px;
    color: #333;
    line-height: normal;
    display: flex;
    align-items: center;
  }
}
// 智能推荐
.zntj-icon {
  padding-left: 26px;
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 26px;
    height: 100%;
    background: url(../../static/images/global_iocn_setup1.png) no-repeat left center;
    background-size: 22px 22px;
  }
}
// 筛选
.sx-icon {
  padding-left: 24px;
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 24px;
    height: 100%;
    background: url(../../static/images/global_iocn_filtrate.png) no-repeat left center;
    background-size: 18px 18px;
  }
}
// 投诉/反馈
.tsfk-icon {
  padding-left: 19px;
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 19px;
    height: 100%;
    background: url(../../static/images/nav_ic_complaint.png) no-repeat left center;
    background-size: 14px 14px;
  }
}
// iphoneX、iphoneXs
@media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
  .hyapp-page.isIOS .ios-header {
    height: 44px;
  }
  .hyapp-page.isIOS .hyapp-content {
    top: 88px;
  }
  .hyapp-page.isIOS.mycenterpage .hyapp-content {
    top: 44px;
  }
}
// iphone Xs Max
@media only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) {
  .hyapp-page.isIOS .ios-header {
    height: 44px;
  }
  .hyapp-page.isIOS .hyapp-content {
    top: 88px;
  }
  .hyapp-page.isIOS.mycenterpage .hyapp-content {
    top: 44px;
  }
}
// iphone XR
@media only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2) {
  .hyapp-page.isIOS .ios-header {
    height: 44px;
  }
  .hyapp-page.isIOS .hyapp-content {
    top: 88px;
  }
  .hyapp-page.isIOS.mycenterpage .hyapp-content {
    top: 44px;
  }
}
</style>
