<template>
  <div id="loading"
       class="loading">
    <div class="loadimg">
      <div class="load-box">
        <span>
          <div class="mint-spinner-snake"></div>
        </span>
        <span>努力加载中...</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Loading',
  data () {
    return {}
  },
};
</script>

<style lang="scss" scoped="scoped">
.loading {
  width: 100%;
  bottom: rc(100);
  position: fixed;
  top: 0;
  line-height: 56px;
  color: #fff;
  font-size: 15px;
  background: rgba(255, 255, 255, 0);
  z-index: 99;
}
.loadimg {
  /*height: rc(260);*/
  width: rc(330);
  text-align: center;
  margin: auto;
  margin-top: 60%;
  .txt {
    font-size: rc(20);
    line-height: rc(60);
    color: #999;
    text-align: center;
  }
}

.load-box {
  /*background-color: rgba(226, 226, 226, 0.71);*/
  border-radius: 10px;
  display: flex;
  background-color: #111111;
  justify-content: center;
  align-items: center;
  /*padding: 0 rc(15);*/
  span {
    padding-left: rc(20);
  }
}
.mint-spinner-snake {
  animation: mint-spinner-rotate 0.8s infinite linear;
  border: 4px solid transparent;
  border-radius: 50%;
  border-top-color: #ccc;
  border-left-color: #ccc;
  border-bottom-color: #ccc;
  height: 20px;
  width: 20px;
}
@-webkit-keyframes mint-spinner-rotate {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }

  to {
    -webkit-transform: rotate(1turn);
    transform: rotate(1turn);
  }
}

@keyframes mint-spinner-rotate {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }

  to {
    -webkit-transform: rotate(1turn);
    transform: rotate(1turn);
  }
}
</style>

