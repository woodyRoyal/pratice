<template>
  <!-- 判断是否过审 -->
  <div></div>
</template>
<script>
import { getUserProductListApi } from '@/api/controller/product/index'

export default {
  name: 'AuditPass',
  methods: {
    /**
     * 过审操作
     * needGetList {Boolean} 是否调用获取过审产品列表接口
     * cb 已过审回调
     * cb1未过审回调
     */
    init (needGetList, cb, cb1) {
      let that = this
      // 判断安卓是否过审
      if (isAndroid) {
        that.$appInvoked('appGetAllInfos', {}, (rst) => {
          // rst = {hasAuditPass: true}
          if (rst.hasAuditPass) {
            // 已过审，展示正常流程
            localStorage.setItem('AUDIT-PASS', 1)
            cb && cb()
          } else { // 未过审，展示过审页面
            localStorage.setItem('AUDIT-PASS', 0)
            if (needGetList) {
              // 开始接口请求
              that.$emit('begin-request', true)
              // 获取过审中产品列表
              getUserProductListApi().then((data) => {
                // 获取成功
                cb1 && cb1(true, data)
              }, (err) => {
                // 获取失败
                cb1 && cb1(false, err)
              })
            } else {
              cb1 && cb1()
            }
          }
        })
      } else {
        // 不需要过审判断，展示正常流程
        localStorage.setItem('AUDIT-PASS', 1)
        cb && cb()
        // 模拟未过审
        // localStorage.setItem('AUDIT-PASS', 0)
        // if (needGetList) {
        //   // 开始接口请求
        //   that.$emit('begin-request', true)
        //   // 获取过审中产品列表
        //   getUserProductListApi().then(data => {
        //     // 获取成功
        //     cb1 && cb1(true, data)
        //   }, err => {
        //     // 获取失败
        //     cb1 && cb1(false, err)
        //   })
        // } else {
        //   cb1 && cb1()
        // }
      }
    },
  },
}
</script>

