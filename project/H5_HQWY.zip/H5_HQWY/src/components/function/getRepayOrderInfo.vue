<template>
  <!-- 获取接近还款日或逾期的订单 -->
  <div></div>
</template>
<script>
import { getRepayOrderInfoApi } from '@/api/controller/api'
export default {
  methods: {
    getRepayOrderInfo (params, cb, errcb) {
      let that = this
      that.$appInvoked("appGetUserToken", {}, function (token) {
        if (token !== "" && token != null) {
          getRepayOrderInfoApi(params).then((data) => {
            cb && cb(data)
          }, (err) => {
            errcb && errcb(err)
          })
        }
      })
    },
  },
}
</script>

