<template>
  <div id="loading"
       class="loading"
       :style="{display:isload}">
    <div class="loadimg">
      <div class="load-box">
        <!-- 使用CDN图片路径 -->
        <!-- <img src="//imgwx5.2345.com/hj/hqwy/dist/static/images/refresh1.gif"> -->
        <img :src="require('APP_IMG/refresh1.gif')">
      </div>

      <!--<p class="txt">努力加载中...</p>-->
    </div>
  </div>
</template>

<script>
export default {
  props: {
    isload: {
      type: String,
      default: '',
    },
  },
  data () {
    return {};
  },
};
</script>

<style lang="scss" scoped="scoped">
.loading {
  width: 100%;
  bottom: rc(100);
  position: absolute;
  top: 0;
  line-height: 56px;
  color: #fff;
  font-size: 15px;
  background: rgba(255, 255, 255, 0);
  z-index: 99;
}

.loadimg {
  height: rc(260);
  width: rc(300);

  text-align: center;
  margin: auto;
  margin-top: 60%;
  .txt {
    font-size: rc(20);
    line-height: rc(60);
    color: #999;
    text-align: center;
  }
}

.load-box {
  background-color: rgba(226, 226, 226, 0.71);
  border-radius: 20px;
}

img {
  height: rc(300);
  width: rc(300);
}
</style>
