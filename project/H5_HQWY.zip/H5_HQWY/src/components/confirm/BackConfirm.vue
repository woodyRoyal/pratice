<template>
  <Confirm ref="backComfirm"
           :type="'confirm-icon ' + type"
           :title="title"
           :cancel-txt="cancelTxt"
           :sure-txt="sureTxt"
           :btn-type="btnType"
           :close-flag="closeFlag"
           @on-cancel="backConfirmCancel()"
           @on-confirm="backConfirmSure()">
    <div slot="icon"
         class="dialog-icon info-back-dialog"
         :class="'info-back-dialog-' + iconType">
      <img v-if="iconType===1"
           :src="require('APP_IMG/dialog_img_1.png')"
           alt="">
      <img v-else-if="iconType===2"
           :src="require('APP_IMG/dialog_img_2.png')"
           alt="">
      <img v-else-if="iconType===3"
           :src="require('APP_IMG/dialog_img_3.png')"
           alt="">
    </div>
    <div class="hy-txt"
         v-html="txt">
      <slot></slot>
    </div>
  </Confirm>
</template>
<script>
import Confirm from './index'
export default {
  name: 'BackConfirm',
  components: {
    Confirm,
  },
  props: {
    title: {
      type: String,
      default: '温馨提示',
    },
    txt: {
      type: String,
      default: '',
    },
    cancelTxt: {
      type: String,
      default: '',
    },
    sureTxt: {
      type: String,
      default: '',
    },
    btnType: {
      type: String,
      default: 'lr',
    },
    closeFlag: {
      type: Boolean,
      default: false,
    },
    iconType: {
      type: Number,
      default: 1,
    },
    type: {
      type: String,
      default: '',
    },
  },
  // data () {
  //   return {}
  // },
  methods: {
    show () {
      this.$refs.backComfirm.show()
    },
    hide () {
      this.$refs.backComfirm.hide()
    },
    backConfirmCancel () {
      this.$emit('on-cancel')
    },
    backConfirmSure () {
      this.$emit('on-confirm')
    },
  },
}
</script>
<style lang="scss">
.confirm-icon {
  .remind-txt {
    color: $color-remind;
    font-weight: bold;
  }
}
</style>

<style lang="scss" scoped>
.confirm-icon {
  .hy-txt {
    text-align: center;
  }
  .dialog-icon {
    margin-bottom: rc(24);
    img {
      position: absolute;
      top: rc(38);
      left: 50%;
      transform: translate(-50%, -100%);
    }
    &.info-back-dialog {
      // img {
      //   top: rc(38);
      //   width: rc(360);
      //   height: rc(237);
      // }
      &-1 img {
        top: rc(40);
        width: rc(360);
        height: rc(237);
      }
      &-2 img {
        top: rc(38);
        width: rc(360);
        height: rc(237);
      }
      &-3 img {
        top: rc(38);
        width: rc(360);
        height: rc(237);
      }
    }
  }
}
</style>


