<template>
  <Confirm ref="backComfirm"
           :title="title"
           :cancel-txt="cancelTxt"
           :sure-txt="sureTxt"
           btn-type="tb"
           :close-flag="closeFlag"
           :close-on-confirm="false"
           @on-cancel="backConfirmCancel()"
           @on-confirm="backConfirmSure()">
    <div class="hy-txt">
      <div class="permission-subtitle"
           v-html="txt"></div>
      <ul class="permission-list">
        <li v-for="p in lists"
            :key="p.type"
            class="permission-item">
          <img :src="p.icon"
               class="permission-item-icon">
          <span class="permission-item-name">{{ p.name }}</span>
        </li>
      </ul>
      <slot></slot>
    </div>
  </Confirm>
</template>
<script>
import Confirm from './index'
export default {
  name: 'PermissionConfirm',
  components: {
    Confirm,
  },
  props: {
    title: {
      type: String,
      default: '',
    },
    txt: {
      type: String,
      default: '为确保向您提供精准匹配贷款产品、享受优惠贷款的服务，请先开启以下权限！',
    },
    cancelTxt: {
      type: String,
      default: '',
    },
    sureTxt: {
      type: String,
      default: '知道了',
    },
    closeFlag: {
      type: Boolean,
      default: false,
    },
    type: {
      type: String,
      default: '',
    },
    permissions: {
      type: Array,
      // required: true,
      default: () => [],
    },
    /**
     * 权限弹窗类型
     * login:Android系统用户进入登录页弹窗提示告知需获取设备信息
     * sfrz:身份认证页面权限弹窗
     * jjlxr:紧急联系人页面权限弹窗
     */
    pt: {
      type: String,
      default: '',
      // required: true
    },
  },
  data () {
    return {
      callback: null, // 弹窗不展示或者展示点击知道了后执行的回调
    }
  },
  computed: {
    lists () {
      // 1：相机，2：相册，3：麦克风，4：通讯录，5；短信，6：定位，7：通话记录，8：设备信息
      let all = {
        1: { name: '相机权限', icon: require('APP_IMG/icon_empower_camera.png') },
        2: { name: '相册权限', icon: require('APP_IMG/icon_empower_photo.png') },
        // 3: { name: '麦克风权限', icon: require('APP_IMG/icon_empower_tape.png') },
        4: { name: '通讯录权限', icon: require('APP_IMG/icon_empower_addressbook.png') },
        // 5: { name: '短信权限', icon: require('APP_IMG/icon_empower_message.png') },
        // 6: { name: '定位权限', icon: require('APP_IMG/icon_empower_location.png') },
        // 7: { name: '通话记录权限', icon: require('APP_IMG/icon_empower_telephone.png') },
        // 8: { name: '设备信息权限', icon: require('APP_IMG/icon_empower_iphone.png') },
        // 9: { name: 'applist权限', icon: require('APP_IMG/icon_empower_applist.png') }
      }
      let val = this.permissions
      let lists = []
      for (let i = 0; i < val.length; i++) {
        let item = { ...all[val[i]], type: val[i] }
        lists.push(item)
      }
      return lists
    },
  },
  methods: {
    show (cfg) {
      if (cfg && cfg.callback) {
        this.callback = cfg.callback
      } else {
        this.callback = null
      }
      // this.initAppDataCache({ action: 3 })
      this.initAppDataCache({ action: 2 }, (rst) => {
        if (!rst) {
          this.$refs.backComfirm.show()
        } else {
          try {
            rst = JSON.parse(rst)
            if (!rst[this.pt] || rst[this.pt] < 1) {
              this.$refs.backComfirm.show()
            } else {
              if (cfg && cfg.callback) {
                cfg.callback()
              }
            }
          } catch (error) {
            this.$refs.backComfirm.show()
          }
        }
      })
    },
    hide () {
      this.$refs.backComfirm.hide()
    },
    backConfirmCancel () {
      this.$emit('on-cancel')
    },
    backConfirmSure () {
      this.initAppDataCache({ action: 2 }, (rst) => {
        let value = {}, pt = this.pt
        if (!rst) {
          value[pt] = 1
        } else {
          try {
            rst = JSON.parse(rst)
            value = rst
            if (rst[pt]) {
              value[pt] = rst[pt] + 1
            } else {
              value[pt] = 1
            }
          } catch (error) {
            value[pt] = 1
          }
        }
        this.initAppDataCache({ action: 1, value: JSON.stringify(value) })
        // this.$appInvoked('appAskPermissionStatus', {
        //   needShowPermissionAlert: true,
        //   permissions: this.permissions
        // })
        if (this.callback) {
          this.callback()
        }
        this.$emit('on-confirm')
        this.hide()
      })
    },
    initAppDataCache (cfg, cb) {
      this.$appInvoked('appDataCache', {
        action: cfg.action, // 1-存储；2-取值；3-清除
        key: 'ALL_PERMISSION_CONFIRM_TIMES',
        memoryCache: false,
        value: cfg.value,
      }, (rst) => {
        cb && cb(rst)
      })
    },
  },
}
</script>
<style lang="scss" scoped>
.permission-subtitle {
  color: #333;
  font-size: rc(24);
  line-height: rc(40);
  // text-align: center;
}
.permission-list {
  margin-top: rc(27);
  max-height: rc(520);
  overflow-y: auto;
  box-sizing: border-box;
}
.permission-item {
  display: flex;
  align-items: center;
  margin-bottom: rc(37);
  &:last-child {
    margin-bottom: 0;
  }
  .permission-item-icon {
    width: rc(84);
    margin-right: rc(30);
  }
  .permission-item-name {
    font-size: rc(32);
    color: #444;
  }
}
</style>


