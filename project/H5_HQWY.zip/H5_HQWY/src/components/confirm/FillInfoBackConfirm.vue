<!-- 完善贷款资料返回挽留弹窗：重新智能推荐&API完善资料 -->
<template>
  <BackConfirm ref="backComfirm"
               :type="type"
               title="温馨提示"
               :cancel-txt="confirm.cancelTxt"
               :sure-txt="confirm.sureTxt"
               :btn-type="confirm.btnType"
               :icon-type="confirm.iconType"
               :txt="confirm.txt"
               @on-cancel="backConfirmCancel()"
               @on-confirm="backConfirmSure()">
  </BackConfirm>
</template>
<script>
import BackConfirm from './BackConfirm'
export default {
  name: 'FillInfoBackConfirm',
  components: {
    BackConfirm,
  },
  props: {
    source: {
      type: String,
      default: '1',
    },
    page: {
      type: String,
      default: '',
    },
    type: {
      type: String,
      default: '',
    },
  },
  data () {
    return {
    }
  },
  computed: {
    confirm () {
      if (this.source === '2') {
        return {
          cancelTxt: '立即重新推荐',
          sureTxt: '继续完善',
          btnType: 'tb',
          iconType: 2,
          txt: '资料越完善，<br>推荐的产品通过率越高哦~',
        }
      } else {
        return {
          cancelTxt: '确认放弃',
          sureTxt: '继续填写',
          btnType: 'lr',
          iconType: 1,
          txt: '<span class="remind-txt">大额、高通过率产品</span>正等您！<br>确认放弃？',
        }
      }
    },
    eventId () {
      let source = this.source
      let page = this.page
      let allEventIds = {
        SFRZ: [ // 身份认证
          ['sfrz;zntj;fhtc;w287', 'sfrz;zntj;fhtc;w288'], // 智能推荐入口返回挽留弹窗埋点(确认、取消)
          ['sfrz;wsdkxx;fhtc;w284', 'sfrz;wsdkxx;fhtc;w285'], // 完善贷款信息入口返回挽留弹窗埋点(确认、取消)
        ],
        JJLXR: [ // 紧急联系人
          ['jjlxr;zntj;fhtc;w293', 'jjlxr;zntj;fhtc;w294'],
          ['jjlxr;wsdkxx;fhtc;w290', 'jjlxr;wsdkxx;fhtc;w291'],
        ],
        QTXX: [ // 其他信息
          ['qtxx;zntj;fhtc;w304', 'qtxx;zntj;fhtc;w305'],
          ['qtxx;wsdkxx;fhtc;w302', 'qtxx;wsdkxx;fhtc;w303'],
        ],
      }
      let w = {
        SFRZ: [[287, 288], [284, 285]],
        JJLXR: [[293, 294], [290, 291]],
        QTXX: [[304, 305], [302, 303]],
      }
      if (source === '2') {
        return {
          eventId: allEventIds[page] ? allEventIds[page][0] : [],
          w: w[page] ? w[page][0] : [],
        }
      } else {
        return {
          eventId: allEventIds[page] ? allEventIds[page][1] : [],
          w: w[page] ? w[page][1] : [],
        }
      }
    },
  },
  methods: {
    show () {
      this.$refs.backComfirm.show()
    },
    hide () {
      this.$refs.backComfirm.hide()
    },
    backConfirmCancel () {
      if (this.eventId.eventId[1]) {
        this.$appInvoked('appExecStatistic', {
          eventId: this.eventId.eventId[1],
        })
      }
      if (this.source === '2') {
        // 重新推荐逻辑
        this.globalRecommendClick(this.eventId.w[1], '2')
      } else {
        this.$routerGo(-1);
      }
    },
    backConfirmSure () {
      if (this.eventId.eventId[0]) {
        this.$appInvoked('appExecStatistic', {
          eventId: this.eventId.eventId[0],
        })
      }
    },
  },
}
</script>
<style lang="scss" scoped>
.confirm-icon {
  .remind-txt {
    color: $color-remind;
    font-weight: bold;
  }
  .hy-txt {
    text-align: center;
  }
  .dialog-icon {
    margin-bottom: rc(24);
    img {
      position: absolute;
      top: rc(38);
      left: 50%;
      transform: translate(-50%, -100%);
    }
    &.info-back-dialog {
      img {
        top: rc(38);
        width: rc(325);
        height: rc(226);
      }
      &.info-back-dialog-2 img {
        top: rc(18);
        width: rc(175);
        height: rc(196);
      }
    }
  }
}
</style>


