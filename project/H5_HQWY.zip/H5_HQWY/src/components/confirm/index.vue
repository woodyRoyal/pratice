<template>
  <div v-show="showValue"
       ref="confirm"
       class="hy-confirm"
       :class="type">
    <div ref="mask"
         class="hy-confirm-mask"></div>
    <div class="hy-confirm-content">
      <div v-if="closeFlag"
           class="hy-close-btn"
           @click="closeFun()"></div>
      <slot name="icon"></slot>
      <div v-if="title"
           class="hy-title">
        {{ title }}
      </div>
      <div class="hy-confirm-center">
        <p v-if="txt"
           class="hy-txt"
           :style="{'text-align': txtStyle}"
           v-html="txt"></p>
        <slot></slot>
      </div>
      <div v-if="cancelTxt || sureTxt"
           :class="['hy-confirm-btns-' + btnType, btnSameColor ? 'btns-same-color': '']">
        <div v-if="sureTxt"
             class="hy-btn-sure"
             :class="btnType === 'lr' ? 'hy-btn' : 'jrcs-btn'"
             @click="sureFun()">
          {{ sureTxt }}
        </div>
        <div v-if="cancelTxt"
             class="hy-btn-cancel"
             :class="btnType === 'lr' ? 'hy-btn' : ''"
             @click="cancelFun()">
          {{ cancelTxt }}
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Confirm',
  props: {
    title: { // 弹窗标题
      type: String,
      default: '温馨提示',
    },
    txt: { // 弹窗中间内容文案
      type: String,
      default: '',
    },
    cancelTxt: { // 灰色按钮
      type: String,
      default: '',
    },
    sureTxt: { // 橙色按钮
      type: String,
      default: '',
    },
    closeFlag: { // 关闭按钮
      type: Boolean,
      default: false,
    },
    txtStyle: { // 弹窗中间内容文案居中方式
      type: String,
      default: 'left',
    },
    whiteSpace: {
      type: Boolean,
      default: false, // 点击空白区域是否关闭弹窗 默认不关闭
    },
    btnSameColor: {
      type: Boolean,
      default: false, // 两个按钮颜色一样 默认不一样
    },
    closeOnConfirm: { // 点击确认按钮时，是否关闭confirm。默认关闭
      type: Boolean,
      default: true,
    },
    btnType: { // 按钮展示类型。支持lr-左右，tb-上下。默认lr左右展示
      type: String,
      default: 'lr',
    },
    type: { // 自定义class
      type: String,
      default: '',
    },
  },
  data () {
    return {
      showValue: false,
    }
  },
  created () {
    this.callback = null
  },
  mounted () {
    document.addEventListener('click', this.hideMask, false)
  },
  methods: {
    closeFun () {
      this.hide()
      this.$emit('on-close')
    },
    cancelFun () {
      this.hide()
      this.$emit('on-cancel')
    },
    sureFun () {
      if (this.closeOnConfirm) {
        this.hide()
      }
      this.callback ? this.callback() : this.$emit('on-confirm')
    },
    hideMask (e) {
      if (this.whiteSpace && e.target === this.$refs.mask) {
        this.hide()
      }
    },
    show (cb) {
      this.showValue = true
      this.callback = cb
    },
    hide () {
      this.showValue = false
    },
  },
}
</script>
<style lang="scss" scoped>
.hy-confirm {
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  z-index: 100;
}
.hy-confirm-mask {
  position: fixed;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 100;
}
// .diversion-confirm .hy-confirm-mask {
//   bottom: rc(100);
// }
.hy-close-btn {
  position: fixed;
  right: rc(10);
  top: rc(10);
  width: rc(60);
  height: rc(60);
  background: url(../../../static/images/close.png) no-repeat center;
  background-size: rc(20 20);
  // &:before,
  // &::after {
  //   content: '';
  //   position: absolute;
  //   left: 50%;
  //   top: 50%;
  //   margin-left: rc(-2);
  //   margin-top: rc(-17);
  //   width: rc(4);
  //   height: rc(34);
  //   background-color: #333;
  // }
  // &:before {
  //   transform: rotate(45deg);
  // }
  // &:after {
  //   transform: rotate(-45deg);
  // }
}
.hy-confirm-content {
  position: fixed;
  left: rc(70);
  right: rc(70);
  top: 50%;
  transform: translateY(-50%);
  // width: rc(560);
  padding-top: rc(36);
  border-radius: rc(20);
  background-color: #fff;
  z-index: 101;
  .hy-title {
    padding: 0 0 rc(20);
    text-align: center;
    font-size: rc(36);
    line-height: rc(50);
    color: #333;
    font-weight: bold;
  }
}
.hy-confirm-center {
  padding: 0 rc(50) rc(30);
  // max-height: rc(720);
  // overflow-y: auto;
  // box-sizing: border-box;
  .hy-txt {
    font-size: rc(30);
    line-height: rc(45);
    color: #444;
  }
}
.hy-confirm-btns-lr {
  position: relative;
  display: flex;
  flex-direction: row-reverse;
  height: rc(90);
  line-height: rc(90);
  text-align: center;
  font-size: rc(32);
  &:before {
    content: '';
    width: 100%;
    height: 1px;
    left: 0;
    position: absolute;
    border-top: 1px solid #ddd;
    top: 0;
    transform: scaleY(0.5);
    transform-origin: 0 0;
  }
  .hy-btn {
    flex: 1;
    height: 100%;
    &:nth-child(2) {
      position: relative;
      &:before {
        content: '';
        width: 1px;
        height: 100%;
        right: 0;
        position: absolute;
        border-right: 1px solid #d8d8d8;
        top: 0;
        transform: scaleX(0.5);
        transform-origin: 0 0;
      }
    }
  }
  .hy-btn-cancel {
    color: $color-text-sub;
  }
  .hy-btn-sure {
    color: $color-main;
  }
  .btns-same-color {
    .hy-btn-cancel,
    .hy-btn-sure {
      color: $color-text-title;
    }
  }
}
.hy-confirm-btns-tb {
  padding: rc(24 50 30);
  .hy-btn-sure {
    height: rc(80);
    border-radius: rc(45);
    font-size: rc(36);
    margin-bottom: rc(30);
  }
  .hy-btn-cancel {
    color: $color-text-tip;
    font-size: rc(28);
    line-height: rc(40);
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
  }
}
</style>
