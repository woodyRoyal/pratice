<!-- 登录引导弹窗 -->
<template>
  <BackConfirm ref="backComfirm"
               type="diversion-confirm"
               title="还没看到合适的产品？"
               cancel-txt="继续浏览"
               sure-txt="去登录"
               btn-type="tb"
               :icon-type="2"
               txt="立即登录，解锁更多高通率产品！"
               :close-flag="false"
               @on-confirm="backConfirmSure()"
               @on-cancel="backConfirmCancel()">
  </BackConfirm>
</template>
<script>
import BackConfirm from './BackConfirm'
export default {
  name: 'DiversionConfirm',
  components: {
    BackConfirm,
  },
  data () {
    return {
    }
  },
  methods: {
    show () {
      let showLoginConfirm = (isLogin) => {
        if (!isLogin) {
          this.$refs.backComfirm.show()
          // this.$emit('switch-status', true)
        }
      }
      if (isIos || isAndroid) {
        this.$appInvoked('appIsLogin', {}, (isLogin) => {
          showLoginConfirm(isLogin)
        })
      } else {
        let isLogin = false
        showLoginConfirm(isLogin)
      }
    },
    hide () {
      this.$refs.backComfirm.hide()
      // this.$emit('switch-status', false)
    },
    backConfirmSure () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'dlyd;tc;qdl;w325',
      })
      this.hide()
      this.needUserLogin(325)
    },
    backConfirmCancel () {
      this.$appInvoked('appExecStatistic', {
        eventId: 'dlyd;tc;jxll;w326',
      })
      this.hide()
    },
  },
}
</script>
<style lang="scss" scoped>
.confirm-icon {
  .remind-txt {
    color: $color-remind;
    font-weight: bold;
  }
  .hy-txt {
    text-align: center;
  }
  .dialog-icon {
    margin-bottom: rc(24);
    img {
      position: absolute;
      top: rc(38);
      left: 50%;
      transform: translate(-50%, -100%);
    }
    &.info-back-dialog {
      img {
        top: rc(38);
        width: rc(325);
        height: rc(226);
      }
      &.info-back-dialog-2 img {
        top: rc(18);
        width: rc(175);
        height: rc(196);
      }
    }
  }
}
</style>


