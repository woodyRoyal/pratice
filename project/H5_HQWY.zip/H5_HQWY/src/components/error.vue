<template>
  <div class="error-page">
    <img :src="require('APP_IMG/global_loading_fail.png')"
         class="error-page-icon">
    <div class="error-page-tips">
      页面加载失败，请重试~
    </div>
    <div class="error-page-btn jrcs-btn"
         @click="reload()">
      重新加载
    </div>
  </div>
</template>
<script>
export default {
  methods: {
    reload () {
      window.location.reload();
    },
  },
}
</script>
<style lang="scss" scoped>
.error-page {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  background-color: #fff;
  text-align: center;
  &-icon {
    width: rc(340);
    height: rc(300);
    margin-top: rc(148);
  }
  &-tips {
    font-size: rc(28);
    color: #666;
    margin-top: rc(104);
  }
  &-btn {
    font-size: rc(28);
    color: #fff;
    width: rc(240);
    height: rc(68);
    // background-image: linear-gradient(90deg, #ff5b00 0%, #ff8f00 100%);
    border-radius: rc(100);
    // text-align: center;
    margin: rc(30) auto;
  }
}
</style>


