<template>
  <div class="footer">
    <ul>
      <router-link class=""
                   replace
                   to="/home"
                   tag="li"
                   @click.native="addStatic('dock;w21')">
        <span class="icon icon-index flexcenter"></span>
        <div>首页</div>
      </router-link>
      <router-link replace
                   to="/productlist"
                   tag="li"
                   @click.native="addStatic('dock;w71')">
        <span class="icon icon-order flexcenter"></span>
        <div>贷款大全</div>
      </router-link>
      <router-link class=""
                   replace
                   to="/guessborrow"
                   tag="li"
                   @click.native="addStatic('dock;w108')">
        <span class="icon icon-cart flexcenter"></span>
        <div>猜你可贷</div>
      </router-link>
      <router-link class=""
                   replace
                   to="/mycenter"
                   tag="li"
                   @click.native="mycenterClick('dock;w110')">
        <span class="icon icon-user flexcenter"
              :class="{'over-due': orderDotRemark.overDue, 'dot': orderDotRemark.remark && !orderDotRemark.overDue}"></span>
        <div>我的</div>
      </router-link>
    </ul>
    <div v-show="isMaskerShow && pageShowMask"
         class="hqwy-masker-footer"
         @click="maskerHandle"></div>
  </div>
</template>

<script>
import eventCtr from "../../static/js/eventCtr";
import { updateStatusApi } from "@/api/controller/common/index";

export default {
  data () {
    return {
      isMaskerShow: false,
      orderDotRemark: {
        remark: false,
        overDue: false,
      },
      pageShowMask: false, // 当前页面tabbar是否需要显示遮罩层。首页、贷款大全需要展示
    };
  },
  watch: {
    $route (to) {
      if (['/home', '/productlist'].indexOf(to.path) > -1) {
        this.pageShowMask = true
      } else {
        this.pageShowMask = false
      }
    },
  },
  mounted () {
    let that = this;
    if (['/home', '/productlist'].indexOf(this.$route.path) > -1) {
      this.pageShowMask = true
    } else {
      this.pageShowMask = false
    }
    eventCtr.$on("maskerHandle", (msg) => {
      that.isMaskerShow = msg;
    });
    let orderDotRemark = that.$store.state.redPoint.orderDotRemark;
    that.orderDotRemark = orderDotRemark;
  },
  methods: {
    maskerHandle () {
      this.isMaskerShow = false;
      eventCtr.$emit("maskerDownHandle", false);
    },
    addStatic (eventid) {
      this.$appInvoked("appExecStatistic", { eventId: eventid, eventType: 0 }); //埋点
    },
    mycenterClick (eventid) {
      let that = this
      that.addStatic(eventid)
      that.updateMineStatus()
    },
    // 标记我的小红点和逾期标识
    updateMineStatus () {
      let that = this
      let orderDotRemark = that.orderDotRemark
      if (orderDotRemark.overDue) {
        // 标记逾期未已读（每日展示一次，本地处理）
        let curDate = new Date();
        localStorage.setItem('hideOverdueMarkDate', curDate.getFullYear() + '-' + (curDate.getMonth() + 1) + '-' + curDate.getDate());
      }
      if (orderDotRemark.remark) {
        // 标记小红点已读（只展示一次，调接口）
        updateStatusApi({ remarkType: 0, remarkStatus: 0 });
      }

      that.$store.commit('orderDotRemark', {
        overDue: false,
        remark: false,
      });
    },
  },
};
</script>

<style lang="scss" scoped="scoped">
.footer {
  /*width: 100%;*/
  height: rc(100);
  position: absolute;
  bottom: 0px;
  left: 0;
  right: 0;
  z-index: 2;
  background: #fff;
  font-size: rc(20);
  border-top: 1px solid #e6e6e6;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
  color: $tab-bottom-text-color;
  /*background: -webkit-gradient(linear, left top, right bottom, color-stop(0%, #9dc3fb), color-stop(100%, #84b2f7));*/
  ul {
    display: flex;
    li {
      padding-top: rc(15);
      flex: 1;
      text-decoration: none;
      list-style: none;
      text-align: center;
      font-size: rc(20);
      div {
        height: rc(28);
        line-height: rc(28);
      }
    }
  }
}

.hqwy-masker-footer {
  position: fixed;
  bottom: 0;
  width: 100%;
  height: rc(100);
  background-color: #000000;
  opacity: 0.5;
  z-index: 4;
}

.link {
  float: left;
  width: 25%;
  text-decoration: none;
  list-style: none;
  text-align: center;
  color: #666;
  font-size: rc(20);
  div {
    height: rc(28);
    line-height: rc(28);
  }
  /*margin-bottom: rc(5);*/
}

.router-link-active {
  color: $color-main;
}

.icon {
  display: inline-block;
  height: rc(66);
  /*border: 1px solid red;*/
  &.dot {
    position: relative;
    &::after {
      content: '';
      position: absolute;
      right: rc(-2);
      top: 0;
      width: rc(12);
      height: rc(12);
      border-radius: 50%;
      background-color: #ff4c4c;
    }
  }
  &.over-due {
    position: relative;
    &::after {
      content: '';
      width: rc(56);
      height: rc(33);
      background: url(../../static/images/ic_remind.png) no-repeat center;
      background-size: 100% 100%;
      // line-height: rc(28);
      position: absolute;
      top: rc(-12);
      left: 100%;
      margin-left: rc(-8);
      // padding: rc(2 10);
      // border: 1px solid #fff;
      // border-radius: rc(18);
      // border-bottom-left-radius: 0;
      // background-color: #ff4c4c;
      // color: #fff;
      // font-size: rc(20);
      // word-break: keep-all;
    }
  }
}

.icon-index {
  /*margin-top: rc(15);*/
  background: url(../../static/images/#{$APP_NAME}/tabbar_home_normal.png);
  width: rc(44);
  height: rc(44);
  background-size: 100% 100%;
}

.router-link-active .icon-index {
  /*margin-top: rc(15);*/
  background: url(../../static/images/#{$APP_NAME}/tabbar_home_selected.png);
  width: rc(44);
  height: rc(44);
  background-size: 100% 100%;
}

.icon-order {
  /*margin-top: rc(10);*/
  background: url(../../static/images/#{$APP_NAME}/tabbar_money_normal.png);
  width: rc(44);
  height: rc(44);
  background-size: 100% 100%;
}

.router-link-active .icon-order {
  /*margin-top: rc(10);*/
  background: url(../../static/images/#{$APP_NAME}/tabbar_money_selected.png);
  width: rc(44);
  height: rc(44);
  background-size: 100% 100%;
}

.icon-cart {
  /*margin-top: rc(10);*/
  background: url(../../static/images/#{$APP_NAME}/tabbar_like_normal.png);
  width: rc(44);
  height: rc(44);
  background-size: 100% 100%;
}

.router-link-active .icon-cart {
  /*margin-top: rc(10);*/
  background: url(../../static/images/#{$APP_NAME}/tabbar_like_selected.png);
  width: rc(44);
  height: rc(44);
  background-size: 100% 100%;
}

.icon-user {
  /*margin-top: rc(15);*/
  background: url(../../static/images/#{$APP_NAME}/tabbar_me_normal.png);
  width: rc(44);
  height: rc(44);
  background-size: 100% 100%;
}

.router-link-active .icon-user {
  /*margin-top: rc(15);*/
  background: url(../../static/images/#{$APP_NAME}/tabbar_me_selected.png);
  width: rc(44);
  height: rc(44);
  background-size: 100% 100%;
}
</style>
