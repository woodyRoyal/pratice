<template>
  <div v-show="isShow"
       class="cover">
    <div class="hy-confirm-mask"
         @click="hide()"></div>
    <div class="actionsheet-layerchild actionsheet-anim-up actionsheet-layer-footer action-sheet">
      <div class="actionsheet-layercont">
        <span class="cancel"
              @click="hide()">取消</span>
        <span class="title">{{ actionTitle }}</span>
        <span class="cancel right">取消</span>
      </div>
      <ul class="actionsheet-layerbtn">
        <li v-for="(item, index) in showData"
            :key="index"
            @click="selectedItem(item,index)">
          <img class="logo"
               :src="item.logoUrl" />
          <span>{{ item.cardNo | formateBank(item.bankName) }}</span>
          <img v-show="item.cardNo == actionId"
               class="select"
               src="../../../static/images/order_card_check.png"
               alt="">
        </li>
        <li @click="addBankItem('xzyhk;tjyhk;2226')">
          <img class="logo-add"
               :src="require('APP_IMG/card_img_normal.png')" />
          <span>添加银行卡</span>
          <img class="link"
               src="../../../static/images/arrow.png"
               alt="">
        </li>
      </ul>
    </div>
    <!-- 绑定提示弹窗 -->
    <Confirm ref="bindComfirm"
             title="温馨提示"
             cancel-txt="取消"
             sure-txt="确定"
             @on-confirm="confirmBind()">
      <div class="sure-info">
        确认要绑定这张银行卡吗？
      </div>
    </Confirm>
    <!-- 请输入短信验证码 begin -->
    <Confirm ref="msgPopFlag"
             title="请输入短信验证码"
             :close-on-confirm="false"
             cancel-txt="取消"
             sure-txt="确定"
             style="z-index: 10; position: relative"
             @on-cancel="confirmCancel('xzyhk;yzmqx;w228')"
             @on-confirm="dynamicCodeFun('xzyhk;yzmtj;w229')">
      <div class="cardList"
           style="padding:0;">
        <ul class="cardList-tb">
          <li class="hy-1px-b">
            <input v-model.trim="dynamicNum"
                   type="text"
                   maxlength="6"
                   placeholder="请输入验证码">
            <a v-show="sendAgainFlag"
               class="btnAgain"
               href="javascript:"
               @click="getDynamicCodeFun('xzyhk;hqyzm;w227')">重新发送</a>
            <em v-show="!sendAgainFlag"
                class="countDown">{{ countDownTime }}秒后重试</em>
          </li>
        </ul>
      </div>
      <aside class="setTip">
        验证码已发送至手机<span>{{ sItem.mobilePhone | formatePhone }}</span>，请查看并填写。
      </aside>
    </Confirm>
    <!-- 请输入短信验证码 end -->
    <Loading v-show="showLoading"></Loading>
  </div>
</template>

<script>
import utils from "../../util/utils"
import Loading from "../../components/loading/loading"
import Confirm from "../../components/confirm/index"
import { getBankImageByCode } from '../../assets/js/bankImages'
import { getBindListApi, bankcardBindApi } from '../../api/controller/bankCtr/index'
/* eslint-disable eqeqeq */
export default {
  name: "ActionBank",
  components: {
    Confirm,
    Loading,
  },
  filters: {
    formatePhone (val) {
      if (val) {
        return val.substr(0, 3) + '****' + val.substr(7, 4)
      } else {
        return ''
      }
    },
    formateBank (card, name) {
      if (card) {
        return name + '(' + card.substr(card.length - 4) + ')'
      } else {
        return name
      }
    },
  },
  props: {
    actionId: {
      type: [String, Number],
      default: '',
    },
    pdInfo: {
      type: Object,
      default: () => ({
        productId: '',//产品Id
        applyNo: '',//进件订单编号
        loanNo: '',//借款订单号
        stage: '',//1：借款阶段 2：还款阶段
      }),
    },
    actionTitle: {
      type: [String, Number],
      default: '',
    },
  },
  data () {
    return {
      isShow: false,
      showData: [],
      sItem: {},
      countDownTime: 60, // 验证码倒计时
      sendAgainFlag: false, // 重新发送Flag
      dynamicNum: '', // 短信验证码
      dynamicCodeFlag: true, // 验证码弹框确定Flag
      timer: null,
      showLoading: false,
    };
  },
  computed: {
  },
  activated () {
    let that = this
    that.showLoading = false

    that.showData = []
    that.sItem = {}
    that.countDownTime = 60 // 验证码倒计时
    that.sendAgainFlag = false // 重新发送Flag
    that.dynamicNum = '' // 短信验证码
    that.dynamicCodeFlag = true // 验证码弹框确定Flag
    that.timer = null

    that.$refs.bindComfirm.hide()
    that.$refs.msgPopFlag.hide()
  },
  methods: {
    selectedItem: function (item) {
      let that = this
      that.sItem = item
      that.appExecStatistic('xzyhk;yyyhk;w225')
      if (item.cardNo == that.actionId) { //1：可借款可还款 2：仅可借款 3：仅可还款
        that.$emit('on-select', item);
        that.isShow = false;
      } else {
        that.$refs.bindComfirm.show()
      }
    },
    confirmBind () {
      let that = this
      that.getDynamicCodeFun('')
    },
    // 短信验证码确定按钮
    dynamicCodeFun (eventId) {
      let that = this
      that.eventFun(eventId)
      if (that.isdynamicCode() && that.dynamicCodeFlag) {
        that.showLoading = true
        that.dynamicCodeFlag = false
        let formData = {
          applyNo: that.pdInfo.applyNo,
          bankCode: that.sItem.bankCode,
          bankMobilePhone: that.sItem.mobilePhone,
          bankName: that.sItem.bankName,
          cardMode: '1',
          cardNo: that.sItem.cardNo,
          loanNo: that.pdInfo.loanNo,
          stage: that.pdInfo.stage,
          verifyCode: that.dynamicNum,
        }

        bankcardBindApi(formData).then((data) => {
          that.showLoading = false
          that.dynamicCodeFlag = true
          let status = data.body.status
          if (status == 200) {
            // todo 绑卡成功
            that.$refs.msgPopFlag.hide()
            that.dynamicNum = ''
            that.dynamicCodeFlag = true
            that.$emit('on-select', that.sItem)
            that.isShow = false
          } else if (405 == status || 100 == status) {//验证码错误，验证码发送成功
            if (status == 100) {
              that.timeCountDownFunc()
            } else {
              utils.toastMsg(data.body.detail)
            }
            that.$refs.msgPopFlag.show()
            that.dynamicNum = ''
            that.dynamicCodeFlag = true
          } else {
            utils.toastMsg(data.body.detail)
            that.$refs.msgPopFlag.hide()
          }
        }, () => {
          that.showLoading = false
          that.dynamicCodeFlag = true
        })
      }
    },
    // 添加银行卡，获取验证码
    getDynamicCodeFun (eventId) {
      let that = this
      that.showLoading = true
      that.eventFun(eventId)
      let formData = {
        applyNo: that.pdInfo.applyNo,
        bankCode: that.sItem.bankCode,
        bankMobilePhone: that.sItem.mobilePhone,
        bankName: that.sItem.bankName,
        cardMode: '1',
        cardNo: that.sItem.cardNo,
        loanNo: that.pdInfo.loanNo,
        stage: that.pdInfo.stage,
      }
      bankcardBindApi(formData).then((data) => {
        that.showLoading = false
        that.dynamicCodeFlag = true
        let status = data.body.status
        if (status == 200) {
          // 绑卡成功
          that.$refs.msgPopFlag.hide()
          that.dynamicNum = ''
          that.dynamicCodeFlag = true
          that.$emit('on-select', that.sItem)
          that.isShow = false
        } else if (status == 405 || status == 100) {//验证码错误，验证码发送成功
          if (status == 100) {
            that.timeCountDownFunc()
          } else {
            utils.toastMsg(data.body.detail)
          }
          that.$refs.msgPopFlag.show()
          that.dynamicNum = ''
          that.dynamicCodeFlag = true
        } else {
          utils.toastMsg(data.body.detail)
          that.$refs.msgPopFlag.hide()
        }
      }, () => {
        that.showLoading = false
        that.dynamicCodeFlag = true
      })
    },
    // 验证码倒计时
    timeCountDownFunc: function () {
      let that = this
      let timer = that.timer
      that.sendAgainFlag = false
      clearInterval(timer)
      that.countDownTime = 60
      that.dynamicNum = ''
      that.timer = setInterval(() => {
        that.countDownTime--
        if (that.countDownTime <= 0) {
          that.sendAgainFlag = true
          that.countDownTime = 60
          clearInterval(that.timer)
        }
      }, 1000)
    },
    // 检查短信验证码
    isdynamicCode () {
      if (this.dynamicNum.length === 0) {
        // this.errorMsgFlag = true
        // this.errorMsg = '短信验证码不能为空'
        utils.toastMsg('短信验证码不能为空')
      } else if (this.dynamicNum.length < 6) {
        // this.errorMsgFlag = true
        // this.errorMsg = '请完整输入验证码'
        utils.toastMsg('请完整输入验证码')
      } else {
        return true
      }
    },
    confirmCancel (eventId) {
      let that = this
      that.appExecStatistic(eventId)
    },
    appExecStatistic (eventId) { // 埋点
      this.$appInvoked("appExecStatistic", {
        eventId: eventId,
        eventType: 0,
      }); //埋点
    },
    addBankItem: function (eventId) {
      let pdInfo = this.pdInfo
      this.appExecStatistic(eventId)
      this.$emit("on-addbank");
      this.$routerPush(`/addBank?productId=${pdInfo.productId}&applyNo=${pdInfo.applyNo}&loanNo=${pdInfo.loanNo}&stage=${pdInfo.stage}`)
      this.isShow = false;
    },
    bankLogoFun (bankCode) {// 银行logo
      return getBankImageByCode(bankCode)
    },
    show: function () {
      this.isShow = true;
      this.getBindListFun()
    },
    hide: function () {
      this.isShow = false;
      this.$emit("onHideAction");
    },
    bubbleSort: function (arr) {
      for (let i in arr) {
        let logo = this.bankLogoFun(arr[i].bankCode).logo
        arr[i].logoUrl = require(`../../assets/images/${logo}`)
      }
      return arr;
    },
    // 获取用户绑定的银行卡
    getBindListFun () {
      let that = this
      let formData = {
        applyNo: that.pdInfo.applyNo,
      }
      that.showLoading = true
      getBindListApi(formData).then((data) => {
        that.showLoading = false
        let showData = that.bubbleSort(data.body.userBankCardList)
        that.showData = showData
        if (showData && showData.length > 0) {
          that.$set(that.showData, 0, showData[0])
        }
      }).catch(() => {
        that.showLoading = false
      })
    },
    // 埋点
    eventFun (eventId) {
      if (eventId) {
        this.$appInvoked('appExecStatistic', { eventId: eventId })
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.cover {
  z-index: 97;
  width: 100%;
  height: 100%;
  bottom: 0;
  position: fixed;
}
.hy-confirm-mask {
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 1;
}
.actionsheet-layerchild {
  z-index: 2;
  width: 100%;
  bottom: 0;
  position: absolute;
  display: inline-block;
  background-color: #fff;
  font-size: rc(14);
  -webkit-overflow-scrolling: touch;
  // -webkit-animation-fill-mode: both;
  // animation-fill-mode: both;
  -webkit-animation-duration: 0.2s;
  animation-duration: 0.2s;
}

@keyframes actionsheet-anim-up {
  0% {
    opacity: 0;
    -webkit-transform: translateY(800px);
    transform: translateY(800px);
  }
  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    transform: translateY(0);
  }
}

.actionsheet-anim-up {
  -webkit-animation-name: actionsheet-anim-up;
  animation-name: actionsheet-anim-up;
}

.actionsheet-layerchild h3 {
  margin: 0;
  padding: 0 rc(10);
  height: rc(60);
  line-height: rc(60);
  font-size: rc(16);
  font-weight: 400;
  text-align: center;
}

.actionsheet-layerbtn span,
.actionsheet-layerchild h3 {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}

.actionsheet-layercont {
  position: relative;
  display: flex;
  line-height: rc(96);
  font-weight: bold;
  color: #333;
  font-size: rc(34);
  &::after {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: 1px;
    border-bottom: 1px solid #ddd;
    transform: scaleY(0.5);
  }
  .cancel {
    color: #666;
    margin: 0 rc(30) 0;
    white-space: nowrap;
  }
  .right {
    visibility: hidden !important;
  }
  .title {
    text-align: center;
    width: 100%;
  }
}
.actionsheet-layerbtn {
  display: flex;
  max-height: rc(490);
  overflow: scroll;
  font-size: 0;
  background-color: #f2f2f2;
  li {
    display: flex;
    justify-content: left;
    background-color: #fff;
    position: relative;
    align-items: center;
    padding: 0 rc(30) 0;

    .logo {
      width: rc(62);
      height: rc(62);
    }
    .logo-add {
      width: rc(54);
      height: rc(36);
    }
    .select {
      width: rc(36);
      height: rc(36);
      margin-right: rc(23);
    }
    .link {
      width: rc(15);
      height: rc(25);
    }
    span {
      display: block;
      flex: 1;
      line-height: rc(90);
      font-size: rc(30);
      cursor: pointer;
      color: #333;
      position: relative;
      text-align: left;
      margin-left: rc(27);
    }
  }
}

.actionsheet-layer-footer .actionsheet-layercont {
  background-color: #fff;
}

.actionsheet-layer-footer .actionsheet-layerbtn {
  display: block;
  height: rc(447);
  background: 0 0;
  border-top: none;
}

.actionsheet-layer-footer .actionsheet-layerbtn li {
  &::after {
    content: '';
    position: absolute;
    left: rc(30);
    right: 0;
    bottom: 0;
    height: 1px;
    border-bottom: 1px solid #ddd;
    transform: scaleY(0.5);
  }
  /*&:last-child{*/
  /*&:after{*/
  /*border-bottom: 0;*/
  /*}*/
  /*}*/
}
.sure-info {
  font-size: rc(30);
  line-height: rc(32);
  color: #444;
}
.cardList {
  padding: rc(0 36);
  margin-top: rc(40);
  font-size: rc(30);
  li {
    height: rc(98);
    display: flex;
    align-items: center;
    position: relative;
    width: 100%;

    > span {
      width: rc(170);
      color: #444;
    }

    > input {
      flex: 1;
    }
  }

  .countDown {
    font-size: rc(26);
    color: #aaa;
    text-align: right;
    display: block;
    position: absolute;
    right: 0;
    top: rc(30);
  }

  .btnAgain {
    font-size: rc(26);
    color: #ff5b00;
    text-align: right;
    position: absolute;
    right: 0;
    top: rc(30);
  }
}
.setTip {
  font-size: rc(26);
  color: #777777;
  text-align: left;
  margin-top: rc(20);

  span {
    color: #ff9d00;
  }
}
.hy-1px-b {
  position: relative;
  &::after {
    content: ' ';
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: 1px;
    color: #e7e7e7;
    border-bottom: 1px solid #e7e7e7;
    transform-origin: 0 100%;
    transform: scaleY(0.5);
  }
}
</style>
