<template>
  <div class="error-page"
       :class="{'has-tabbar': hasTabbar}">
    <img v-if="imgUrl"
         :src="imgUrl"
         class="error-page-icon"
         alt="icon">
    <div v-if="title"
         class="error-page-title"
         v-html="title"></div>
    <div v-if="btnTxt"
         class="error-page-btn jrcs-btn"
         @click="btnClick">
      {{ btnTxt }}
    </div>
  </div>
</template>
<script>
export default {
  name: 'DefaultBlankPage',
  props: {
    hasTabbar: { // 是否有tabbar。首页四个页面传true
      type: Boolean,
      default: false,
    },
    icon: { // 缺省页图标
      type: String,
      default: 'qsy_jzsb.png',
    },
    title: { // 缺省页文言
      type: [String, Number],
      default: '',
    },
    btnTxt: { // 缺省页按钮文言
      type: [String, Number],
      default: '',
    },
    btnClick: {
      type: Function,
      default: null,
    },
  },
  computed: {
    imgUrl () {
      if (this.icon) {
        return require(`APP_IMG/${this.icon}`) || ''
      }
      return ''
    },
  },
}
</script>
<style lang="scss" scoped>
.error-page {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #fff;
  z-index: 2;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  &.has-tabbar {
    bottom: rc(100);
  }
  .error-page-icon {
    width: rc(300);
    height: rc(300);
    margin-top: rc(-260);
  }
  .error-page-title {
    margin-top: rc(21);
    font-size: rc(28);
    line-height: rc(40);
    color: $color-text-sub;
    text-align: center;
  }
  .error-page-btn {
    margin-top: rc(35);
    height: rc(60);
    border-radius: rc(30);
    padding: rc(0 50);
    font-size: rc(28);
    color: #fff;
  }
}
</style>


