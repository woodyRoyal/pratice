<template>
  <LoanCard :type="type"
            :show-half-circle="false">
    <div class="card-head-infos">
      <img v-lazy="{src:icon}"
           alt=""
           class="chi-left">
      <div class="chi-right">
        <div class="chir-title">
          <slot name="title">
            {{ name }}
          </slot>
        </div>
        <div class="chir-tips"
             v-text="tips"></div>
      </div>
    </div>
    <div class="split-dotted-half-circle"></div>
    <slot></slot>
  </LoanCard>
</template>
<script>
import LoanCard from '@/components/card/index'

export default {
  components: {
    LoanCard,
  },
  props: {
    type: {
      type: [String, Number],
      default: '',
    },
    icon: {
      type: String,
      default: '',
    },
    name: {
      type: [String, Number],
      default: '',
    },
    tips: {
      type: [String, Number],
      default: '',
    },
  },
  // data () {
  //   return {
  //   }
  // },
  // 页面开启的时候调用
  // activated () {
  // },
  // methods: {
  // },
}
</script>
<style lang="scss" scoped>
.od-head-bg {
  height: rc(350);
  background-image: linear-gradient(83deg, #ff7523 0%, #ffbd74 100%);
}
.info-card {
  margin-top: rc(-110);
  margin-bottom: rc(20);
}
// 产品详情页使用。由于card加了阴影，需要改变左右半圆颜色。
.product-info-card {
  .split-dotted-half-circle {
    &::before {
      background-color: $linear-color-left;
    }
    &::after {
      background-color: $linear-color-right;
    }
  }
}
.card-head-infos {
  padding: rc(40 30);
  display: flex;
  align-items: flex-start;
  .chi-left {
    width: rc(80);
    height: rc(80);
    border-radius: rc(12);
    border: solid 1px #e6e6e6;
    margin-right: rc(30);
  }
  .chi-right {
    flex: 1;
  }
  .chir-title {
    font-size: rc(30);
    line-height: rc(42);
    font-weight: bold;
    color: #111111;
  }
  .chir-tips {
    margin-top: rc(7);
    font-size: rc(24);
    line-height: rc(33);
    color: #999;
    word-break: break-word;
  }
}
.split-dotted-half-circle {
  height: 1px;
  border-bottom: 1px dotted #e5e5e5;
  margin: rc(0 30);
  position: relative;
  &::before,
  &::after {
    content: '';
    position: absolute;
    width: rc(10);
    height: rc(20);
    top: 50%;
    transform: translateY(-50%);
    background-color: $bgColor;
  }
  &::before {
    left: rc(-30);
    border-radius: rc(0 20 20 0);
  }
  &::after {
    right: rc(-30);
    border-radius: rc(20 0 0 20);
  }
}
</style>
