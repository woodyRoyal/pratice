<template>
  <div class="hqwy-card"
       :class="[type, showHalfCircle ? 'show-half-circle' : '']">
    <slot></slot>
  </div>
</template>
<script>
export default {
  name: 'Card',
  props: {
    type: {
      type: [String, Number],
      default: '',
    },
    showHalfCircle: { // 是否展示卡片上两个半圆
      type: Boolean,
      default: false,
    },
  },
}
</script>
<style lang="scss" scoped>
.hqwy-card {
  margin-left: rc(36);
  margin-right: rc(36);
  background-color: #fff;
  // box-shadow: 0px rc(8) rc(16) 0px rgba(0, 0, 0, 0.05);
  border-radius: rc(10);
  position: relative;
  &.show-half-circle {
    min-height: rc(220);
    &::before,
    &::after {
      content: '';
      position: absolute;
      top: rc(168);
      width: rc(10);
      height: rc(20);
      background-color: #f2f2f2;
    }
    &::before {
      left: 0;
      border-radius: rc(0 20 20 0);
    }
    &::after {
      right: 0;
      border-radius: rc(20 0 0 20);
    }
  }
}
</style>


