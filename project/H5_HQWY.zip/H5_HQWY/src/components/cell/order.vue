<template>
  <div class="hy-cell">
    <div class="hy-cell-left"
         v-text="title"></div>
    <div class="hy-cell-right"
         :style="{justifyContent: rightAlignVal}">
      <slot></slot>
    </div>
  </div>
</template>
<script>
export default {
  name: 'HyCellOrder',
  props: {
    isLink: {
      type: Boolean,
      default: true,
    },
    title: {
      type: [String, Number],
      default: '',
    },
    rightAlign: {
      type: String,
      default: 'right',
    },
  },
  computed: {
    rightAlignVal () {
      let rightAlign = this.rightAlign
      return rightAlign === 'left' ? 'flex-start' : rightAlign === 'center' ? 'center' : 'flex-end'
    },
  },
}
</script>
<style lang="scss" scoped>
.hy-cell {
  margin-left: rc(40);
  padding: rc(26 40 26 0);
  position: relative;
  display: flex;
  align-items: center;
  line-height: rc(35);
  font-size: rc(30);
  .hy-cell-left {
    color: #333;
    margin-right: rc(20);
  }
  .hy-cell-right {
    position: relative;
    flex: 1;
    display: flex;
    align-items: center;
  }
}
</style>
