<template>
  <div class="hy-cell"
       :class="[showLine?'hy-1px-b':'', borderType==1?'bb-full':'', borderType==2?'bb-lr':'', type]">
    <div class="hy-cell-left"
         v-text="title"></div>
    <div class="hy-cell-right"
         :style="{justifyContent: rightAlignVal}">
      <slot></slot>
    </div>
    <img v-if="isLink"
         class="hy-link"
         :class="'arrow-' + direction"
         src="../../../static/images/arrow.png"
         alt="">
  </div>
</template>
<script>
export default {
  name: 'HyCell',
  props: {
    isLink: {
      type: Boolean,
      default: true,
    },
    showLine: {
      type: Boolean,
      default: true,
    },
    title: {
      type: [String, Number],
      default: '',
    },
    rightAlign: {
      type: String,
      default: 'right',
    },
    borderType: { // 下边线类型
      type: [String, Number],
      default: 0, // 默认0-距左边30，右边0；1-距左右0，2-距左右30
    },
    direction: { // 箭头方向
      type: String,
      default: 'right',
    },
    type: { // 自定义cell class，用于设置样式
      type: [String, Number],
      default: '',
    },
  },
  computed: {
    rightAlignVal () {
      let rightAlign = this.rightAlign
      return rightAlign === 'left' ? 'flex-start' : rightAlign === 'center' ? 'center' : 'flex-end'
    },
  },
}
</script>
<style lang="scss" scoped>
.hy-cell {
  margin-left: rc(30);
  padding: rc(26 30 26 0);
  position: relative;
  display: flex;
  align-items: center;
  line-height: rc(45);
  font-size: rc(30);
  &.bb-full {
    margin-left: 0;
    padding-left: rc(30);
  }
  &.bb-lr {
    margin-right: rc(30);
    padding-right: 0;
  }
  .hy-cell-left {
    color: #333;
    margin-right: rc(20);
  }
  .hy-cell-right {
    position: relative;
    flex: 1;
    display: flex;
    align-items: center;
  }
  .hy-link {
    width: rc(15);
    height: rc(26);
    margin-left: rc(20);
    vertical-align: middle;
    transition: transform 300ms;
    &.arrow {
      &-up {
        transform: rotate(-90deg);
      }
      &-down {
        transform: rotate(90deg);
      }
      &-left {
        transform: rotate(180deg);
      }
      &-right {
        transform: rotate(0deg);
      }
    }
  }
}
.hy-1px-b {
  position: relative;
  &::after {
    content: ' ';
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: 1px;
    color: #e7e7e7;
    border-bottom: 1px solid #e7e7e7;
    transform-origin: 0 100%;
    transform: scaleY(0.5);
  }
}
</style>
