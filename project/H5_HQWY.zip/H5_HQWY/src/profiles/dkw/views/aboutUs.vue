<template>
  <PageView title="关于我们">
    <div>
      <img class="logo"
           :src="require('APP_IMG/logo.png')">
      <p class="aboutTxt">
        2345贷款王是一个为个人消费者和小微企业推荐贷款、信用卡等金融产品的平台，具有智能搜索、精准推荐等特点。自上线以来，平台依托强大的技术、资金实力，一直致力于为广大用户提供安全、快捷、高效的金融信息服务。
      </p>
    </div>
    <div class="about-infor">
      <ul class="about-infor-list">
        <li class="dis-flex-row"
            @click="goServiceProtocol">
          <div class="flex-1">
            用户服务协议
          </div>
          <div class="flex-1 align-rignt">
            <img src="../../../../static/images/arrow.png"
                 alt="">
          </div>
        </li>
        <li class="dis-flex-row"
            @click="goyszc">
          <div class="flex-1">
            隐私政策
          </div>
          <div class="flex-1 align-rignt">
            <img src="../../../../static/images/arrow.png"
                 alt="">
          </div>
        </li>
        <li><span>版本信息：<em>{{ appVersion }}</em></span></li>
        <li><span>商务合作邮箱：<em>bd@huaqianwuyou.cn</em></span></li>
        <li>
          <span>客服电话：</span>
          <a class="flex-a">400-100-2345</a>
        </li>
      </ul>
    </div>
    <footer>
      <p>版权所有 &copy; 2345贷款王</p>
    </footer>
  </PageView>
</template>

<script>
export default {
  name: "AboutUs",
  data () {
    return {
      appVersion: "",
    };
  },
  activated () {
    var self = this;
    self.$appInvoked("appGetVersion", "", function (appVersion) {
      if (appVersion) {
        self.appVersion = "V " + appVersion;
      }
    });
  },
  methods: {
    goServiceProtocol () {
      this.$appInvoked("appExecStatistic", {
        eventId: "gywm;fwxy;w136",
        eventType: 0,
      }); //埋点
      this.$routerPush("/userServiceAgreement");
    },
    goyszc () {
      this.$routerPush("/yszc");
    },
  },
};
</script>

<style lang="scss" scoped>
.dis-flex-row {
  display: flex;
  display: -webkit-flex;
  flex-direction: row;
}

.flex-1 {
  flex: 1;
  -webkit-flex: 1;
}
.align-rignt {
  text-align: right;
}
.logo {
  width: rc(344);
  height: rc(100);
  display: block;
  margin: rc(110) auto rc(42) auto;
}

.aboutTxt {
  margin: 0 rc(30);
  font-size: rc(26);
  color: #777;
  line-height: 1.56444rem;
  text-align: justify;
  text-indent: 2em;
}

.about-infor-list {
  background: #fff;
  padding: 0 rc(30);
  margin-top: rc(48);
}

.about-infor-list li {
  line-height: rc(96);
  vertical-align: top;
  border-top: 1px solid #f2f2f2;
  display: flex;
  -moz-align-items: center;
  -webkit-align-items: center;
  align-items: center;
  font-size: rc(30);
  color: #333;
  position: relative;
}

.about-infor-list li:first-child {
  border-top: 0 none;
}

.about-infor > ul > li img {
  width: rc(14);
  height: rc(24);
  /*float: right;*/
  /*margin-top: 6%;*/
}

footer {
  text-align: center;
  font-size: rc(24);
  color: #999;
  bottom: 0;
  position: absolute;
  width: 100%;
  margin-bottom: rc(30);
}
</style>
