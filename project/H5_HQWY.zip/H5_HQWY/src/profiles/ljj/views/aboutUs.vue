<template>
  <PageView title="关于我们">
    <div class="dis-flex-row padding-top-110">
      <div class="app-icon flex-1">
        <img class=""
             :src="require('APP_IMG/logo.png')">
      </div>
    </div>
    <div class="dis-flex-row description">
      <div class="flex-1 color-999 ft-26">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;立即借是一个为个人消费者和小微企业推荐贷款、信用卡等金融产品的平台，具有智能搜索、精准推荐等特点。自上线以来，平台依托强大的技术、资金实力，一直致力于为广大用户提供安全、快捷、高效的金融信息服务。
      </div>
    </div>
    <div class="company-info">
      <ul>
        <li class="dis-flex-row"
            @click="goServiceProtocol('fwxy')">
          <div class="flex-1">
            用户服务协议
          </div>
          <div class="flex-1 align-rignt">
            <img class="link-arrow"
                 src="../../../../static/images/arrow.png"
                 alt="">
          </div>
        </li>
        <li class="dis-flex-row"
            @click="goServiceProtocol('yszc')">
          <div class="flex-1">
            隐私政策
          </div>
          <div class="flex-1 align-rignt">
            <img class="link-arrow"
                 src="../../../../static/images/arrow.png"
                 alt="">
          </div>
        </li>
        <!--<li>-->
        <!--<span>商务合作QQ：3481708277</span>-->
        <!--</li>-->
        <li>
          <span>商务合作邮箱：bd@huaqianwuyou.cn</span>
        </li>
        <!--<li>-->
        <!--<span>公司官网：<span>www.huaqianwy.com</span></span>-->
        <!--</li>-->
      </ul>
    </div>
    <footer>
      <p>版权所有 © 立即借</p>
    </footer>
  </PageView>
</template>

<script>
export default {
  name: "AboutUs",
  methods: {
    goServiceProtocol (type) {
      let eventId = '', url = ''
      if (type === 'fwxy') {
        eventId = 'gywm;fwxy;w136'
        url = '/userServiceAgreement'
      } else if (type === 'yszc') {
        url = '/yszc'
      }
      eventId && this.$appInvoked("appExecStatistic", {
        eventId: eventId,
        eventType: 0,
      })
      url && this.$routerPush(url);
    },
  },
};
</script>

<style lang="scss" scoped>
.dis-flex-row {
  display: flex;
  display: -webkit-flex;
  flex-direction: row;
}

.flex-1 {
  flex: 1;
  -webkit-flex: 1;
}

.padding-top-110 {
  padding-top: rc(110);
}

.bg-fff {
  background-color: #fff;
}

.color-999 {
  color: #999;
}

.ft-26 {
  font-size: rc(26);
}

.align-center {
  text-align: center;
}

.align-rignt {
  text-align: right;
}

.description {
  padding: rc(42) rc(30) rc(48);
  letter-spacing: 0;
}

.app-icon {
  vertical-align: middle;
  text-align: center;
  width: 100%;
}

.app-icon img {
  width: rc(344);
  height: rc(100);
}

.content {
  padding: rc(10) rc(30);
}

.company-info {
  padding: 0 rc(30);
  background: #fff;
}

.company-info > ul > li {
  border-bottom: solid #f2f2f2 1px;
  line-height: rc(96);
  font-size: rc(30);
  color: #333;
}

.company-info img.link-arrow {
  width: rc(10);
  height: rc(17);
  /*float: right;*/
  /*margin-top: 6%;*/
}

.company-web {
  color: #4996ff;
}

footer {
  text-align: center;
  position: absolute;
  bottom: rc(30);
  width: 100%;
  font-size: rc(24);
  color: #999;
  /*text-align: ;*/
}
</style>
