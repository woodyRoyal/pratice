<template>
  <PageView title="公告详情"
            class="bg-fff">
    <div class="content">
      <div class="title">
        “立即贷”已全新升级为“立即借”啦！
      </div>
      <div class="con">
        <p class="subtitle">
          尊敬的用户：
        </p>
        <p></p>
        <p class="ti-2">
          “立即贷”已全新升级为“立即借”啦！
        </p>
        <p class="ti-2">
          “立即借”是为个人和企业者提供贷款及信用卡的搜索、匹配、推荐等服务的信息平台。
        </p>
        <p class="ti-2">
          自上线以来，平台依托上市集团强大的技术、资金实力，致力于为广大用户提供安全、快捷、高效的金融服务。
        </p>
        <!-- <p class="ti-2">
          平台上的金融产品均来自于银行、消费金融公司、小额贷款公司、互联网金融公司等机构。
        </p> -->
        <p class="ti-2">
          本次版本升级，旨在为用户提供更丰富的金融产品和更好的服务。如果您有尚未结清的“立即贷”借款，登录即可还款！
        </p>
        <p class="ti-2">
          欢迎大家多多支持。
        </p>
        <p class="ta-r">
          立即借运营团队
        </p>
      </div>
      <!-- <div class="conimg"></div> -->
    </div>
  </PageView>
</template>
<style lang="scss" scoped="scoped">
.content {
  background: #fff;
  padding-left: rc(30);
  padding-right: rc(30);
  padding-top: rc(40);
  .title {
    font-size: rc(36);
    font-weight: bold;
    color: #111111;
    line-height: rc(50);
  }
}
.con {
  p {
    // margin-top: rc(30);
    font-size: rc(28);
    color: #333;
    line-height: rc(50);
    &.subtitle {
      margin: rc(30 0);
    }
    &.ta-r {
      text-align: right;
    }
    &.ti-2 {
      text-indent: 2em;
    }
  }
}
// .conimg {
//   width: 100%;
//   height: rc(517);
//   background: url(../../../static/images/1.jpg);
//   background-size: 100% 100%;
//   margin-top: rc(30);
// }
</style>