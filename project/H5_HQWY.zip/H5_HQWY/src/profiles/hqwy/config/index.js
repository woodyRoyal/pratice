import * as _env from '@/assets/js/util/env'
let env = _env.get()
if (env === 'dev') { // 本地开发环境指向
  env = 'd1'
}
let protocol = window.location.protocol + '//'
if (env !== 'prod') {
  protocol += `${env}-`
}
let config = {
  base: {
    env: env, // 当前系统运行环境
    appName: 'hqwy',
    appNameCh: '花钱无忧',
    platform: 1, // 平台:0-全部 1-花钱无忧 2-大圣钱包 3-无忧钱包 4-贷款王 5-H5聚合页 8-立即借
    productId: 902, // productId：901-贷款王，902-花钱无忧，903-立即借
    LJDPRODUCTID: 354, // 立即贷API产品productId，用于API全流程V2.0一期立即贷判断使用
    fullPath: `${protocol}static.huaqianwy.com/hqwy/v3/index.html`,
    companyName: '宁波盛盈金融信息服务有限公司',
    companyAddr: '浙江省宁波市大榭开发区永丰路128号28幢112-2室',
    url: {
      helpcenterHome: `${protocol}wsdaikuan.2345.com/xfjr/public/helpcenter/dist/#/home?1=1`, // 帮助中心首页
      helpcenterAsk: `${protocol}wsdaikuan.2345.com/xfjr/public/helpcenter/dist/#/ask?category=1185&img_require=1`, // 问题提交页面（对应帮助中心“我要投诉”问题）
      helpcenterQsList: `${protocol}wsdaikuan.2345.com/xfjr/public/helpcenter/dist/#/type?1=1`, // 问题选择页面
    },
    tel: {
      kf: '4008216161',
    },
    parameter: {
      smsType: '21', // 发送短信验证码类型(登录)
      passSmsType: '31', // 发送短信验证码类型(找回密码)
    },
    events: {
      linkSeqId: 5, // 支持API全流程产品链接ID：花钱无忧&无忧钱包5，贷款王6，立即借9
      creditCardlinkId: 1, // 信用卡埋点链接ID
    },
    module: {
      sytsfk: false, // 首页右上角投诉反馈入口
      syggTips: false, // 首页公告小黄条
    },
  },
}
export { config }
