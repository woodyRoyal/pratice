// 删除接口返回金额前带的单位￥
export function delUnit (amount) {
  if (amount) {
    amount = amount.replace('￥', '')
  }
  return amount
}

/**
 * 时间戳转日期
 * @param time
 * @param type 默认-分割,1:年月日分割
 * @returns {*}
 */
export function timeToDate (time, type) {
  let date = new Date(parseInt(time, 10))
  let Y = date.getFullYear() + (type === 1 ? '年' : '-')
  let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + (type === 1 ? '月' : '-')
  let D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate()) + (type === 1 ? '日' : ' ')
  return Y + M + D
}
