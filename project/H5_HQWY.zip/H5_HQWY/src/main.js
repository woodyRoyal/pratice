import './errorLog'
import Vue from 'vue'
import App from './App'
import router from './router'
import VueLazyLoad from 'vue-lazyload'
import store from './vuex/store'
import hyapp from 'hyapp-utils'
import Mixins from './plugins/mixins'
import PageViewPlugin from './plugins/pageView'
import * as filters from './filters'
import * as configCenter from './plugins/configCenter'
// 配置中心
Vue.prototype.$config = {
  get: configCenter.get,
}
// 配置中心
window.$config = {
  get: configCenter.get,
}
Vue.prototype.$transitionName = ''
// 工具类方法
Vue.use(hyapp.ToolsManual) // 手动初始化jsBridge
Vue.mixin(Mixins)
Vue.use(PageViewPlugin)
// 过滤器
Object.keys(filters).forEach((key) => {
  Vue.filter(key, filters[key])
})
/* global APP_NAME */
Vue.prototype.$APP_NAME = APP_NAME
// 封装localstorage
import * as storage from './storage/index'

global.storage = storage // localstorage

if (process.env.NODE_ENV === 'development') {
  require('./plugins/vconsole')
}

Vue.config.productionTip = false

import FastClick from 'fastclick'

FastClick.attach(document.body)

window.vm = window.vueApp = new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>',
})

// 重写路由切换方法，用于自定义动画
Vue.prototype.$routerPush = (url) => {
  if (url.indexOf('/login') === -1) {
    Vue.prototype.$transitionName = "slide-right";
  } else {
    Vue.prototype.$transitionName = "slide-bottom";
  }
  vueApp.$router.push(url);
};
Vue.prototype.$routerReplace = (url) => {
  if (url.indexOf('/login') === -1) {
    Vue.prototype.$transitionName = "slide-right";
  } else {
    Vue.prototype.$transitionName = "slide-bottom";
  }
  vueApp.$router.replace(url);
};
Vue.prototype.$routerGo = (n = -1) => {
  let transitionName = vueApp.$transitionName
  let path = vueApp.$route.path
  if (transitionName === 'slide-bottom' || path === '/login') {
    Vue.prototype.$transitionName = "slide-top";
  } else if (transitionName === 'slide-right') {
    Vue.prototype.$transitionName = "slide-left";
  }
  vueApp.$router.go(n);
};
Vue.prototype.$routerBack = () => {
  vueApp.$routerGo(-1);
};

Vue.use(VueLazyLoad, {
  error: window.vm.getCachedImages('productIcon') || require('APP_IMG/default.png'),
  loading: window.vm.getCachedImages('productIcon') || require('APP_IMG/default.png'),
})
window.setupWebViewJavascriptBridge(function (bridge) {
  // 通知原生jsBridge初始化成功
  window.noticeJSBridgeComplete()

  // bridge.registerHandler('webViewDidDisappear', function () { })
  // bridge.registerHandler('webViewDidAppear', function () { })
  // bridge.registerHandler('webViewWillDisappear', function () { })

  bridge.registerHandler('webViewWillAppear', function () {
    // ios第一次进来时候可能会报错，需要处理下
    window.vueApp && window.vueApp.webviewWillAppear && window.vueApp.webviewWillAppear()
    isIos && window.isLoginSuccessCloseWebview && window.isLoginSuccessCloseWebview()
    // window.vm.$appInvoked('appGetAjaxHeader', {}, function(headdata) {
    //   ajaxHeaders.os = headdata.os
    //   ajaxHeaders.channel = headdata.channel
    //   ajaxHeaders.city = headdata.city
    //   ajaxHeaders.deviceNo = headdata.deviceNo
    //   ajaxHeaders.packageName = headdata.packageName
    //   ajaxHeaders.terminalId = headdata.token
    //   ajaxHeaders.token = headdata.token || ''
    //   ajaxHeaders.userAgent = headdata.userAgent || ''
    //   ajaxHeaders.version = headdata.version
    //   ajaxHeaders.productHidden = headdata.productHidden || ''
    // })

    if (window.currentPageName && window.length > 0) {
      window.vm.$appInvoked('appOnPageBegin', { pageName: window.currentPageName })
      window.currentPageName = ''
    }
    if (window.location.href.indexOf('home') !== -1) {
      //判断一下当前页面是否为首页，如果是首页再去调用初始化swiper的代码，以免在其他tab调用导致swiper报错，下拉刷新卡死
      typeof window.updateSwiperStatus === 'function' && window.updateSwiperStatus()
    }
    var appAwake = localStorage.getItem('kAppEnterForegroundTime')
    if (window.vm.$needRefreshData(appAwake)) {
      window.location.reload()
    }
    var timestamp = new Date().getTime()
    localStorage.setItem('kAppEnterForegroundTime', timestamp)

  })
})

// if (process.env.NODE_ENV === 'production') {
//   // 全局错误统计
//   window.onerror = function (msg, url, line, col, error) {
//     // 没有URL不上报！上报也不知道错误
//     if (msg !== 'Script error.' && !url) {
//       return true
//     }
//     // 采用异步的方式
//     // 我遇到过在window.onunload进行ajax的堵塞上报O
//     // 由于客户端强制关闭webview导致这次堵塞上报有Network Error
//     // 我猜测这里window.onerror的执行流在关闭前是必然执行的
//     // 而离开文章之后的上报对于业务来说是可丢失的
//     // 所以我把这里的执行流放到异步事件去执行
//     // 脚本的异常数降低了10倍
//     setTimeout(function () {
//       var data = {}
//       // 不一定所有浏览器都支持col参数
//       col = col || (window.event && window.event.errorCharacter) || 0
//       data.url = window.location.href
//       data.line = line
//       data.col = col
//       data.errMessage = msg || error.message
//       data.msg = ''
//       if (error && error !== null && error.stack && error.stack !== null) {
//         // 如果浏览器有堆栈信息
//         // 直接使用
//         data.msg = error.stack.toString()
//       }
//       // console
//       // 把data上报到后台！
//       // console.log(data)
//       // 部分安卓手机app启动时候初始化时候会报错
//       if (data.msg.indexOf('WebViewJavascriptBridge') !== -1) {
//         return true
//       }
//       // console.log('错误收集 --- > ' + JSON.stringify(data));
//       window.vm.$appInvoked('appUploadException', { error: data }, '')
//     }, 0)
//     return true
//   }

//   // 添加版本信息
//   // let vData = new Date()
//   // let m = vData.getMonth() + 1 + ''
//   // let d = vData.getDay() + ''
//   // console.log(
//   //   "版本号:",
//   //   VERSION +
//   //     "_" +
//   //     (m.length === 1 ? "0" + m : m) +
//   //     "" +
//   //     (d.length === 1 ? "0" + d : d)
//   // );
// }
// 通知原生jsBridge初始化成功
window.noticeJSBridgeComplete = function () {
  setTimeout(function () {
    window.vm.$appInvoked('appJSBridgeComplete', {})
  }, 500)
}
// 初始化jsBridge
window.htmlInitializeJSBridge = function () {
  window.setupWebViewJavascriptBridge(function (bridge) {
    window.noticeJSBridgeComplete(bridge)
  })
}
// 判断jsBridge是否初始化成功
window.htmlJSBridgeIsComplete = function () {
  return window.WebViewJavascriptBridge && window.WebViewJavascriptBridge.callHandler ? true : false
}
