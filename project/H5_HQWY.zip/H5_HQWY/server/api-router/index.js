const Router = require('koa-router')
const router = new Router()

const orderListUrl = '/order/list'; // 查询订单列表接口
const loanEntryQueryUrl = '/loanEntry/query'; // 我的页面-完善贷款信息查询

// 查询订单列表接口
router.post(orderListUrl, async (ctx, next) => {
  let rst = await getOrderList(ctx)
  ctx.body = rst
});
router.post(loanEntryQueryUrl, async (ctx, next) => {
  let rst = await loanEntryQuery(ctx)
  ctx.body = rst
});

/**
 * @param ctx
 * @returns {Promise<any>}
 */
function getOrderList (ctx) {
  return new Promise((resolve) => {
    setTimeout(() => {
      return resolve({
        'respCode': '1000',
        'respMsg': '',
        'body': {
          ProdcutOrderInfoVo: [],
          currentIndex: 1,
          totalCount: 100,
          totalPage: 10
        }
      })
    }, 30)
  })
}
function loanEntryQuery (ctx) {
  return new Promise((resolve) => {
    setTimeout(() => {
      return resolve({
        'respCode': '1000',
        'respMsg': '',
        'body': [
          {authStatus: 1, authType: 'JCZL'},
          {authStatus: 1, authType: 'CA'},
          {authStatus: 1, authType: 'CON'},
          {authStatus: 0, authType: 'MOP'},
          {authStatus: 0, authType: 'OTH'}
        ]
      })
    }, 30)
  })
}

module.exports = router
