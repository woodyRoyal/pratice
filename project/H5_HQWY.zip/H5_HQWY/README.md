# 花钱无忧

> A Vue.js project

## Build Setup

```bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

## 注意事项

```
1、package.json配置当前版本号version字段（代码打包使用，例：2.4.0）
2、static/util.js修改版本号，规则：包名_v版本号.上线日期年月（例：hqwy_v2.4.0.1206）
3、static/cacheCfg.json更新缓存版本号（测试初期可改为-1，关闭缓存，避免频繁发包修改版本号）
4、新增接口如使用json格式传数据，需在src/api/http.js添加接口路径到jsonContentTypeList（联调前检查）
5、关于第4条，可使用post1方法，无需添加接口路径
6、index.html里直接引入的js不经过babel编译，不能使用ES6语法，部分机型不兼容（let、const、箭头函数、``拼接url等）。新的公共方法放入mixins.js，尽量不要放入util.js
```

## 打包步骤

```
1、cd H5_HQWY
2、npm run build
```

## 花钱无忧&贷款王开发步骤

```
1、master 分支拉取花钱无忧版本分支
2、dkw/master 分支拉取贷款王版本分支
3、基于花钱无忧版本分支进行开发
4、合并花钱无忧代码至贷款王版本分支
```

## 花钱无忧&贷款王开发注意事项

```
1、基于花钱无忧开发，完成后合并至贷款王。不能从贷款王合并至花钱无忧
2、assets/css/theme.scss 主题配置文件，若有新增，分支合并后注意贷款王是否有差异并修改
3、分支合并到贷款王后，删除 hqwy/ 目录，贷款王发布目录为 dkw/
```

## 花钱无忧&贷款王项目背景

```
1、花钱无忧、贷款王代码属于同一git、不同分支
2、花钱无忧代码 master、dev 分支；贷款王 dkw/* 分支；发布时需单独打包
3、花钱无忧打包部署目录：hqwy/dist (老版本，基本不继续维护)、hqwy/v3（3.0新版本，20190709上线）
4、贷款王打包部署目录：dkw/dist (老版本，基本不继续维护)、dkw/v7（7.0新版本，20190709上线）
```

# 设置环境变量`APP_NAME`默认是`hqwy`

```
APP_NAME=dkw npm run dev
```

# Windows 设置环境变量

npx cross-env APP_NAME=dkw npm run dev

# 设置环境变量`APP_NAME`默认是`hqwy`

APP_NAME=dkw npm run build

# Windows 设置环境变量

npx cross-env APP_NAME=dkw npm run build

# 示例

- `{{$APP_NAME}}` 获取设置的环境变量：`hqwy dkw`等等
- `APP_IMG` 用于`require`图片引入，直接指向当前环境下对应的目录：`src/assets/images/hqwy` -`$config` 分别在 vue 原型和 window 对象上注入`$config.get('key')`
- #`{$APP_NAME}` sass 文件配置的变量同环境变量

```js
<template>
  <div class="test">test-{{$APP_NAME}}
    <p>配置中心:{{$config.get('appName')}}</p>
    <p>配置中心:{{$config.get('url.aboutUs')}}</p>
    <p>配置中心:{{appName}}</p>
    <img :src="require('APP_IMG/test.png')">
    <div class="bg-test"></div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      appName:this.$config.get('appName')
    }
 },
}
</script>
<style lang="scss" scoped>
.test{
  color: $base-test;
  background: $color-test;
}
.bg-test{
  width: 100px;
  height: 100px;
  margin-top: 50px;
   background: url('~@/assets/images/#{$APP_NAME}/test.png') no-repeat;
}
</style>

```
