'use strict'
// Template version: 1.3.1
// see http://vuejs-templates.github.io/webpack for documentation.

const path = require('path')

const getDate = function () {
  let time = new Date()
  let y = time.getFullYear() + ''
  let m = time.getMonth() + 1 + ''
  let d = time.getDate() + ''
  let h = time.getHours() + ''
  let i = time.getMinutes() + ''
  let s = time.getSeconds() + ''
  return y.substring(2) + (m < 10 ? 0 + m : m) + (d < 10 ? 0 + d : d) + (h < 10 ? 0 + h : h) + (i < 10 ? 0 + i : i) + (s < 10 ? 0 + s : s)
}
function getAppName () {
  return process.env.APP_NAME || 'hqwy'
}
let APP_NAME = getAppName()
let buildIndex = `../../jrcs/${APP_NAME}/index.html`
let buildAssetsRoot = `../../jrcs/${APP_NAME}`
if (APP_NAME === 'hqwy') {
  buildIndex = `../../hqwy/v3/index.html`
  buildAssetsRoot = `../../hqwy/v3`
} else if (APP_NAME === 'dkw') {
  buildIndex = `../../dkw/v7/index.html`
  buildAssetsRoot = `../../dkw/v7`
}
module.exports = {
  APP_NAME: APP_NAME,
  dev: {
    // Paths
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',
    proxyTable: {
      '/': {
        //				target: 'http://172.17.16.115:10022/',
        // target: 'http://172.17.16.244:8081/',
        //				target: 'http://dev-static.huaqianwy.com/',
        target: 'http://t1-static.huaqianwy.com/',
        changeOrigin: true,
        pathRewrite: {
          '^/': '',
        },
        logLevel: 'debug',
      },
      // '/api': {
      //   //				target: 'http://172.17.16.115:10022/',
      //   // target: 'http://172.17.16.244:8081/',
      //   //				target: 'http://dev-static.huaqianwy.com/',
      //   target: 'http://172.17.16.163:8081/',
      //   changeOrigin: true,
      //   pathRewrite: {
      //     '^/': ''
      //   },
      //   logLevel: 'debug'
      // },
      // '/mem': {
      //   //				target: 'http://172.17.16.115:10022/',
      //   // target: 'http://172.17.16.244:8081/',
      //   //				target: 'http://dev-static.huaqianwy.com/',
      //   target: 'http://172.17.16.163:8082/',
      //   changeOrigin: true,
      //   pathRewrite: {
      //     '^/': ''
      //   },
      //   logLevel: 'debug'
      // }
    },

    // Various Dev Server settings
    host: '::', // can be overwritten by process.env.HOST
    port: 8088, // can be overwritten by process.env.PORT, if port is in use, a free one will be determined
    autoOpenBrowser: false,
    errorOverlay: true,
    notifyOnErrors: true,
    poll: false, // https://webpack.js.org/configuration/dev-server/#devserver-watchoptions-

    /**
     * Source Maps
     */

    // https://webpack.js.org/configuration/devtool/#development
    devtool: 'cheap-module-eval-source-map',

    // If you have problems debugging vue-files in devtools,
    // set this to false - it *may* help
    // https://vue-loader.vuejs.org/en/options.html#cachebusting
    cacheBusting: true,

    cssSourceMap: true,
  },

  build: {
    // Template for index.html
    index: path.resolve(__dirname, buildIndex),
    // Paths
    assetsRoot: path.resolve(__dirname, buildAssetsRoot),
    assetsSubDirectory: './dist' + getDate(),
    assetsPublicPath: './',

    /**
     * Source Maps
     */

    productionSourceMap: true,
    // https://webpack.js.org/configuration/devtool/#production
    devtool: '#source-map',

    // Gzip off by default as many popular static hosts such as
    // Surge or Netlify already gzip all static assets for you.
    // Before setting to `true`, make sure to:
    // npm install --save-dev compression-webpack-plugin
    productionGzip: false,
    productionGzipExtensions: ['js', 'css'],

    // Run the build command with an extra argument to
    // View the bundle analyzer report after build finishes:
    // `npm run build --report`
    // Set to `true` or `false` to always turn it on or off
    bundleAnalyzerReport: process.env.npm_config_report,
  },
}
