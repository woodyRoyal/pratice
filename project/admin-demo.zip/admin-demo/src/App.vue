<template>
  <div id="app">
    <p v-if="userPermission.action1">操作1</p>
    <p v-if="userPermission.action2">操作2</p>
    <p v-if="userPermission.action3">操作3</p>
    <p v-if="userPermission.action4">操作4</p>
    <p v-if="userPermission.action5">操作5</p>
    <p v-if="userPermission.action6">操作6</p>
  </div>
</template>

<script>
import axios from 'axios'
import { mapState } from 'vuex'
import setPermission from './config/permission'
export default {
  created () {
    this.testCors()
    // this.getCpus()
    // this.$store.dispatch('getCpus')
    this.setUserInfo()
    this.setUserMenu()
    this.setPermission()
  },
  computed: mapState(['userPermission']),
  methods: {
    // 设置权限
    setPermission () {
      let permission = setPermission('admin')
      // let permission = setPermission('user1')
      // let permission = setPermission('user2')
      this.$store.commit('userPermission', permission)
    },
    async getCpus () {
      console.log(await this.$api.getCpus())
    },
    test404 () {
      this.$api.getCpus()
      // 测试404
      axios.post(location.protocol + '//' + location.hostname + ':8088' + '/mock/api/getDevices', {
        phone: 'apple'
      }).then(res => {
        console.log(res)
      })
    },
    testCors () {
      // 测试跨域
      axios.post(location.protocol + '//' + location.hostname + ':3000' + '/mock/api/cpu', {
        phone: 'apple'
      }).then(res => {
        console.log(res)
      })
    },
    setUserInfo () {
      this.$store.commit('userInfo', { name: 'Edison', age: 11 })
      setTimeout(() => {
        this.$store.commit('userInfo', { name: 'Yang', age: 13 })
      }, 3000)
    },
    setUserMenu () {
      this.$store.commit('userMenu', [{ name: '菜单1' }, { name: '菜单2' }])
    }
  },
}
</script>

<style lang="scss">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
#nav {
  padding: 30px;
  a {
    font-weight: bold;
    color: #2c3e50;
    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
