import Vue from 'vue'
import Vuex from 'vuex'
import cache from './utils/storage'
import api from './api'

cache.initNamespace('__ADMIN__DEMO')

Vue.use(Vuex)

let initData = {
  // 样例，取值 this.$store.state.userInfo,提交 this.$store.commit('userInfo', {})
  userInfo: {
    persistence: true, // 是否持久化，是否存入localStorage
    default: {}
  },
  userMenu: { // 用户菜单
    persistence: true,
    default: {}
  },
  cpus: { // cpu核心数
    default: 0,
  },
  // 用户权限
  userPermission: {
    default: {}
  }
}

let state = {}

let mutations = {}

// 初始化state和mutation
for (let key in initData) {
  if (initData[key].persistence) {
    state[key] = cache.getFromLoacl(key) || cache.getFromSession(key, initData[key].default)
    mutations[key] = (storeState, obj) => {
      storeState[key] = obj
      cache.saveToLocal(key, obj)
      cache.saveToSession(key, obj)
    }
  } else {
    state[key] = cache.getFromLoacl(key, initData[key].default)
    mutations[key] = (storeState, obj) => {
      storeState[key] = obj
      cache.saveToSession(key, obj)
    }
  }
}

export default new Vuex.Store({
  state,
  mutations,
  actions: {
    async getCpus (context) {
      let cpuInfo = await api.getCpus()
      context.commit('cpus', cpuInfo.cpus)
    }
  }
})
