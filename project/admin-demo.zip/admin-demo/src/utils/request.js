import axios from 'axios'
axios.defaults.headers.common['Content-Type'] = 'application/json;charset=UTF-8'
// axios.defaults.baseURL = location.origin // 发送请求的基础url
axios.defaults.baseURL = 'http://localhost:8088' // 发送请求的基础url
axios.defaults.timeout = 5000 // 请求的超时时间
// axios.defaults.withCredentials = true // 需要跨域携带认证

// 添加请求拦截器
// axios.interceptors.response.use(config => {
//   return config
// })

// 添加一个响应拦截器
axios.interceptors.response.use(res => {
  // 在这里对返回的数据进行处理/
  if (res.data.code !== 0) {
    Notification.error({
      title: '请求出错',
      message: res.data.msg || '服务器请求出错！'
    })
    return Promise.reject(new Error(res.data.msg || '服务器错误'))
  }
  return res.data.data
}, (err) => {
  return Promise.reject(err)
})

/***
 *  函数的参数options为axios的配置
 *  method => 方法名 "POST"等
 *  url => 路径,实际调用时传type即可，即为urlDict的key
 *  data => 数据的对象
 *  调用前将type值转为对应的url
 * **/
let request = (options) => {
  options.headers = options.headers || {}
  options.method = options.method || 'get'
  if (options.method.toUpperCase() === 'GET') {
    options.params = options.data
  }
  return axios(options)
}

export default request
