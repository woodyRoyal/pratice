// 定义所有需要控制权限的操作列表
/*eslint-disable*/
const actionMap = {
  action1: '操作1',
  action2: '操作2',
  action3: '操作3',
  action4: '操作4',
  action5: '操作5',
  action6: '删除',
}

const userPermission = {
  admin: ['action1', 'action2', 'action3', 'action4', 'action5', 'action6'],
  user1: ['action1', 'action2', 'action3'],
  user2: ['action1', 'action4', 'action5', 'action6']
}

const setPermission = (user) => {
  let arr = userPermission[user]
  let permission = {}
  arr.forEach(item => {
    permission[item] = true
  })
  return permission
}

export default setPermission
