import request from '../utils/request'

export default {
  getCpus: data => {
    return request({
      data,
      url: '/mock/api/cpu',
      method: 'post'
    })
  }
}
