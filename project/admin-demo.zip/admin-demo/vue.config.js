const packageConfig = require('./package.json')
const mock = require('./mock/index')

module.exports = {
  outputDir: packageConfig.name, // 构建目录名称
  filenameHashing: true,
  lintOnSave: true, // 保存立即检查
  // 开发运行相关配置
  devServer: {
    before (app) {
      mock(app)
    },
    open: false, // 自动打开浏览器
    port: 8088, // 端口
    proxy: {
      '/warn-api': {
        // target: 'http://172.17.19.35:8088', // 王辉环境
        target: 'http://test.hulk.alert.bumblebee.2345.cn', // 测试环境
        ws: false, // 是否启用websockets,此项目不存在ws连接
        changOrigin: true, // 是否将请求header中的origin修改为目标地址
        pathRewrite: {
          '^/warn-api': ''
        }
      }
    }, // 转发代理配置
    // 浏览器 overlay（刷新） 同时显示eslint的警告和错误
    overlay: {
      warnings: true,
      errors: true
    }
  },
  runtimeCompiler: true, // 运行时是否需要编译
}
