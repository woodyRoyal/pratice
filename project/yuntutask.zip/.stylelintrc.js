module.exports = {
  extends: [
    '@ued2345/stylelint-config'
  ],
  rules: {
    'linebreaks': null,     // Specify unix or windows linebreaks.
  },

}
