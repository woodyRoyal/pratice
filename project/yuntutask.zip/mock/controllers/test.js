module.exports = {
  '/mock/api/cpu': () => {
    return {
      100: 1,
      50: 2
    }
  },
  '/mock/api/phone': {
    'GET': {
      info: '这是一个手机,请求类型get'
    },
    'POST': {
      info: '这是一个手机，请求类型post'
    }
  },
  '/mock/api/brand': {
    'GET': function (req, res) {
      // console.log('query参数：', req.query)
      // console.log('body参数：', req.query)
      if (req.query.brand === 'xiaomi') {
        return {
          info: '这是一个国产品牌'
        }
      } else if (req.query.brand === 'apple') {
        return {
          info: '这是一个美国品牌'
        }
      } else {
        return {
          info: '这是一个未知品牌'
        }
      }
    }
  }
}
