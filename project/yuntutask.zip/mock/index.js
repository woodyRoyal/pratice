const cors = require('cors')
const bodyParser = require('body-parser')
// const chalk = require('chalk')
const products = require('./controllers/test')

function mock (app) {
  app.use(cors())
  app.use(bodyParser.urlencoded({ extended: false }))
  app.use(bodyParser.json())
  app.use('/mock/api/*', (req, res) => {
    console.log('请求路径:', req.baseUrl)
    console.log('请求方法:', req.method)
    // console.log('请求query:', req.query)
    // console.log('请求体:', req.body)
    // console.log('请求Content-Type:', req.get('Content-Type'))
    // console.log('授权信息:', req.get('Authorization'))
    if (products[req.baseUrl]) {
      let resData = products[req.baseUrl]
      if (resData[req.method.toUpperCase()]) {
        resData = resData[req.method]
      }
      if (typeof resData === 'function') {
        resData = resData(req)
      }
      res.json({
        code: 0,
        data: resData,
        message: '',
        timestamp: Date.now()
      })
    } else {
      res.status(404)
      res.end()
    }
  })
  // app.get('/api/*', function (req, res) {
  //   console.log('请求路径:', req.baseUrl)
  //   console.log('请求方法:', req.method)
  //   console.log('请求query:', req.query)
  //   console.log('请求体:', req.body)
  //   console.log('请求Content-Type:', req.get('Content-Type'))
  //   console.log('授权信息:', req.get('Authorization'))
  //   res.json({
  //     code: 0,
  //     data: ['', 1],
  //     error: '',
  //     timestamp: Date.now()
  //   })
  // })
  // app.post('/api/*', function (req, res) {
  //   console.log('请求路径:', req.baseUrl)
  //   console.log('请求方法:', req.method)
  //   console.log('请求query:', req.query)
  //   console.log('请求体:', req.body)
  //   console.log('请求Content-Type:', req.get('Content-Type'))
  //   console.log('授权信息:', req.get('Authorization'))
  //   res.json({
  //     code: 0,
  //     data: [2, 3],
  //     error: '',
  //     timestamp: Date.now()
  //   })
  // })

  // 如果需要模拟跨域请求
  // const port = 3000
  // app.listen(port, () => {
  //   console.log(chalk.green(`\nMock service is running at port ${port}`))
  // })
}
module.exports = mock
