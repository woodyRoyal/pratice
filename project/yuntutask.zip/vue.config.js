let isDev = process.env.VUE_APP_ENV === 'dev'
let isProd = process.env.VUE_APP_ENV === 'prod'
const packageConfig = require('./package.json')
const mock = require('./mock/index')

module.exports = {
  publicPath: isDev ? '/' : '', // 二级目录路径
  outputDir: packageConfig.name, // 构建目录名称
  productionSourceMap: !isProd, // 生产环境sourceMap
  css: {
    sourceMap: !isProd // CSS sourceMap
  },
  filenameHashing: true,
  lintOnSave: isDev, // 保存立即检查
  // 开发运行相关配置
  devServer: {
    before (app) {
      mock(app)
    },
    open: false, // 自动打开浏览器
    port: 8086, // 端口
    proxy: {
      '/yuntutask': {
        target: 'http://test.example.cn', // 测试环境
        ws: false, // 是否启用websockets,项目存在ws连接时开启
        changOrigin: true, // 是否将请求header中的origin修改为目标地址
        pathRewrite: {
        }
      }
    }, // 转发代理配置
    // 浏览器 overlay（刷新） 同时显示eslint的警告和错误
    overlay: {
      warnings: true,
      errors: true
    }
  },
  runtimeCompiler: true, // 运行时是否需要编译
}
