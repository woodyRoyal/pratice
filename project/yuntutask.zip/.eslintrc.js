module.exports = {
  root: true,
  env: {
    node: true
  },
  'extends': [
    '@ued2345',
    'plugin:vue/essential',
    // '@vue/standard'
  ],
  rules: {
    'no-console': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    // 忽略对象数组末尾的逗号
    // 'comma-dangle': 'off',
  },
  parserOptions: {
    parser: 'babel-eslint'
  }
}
