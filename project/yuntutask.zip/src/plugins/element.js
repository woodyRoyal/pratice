import Vue from 'vue'
// import 'element-ui/lib/theme-chalk/index.css'
import './element-variables.scss'

// 全局引入
import Element from 'element-ui'
Vue.use(Element, { size: 'small', zIndex: 3000 })
