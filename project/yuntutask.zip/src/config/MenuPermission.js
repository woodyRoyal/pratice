const PermissionMenu = [
  {
    name: '页面排版',
    icon: 'el-icon-document',
    children: [
      {
        path: '/form/baseForm',
        name: '基础表单',
      },
      {
        path: '/form/listForm',
        name: '卡片列表',
      },
      {
        path: '/form/tabForm',
        name: '查询表格',
      }
    ]
  },
  {
    name: '自定义组件',
    icon: 'el-icon-data-analysis',
    children: [
      {
        path: '/myComponents/radio',
        name: '选框类',
      }
    ]
  }
]

export default PermissionMenu
