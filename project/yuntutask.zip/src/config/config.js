let timeSelect = []
for (let i = 0; i < 25; i++) {
  i < 10 ? timeSelect.push(`0${i}:00:00`) : timeSelect.push(`${i}:00:00`)
}
export { timeSelect }




