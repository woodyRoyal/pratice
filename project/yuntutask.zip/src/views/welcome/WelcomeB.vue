<template>
  <PageContentWrapper>
    <div class="welcome">
      <div class="welcome-desc">
        <h1 class="welcome-inner-title">欢迎使用</h1>
        <p class="welcome-inner-content">Octopus Pro</p>
        <p class="welcome-inner--tip">-- 环科路555号最具影响力的中后台前端方案</p>
      </div>
      <div class="welcome-image"></div>
    </div>
  </PageContentWrapper>
</template>

<script>
import PageContentWrapper from '../../layout/PageContentWrapper'

export default {
  name: 'WelcomeB',
  components: {
    PageContentWrapper,
  }
}
</script>

<style scoped lang="scss">
	.welcome {
		background: #fff;
		height: 100%;
		display: flex;
		justify-content: center;
		align-items: center;

		.welcome-desc {
			position: relative;
			bottom: 40px;

			.welcome-inner-title {
				font-size: 30px;
				line-height: 42px;
				color: #333;
			}

			.welcome-inner-content {
				font-size: 44px;
				line-height: 62px;
				color: #409eff;
			}
		}

		.welcome-inner--tip {
			text-align: right;
			margin-top: 20px;
			font-size: 12px;
			color: #999;
		}

		.welcome-image {
			margin-left: 105px;
			width: 371px;
			height: 438px;
			background-image: url('../../assets/image/welcome-pic-2.png');
		}
	}
</style>
