<template>
  <PageContentWrapper>
    <div class="welcome">
      <div class="welcome-inner">
        <h1 class="welcome-inner-title">WELCOME</h1>
        <p class="welcome-inner-content">欢迎使用 Octopus Pro 系统</p>
        <p class="welcome-inner--tip">-- 环科路555号最具影响力的中后台前端方案</p>
      </div>
    </div>
  </PageContentWrapper>
</template>

<script>
import PageContentWrapper from '../../layout/PageContentWrapper'

export default {
  name: 'WelcomeA',
  components: {
    PageContentWrapper
  }
}
</script>

<style scoped lang="scss">
	.welcome {
		width: 100%;
		height: 100%;
		background: #fff;
		display: flex;
		justify-content: center;
		align-items: center;

		.welcome-inner {
			width: 649px;
			height: 405px;
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			background-image: url('../../assets/image/welcome-pic-1.png');

			.welcome-inner-title {
				font-size: 44px;
				line-height: 62px;
				letter-spacing: 4px;
				color: #409eff;
			}

			.welcome-inner-content {
				font-size: 22px;
				letter-spacing: 2px;
				color: #666;
			}

			.welcome-inner--tip {
				position: relative;
				right: -30px;
				text-align: right;
				margin-top: 20px;
				font-size: 12px;
				color: #999;
			}
		}
	}
</style>
