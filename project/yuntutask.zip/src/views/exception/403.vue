<template>
  <PageContentWrapper>
    <div class="exception">
      <Exception :code="403"/>
    </div>
  </PageContentWrapper>
</template>

<script>
import PageContentWrapper from '../../layout/PageContentWrapper'
import Exception from '../../components/Exception'
export default {
  name: 'fot',
  components: {
    PageContentWrapper,
    Exception
  }
}
</script>

<style scoped lang="scss">
  .exception {
    height: 100%;
    background: white;
    text-align: center;
  }
</style>
