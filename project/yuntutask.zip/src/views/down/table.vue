<template>
  <div>
    <PageContentWrapper>
      <PageItemViewer :title="'试用中心/唤醒数据报表'">
        <el-form :inline="true"
                 :model="queryForm"
                 size="mini"
                 class="demo-form-inline"
                 style="margin-top:20px">
          <el-form-item label="选择">
            <el-date-picker v-model="queryForm.time"
                            style="width:350px;"
                            type="daterange"
                            value-format="yyyy-MM-dd"
                            range-separator="至"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期"
                            align="right">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="
                            ">
            <el-button type="primary
                            "
                       @click="fetchData
                            ">查询</el-button>
          </el-form-item>
        </el-form>
        <el-table :data="tableData"
                  border>
          <el-table-column fixed
                           prop="date"
                           label="日期">
          </el-table-column>
          <el-table-column prop="name"
                           label="文件名称">
          </el-table-column>
          <el-table-column prop="name"
                           label="创建时间">
          </el-table-column>
          <el-table-column prop="name"
                           label="生成状态">
          </el-table-column>
          <el-table-column prop="name"
                           label="操作">
          </el-table-column>

          <el-table-column label="操作"
                           width="100">
            <template slot-scope="scope">
              <el-button @click="handleClick(scope.row)"
                         type="text"
                         size="small">下载</el-button>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination class="pagination"
                       :current-page="pageable.pageNum"
                       :page-sizes="pageable.pageSizes"
                       :page-size="pageable.pageSize"
                       layout="total, sizes, prev, pager, next, jumper"
                       :total="pageable.total"
                       @size-change="handleSizeChange"
                       @current-change="handleCurrentChange">
        </el-pagination>
      </PageItemViewer>
    </PageContentWrapper>
  </div>
</template>

<script>
import goldApi from '../../api/goldApi.js'
export default {
  name: 'awakenTable',
  components: {
    //统计展示组件
    // 表格分页一体化组件
    //  二次封装多选组件
  },
  data () {
    return {
      // 表格是否loding
      isLoading: false,
      // 表格数据
      tableData: [],
      // 统计
      summaryObj: {},
      // 分页数据
      pageable: {
        pageNum: 1,
        pageSize: 100,
        pageSizes: [20, 50, 100],
        total: 0,
      },
      queryForm: {
        Keyword: '',
        time: [],
        startTime: '',
        endTime: '',
        value1: [],
      },
      selectList: {
        list1: [],
        list2: [],
        list3: [],
        list4: [],
      }
    }
  },
  methods: {
    downEmit () {
      //
    },
    handleClick () {
      //
    },
    async  fetchData (pageable) {
      if (pageable.pageNum) {
        this.pageable.pageNum = pageable.pageNum
        this.pageable.pageSize = pageable.pageSize
      }
      let data = {
        ...this.queryForm,
        pageNum: this.pageable.pageNum,
        pageSize: this.pageable.pageSize,
      }
      try {
        let res = await goldApi.fetchTable(data)
        this.tableData = res.result.list
        this.pageable.total = res.result.total
      } catch (e) {
        this.tableData = []
      } finally {
        this.isLoading = false
      }
      //
    },
    // changeMul (value, type) {
    //   console.log(value)
    //   console.log(type)
    // },
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert('submit!')
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm (formName) {
      this.$refs[formName].resetFields()
    },
    handleSizeChange (val) {
      this.pageable.pageSize = val
      this.fetchData()
    },
    handleCurrentChange (val) {
      this.pageable.pageNum = val
      this.fetchData()
    },
  },

}
</script>
<style lang="scss" scoped>
.pagination {
  display: flex;
  justify-content: flex-end;
}
</style>