<template>
  <div>
    <PageContentWrapper>
      <PageItemViewer :title="'试用中心/唤醒数据报表'">
        <el-form :inline="true"
                 :model="queryForm"
                 size="mini"
                 class="demo-form-inline"
                 style="margin-top:20px">
          <el-form-item label="日期筛选">
            <el-date-picker v-model="queryForm.time"
                            style="width:350px;"
                            type="daterange"
                            value-format="yyyy-MM-dd"
                            range-separator="至"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期"
                            align="right">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="时段筛选">
            <el-select v-model="queryForm.startTime">
              <el-option v-for="item in selectList.timeSelect"
                         :value="item"
                         :label="item"
                         :key="item">
              </el-option>
            </el-select>
            至
            <el-select v-model="queryForm.endTime">
              <el-option v-for="item in selectList.timeSelect"
                         :value="item"
                         :label="item"
                         :key="item">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="应用筛选">
            <multipleSelect :parentValue.sync="queryForm.value1
                            "
                            :selectList="selectList.list1
                            "></multipleSelect>
          </el-form-item>
          <el-form-item>
            <multipleSelect :parentValue.sync="queryForm.value1"
                            placeholder="选择星球任务ID">

            </multipleSelect>
          </el-form-item>
          <el-form-item>
            <multipleSelect placeholder="选择位置"
                            :parentValue.sync="queryForm.value1
                            "></multipleSelect>
          </el-form-item>
          <el-form-item>
            <multipleSelect placeholder="选择渠道"
                            :parentValue.sync="queryForm.value1
                            "></multipleSelect>
          </el-form-item>
          <el-form-item>
            <multipleSelect placeholder="选择唤醒对象"
                            :parentValue.sync="queryForm.value1
                            "></multipleSelect>
          </el-form-item>
          <el-form-item>
            <multipleSelect placeholder="选择任务类型"
                            :parentValue.sync="queryForm.value1
                            "></multipleSelect>
          </el-form-item>
          <el-form-item label="
                            ">
            <el-button type="primary
                            "
                       @click="fetchData
                            ">查询</el-button>
            <el-button type="primary
                            "
                       @click="downEmit
                            ">下载</el-button>
          </el-form-item>
        </el-form>
        <TableCom :is-loading="isLoading
                            "
                  :columns="tableColumns
                            "
                  :data="tableData
                            "
                  :isShowSummary="true
                            "
                  :summaryObj='summaryObj'
                  :is-show-pagination="true
                            "
                  :pageable="pageable
                            "
                  @getTableData="fetchData
                            "
                  style="margin-top:20px
                            ">
        </TableCom>
      </PageItemViewer>
    </PageContentWrapper>
  </div>
</template>

<script>
import TableCom from '../../components/tableCom/index'
import goldApi from '../../api/goldApi.js'
import multipleSelect from '../../components/multipleSelect/index'
import { tableColumns } from './config.js'
import { timeSelect } from '../../config/config.js'
export default {
  name: 'awakenTable',
  components: {
    //统计展示组件
    // 表格分页一体化组件
    TableCom,
    //  二次封装多选组件
    multipleSelect
  },
  data () {
    return {
      // 表格是否loding
      isLoading: false,
      // 表格数据
      tableData: [],
      // 统计
      summaryObj: {},
      //表格列
      tableColumns: tableColumns,
      // 分页数据
      pageable: {
        pageNum: 1,
        pageSize: 100,
        pageSizes: [20, 50, 100],
        total: 0,
      },
      queryForm: {
        Keyword: '',
        time: [],
        startTime: '',
        endTime: '',
        value1: [],
      },
      selectList: {
        timeSelect: timeSelect,
        list1: [],
        list2: [],
        list3: [],
        list4: [],
      }
    }
  },
  methods: {
    downEmit () {
      //
    },
    async  fetchData (pageable) {
      if (pageable.pageNum) {
        this.pageable.pageNum = pageable.pageNum
        this.pageable.pageSize = pageable.pageSize
      }
      let data = {
        ...this.queryForm,
        pageNum: this.pageable.pageNum,
        pageSize: this.pageable.pageSize,
      }
      try {
        let res = await goldApi.fetchTable(data)
        this.tableData = res.result.list
        this.pageable.total = res.result.total
      } catch (e) {
        this.tableData = []
      } finally {
        this.isLoading = false
      }
      //
    },
    // changeMul (value, type) {
    //   console.log(value)
    //   console.log(type)
    // },
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert('submit!')
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm (formName) {
      this.$refs[formName].resetFields()
    }
  },

}
</script>
