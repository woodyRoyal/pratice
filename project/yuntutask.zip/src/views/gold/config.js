export const tableColumns = [
  {
    label: '日期',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宿主名称',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '星球任务id',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '金币数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '金币PV',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },

  {
    label: '金币UV',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
]