<template>
  <PageWrapper>
    <PageContentWrapper class="card-wrapper">
      <div class="card" v-for="(item, index) in names" :key="index">
        <div class="card-inner">
          <div class="card-content">
            <p class="card-name" :style="'background:' + item.background">{{item.name}}</p>
            <div>
              <p style="font-size: 18px; line-height: 24px; color: #333;">{{item.title}}</p>
              <p style="font-size: 16px; color: #666; line-height: 44px;">{{item.content}}</p>
            </div>
          </div>
          <div class="action">
            <el-button type="text">操作一</el-button>
            <el-button type="text">操作二</el-button>
          </div>
        </div>
      </div>

    </PageContentWrapper>
  </PageWrapper>
</template>

<script>
import PageWrapper from '../../layout/PageWrapper'
import PageContentWrapper from '../../layout/PageContentWrapper'

export default {
  name: 'form2',
  data () {
    return {
      names: [{
        name: '二',
        background: '#26ADF3',
        title: '二三四五',
        content: '我们坚信：新科技改变生活，为创造美好生活而不懈努力'
      }, {
        name: '三',
        title: '坦诚',
        background: '#BC0D30',
        content: '客观如实，不忽悠、不糊弄、不隐瞒，不增不减，好的不多说，坏的不少说'
      }, {
        name: '四',
        title: '简单',
        background: '#7B50B3',
        content: '为人处事，简单是真理，把复杂的事情变简单，才能抓住重点'
      }, {
        name: '五',
        title: '直接',
        background: '#56D4FC',
        content: '有话直说，直达目的、不绕弯、不留情，直接说问题、直接说方案、直接说结果'
      }]
    }
  },
  methods: {
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert('submit!')
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm (formName) {
      this.$refs[formName].resetFields()
    }
  },
  components: {
    PageWrapper,
    PageContentWrapper
  }
}
</script>

<style scoped lang="scss">
	.card {
		display: inline-block;
		width: 50%;
		box-sizing: border-box;

		&:nth-child(n + 3) {
			margin-top: 20px;
		}

		&:nth-child(2n) {
			padding-left: 10px;
		}

		&:nth-child(2n - 1) {
			padding-right: 10px;
		}

		.card-inner {
			display: flex;
			flex-direction: column;
			background: white;
			height: 200px;
			border: 1px solid rgba(0, 0, 0, 0.1);
			border-radius: 4px;

			&:hover {
				transition: all 0.3s;
				box-shadow: 0 2px 8px rgba(0, 0, 0, 0.09);
			}

			.card-content {
				flex: 1;
				display: flex;
				padding: 20px;

				.card-name {
					margin-right: 20px;
					width: 48px;
					height: 48px;
					border-radius: 50%;
					background: #56d4fc;
					flex-shrink: 0;
					text-align: center;
					line-height: 48px;
					font-size: 28px;
					color: white;
				}
			}

			.action {
				border-top: 1px solid #ddd;
				height: 50px;
				flex-shrink: 0;
				display: flex;
				justify-content: space-around;
				align-items: center;
			}
		}
	}
</style>
