export const totalColumns = [ // 表头
  {
    label: '日期',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: true
  },
  {
    label: '宿主',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: true
  },
  {
    label: '唤醒对象',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: true
  },
  {
    label: '位置来源',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: true
  },
  {
    label: '页面曝光次数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '页面UV',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务曝光数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务点击数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },

  {
    label: '点击率',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务弹窗曝光',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务弹窗点击',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务弹窗点击率',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '唤醒次数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '唤醒成功数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '唤醒成功率',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '总金币数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '总发金币次数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '总金币UV',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务发cheat数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务发金币次数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务奖励弹窗',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务发金币率',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务参与用户数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务金币数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宝箱1发cheat数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宝箱1发金币次数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宝箱1发金币率',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宝箱1弹窗',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宝箱1参与用户数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宝箱1金币数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宝箱2发cheat数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宝箱2发金币次数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宝箱2发金币率',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宝箱2弹窗',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宝箱2参与用户数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宝箱2金币数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: 'awake接口失败次数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '投放任务数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
]


export const tableColumns = [
  {
    label: '日期',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: true
  },
  {
    label: '任务ID',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务名称',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '宿主名称',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '曝光PV',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },

  {
    label: '点击PV',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '点击率',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '开始下载UV',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '下载成功UV',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '安装成功UV',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '激活成功UV',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '下载率',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '下载成功率',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '安装成功率',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '激活成功率',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '金币数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '参与用户数',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务弹窗曝光',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务弹窗点击',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务弹窗点击率',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
  {
    label: '任务奖励弹窗',
    prop: 'merchantOrderNumber',
    align: 'center',
    fixed: false
  },
]