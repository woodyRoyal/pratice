<template>
  <div class="login">
    <div class="login-header">
      <div class="login-header-title">Octopus Pro</div>
      <div class="login-header-desc">A股上市公司旗下产品产品简介产品简介产品简介</div>
    </div>
    <div class="login-wrapper">
      <template v-if="pageType === 1">
        <LoginDialog />
        <div class="login-type-switch">还没有账户？<el-button class="login-type-switch-btn" type="text" @click="pageType = 2">立即注册</el-button></div>
      </template>
      <template v-else-if="pageType === 2" >
        <SignupDialog />
        <div class="login-type-switch">已有账户？<el-button class="login-type-switch-btn" type="text" @click="pageType = 1">立即登录</el-button></div>
      </template>
    </div>
  </div>
</template>

<script>
import LoginDialog from '../../layout/LoginDialog'
import SignupDialog from '../../layout/SignupDialog'
export default {
  name: 'login',
  data () {
    return {
      pageType: 1, // 1登录，2注册
    }
  },
  components: {
    LoginDialog,
    SignupDialog
  }
}
</script>

<style scoped lang="scss">
	.login {
		box-sizing: border-box;
		width: 100%;
		height: 100%;
		padding-bottom: 20px;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		background: url('../../assets/image/bg-fhd.png') no-repeat center center / cover;
		@media screen and (max-width: 1366px) {
			background: url('../../assets/image/bg-hd.png') no-repeat center center /cover;
		}
		.login-header {
			width: 428px;
			.login-header-title {
				margin-bottom: 14px;
				font-size: 34px;
				text-align: center;
				color: rgba(0, 0, 0, 0.85);
			}
			.login-header-desc {
				line-height: 22px;
				font-size: 14px;
				color: #999;
				text-align: center;
			}
		}
		.login-wrapper {
			margin-top: 30px;
			padding: 20px 30px 30px;
			box-sizing: border-box;
			width: 428px;
			border-radius: 4px;
			background: #fff;
			.login-type-switch {
				margin-top: 14px;
				text-align: center;
				font-size: 14px;
				.login-type-switch-btn {
					font-size: 14px;
				}
			}
		}
	}
</style>
