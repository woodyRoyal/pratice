// 下载文件
export function downLoad (URL, data) {
  let params = ''
  if (data) {
    params = '?' + queryParams(data)
  }
  window.location.href = URL + params
}

function queryParams (data) {
  var _result = [];
  for (let key in data) {
    let value = data[key];
    if (value.constructor === Array) {
      value.forEach(function (_value) {
        _result.push(key + "=" + _value);
      });
    } else {
      _result.push(key + '=' + value);
    }
  }
  return _result.join('&');
}