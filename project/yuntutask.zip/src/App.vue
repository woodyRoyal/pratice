<template>
  <router-view id="app"/>
</template>

<script>
export default {
  name: 'app',
  components: {}
}
</script>

<style>
#app {
	font-family: Avenir, Helvetica, Arial, sans-serif;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	width: 100%;
	height: 100%;
	overflow: auto;
}
</style>
