import 'eric-meyer-reset/eric-meyer-reset.min.css'
import './assets/style/index.scss'
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import './plugins/element.js'
import api from './api'
import PageContentWrapper from './layout/PageContentWrapper'
import PageItemViewer from './layout/PageItemViewer'
Vue.component('PageContentWrapper', PageContentWrapper)
Vue.component('PageItemViewer', PageItemViewer)



Vue.prototype.$api = api

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
