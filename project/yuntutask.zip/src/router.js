import Vue from 'vue'
import Router from 'vue-router'
import BlankLayout from './layout/BlankLayout'
import BasicLayout from './layout/BasicLayout'
import store from './store'
import checkPermissionMenu from './utils/checkPermissionMenu'
import el from 'element-ui/src/locale/lang/el'

Vue.use(Router)

let router = new Router({
  routes: [
    {
      path: '/user',
      component: BlankLayout,
      children: [
        {
          path: '/',
          redirect: 'login'
        },
        {
          path: 'login',
          meta: {
            exemption: true,
          },
          name: '登录',
          component: () => import('./views/user/Login.vue')
        },
        {
          path: 'auth',
          meta: {
            exemption: true,
          },
          name: '授权登录中...',
          component: () => import('./views/user/Auth.vue')
        }
      ]
    },
    {
      path: '/',
      component: BasicLayout,
      children: [
        {
          path: '/',
          redirect: 'welcome2'
        },
        {
          path: 'welcome1',
          meta: {
            exemption: true,
          },
          name: '欢迎使用本系统',
          component: () => import('./views/welcome/WelcomeA.vue')
        },
        {
          path: 'welcome2',
          meta: {
            exemption: true,
          },
          name: '欢迎使用本系统',
          component: () => import('./views/welcome/WelcomeB.vue')
        },
        {
          path: 'awakenTotal',
          name: '唤醒项目概览',
          component: () => import('./views/awaken/total.vue')
        },
        {
          path: 'awakenTable',
          name: '唤醒数据报表',
          component: () => import('./views/awaken/table.vue')
        },
        {
          path: 'projectTotal',
          name: '分发项目概览',
          component: () => import('./views/project/total.vue')
        },
        {
          path: 'projectable',
          name: '分发数据报表',
          component: () => import('./views/project/table.vue')
        },
        {
          path: 'goldTable',
          name: '星球任务金币',
          component: () => import('./views/gold/table.vue')
        },
        {
          path: 'down',
          name: '数据导出列表',
          component: () => import('./views/down/table.vue')
        },
        {
          path: 'form',
          component: BlankLayout,
          children: [
            {
              path: 'tabForm',
              name: 'Tab表单',
              component: () => import('./views/form/TabForm.vue')
            },
            {
              path: 'listForm',
              name: '表单列表',
              component: () => import('./views/form/listForm.vue')
            },
            {
              path: 'baseForm',
              name: '基础表单',
              component: () => import('./views/form/BaseForm.vue')
            }
          ]
        },
      ]
    },
    {
      path: '*',
      redirect: '/exception/exc404'
    }
  ]
})

router.beforeEach((to, from, next) => {
  document.title = to.name || 'Octopus Pro'
  if (to.meta.exemption) {
    next()
  } else if (!checkPermissionMenu(to.path, store.state.userMenu)) {
    next('/exception/exc403')
  } else {
    next()
  }
})

export default router
