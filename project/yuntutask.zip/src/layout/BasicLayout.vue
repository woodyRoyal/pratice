<template>
  <div class="basic-layout">
    <!--  左侧菜单  -->
    <el-menu default-active="1-4-1"
             class="basic-layout-menu"
             @open="handleOpen"
             @close="handleClose"
             background-color="#475266"
             text-color="#eee"
             :router="true"
             unique-opened
             :collapse="isCollapse">
      <!--  logo与名称  -->
      <div class="logo">
        <img src="../assets/logo/logo.png"
             @click="toggle">
        <p v-if="!isCollapse">试用中心</p>
      </div>
      <!--  展开收缩按钮  -->
      <div class="basic-layout-menu-fold"
           @click="toggle"
           :class="isCollapse ? 'fold' : 'unfold'">
      </div>
      <template v-for="(child1,index1) in userMenu"
                v-show="!child1.hidden">
        <template v-if="!child1.hidden">
          <el-menu-item :index="child1.path"
                        :key="index1"
                        v-if="child1.path">
            <i :class="child1.icon"></i>
            <span slot="title">{{child1.name}}</span>
          </el-menu-item>
          <el-submenu :index="'' + index1"
                      v-bind:key="index1"
                      v-else>
            <template slot="title">
              <i :class="child1.icon"></i>
              <span slot="title">{{child1.name}}</span>
            </template>
            <template v-for="(child2,index2) in child1.children">
              <el-menu-item :index="child2.path"
                            :key="index2"
                            v-if="child2.path">
                <span slot="title">{{child2.name}}</span>
              </el-menu-item>
              <el-submenu :index="'' + index2"
                          v-bind:key="index2"
                          v-else>
                <template slot="title">
                  <span slot="title">{{child2.name}}</span>
                </template>
                <el-menu-item v-for="(child3,index3) in child2.children"
                              index="child3.path"
                              :key="index3">选框类
                </el-menu-item>
              </el-submenu>
            </template>
          </el-submenu>
        </template>
      </template>
    </el-menu>
    <!--  右侧区域  -->
    <div class="basic-layout-right">
      <!--  topbar  -->
      <div class="basic-layout-right-top">
        <el-col :span="4"
                :offset="20"
                style="padding-right: 20px; height: 50px; display: flex; align-items: center; justify-content: flex-end;">
          <el-avatar size="small"
                     src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"
                     style="margin-right: 6px;"></el-avatar>
          <el-dropdown @command="switchPermission">
            <span class="el-dropdown-link">
              王小虎
              <i class="el-icon-arrow-down el-icon--right"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>查看信息</el-dropdown-item>
              <el-dropdown-item>个人设置</el-dropdown-item>
              <el-dropdown-item v-if="!permissionAble"
                                command="switchPermission">限制菜单权限</el-dropdown-item>
              <el-dropdown-item v-else
                                command="switchPermission">全部菜单权限</el-dropdown-item>
              <el-dropdown-item divided>退出</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </el-col>
      </div>
      <router-view class="basic-layout-right-main" />
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import FullMenu from '../config/FullMenu'
import PermissionMenu from '../config/MenuPermission'

export default {
  name: 'BasicLayout',
  data () {
    return {
      isCollapse: false
    }
  },
  computed: {
    ...mapState(['permissionAble', 'userMenu'])
  },
  watch: {
    permissionAble: {
      handler: function () {
        this.setMenu()
      },
      immediate: true
    }
  },
  // created() {},
  methods: {
    setMenu () {
      // this.$store.commit('userMenu', this.permissionAble ? PermissionMenu : FullMenu)
      this.$store.commit('userMenu', FullMenu)
    },
    switchPermission (comm) {
      if (comm === 'switchPermission') {
        this.$store.commit('permissionAble', !this.permissionAble)
      }
    },
    toggle () {
      this.isCollapse = !this.isCollapse
    },
    handleOpen (key, keyPath) {
      console.log(key, keyPath)
    },
    handleClose (key, keyPath) {
      console.log(key, keyPath)
    }
  }
}
</script>

<style scoped lang="scss">
.logo {
  margin-bottom: 6px;
  display: flex;
  align-items: center;
  width: 100%;
  height: 50px;
  overflow: hidden;

  img {
    margin: 0 16px;
    width: 32px;
    height: 32px;
  }

  p {
    color: #fff;
    font-weight: 600;
    font-size: 16px;
  }
}

.basic-layout {
  width: 100%;
  height: 100%;
  background: #f5f5f5;
  display: flex;
}

.basic-layout-menu {
  box-shadow: 4px 0 6px 0 rgba(204, 204, 204, 0.1);
}

.basic-layout-menu:not(.el-menu--collapse) {
  width: 200px;
  flex-shrink: 0;
}

.basic-layout-menu {
  position: relative;
  z-index: 100;
  height: 100%;
  min-height: 100%;
}

.basic-layout-right {
  flex: 1;
  min-width: 1140px;
  min-height: 100%;
  display: flex;
  flex-direction: column;
  overflow: auto;
}

.basic-layout-right-top {
  height: 50px;
  flex-shrink: 0;
  background: #fff;
}

.basic-layout-right-main {
  flex: 1;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
}

.basic-layout-menu-fold {
  position: absolute;
  z-index: 100;
  width: 12px;
  height: 80px;
  right: -12px;
  margin-top: -80px;
  top: 50%;
  cursor: pointer;

  &.unfold {
    background-image: url('../assets/image/btn-fold.png');
  }

  &.fold {
    background-image: url('../assets/image/btn-unfold.png');
  }
}
</style>
