<template>
  <div class="page-wrapper">
    <el-breadcrumb class="page-wrapper-breadcrumb" separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>一级目录</el-breadcrumb-item>
      <el-breadcrumb-item>二级菜单</el-breadcrumb-item>
    </el-breadcrumb>
    <slot/>
  </div>
</template>

<script>
// 标准页面容器
export default {
  name: 'PageHeaderWrapper'
}
</script>

<style scoped lang="scss">
	.page-wrapper {
		position: relative;
		flex: 1;
		display: flex;
		flex-direction: column;
		.page-wrapper-breadcrumb {
			box-sizing: border-box;
			border-top: 1px solid #f5f5f5;
			background: #fff;
			height: 50px;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			padding: 0 20px;
		}
	}

</style>
