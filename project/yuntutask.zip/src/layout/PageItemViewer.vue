<template>
  <div class="page-item-viewer">
    <div class="page-item-viewer-title">{{title}}</div>
    <div class="page-item-viewer-content">
      <slot></slot>
    </div>
  </div>
</template>

<script>
//
export default {
  name: 'PageItemViewer',
  props: {
    title: {
      type: String,
      default: ''
    }
  },
}
</script>

<style scoped lang="scss">
	.page-item-viewer {
		background: #fff;
		&:not(:first-of-type) {
			margin-top: 20px;
		}
		.page-item-viewer-title {
			font-weight: 500;
			padding: 40px 30px 30px;
			font-size: 16px;
			color: #333;
		}
		.page-item-viewer-content {
			padding: 0 30px 40px 60px;
		}
	}
</style>
