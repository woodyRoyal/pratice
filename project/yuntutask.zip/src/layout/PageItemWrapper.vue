<template>
  <div class="page-item-wrapper">
    <slot></slot>
  </div>
</template>

<script>
// 页面板块内容组件
export default {
  name: 'PageItemWrapper'
}
</script>

<style scoped lang="scss">
	.page-item-wrapper {
		background: #fff;
		box-sizing: border-box;
		padding: 20px;
		&:not(:first-of-type) {
			margin-top: 20px;
		}
	}
</style>
