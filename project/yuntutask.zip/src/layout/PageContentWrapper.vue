<template>
  <div class="page-content-wrapper">
    <slot></slot>
  </div>
</template>

<script>
// 纯内容组件，不包含头部面包屑
export default {
  name: 'PageContentWrapper'
}
</script>

<style scoped>
	.page-content-wrapper {
		flex: 1;
		box-sizing: border-box;
		padding: 20px;
	}
</style>
