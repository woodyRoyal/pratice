<template>
  <el-tabs v-model="loginType">
    <el-tab-pane label="手机号码注册" name="1">
      <el-form class="login-account" ref="form" :model="form" label-width="0" size="normal">
        <el-form-item error="错误信息">
          <el-input
            placeholder="11位手机号"
            prefix-icon="el-icon-user"
            v-model="form.username">
          </el-input>
        </el-form-item>
        <el-row class="vali-row">
          <el-form-item class="vali-row-input">
            <el-input
              placeholder="验证码"
              v-model="form.valicodePic">
            </el-input>
          </el-form-item>
          <div class="vali-code" @click="changePicture" v-loading="valiCodeLoading"></div>
        </el-row>
        <el-form-item class="vali-row-input">
          <el-input placeholder="短信验证码" v-model="form.valiCodeMessage" class="input-with-select">
            <el-button slot="append" size="small" :disabled="!!countdownValue" @click="getMessageValicode">
              获取验证码<span v-if="countdownValue">({{countdownValue}})</span>
            </el-button>
          </el-input>
        </el-form-item>
        <el-form-item>
          <el-input
            show-password
            placeholder="设置6-16位密码，区分大小写"
            v-model="form.password">
          </el-input>
        </el-form-item>
        <el-form-item>
          <el-input
            show-password
            placeholder="确认密码"
            v-model="form.password">
          </el-input>
        </el-form-item>
        <div class="signup-error">
          这里是错误提示
        </div>
        <el-button
          style="width: 100%; height: 40px; font-size: 18px; letter-spacing: 10px; padding: 0; line-height: 40px;"
          type="primary">注册
        </el-button>
      </el-form>
    </el-tab-pane>
    <el-tab-pane label="邮箱注册" name="2">
      <el-form class="login-account" ref="form" :model="form" label-width="0" size="normal">
        <el-form-item error="错误信息">
          <el-input
            placeholder="11位手机号"
            prefix-icon="el-icon-user"
            v-model="form.username">
          </el-input>
        </el-form-item>
        <el-row class="vali-row">
          <el-form-item class="vali-row-input">
            <el-input
              placeholder="验证码"
              v-model="form.valicodePic">
            </el-input>
          </el-form-item>
          <div class="vali-code" @click="changePicture" v-loading="valiCodeLoading"></div>
        </el-row>
        <el-form-item>
          <el-input
            show-password
            placeholder="设置6-16位密码，区分大小写"
            v-model="form.password">
          </el-input>
        </el-form-item>
        <el-form-item>
          <el-input
            show-password
            placeholder="确认密码"
            v-model="form.password">
          </el-input>
        </el-form-item>
        <div class="signup-error">
          这里是错误提示
        </div>
        <el-button
          style="width: 100%; height: 40px; font-size: 18px; letter-spacing: 10px; padding: 0; line-height: 40px;"
          type="primary" @click="signup">注册
        </el-button>
      </el-form>
    </el-tab-pane>
  </el-tabs>
</template>

<script>
export default {
  name: 'SignupDialog',
  data () {
    return {
      timer: null, // 定时器
      loginType: '1', // '1'、账户密码登录，'2'、短信登录
      valiCodeLoading: false, // 验证码加载
      countdownLimit: 5, // 倒计时长
      countdownValue: 0, // 倒计时秒数
      remenberPassword: false, // 记住密码
      form: {
        valicodePic: '',
        valiCodeMessage: '',
        username: '',
        password: ''
      },
    }
  },
  methods: {
    // 注册按钮点击
    // signup () {
    // },
    // 获取短信验证码
    getMessageValicode () {
      this.countdownValue = this.countdownLimit
      this.timer = setInterval(() => {
        this.countdownValue--
        if (this.countdownValue < 1) {
          this.clearTimer()
        }
      }, 1000)
    },
    // 更换验证图片
    changePicture () {
      this.valiCodeLoading = true
      setTimeout(() => {
        this.valiCodeLoading = false
      }, 500)
    },
    // 清楚定时器
    clearTimer () {
      clearInterval(this.timer)
    }
  },
  // 销毁时清楚定时器
  destroyed () {
    this.clearTimer()
  }
}
</script>

<style scoped lang="scss">
	.login-account {
		margin-top: 25px;

		.signup-error {
			height: 20px;
			font-size: 14px;
			line-height: 20px;
			text-align: center;
			color: #f56c6c;
			margin-bottom: 10px;
		}
	}

	.vali-row {
		display: flex;
		justify-content: space-between;
		align-items: flex-start;

		.vali-row-input {
			flex: 1;
		}

		.vali-code {
			margin-left: 20px;
			width: 90px;
			height: 40px;
			background: #409eff;
			background: url('../assets/image/valicode.png') no-repeat center center / 100% 100%;
		}
	}
</style>

<style scoped>
	/* taps 在顶部的样式修改 */

	/deep/ .is-top.el-tabs__header {
		width: 200px;
		margin: 0 auto;
	}

	/* 移除底部虚线 */
	/deep/ .is-top.el-tabs__nav-wrap::after {
		display: none;
	}

	/* taps高度为50 */
	/deep/ .is-top.el-tabs__nav {
		width: 100%;
		height: 40px;
		margin: 0;
	}

	/* taps高度为50 */
	/deep/ .is-top.el-tabs__item {
		height: 40px;
		line-height: 40px;
		font-size: 16px;
	}
</style>
