import request from '../utils/request'

export default {
  // 获取选项配置接口
  getData: data => {
    return request({
      data,
      url: '/rest/api',
      method: 'get'
    })
  },
}
