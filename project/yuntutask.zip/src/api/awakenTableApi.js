import request from '../utils/request'
export default {
  // 获取
  fetchTable (params) {
    return request({
      url: '/tradeStatisticsDay/list',
      method: 'get',
      params,
    })
  },
}