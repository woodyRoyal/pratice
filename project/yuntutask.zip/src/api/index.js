const files = require.context('.', true, /\.js$/)

const modules = {}

files.keys().forEach((key) => {
  if (key === './index.js') return
  // modules[key.replace(/(\.\/|\.js)/g, '')] = files(key).default
  let childModule = files(key).default
  for (let key in childModule) {
    modules[key] = childModule[key]
  }
})

export default modules
