<template>
  <div>
    <el-card>
      <el-form size="mini"
               :inline="true"
               label-width="140px">
        <el-form-item v-for="(item,index) in options"
                      :key="index"
                      :label="item.label">
          <el-date-picker v-if="item.type === 'daterange'"
                          v-model="item.value"
                          style="width:350px;"
                          type="daterange"
                          value-format="yyyy-MM-dd"
                          :picker-options="item.pickerOptions"
                          range-separator="至"
                          start-placeholder="开始日期"
                          end-placeholder="结束日期"
                          align="right">
          </el-date-picker>
          <el-input v-if="item.type === 'input'"
                    v-model="item.value"
                    :placeholder="item.placeholder">
          </el-input>

          <el-select v-if="item.type === 'select'"
                     v-model="item.value"
                     :placeholder="item.placeholder"
                     :clearable="item.clearable">
            <el-option v-for="(itemChild,indexChild) in item.selectList"
                       :key="indexChild"
                       :label="itemChild.label"
                       :value="itemChild.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary"
                     @click="fetch">
            查询
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>
<script>
// 将后台系统搜索向配置化生成的组件
export default {
  name: 'SearchForm',
  props: {
    options: {
      type: Array,
      required: true,
      default: () => [],
    },
  },
  data () {
    return {
      info: {},
    }
  },
  methods: {
    fetch () {
      let obj = {}
      this.options.forEach((t) => {
        obj[t.model] = t.value
      })
      this.$emit('fetchData', obj)
    },
  },
}
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
</style>
