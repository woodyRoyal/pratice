<template>
  <div>
    <div class="box">
      <span v-for="(item,index) in data"
            :key="index"
            class="itemBox">
        <p>{{item.num}}</p>
        <p>{{item.title}}</p>
      </span>
    </div>

  </div>
</template>

<script>
// 统计栏组件
export default {
  name: 'totalView',
  props: {
    data: {
      type: Array,
      default: () => {
        return [
          {
            title: '今日唤醒成功数',
            num: '34654654',
          },
          {
            title: '今日唤醒成功数',
            num: '34654654',
          },
          {
            title: '今日唤醒成功数',
            num: '34654654',
          },
          {
            title: '今日唤醒成功数',
            num: '34654654',
          },
          {
            title: '今日唤醒成功数',
            num: '34654654',
          },
          {
            title: '今日唤醒成功数',
            num: '34654654',
          },
        ]
      }
    },
  },
  components: {

  },
  data () {
    return {

    }
  },
  methods: {

  },

}
</script>
<style scoped>
.box {
  display: inline-block;
  border: 0.5px solid rgba(121, 121, 121, 1);
  border-bottom: none;
}
p {
  line-height: 44px;
}
.itemBox {
  display: inline-block;
  height: 90px;
  width: 130px;
  border-right: 0.5px solid rgba(121, 121, 121, 1);
  border-bottom: 0.5px solid rgba(121, 121, 121, 1);
  background-color: rgba(242, 242, 242, 1);
  text-align: center;
}
</style>

