<template>
  <el-select multiple
             :placeholder="placeholder"
             v-model="value"
             style="width:260px;"
             collapse-tags
             @change="changeValue">
    <el-option v-for="(item,index) in selectList"
               :key="index"
               :value="item.value"
               :label="item.label">
    </el-option>
  </el-select>
</template>
<script>
export default {
  props: {
    placeholder: {
      type: String
    },
    parentValue: {
      type: Array
    },
    selectList: {
      type: Array,
      default: () => {
        return [
          {
            value: '全选',
            label: '全选'
          },
          {
            value: '选项1',
            label: '黄金糕'
          }, {
            value: '选项2',
            label: '双皮奶'
          }, {
            value: '选项3',
            label: '蚵仔煎'
          }, {
            value: '选项4',
            label: '龙须面'
          }, {
            value: '选项5',
            label: '北京烤鸭'
          }]
      },
    }
  },
  data () {
    return {
      all: false,
      options: [
        {
          value: '全选',
          label: '全选'
        },
        {
          value: '选项1',
          label: '黄金糕'
        }, {
          value: '选项2',
          label: '双皮奶'
        }, {
          value: '选项3',
          label: '蚵仔煎'
        }, {
          value: '选项4',
          label: '龙须面'
        }, {
          value: '选项5',
          label: '北京烤鸭'
        }],
      value: [],
    }
  },
  // mounted () {

  // },
  methods: {
    getValue (arr) {
      let value = []
      this.options.forEach(t => {
        value.push(t.value)
      })
      return value
    },
    changeValue (val) {
      this.$emit('update:parentValue', this.value)
      if (this.all) {
        if (val.length === this.options.length - 1 && val.includes('全选')) {
          val.shift()
          console.log(val)
          // this.$emit('update:parentValue', this.value)
          this.value = val
          this.$emit('update:parentValue', this.value)
          this.all = false
        }
        if (!val.includes('全选') && this.options.length - 1 === val.length) {
          this.value = []
          // this.$emit('update:parentValue', this.value)
          this.all = false
        }
      } else {
        if (val.includes('全选')) {
          this.value = this.getValue(this.options)
          this.$emit('update:parentValue', this.value)
          this.all = true
        }
        if (!val.includes('全选') && val.length === this.options.length - 1) {
          val.unshift('全选')
          this.value = val
          this.$emit('update:parentValue', this.value)
          this.all = true
        }
      }
    },
  }
}
</script>