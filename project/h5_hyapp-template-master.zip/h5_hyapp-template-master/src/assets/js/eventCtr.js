/**
 * @Description: 同级组件通信中间层 $emit / $on
 */
import Vue from 'vue'

export default new Vue()
