# vue-admin-demo

## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn dev
or
yarn serve
```

### Compiles and minifies for production
```
yarn build:uat
and
yarn build:pro
```

### Lints and fixes files
```
yarn lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
