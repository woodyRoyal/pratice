const getters = {
  // app
  sidebar: (state) => state.app.sidebar,
  // user
  username: (state) => state.user.username,
  menuTreeList: (state) => state.user.menuTreeList,
  toLoginCount: (state) => state.user.toLoginCount,
  // permission
  routers: (state) => state.permission.routers,
  addRouters: (state) => state.permission.addRouters,
  // 页面高度
  boxHeight: (state) => state.app.boxHeight,
  // 是否需要结算标记
  settlementFlag: (state) => state.user.settlementFlag,
  // 商户信息
  merchantInfo: (state) => state.user.merchantInfo,
}
export default getters
