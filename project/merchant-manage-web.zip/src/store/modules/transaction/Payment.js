const Payment = {
  state: {
    // 交易类型
    tradeTypeList: [],
    // 交易状态
    tradeStatusList: [],
    // 支付渠道
    tradeChannelList: [],
    // 交易商户号
    tradeChannelMerchantNoList: [],
  },
  mutations: {
    SETTradeTypeList(state, value) {
      state.tradeTypeList = value
    },
    SETtradeStatusList(state, value) {
      state.tradeStatusList = value
    },
    SETTradeChannelList(state, value) {
      state.tradeChannelList = value
    },
    SETTradeChannelMerchantNoList(state, value) {
      state.tradeChannelMerchantNoList = value
    },
  },
  actions: {

  },
}
export default Payment
