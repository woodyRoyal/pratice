const authentication = {
  state: {
    //鉴权渠道下拉列表  
    signChannelList: [],
    // 鉴权渠道商户号下拉列表
    signChannelMerchantNoList: [],
    // 鉴权状态下拉列表
    signStatusList: [],
  },
  mutations: {
    SETSignChannelList(state, value) {
      state.signChannelList = value
    },
    SETSignChannelMerchantNoList(state, value) {
      state.signChannelMerchantNoList = value
    },
    SETSignStatusList(state, value) {
      state.signStatusList = value
    },
  },
  actions: {

  },
}
export default authentication
