import {
  // asyncRouterMap,
  asyncRouterMapObj,
  constantRouterMap,
  lastRouterConst,
} from '@/router'

function addRouterAttribute(menu) {
  if (!asyncRouterMapObj[menu.path]) {
    return menu
  }
  if (asyncRouterMapObj[menu.path].component) {
    menu.component = asyncRouterMapObj[menu.path].component
  }
  // 先取表里的名称
  if (!menu.name) {
    menu.name = asyncRouterMapObj[menu.path].name
  }
  if (asyncRouterMapObj[menu.path].icon) {
    menu.icon = asyncRouterMapObj[menu.path].icon
  }
  if (asyncRouterMapObj[menu.path].redirect) {
    menu.redirect = asyncRouterMapObj[menu.path].redirect
  }
  if (asyncRouterMapObj[menu.path].hidden) {
    menu.hidden = asyncRouterMapObj[menu.path].hidden
  }
  if (asyncRouterMapObj[menu.path].alwaysShow) {
    menu.alwaysShow = asyncRouterMapObj[menu.path].alwaysShow
  }
  if (menu.children && menu.children.length > 0) {
    menu.children = menu.children.map((item) => addRouterAttribute(item))
  }
  return menu
}

const permission = {
  state: {
    routers: constantRouterMap,
    addRouters: [],
  },
  mutations: {
    SET_ROUTERS: (state, routers) => {
      state.addRouters = routers
      state.routers = constantRouterMap.concat(routers).concat(lastRouterConst)
    },
    SET_ROUTERS_LAST: (state) => {
      state.routers = constantRouterMap.concat(lastRouterConst)
    },
    CLEAR_ROUTERS: (state) => {
      state.routers = constantRouterMap
      state.addRouters = []
    },
  },
  actions: {
    GenerateRoutes({
      commit,
    }, menuTreeList) {
      return new Promise((resolve) => {
        let accessedRouters
        if (process.env.VUE_APP_ENV === 'dev') {
          // 本地router
          // commit('SET_ROUTERS', asyncRouterMap)
          // 后端返回router进行比较
          accessedRouters = menuTreeList.map((item) => addRouterAttribute(item))
        } else {
          accessedRouters = menuTreeList.map((item) => addRouterAttribute(item))
        }
        commit('SET_ROUTERS', accessedRouters)
        resolve(accessedRouters.concat(lastRouterConst))
      })
    },
    SetRouterLast({
      commit,
    }) {
      commit('SET_ROUTERS_LAST')
    },
    // 清空路由
    ClearRouters({
      commit,
    }) {
      commit('CLEAR_ROUTERS')
    },
  },
}
export default permission
