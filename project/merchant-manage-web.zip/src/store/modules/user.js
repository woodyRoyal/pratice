import {
  saveToStorage,
  getFromStorage,
  removeStorage,
} from '@/utils/storage'

const cacheMenuTreeList = getFromStorage('local', 'menuTreeList')
const cacheUsername = getFromStorage('local', 'username')
const cacheSettlementFlag = getFromStorage('local', 'settlementFlag')
const cacheMerchantInfo = getFromStorage('local', 'merchantInfo')
const user = {
  state: {
    username: cacheUsername,
    menuTreeList: cacheMenuTreeList || [], // 菜单树列表
    settlementFlag: cacheSettlementFlag || 0,
    merchantInfo: cacheMerchantInfo || {},
    toLoginCount: 0,
  },
  mutations: {
    SET_USERNAME: (state, username) => {
      state.username = username
      saveToStorage('local', 'username', username)
    },
    SET_MENU_TREE_LIST: (state, menuTreeList) => {
      state.menuTreeList = menuTreeList
      saveToStorage('local', 'menuTreeList', menuTreeList)
    },
    SET_FLAG(state, value) {
      state.settlementFlag = value
      saveToStorage('local', 'settlementFlag', value)
    },
    SET_MERCHANT(state, value) {
      state.merchantInfo = value
      saveToStorage('local', 'merchantInfo', value)
    },
    SET_TO_LOGIN_COUNT(state, value) {
      state.toLoginCount = value
    },
  },
  actions: {
    username({
      commit,
    }, username) {
      commit('SET_USERNAME', username)
    },
    menuTreeList({
      commit,
    }, menuTreeList) {
      commit('SET_MENU_TREE_LIST', menuTreeList)
    },
    // 退出
    logout({
      commit,
    }) {
      commit('SET_USERNAME', '')
      commit('SET_MENU_TREE_LIST', [])
      removeStorage('local')
    },
    toLoginCount({
      commit,
    }, value) {
      commit('SET_TO_LOGIN_COUNT', value)
    },
  },
}
export default user
