import {
  saveToStorage,
  getFromStorage,
} from '@/utils/storage'
const cacheOpened = getFromStorage('local', 'sidebarStatus') || false
const app = {
  state: {
    sidebar: {
      opened: !cacheOpened,
    },
    boxHeight: 800,
  },
  mutations: {
    changeBoxHeight(state, value) {
      state.boxHeight = value
    },
    TOGGLE_SIDEBAR: (state) => {
      if (state.sidebar.opened) {
        saveToStorage('local', 'sidebarStatus', true)
      } else {
        saveToStorage('local', 'sidebarStatus', false)
      }
      state.sidebar.opened = !state.sidebar.opened
    },
  },
  actions: {
    toggleSideBar({
      commit,
    }) {
      commit('TOGGLE_SIDEBAR')
    },
  },
}
export default app
