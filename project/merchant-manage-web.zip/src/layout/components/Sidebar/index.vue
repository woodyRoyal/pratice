<template>
  <el-menu :default-active="$route.path"
           :collapse="isCollapse"
           mode="vertical"
           background-color="#304156"
           text-color="#bfcbd9"
           active-text-color="#ffd059">
    <SidebarItem v-for="route in routers"
                 :key="route.name"
                 :item="route"
                 :base-path="route.path"></SidebarItem>
  </el-menu>
</template>

<script>
import { mapGetters } from 'vuex'
import SidebarItem from './SidebarItem'

export default {
  components: { SidebarItem },
  computed: {
    ...mapGetters([
      'sidebar',
      'routers',
    ]),
    isCollapse () {
      return !this.sidebar.opened
    },
    // routes () {
    //   return this.$router.options.routes
    // }
  },
  created () {
    // console.log(this.$router.options.routes)
  },
}
</script>

<style lang="scss" scoped>
/*滚动条样式*/
::-webkit-scrollbar {
  width: 0;
  height: 0;
}
::-webkit-scrollbar-thumb {
  border-radius: 10px;
  box-shadow: inset 0 0 0 rgba(0, 0, 0, 0.2);
  background: rgba(0, 0, 0, 0.2);
}
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 0 rgba(0, 0, 0, 0.2);
  border-radius: 0;
  background: rgba(0, 0, 0, 0.1);
}
</style>

