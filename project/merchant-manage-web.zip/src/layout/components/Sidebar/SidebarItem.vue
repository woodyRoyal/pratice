<template>
  <div v-if="!item.hidden && item.children">
    <router-link v-if="hasOneShowingChild(item.children) && !onlyOneChild.children && !item.alwaysShow"
                 :to="resolvePath(onlyOneChild.path)">
      <el-menu-item :index="resolvePath(onlyOneChild.path)">
        <i v-if="onlyOneChild && onlyOneChild.icon"
           :class="onlyOneChild.icon"></i>
        <span v-if="onlyOneChild && onlyOneChild.name"
              slot="title">{{ onlyOneChild.name }}</span>
      </el-menu-item>
    </router-link>

    <el-submenu v-else
                :index="item.name || item.path">
      <template slot="title">
        <i v-if="item.icon"
           :class="item.icon"></i>
        <span slot="title">{{ item.name }}</span>
      </template>

      <div v-for="child in item.children"
           :key="child.name">
        <template v-if="!child.hidden">
          <sidebar-item v-if="child.children && child.children.length > 0"
                        :key="child.path"
                        :item="child"
                        :base-path="resolvePath(child.path)"></sidebar-item>
          <router-link v-else
                       :key="child.name"
                       :to="resolvePath(child.path)">
            <el-menu-item :index="resolvePath(child.path)">
              <i v-if="child.icon"
                 :class="child.icon"></i>
              <span slot="title">{{ child.name }}</span>
            </el-menu-item>
          </router-link>
        </template>
      </div>
    </el-submenu>
  </div>
</template>

<script>
import path from 'path'

export default {
  name: 'SidebarItem',
  props: {
    // route object
    item: {
      type: Object,
      required: true,
    },
    basePath: {
      type: String,
      default: '',
    },
  },
  data () {
    return {
      onlyOneChild: null,
    }
  },
  methods: {
    hasOneShowingChild (children) {
      const showingChildren = children.filter((item) => {
        if (item.hidden) {
          return false
        } else {
          // temp set(will be used if only has one showing child )
          this.onlyOneChild = item
          return true
        }
      })
      if (showingChildren.length === 1) {
        return true
      }
      return false
    },
    resolvePath (...paths) {
      return path.resolve(this.basePath, ...paths)
    },
  },
}
</script>

<style lang="scss" scoped>
/*加了div*/
.el-menu--collapse > .el-menu-item span,
.el-menu--collapse > div > .el-submenu > .el-submenu__title span {
  height: 0;
  width: 0;
  overflow: hidden;
  visibility: hidden;
  display: inline-block;
}
.iconfont {
  margin-right: 4px;
  font-size: 18px;
}
</style>

<style lang="scss">
.el-menu--collapse > .el-menu-item .el-submenu__icon-arrow,
.el-menu--collapse > div > .el-submenu > .el-submenu__title .el-submenu__icon-arrow {
  display: none !important;
}
</style>

