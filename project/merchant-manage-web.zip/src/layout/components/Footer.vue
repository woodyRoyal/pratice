<template>
  <div class="footer-wrapper">
    Copyright@2019 2345.com
  </div>
</template>

<style>
.footer-wrapper {
  background-color: #eee;
  height: 50px;
  line-height: 50px;
  border-bottom: solid 1px #e6e6e6;
  text-align: center;
  font-size: 14px;
}
</style>
