<template>
  <section class="app-main">
    <transition name="fade-transform"
                mode="out-in">
      <router-view :key="key"></router-view>
    </transition>
  </section>
</template>

<script>
import caclHeight from '../../mixins/caclHeightMixin'
export default {
  name: 'AppMain',
  mixins: [caclHeight],
  computed: {
    key () {
      return this.$route.fullPath
    },
  },
}
</script>

<style lang="scss" scoped>
.app-main {
  /*50 = navbar */
  /*min-height: calc(100vh - 50px);*/
  height: calc(100vh - 50px);
  position: relative;
  overflow: auto;
  padding: 10px;
}

/*fade-transform*/
.fade-transform-leave-active,
.fade-transform-enter-active {
  transition: all 0.5s;
}
.fade-transform-enter {
  opacity: 0;
  transform: translateX(-30px);
}
.fade-transform-leave-to {
  opacity: 0;
  transform: translateX(30px);
}
</style>
