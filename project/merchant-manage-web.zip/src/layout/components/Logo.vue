<template>
  <div class="sidebar-logo-container"
       :class="[collapse ? 'collapse' : 'expand']">
    <transition name="sidebarLogoFade">
      <router-link v-if="collapse"
                   key="collapse"
                   class="sidebar-logo-link"
                   to="/">
        <!-- <div v-if="logo"
             class="sidebar-logo"></div> -->
        <h1 class="sidebar-title">
          {{ title }}
        </h1>
      </router-link>
      <router-link v-else
                   key="expand"
                   class="sidebar-logo-link"
                   to="/">
        <!-- <div v-if="logo"
             class="sidebar-logo"></div> -->
        <h1 class="sidebar-title">
          {{ title }}
        </h1>
      </router-link>
    </transition>
  </div>
</template>

<script>
import { sysname } from '../../../package'
import logo from '../../assets/logo.png'

export default {
  name: 'SidebarLogo',
  props: {
    collapse: {
      type: Boolean,
      required: true,
    },
  },
  data () {
    return {
      title: sysname,
      logo,
    }
  },
}
</script>

<style lang="scss" scoped>
.sidebarLogoFade-enter-active {
  transition: opacity 1.5s;
}

.sidebarLogoFade-enter,
.sidebarLogoFade-leave-to {
  opacity: 0;
}

.sidebar-logo-container {
  position: relative;
  width: 100%;
  background: #2e3851;
  white-space: nowrap;
  overflow: hidden;

  & .sidebar-logo-link {
    height: 122px;
    width: 100%;

    & .sidebar-logo {
      width: 100%;
      height: 80px;
      background: url('../../assets/logo.png') center 30px no-repeat;
      background-size: 42px 42px;
    }

    & .sidebar-title {
      display: block;
      margin: 0;
      color: #fff;
      font-weight: bold;
      font-size: 20px;
      line-height: 122px;
      text-align: center;
    }
  }

  .sidebar-logo {
    transition: all 0.28s;
    -webkit-transition: all 0.28s;
  }
  &.collapse {
    text-align: center;
    .sidebar-logo-link {
      height: 50px;
      .sidebar-logo {
        height: 50px;
        background: url('../../assets/logo.png') center no-repeat;
        background-size: 20px 20px;
      }
    }
  }
  &.expand {
    padding: 0 20px;
  }
}
</style>
