<template>
  <div class="navbar">
    <Hamburger :toggle-click="toggleSideBar"
               :is-active="sidebar.opened"
               class="hamburger-container"></Hamburger>

    <Breadcrumb class="breadcrumb-container"></Breadcrumb>

    <div class="right-menu">
      <span>欢迎，</span>
      <span class="display-name">{{ username || 'xxx' }}</span>
      <el-button type="text"
                 @click="handleLogout">
        退出
      </el-button>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Breadcrumb from '../../components/Breadcrumb'
import Hamburger from '../../components/Hamburger'
import userApi from '../../api/user'

export default {
  components: {
    Breadcrumb,
    Hamburger,
  },
  data () {
    return {
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'username',
    ]),
  },
  methods: {
    toggleSideBar () {
      this.$store.commit('TOGGLE_SIDEBAR')
    },
    handleLogout () {
      this.$confirm('确定退出商户服务平台吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }).then(() => {
        this.logout()
      }).catch(() => {
        // 
      })
    },
    // 退出登录
    async logout () {
      await userApi.fetchLogout()
      this.$store.dispatch('logout')
      this.$store.dispatch('ClearRouters')
      this.$router.push('/login')
    },
  },
}
</script>

<style lang="scss" scoped>
.navbar {
  background-color: #fff;
  height: 50px;
  line-height: 50px;
  border-bottom: solid 1px #e6e6e6;
  .hamburger-container {
    line-height: 58px;
    height: 50px;
    float: left;
    padding: 0 10px;
  }
  .breadcrumb-container {
    float: left;
  }
  .right-menu {
    float: right;
    padding: 0 10px;
    font-size: 14px;
  }
}
.breadcrumb-container {
  float: left;
}
.right-menu {
  float: right;
  padding: 0 10px;
  font-size: 14px;
  .display-name {
    margin-right: 20px;
  }
}
</style>
