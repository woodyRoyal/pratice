<template>
  <div class="app-wrapper"
       :class="classObj">
    <Logo class="logo-container"
          :collapse="isCollapse"></Logo>
    <Sidebar class="sidebar-container"></Sidebar>
    <div class="main-container">
      <Navbar></Navbar>
      <AppMain></AppMain>
      <!-- <Footer></Footer> -->
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import {
  Logo,
  AppMain,
  Navbar,
  Sidebar,
  // Footer,
} from './components'

export default {
  name: 'Layout',
  components: {
    Logo,
    Navbar,
    Sidebar,
    AppMain,
    // Footer,
  },
  computed: {
    ...mapGetters([
      'sidebar',
    ]),
    isCollapse () {
      return !this.sidebar.opened
    },
    classObj () {
      return {
        hideSidebar: this.isCollapse,
        openSidebar: !this.isCollapse,
      }
    },
  },
  methods: {},
}
</script>

<style lang="scss" scoped>
.app-wrapper {
  position: relative;
  height: 100%;
  width: 100%;
}
.logo-container {
  width: 180px !important;
  transition: width 0.28s;
  height: 122px;
  border-right: solid 1px #e6e6e6;
  position: fixed;
  top: 0;
  left: 0;
  overflow: hidden;
}
.sidebar-container {
  width: 180px !important;
  transition: width 0.28s;
  height: calc(100% - 122px);
  position: fixed;
  top: 122px;
  bottom: 0;
  left: 0;
  overflow: auto;
}
.main-container {
  min-height: 100%;
  margin-left: 180px;
  transition: margin-left 0.28s;
}
.hideSidebar {
  .logo-container {
    width: 65px !important;
    height: 50px;
  }
  .sidebar-container {
    width: 65px !important;
    height: calc(100% - 50px);
    top: 50px;
  }
  .main-container {
    min-height: 100%;
    margin-left: 65px;
    transition: margin-left 0.28s;
    background-color: d0d0d0;
  }
}
</style>
