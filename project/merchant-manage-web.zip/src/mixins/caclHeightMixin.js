/*
 * 计算表格的最大高度，计算结果保存在vuex
 * */
import debounce from '../utils/debounce.js'

export default {
  created() {
    this.caclHeight()
  },
  methods: {
    // 实时计算表格的最大高度（防抖）
    caclHeight() {
      const fn = () => {
        const documentHeight = document.documentElement.clientHeight
        let height = documentHeight - 70
        if (height < 50) {
          height = 50
        }
        this.$store.commit('changeBoxHeight', height)
      }
      window.addEventListener('resize', debounce(fn, 300, true))
    },
  },
}
