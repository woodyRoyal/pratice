import dayjs from 'dayjs'
import api from '../api/reportTable/tradeStatisticsDay'
// 获取当日时间
export function getDay (cformat) {
  return dayjs().format(cformat)
}
// 转换url参数 
function queryParams (data) {
  var _result = [];
  for (var key in data) {
    var value = data[key];
    if (value.constructor === Array) {
      value.forEach(function (_value) {
        _result.push(key + "=" + _value);
      });
    } else {
      _result.push(key + '=' + value);
    }
  }
  return _result.join('&');
}
// 下载文件
export function downLoad (URL, data) {
  let params = ''
  if (data) {
    params = '?' + queryParams(data)
  }
  window.location.href = URL + params
}
// 下载多个文件
export function downLoadMultiple (URL) {
  const iframe = document.createElement("iframe");
  iframe.style.display = "none"; // 防止影响页面
  iframe.style.height = 0; // 防止影响页面
  iframe.src = URL;
  document.body.appendChild(iframe); // 这一行必须，iframe挂在到dom树上才会发请求
  // 5分钟之后删除（onload方法对于下载链接不起作用，就先抠脚一下吧）
  setTimeout(() => {
    iframe.remove();
  }, 5 * 60 * 1000);
}

// 验证时间区间
export function validateDay (start, end, day) {
  let s1 = start ? new Date(start.replace(/-/g, '/')) : ''
  let s2 = end ? new Date(end.replace(/-/g, '/')) : ''
  if (s1) {
    let days = s2.getTime() - s1.getTime()
    if (parseInt(days / (1000 * 60 * 60 * 24)) > day) {
      return false
    } else {
      return true
    }
  } else {
    return true
  }
}
// 轮询
export async function pollingStart (context) {
  try {
    const data = {
      serialNumber: context.serialNumber,
      count: context.count,
    }
    const res = await api.export(data)
    if (context.count > 10) {
      context.downLoading = false
      clearInterval(context.timer)
      return context.$message.error('下载时间超时')
    }
    context.count += 1
    if (res.code === 'success') {
      if (res.result) {
        context.downLoading = false
        let fileList = res.result.split(',')
        console.log(fileList)
        clearInterval(context.timer)
        fileList.forEach((t) => {
          downLoadMultiple(t)
        })
        context.count = 0
      }
    } else {
      context.downLoading = false
      clearInterval(context.timer)
      context.count = 0
    }
  } catch (error) {
    context.downLoading = false
    clearInterval(context.timer)
    context.count = 0
  }
}
