/**
 * 对象深拷贝
 * 如果想使用完美的深拷贝，请使用lodash的cloneDeep
 * import { cloneDeep } from 'lodash'
 * @param {Object} source
 * @returns {Object}
 */
import {
  getFromStorage,
} from '@/utils/storage'
export function deepClone(source) {
  if (!source && typeof source !== 'object') {
    throw new Error('error arguments', 'deepClone')
  }
  const targetObj = source.constructor === Array ? [] : {}
  Object.keys(source).forEach((keys) => {
    if (source[keys] && typeof source[keys] === 'object') {
      targetObj[keys] = deepClone(source[keys])
    } else {
      targetObj[keys] = source[keys]
    }
  })
  return targetObj
}

/**
 * 获取URL的具体参数值
 * @param {string} name
 * @returns {string}
 */
export function getQueryString(name) {
  const reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)')
  // let r = window.location.search.substr(1).match(reg)
  const num = window.location.href.indexOf('?')
  const r = window.location.href.substr(num + 1).match(reg)
  if (r != null) return decodeURI(r[2])
  return null
}

/**
 * 把时间解析为字符串
 * @param {(Object|string|number)} time
 * @param {string} cFormat
 * @returns {string}
 */
export function parseTime(time, cFormat) {
  if (arguments.length === 0) {
    return null
  }
  const format = cFormat || '{y}-{m}-{d} {h}:{i}:{s}'
  let date
  if (typeof time === 'object') {
    date = time
  } else {
    if ((typeof time === 'string') && (/^[0-9]+$/.test(time))) {
      time = parseInt(time)
    }
    if ((typeof time === 'number') && (time.toString().length === 10)) {
      time = time * 1000
    }
    date = new Date(time)
  }
  const formatObj = {
    y: date.getFullYear(),
    m: date.getMonth() + 1,
    d: date.getDate(),
    h: date.getHours(),
    i: date.getMinutes(),
    s: date.getSeconds(),
    a: date.getDay(),
  }
  return format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
    let value = formatObj[key]
    // Note: getDay() returns 0 on Sunday
    if (key === 'a') {
      return ['日', '一', '二', '三', '四', '五', '六'][value]
    }
    if (result.length > 0 && value < 10) {
      value = '0' + value
    }
    return value || 0
  })
}

/**
 * 获取URL上的参数对象
 * @param {string} url
 * @returns {Object}
 */
export function getQueryObject(url) {
  url = url == null ? window.location.href : url
  const search = url.substring(url.lastIndexOf('?') + 1)
  const obj = {}
  const reg = /([^?&=]+)=([^?&=]*)/g
  search.replace(reg, (rs, $1, $2) => {
    const name = decodeURIComponent($1)
    let val = decodeURIComponent($2)
    val = String(val)
    obj[name] = val
    return rs
  })
  return obj
}

/**
 * 合并两个对象，赋予最后一个优先级
 * @param {Object} target
 * @param {(Object|Array)} source
 * @returns {Object}
 */
export function objectMerge(target, source) {
  if (typeof target !== 'object') {
    target = {}
  }
  if (Array.isArray(source)) {
    return source.slice()
  }
  Object.keys(source).forEach((property) => {
    const sourceProperty = source[property]
    if (typeof sourceProperty === 'object') {
      target[property] = objectMerge(target[property], sourceProperty)
    } else {
      target[property] = sourceProperty
    }
  })
  return target
}

/**
 * 去抖
 * @param {Function} func
 * @param {number} wait
 * @param {boolean} immediate
 * @return {*}
 */
export function debounce(func, wait, immediate) {
  let timeout, args, context, timestamp, result
  const later = function () {
    // 据上一次触发时间间隔
    const last = +new Date() - timestamp
    // 上次被包装函数被调用时间间隔 last 小于设定时间间隔 wait
    if (last < wait && last > 0) {
      timeout = setTimeout(later, wait - last)
    } else {
      timeout = null
      // 如果设定为immediate===true，因为开始边界已经调用过了此处无需调用
      if (!immediate) {
        result = func.apply(context, args)
        if (!timeout) context = args = null
      }
    }
  }
  return function (...args) {
    context = this
    timestamp = +new Date()
    const callNow = immediate && !timeout
    // 如果延时不存在，重新设定延时
    if (!timeout) timeout = setTimeout(later, wait)
    if (callNow) {
      result = func.apply(context, args)
      context = args = null
    }
    return result
  }
}

/**
 * 单个数组内去重
 * @param {Array} arr
 * @returns {Array}
 */
export function uniqueArr(arr) {
  return Array.from(new Set(arr))
}

/**
 * 两个数组的并集（两个数组的元素为数值或字符串）
 * @param {Array} arr1
 * @param {Array} arr2
 * @returns {Array}
 */
export const unionArr = (arr1, arr2) => Array.from(new Set([...arr1, ...arr2]))
/**
 * 两个数组的交集（两个数组的元素为数值或字符串）
 * @param {Array} arr1
 * @param {Array} arr2
 * @returns {Array}
 */
export const intersectionArr = (arr1, arr2) => {
  const len = Math.min(arr1.length, arr2.length)
  let i = -1
  const res = []
  while (++i < len) {
    const item = arr2[i]
    if (arr1.indexOf(item) > -1) res.push(item)
  }
  return res
}
/**
 * 两个数组的差集（两个数组的元素为数值或字符串）
 * @param {Array} targetArr 目标数组
 * @param {Array} sourceArr 对比数组
 * @returns {Array} 目标数组中不和对比数组重复的值
 */
export const differenceArr = (targetArr, sourceArr) => targetArr.filter((item) => !sourceArr.some((ele) => ele === item))

/**
 * 金额（元）格式为几位小数的千分位 如：12345678 => 12,345,678.00 、 12345678.2345 => 12,345,678.23
 * @param {Number|String} s 金额（元）
 * @param {Number|String} n 小数位数 默认2位小数，最小1位小数
 * @returns {String}
 */
export function parseToThousandth(s, n) {
  if (/^([0-9]+|[0-9]{1,3}(,[0-9]{3})*)(.[0-9]{1,2})?$/.test(s) && ((s + '').indexOf(',') > -1)) {
    return s
  } else if (/^[0-9]+(.[0-9]+)?$/.test(s)) {
    n = n > 0 && n <= 20 ? n : 2
    s = parseFloat((s + '').replace(/[^\d.-]/g, '')).toFixed(n) + ''
    const l = s
      .split('.')[0]
      .split('')
      .reverse()
    const r = s.split('.')[1]
    let t = ''
    for (let i = 0; i < l.length; i++) {
      t += l[i] + ((i + 1) % 3 === 0 && i + 1 !== l.length ? ',' : '')
    }
    return (
      t
      .split('')
      .reverse()
      .join('') +
      '.' +
      r
    )
  } else {
    return '0.00'
  }
}

/**
 * 千分位格式为金额（元） 如：12,345,678.23 => 12345678.23
 * @param {String} val 千分位
 * @returns {String}
 */
export function parseToMoney(val) {
  val = val + ''
  if (/^([0-9]+|[0-9]{1,3}(,[0-9]{3})*)(.[0-9]{1,2})?$/.test(val)) {
    if (val.indexOf(',')) {
      const a = val.split('.')
      if (a[1] === '00') {
        val = a[0].split(',').join('')
      } else {
        a[1] = a[1].slice(0, 2)
        a[0] = a[0].split(',').join('')
        val = a.join('.')
      }
    } else {
      const b = val.split('.')
      if (b[1] === '00') {
        val = b[0]
      } else {
        b[1] = b[1].slice(0, 2)
        val = b.join('.')
      }
    }
    return val
  } else {
    return '0'
  }
}

/**
 * 乘法（以防精度丢失）
 * @param {Number} arg1
 * @param {Number} arg2
 * @returns {Number}
 */
export function accMul(arg1, arg2) {
  let m = 0
  const s1 = arg1.toString()
  const s2 = arg2.toString()
  try {
    m += s1.split('.')[1].length
  } catch (e) {
    //
  }
  try {
    m += s2.split('.')[1].length
  } catch (e) {
    //
  }
  return Number(s1.replace('.', '')) * Number(s2.replace('.', '')) / Math.pow(10, m)
}

/**
 * 对比菜单树
 * @param {Object} obj
 * @param {Object} menu
 * @returns {Number}
 */
export function addRouterAttribute(obj, menu) {
  if (!obj[menu.path]) {
    return menu
  }
  if (obj[menu.path].component) {
    menu.component = obj[menu.path].component
  }
  if (!menu.name) {
    menu.name = obj[menu.path].name
  }
  if (obj[menu.path].icon) {
    menu.icon = obj[menu.path].icon
  }
  if (obj[menu.path].redirect) {
    menu.redirect = obj[menu.path].redirect
  }
  if (obj[menu.path].hidden) {
    menu.hidden = obj[menu.path].hidden
  }
  if (menu.children && menu.children.length > 0) {
    menu.children = menu.children.map((item) => addRouterAttribute(item))
  }
  return menu
}

/**
 * 是否有该按钮权限
 * @param {String} str
 * @param {Array} btns
 * @returns {Boolean}
 */
export function isPermissionBtn(str, arr) {
  let btns = arr ? arr : getFromStorage('local', 'btns')
  if (btns && Array.isArray(btns) && btns.length > 0) {
    let a = btns.filter((item) => item === str)
    if (a && a.length < 1) {
      return false
    } else {
      return true
    }
  } else {
    return false
  }
}
