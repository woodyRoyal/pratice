/**
 * @param {String} type = 'session' || 'local'
 * @param {String} key
 * @param {String} value
 */
// todo key替换为当前的服务 比如 __ASSET_SERVICE__
const SERVICE = '__MERCHANT_SERVICE__'
const saveToStorage = (type, key, value) => {
  const store = type === 'session' ? window.sessionStorage : window.localStorage
  let _SERVICE = store[SERVICE]
  if (!_SERVICE) {
    _SERVICE = {}
    _SERVICE[key] = value
  } else {
    _SERVICE = JSON.parse(_SERVICE)
    // if (!_SERVICE[id]) {
    //   _SERVICE[id] = {}
    // }
  }
  _SERVICE[key] = value
  store[SERVICE] = JSON.stringify(_SERVICE)
}

/**
 * @para
 * type: {存储类型，String：'session' || 'local'}
 * key: 取值存储的键
 * value: 取不到的默认值
 * */
const getFromStorage = (type, key, value) => {
  const store = type === 'session' ? window.sessionStorage : window.localStorage
  let _SERVICE = store[SERVICE]
  if (!_SERVICE) {
    return value
  }
  _SERVICE = JSON.parse(_SERVICE)
  if (_SERVICE[key] === 'undefined' || _SERVICE[key] === 'null') {
    return value
  }
  return _SERVICE[key] || value
}
/**
 * @para
 * type: {存储类型，String：'session' || 'local'}
 * */
const removeStorage = (type) => {
  if (type === 'session') {
    window.sessionStorage.removeItem(SERVICE)
  } else if (type === 'local') {
    window.localStorage.removeItem(SERVICE)
  }
}
export {
  saveToStorage,
  getFromStorage,
  removeStorage,
}
