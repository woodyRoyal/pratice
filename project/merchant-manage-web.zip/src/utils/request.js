import axios from 'axios'
import qs from 'qs'
import router from '../router'
import store from '../store'
import {
  Message,
} from 'element-ui'

const baseURL = process.env.VUE_APP_BASE_URL
// 创建axios实例
const service = axios.create({
  baseURL, // base_url
  timeout: 50000, // 指定请求超时的毫秒数(0 表示无超时时间)
  withCredentials: true, // 表示跨域请求时是否需要使用凭证 自动set-cookie
  headers: {
    'Content-Type': 'application/json;charset=UTF-8',
  },
})

// 默认把请求视为切换路由就会把pending状态的请求取消，false为不取消
// "axios": "0.19.0" 存在bug（不会携带参数，所以此参数设置无效，建议降到"0.18.1"，等待修复后可升级）
service.defaults.routeChangeCancel = true

// 用于存储目前状态为pending的请求标识信息
let pendingRequest = []

/**
 * 请求的拦截处理
 * @param config - 请求的配置项
 */
const handleRequestIntercept = (config) => {
  // 区别请求的唯一标识，这里用方法名+请求路径
  // 如果一个项目里有多个不同baseURL的请求，可以改成`${config.method} ${config.baseURL}${config.url}`
  const data = config.data ? config.data : config.params
  const requestMark = `${config.url}&method=${config.method}&${qs.stringify(data)}`
  // 是否重复请求
  const markIndex = pendingRequest.findIndex((item) => item.name === requestMark)
  if (markIndex > -1) {
    // 取消上个重复的请求
    pendingRequest[markIndex].cancel()
    // 删掉在pendingRequest中的请求标识
    pendingRequest.splice(markIndex, 1)
  }
  // （重新）新建针对这次请求的axios的cancelToken标识
  const CancelToken = axios.CancelToken
  const source = CancelToken.source()
  config.cancelToken = source.token
  // 设置自定义配置requestMark项，主要用于响应拦截中
  config.requestMark = requestMark
  // 记录本次请求的标识
  pendingRequest.push({
    name: requestMark,
    cancel: source.cancel,
    routeChangeCancel: config.routeChangeCancel, // 可能会有优先级高于默认设置的routeChangeCancel项值
  })

  return config
}

/**
 * 响应的拦截处理
 * @param config - 请求的配置项
 */
const handleResponseIntercept = (config) => {
  // 根据请求拦截里设置的requestMark配置来寻找对应pendingRequest里对应的请求标识
  const markIndex = pendingRequest.findIndex((item) => item.name === config.requestMark)
  // 找到了就删除该标识
  markIndex > -1 && pendingRequest.splice(markIndex, 1)
}

// request interceptor
service.interceptors.request.use(
  (config) => {
    if (config.method === 'get') {
      config.params = {
        _t: Date.parse(new Date()),
        ...config.params,
      }
    }
    // 请求的拦截处理
    handleRequestIntercept(config)
    return config
  },
  (error) => Promise.reject(error))

// response interceptor
service.interceptors.response.use(
  (response) => {
    // 响应的拦截处理
    response.config && handleResponseIntercept(response.config)
    const {
      data,
    } = response
    const {
      code,
      msg,
    } = data
    if (
      code === 'merchant-manage.user-not-login' || // 用户未登录，跳转登录
      code === 'merchant-manage.user-no-permission' // 权限不足，跳转登录
    ) {
      let count = store.getters.toLoginCount
      if (count === 0) {
        code === 'merchant-manage.user-no-permission' && Message.error(msg) // 用户未登录，不弹信息
        router.push('/login')
      }
      // 清除缓存数据 和 router数据（预防直接输入url的操作）
      store.dispatch('logout')
      store.dispatch('ClearRouters')
      // hack 多次弹窗的问题
      store.dispatch('toLoginCount', 1)
      return Promise.reject(data)
    } else if (code !== 'success') {
      Message.error(msg)
      return Promise.reject(data)
    } else {
      return Promise.resolve(data)
    }
  },
  (error) => {
    const {
      response,
      message,
    } = error
    // 请求已发出，但服务器响应的状态码不在 2xx 范围内
    if (response) {
      // 响应的拦截处理
      response.config && handleResponseIntercept(response.config)
      if (response.status === 404) {
        Message.error('网络连接异常，' + message)
      } else {
        Message.error('请求系统发生错误，' + message)
      }
    }
    // 如果是主动取消了请求，做个标识
    if (axios.isCancel(error)) {
      error.selfCancel = true
    }
    return Promise.reject(error)
  }
)

export {
  pendingRequest,
}

export default service
