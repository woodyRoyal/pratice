export const pickerOptions = {
  disabledDate(time) {
    return time.getTime() < (Date.now() - 365 * 24 * 60 * 60 * 1000);
  },
  shortcuts: [{
    text: '最近一周',
    onClick(picker) {
      const end = new Date();
      const start = new Date();
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
      picker.$emit('pick', [start, end]);
    },
  }],
}
