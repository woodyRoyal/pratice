<template>
  <div>
    <el-card class="box-card">
      <div slot="header"
           class="clearfix">
        <span>个人信息</span>
      </div>
      <el-form ref="addForm"
               size="mini"
               :model="info"
               :rules="rules"
               label-width="100px">
        <el-form-item label="用户账号">
          <span class="itemFirst">{{ info.username }}</span>
        </el-form-item>
        <el-form-item label="用户角色">
          <span class="itemFirst">{{ info.roleNames }}</span>
        </el-form-item>
        <el-form-item label="用户手机号"
                      prop="phoneNo">
          <el-input v-model="info.phoneNo"
                    class="itemFirst"></el-input>
          <span class="font-info">用于接收各类提醒，请填写正确的手机号和邮箱</span>
        </el-form-item>
        <el-form-item label="用户邮箱"
                      prop="email">
          <el-input v-model="info.email"
                    class="itemFirst"></el-input>
        </el-form-item>
        <el-form-item label=" ">
          <el-button type="primary"
                     :loading="loading"
                     style="margin-left:50px;"
                     @click="onSubmit">
            提交
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import api from '../../api/userInfo'
export default {
  name: 'Personal',
  data () {
    return {
      loading: false,
      info: {
        roleNames: [],
        email: '',
        phoneNo: '',
        username: '',
      },
      rules: {
        phoneNo: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value) {
                callback(new Error('手机号码不能为空!'))
              } else if (!/^1\d{10}$/.test(value)) {
                callback(new Error('请输入正确的手机号码'))
              } else {
                callback()
              }
            },
          },
        ],
        email: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value) {
                callback(new Error('邮箱不能为空!'))
                // eslint-disable-next-line no-useless-escape
              } else if (!/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/.test(value)) {
                callback(new Error('请输入正确的邮箱'))
              } else {
                callback()
              }
            },
          },
        ],
      },
      resouce: {
        email: '',
        phoneNo: '',
      },
    }
  },
  created () {
    this.fetchData()
  },
  methods: {
    selectForm (str, resouce) {
      if (str.indexOf('*') > -1) {
        return resouce
      } else {
        return str
      }
    },
    async fetchData () {
      let res = await api.querySelf()
      res.result.roleNames = res.result.roleNames.join(',')
      this.info = res.result
      this.resouce = res.result
    },
    onSubmit () {
      this.loading = true
      this.$refs['addForm'].validate(async (valid) => {
        if (!valid) {
          this.loading = false
          return false
        }
        try {
          let confirm = await this.$confirm(`确定提交更改吗?`, '提示', { type: 'warning' })
          if (confirm) {
            let data = {
              email: this.selectForm(this.info.email, this.resouce.email),
              phoneNo: this.selectForm(this.info.phoneNo, this.resouce.phoneNo),
            }
            await api.updateSelf(data)
            this.loading = false
            this.$message.success('修改成功')
            this.fetchData()
          }
        } catch (error) {
          // error不传报错
          this.loading = false
        }
      })
    },
  },
}
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.itemFirst {
  width: 200px;
  // margin-left:50px;
}
.font-info {
  color: #99a9bf;
  font-size: 12px;
  margin-left: 10px;
}
</style>
