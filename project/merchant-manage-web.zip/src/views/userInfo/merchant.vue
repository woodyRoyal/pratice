<template>
  <div>
    <el-card class="box-card">
      <div slot="header"
           class="clearfix">
        <span>商户信息</span>
      </div>
      <el-form size="mini"
               label-width="140px">
        <el-form-item label="商户号">
          <span class="itemFirst">{{ info.merchantCode }}</span>
        </el-form-item>
        <el-form-item label="商户名称">
          <span class="itemFirst">{{ info.merchantName }}</span>
        </el-form-item>
        <el-form-item label="业务权限">
          <span class="itemFirst">{{ info.moduleService }}</span>
        </el-form-item>
        <el-form-item label="付款方式">
          <span class="itemFirst">{{ info.payType }}</span>
        </el-form-item>
        <el-form-item label="商户对接人手机号">
          <span class="itemFirst">{{ info.contactPhone }}</span>
        </el-form-item>
        <el-form-item label="商户对接人邮箱">
          <span class="itemFirst">{{ info.contactEmail }}</span>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>
<script>
import api from '../../api/userInfo'
export default {
  name: 'Personal',
  data () {
    return {
      info: {},
    }
  },
  created () {
    this.fetchData()
  },
  methods: {
    async fetchData () {
      let res = await api.queryMerchantInfo()
      this.info = res.result
    },
  },
}
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.itemFirst {
  width: 200px;
  margin-left: 50px;
}
.font-info {
  color: #99a9bf;
  font-size: 12px;
  margin-left: 10px;
}
</style>
