<!--角色管理-->
<template>
  <div class="role-manage">
    <!--表单-->
    <el-form :inline="true"
             :model="queryFormData"
             size="mini">
      <el-form-item label="角色名称">
        <el-input v-model="queryFormData.name"
                  clearable
                  placeholder="请输入角色名称"
                  @keyup.enter.native="handleSearchData">
        </el-input>
      </el-form-item>
      <el-form-item>
        <el-button v-directiveBtns="'/role/queryAll'"
                   type="primary"
                   @click="handleSearchData">
          查询
        </el-button>
        <el-button v-directiveBtns="'/role/queryAll'"
                   type="info"
                   @click="handleResetData">
          重置
        </el-button>
        <el-button v-directiveBtns="'/role/add'"
                   type="success"
                   style="margin-left: 100px;"
                   @click="handleAdd">
          新增角色
        </el-button>
      </el-form-item>
    </el-form>
    <!-- 表格 -->
    <VueTable :is-loading="isLoading"
              :columns="tableColumns"
              :data="tableData"
              :is-show-pagination="true"
              :pageable="pageable"
              @getTableData="getTableData">
      <template slot="permissions"
                slot-scope="{ row }">
        <span>{{ row.permissions.join('、') }}</span>
      </template>
      <template slot="status"
                slot-scope="{ row }">
        <div>{{ row.status ? '启用' : '禁用' }}</div>
      </template>
      <template slot="operation"
                slot-scope="{ row }">
        <el-button v-if="row.editable"
                   v-directiveBtns="'/role/update/\d+'"
                   type="primary"
                   size="mini"
                   icon="edit"
                   @click="handleEditRole(row)">
          编辑
        </el-button>
        <!-- <el-button v-if="row.editable"
                   v-directiveBtns="'/role/delete/\d+'"
                   type="danger"
                   icon="delete2"
                   size="mini"
                   @click="handleDeleteRole(row)">
          删除
        </el-button> -->
      </template>
    </vuetable>
    <!-- 新增或编辑角色 -->
    <el-dialog :title="dialogTitle"
               :visible.sync="dialogFormVisible"
               @close="handleDialogClose">
      <el-form ref="dialogForm"
               :model="dialogForm"
               :rules="dialogFormRules"
               label-width="80px">
        <el-form-item label="角色名称"
                      prop="name">
          <el-input v-model="dialogForm.name"
                    maxlength="20"
                    placeholder="请输入角色名称"></el-input>
        </el-form-item>
        <el-form-item label="角色描述"
                      prop="description">
          <el-input v-model="dialogForm.description"
                    type="textarea"
                    maxlength="100"
                    placeholder="请输入角色描述"
                    resize="none"></el-input>
        </el-form-item>
        <el-form-item label="角色权限"
                      prop="permissions"
                      class="is-required">
          <el-tree ref="permissionTreeData"
                   show-checkbox
                   highlight-current
                   style="max-height: 300px;overflow: auto"
                   default-expand-all
                   :data="permissionTreeData"
                   node-key="id"
                   :props="permissionTreeProps"
                   @check-change="handleCheckChange">
          </el-tree>
        </el-form-item>
        <el-form-item label="角色状态"
                      prop="status"
                      class="is-required">
          <el-radio v-model="dialogForm.status"
                    class="radio"
                    :label="1">
            启用
          </el-radio>
          <el-radio v-model="dialogForm.status"
                    class="radio"
                    :label="0">
            禁用
          </el-radio>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="handleCancel">
          取 消
        </el-button>
        <el-button type="primary"
                   :loading="isBtnLoading"
                   @click="handleConfirm">
          确 定
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import VueTable from '@/components/VueTable'
import sysApi from '../../api/sys'
import { differenceArr, isPermissionBtn } from '@/utils/index'
import { getFromStorage } from '@/utils/storage'

export default {
  name: 'Role',
  components: {
    VueTable,
  },
  data () {
    // 权限
    const validatePermission = (rule, value, callback) => {
      if (!value || value.length === 0) {
        callback(new Error('请选择角色权限'))
      } else {
        callback()
      }
    }
    return {
      // 查询表单参数
      queryFormData: {
        name: '', // 角色名称
      },
      isLoading: false,
      tableData: [],
      tableColumns: [
        { label: '角色名称', prop: 'name', align: 'center', width: 120 },
        { label: '角色描述', prop: 'description', align: 'center', width: 200, showOverflowTooltip: true },
        { label: '角色权限', slot: 'permissions', align: 'center' },
        { label: '角色状态', slot: 'status', align: 'center', width: 80 },
        { label: '操作', slot: 'operation', align: 'center', width: 200 },
      ],
      pageable: {
        pageNum: 1,
        pageSize: 100,
        pageSizes: [20, 50, 100],
        total: 0,
      },

      dialogFormVisible: false,

      permissionTreeData: [], // 权限树数据
      permissionListMap: {}, // 权限数据对象
      permissionTreeProps: { // 权限树配置 字段映射
        children: 'children',
        label: 'name',
        id: 'id',
      },

      dialogForm: {
        name: '',
        description: '',
        permissions: [],
        status: 1,
      },
      // 规则
      dialogFormRules: {
        name: [
          { required: true, message: '请输入角色名称', trigger: 'blur' },
        ],
        permissions: [
          { validator: validatePermission, trigger: 'change' },
        ],
      },
      dialogTitle: '', // 弹窗的title
      isBtnLoading: false, // 确定按钮控制
    }
  },
  created () {
    const btns = getFromStorage('local', 'btns')
    if (isPermissionBtn('/role/queryAll', btns)) {
      this.getTableData()
    }
    this.getPermissionTree()
  },
  methods: {
    // 处理分页每页显示数改变事件
    handleSizeChange (val) {
      this.queryFormData.pageSize = val
      this.getTableData()
    },
    // 处理页码改变事件
    handleCurrentChange (val) {
      this.queryFormData.pageNum = val
      this.getTableData()
    },
    // 搜索按钮
    handleSearchData () {
      this.getTableData()
    },
    // 重置
    handleResetData () {
      this.queryFormData.name = ''
      this.pageable.pageSize = 100
      this.pageable.pageNum = 1
      this.getTableData()
    },
    // 获取表格数据
    async getTableData () {
      let arr = Array.from(arguments)
      if (arr.length) {
        const { pageNum, pageSize } = arr[0]
        this.pageable.pageSize = pageSize
        this.pageable.pageNum = pageNum
      }
      this.isLoading = true
      try {
        const queryForm = {
          name: this.queryFormData.name,
          pageSize: this.pageable.pageSize,
          pageNo: this.pageable.pageNum,
        }
        const res = await sysApi.fetchRoleList(queryForm)
        this.tableData = res.result.list
        this.pageable.total = res.result.total
        this.isLoading = false
      } catch (e) {
        // 不是自动取消
        if (!e.selfCancel) {
          this.tableData = []
          this.pageable.total = 0
          this.isLoading = false
        }
      }
    },
    // 获取权限树
    async getPermissionTree () {
      const res = await sysApi.fetchPermissionTree()
      this.permissionTreeData = res.result
    },
    // 获取权限列表
    async getPermissionList () {
      const { result } = await sysApi.fetchPermissionList()
      if (result && result.length > 0) {
        for (let item of result) {
          this.permissionListMap[item.id] = item.name
        }
      }
    },
    // 新增角色
    handleAdd () {
      this.dialogTitle = '新增角色'
      this.dialogFormVisible = true
      this.dialogForm = {
        name: '',
        description: '',
        permissions: [],
        status: 1,
      }
    },
    // 清空树节点的选择
    resetChecked () {
      this.$refs.permissionTreeData.setCheckedKeys([])
    },
    // 通过key设置
    setCheckedKeys (keys) {
      this.$refs.permissionTreeData.setCheckedKeys(keys)
    },
    // Dialog 关闭的回调
    handleDialogClose () {
      // 表单置空
      this.dialogForm = {
        name: '',
        description: '',
        permissions: [],
        status: 1,
      }
      this.resetChecked()
      this.$refs['dialogForm'].resetFields()
    },
    // 点击编辑按钮，查询指定id的角色，打开dialog
    async handleEditRole (row) {
      const res = await sysApi.fetchGetRoleById(row.id)
      this.dialogTitle = '编辑角色'
      this.dialogFormVisible = true
      this.dialogForm = Object.assign({}, res.result)
      // 给权限树赋值（等视图渲染完再，不然undefined）
      this.$nextTick(() => {
        this.setCheckedKeys(res.result.permissions)
        // 去除父级id
        let arr = []
        this.permissionTreeData.forEach((item) => {
          if (item.children && item.children.length) {
            arr.push(item.id)
            item.children.forEach((j) => {
              if (j.children && j.children.length) {
                arr.push(j.id)
              }
            })
          }
        })
        let arr1 = differenceArr(res.result.permissions, arr)
        // 给权限树赋值
        this.setCheckedKeys(arr1)

      })
    },
    // 新增或编辑角色
    async saveOrUpdateRole (row) {
      this.isBtnLoading = true
      try {
        let queryForm = {
          name: row.name,
          description: row.description,
          permissions: row.permissions,
          status: row.status,
          id: row.id || null,
        }
        switch (this.dialogTitle) {
          case '新增角色':
            await sysApi.fetchAddRole(queryForm)
            this.$message.success('新增角色成功')
            break
          case '编辑角色':
            await sysApi.fetchUpdateRole(queryForm)
            this.$message.success('编辑角色成功')
            break
        }
        this.dialogFormVisible = false
        this.getTableData()
      } catch (e) {
        // 
      } finally {
        this.isBtnLoading = false
      }
    },
    // 删除当前角色
    handleDeleteRole (row) {
      this.$confirm('确定删除吗？删除后具有该角色的用户将取消权限?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }).then(() => {
        this.deleteRole(row.id)
      }).catch(() => {
        // 
      })
    },
    // 删除角色
    async deleteRole (id) {
      await sysApi.fetchDeleteRole(id)
      this.$message.success('删除成功')
      this.getTableData()
    },
    // 处理权限树选中事件
    handleCheckChange () {
      let authorityIds = this.$refs.permissionTreeData.getCheckedKeys()
      let arr = []
      // function addParentIdFun (tree, list, arr) {
      //   if (tree.children && tree.children.length) {
      //     tree.children.forEach((j) => {
      //       list.indexOf(j.id) > -1 && arr.push(j.parentId)
      //       addParentIdFun(j, list, arr)
      //     })
      //   }
      // }
      // // 添加父级id
      // this.permissionTreeData.forEach((item) => {
      //   addParentIdFun(item, authorityIds, arr)
      // })
      // console.log(arr);

      this.permissionTreeData.forEach((item) => {
        if (item.children && item.children.length) {
          item.children.forEach((j) => {
            // authorityIds.indexOf(j.id) > -1 && arr.push(j.parentId)
            if (j.children && j.children.length) {
              j.children.forEach((m) => {
                authorityIds.indexOf(m.id) > -1 && arr.push(m.parentId)
              })
            }
          })
        }
      })
      let authorityIds1 = authorityIds.concat(arr)
      let arr1 = []
      this.permissionTreeData.forEach((item) => {
        if (item.children && item.children.length) {
          item.children.forEach((j) => {
            authorityIds1.indexOf(j.id) > -1 && arr1.push(j.parentId)
          })
        }
      })
      let arr2 = authorityIds1.concat(arr1)
      // 数组去重-利用数组中的filter方法
      let r = arr2.filter((element, index, self) => self.indexOf(element) === index)
      this.dialogForm.permissions = r.sort()
    },
    // 确认添加角色
    handleConfirm () {
      this.submitForm('dialogForm')
    },
    // 取消添加角色
    handleCancel () {
      this.dialogFormVisible = false
      this.resetForm('dialogForm')
    },
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.saveOrUpdateRole(this.dialogForm)
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm (formName) {
      this.$refs[formName].resetFields()
    },
  },
}
</script>

<style lang="scss" scoped>
</style>
