<template>
  <div class="user-container">
    <!-- 表单 -->
    <el-form :inline="true"
             :model="queryFormData"
             size="mini">
      <el-form-item label="用户账号">
        <el-input v-model="queryFormData.username"
                  clearable
                  placeholder="请输入用户账号"
                  @keyup.enter.native="handleSearchData">
        </el-input>
      </el-form-item>
      <el-form-item label="用户手机号">
        <el-input v-model="queryFormData.phoneNo"
                  clearable
                  placeholder="请输入用户手机号"
                  @keyup.enter.native="handleSearchData">
        </el-input>
      </el-form-item>
      <el-form-item>
        <el-button v-directiveBtns="'/user/queryAll'"
                   type="primary"
                   @click="handleSearchData">
          查询
        </el-button>
        <el-button v-directiveBtns="'/user/queryAll'"
                   type="info"
                   @click="handleResetData">
          重置
        </el-button>
        <el-button v-directiveBtns="'/user/add'"
                   type="success"
                   style="margin-left: 100px;"
                   @click="handleAdd">
          新增用户
        </el-button>
      </el-form-item>
    </el-form>
    <!-- 表格 -->
    <VueTable :is-loading="isLoading"
              :columns="tableColumns"
              :data="tableData"
              :is-show-pagination="true"
              :pageable="pageable"
              @getTableData="getTableData">
      <template slot="id"
                slot-scope="{ row, $index }">
        <div>{{ $index + 1 }}</div>
      </template>
      <template slot="roleNameList"
                slot-scope="{ row }">
        <div>{{ row.roleNameList.join('、') }}</div>
      </template>
      <template slot="status"
                slot-scope="{ row }">
        <div>{{ row.status ? '启用' : '禁用' }}</div>
      </template>
      <template slot="operation"
                slot-scope="{ row }">
        <el-button v-if="row.editable"
                   v-directiveBtns="'/user/update/\d+'"
                   size="mini"
                   type="primary"
                   @click="handleUpdate(row)">
          编辑
        </el-button>
        <el-button v-if="row.editable"
                   v-directiveBtns="'/user/resetPassword/\d+'"
                   size="mini"
                   type="danger"
                   @click="handleResetPassword(row)">
          重置密码
        </el-button>
      </template>
    </vuetable>
    <!-- 弹窗（新增/编辑用户） -->
    <el-dialog :title="dialogTitle"
               :visible.sync="dialogFormVisible"
               @close="handleDialogClose">
      <el-form ref="dialogForm"
               size="small"
               :model="dialogForm"
               :rules="dialogFormRules"
               label-width="100px">
        <el-form-item label="用户手机号"
                      prop="phoneNo">
          <el-input v-model="dialogForm.phoneNo"
                    placeholder="用于接收短信，请填写正确的手机号"></el-input>
        </el-form-item>
        <el-form-item label="用户邮箱"
                      prop="email">
          <el-input v-model="dialogForm.email"
                    placeholder="用于接收密码，请填写正确的邮箱"></el-input>
        </el-form-item>
        <el-form-item label="登录账号"
                      prop="username">
          <el-input v-model="dialogForm.username"
                    maxlength="15"
                    :disabled="dialogTitle === '编辑用户'"
                    placeholder="可使用姓名拼音，比如zhaol"></el-input>
        </el-form-item>
        <el-form-item label="用户角色"
                      prop="roleIds">
          <el-select v-model="dialogForm.roleIds"
                     style="width: 100%;"
                     multiple
                     placeholder="请选择用户角色">
            <el-option v-for="item in roleList"
                       :key="item.id"
                       :label="item.name"
                       :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="账号状态"
                      prop="status"
                      class="is-required">
          <el-radio v-model="dialogForm.status"
                    class="radio"
                    :label="1">
            启用
          </el-radio>
          <el-radio v-model="dialogForm.status"
                    class="radio"
                    :label="0">
            禁用
          </el-radio>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="handleCancel">
          取 消
        </el-button>
        <el-button type="primary"
                   :loading="isBtnLoading"
                   @click="handleConfirm">
          确 定
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import VueTable from '@/components/VueTable'
import sysApi from '@/api/sys'
import { isPermissionBtn } from '@/utils/index'
import { getFromStorage } from '@/utils/storage'

export default {
  name: 'User',
  components: {
    VueTable,
  },
  data () {
    return {
      // 查询表单参数
      queryFormData: {
        username: '', // 账号
        phoneNo: '', // 手机号
      },
      isLoading: false,
      tableData: [],
      tableColumns: [
        { label: '序号', slot: 'id', align: 'center', width: 60 },
        { label: '用户账号', prop: 'username', align: 'center' },
        { label: '用户手机号', prop: 'phoneNo', align: 'center' },
        { label: '用户邮箱', prop: 'email', align: 'center' },
        { label: '用户角色', slot: 'roleNameList', align: 'center' },
        { label: '账号状态', slot: 'status', align: 'center' },
        { label: '操作', slot: 'operation', align: 'center', width: 200 },
      ],
      pageable: {
        pageNum: 1,
        pageSize: 100,
        pageSizes: [20, 50, 100],
        total: 0,
      },
      roleList: [], // 全部角色列表
      dialogForm: {
        phoneNo: '',
        email: '',
        username: '',
        roleIds: [],
        status: 1,
      },
      dialogFormRules: {
        phoneNo: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value) {
                callback(new Error('手机号码不能为空!'))
              } else if (!/^1\d{10}$/.test(value)) {
                callback(new Error('请输入正确的手机号码'))
              } else {
                callback()
              }
            },
          },
        ],
        email: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (!value) {
                callback(new Error('邮箱不能为空!'))
                // eslint-disable-next-line no-useless-escape
              } else if (!/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/.test(value)) {
                callback(new Error('请输入正确的邮箱'))
              } else {
                callback()
              }
            },
          },
        ],
        username: [
          { required: true, message: '请输入登录账号', trigger: 'blur' },
        ],
        roleIds: [
          { required: true, message: '请输入用户角色', trigger: 'change' },
        ],
      },
      dialogTitle: '',
      dialogFormVisible: false,
      isBtnLoading: false, // 确定按钮控制
    }
  },
  created () {
    this.getRoleList()
    const btns = getFromStorage('local', 'btns')
    if (isPermissionBtn('/role/queryAll', btns)) {
      this.getTableData()
    }
  },
  methods: {
    // 搜索按钮
    handleSearchData () {
      this.getTableData()
    },
    // 重置
    handleResetData () {
      this.queryFormData.username = ''
      this.queryFormData.phoneNo = ''
      this.pageable.pageSize = 100
      this.pageable.pageNum = 1
      this.getTableData()
    },
    // 获取表格数据
    async getTableData () {
      let arr = Array.from(arguments)
      if (arr.length) {
        const { pageNum, pageSize } = arr[0]
        this.pageable.pageSize = pageSize
        this.pageable.pageNum = pageNum
      }
      this.isLoading = true
      try {
        const queryForm = {
          pageSize: this.pageable.pageSize,
          pageNo: this.pageable.pageNum,
          username: this.queryFormData.username,
          phoneNo: this.queryFormData.phoneNo,
        }
        const res = await sysApi.fetchUserList(queryForm)
        this.tableData = res.result.list
        this.pageable.total = res.result.total
        this.isLoading = false
      } catch (e) {
        // 不是自动取消
        if (!e.selfCancel) {
          this.tableData = []
          this.pageable.total = 0
          this.isLoading = false
        }
      }
    },
    // 获取角色列表
    async getRoleList () {
      const res = await sysApi.fetchStatusOnRoleList()
      this.roleList = res.result
    },
    // 新增用户
    handleAdd () {
      this.dialogTitle = '新增用户'
      this.dialogFormVisible = true
    },
    // 编辑用户，查询指定id的用户，打开dialog
    async handleUpdate (row) {
      const res = await sysApi.fetchGetUserById(row.uid)
      this.dialogTitle = '编辑用户'
      this.dialogFormVisible = true
      this.dialogForm = Object.assign({}, res.result)
    },
    // 确认用户
    handleConfirm () {
      this.$refs['dialogForm'].validate((valid) => {
        if (valid) {
          this.addOrUpdateUser()
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    async addOrUpdateUser () {
      this.isBtnLoading = true
      try {
        let queryForm = {}
        switch (this.dialogTitle) {
          case '新增用户':
            queryForm = {
              phoneNo: this.dialogForm.phoneNo,
              email: this.dialogForm.email,
              accountNumber: this.dialogForm.username,
              roleIds: this.dialogForm.roleIds,
              status: this.dialogForm.status,
            }
            await sysApi.fetchAddUser(queryForm)
            this.$message.success('用户创建成功，账号和密码已发送至该用户绑定的邮箱中')
            break
          case '编辑用户':
            queryForm = {
              id: this.dialogForm.uid,
              phoneNo: this.dialogForm.phoneNo,
              email: this.dialogForm.email,
              accountNumber: this.dialogForm.username,
              roleIds: this.dialogForm.roleIds,
              status: this.dialogForm.status,
            }
            await sysApi.fetchUpdateUser(queryForm)
            this.$message.success('编辑用户成功')
            break
        }
        this.dialogFormVisible = false
        this.getTableData()
      } catch (e) {
        // 
      } finally {
        this.isBtnLoading = false
      }
    },
    // 取消用户
    handleCancel () {
      this.dialogFormVisible = false
      this.$refs['dialogForm'].resetFields()
      this.clearDialogForm()
    },
    // Dialog 关闭的回调
    handleDialogClose () {
      this.$refs['dialogForm'].resetFields()
      this.clearDialogForm()
    },
    // 重置用户信息
    clearDialogForm () {
      this.dialogForm = {
        phoneNo: '',
        email: '',
        username: '',
        roleIds: [],
        status: 1,
      }
    },
    // 重置密码按钮
    handleResetPassword (row) {
      this.$confirm('确定重置用户密码吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }).then(() => {
        this.resetPassword(row.uid)
      }).catch(() => {
        // 
      })
    },
    // 重置密码
    async resetPassword (id) {
      await sysApi.fetchResetPassword(id)
      this.$message.success('重置密码成功，新密码已发送至该用户邮箱')
    },
  },
}
</script>

<style lang="scss" scoped>
</style>
