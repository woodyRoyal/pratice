export const statusCodeMap = {
  0: '全部',
  1: '成功',
  2: '失败',
  3: '处理中',
  4: '未鉴权',
}
// 若商户为不需要配置结算标记的商户，展示字段内容
export const tradeStatisticsDayTableALL = [{
  label: '渠道商户号',
  align: 'center',
  prop: 'channelMerchantCode',
},
{
  label: '商户订单号',
  prop: 'merchantOrderNumber',
  align: 'center',
},
{
  label: '交易订单号',
  prop: 'tradeOrderNumber',
  align: 'center',
},
{
  label: '支付通道',
  prop: 'payChannel',
  align: 'center',
},
{
  label: '交易类型',
  prop: 'tradeTypeDesc',
  align: 'center',
},
{
  label: '请求扣款金额（元）',
  prop: 'requestTradeAmountStr',
  align: 'center',
},
{
  label: '成功交易金额（元）',
  prop: 'tradeAmountStr',
  align: 'center',
},
{
  label: '交易状态',
  prop: 'tradeStatusDesc',
  align: 'center',
},
{
  label: '订单创建时间',
  prop: 'orderCreateTimeDesc',
  align: 'center',
},
{
  label: '订单完成时间',
  prop: 'orderFinishTime',
  align: 'center',
},
]
// 若商户为需要配置结算标记的商户，展示字段内容：
export const tradeStatisticsDayTable = [
  // { label: '渠道商户号', align: 'center',prop: 'channelAccountNo'},
  {
    label: '商户订单号',
    prop: 'merchantOrderNumber',
    align: 'center',
  },
  {
    label: '交易订单号',
    prop: 'tradeOrderNumber',
    align: 'center',
  },
  {
    label: '支付通道',
    prop: 'payChannel',
    align: 'center',
  },
  {
    label: '交易类型',
    prop: 'tradeTypeDesc',
    align: 'center',
  },
  {
    label: '请求扣款金额（元）',
    prop: 'requestTradeAmountStr',
    align: 'center',
  },
  {
    label: '成功交易金额（元）',
    prop: 'tradeAmountStr',
    align: 'center',
  },
  {
    label: '交易状态',
    prop: 'tradeStatusDesc',
    align: 'center',
  },
  {
    label: '订单创建时间',
    prop: 'orderCreateTimeDesc',
    align: 'center',
  },
  {
    label: '订单完成时间',
    prop: 'orderFinishTime',
    align: 'center',
  },
]
