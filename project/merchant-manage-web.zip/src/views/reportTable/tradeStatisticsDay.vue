<template>
  <div>
    <el-form size="mini"
             :inline="true"
             label-width="100px">
      <el-form-item label="订单创建时间">
        <el-date-picker v-model="queryForm.time"
                        style="width:350px;"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        :picker-options="pickerOptions"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期"
                        align="right">
        </el-date-picker>
      </el-form-item>
      <el-form-item v-if="!settlementFlag"
                    label="渠道商户号">
        <el-select v-model.trim="queryForm.channelMerchantCode"
                   class="queryItem"
                   clearable>
          <el-option value=""
                     label="全部"></el-option>
          <el-option v-for="(item,index) in tradeChannelMerchantNoList"
                     :key="index"
                     :value="item"
                     :label="item">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label=" "
                    label-width="30px">
        <el-button v-directiveBtns="'/tradeStatisticsDay/list'"
                   type="primary"
                   :loading="isLoading"
                   @click="fetchData">
          查询
        </el-button>
      </el-form-item>
      <el-form-item label=" "
                    label-width="30px">
        <el-button v-directiveBtns="'/tradeStatisticsDay/exportPre'"
                   type="primary"
                   :loading="downLoading"
                   @click="down">
          下载
        </el-button>
      </el-form-item>
    </el-form>
    <VueTable :is-loading="isLoading"
              :columns="tableColumns"
              :data="tableData"
              :is-show-pagination="true"
              :pageable="pageable"
              @getTableData="fetchData">
    </VueTable>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import api from '../../api/reportTable/tradeStatisticsDay'
import { getDay, validateDay, pollingStart } from '../../utils/common'
import commonApi from '../../api/commonApi/commonApi'
import { tradeStatisticsDayTableALL, tradeStatisticsDayTable } from './config'
import VueTable from '@/components/VueTable'
import { isPermissionBtn } from '@/utils/index'
export default {
  name: 'Personal',
  components: { VueTable },
  data () {
    return {
      //下载按钮
      downLoading: false,
      serialNumber: null,
      //轮询次数
      count: 0,
      // 列表查询loading
      isLoading: false,
      // 轮询定时器id
      timer: null,
      // 表格配置
      tableColumns: [],
      pickerOptions: {
        disabledDate (time) {
          return time.getTime() < (Date.now() - 365 * 24 * 60 * 60 * 1000);
        },
        shortcuts: [{
          text: '最近一周',
          onClick (picker) {
            const end = new Date();
            const start = new Date();
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
            picker.$emit('pick', [start, end]);
          },
        }],
      },
      //交易商户号
      tradeChannelMerchantNoList: [],
      queryForm: {
        time: [],
        // 商户号
        channelMerchantCode: '',
      },
      tableData: [],
      pageable: {
        pageNum: 1,
        pageSize: 100,
        pageSizes: [20, 50, 100],
        total: 0,
      },
    }
  },
  computed: {
    ...mapGetters([
      'boxHeight',
      'settlementFlag',
    ]),
  },
  created () {
    // settlementFlag  0 ：不需要结算标记  1：需要结算标记‘
    // 0： 显示全项  1： 隐藏部分项 不需要拉取对应数据
    if (!this.settlementFlag) {
      this.fetchTradeChannelMerchantNo()
    }
    this.checkColumns()
    this.initForm()
    // 有权限就自动查询
    if (isPermissionBtn('/tradeStatisticsDay/list')) {
      this.fetchData({})
    }
  },
  methods: {
    // 开始下载
    async down () {
      try {
        let flag = validateDay(this.queryForm.time[0], this.queryForm.time[1], 7)
        if (!flag) {
          return this.$message.warning(`查询时间跨度支持7天内`)
        }
        this.downLoading = true
        let data = {
          ...this.queryForm,
          orderCreateDateBegin: this.queryForm.time[0] ? this.queryForm.time[0] : '',
          orderCreateDateEnd: this.queryForm.time[1] ? this.queryForm.time[1] : '',
          pageNum: this.pageable.pageNum,
          pageSize: this.pageable.pageSize,
        }
        delete data.time
        const res = await api.exportPre(data)
        this.serialNumber = res.result
        this.timer = setInterval(() => { pollingStart(this) }, 3000);
      } catch (error) {
        this.downLoading = false
      }
    },
    // settlementFlag  0 ：不需要结算标记  1：需要结算标记‘
    // 0： 显示全列表项  1： 隐藏部分列表项 
    checkColumns () {
      if (!this.settlementFlag) {
        this.tableColumns = tradeStatisticsDayTableALL
      } else {
        this.tableColumns = tradeStatisticsDayTable
      }
    },
    async fetchTradeChannelMerchantNo () {
      const res = await commonApi.tradeChannelMerchantNo()
      this.tradeChannelMerchantNoList = res.result
    },
    initForm () {
      this.queryForm.time = [getDay('YYYY-MM-DD'), getDay('YYYY-MM-DD')]
    },
    async fetchData (pageable) {
      let flag = validateDay(this.queryForm.time[0], this.queryForm.time[1], 7)
      if (!flag) {
        return this.$message.warning(`查询时间跨度支持7天内`)
      }
      if (pageable.pageNum) {
        this.pageable.pageNum = pageable.pageNum
        this.pageable.pageSize = pageable.pageSize
      }
      let data = {
        ...this.queryForm,
        orderCreateDateBegin: this.queryForm.time[0] ? this.queryForm.time[0] : '',
        orderCreateDateEnd: this.queryForm.time[1] ? this.queryForm.time[1] : '',
        pageNum: this.pageable.pageNum,
        pageSize: this.pageable.pageSize,
      }
      delete data.time
      this.isLoading = true
      try {
        let res = await api.tradeStatisticsDay(data)
        this.tableData = res.result.list
        this.pageable.total = res.result.total
      } catch (e) {
        this.tableData = []
      } finally {
        this.isLoading = false
      }
    },
  },
}
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.itemFirst {
  width: 200px;
  margin-left: 50px;
}
.font-info {
  color: #99a9bf;
  font-size: 12px;
  margin-left: 10px;
}
.queryItem {
  width: 120px;
}
</style>
