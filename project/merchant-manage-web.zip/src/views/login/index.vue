<template>
  <div class="login-container">
    <div class="login-main">
      <div class="login-left"></div>
      <div class="login-right">
        <div class="login-right-main">
          <!-- <div class="logo"></div> -->
          <div class="title">
            商户服务平台
          </div>
          <div class="username">
            <label for="username"
                   class="icon"></label>
            <input id="username"
                   v-model="loginForm.username"
                   type="text"
                   spellcheck="false"
                   placeholder="请输入登录账号"
                   @keyup.enter="handleLogin">
          </div>
          <div class="password">
            <label for="password"
                   class="icon"></label>
            <input id="password"
                   v-model="loginForm.password"
                   type="password"
                   spellcheck="false"
                   placeholder="请输入登录密码"
                   @keyup.enter="handleLogin">
          </div>
          <div class="captcha">
            <label for="captcha"
                   class="icon"></label>
            <input id="captcha"
                   v-model="loginForm.captcha"
                   type="text"
                   spellcheck="false"
                   placeholder="请输入验证码"
                   maxlength="4"
                   @keyup.enter="handleLogin">
            <img :src="captchaSrc"
                 alt=""
                 @click="getCaptcha">
          </div>
          <el-button class="login-button"
                     size="small"
                     :loading="isLoading"
                     @click="handleLogin">
            登录
          </el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import userApi from '../../api/user'
import {
  saveToStorage,
} from '@/utils/storage'
export default {
  name: 'Login',
  data () {
    return {
      isLoading: false,
      loginForm: {
        username: '',
        password: '',
        captcha: '',
      },
      captchaSrc: '', // 验证码base64
    }
  },
  created () {
    this.getCaptcha()
  },
  methods: {
    // 获取验证码
    async getCaptcha () {
      // 每次错误提示后，验证码需刷新，验证码输入框均需置空重新填写
      this.loginForm.captcha = ''
      const { result } = await userApi.fetchGetCaptcha()
      this.captchaSrc = result
    },
    // 登录
    async handleLogin () {
      if (!this.loginForm.username) {
        this.$message.warning('请输入登录账号')
        this.getCaptcha()
        return false
      } else if (!this.loginForm.password) {
        this.$message.warning('请输入登录密码')
        this.getCaptcha()
        return false
      } else if (!this.loginForm.captcha) {
        this.$message.warning('请根据图片输入图形验证码')
        this.getCaptcha()
        return false
      }
      this.isLoading = true
      try {
        const queryForm = {
          username: this.loginForm.username,
          password: this.loginForm.password,
          captcha: this.loginForm.captcha,
        }
        const res = await userApi.fetchLogin(queryForm)
        if (res.code === 'success') {
          // 登陆成功 清除缓存数据 和 router数据（预防不走退出，直接登录的操作）
          this.$store.dispatch('logout')
          this.$store.dispatch('ClearRouters')
          // 存储登录标志到storage
          this.$store.dispatch('username', this.loginForm.username)
          // 重置toLoginCount
          this.$store.dispatch('toLoginCount', 0)
          // 查询自身权限列表
          this.getMenuTreeList()
        } else {
          this.getCaptcha()
        }
      } catch (e) {
        this.getCaptcha()
      } finally {
        this.isLoading = false
      }
    },
    // 处理成权限按钮数组
    changeBtns (arr, btns) {
      arr.forEach((v) => {
        if (v.type === 1) {
          btns.push(v.path)
        }
        if (v.children && v.children.length > 0) {
          this.changeBtns(v.children, btns)
        }
      })
      return btns
    },
    // 查询自身权限列表
    async getMenuTreeList () {
      // 登录成功后，切换路由到首页，接口不取消请求
      let res = await userApi.fetchGetMenuTreeList({ routeChangeCancel: false })
      let btns = this.changeBtns(res.result, [])
      saveToStorage('local', 'btns', btns)
      function menuTreeListFuc (menu) {
        if (menu.children && menu.children.length > 0) {
          if (menu.children[0].type === 1) {
            menu.children = null
          } else {
            menu.children = menu.children.map((item) => menuTreeListFuc(item))
          }
        }
        return menu
      }
      const menuTreeList = res.result.map((menu) => {
        menuTreeListFuc(menu)
        return menu
      })
      // await userApi.fetchGetPermissionList()
      // 存储登录标志到storage
      this.$store.dispatch('menuTreeList', menuTreeList)
      // 跳转到首页
      this.$router.push({ path: '/home/index' })
    },
  },
}
</script>

<style lang="scss" scoped>
.login-container {
  width: 100%;
  height: 100%;
  background-color: #f9fcff;
  .login-main {
    width: 800px;
    height: 460px;
    box-shadow: 0 2px 20px 0 rgba(57, 104, 249, 0.11);
    border-radius: 8px;
    position: absolute;
    margin: auto;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    display: flex;
    justify-content: center;
    background-color: #fff;
    .login-left {
      width: 390px;
      background: url('../../assets/login/banner.png') center center no-repeat;
      -webkit-background-size: 390px 460px;
      background-size: 390px 460px;
    }
    .login-right {
      width: 410px;
      height: 460px;
      .login-right-main {
        width: 282px;
        height: 304px;
        margin: 52px 64px 104px 64px;
        /*background-color: #48e79a;*/
        .logo {
          width: 100%;
          height: 60px;
          padding: 0 111px;
          background: url('../../assets/login/logo.png') center center no-repeat;
          -webkit-background-size: 60px 60px;
          background-size: 60px 60px;
        }
        .title {
          width: 100%;
          height: 46px;
          line-height: 46px;
          text-align: center;
          // font-size: 18px;
          font-size: 26px;
          font-weight: bolder;
          color: #2d6bfa;
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
        }
        .username,
        .password,
        .captcha {
          height: 46px;
          margin-top: 14px;
          margin-left: 11px;
          margin-right: 11px;
          border-bottom: 1px solid #e7e7e7;
          display: flex;
          justify-content: center;
          .icon {
            width: 38px;
            height: 46px;
          }
          input {
            /*首先要将input输入框的默认样式去掉*/
            -web-kit-appearance: none;
            -moz-appearance: none;
            /*设置input的高度和字体大小和颜色*/
            font-size: 14px;
            width: 222px;
            height: 45px;
            font-weight: bolder;
            border: 0;
            color: #333;
            /*然后将input输入框的轮廓去掉：*/
            outline: 0;
          }
        }

        .captcha {
          justify-content: left;
          input {
            width: 100px;
          }
          img {
            cursor: pointer;
          }
        }
        .username .icon {
          background: url('../../assets/login/name.png') center center no-repeat;
          -webkit-background-size: 22px 22px;
          background-size: 22px 22px;
        }
        .password .icon {
          background: url('../../assets/login/password.png') center center no-repeat;
          -webkit-background-size: 22px 22px;
          background-size: 22px 22px;
        }
        .captcha .icon {
          background: url('../../assets/login/captcha.png') center center no-repeat;
          -webkit-background-size: 22px 22px;
          background-size: 22px 22px;
        }
        .login-button {
          width: 100%;
          height: 44px;
          margin-top: 34px;
          font-size: 16px;
          font-weight: bolder;
          letter-spacing: 0;
          color: #fff;
          background-image: linear-gradient(33deg, #296cfa 0%, #685ef8 100%);
          border-radius: 22px;
          &:hover {
            background-image: linear-gradient(33deg, #124cc9 0%, #3328d6 100%);
          }
        }
      }
    }
  }
  /* autocomplete属性 导致输入框背景色变黄 设置内置阴影或autocomplete="off" */
  input:-webkit-autofill,
  textarea:-webkit-autofill,
  select:-webkit-autofill {
    box-shadow: 0 0 0 1000px #fff inset;
    -webkit-text-fill-color: #333; //设置字体颜色
  }

  /* 输入框占位符的color */
  input::-webkit-input-placeholder {
    color: #d5dbe6;
  }
  input:-moz-placeholder {
    color: #d5dbe6;
  }
  input::-moz-placeholder {
    color: #d5dbe6;
  }
  input:-ms-input-placeholder {
    color: #d5dbe6;
  }
}
</style>
