<template>
  <div class="home-container">
    <el-form size="mini"
             :inline="true"
             class="form-container"
             :model="merchantInfo"
             label-width="100px">
      <el-form-item label="商户号">
        <span>{{ merchantInfo.merchantCode }}</span>
      </el-form-item>
      <el-form-item label="商户名称">
        <span>{{ merchantInfo.merchantName }}</span>
      </el-form-item>
    </el-form>
    <div class="welcome-container">
      <p>欢迎来到 {{ currentSysName }}</p>
      <p>使用过程中遇到任何问题可联系平台商务人员</p>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { sysname } from '../../../package'
import userApi from '@/api/user'
export default {
  name: 'HomeIndex',
  data () {
    return {
      currentSysName: sysname, // 当前系统名称
    }
  },
  computed: {
    ...mapGetters([
      'merchantInfo',
    ]),
  },
  created () {
    // 获取自身是否需结算标记
    this.fetchSettlementFlag()
  },
  methods: {
    async fetchSettlementFlag () {
      // 登录成功后，切换路由到首页，接口不取消请求
      const res = await userApi.queryMerchantInfo()
      let settlementFlag = parseInt(res.result.settlementFlag)
      this.$store.commit('SET_FLAG', settlementFlag)
      this.$store.commit('SET_MERCHANT', res.result)
    },
  },
}
</script>

<style lang="scss" scoped>
.home-container {
  .form-container {
    border-bottom: 2px solid #ddd;
  }
  .welcome-container {
    margin: 200px auto;
    color: #99a9bf;
    width: 100%;
    font-size: 20px;
    text-align: center;
  }
}
</style>
