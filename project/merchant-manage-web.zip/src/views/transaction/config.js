export const statusCodeMap = {
  0: '全部',
  1: '成功',
  2: '失败',
  3: '处理中',
  4: '未鉴权',
}
// 若商户为不需要配置结算标记的商户，展示字段内容
export const authTableALL = [{
    label: '渠道商户号',
    align: 'center',
    prop: 'channelAccountNo',
  },
  {
    label: '鉴权订单号',
    prop: 'reqOrderNo',
    align: 'center',
  },
  {
    label: '客户姓名',
    prop: 'idCardNameMask',
    align: 'center',
  },
  {
    label: '手机号码',
    prop: 'reservePhoneMask',
    align: 'center',
  },
  {
    label: '身份证编号',
    prop: 'idCardNoMask',
    align: 'center',
  },
  {
    label: '银行卡编号',
    prop: 'bankCardNoMask',
    align: 'center',
  },
  {
    label: '鉴权渠道',
    prop: 'payChannelCode',
    align: 'center',
  },
  {
    label: '鉴权状态',
    prop: 'statusDesc',
    align: 'center',
  },
  {
    label: '鉴权发起时间',
    prop: 'tradeAuthBeginTime',
    align: 'center',
  },
  {
    label: '鉴权完成时间',
    prop: 'tradeAuthFinishTime',
    align: 'center',
  },
]
// 若商户为需要配置结算标记的商户，展示字段内容
export const authTable = [
  // { label: '渠道商户号', align: 'center',prop: 'channelAccountNo'},
  {
    label: '鉴权订单号',
    prop: 'reqOrderNo',
    align: 'center',
  },
  {
    label: '客户姓名',
    prop: 'idCardNameMask',
    align: 'center',
  },
  {
    label: '手机号码',
    prop: 'reservePhoneMask',
    align: 'center',
  },
  {
    label: '身份证编号',
    prop: 'idCardNoMask',
    align: 'center',
  },
  {
    label: '银行卡编号',
    prop: 'bankCardNoMask',
    align: 'center',
  },
  // { label: '鉴权渠道',prop: 'payChannelCode',  align: 'center' },
  {
    label: '鉴权状态',
    prop: 'statusDesc',
    align: 'center',
  },
  {
    label: '鉴权发起时间',
    prop: 'tradeAuthBeginTime',
    align: 'center',
  },
  {
    label: '鉴权完成时间',
    prop: 'tradeAuthFinishTime',
    align: 'center',
  },
]

//若商户为不需要配置结算标记的商户，展示字段内容
export const PaymentTableALL = [{
    label: '渠道商户号',
    align: 'center',
    prop: 'channelAccountNo',
  },
  {
    label: '商户订单号',
    prop: 'reqOrderNo',
    align: 'center',
  },
  {
    label: '交易订单号',
    prop: 'businessOrderNo',
    align: 'center',
  },
  {
    label: '支付通道',
    prop: 'payChannelCode',
    align: 'center',
  },
  {
    label: '交易类型',
    prop: 'repaymentTypeDesc',
    align: 'center',
  },
  {
    label: '请求扣款金额（元）',
    prop: 'totalAmount',
    align: 'center',
  },
  {
    label: '成功交易金额（元）',
    prop: 'actualTotalAmount',
    align: 'center',
  },
  {
    label: '交易状态',
    prop: 'statusDesc',
    align: 'center',
  },
  {
    label: '订单创建时间',
    prop: 'tradeRepaymentBeginTime',
    align: 'center',
  },
  {
    label: '订单完成时间',
    prop: 'tradeRepaymentFinishTime',
    align: 'center',
  },
]
//若商户为需要配置结算标记的商户，展示字段内容
export const PaymentTable = [
  // { label: '渠道商户号', align: 'center',prop: 'channelAccountNo'},
  // { label: '商户订单号', prop: 'reqOrderNo', align: 'center'},
  {
    label: '交易订单号',
    prop: 'businessOrderNo',
    align: 'center',
  },
  // { label: '支付通道',prop: 'payChannelCode',  align: 'center' },
  // { label: '交易类型',prop: 'repaymentTypeCode',  align: 'center' },
  {
    label: '请求扣款金额（元）',
    prop: 'totalAmount',
    align: 'center',
  },
  {
    label: '成功交易金额（元）',
    prop: 'actualTotalAmount',
    align: 'center',
  },
  {
    label: '交易状态',
    prop: 'statusDesc',
    align: 'center',
  },
  {
    label: '订单创建时间',
    prop: 'tradeRepaymentBeginTime',
    align: 'center',
  },
  {
    label: '订单完成时间',
    prop: 'tradeRepaymentFinishTime',
    align: 'center',
  },
]
