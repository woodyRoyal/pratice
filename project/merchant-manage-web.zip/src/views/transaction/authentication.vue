<template>
  <div>
    <el-form size="mini"
             :inline="true"
             label-width="100px">
      <el-form-item label="鉴权发起时间">
        <el-date-picker v-model="queryForm.time"
                        style="width:350px;"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        :picker-options="pickerOptions"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期"
                        align="right">
        </el-date-picker>
      </el-form-item>
      <el-form-item v-if="!settlementFlag"
                    label="渠道商户号">
        <el-select v-model="queryForm.channelAccountNo"
                   class="queryItem"
                   clearable>
          <el-option value=""
                     label="全部"></el-option>
          <el-option v-for="(item,index) in signChannelMerchantNoList"
                     :key="index"
                     :value="item"
                     :label="item">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item v-if="!settlementFlag"
                    label="鉴权状态">
        <el-select v-model="queryForm.status"
                   class="queryItem"
                   clearable>
          <el-option value=""
                     label="全部"></el-option>
          <el-option v-for="(item,index) in signStatusList"
                     :key="index"
                     :value="item.code"
                     :label="item.message">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item v-if="!settlementFlag"
                    label="鉴权渠道">
        <el-select v-model="queryForm.payChannelCode"
                   class="queryItem"
                   clearable>
          <el-option value=""
                     label="全部"></el-option>
          <el-option v-for="(item,index) in signChannelList"
                     :key="index"
                     :value="item"
                     :label="item">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item v-if="!settlementFlag"
                    label="客户姓名">
        <el-input v-model="queryForm.idCardName"
                  class="queryItem"></el-input>
      </el-form-item>
      <el-form-item v-if="!settlementFlag"
                    label="手机号码">
        <el-input v-model="queryForm.reservePhone"
                  class="queryItem"></el-input>
      </el-form-item>
      <el-form-item v-if="!settlementFlag"
                    label="身份证编号">
        <el-input v-model="queryForm.idCardNo"
                  class="queryItem"></el-input>
      </el-form-item>
      <el-form-item v-if="!settlementFlag"
                    label="银行卡编号">
        <el-input v-model="queryForm.bankCardNo"
                  class="queryItem"></el-input>
      </el-form-item>
      <el-form-item label="鉴权订单号">
        <el-input v-model="queryForm.reqOrderNo"
                  class="queryItem"></el-input>
      </el-form-item>
      <el-form-item label=" "
                    label-width="30px">
        <el-button v-directiveBtns="'/tradeInfo/authList'"
                   type="primary"
                   :loading="isLoading"
                   @click="fetchData">
          查询
        </el-button>
      </el-form-item>
    </el-form>
    <VueTable :is-loading="isLoading"
              :columns="tableColumns"
              :data="tableData"
              :is-show-pagination="true"
              :pageable="pageable"
              @getTableData="fetchData">
              <!--行数据 row-->
    </VueTable>
  </div>
</template>

<script>
import { mapGetters, mapState } from 'vuex'
import api from '../../api/transaction/authentication'
import commonApi from '../../api/commonApi/commonApi'
import { getDay, validateDay } from '../../utils/common'
import { isPermissionBtn } from '@/utils/index'
import { authTableALL, authTable } from './config'
import VueTable from '@/components/VueTable'
export default {
  name: 'Personal',
  components: { VueTable },
  data () {
    return {
      // 列表loading
      isLoading: false,
      // 表格列参数
      tableColumns: [],
      pickerOptions: {
        disabledDate (time) {
          return time.getTime() < (Date.now() - 365 * 24 * 60 * 60 * 1000);
        },
        shortcuts: [{
          text: '最近一周',
          onClick (picker) {
            const end = new Date();
            const start = new Date();
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
            picker.$emit('pick', [start, end]);
          },
        }],
      },
      queryForm: {
        // 发起时间
        time: [],
        //渠道商户号
        channelAccountNo: '',
        // 鉴权状态
        status: '',
        // 鉴权渠道
        payChannelCode: '',
        // 客户姓名
        idCardName: '',
        // 身份证编号
        idCardNo: '',
        // 手机号码
        reservePhone: '',
        // 银行卡编号
        bankCardNo: '',
        // 鉴权订单号
        reqOrderNo: '',
      },
      tableData: [],
      pageable: {
        pageNum: 1,
        pageSize: 100,
        pageSizes: [20, 50, 100],
        total: 0,
      },
    }
  },
  computed: {
    ...mapGetters([
      'boxHeight',
      'settlementFlag',
    ]),
    ...mapState({
      // 渠道
      signChannelList: (state) => state.authentication.signChannelList,
      // 商户号
      signChannelMerchantNoList: (state) => state.authentication.signChannelMerchantNoList,
      // 鉴权状态
      signStatusList: (state) => state.authentication.signStatusList,
    }),
  },
  created () {
    this.checkColumns()
    this.initForm()
    if (!this.settlementFlag) {
      this.getSelect()
    }
    // 有权限就自动查询
    if (isPermissionBtn('/tradeInfo/authList')) {
      this.fetchData({})
    }
  },
  methods: {
    // settlementFlag  0 ：不需要结算标记  1：需要结算标记‘
    // 0： 显示全列表项  1： 隐藏部分列表项  不需要拉取对应数据
    checkColumns () {
      if (!this.settlementFlag) {
        this.tableColumns = authTableALL
      } else {
        this.tableColumns = authTable
      }
    },
    initForm () {
      this.queryForm.time = [getDay('YYYY-MM-DD'), getDay('YYYY-MM-DD')]
    },
    async fetchSignChannel () {
      const res = await commonApi.signChannel()
      this.$store.commit('SETSignChannelList', res.result)
    },
    async fetchSignChannelMerchantNo () {
      const res = await commonApi.signChannelMerchantNo()
      this.$store.commit('SETSignChannelMerchantNoList', res.result)
    },
    async fetchSignStatus () {
      const res = await commonApi.signStatus()
      this.$store.commit('SETSignStatusList', res.result)
    },
    getSelect () {
      this.fetchSignChannel()
      this.fetchSignChannelMerchantNo()
      this.fetchSignStatus()
    },
    async fetchData (obj) {
      let flag = validateDay(this.queryForm.time[0], this.queryForm.time[1], 7)
      if (!flag) {
        return this.$message.warning(`查询时间跨度支持7天内`)
      }
      if (obj.pageNum) {
        this.pageable.pageNum = obj.pageNum
        this.pageable.pageSize = obj.pageSize
      }
      let data = {
        ...this.queryForm,
        startDate: this.queryForm.time[0] ? this.queryForm.time[0] : '',
        endDate: this.queryForm.time[1] ? this.queryForm.time[1] : '',
        currentPage: this.pageable.pageNum,
        pageSize: this.pageable.pageSize,
      }
      delete data.time
      this.isLoading = true
      try {
        let res = await api.authList(data)
        this.tableData = res.result.list
        this.pageable.total = res.result.total
      } catch (e) {
        this.tableData = []
      } finally {
        this.isLoading = false
      }
    },
  },
}
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.itemFirst {
  width: 200px;
  margin-left: 50px;
}
.font-info {
  color: #99a9bf;
  font-size: 12px;
  margin-left: 10px;
}
.queryItem {
  width: 120px;
}
</style>
