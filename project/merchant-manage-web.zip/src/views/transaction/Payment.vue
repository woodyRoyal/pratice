<template>
  <div>
    <el-form size="mini"
             :inline="true"
             label-width="100px">
      <el-form-item label="订单创建时间">
        <el-date-picker v-model="queryForm.time"
                        style="width:350px;"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        :picker-options="pickerOptions"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期"
                        align="right">
        </el-date-picker>
      </el-form-item>
      <el-form-item v-if="!settlementFlag"
                    label="渠道商户号">
        <el-select v-model="queryForm.channelAccountNo"
                   class="queryItem"
                   clearable>
          <el-option value=""
                     label="全部"></el-option>
          <el-option v-for="(item,index) in tradeChannelMerchantNoList"
                     :key="index"
                     :value="item"
                     :label="item">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item v-if="!settlementFlag"
                    label="支付渠道">
        <el-select v-model="queryForm.payChannelCode"
                   class="queryItem"
                   clearable>
          <el-option value=""
                     label="全部"></el-option>
          <el-option v-for="(item,index) in tradeChannelList"
                     :key="index"
                     :value="item"
                     :label="item">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item v-if="!settlementFlag"
                    label="商户订单号">
        <el-input v-model="queryForm.reqOrderNo"
                  class="queryItem"></el-input>
      </el-form-item>
      <el-form-item label="交易订单号">
        <el-input v-model="queryForm.businessOrderNo"
                  class="queryItem"></el-input>
      </el-form-item>
      <el-form-item v-if="!settlementFlag"
                    label="交易类型">
        <el-select v-model="queryForm.type"
                   class="queryItem"
                   clearable>
          <el-option value=""
                     label="全部"></el-option>
          <el-option v-for="(item,index) in tradeTypeList"
                     :key="index"
                     :value="item.code"
                     :label="item.message">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item v-if="!settlementFlag"
                    label="交易状态">
        <el-select v-model="queryForm.status"
                   class="queryItem"
                   clearable>
          <el-option value=""
                     label="全部"></el-option>
          <el-option v-for="(item,index) in tradeStatusList"
                     :key="index"
                     :value="item.code"
                     :label="item.description">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label=" "
                    label-width="30px">
        <el-button v-directiveBtns="'/tradeInfo/repaymentList'"
                   type="primary"
                   :loading="isLoading"
                   @click="fetchData">
          查询
        </el-button>
      </el-form-item>
    </el-form>
    <VueTable :is-loading="isLoading"
              :columns="tableColumns"
              :data="tableData"
              :is-show-pagination="true"
              :pageable="pageable"
              @getTableData="fetchData">
              <!--行数据 row-->
    </VueTable>
  </div>
</template>

<script>
import { mapGetters, mapState } from 'vuex'
import api from '../../api/transaction/Payment'
import commonApi from '../../api/commonApi/commonApi'
import { getDay, validateDay } from '../../utils/common'
import { PaymentTableALL, PaymentTable } from './config'
import VueTable from '@/components/VueTable'
import { isPermissionBtn } from '@/utils/index'
export default {
  name: 'Personal',
  components: { VueTable },
  data () {
    return {
      // 列表loading
      isLoading: false,
      // 表格配置项
      tableColumns: PaymentTable,
      pickerOptions: {
        disabledDate (time) {
          return time.getTime() < (Date.now() - 365 * 24 * 60 * 60 * 1000);
        },
        shortcuts: [{
          text: '最近一周',
          onClick (picker) {
            const end = new Date();
            const start = new Date();
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
            picker.$emit('pick', [start, end]);
          },
        }],
      },
      queryForm: {
        //发起时间
        time: [],
        // 渠道商户号
        channelAccountNo: '',
        // 支付渠道
        payChannelCode: '',
        // 商户订单号
        reqOrderNo: '',
        // 交易订单号
        businessOrderNo: '',
        // 交易状态
        status: '',
        // 交易类型
        type: '',
      },
      tableData: [],
      pageable: {
        pageNum: 1,
        pageSize: 100,
        pageSizes: [20, 50, 100],
        total: 0,
      },
    }
  },
  computed: {
    ...mapGetters([
      'boxHeight',
      'settlementFlag',
    ]),
    ...mapState({
      // 交易类型
      tradeTypeList: (state) => state.Payment.tradeTypeList,
      // 交易状态
      tradeStatusList: (state) => state.Payment.tradeStatusList,
      // 支付渠道
      tradeChannelList: (state) => state.Payment.tradeChannelList,
      // 交易商户号
      tradeChannelMerchantNoList: (state) => state.Payment.tradeChannelMerchantNoList,
    }),
  },
  created () {
    this.checkColumns()
    this.initForm()
    // settlementFlag  0 ：不需要结算标记  1：需要结算标记‘
    // 0： 显示全项   1：隐藏部分项 不需要拉取对应数据
    if (!this.settlementFlag) {
      this.getSelect()
    }
    // 有权限就自动查询
    if (isPermissionBtn('/tradeInfo/repaymentList')) {
      this.fetchData({})
    }
  },
  methods: {
    // settlementFlag  0 ：不需要结算标记  1：需要结算标记‘
    // 0： 显示全列表项  1： 隐藏部分列表项 
    checkColumns () {
      if (!this.settlementFlag) {
        this.tableColumns = PaymentTableALL
      } else {
        this.tableColumns = PaymentTable
      }
    },
    initForm () {
      this.queryForm.time = [getDay('YYYY-MM-DD'), getDay('YYYY-MM-DD')]
    },
    async fetchTradeType () {
      const res = await commonApi.tradeType()
      this.$store.commit('SETTradeTypeList', res.result)
    },
    async fetchTradeStatus () {
      const res = await commonApi.tradeStatus()
      this.$store.commit('SETtradeStatusList', res.result)
    },
    async fetchTradeChannel () {
      const res = await commonApi.tradeChannel()
      this.$store.commit('SETTradeChannelList', res.result)
    },
    async fetchTradeChannelMerchantNo () {
      const res = await commonApi.tradeChannelMerchantNo()
      this.$store.commit('SETTradeChannelMerchantNoList', res.result)
    },
    getSelect () {
      this.fetchTradeType()
      this.fetchTradeStatus()
      this.fetchTradeChannel()
      this.fetchTradeChannelMerchantNo()
    },
    async fetchData (pageable) {
      let flag = validateDay(this.queryForm.time[0], this.queryForm.time[1], 7)
      if (!flag) {
        return this.$message.warning(`查询时间跨度支持7天内`)
      }
      if (pageable.pageNum) {
        this.pageable.pageNum = pageable.pageNum
        this.pageable.pageSize = pageable.pageSize
      }
      let data = {
        ...this.queryForm,
        startDate: this.queryForm.time[0] ? this.queryForm.time[0] : '',
        endDate: this.queryForm.time[1] ? this.queryForm.time[1] : '',
        currentPage: this.pageable.pageNum,
        pageSize: this.pageable.pageSize,
      }
      delete data.time
      this.isLoading = true
      try {
        let res = await api.repaymentList(data)
        this.tableData = res.result.list
        this.pageable.total = res.result.total
      } catch (e) {
        this.tableData = []
      } finally {
        this.isLoading = false
      }
    },
  },
}
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.itemFirst {
  width: 200px;
  margin-left: 50px;
}
.font-info {
  color: #99a9bf;
  font-size: 12px;
  margin-left: 10px;
}
.queryItem {
  width: 120px;
}
</style>
