import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import 'normalize.css/normalize.css' // normalize.css 样式格式化
import './styles/index.scss' // 全局自定义的css样式
import * as filters from './filters'
import {
  directiveBtns,
} from './directive/permission'
// 按钮权限自定义指令 v-directiveBtns="'btn_policy_edit'"
Vue.use(directiveBtns)
// 全局注册所有过滤器
Object.keys(filters).forEach((key) => {
  Vue.filter(key, filters[key])
})


Vue.use(ElementUI)
Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount('#app')
