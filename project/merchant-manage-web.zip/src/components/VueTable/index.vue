<template>
  <div>
    <el-table v-loading="isLoading"
              :data="data"
              :border="border"
              :stripe="stripe"
              :height="height"
              :max-height="maxHeight"
              style="width: 100%">
      <el-table-column v-for="(item, key) in columns"
                       :key="key"
                       :label="item.label"
                       :prop="item.prop"
                       :align="item.align"
                       :width="item.width"
                       :show-overflow-tooltip="item.showOverflowTooltip">
        <template slot-scope="scope">
          <template v-if="!item.slot">
            {{ scope.row[item.prop] }}
          </template>
          <template v-if="item.slot">
            <slot :name="item.slot"
                  :row="scope.row"
                  :$index="scope.$index"></slot>
          </template>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination v-if="isShowPagination"
                   class="pagination"
                   :current-page="pageable.pageNum"
                   :page-sizes="pageable.pageSizes"
                   :page-size="pageable.pageSize"
                   layout="total, sizes, prev, pager, next, jumper"
                   :total="pageable.total"
                   @size-change="handleSizeChange"
                   @current-change="handleCurrentChange">
    </el-pagination>
  </div>
</template>

<script>
export default {
  name: 'VueTable',
  props: {
    isLoading: {
      type: Boolean,
      default: false,
    },
    data: {
      type: Array,
      required: true,
      default: () => [],
    },
    border: {
      type: Boolean,
      default: true,
    },
    stripe: {
      type: Boolean,
      default: false,
    },
    height: {
      type: [String, Number],
      default: null,
    },
    maxHeight: {
      type: [String, Number],
      default: null,
    },
    columns: {
      type: Array,
      required: true,
      default: () => [],
    },
    isShowPagination: {
      type: Boolean,
      default: false,
    },
    pageable: {
      type: Object,
      default: () => ({
        pageNum: 1,
        pageSize: 100,
        pageSizes: [10, 20, 50, 100, 200],
        total: 0,
      }),
    },
  },
  data () {
    return {
    }
  },
  methods: {
    handleSizeChange (val) {
      this.pageable.pageSize = val
      const { pageNum, pageSize } = this.pageable
      this.$emit('getTableData', { pageNum, pageSize })
    },
    handleCurrentChange (val) {
      this.pageable.pageNum = val
      const { pageNum, pageSize } = this.pageable
      this.$emit('getTableData', { pageNum, pageSize })
    },
  },
}
</script>

<style lang="scss" scoped>
.pagination {
  display: flex;
  justify-content: flex-end;
}
</style>
