<template>
  <el-breadcrumb class="app-breadcrumb"
                 separator="/">
    <transition-group name="breadcrumb">
      <el-breadcrumb-item v-for="(item,index) in levelList"
                          :key="item.path">
        <template v-if="item.name">
          <span v-if="item.redirect === 'noredirect' || index === levelList.length - 1"
                class="no-redirect">{{ item.name }}</span>
          <router-link v-else
                       :to="item.redirect || item.path">
            {{ item.name }}
          </router-link>
        </template>
      </el-breadcrumb-item>
    </transition-group>
  </el-breadcrumb>
</template>

<script>
export default {
  data () {
    return {
      levelList: null,
    }
  },
  watch: {
    $route () {
      this.getBreadcrumb()
    },
  },
  created () {
    this.getBreadcrumb()
  },
  methods: {
    getBreadcrumb () {
      const matched = this.$route.matched.filter((item) => item.name)
      const first = { ...matched[0] }
      const second = { ...matched[1] }
      if (first && first.name && first.name.trim() === '首页') {
        first.name = ''
        this.levelList = [second]
      } else {
        this.levelList = matched
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.app-breadcrumb.el-breadcrumb {
  display: inline-block;
  font-size: 14px;
  line-height: 50px;
  margin-left: 10px;
  .no-redirect {
    color: #97a8be;
    cursor: text;
  }
}

.breadcrumb-enter-active,
.breadcrumb-leave-active {
  transition: all 0.5s;
}
.breadcrumb-enter,
.breadcrumb-leave-active {
  opacity: 0;
  transform: translateX(20px);
}
.breadcrumb-leave-active {
  position: absolute;
}
</style>
