export const options = [{
    label: '发起时间',
    type: 'daterange',
    model: 'time',
    value: ['2019-10-10', '2019-10-10'],
    format: 'yyyy-MM-dd',
    pickerOptions: {
      disabledDate(time) {
        return time.getTime() < (Date.now() - 365 * 24 * 60 * 60 * 1000);
      },
      shortcuts: [{
        text: '最近一周',
        onClick(picker) {
          const end = new Date();
          const start = new Date();
          start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
          picker.$emit('pick', [start, end]);
        },
      }],
    },
  },
  {
    label: '姓名',
    type: 'input',
    model: 'name',
    value: '',
    placeholder: '请填写',
  },
  {
    label: '商户',
    type: 'select',
    model: 'NO',
    value: '',
    clearable: true,
    placeholder: '',
    selectList: [{
        label: '选项1',
        value: '内容1',
      },
      {
        label: '选项2',
        value: '内容2',
      },
    ],
  },
]
