import request from '../../utils/request'
export default {
  // 获取鉴权列表
  authList(params) {
    return request({
      url: '/tradeInfo/authList',
      method: 'get',
      params,
    })
  },
}
