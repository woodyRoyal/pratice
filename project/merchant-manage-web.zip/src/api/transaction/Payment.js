import request from '../../utils/request'
export default {
  //获取代扣列表
  repaymentList(params) {
    return request({
      url: '/tradeInfo/repaymentList',
      method: 'get',
      params,
    })
  },
}
