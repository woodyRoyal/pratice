import request from '../../utils/request'
export default {
  // 鉴权渠道下拉列表
  signChannel() {
    return request({
      url: '/tradeInfo/signChannel',
      method: 'get',
    })
  },
  // 交易渠道商户号下拉列表
  tradeChannelMerchantNo(data) {
    return request({
      url: '/tradeInfo/tradeChannelMerchantNo',
      method: 'get',
      data,
    })
  },
  // 交易状态
  tradeStatus(data) {
    return request({
      url: '/tradeInfo/tradeStatus',
      method: 'get',
      data,
    })
  },
  // 支付渠道号下拉列表
  tradeChannel(data) {
    return request({
      url: '/tradeInfo/tradeChannel',
      method: 'get',
      data,
    })
  },
  // 鉴权状态
  signStatus(data) {
    return request({
      url: '/tradeInfo/signStatus',
      method: 'get',
      data,
    })
  },
  // 鉴权渠道商户号下拉列表
  signChannelMerchantNo(data) {
    return request({
      url: '/tradeInfo/signChannelMerchantNo',
      method: 'get',
      data,
    })
  },
  // 交易类型
  tradeType(data) {
    return request({
      url: '/tradeInfo/tradeType',
      method: 'get',
      data,
    })
  },
}
