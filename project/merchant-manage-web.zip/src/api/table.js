import request from '../utils/request'
export default {
  fetchGetTableData() {
    return request({
      url: 'getTableData',
      method: 'get',
    })
  },
}
