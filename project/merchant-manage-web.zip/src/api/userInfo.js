import request from '../utils/request'
export default {
  // 个人中心
  querySelf() {
    return request({
      url: '/user/querySelf',
      method: 'get',
    })
  },
  updateSelf(data) {
    return request({
      url: '/user/updateSelf',
      method: 'post',
      data,
    })
  },
  queryMerchantInfo(data) {
    return request({
      url: '/merchant/queryMerchantInfo',
      method: 'get',
      data,
    })
  },
}
