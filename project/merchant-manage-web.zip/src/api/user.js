import request from '../utils/request'
export default {
  // 登录
  fetchLogin(data) {
    return request({
      url: 'user/login',
      method: 'post',
      data,
    })
  },
  // 查询自身权限列表
  fetchGetMenuTreeList() {
    return request({
      url: 'permission/selfPermissionTree',
      method: 'get',
    })
  },
  // 查询当前用户权限及权限列表
  fetchGetPermissionList() {
    return request({
      url: 'permission/permissionList',
      method: 'get',
    })
  },
  // 获取验证码
  fetchGetCaptcha() {
    return request({
      url: 'captcha/login',
      method: 'get',
    })
  },
  // 退出
  fetchLogout() {
    return request({
      url: 'user/logout',
      method: 'get',
    })
  },
  // 查询商户信息
  queryMerchantInfo(data) {
    return request({
      url: '/merchant/queryMerchantInfo',
      method: 'get',
      data,
    })
  },
}
