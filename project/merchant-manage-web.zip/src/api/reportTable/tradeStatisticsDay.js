import request from '../../utils/request'
export default {
  // 获取全流水
  tradeStatisticsDay(params) {
    return request({
      url: '/tradeStatisticsDay/list',
      method: 'get',
      params,
    })
  },
  // 预导出excel
  exportPre(params) {
    return request({
      url: '/tradeStatisticsDay/exportPre',
      method: 'get',
      params,
    })
  },
  // 获取下载链接
  export (params) {
    return request({
      url: '/tradeStatisticsDay/export',
      method: 'get',
      params,
    })
  },
}
