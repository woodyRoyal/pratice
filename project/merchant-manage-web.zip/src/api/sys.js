import request from '../utils/request'
export default {
  /* **************角色管理************** */
  // 获取角色列表
  fetchRoleList(params) {
    return request({
      url: 'role/queryAll',
      method: 'get',
      params,
    })
  },
  // 获取启用角色列表
  fetchStatusOnRoleList(params) {
    return request({
      url: 'role/queryStatusOnRoleList',
      method: 'get',
      params,
    })
  },
  // 获取权限树
  fetchPermissionTree() {
    return request({
      url: 'permission/allTree',
      method: 'get',
    })
  },
  // 获取权限列表
  fetchPermissionList() {
    return request({
      url: 'permission/all',
      method: 'get',
    })
  },
  // 新增角色
  fetchAddRole(data) {
    return request({
      url: 'role/add',
      method: 'post',
      data,
    })
  },
  // 更新角色
  fetchUpdateRole(data) {
    return request({
      url: 'role/update/' + data.id,
      method: 'post',
      data,
    })
  },
  // 查询指定id的角色
  fetchGetRoleById(id) {
    return request({
      url: 'role/queryById/' + id,
      method: 'get',
    })
  },
  // 删除角色
  fetchDeleteRole(id) {
    return request({
      url: 'role/delete/' + id,
      method: 'delete',
    })
  },
  /* **************用户管理************** */
  // 获取用户列表
  fetchUserList(params) {
    return request({
      url: 'user/queryAll',
      method: 'get',
      params,
    })
  },
  // 重置密码
  fetchResetPassword(id) {
    return request({
      url: 'user/resetPassword/' + id,
      method: 'post',
    })
  },
  // 新增用户
  fetchAddUser(data) {
    return request({
      url: 'user/add',
      method: 'post',
      data,
    })
  },
  // 更新用户
  fetchUpdateUser(data) {
    return request({
      url: 'user/update/' + data.id,
      method: 'post',
      data,
    })
  },
  // 查询指定id的用户
  fetchGetUserById(id) {
    return request({
      url: 'user/query/' + id,
      method: 'get',
    })
  },
}
