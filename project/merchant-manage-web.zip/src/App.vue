<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style lang="scss">
@import url(//at.alicdn.com/t/font_1454621_cupj2vrkkvp.css);
</style>