import Layout from '../../layout/Layout'

const tradeStatisticsDay = (resolve) => require(['../../views/reportTable/tradeStatisticsDay.vue'], resolve)

const reportTableRouter = {
  path: '/reportTable',
  name: '报表管理',
  alwaysShow: true,
  icon: 'iconfont icondabaobiaoguanli',
  redirect: 'noredirect',
  component: Layout,
  children: [{
    path: 'tradeStatisticsDay',
    name: '交易全流水报表',
    icon: 'iconfont iconliushui',
    component: tradeStatisticsDay,
  }],
}
export default reportTableRouter
