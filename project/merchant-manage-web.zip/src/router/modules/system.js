import Layout from '../../layout/Layout'

const role = (resolve) => require(['../../views/system/role.vue'], resolve)
const user = (resolve) => require(['../../views/system/user.vue'], resolve)

const systemRouter = {
  path: '/system',
  name: '用户权限管理',
  alwaysShow: true,
  icon: 'iconfont iconxitongguanli',
  redirect: 'noredirect',
  component: Layout,
  children: [{
      path: 'role',
      name: '角色管理',
      icon: 'iconfont iconyidongyunkongzhitaiicon45',
      component: role,
    },
    {
      path: 'user',
      name: '用户管理',
      icon: 'iconfont iconyonghuguanli',
      component: user,
    },
  ],
}
export default systemRouter
