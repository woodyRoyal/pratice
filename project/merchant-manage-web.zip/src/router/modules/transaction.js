import Layout from '../../layout/Layout'

const authentication = (resolve) => require(['../../views/transaction/authentication.vue'], resolve)
const Payment = (resolve) => require(['../../views/transaction/Payment.vue'], resolve)

const transactionRouter = {
  path: '/transaction',
  name: '交易管理',
  alwaysShow: true,
  icon: 'iconfont iconjiaoyi',
  redirect: 'noredirect',
  component: Layout,
  children: [{
      path: 'authentication',
      name: '鉴权查询',
      icon: 'iconfont iconxiangmujianquan',
      component: authentication,
    },
    {
      path: 'payment',
      name: '收付款交易查询',
      icon: 'iconfont iconshoufukuan',
      component: Payment,
    },
  ],
}
export default transactionRouter
