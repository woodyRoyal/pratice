import Vue from 'vue'
import Router from 'vue-router'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import store from '../store'
// import {
//   Message,
// } from 'element-ui'
import {
  pendingRequest,
} from '@/utils/request'


/* Layout */
import Layout from '../layout/Layout'

/* Router Modules */
import transactionRouter from './modules/transaction'
import reportTableRouter from './modules/reportTable'
import systemRouter from './modules/system'

// login页面
const loginPage = (resolve) => require(['../views/login/index.vue'], resolve)
// home页面
const homePage = (resolve) => require(['../views/home/home.vue'], resolve)
// 个人中心
const personal = (resolve) => require(['../views/userInfo/personal.vue'], resolve)
const merchant = (resolve) => require(['../views/userInfo/merchant.vue'], resolve)

NProgress.inc(0.2)
NProgress.configure({
  easing: 'ease',
  speed: 100,
  showSpinner: false,
})

Vue.use(Router)
export const constantRouterMap = [{
  path: '/login',
  name: '登录',
  hidden: true,
  component: loginPage,
}, {
  path: '/home',
  name: '首页',
  hidden: true,
  icon: 'el-icon-s-home',
  redirect: 'noredirect',
  component: Layout,
  children: [{
    path: 'index',
    name: '首页',
    icon: 'el-icon-s-home',
    component: homePage,
  }],
}, {
  path: '/userInfo',
  name: '个人中心',
  icon: 'iconfont iconiconfontgerenzhongxin',
  redirect: 'noredirect',
  component: Layout,
  children: [{
      path: 'personal',
      name: '个人信息',
      icon: 'iconfont icongerenxinxi',
      component: personal,
    },
    {
      path: 'merchant',
      name: '商户信息',
      icon: 'iconfont iconshanghu',
      component: merchant,
    },
  ],
}]

const router = new Router({
  scrollBehavior: () => ({
    y: 0,
  }),
  routes: constantRouterMap,
})

export const asyncRouterMap = [
  transactionRouter,
  reportTableRouter,
  systemRouter,
]

// 路由树转换为键值对对象 path为key
function routerTreeListToMapObj(treeList) {
  const mapObj = {}
  treeList.map((item) => transObj(item, mapObj))
  return mapObj
}
// 转换对象
function transObj(source, target) {
  if (!source.path) {
    return
  }
  target[source.path] = {}
  if (source.name) {
    target[source.path].name = source.name
  }
  if (source.component) {
    target[source.path].component = source.component
  }
  if (source.icon) {
    target[source.path].icon = source.icon
  }
  if (source.redirect) {
    target[source.path].redirect = source.redirect
  }
  if (source.hidden) {
    target[source.path].hidden = source.hidden
  }
  if (source.alwaysShow) {
    target[source.path].alwaysShow = source.alwaysShow
  }
  // 递归处理子菜单
  if (source.children && source.children.length > 0) {
    source.children.map((item) => transObj(item, target))
  }
  return target
}

// 输出路由映射对象
export const asyncRouterMapObj = routerTreeListToMapObj(asyncRouterMap)
// “*” 匿名路由须放在最后
export const lastRouterConst = [{
  path: '*',
  redirect: '/home/index',
  hidden: true,
}]

const whiteList = ['/login'] // no redirect whitelist

router.beforeEach(async (to, from, next) => {
  // 路由跳转时，把上个页面还没结束的请求取消掉
  pendingRequest.forEach((item) => {
    item.routeChangeCancel && item.cancel()
  })

  // 修改页面标题
  document.title = to.name
  NProgress.start()

  if (store.getters.username) {
    const menuTreeList = store.getters.menuTreeList
    if (menuTreeList && menuTreeList.length) {
      if (store.getters.addRouters.length === 0) { // 判断当前用户是否已有可访问的路由表
        const accessRoutes = await store.dispatch('GenerateRoutes', menuTreeList)
        router.addRoutes(accessRoutes) // 动态添加可访问路由表
        next(to.path)
      } else {
        next()
      }
    } else {
      await store.dispatch('SetRouterLast', menuTreeList)
      next()
    }
  } else {
    if (whiteList.indexOf(to.path) !== -1) {
      // in the free login whitelist, go directly
      next()
    } else {
      // other pages that do not have permission to access are redirected to the login page.
      // Message.warning('用户信息已过期, 请重新登录')
      next('/login')
      document.title = '登录'
      NProgress.done()
    }
  }
})
router.afterEach(() => {
  NProgress.done()
})

export default router
