import Vue from 'vue'
import {
  getFromStorage,
} from '@/utils/storage'
const directiveBtns = () => Vue.directive('directiveBtns', {
  bind(el, binding) {
    let btns = getFromStorage('local', 'btns')
    if (btns && btns.length > 0) {
      let a = btns.filter((item) => "'" + item + "'" === binding.expression)
      if (a && a.length < 1) {
        el.style.display = "none"
      }
    } else {
      console.log('无按钮权限')
      el.style.display = "none"
    }
  },
})

export {
  directiveBtns,
}
