const packageInfo = require('./package.json')
const isDev = process.env.NODE_ENV === 'development'
const isProd = process.env.NODE_ENV === 'production'
module.exports = {
  publicPath: isDev ? '/' : '', // 二级目录路径
  outputDir: packageInfo.name, // 构建目录名称
  productionSourceMap: !isProd, // 生产环境sourceMap
  css: {
    sourceMap: !isProd, // CSS sourceMap
  },
  lintOnSave: isDev, // 保存立即检查
  // 开发运行相关配置
  devServer: {
    open: true, // 自动打开浏览器
    port: 8081, // 端口
    proxy: {
      '/merchant-manage/': {
        // target: 'http://yapi.2345intra.com',
        target: 'http://d1-managerdaikuan.2345.com',
        ws: false, // 是否启用websockets,此项目不存在ws连接
        changOrigin: true, // 是否将请求header中的origin修改为目标地址
        // pathRewrite: {
        //   '^/merchant-manage/': '/mock/54/',
        // },
      },
    }, // 转发代理配置
    // 浏览器 overlay（刷新） 同时显示eslint的警告和错误
    overlay: {
      warnings: true,
      errors: true,
    },
  },
  runtimeCompiler: true, // 运行时是否需要编译
}
